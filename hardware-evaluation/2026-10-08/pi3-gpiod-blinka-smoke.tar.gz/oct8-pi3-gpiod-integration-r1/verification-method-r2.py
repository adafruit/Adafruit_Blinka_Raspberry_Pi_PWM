"""Fresh Pi 3 private venv and frozen-wheel inventory; never request GPIO."""

import email
import hashlib
import importlib.metadata as metadata
import json
import os
import platform
import re
import struct
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

MODEL = "Raspberry Pi 3 Model B Plus Rev 1.4"
BOOT = "7daae0fd-0934-48b8-b9d0-f5665d932eec"
WHEELS = {
    "adafruit_platformdetect-3.89.1-py3-none-any.whl": "a5324036805c70304cceb01a32eb87df226569357bb86e26272f0219421c0359",
    "adafruit_pureio-1.1.12-py3-none-any.whl": "b3445a2b90034ca18d889dc5e4402683a52176678d7c2863d60b62e614a66238",
    "binho_host_adapter-0.1.6-py3-none-any.whl": "f71ca176c1e2fc1a5dce128beb286da217555c6c7c805f2ed282a6f3507ec277",
    "pyftdi-0.57.2-py3-none-any.whl": "dec3acdc262594d8b1850a6aee608b861c2973f90011faf5cccae3107d3c67a4",
    "packaging-26.3-py3-none-any.whl": "414c46fcfb5f98edc3e3139a1f1d780e01cf76995b072f11975c665fcc57de83",
    "adafruit_circuitpython_typing-1.12.3-py3-none-any.whl": "91b1aadc1af601a70292979c24457f365de9fda31d8501bc4c806ac2346cbbf9",
    "sysv_ipc-1.2.0-cp313-cp313-manylinux2014_aarch64.manylinux_2_17_aarch64.manylinux_2_28_aarch64.whl": "977f0e313c2e663000f0c316682ea2c3f6d2f86bbbdb1bcd274fea244a211df0",
    "adafruit_circuitpython_busdevice-5.2.17-py3-none-any.whl": "7f2f0fa5e7352c06fa39cb2c73e332ebc23e471e8cfac207a0ba27ebbb652293",
    "adafruit_circuitpython_requests-4.1.17-py3-none-any.whl": "cfae517c9273efd082c9c82147924fa2a90a7da54f15208f606ed929c643db31",
    "adafruit_circuitpython_connectionmanager-3.1.8-py3-none-any.whl": "51973f85a3df87070783bb54794a17fb1f783727ebe0d4e1ad734815de8f85c6",
    "typing_extensions-4.16.0-py3-none-any.whl": "481caa481374e813c1b176ada14e97f1f67a4539ce9cfeb3f350d78d6370c2e8",
    "pyserial-3.5-py2.py3-none-any.whl": "c4451db6ba391ca6ca299fb3ec7bae67a5c55dde170964c7a14ceefec02f2cf0",
    "pyusb-1.3.1-py3-none-any.whl": "cb7933555f05f6bf0b6219111c3d4433148a3567ddfb250f3e6e8dfc7f6cee3a",
    "gpiod-2.5.0-cp313-cp313-manylinux2014_aarch64.manylinux_2_17_aarch64.manylinux_2_28_aarch64.whl": "c6b51959d24461d55fbafc1a6d1accd0904bb1de76182f7479b2bc473d86cfc8",
    "adafruit_blinka_raspberry_pi_pwm-0.0.1.dev0-cp313-cp313-linux_aarch64.whl": "abaaa8a147b1e50fca28635dc0214eb0fde133d194c2ef871eff495acf7fb4ad",
    "adafruit_blinka-9.0.5.dev77-py3-none-any.whl": "19fe8a3c20de1684cf594f78e0b815837a0e34e6c8b196e8ef19f60d1f3e70ab",
}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    need(path.is_file() and not path.is_symlink() and path.resolve() == path, str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(arguments):
    result = subprocess.run(
        arguments,
        capture_output=True,
        text=True,
        check=False,
        timeout=60,
        env={
            **os.environ,
            "PIP_CONFIG_FILE": "/dev/null",
            "PIP_DISABLE_PIP_VERSION_CHECK": "1",
        },
    )
    return {
        "arguments": arguments,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


def platform_gate():
    need(
        sys.flags.isolated and sys.platform == "linux" and os.getuid() == 1000,
        "Isolated Linux pi user required",
    )
    need(
        platform.node() == "test-pi3"
        and platform.machine() == "aarch64"
        and struct.calcsize("P") == 8,
        "Exact ARM64 bench required",
    )
    need(
        platform.python_version() == "3.13.5"
        and platform.release() == "6.18.50+rpt-rpi-v8",
        "Exact Python/kernel required",
    )
    need(
        Path("/proc/device-tree/model").read_text().rstrip("\x00\n") == MODEL
        and Path("/proc/sys/kernel/random/boot_id").read_text().strip() == BOOT,
        "Model/boot changed",
    )
    need(
        not any(
            k.startswith("BLINKA_") or k in ("PYTHONPATH", "PYTHONHOME")
            for k in os.environ
        ),
        "Dispatch/path overrides forbidden",
    )
    flags = run(["vcgencmd", "get_throttled"])
    need(
        flags["returncode"] == 0 and flags["stdout"] == "throttled=0x0\n",
        "Throttle flags nonzero",
    )
    need(
        int(Path("/sys/class/thermal/thermal_zone0/temp").read_text()) < 65000,
        "Bench too warm",
    )


def main():
    platform_gate()
    if sys.argv[1] == "bootstrap":
        root = Path(tempfile.mkdtemp(prefix="blinka-pi3-gpio.", dir="/tmp"))
        result = run([sys.executable, "-I", "-m", "venv", str(root / "venv")])
        with (root / "bootstrap.json").open("x") as stream:
            json.dump({"remote_root": str(root), "venv": result}, stream, indent=2)
        need(result["returncode"] == 0, "Private venv creation failed")
        (root / "wheelhouse").mkdir(mode=0o700)
        print(json.dumps({"remote_root": str(root), "venv": result}, indent=2))
        return
    need(sys.argv[1] in ("install", "verify-installed"), "Unknown stage")
    root = Path(__file__).parent
    need(
        re.fullmatch(r"/tmp/blinka-pi3-gpio\.[A-Za-z0-9_]{6,16}", str(root))
        and root.resolve() == root,
        "Fresh canonical root required",
    )
    need(
        root.stat().st_uid == 1000
        and root.stat().st_mode & 0o777 == 0o700
        and sys.executable == str(root / "venv/bin/python"),
        "Private root/Python required",
    )
    house, site, helper = (
        root / "wheelhouse",
        root / "venv/lib/python3.13/site-packages",
        root / "pi3_gpiod_integration_smoke.py",
    )
    need(
        not (root / "manifest.json").exists() and sha(helper) == sys.argv[2],
        "Fresh manifest/frozen helper required",
    )
    need(
        {p.name for p in house.iterdir()} == set(WHEELS),
        "Exact 16-wheel inputs required",
    )
    for name, expected in WHEELS.items():
        need(sha(house / name) == expected, "Wheel bytes changed: " + name)
    install_arguments = [
        sys.executable,
        "-I",
        "-m",
        "pip",
        "install",
        "--no-index",
        "--no-deps",
        *[str(house / name) for name in WHEELS],
    ]
    check_arguments = [sys.executable, "-I", "-m", "pip", "check"]
    if sys.argv[1] == "install":
        install = run(install_arguments)
        with (root / "install.json").open("x") as stream:
            json.dump(install, stream, indent=2)
        check = run(check_arguments)
        with (root / "pip-check.json").open("x") as stream:
            json.dump(check, stream, indent=2)
    else:
        install = json.loads((root / "install.json").read_text())
        check = json.loads((root / "pip-check.json").read_text())
        need(install["arguments"] == install_arguments, "Original install differs")
        need(check["arguments"] == check_arguments, "Original pip check differs")
    need(install["returncode"] == 0, "Offline private installation failed")
    need(check["returncode"] == 0, "Private dependency closure incomplete")
    versions, checked, relocated_scripts = {}, 0, []
    for name in WHEELS:
        with zipfile.ZipFile(house / name) as archive:
            info = email.message_from_bytes(
                archive.read(
                    next(
                        n
                        for n in archive.namelist()
                        if n.endswith(".dist-info/METADATA")
                    )
                )
            )
            versions[info["Name"]] = metadata.version(info["Name"])
            need(
                versions[info["Name"]] == info["Version"],
                "Distribution version mismatch",
            )
            for entry in archive.namelist():
                if entry.endswith((".py", ".so", ".json")):
                    wheel_bytes = archive.read(entry)
                    if ".data/scripts/" in entry:
                        script_name = entry.split(".data/scripts/", 1)[1]
                        need("/" not in script_name, "Unexpected script subdirectory")
                        target = root / "venv/bin" / script_name
                        need(
                            wheel_bytes.startswith(b"#!python\n"),
                            "Unexpected script header",
                        )
                        installed_bytes = target.read_bytes()
                        need(
                            installed_bytes
                            == b"#!"
                            + sys.executable.encode()
                            + b"\n"
                            + wheel_bytes.split(b"\n", 1)[1],
                            "Relocated script payload differs: " + entry,
                        )
                        relocated_scripts.append(
                            {
                                "wheel_entry": entry,
                                "installed_path": str(target),
                                "installed_sha256": sha(target),
                                "payload_compared": True,
                                "pip_shebang_rewrite": True,
                            }
                        )
                        continue
                    need(
                        ".data/" not in entry, "Unsupported wheel relocation: " + entry
                    )
                    need(
                        (site / entry).read_bytes() == wheel_bytes,
                        "Installed source differs from frozen wheel: " + entry,
                    )
                    checked += 1
    source_paths = {
        str(p.relative_to(site)): str(p)
        for p in sorted(site.rglob("*"))
        if p.suffix in (".py", ".so", ".json")
    }
    source_paths[helper.name] = str(helper)
    for alias, pattern in (
        ("gpiod/_ext.so", "gpiod/_ext*.so"),
        (
            "adafruit_blinka_raspberry_pi_pwm/_native.so",
            "adafruit_blinka_raspberry_pi_pwm/_native*.so",
        ),
    ):
        matches = list(site.glob(pattern))
        need(len(matches) == 1, "Unique native extension required")
        source_paths[alias] = str(matches[0])
    import gpiod  # Metadata inspection only, never requests a line.

    candidates = []
    for path in sorted({p.resolve() for p in Path("/dev").glob("gpiochip*")}):
        with gpiod.Chip(str(path)) as chip:
            info = chip.get_info()
            if info.label == "pinctrl-bcm2835":
                need(
                    all(not chip.get_line_info(g).used for g in (18, 23)),
                    "Test lines already owned",
                )
                candidates.append(
                    {
                        "path": str(path),
                        "name": info.name,
                        "label": info.label,
                        "num_lines": info.num_lines,
                        "device_number": f"{os.major(path.stat().st_rdev)}:{os.minor(path.stat().st_rdev)}",
                        "of_node": str(
                            (
                                Path("/sys/bus/gpio/devices") / info.name / "of_node"
                            ).resolve(strict=True)
                        ),
                    }
                )
    need(len(candidates) == 1, "Unique BCM283x controller required")
    blinka = house / "adafruit_blinka-9.0.5.dev77-py3-none-any.whl"
    manifest = {
        "schema_version": 1,
        "remote_root": str(root),
        "overlay_site": str(site),
        "model": MODEL,
        "kernel": platform.release(),
        "python_version": platform.python_version(),
        "boot_id": BOOT,
        "machine": platform.machine(),
        "python_bits": 64,
        "pwm_zero_handoff": True,
        "boot_config_sha256": {
            p: sha(Path(p)) for p in ("/boot/config.txt", "/boot/firmware/config.txt")
        },
        "controller": candidates[0],
        "distribution_versions": versions,
        "source_paths": source_paths,
        "source_sha256": {k: sha(Path(p)) for k, p in source_paths.items()},
        "wheel": {"path": str(blinka), "sha256": sha(blinka)},
        "wheel_sha256": WHEELS,
        "installed_wheel_source_files_compared": checked,
        "relocated_scripts": relocated_scripts,
        "pip_check": check,
    }
    with (root / "manifest.json").open("x") as stream:
        json.dump(manifest, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                "remote_root": str(root),
                "install": install,
                "pip_check": check,
                "manifest_sha256": sha(root / "manifest.json"),
                "compared_sources": checked,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
