"""Read-only postflight for the single Pi 3 GPIO smoke; never request a line."""

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import gpiod


def main():
    root = Path("/tmp/blinka-pi3-gpio.evpgg91e")
    if not sys.flags.isolated or sys.executable != str(root / "venv/bin/python"):
        raise RuntimeError("Exact isolated private Python required")
    manifest_path = root / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    result = {
        "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        "temperature_millic": int(
            Path("/sys/class/thermal/thermal_zone0/temp").read_text()
        ),
        "queries": [],
    }

    def query(arguments):
        completed = subprocess.run(
            arguments, capture_output=True, text=True, timeout=3, check=False
        )
        row = {
            "arguments": arguments,
            "returncode": completed.returncode,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
        }
        result["queries"].append(row)
        if completed.returncode:
            raise RuntimeError("Read-only command failed")
        return completed.stdout

    result["throttled"] = query(["vcgencmd", "get_throttled"])
    result["pinctrl"] = {str(g): query(["pinctrl", "get", str(g)]) for g in (18, 23)}
    with gpiod.Chip(manifest["controller"]["path"]) as chip:
        result["lines"] = {
            str(g): {
                "used": chip.get_line_info(g).used,
                "consumer": chip.get_line_info(g).consumer,
            }
            for g in (18, 23)
        }
    result["boot_config_unchanged"] = all(
        hashlib.sha256(Path(p).read_bytes()).hexdigest() == value
        for p, value in manifest["boot_config_sha256"].items()
    )
    result["sources_unchanged"] = all(
        hashlib.sha256(Path(path).read_bytes()).hexdigest()
        == manifest["source_sha256"][key]
        for key, path in manifest["source_paths"].items()
    )
    # Scan as bytes, constructing the needle separately so this stdin method
    # cannot match itself; do not signal or modify any process.
    needle = b"pi3_gpiod_" + b"integration_smoke.py"
    result["remaining_helper_pids"] = []
    for directory in Path("/proc").iterdir():
        if directory.name.isdigit() and int(directory.name) != os.getpid():
            try:
                if needle in (directory / "cmdline").read_bytes():
                    result["remaining_helper_pids"].append(int(directory.name))
            except (FileNotFoundError, PermissionError, ProcessLookupError):
                pass
    result["success"] = (
        result["boot_id"] == manifest["boot_id"]
        and result["boot_config_unchanged"]
        and result["sources_unchanged"]
        and result["throttled"] == "throttled=0x0\n"
        and result["temperature_millic"] < 70000
        and not result["remaining_helper_pids"]
        and all(
            not row["used"] and row["consumer"] is None
            for row in result["lines"].values()
        )
        and all("| lo //" in value for value in result["pinctrl"].values())
    )
    print(json.dumps(result, indent=2))
    return 0 if result["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
