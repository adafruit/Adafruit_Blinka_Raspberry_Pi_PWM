"""Reuse recording-only ownership fakes; no GPIO, native calls or processes."""

import errno
import re
import sys
from pathlib import Path
from types import SimpleNamespace as NS

import pytest

import pi3_gpiod_integration_smoke as smoke
import test_pi_gpiod_integration_smoke as prior_tests


@pytest.fixture
def recorded(monkeypatch):
    # The retained fake fixture calls whichever helper its module selects.
    # Do not edit the earlier helper/tests or use any real native binding.
    monkeypatch.setattr(prior_tests, "smoke", smoke)
    return prior_tests.recorded.__wrapped__(monkeypatch)


def test_public_pin_sequences_release_reclaim_and_zero_handoff(recorded):
    labels = [row["operation"] for row in recorded.report["events"]]
    for gpio in (18, 23):
        inputs = [
            row["result"]
            for row in recorded.report["events"]
            if row["operation"].startswith(f"GPIO{gpio}:input_")
        ]
        outputs = [
            row["result"]
            for row in recorded.report["events"]
            if row["operation"].startswith(f"GPIO{gpio}:output_")
        ]
        assert inputs == [True, False, False]
        assert outputs == [False, True, False]
        assert labels.count(f"GPIO{gpio}:pin_reclaim") == 2
        assert getattr(recorded.board, f"D{gpio}")._line_request is None
    assert recorded.report["busy_errno"] == errno.EBUSY
    assert "GPIO18:reclaim_after_pwm" in labels
    assert not recorded.owners and not recorded.report["cleanup_errors"]


def test_dual_ownership_is_independent(recorded):
    both = recorded.report["both_owned_input_down"]
    assert all(
        row["used"] and row["direction"] == "INPUT" and row["bias"] == "PULL_DOWN"
        for row in both.values()
    )
    after = recorded.report["after_deinit18_with23_owned"]
    assert not after[18]["used"] and after[23]["used"]
    assert ("read", 23, False, (23,)) in recorded.calls


@pytest.mark.parametrize("attempt", ["module", "chip", "failure"])
def test_import_hooks_restored_after_denied_claim_or_failure(monkeypatch, attempt):
    monkeypatch.setattr(prior_tests, "smoke", smoke)
    prior_tests.test_import_request_hooks_restored_on_forbidden_claim_or_failure(
        monkeypatch, attempt
    )


@pytest.mark.parametrize("present", [False, True])
def test_optional_spec_probe_does_not_import_foreign_gpio(
    monkeypatch, tmp_path, present
):
    monkeypatch.setattr(prior_tests, "smoke", smoke)
    prior_tests.test_dependency_spec_probe_is_genuine_but_import_execution_is_refused(
        monkeypatch, tmp_path, present
    )


@pytest.mark.parametrize("wrong", [None, "board", "chip", "pin_map", "alias"])
def test_imports_require_real_pi3_dispatch_and_genuine_alias_identity(
    monkeypatch, wrong
):
    class Pin:
        def __init__(self, gpio):
            self.id, self._chip, self._line_request = gpio, None, None

        def __eq__(self, other):
            return self.id == getattr(other, "id", other)

    class Chip:
        def request_lines(self, **_kwargs):
            pytest.fail("Import unexpectedly requested a line")

    bcm = NS(__name__="adafruit_blinka.microcontroller.bcm283x.pin", Pin=Pin)
    board = NS(board_id="RASPBERRY_PI_3B_PLUS")
    for gpio in (2, 3, 11, 18, 23):
        pin = Pin(gpio)
        setattr(board, f"D{gpio}", pin)
        setattr(bcm, f"D{gpio}", pin)
    board.SDA, board.SCL, board.SCK = board.D2, board.D3, board.D11
    agnostic = NS(chip_id="BCM2XXX")
    pwm_class = type("PWMOut", (), {})
    modules = {
        "board": board,
        "digitalio": NS(Pin=Pin),
        "pwmio": NS(PWMOut=pwm_class),
        smoke.BASE + "raspberry_pi_pin": NS(Pin=Pin),
        smoke.BASE + "raspberry_pi_pwmout": NS(PWMOut=pwm_class),
        bcm.__name__: bcm,
        "adafruit_blinka.agnostic": agnostic,
    }
    if wrong == "board":
        board.board_id = "RASPBERRY_PI_4B"
    elif wrong == "chip":
        agnostic.chip_id = "BCM2711"
    elif wrong == "pin_map":
        bcm.Pin = object
    elif wrong == "alias":
        board.D18 = Pin(18)
    lib = NS(Chip=Chip, request_lines=lambda **_kwargs: pytest.fail("No GPIO request"))
    previous = lib.request_lines, Chip.request_lines
    monkeypatch.setattr(smoke, "importlib", NS(import_module=modules.__getitem__))
    monkeypatch.setattr(smoke, "origins", lambda *_args: None)
    report = {}
    if wrong is None:
        assert smoke.imports(lib, {}, report) == (
            board,
            modules["digitalio"],
            modules["pwmio"],
        )
        assert report["dispatch"] == {
            "board_id": "RASPBERRY_PI_3B_PLUS",
            "chip_id": "BCM2XXX",
            "pin_map": bcm.__name__,
        }
    else:
        with pytest.raises(RuntimeError, match="dispatch|genuine lazy"):
            smoke.imports(lib, {}, report)
    assert report["import_request_hooks_restored"]
    assert (lib.request_lines, Chip.request_lines) == previous


@pytest.mark.parametrize("kind", ["pin", "digitalio", "pwm"])
def test_partial_cleanup_never_claims_or_writes_unowned_line(monkeypatch, kind):
    monkeypatch.setattr(prior_tests, "smoke", smoke)
    prior_tests.test_cleanup_never_claims_or_writes_unowned_partial_objects(kind)


def test_cleanup_preserves_both_low_and_release_errors(monkeypatch):
    monkeypatch.setattr(prior_tests, "smoke", smoke)
    prior_tests.test_cleanup_retains_low_and_deinit_errors()


@pytest.mark.parametrize(
    "configuration,level,direction,accepted",
    [
        ("ip    --", "lo", "input", True),
        ("ip pd", "lo", "input", True),
        ("op -- --", "lo", "output", True),
        ("op -- pn", "lo", "output", True),
        ("op dl --", "lo", "output", True),
        ("op dh --", "lo", "output", False),
        ("op -- --", "hi", "output", False),
        ("ip    --", "hi", "input", False),
        ("ip    --", "lo", "output", False),
    ],
)
def test_free_low_grammar_records_unknown_bias_but_not_high_or_high_drive(
    configuration, level, direction, accepted
):
    rows = {
        gpio: {
            "used": False,
            "consumer": None,
            "pinctrl": f"{gpio}: {configuration} | {level} // GPIO{gpio} = {direction}\n",
        }
        for gpio in (18, 23)
    }
    assert smoke.free_low(rows) is accepted
    rows[18]["used"] = True
    assert not smoke.free_low(rows)


@pytest.mark.parametrize(
    "root,accepted",
    [
        ("/tmp/blinka-pi3-gpio.aB_1234567", True),
        ("/tmp/blinka-pi3-gpio.123456", True),
        ("/tmp/blinka-pi3-gpio.", False),
        ("/tmp/blinka-pi3-gpio.a/../../other", False),
        ("/tmp/blinka-pi3-gpio.123456/child", False),
        ("/tmp/blinka-pwm-pi3.ohoO6y", False),
    ],
)
def test_only_new_private_root_pattern_is_accepted(root, accepted):
    assert (re.fullmatch(smoke.ROOT_PATTERN, root) is not None) is accepted


def test_inspect_path_never_exercises_outputs(monkeypatch):
    rows = {
        gpio: {
            "used": False,
            "consumer": None,
            "pinctrl": f"{gpio}: ip    -- | lo // GPIO{gpio} = input\n",
        }
        for gpio in (18, 23)
    }
    signals = []
    fake_signal = NS(
        SIGALRM=14,
        SIGTERM=15,
        ITIMER_REAL=0,
        getsignal=lambda sig: "previous" + str(sig),
        getitimer=lambda _timer: (0.0, 0.0),
        signal=lambda *args: signals.append(("signal", args)),
        setitimer=lambda *args: signals.append(("timer", args)),
    )
    monkeypatch.setattr(smoke, "signal", fake_signal)
    monkeypatch.setattr(smoke, "read_manifest", lambda _path: {})
    monkeypatch.setattr(smoke, "digest", lambda _path: "frozen")
    monkeypatch.setattr(smoke, "gate", lambda *_args: None)
    monkeypatch.setattr(smoke, "importlib", NS(import_module=lambda _name: NS()))
    monkeypatch.setattr(smoke, "snapshot", lambda *_args: rows)
    monkeypatch.setattr(smoke, "imports", lambda *_args: (NS(), NS(), NS()))
    monkeypatch.setattr(smoke, "origins", lambda *_args: None)
    monkeypatch.setattr(
        smoke, "exercise", lambda *_args: pytest.fail("inspect constructed GPIO")
    )
    monkeypatch.setattr(Path, "read_text", lambda _path: "35000")
    monkeypatch.setattr(smoke, "query", lambda *_args: "throttled=0x0\n")
    before = dict(sys.modules)
    result = smoke.run(
        Path("/tmp/blinka-pi3-gpio.1234567890"),
        Path("/tmp/blinka-pi3-gpio.1234567890/venv/site"),
        Path("manifest.json"),
        inspect_only=True,
    )
    assert result["success"] and result["inspect_only"]
    assert not result["events"] and not result["cleanup_errors"]
    assert not result["analyzer_used"] and not result["pwm_timing_tested"]
    assert all(name in before for name in sys.modules)
    assert signals[-3:] == [
        ("timer", (0, 0)),
        ("signal", (14, "previous14")),
        ("signal", (15, "previous15")),
    ]
