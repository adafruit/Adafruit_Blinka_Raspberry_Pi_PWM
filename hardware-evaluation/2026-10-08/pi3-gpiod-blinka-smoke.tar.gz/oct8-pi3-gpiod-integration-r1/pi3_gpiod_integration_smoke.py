"""Finite Pi 3B+ GPIO integration and zero-duty PWM ownership smoke; lab only.

No waveform/timing measurement, PIO or actuators. --inspect imports and reads
metadata but never constructs an output. The 20-second alarm cannot bound stuck
native/kernel calls or SIGKILL. LOW/read/free are sampled observations only.
"""

import argparse
import errno
import hashlib
import importlib
import importlib.metadata
import json
import os
import platform
import re
import signal
import struct
import subprocess
import sys
import time
from contextlib import redirect_stdout
from importlib.machinery import PathFinder
from pathlib import Path

BASE = "adafruit_blinka.microcontroller.generic_linux."
NATIVE = "adafruit_blinka_raspberry_pi_pwm"
MODEL = "Raspberry Pi 3 Model B Plus Rev 1.4"
ROOT_PATTERN = r"/tmp/blinka-pi3-gpio\.[A-Za-z0-9_]{6,16}"
FOREIGN = (
    "RPi",
    "lgpio",
    "rp1pio",
    "_rpi_ws281x",
    "adafruit_raspberry_pi5_neopixel_write",
)
REQUIRED = {
    "board.py",
    "digitalio.py",
    "pwmio.py",
    "board_imports.json",
    "microcontroller_imports.json",
    "pi3_gpiod_integration_smoke.py",
    "adafruit_blinka/platform_dependencies.py",
    "adafruit_blinka/importing.py",
    "adafruit_blinka/agnostic/__init__.py",
    "adafruit_blinka/board/raspberrypi/raspi_40pin.py",
    "adafruit_blinka/microcontroller/bcm283x/pin.py",
    "gpiod/__init__.py",
    "gpiod/_ext.so",
    *(NATIVE + "/" + p for p in ("__init__.py", "_software.py", "_native.so")),
    *(
        BASE.replace(".", "/") + p
        for p in (
            "raspberry_pi_pin.py",
            "raspberry_pi_pwmout.py",
            "libgpiod_pin.py",
            "libgpiod/libgpiod_pin_2_x.py",
        )
    ),
}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(path):
    path = Path(path)
    need(
        path.is_file() and not path.is_symlink() and path.resolve() == path,
        "Regular canonical source required: " + str(path),
    )
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "Duplicate manifest key: " + key)
            result[key] = value
        return result

    return json.loads(
        Path(path).read_text(),
        object_pairs_hook=pairs,
        parse_constant=lambda value: need(False, "Nonfinite JSON: " + value),
    )


def query(report, arguments):
    result = subprocess.run(
        arguments, capture_output=True, text=True, timeout=3, check=False
    )
    report.setdefault("queries", []).append(
        {
            "arguments": arguments,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    )
    need(result.returncode == 0, "Read-only command failed: " + str(arguments))
    return result.stdout


def gate(root, site, manifest, report):
    need(
        re.fullmatch(ROOT_PATTERN, str(root)) is not None
        and root.resolve() == root
        and not root.is_symlink()
        and root.stat().st_uid == os.getuid() == 1000
        and root.stat().st_mode & 0o777 == 0o700,
        "Canonical private Pi 3 root owned by pi with mode 700 required",
    )
    need(
        site.is_dir() and site.resolve() == site and site.is_relative_to(root),
        "Canonical private overlay required",
    )
    need(Path(__file__).resolve().is_relative_to(root), "Helper outside root")
    need(
        type(manifest["schema_version"]) is int
        and manifest["schema_version"] == 1
        and manifest["remote_root"] == str(root)
        and manifest["overlay_site"] == str(site),
        "Manifest root/site mismatch",
    )
    need(
        sys.flags.isolated
        and sys.platform == "linux"
        and Path(sys.executable) == root / "venv/bin/python",
        "Isolated declared Linux venv required",
    )
    need(
        not sys.stdin.isatty() and not sys.stdout.isatty(),
        "Noninteractive process required",
    )
    need(
        not any(
            k.startswith("BLINKA_") or k in ("PYTHONPATH", "PYTHONHOME")
            for k in os.environ
        ),
        "Inherited dispatch/path overrides forbidden",
    )
    prefixes = (
        "board",
        "digitalio",
        "pwmio",
        "adafruit_blinka",
        "gpiod",
        NATIVE,
        *FOREIGN,
    )
    need(
        not any(n == p or n.startswith(p + ".") for n in sys.modules for p in prefixes),
        "Fresh process required",
    )
    need(
        REQUIRED <= manifest["source_paths"].keys() == manifest["source_sha256"].keys(),
        "Complete source map required",
    )
    for key, path in manifest["source_paths"].items():
        need(
            Path(path).is_relative_to(root)
            and digest(path) == manifest["source_sha256"][key],
            "Private source bytes changed: " + key,
        )
    need(
        manifest["source_paths"][Path(__file__).name] == str(Path(__file__).resolve()),
        "Actual helper path mismatch",
    )
    need(
        digest(manifest["wheel"]["path"]) == manifest["wheel"]["sha256"],
        "Wheel bytes changed",
    )
    actual = {
        "model": Path("/proc/device-tree/model").read_text().rstrip("\x00\n"),
        "kernel": platform.release(),
        "python_version": platform.python_version(),
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        "machine": platform.machine(),
        "python_bits": struct.calcsize("P") * 8,
    }
    need(
        actual["model"] == MODEL and all(actual[k] == manifest[k] for k in actual),
        "Platform/model/boot/ABI changed",
    )
    need(
        actual["machine"] == "aarch64"
        and actual["python_bits"] == 64
        and manifest["pwm_zero_handoff"] is True,
        "This profile requires confirmed ARM64 current native zero-duty handoff",
    )
    need(
        set(manifest["boot_config_sha256"])
        == {"/boot/config.txt", "/boot/firmware/config.txt"}
        and all(
            digest(path) == expected
            for path, expected in manifest["boot_config_sha256"].items()
        ),
        "Boot configuration changed",
    )
    controller = manifest["controller"]
    need(
        controller["label"] == "pinctrl-bcm2835"
        and re.fullmatch(r"gpiochip[0-9]+", controller["name"]) is not None
        and controller["path"] == "/dev/" + controller["name"]
        and Path(controller["path"]).resolve() == Path(controller["path"]),
        "Canonical Pi 3 header controller required",
    )
    device = Path(controller["path"]).stat()
    of_node = Path("/sys/bus/gpio/devices") / controller["name"] / "of_node"
    need(
        f"{os.major(device.st_rdev)}:{os.minor(device.st_rdev)}"
        == controller["device_number"]
        and str(of_node.resolve(strict=True)) == controller["of_node"],
        "Controller device/OF changed",
    )
    actual["temperature_millic"] = int(
        Path("/sys/class/thermal/thermal_zone0/temp").read_text()
    )
    actual["throttled"] = query(report, ["vcgencmd", "get_throttled"])
    need(
        actual["temperature_millic"] < 65_000
        and actual["throttled"] == "throttled=0x0\n",
        "Thermal gate failed",
    )
    report.update(
        platform=actual,
        source_paths=manifest["source_paths"],
        source_sha256=manifest["source_sha256"],
        wheel=manifest["wheel"],
        pwm_zero_handoff=True,
        scope="GPIO functionality and zero-duty PWM ownership only",
        analyzer_used=False,
        pwm_timing_tested=False,
    )
    sys.path.insert(0, str(site))
    versions = {
        name: importlib.metadata.version(name)
        for name in manifest["distribution_versions"]
    }
    need(
        versions == manifest["distribution_versions"]
        and versions.get("Adafruit-Blinka") == "9.0.5.dev77"
        and versions.get("gpiod") == "2.5.0"
        and versions.get("Adafruit-Blinka-Raspberry-Pi-PWM") == "0.0.1.dev0",
        "Exact declared evaluation runtime versions required",
    )
    report["distribution_versions"] = versions


def snapshot(lib, manifest, report):
    controller = manifest["controller"]
    rows = {}
    with lib.Chip(controller["path"]) as chip:
        info = chip.get_info()
        need(
            (info.name, info.label, info.num_lines)
            == tuple(controller[k] for k in ("name", "label", "num_lines")),
            "Controller metadata changed",
        )
        for gpio in (18, 23):
            line = chip.get_line_info(gpio)
            rows[gpio] = {
                "used": line.used,
                "consumer": line.consumer,
                "direction": line.direction.name,
                "bias": line.bias.name,
                "pinctrl": query(report, ["pinctrl", "get", str(gpio)]),
            }
    return rows


def free_low(rows):
    for gpio, row in rows.items():
        # Older BCM2835 pull state is not readable by pinctrl; preserve '--'
        # verbatim but require LOW, no owner and a supported input/output mode.
        grammar = (
            rf"{gpio}: (?:ip +(?:pd|pu|pn|--) \| lo // GPIO{gpio} = input"
            rf"|op (?:--|dl) (?:pd|pu|pn|--) \| lo // GPIO{gpio} = output)\n"
        )
        if row["used"] or row["consumer"] not in (None, ""):
            return False
        if re.fullmatch(grammar, row["pinctrl"]) is None:
            return False
    return set(rows) == {18, 23}


def origins(manifest, report):
    found = {}
    prefixes = (
        "adafruit_blinka",
        NATIVE,
        "gpiod",
        "adafruit_platformdetect",
        "packaging",
    )
    for name, module in list(sys.modules.items()):
        if name in ("board", "digitalio", "pwmio") or name.startswith(prefixes):
            path = getattr(module, "__file__", None)
            if path:
                need(
                    path in manifest["source_paths"].values(),
                    "Undeclared loaded source: " + name,
                )
                found[name] = path
    need(
        not any(n == p or n.startswith(p + ".") for n in sys.modules for p in FOREIGN),
        "Foreign GPIO/PIO import occurred",
    )
    report["module_origins"] = found


def imports(lib, manifest, report):
    previous = lib.request_lines, lib.Chip.request_lines

    class NoForeignGPIO:
        def create_module(self, _spec):
            raise RuntimeError("Foreign GPIO/PIO import forbidden")

        exec_module = create_module

        def find_spec(self, name, path=None, _target=None):
            if not any(name == p or name.startswith(p + ".") for p in FOREIGN):
                return None
            spec = PathFinder.find_spec(name, path)
            if spec is not None:
                spec.loader = self
            return spec

    finder = NoForeignGPIO()

    def deny(*_args, **_kwargs):
        raise RuntimeError("Import-phase GPIO request forbidden")

    sys.meta_path.insert(0, finder)
    lib.request_lines = lib.Chip.request_lines = deny
    try:
        with redirect_stdout(sys.stderr):
            board, dio, pwm = (
                importlib.import_module(name)
                for name in ("board", "digitalio", "pwmio")
            )
        pin = importlib.import_module(BASE + "raspberry_pi_pin").Pin
        adapter = importlib.import_module(BASE + "raspberry_pi_pwmout").PWMOut
        bcm = importlib.import_module("adafruit_blinka.microcontroller.bcm283x.pin")
        agnostic = importlib.import_module("adafruit_blinka.agnostic")
        need(
            board.board_id == "RASPBERRY_PI_3B_PLUS"
            and agnostic.chip_id == "BCM2XXX"
            and bcm.Pin is pin,
            "Real Pi 3 board/BCM283x dispatch required",
        )
        need(
            dio.Pin is pin and pwm.PWMOut is adapter,
            "Actual Pin/PWM adapter identities required",
        )
        for gpio in (18, 23):
            alias = getattr(board, "D" + str(gpio))
            need(
                alias is getattr(bcm, "D" + str(gpio))
                and type(alias) is pin
                and type(alias.id) is int
                and alias.id == gpio
                and alias._line_request is None
                and alias._chip is None,
                "Integer genuine lazy BCM283x Pin identity required",
            )
        need(
            board.SDA == board.D2 and board.SCL == board.D3 and board.SCK == board.D11,
            "Board aliases differ",
        )
        report["dispatch"] = {
            "board_id": board.board_id,
            "chip_id": agnostic.chip_id,
            "pin_map": bcm.__name__,
        }
        origins(manifest, report)
        return board, dio, pwm
    finally:
        sys.meta_path.remove(finder)
        lib.request_lines, lib.Chip.request_lines = previous
        report["import_request_hooks_restored"] = (
            lib.request_lines,
            lib.Chip.request_lines,
        ) == previous


def event(report, label, operation):
    row = {"operation": label, "begin_ns": time.monotonic_ns()}
    report["events"].append(row)
    try:
        result = operation()
        row.update(status="ok", result=result)
        return result
    except BaseException as error:
        row.update(status="error", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        row["end_ns"] = time.monotonic_ns()


def hold(report, label, change, read, expected):
    def phase():
        change()
        time.sleep(0.08)
        value = read()
        need(
            expected is None or value is expected,
            "Unexpected public readback: " + label,
        )
        return value

    return event(report, label, phase)


def cleanup(kind, obj, report):
    def low():
        pin = getattr(obj, "_pin", None) if kind == "digitalio" else obj
        if kind == "pwm":
            native = getattr(obj, "_pwm", None)
            if getattr(getattr(native, "_engine", None), "_request", None) is not None:
                obj.duty_cycle = 0
        elif getattr(pin, "_line_request", None) is not None:
            if kind == "digitalio":
                obj.switch_to_output(value=False)
            else:
                obj.init(mode=obj.OUT)
                obj.value(False)

    for label, operation in (("owned_low", low), ("public_deinit", obj.deinit)):
        try:
            event(report, kind + ":" + label, operation)
        except BaseException as error:
            report["cleanup_errors"].append(f"{type(error).__name__}: {error}")


def exercise(board, dio, pwm, lib, manifest, report, owned):
    def new(kind, cls, *args, **kwargs):
        obj = cls.__new__(cls)
        owned.append((kind, obj))
        event(report, kind + ":constructor", lambda: obj.__init__(*args, **kwargs))
        return obj

    for gpio in (18, 23):
        peer = 23 if gpio == 18 else 18
        baseline = snapshot(lib, manifest, report)[peer]
        pin = getattr(board, "D" + str(gpio))
        obj = new("digitalio", dio.DigitalInOut, pin)
        for name, pull, expected in (
            ("up", dio.Pull.UP, True),
            ("down", dio.Pull.DOWN, False),
            ("none", None, None),
        ):
            hold(
                report,
                f"GPIO{gpio}:input_{name}",
                lambda p=pull, o=obj: o.switch_to_input(pull=p),
                lambda o=obj: o.value,
                expected,
            )
            state = snapshot(lib, manifest, report)
            report.setdefault("active_line_snapshots", []).append(
                {"phase": f"GPIO{gpio}:input_{name}", "lines": state}
            )
            need(
                state[gpio]["used"]
                and state[gpio]["direction"] == "INPUT"
                and state[gpio]["bias"]
                == {"up": "PULL_UP", "down": "PULL_DOWN", "none": "DISABLED"}[name],
                "Active input direction/bias mismatch",
            )
            need(state[peer] == baseline, "Inactive peer changed")
        for name, value in (("low", False), ("high", True), ("low", False)):
            hold(
                report,
                f"GPIO{gpio}:output_{name}",
                lambda v=value, o=obj: o.switch_to_output(value=v),
                lambda o=obj: o.value,
                value,
            )
            need(
                snapshot(lib, manifest, report)[peer] == baseline,
                "Inactive peer changed",
            )
        cleanup("digitalio", obj, report)
        clone = new("pin", type(pin), gpio)
        for _attempt in range(2):
            hold(
                report,
                f"GPIO{gpio}:pin_reclaim",
                lambda c=clone: c.init(mode=c.IN, pull=c.PULL_DOWN),
                lambda c=clone: c.value(),
                False,
            )
            cleanup("pin", clone, report)
        need(
            pin._line_request is None
            and snapshot(lib, manifest, report)[peer] == baseline,
            "Board alias/peer must remain unclaimed",
        )

    baseline = snapshot(lib, manifest, report)[23]
    output = new(
        "pwm",
        pwm.PWMOut,
        board.D18,
        frequency=50,
        duty_cycle=0,
        variable_frequency=False,
    )
    need(
        type(output._pwm) is importlib.import_module(NATIVE).PWMOut
        and output.duty_cycle == 0,
        "Actual zero-duty native instance required",
    )
    hold(report, "GPIO18:pwm_zero", lambda: None, lambda: output.duty_cycle == 0, True)
    try:
        new("digitalio", dio.DigitalInOut, board.D18)
    except OSError as error:
        need(error.errno == errno.EBUSY, "Expected exact EBUSY ownership conflict")
        report["busy_errno"] = error.errno
        report["events"][-1]["expected_busy_conflict"] = True
    else:
        raise RuntimeError("Owned PWM line was incorrectly reclaimed")
    cleanup("pwm", output, report)
    obj = new("digitalio", dio.DigitalInOut, board.D18)
    hold(
        report,
        "GPIO18:reclaim_after_pwm",
        lambda: obj.switch_to_input(pull=dio.Pull.DOWN),
        lambda: obj.value,
        False,
    )
    cleanup("digitalio", obj, report)
    need(
        snapshot(lib, manifest, report)[23] == baseline,
        "GPIO23 changed during PWM handoff",
    )

    both = [
        new("digitalio", dio.DigitalInOut, getattr(board, "D" + str(gpio)))
        for gpio in (18, 23)
    ]
    for obj in both:
        obj.switch_to_input(pull=dio.Pull.DOWN)
    hold(
        report,
        "both:input_down",
        lambda: None,
        lambda: all(obj.value is False for obj in both),
        True,
    )
    report["both_owned_input_down"] = snapshot(lib, manifest, report)
    need(
        all(
            row["used"] and row["direction"] == "INPUT" and row["bias"] == "PULL_DOWN"
            for row in report["both_owned_input_down"].values()
        ),
        "Both lines must be independently owned inputs",
    )
    cleanup("digitalio", both[0], report)
    state = snapshot(lib, manifest, report)
    report["after_deinit18_with23_owned"] = state
    need(
        not state[18]["used"] and state[23]["used"] and both[1].value is False,
        "Deinit18 invalidated independently owned GPIO23",
    )
    cleanup("digitalio", both[1], report)


def run(root, site, manifest_path, inspect_only=False):
    report = {
        "pid": os.getpid(),
        "begin_ns": time.monotonic_ns(),
        "events": [],
        "cleanup_errors": [],
        "success": False,
        "inspect_only": inspect_only,
        "parity_pass": None,
        "analyzer_used": False,
        "pwm_timing_tested": False,
    }
    owned, lib, manifest, armed = [], None, None, False
    previous = {sig: signal.getsignal(sig) for sig in (signal.SIGALRM, signal.SIGTERM)}

    def interrupted(_signum, _frame):
        raise TimeoutError("Bounded smoke interrupted")

    try:
        need(
            signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0),
            "Inherited alarm forbidden",
        )
        armed = True
        for sig in previous:
            signal.signal(sig, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 20)
        manifest = read_manifest(manifest_path)
        report["manifest_sha256"] = digest(manifest_path)
        gate(root, site, manifest, report)
        lib = importlib.import_module("gpiod")
        report["initial_lines"] = snapshot(lib, manifest, report)
        need(free_low(report["initial_lines"]), "Both lines must start free LOW")
        board, dio, pwm = imports(lib, manifest, report)
        need(
            free_low(snapshot(lib, manifest, report)), "Imports changed free LOW lines"
        )
        if not inspect_only:
            exercise(board, dio, pwm, lib, manifest, report, owned)
        origins(manifest, report)
    except BaseException as error:
        report["primary_error"] = f"{type(error).__name__}: {error}"
    finally:
        for kind, obj in reversed(owned):
            cleanup(kind, obj, report)
        if lib is not None:
            try:
                report["final_lines"] = snapshot(lib, manifest, report)
                need(free_low(report["final_lines"]), "Final lines not free LOW")
                final_temp = int(
                    Path("/sys/class/thermal/thermal_zone0/temp").read_text()
                )
                flags = query(report, ["vcgencmd", "get_throttled"])
                report["final_thermal"] = {
                    "temperature_millic": final_temp,
                    "throttled": flags,
                }
                need(
                    final_temp < 70_000 and flags == "throttled=0x0\n",
                    "Final thermal gate failed",
                )
            except BaseException as error:
                report["cleanup_errors"].append(f"{type(error).__name__}: {error}")
        if armed:
            signal.setitimer(signal.ITIMER_REAL, 0)
            for sig, handler in previous.items():
                signal.signal(sig, handler)
        report["end_ns"] = time.monotonic_ns()
        report["success"] = (
            "primary_error" not in report and not report["cleanup_errors"]
        )
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "site", "manifest"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--inspect", action="store_true")
    args = parser.parse_args()
    result = run(args.root, args.site, args.manifest, args.inspect)
    print(json.dumps(result, indent=2, allow_nan=False))
    sys.exit(0 if result["success"] else 1)
