"""Archive this finite Pi 3 smoke; byte-only verification, never GPIO replay."""

import hashlib
import json
import tarfile
from pathlib import Path

LAB = Path(__file__).resolve().parent
RUN = LAB / "oct8-pi3-gpiod-integration-r1"
REPO = LAB.parent / "Adafruit_Blinka_Raspberry_Pi_PWM"
DESTINATION = REPO / "hardware-evaluation/2026-10-08"
REFERENCES = {
    "hardware-evaluation/2026-10-07/pi5-installed-blinka-consumer-evaluation.tar.gz": "59f3b680d1420faa9a11dbd1925ab24583bec181a4a70b24742404f99bda4748",
    "hardware-evaluation/2026-10-08/pi-gpiod-blinka-integration.tar.gz": "4f0c00640753a47e225449441f43f67264599ed7d669568fe65c251d1f3899fe",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = json.loads((RUN / "manifest.json").read_text())
    wheels = manifest["wheel_sha256"]
    found = {}
    for name, expected in REFERENCES.items():
        path = REPO / name
        if sha(path) != expected:
            raise ValueError("Referenced archive changed: " + name)
        with tarfile.open(path, "r:gz") as stream:
            for member in stream.getmembers():
                basename = Path(member.name).name
                if basename in wheels and member.isfile():
                    actual = hashlib.sha256(
                        stream.extractfile(member).read()
                    ).hexdigest()
                    if actual != wheels[basename]:
                        raise ValueError("Reference wheel differs: " + basename)
                    found[basename] = {
                        "archive": name,
                        "member": member.name,
                        "sha256": actual,
                    }
    if found.keys() != wheels.keys():
        raise ValueError(
            "Missing recovery wheels: " + str(wheels.keys() - found.keys())
        )
    with (RUN / "wheel-recovery-references.json").open("x") as stream:
        json.dump(
            {
                "archive_sha256": REFERENCES,
                "wheels": found,
                "byte_comparison_passed": True,
                "extraction_or_replay_performed": False,
            },
            stream,
            indent=2,
        )
        stream.write("\n")
    paths = [Path(__file__), *sorted(RUN.iterdir())]
    for path in paths:
        if (
            not path.is_file()
            or path.is_symlink()
            or path.resolve() != path
            or not path.is_relative_to(LAB)
        ):
            raise ValueError("Canonical regular evidence required: " + str(path))
    expected = {str(p.relative_to(LAB)): sha(p) for p in paths}
    archive = DESTINATION / "pi3-gpiod-blinka-smoke.tar.gz"
    if not DESTINATION.is_dir() or archive.exists():
        raise ValueError("Existing destination and fresh archive required")
    with tarfile.open(archive, "x:gz") as stream:
        for path in sorted(paths):
            stream.add(path, arcname=str(path.relative_to(LAB)), recursive=False)
    with tarfile.open(archive, "r:gz") as stream:
        members = stream.getmembers()
        if (
            len(members) != len(expected)
            or {m.name for m in members} != expected.keys()
            or any(not m.isfile() for m in members)
        ):
            raise ValueError("Unexpected archive members")
        for member in members:
            if (
                hashlib.sha256(stream.extractfile(member).read()).hexdigest()
                != expected[member.name]
            ):
                raise ValueError("Archive differs from source: " + member.name)
    receipt = {
        "archive": archive.name,
        "sha256": sha(archive),
        "size_bytes": archive.stat().st_size,
        "regular_files": len(expected),
        "member_sha256": expected,
        "byte_comparison_passed": True,
        "extraction_or_live_replay_performed": False,
    }
    with (DESTINATION / "pi3-gpiod-archive-verification.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps({k: v for k, v in receipt.items() if k != "member_sha256"}, indent=2)
    )


if __name__ == "__main__":
    main()
