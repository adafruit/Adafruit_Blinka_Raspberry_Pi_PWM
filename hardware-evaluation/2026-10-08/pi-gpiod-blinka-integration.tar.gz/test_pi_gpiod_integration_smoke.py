"""Recording-only smoke tests: no GPIO, native package, subprocess or network."""

import errno
import importlib
import sys
from types import SimpleNamespace as NS

import pytest

import pi_gpiod_integration_smoke as smoke


@pytest.fixture
def recorded(monkeypatch):
    owners, calls, snapshots = {}, [], []
    states = {g: {"used": False, "consumer": None, "direction": "INPUT", "bias": "DISABLED", "value": False} for g in (18, 23)}

    def claim(gpio, owner):
        if gpio in owners and owners[gpio] is not owner:
            calls.append(("busy", gpio, tuple(owners)))
            raise OSError(errno.EBUSY, "Device or resource busy")
        owners[gpio] = owner
        states[gpio].update(used=True, consumer="recording")

    class Pin:
        IN, OUT, PULL_UP, PULL_DOWN = "INPUT", "OUTPUT", "PULL_UP", "PULL_DOWN"

        def __init__(self, gpio):
            self.id, self._line_request = gpio, None

        def init(self, mode, pull=None):
            claim(self.id, self)
            self._line_request = self
            states[self.id].update(direction=mode, bias={self.PULL_UP: "PULL_UP", self.PULL_DOWN: "PULL_DOWN", None: "DISABLED"}[pull])
            if mode == self.IN:
                states[self.id]["value"] = pull == self.PULL_UP
            calls.append(("init", self.id, mode, pull))

        def value(self, value=None):
            assert owners.get(self.id) is self
            if value is not None:
                states[self.id]["value"] = value
                calls.append(("write", self.id, value))
            result = states[self.id]["value"]
            calls.append(("read", self.id, result, tuple(owners)))
            return result

        def deinit(self):
            if owners.get(self.id) is self:
                del owners[self.id]
                states[self.id].update(used=False, consumer=None)
            self._line_request = None
            calls.append(("free", self.id))

    class DigitalInOut:
        def __init__(self, pin):
            self._pin = Pin(pin.id)
            self._pin.init(Pin.IN)

        def switch_to_input(self, pull=None):
            self._pin.init(Pin.IN, pull)

        def switch_to_output(self, value=False):
            self._pin.init(Pin.OUT)
            self._pin.value(value)

        value = property(lambda self: self._pin.value())

        def deinit(self):
            self._pin.deinit()

    class NativePWM:
        pass

    class PWMOut:
        def __init__(self, pin, *, frequency, duty_cycle, variable_frequency):
            assert (pin.id, frequency, duty_cycle, variable_frequency) == (18, 50, 0, False)
            claim(18, self)
            self._pwm = NativePWM()
            self._pwm._engine = NS(_request=self)
            self.duty_cycle = duty_cycle
            states[18].update(direction="OUTPUT", value=False)

        def deinit(self):
            if owners.get(18) is self:
                del owners[18]
                states[18].update(used=False, consumer=None)
            self._pwm._engine._request = None

    def snapshot(*_args):
        result = {g: row.copy() for g, row in states.items()}
        snapshots.append(result)
        return result

    monkeypatch.setattr(smoke, "snapshot", snapshot)
    monkeypatch.setattr(smoke.time, "sleep", lambda seconds: calls.append(("sleep", seconds)))
    monkeypatch.setattr(smoke, "importlib", NS(import_module=lambda name: NS(PWMOut=NativePWM) if name == smoke.NATIVE else pytest.fail(name)))
    board = NS(D18=Pin(18), D23=Pin(23))
    dio = NS(DigitalInOut=DigitalInOut, Pull=NS(UP=Pin.PULL_UP, DOWN=Pin.PULL_DOWN))
    report, owned = {"events": [], "cleanup_errors": []}, []
    smoke.exercise(board, dio, NS(PWMOut=PWMOut), None, {}, report, owned)
    return NS(board=board, calls=calls, snapshots=snapshots, report=report, owners=owners, owned=owned)


def test_public_pin_sequences_and_bias(recorded):
    rows = recorded.report["events"]
    labels = [row["operation"] for row in rows]
    assert labels.index("GPIO18:input_up") < labels.index("GPIO23:input_up")
    for gpio in (18, 23):
        assert [row["result"] for row in rows if row["operation"].startswith(f"GPIO{gpio}:input_")] == [True, False, False]
        assert [row["result"] for row in rows if row["operation"].startswith(f"GPIO{gpio}:output_")] == [False, True, False]
        assert labels.count(f"GPIO{gpio}:pin_reclaim") == 2
        assert any(row[gpio]["used"] and row[gpio]["bias"] == "DISABLED" and row[gpio]["direction"] == "INPUT" for row in recorded.snapshots)
        assert getattr(recorded.board, f"D{gpio}")._line_request is None
    assert not recorded.owners and not recorded.report["cleanup_errors"]
    assert all(call[1] == 0.08 for call in recorded.calls if call[0] == "sleep")


def test_simultaneous_inputs_keep_peer_alive_after_first_release(recorded):
    joint = next(i for i, rows in enumerate(recorded.snapshots) if all(row["used"] and row["direction"] == "INPUT" and row["bias"] == "PULL_DOWN" and row["value"] is False for row in rows.values()))
    assert any(not rows[18]["used"] and rows[23]["used"] and rows[23]["value"] is False for rows in recorded.snapshots[joint + 1:])
    assert ("read", 23, False, (23,)) in recorded.calls
    assert not recorded.owners


def test_zero_pwm_busy_then_public_reclaim(recorded):
    assert recorded.report["busy_errno"] == errno.EBUSY
    assert ("busy", 18, (18,)) in recorded.calls
    rows = {row["operation"]: row for row in recorded.report["events"]}
    assert rows["GPIO18:pwm_zero"]["result"] is True
    assert rows["GPIO18:reclaim_after_pwm"]["result"] is False
    assert any(kind == "digitalio" and obj._pin._line_request is None for kind, obj in recorded.owned)


@pytest.mark.parametrize("attempt", ["module", "chip", "failure"])
def test_import_request_hooks_restored_on_forbidden_claim_or_failure(monkeypatch, attempt):
    class Chip:
        def request_lines(self, **_kwargs):
            pytest.fail("Original Chip request hook called")

    lib = NS(Chip=Chip, request_lines=lambda **_kwargs: pytest.fail("Original module hook called"))
    original = lib.request_lines, Chip.request_lines

    def importing(name):
        assert name == "board"
        if attempt == "failure":
            raise ImportError("recorded import failure")
        request = lib.request_lines if attempt == "module" else Chip().request_lines
        request(config={18: "recording"})

    monkeypatch.setattr(smoke, "importlib", NS(import_module=importing))
    report = {}
    with pytest.raises((RuntimeError, ImportError), match="forbidden|recorded import failure"):
        smoke.imports(lib, {}, report)
    assert (lib.request_lines, Chip.request_lines) == original
    assert report["import_request_hooks_restored"] is True


@pytest.mark.parametrize("present", [False, True])
def test_dependency_spec_probe_is_genuine_but_import_execution_is_refused(
    monkeypatch, tmp_path, present
):
    module = tmp_path / "_rpi_ws281x.py"
    if present:
        module.write_text("raise AssertionError('Foreign test fixture executed')\n")
    monkeypatch.setattr(sys, "path", [str(tmp_path)])
    monkeypatch.delitem(sys.modules, "_rpi_ws281x", raising=False)
    class Chip:
        def request_lines(self, **_kwargs):
            pytest.fail("No line request expected")
    lib = NS(Chip=Chip, request_lines=lambda **_kwargs: pytest.fail("No GPIO request"))
    original = lib.request_lines, Chip.request_lines
    previous_finders = list(sys.meta_path)
    def importing(name):
        assert name == "board"
        spec = importlib.util.find_spec("_rpi_ws281x")
        assert (spec is not None) is present
        if present:
            assert spec.origin == str(module)
            for operation in (spec.loader.create_module, spec.loader.exec_module):
                with pytest.raises(RuntimeError, match="Foreign GPIO/PIO"):
                    operation(spec)
            with pytest.raises(RuntimeError, match="Foreign GPIO/PIO"):
                importlib.import_module("_rpi_ws281x")
        else:
            with pytest.raises(ModuleNotFoundError):
                importlib.import_module("_rpi_ws281x")
        raise ImportError("probe finished without importing foreign dependency")
    monkeypatch.setattr(smoke, "importlib", NS(import_module=importing))
    report = {}
    with pytest.raises(ImportError, match="probe finished"):
        smoke.imports(lib, {}, report)
    assert "_rpi_ws281x" not in sys.modules
    assert sys.meta_path == previous_finders
    assert (lib.request_lines, Chip.request_lines) == original
    assert report["import_request_hooks_restored"] is True


@pytest.mark.parametrize("kind", ["pin", "digitalio", "pwm"])
def test_cleanup_never_claims_or_writes_unowned_partial_objects(kind):
    calls = []

    class Partial:
        _line_request = None

        def deinit(self):
            calls.append("deinit")

        def init(self, **_kwargs):
            pytest.fail("Unowned object claimed a line")

        def switch_to_output(self, **_kwargs):
            pytest.fail("Partial digital object wrote LOW")

        duty_cycle = property(lambda self: 0, lambda self, value: pytest.fail("Unowned PWM wrote duty"))

    report = {"events": [], "cleanup_errors": []}
    smoke.cleanup(kind, Partial(), report)
    assert calls == ["deinit"]
    assert not report["cleanup_errors"]
    assert [row["operation"] for row in report["events"]] == [kind + ":owned_low", kind + ":public_deinit"]


def test_cleanup_retains_low_and_deinit_errors():
    def fail(message):
        raise OSError(message)

    obj = NS(_line_request=object(), OUT="OUTPUT", init=lambda **_kwargs: fail("LOW failed"), deinit=lambda: fail("release failed"))
    report = {"events": [], "cleanup_errors": []}
    smoke.cleanup("pin", obj, report)
    assert report["cleanup_errors"] == ["OSError: LOW failed", "OSError: release failed"]
    assert all(row["status"] == "error" and row["end_ns"] >= row["begin_ns"] for row in report["events"])


@pytest.mark.parametrize("configuration,level,accepted", [("ip pd", "lo", True), ("op -- pn", "lo", True), ("op dl pn", "lo", True), ("op dh pn", "lo", False), ("op -- pn", "hi", False)])
def test_free_low_matches_only_recorded_low_modes(configuration, level, accepted):
    rows = {g: {"used": False, "consumer": None, "pinctrl": f"{g}: {configuration} | {level} // GPIO{g} = {'input' if configuration.startswith('ip') else 'output'}\n"} for g in (18, 23)}
    assert smoke.free_low(rows) is accepted
