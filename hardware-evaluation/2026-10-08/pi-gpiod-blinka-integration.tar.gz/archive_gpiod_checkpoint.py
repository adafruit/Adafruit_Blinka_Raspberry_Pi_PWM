"""Save and byte-verify this finite integration checkpoint, never replay GPIO."""

import hashlib
import json
import tarfile
from pathlib import Path

LAB = Path(__file__).resolve().parent
DESTINATION = (
    LAB.parent / "Adafruit_Blinka_Raspberry_Pi_PWM/hardware-evaluation/2026-10-08"
)
DIRECTORIES = [
    f"oct8-pi{pi}-gpiod-integration-r{revision}" for pi in (4, 5) for revision in (1, 2)
]
FILES = [
    "pi_gpiod_integration_smoke.py",
    "test_pi_gpiod_integration_smoke.py",
    "prepare_gpiod_overlay.py",
    "capture_gpiod_smoke.py",
    "analyze_gpiod_smoke.py",
    "archive_gpiod_checkpoint.py",
    "oct8-gpiod-integration-tests.log",
    "oct8-gpiod-integration-test-lint.log",
    "oct8-gpiod-integration-sphinx.log",
    "oct8-gpiod-integration-build-r2.log",
    "oct8-gpiod-integration-wheel/adafruit_blinka-9.0.5.dev76-py3-none-any.whl",
    "oct8-gpiod-integration-wheel/adafruit_blinka-9.0.5.dev77-py3-none-any.whl",
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    paths = [LAB / name for name in FILES]
    for name in DIRECTORIES:
        paths.extend(p for p in (LAB / name).rglob("*") if p.is_file())
    for path in paths:
        if (
            not path.is_file()
            or path.is_symlink()
            or path.resolve() != path
            or not path.is_relative_to(LAB)
        ):
            raise ValueError("Canonical regular evidence required: " + str(path))
    expected = {str(p.relative_to(LAB)): sha(p) for p in paths}
    if len(expected) != len(paths):
        raise ValueError("Duplicate evidence path")
    archive = DESTINATION / "pi-gpiod-blinka-integration.tar.gz"
    if not DESTINATION.is_dir() or archive.exists():
        raise ValueError("Existing dated destination and fresh archive required")
    with tarfile.open(archive, "x:gz") as stream:
        for path in sorted(paths):
            stream.add(path, arcname=str(path.relative_to(LAB)), recursive=False)
    with tarfile.open(archive, "r:gz") as stream:
        members = stream.getmembers()
        if len(members) != len(expected) or any(not m.isfile() for m in members):
            raise ValueError("Unexpected archive members")
        for member in members:
            content = stream.extractfile(member).read()
            if hashlib.sha256(content).hexdigest() != expected[member.name]:
                raise ValueError("Archive differs from source: " + member.name)
    receipt = {
        "archive": archive.name,
        "sha256": sha(archive),
        "size_bytes": archive.stat().st_size,
        "regular_files": len(expected),
        "member_sha256": expected,
        "byte_comparison_passed": True,
        "extraction_or_live_replay_performed": False,
    }
    with (DESTINATION / "gpiod-integration-archive-verification.json").open(
        "x"
    ) as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps({k: v for k, v in receipt.items() if k != "member_sha256"}, indent=2)
    )


if __name__ == "__main__":
    main()
