"""Record one finite installed-wheel GPIO smoke, keeping all raw edges."""

import argparse
import hashlib
import json
import shlex
import subprocess
import time
from pathlib import Path

from saleae import automation

PROFILES = {
    "pi4": ("pi@test2-pi4.local", "/tmp/blinka-pwm-pi4-real-pin.2y4fi6z0", [2, 3]),
    "pi5": ("pi@test-pi5.local", "/tmp/blinka-pwm-installed-consumers.QmHr57", [0, 1]),
}
DEVICE = "81F8C2631DF5BF30"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("board", choices=PROFILES)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    host, root, channels = PROFILES[args.board]
    directory = args.directory.resolve()
    if directory.parent != Path(__file__).resolve().parent or not directory.is_dir():
        raise ValueError("Existing local lab evidence directory required")
    manifest = json.loads((directory / "manifest.json").read_text())
    if (
        manifest["remote_root"] != root
        or manifest["overlay_site"] != root + "/integration-gpiod-r2/site"
    ):
        raise ValueError("Bench manifest mismatch")
    remote_dir = root + "/integration-gpiod-r2"
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        host,
        shlex.join(
            [
                root + "/venv/bin/python",
                "-I",
                remote_dir + "/pi_gpiod_integration_smoke.py",
                "--root",
                root,
                "--site",
                manifest["overlay_site"],
                "--manifest",
                remote_dir + "/manifest.json",
            ]
        ),
    ]
    receipt = {
        "board": args.board,
        "command": command,
        "sample_rate_hz": 10_000_000,
        "digital_channels": channels,
        "device_id": DEVICE,
        "pi_and_saleae_clocks_aligned": False,
        "filters": [],
        "parity_pass": None,
    }
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        if not any(
            d.device_id == DEVICE and not d.is_simulation for d in manager.get_devices()
        ):
            raise RuntimeError("Confirmed physical analyzer unavailable")
        receipt["logic_version"] = manager.get_app_info().app_version
        config = automation.LogicDeviceConfiguration(
            enabled_digital_channels=channels, digital_sample_rate=10_000_000
        )
        with manager.start_capture(
            device_id=DEVICE, device_configuration=config
        ) as capture:
            time.sleep(0.3)
            try:
                with (directory / "remote.stdout").open("x") as stdout, (
                    directory / "remote.stderr"
                ).open("x") as stderr:
                    result = subprocess.run(
                        command,
                        stdin=subprocess.DEVNULL,
                        stdout=stdout,
                        stderr=stderr,
                        timeout=30,
                        check=False,
                    )
                    receipt["ssh_returncode"] = result.returncode
            except BaseException as error:
                receipt["error"] = f"{type(error).__name__}: {error}"
            finally:
                time.sleep(0.2)
                capture.stop()
                capture.save_capture(str(directory / "waveform.sal"))
                capture.export_raw_data_binary(
                    str(directory), digital_channels=channels
                )
    receipt["files"] = {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in directory.iterdir()
        if p.is_file()
    }
    with (directory / "acquisition.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps(receipt, indent=2))
    if receipt.get("ssh_returncode") != 0 or "error" in receipt:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
