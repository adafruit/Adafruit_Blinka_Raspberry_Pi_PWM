"""Finite passive-probe GPIO18/23 integration smoke; lab only, no PIO/actuators.

20s alarm bounds ordinary Python execution, not stuck native/kernel calls or
SIGKILL. LOW/read/free are sampled observations, not continuous-low guarantees.
Run isolated/noninteractive with explicit root/site/manifest; --inspect claims
no lines. The manifest and exact source/wheel bytes must precede acquisition.
"""

import argparse
import errno
import hashlib
import importlib
import importlib.metadata
import json
import os
import platform
import re
import signal
import subprocess
import sys
import time
from contextlib import redirect_stdout
from importlib.machinery import PathFinder
from pathlib import Path

BASE = "adafruit_blinka.microcontroller.generic_linux."
NATIVE = "adafruit_blinka_raspberry_pi_pwm"
MODELS = {"Raspberry Pi 4 Model B Rev 1.4": ("pinctrl-bcm2711", [2, 3]),
          "Raspberry Pi 5 Model B Rev 1.0": ("pinctrl-rp1", [0, 1])}
ROOTS = {"/tmp/blinka-pwm-pi4-real-pin.2y4fi6z0", "/tmp/blinka-pwm-installed-consumers.QmHr57"}
REQUIRED = {"board.py", "digitalio.py", "pwmio.py", "pi_gpiod_integration_smoke.py",
            "adafruit_blinka/platform_dependencies.py", "gpiod/__init__.py", "gpiod/_ext.so",
            *(NATIVE + "/" + p for p in ("__init__.py", "_software.py", "_native.so")),
            *(BASE.replace(".", "/") + p for p in ("raspberry_pi_pin.py", "raspberry_pi_pwmout.py", "libgpiod_pin.py", "libgpiod/libgpiod_pin_2_x.py")),
            *("adafruit_blinka/microcontroller/" + p for p in ("bcm283x/pin.py", "bcm2711/pin.py", "bcm2712/pin.py", "bcm283x/pulseio/PulseIn.py"))}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def digest(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink() and path.resolve() == path, "Regular canonical source required")
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "Duplicate manifest key")
            result[key] = value
        return result
    return json.loads(Path(path).read_text(), object_pairs_hook=pairs, parse_constant=lambda value: need(False, "Nonfinite JSON: " + value))

def query(r, args):
    result = subprocess.run(args, capture_output=True, text=True, timeout=3, check=False)
    r.setdefault("queries", []).append({"arguments": args, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    need(result.returncode == 0, "Read-only command failed: " + str(args))
    return result.stdout

def gate(root, site, m, r):
    need(str(root) in ROOTS and root.resolve() == root and site.resolve() == site and site.is_dir() and site.is_relative_to(root), "Declared existing root/canonical private overlay required")
    need(type(m["schema_version"]) is int and m["schema_version"] == 1 and m["remote_root"] == str(root) and m["overlay_site"] == str(site), "Manifest root/site mismatch")
    need(sys.flags.isolated and sys.platform == "linux" and Path(sys.executable) == root / "venv/bin/python", "Isolated declared Linux venv required")
    need(not sys.stdin.isatty() and not sys.stdout.isatty(), "Noninteractive process required")
    need(not any(k.startswith("BLINKA_") or k in ("PYTHONPATH", "PYTHONHOME") for k in os.environ), "Inherited dispatch/path overrides forbidden")
    need(not any(n == p or n.startswith(p + ".") for n in sys.modules for p in ("board", "digitalio", "pwmio", "adafruit_blinka", "gpiod", NATIVE, "RPi", "lgpio", "rp1pio")), "Fresh process required")
    need(REQUIRED <= m["source_paths"].keys() == m["source_sha256"].keys(), "Complete source map required")
    need(all(digest(m["source_paths"][k]) == v for k, v in m["source_sha256"].items()), "Source bytes changed")
    need(m["source_paths"][Path(__file__).name] == str(Path(__file__).resolve()), "Actual helper path mismatch")
    need(digest(m["wheel"]["path"]) == m["wheel"]["sha256"], "Wheel bytes changed")
    actual = {"model": Path("/proc/device-tree/model").read_text().rstrip("\x00\n"), "kernel": platform.release(), "python_version": platform.python_version(), "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip()}
    need(actual["model"] in MODELS and all(actual[k] == m[k] for k in actual), "Platform/model/boot changed")
    need(all(digest(k) == v for k, v in m["boot_config_sha256"].items()) and len(m["boot_config_sha256"]) == 2, "Boot configuration changed")
    c = m["controller"]
    need(c["label"] == MODELS[actual["model"]][0] and c["path"] == "/dev/" + c["name"], "Controller/profile mismatch")
    device = Path(c["path"]).stat()
    need(f"{os.major(device.st_rdev)}:{os.minor(device.st_rdev)}" == c["device_number"] and str((Path("/sys/bus/gpio/devices") / c["name"] / "of_node").resolve(strict=True)) == c["of_node"], "Controller device/OF changed")
    actual["temperature_millic"] = int(Path("/sys/class/thermal/thermal_zone0/temp").read_text())
    actual["throttled"] = query(r, ["vcgencmd", "get_throttled"])
    need(actual["throttled"] == "throttled=0x0\n", "Throttle flags nonzero")
    r.update(platform=actual, source_sha256=m["source_sha256"], source_paths=m["source_paths"], wheel=m["wheel"], saleae_channels=MODELS[actual["model"]][1])
    sys.path.insert(0, str(site))
    r["distribution_versions"] = {k: importlib.metadata.version(k) for k in m["distribution_versions"]}
    need(r["distribution_versions"] == m["distribution_versions"] and r["distribution_versions"]["gpiod"] == "2.5.0", "Exact runtime versions required")


def snapshot(lib, m, r):
    rows = {}
    with lib.Chip(m["controller"]["path"]) as chip:
        info = chip.get_info()
        need((info.name, info.label, info.num_lines) == tuple(m["controller"][k] for k in ("name", "label", "num_lines")), "Actual controller metadata changed")
        for gpio in (18, 23):
            line = chip.get_line_info(gpio)
            rows[gpio] = {"used": line.used, "consumer": line.consumer, "direction": line.direction.name, "bias": line.bias.name, "pinctrl": query(r, ["pinctrl", "get", str(gpio)])}
    return rows


def free_low(rows):
    return all(not row["used"] and row["consumer"] in (None, "") and re.fullmatch(rf"{gpio}: (?:ip +(?:pd|pu|pn) \| lo // GPIO{gpio} = input|op (?:--|dl) (?:pd|pu|pn) \| lo // GPIO{gpio} = output)\n", row["pinctrl"]) for gpio, row in rows.items())


def origins(m, r):
    found = {}
    for name, module in list(sys.modules.items()):
        if name in ("board", "digitalio", "pwmio") or name.startswith(("adafruit_blinka", NATIVE, "gpiod", "adafruit_platformdetect", "packaging")):
            path = getattr(module, "__file__", None)
            if path:
                need(path in m["source_paths"].values(), "Undeclared loaded source: " + name)
                found[name] = path
    need(not any(n == p or n.startswith(p + ".") for n in sys.modules for p in ("RPi", "lgpio", "rp1pio", "_rpi_ws281x", "adafruit_raspberry_pi5_neopixel_write")), "Foreign GPIO/PIO import occurred")
    r["module_origins"] = found


def imports(lib, m, r):
    previous = lib.request_lines, lib.Chip.request_lines
    class NoForeignGPIO:
        def create_module(self, _spec):
            raise RuntimeError("Foreign GPIO/PIO import forbidden")
        exec_module = create_module
        def find_spec(self, name, _path=None, _target=None):
            spec = PathFinder.find_spec(name, _path) if any(name == p or name.startswith(p + ".") for p in ("RPi", "lgpio", "rp1pio", "_rpi_ws281x", "adafruit_raspberry_pi5_neopixel_write")) else None
            if spec is not None:
                spec.loader = self
            return spec
    finder = NoForeignGPIO()
    sys.meta_path.insert(0, finder)
    def deny(*_args, **_kwargs):
        raise RuntimeError("Import-phase GPIO request forbidden")
    lib.request_lines = lib.Chip.request_lines = deny
    try:
        with redirect_stdout(sys.stderr):
            board, dio, pwm = (importlib.import_module(n) for n in ("board", "digitalio", "pwmio"))
        pin = importlib.import_module(BASE + "raspberry_pi_pin").Pin
        adapter = importlib.import_module(BASE + "raspberry_pi_pwmout").PWMOut
        need(dio.Pin is pin and pwm.PWMOut is adapter, "Actual Pin/PWM adapter identities required")
        need(all(type(getattr(board, "D" + str(g))) is pin and type(getattr(board, "D" + str(g)).id) is int and getattr(board, "D" + str(g)).id == g and getattr(board, "D" + str(g))._line_request is None for g in (18, 23)), "Integer genuine lazy Pin identities required")
        need(board.SDA == board.D2 and board.SCL == board.D3 and board.SCK == board.D11, "Board aliases differ")
        origins(m, r)
        return board, dio, pwm
    finally:
        sys.meta_path.remove(finder)
        lib.request_lines, lib.Chip.request_lines = previous
        r["import_request_hooks_restored"] = (lib.request_lines, lib.Chip.request_lines) == previous


def event(r, label, operation):
    row = {"operation": label, "begin_ns": time.monotonic_ns()}
    r["events"].append(row)
    try:
        result = operation()
        row.update(status="ok", result=result)
        return result
    except BaseException as error:
        row.update(status="error", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        row["end_ns"] = time.monotonic_ns()


def hold(r, label, change, read, expected):
    def phase():
        change()
        time.sleep(0.08)
        value = read()
        need(expected is None or value is expected, "Unexpected public readback: " + label)
        return value
    return event(r, label, phase)


def cleanup(kind, obj, r):
    def low():
        pin = getattr(obj, "_pin", None) if kind == "digitalio" else obj
        if kind == "pwm":
            native = getattr(obj, "_pwm", None)
            if getattr(getattr(native, "_engine", None), "_request", None) is not None:
                obj.duty_cycle = 0
        elif getattr(pin, "_line_request", None) is not None:
            if kind == "digitalio":
                obj.switch_to_output(value=False)
            else:
                obj.init(mode=obj.OUT)
                obj.value(False)
    for name, operation in (("owned_low", low), ("public_deinit", obj.deinit)):
        try:
            event(r, kind + ":" + name, operation)
        except BaseException as error:  # noqa: BLE001 - preserve cleanup/cancellation failures
            r["cleanup_errors"].append(f"{type(error).__name__}: {error}")


def exercise(board, dio, pwm, lib, m, r, owned):
    def new(kind, cls, *args, **kwargs):
        obj = cls.__new__(cls)
        owned.append((kind, obj))
        event(r, kind + ":constructor", lambda: obj.__init__(*args, **kwargs))
        return obj
    for gpio in (18, 23):
        peer = 23 if gpio == 18 else 18
        baseline = snapshot(lib, m, r)[peer]
        pin = getattr(board, "D" + str(gpio))
        obj = new("digitalio", dio.DigitalInOut, pin)
        for name, pull, expected in (("up", dio.Pull.UP, True), ("down", dio.Pull.DOWN, False), ("none", None, None)):
            hold(r, f"GPIO{gpio}:input_{name}", lambda p=pull, o=obj: o.switch_to_input(pull=p), lambda o=obj: o.value, expected)
            state = snapshot(lib, m, r)
            r.setdefault("active_line_snapshots", []).append({"phase": f"GPIO{gpio}:input_{name}", "lines": state})
            need(state[gpio]["used"] and state[gpio]["direction"] == "INPUT" and state[gpio]["bias"] == {"up": "PULL_UP", "down": "PULL_DOWN", "none": "DISABLED"}[name], "Active input direction/bias mismatch")
            need(state[peer] == baseline, "Inactive peer changed")
            if pull is None:
                need(state[gpio]["bias"] == "DISABLED", "Pull=None must disable bias")
        for name, value in (("low", False), ("high", True), ("low", False)):
            hold(r, f"GPIO{gpio}:output_{name}", lambda v=value, o=obj: o.switch_to_output(value=v), lambda o=obj: o.value, value)
            need(snapshot(lib, m, r)[peer] == baseline, "Inactive peer changed")
        cleanup("digitalio", obj, r)
        clone = new("pin", type(pin), gpio)
        for _attempt in range(2):
            hold(r, f"GPIO{gpio}:pin_reclaim", lambda c=clone: c.init(mode=c.IN, pull=c.PULL_DOWN), lambda c=clone: c.value(), False)
            cleanup("pin", clone, r)
        need(pin._line_request is None and snapshot(lib, m, r)[peer] == baseline, "Board alias/peer must remain unclaimed")
    baseline = snapshot(lib, m, r)[23]
    output = new("pwm", pwm.PWMOut, board.D18, frequency=50, duty_cycle=0, variable_frequency=False)
    need(type(output._pwm) is importlib.import_module(NATIVE).PWMOut and output.duty_cycle == 0, "Actual zero-duty native instance required")
    hold(r, "GPIO18:pwm_zero", lambda: None, lambda: output.duty_cycle == 0, True)
    try:
        new("digitalio", dio.DigitalInOut, board.D18)
    except OSError as error:
        need(error.errno == errno.EBUSY, "Expected exact EBUSY ownership conflict")
        r["busy_errno"] = error.errno
        r["events"][-1]["expected_busy_conflict"] = True
    else:
        raise RuntimeError("Owned PWM line was incorrectly reclaimed")
    cleanup("pwm", output, r)
    obj = new("digitalio", dio.DigitalInOut, board.D18)
    hold(r, "GPIO18:reclaim_after_pwm", lambda: obj.switch_to_input(pull=dio.Pull.DOWN), lambda: obj.value, False)
    cleanup("digitalio", obj, r)
    need(snapshot(lib, m, r)[23] == baseline, "GPIO23 changed during PWM handoff")
    both = [new("digitalio", dio.DigitalInOut, getattr(board, "D" + str(g))) for g in (18, 23)]
    for obj in both:
        obj.switch_to_input(pull=dio.Pull.DOWN)
    hold(r, "both:input_down", lambda: None, lambda: all(o.value is False for o in both), True)
    r["both_owned_input_down"] = snapshot(lib, m, r)
    need(all(row["used"] and row["direction"] == "INPUT" and row["bias"] == "PULL_DOWN" for row in r["both_owned_input_down"].values()), "Both lines must be independently owned inputs")
    cleanup("digitalio", both[0], r)
    r["after_deinit18_with23_owned"] = snapshot(lib, m, r)
    need(not r["after_deinit18_with23_owned"][18]["used"] and r["after_deinit18_with23_owned"][23]["used"] and both[1].value is False, "Deinit18 invalidated independently owned GPIO23")
    cleanup("digitalio", both[1], r)


def run(root, site, manifest_path, inspect_only=False):
    r = {"pid": os.getpid(), "begin_ns": time.monotonic_ns(), "events": [], "cleanup_errors": [], "success": False, "inspect_only": inspect_only, "parity_pass": None, "electrical_and_pi_clocks_aligned": False}
    owned, lib, m, armed = [], None, None, False
    previous = {s: signal.getsignal(s) for s in (signal.SIGALRM, signal.SIGTERM)}
    def interrupted(_signum, _frame):
        raise TimeoutError("Bounded smoke interrupted")
    try:
        need(signal.getitimer(signal.ITIMER_REAL) == (0.0, 0.0), "Inherited alarm forbidden")
        armed = True
        for sig in previous:
            signal.signal(sig, interrupted)
        signal.setitimer(signal.ITIMER_REAL, 20)
        m = read_manifest(manifest_path)
        r["manifest_sha256"] = digest(manifest_path)
        gate(root, site, m, r)
        lib = importlib.import_module("gpiod")
        r["initial_lines"] = snapshot(lib, m, r)
        need(free_low(r["initial_lines"]), "Both lines must start free LOW")
        board, dio, pwm = imports(lib, m, r)
        need(free_low(snapshot(lib, m, r)), "Imports changed free LOW lines")
        if not inspect_only:
            exercise(board, dio, pwm, lib, m, r, owned)
        origins(m, r)
    except BaseException as error:  # noqa: BLE001 - return actual failure and clean owned objects
        r["primary_error"] = f"{type(error).__name__}: {error}"
    finally:
        for kind, obj in reversed(owned):
            cleanup(kind, obj, r)
        if lib is not None:
            try:
                r["final_lines"] = snapshot(lib, m, r)
                need(free_low(r["final_lines"]), "Final lines not free LOW")
            except BaseException as error:  # noqa: BLE001 - retain final read/cancellation failure
                r["cleanup_errors"].append(f"{type(error).__name__}: {error}")
        if armed:
            signal.setitimer(signal.ITIMER_REAL, 0)
            for sig, handler in previous.items():
                signal.signal(sig, handler)
        r["end_ns"] = time.monotonic_ns()
        r["success"] = "primary_error" not in r and not r["cleanup_errors"]
    return r


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "site", "manifest"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--inspect", action="store_true")
    args = parser.parse_args()
    result = run(args.root, args.site, args.manifest, args.inspect)
    print(json.dumps(result, indent=2, allow_nan=False))
    sys.exit(0 if result["success"] else 1)
