"""Install one frozen Blinka wheel in a fresh private bench overlay; no claims."""

import hashlib
import importlib.metadata as metadata
import json
import os
import platform
import re
import subprocess
import sys
import zipfile
from pathlib import Path

ROOTS = {
    "test2-pi4": ("/tmp/blinka-pwm-pi4-real-pin.2y4fi6z0", "pinctrl-bcm2711"),
    "test-pi5": ("/tmp/blinka-pwm-installed-consumers.QmHr57", "pinctrl-rp1"),
}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    path = Path(path)
    need(path.is_file() and not path.is_symlink() and path.resolve() == path, str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    root_name, label = ROOTS[platform.node()]
    root, directory = Path(root_name), Path(__file__).parent
    need(
        root.resolve() == root
        and root.stat().st_uid == os.getuid() == 1000
        and root.stat().st_mode & 0o777 == 0o700,
        "Existing private root required",
    )
    need(
        directory == root / "integration-gpiod-r1" and directory.resolve() == directory,
        "Exact fresh integration directory required",
    )
    need(
        sys.flags.isolated and sys.executable == str(root / "venv/bin/python"),
        "Private isolated Python required",
    )
    need(
        not any(
            k.startswith("BLINKA_") or k in ("PYTHONPATH", "PYTHONHOME")
            for k in os.environ
        ),
        "Dispatch overrides forbidden",
    )
    wheel, helper = (
        next(directory.glob("*.whl")),
        directory / "pi_gpiod_integration_smoke.py",
    )
    need(
        len(list(directory.glob("*.whl"))) == 1
        and sha(wheel) == sys.argv[1]
        and sha(helper) == sys.argv[2],
        "Frozen inputs differ",
    )
    site = directory / "site"
    need(
        not site.exists() and not (directory / "manifest.json").exists(),
        "Never replace previous installation/evidence",
    )
    with zipfile.ZipFile(wheel) as archive:
        entries = archive.namelist()
        need(len(entries) == len(set(entries)), "Duplicate wheel members")
        need(
            all(
                not Path(p).is_absolute()
                and ".." not in Path(p).parts
                and not p.endswith(".pth")
                and Path(p).name not in ("sitecustomize.py", "usercustomize.py")
                for p in entries
            ),
            "Unsafe wheel contents",
        )
    install = subprocess.run(
        [
            sys.executable,
            "-I",
            "-m",
            "pip",
            "install",
            "--no-index",
            "--no-deps",
            "--target",
            str(site),
            str(wheel),
        ],
        capture_output=True,
        text=True,
        timeout=60,
        check=False,
        env={
            **os.environ,
            "PIP_CONFIG_FILE": "/dev/null",
            "PIP_DISABLE_PIP_VERSION_CHECK": "1",
        },
    )
    receipt = {
        "returncode": install.returncode,
        "stdout": install.stdout,
        "stderr": install.stderr,
    }
    with (directory / "install.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
    need(install.returncode == 0, "Offline wheel install failed")
    with zipfile.ZipFile(wheel) as archive:
        for entry in archive.namelist():
            if entry.endswith(".py") and not ".dist-info/" in entry:
                need(
                    (site / entry).read_bytes() == archive.read(entry),
                    "Installed source differs from wheel: " + entry,
                )
    sys.path.insert(0, str(site))
    source_paths = {}
    # Overlay takes precedence; dependencies remain in the existing private venv.
    for source_root in (site, root / "venv/lib/python3.13/site-packages"):
        for path in sorted(source_root.rglob("*")):
            if path.suffix in (".py", ".so"):
                key = str(path.relative_to(source_root))
                if key not in source_paths:
                    sha(path)
                    source_paths[key] = str(path)
    source_paths[helper.name] = str(helper)
    for alias, pattern in (
        ("gpiod/_ext.so", "gpiod/_ext*.so"),
        (
            "adafruit_blinka_raspberry_pi_pwm/_native.so",
            "adafruit_blinka_raspberry_pi_pwm/_native*.so",
        ),
    ):
        matches = list((root / "venv/lib/python3.13/site-packages").glob(pattern))
        need(len(matches) == 1, "Unique existing native extension required")
        source_paths[alias] = str(matches[0])
    import gpiod  # Metadata only, never request a line.

    controllers = []
    for path in sorted(Path("/dev").glob("gpiochip*")):
        if not re.fullmatch(r"gpiochip[0-9]+", path.name):
            continue
        with gpiod.Chip(str(path)) as chip:
            info = chip.get_info()
            if info.label == label:
                controllers.append(
                    {
                        "path": str(path),
                        "name": info.name,
                        "label": info.label,
                        "num_lines": info.num_lines,
                        "device_number": f"{os.major(path.stat().st_rdev)}:{os.minor(path.stat().st_rdev)}",
                        "of_node": str(
                            (
                                Path("/sys/bus/gpio/devices") / info.name / "of_node"
                            ).resolve(strict=True)
                        ),
                    }
                )
                need(
                    all(not chip.get_line_info(gpio).used for gpio in (18, 23)),
                    "Test lines are already owned",
                )
    need(len(controllers) == 1, "Exactly one header controller required")
    manifest = {
        "schema_version": 1,
        "remote_root": root_name,
        "overlay_site": str(site),
        "model": Path("/proc/device-tree/model").read_text().rstrip("\x00\n"),
        "kernel": platform.release(),
        "python_version": platform.python_version(),
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        "boot_config_sha256": {
            p: sha(p) for p in ("/boot/config.txt", "/boot/firmware/config.txt")
        },
        "controller": controllers[0],
        "distribution_versions": {
            name: metadata.version(name)
            for name in (
                "Adafruit-Blinka",
                "Adafruit-PlatformDetect",
                "gpiod",
                "Adafruit-Blinka-Raspberry-Pi-PWM",
            )
        },
        "source_paths": source_paths,
        "source_sha256": {k: sha(p) for k, p in source_paths.items()},
        "wheel": {"path": str(wheel), "sha256": sha(wheel)},
    }
    need(
        manifest["distribution_versions"]["gpiod"] == "2.5.0",
        "Frozen binding version required",
    )
    with (directory / "manifest.json").open("x") as stream:
        json.dump(manifest, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"install": receipt, "manifest": manifest}, indent=2))


if __name__ == "__main__":
    main()
