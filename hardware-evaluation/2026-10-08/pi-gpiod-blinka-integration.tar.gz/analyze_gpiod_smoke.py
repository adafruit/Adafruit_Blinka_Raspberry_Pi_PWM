"""Offline GPIO smoke facts only: all edges/runs, no PWM/parity/actuator claim."""
import argparse
import hashlib
import json
import math
import struct
from pathlib import Path


def need(ok, message):
    if not ok:
        raise ValueError(message)


def raw(path):
    need(path.is_file() and not path.is_symlink() and path.resolve() == path, "Canonical regular file required")
    return path.read_bytes()


def load(path):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "Duplicate JSON key")
            result[key] = value
        return result
    return json.loads(raw(path), object_pairs_hook=pairs, parse_constant=lambda value: need(False, "Nonfinite JSON: " + value))


def decode(data):
    need(len(data) >= 16, "Truncated global header")
    signature, version, kind = struct.unpack_from("<8sii", data)
    need(signature == b"<SALEAE>" and version in (0, 1) and kind == 0, "Unsupported Saleae header")
    cursor, count = 16, 1
    if version == 1:
        need(len(data) >= 24, "Truncated v1 chunk count")
        count, cursor = struct.unpack_from("<Q", data, 16)[0], 24
    need(0 < count <= (len(data) - cursor) // (36 if version else 28), "Invalid chunk count/length")
    chunks = []
    for _index in range(count):
        size = 36 if version else 28
        need(len(data) - cursor >= size, "Truncated chunk header")
        initial = struct.unpack_from("<I", data, cursor)[0]
        rate = struct.unpack_from("<d", data, cursor + 4)[0] if version else None
        begin, end, n = struct.unpack_from("<ddQ", data, cursor + (12 if version else 4))
        cursor += size
        need(initial in (0, 1) and math.isfinite(begin) and math.isfinite(end) and begin <= end and (not chunks or begin >= chunks[-1]["end_s"]) and (rate is None or rate == 10000000), "Invalid chunk state/extent/order/rate")
        need(n <= (len(data) - cursor) // 8, "Truncated edge array")
        edges = list(struct.unpack_from(f"<{n}d", data, cursor)); cursor += n * 8
        need(all(math.isfinite(t) and begin <= t <= end for t in edges) and all(edges[i - 1] < edges[i] for i in range(1, len(edges))), "Invalid edge extent/order")
        points = [begin, *edges, end]
        runs = [{"level": initial ^ (i & 1), "begin_s": points[i], "end_s": points[i + 1], "duration_us": (points[i + 1] - points[i]) * 1e6, "left_censored": i == 0, "right_censored": i == n} for i in range(n + 1)]
        final = initial ^ (n & 1)
        chunks.append({"initial_level": initial, "final_level": final, "begin_s": begin, "end_s": end, "sample_rate_hz_in_export": rate, "edge_count": n, "edges_s": edges, "all_runs": runs, "all_high_runs": [r for r in runs if r["level"]], "quiet_lead_s": points[1] - begin if initial == 0 else 0.0, "quiet_tail_s": end - points[-2] if final == 0 else 0.0})
    need(cursor == len(data), "Trailing/unparsed binary bytes")
    return {"binary_version": version, "chunks": chunks}


def analyze(directory, profile):
    directory = directory.absolute()
    receipt, acq, manifest = (load(directory / name) for name in ("remote.stdout", "acquisition.json", "manifest.json"))
    channels = {"pi4": [2, 3], "pi5": [0, 1]}[profile]
    need(receipt["success"] is True and receipt["cleanup_errors"] == [] and "primary_error" not in receipt and receipt["inspect_only"] is False and receipt["import_request_hooks_restored"] is True, "Actual helper failed/incomplete")
    need(acq["board"] == profile and type(acq["ssh_returncode"]) is int and acq["ssh_returncode"] == 0 and "error" not in acq and acq["sample_rate_hz"] == 10000000 and acq["digital_channels"] == channels and acq["filters"] == [] and acq["device_id"] == "81F8C2631DF5BF30" and acq["pi_and_saleae_clocks_aligned"] is False and acq["parity_pass"] is None, "Actual acquisition contract mismatch")
    need({"remote.stdout", "remote.stderr", "manifest.json", "waveform.sal", *(f"digital_{ch}.bin" for ch in channels)} <= acq["files"].keys(), "Missing recorded file provenance")
    hashes = {}
    for name, expected in acq["files"].items():
        need(Path(name).name == name, "Unsafe recorded filename")
        hashes[name] = hashlib.sha256(raw(directory / name)).hexdigest()
        need(hashes[name] == expected, "Changed acquisition bytes: " + name)
    need(receipt["manifest_sha256"] == hashlib.sha256(raw(directory / "manifest.json")).hexdigest() and receipt["source_sha256"] == manifest["source_sha256"] and receipt["source_paths"] == manifest["source_paths"] and receipt["distribution_versions"] == manifest["distribution_versions"] and hashlib.sha256(raw(Path(__file__).absolute().parent / "pi_gpiod_integration_smoke.py")).hexdigest() == receipt["source_sha256"]["pi_gpiod_integration_smoke.py"], "Manifest/source/version receipt mismatch")
    events = receipt["events"]
    need(all(e["status"] == "ok" or e.get("expected_busy_conflict") is True for e in events) and type(receipt["busy_errno"]) is int and receipt["busy_errno"] == 16 and len([e for e in events if e.get("expected_busy_conflict") is True and e["status"] == "error"]) == 1 and any(e["operation"] == "GPIO18:pwm_zero" and e["result"] is True for e in events) and any(e["operation"] == "GPIO18:reclaim_after_pwm" and e["result"] is False for e in events), "Unexpected event/ownership error")
    for gpio in (18, 23):
        rows = [e for e in events if e["operation"].startswith(f"GPIO{gpio}:")]
        inputs = [e for e in rows if e["operation"].startswith(f"GPIO{gpio}:input_")]
        need([e["operation"] for e in inputs] == [f"GPIO{gpio}:input_{name}" for name in ("up", "down", "none")] and all(type(e["result"]) is bool for e in inputs) and inputs[0]["result"] is True and inputs[1]["result"] is False, "Input phase readbacks differ")
        need(all(type(e["result"]) is bool for e in rows) and [e["result"] for e in rows if e["operation"].startswith(f"GPIO{gpio}:output_")] == [False, True, False] and [e["result"] for e in rows if e["operation"] == f"GPIO{gpio}:pin_reclaim"] == [False, False], "Output/reclaim phase readbacks differ")
    need(len(receipt["active_line_snapshots"]) == 6, "Incomplete pull snapshots")
    for row in receipt["active_line_snapshots"]:
        gpio = row["phase"].split(":")[0][4:]; line = row["lines"][gpio]
        need(line["used"] is True and line["direction"] == "INPUT" and line["bias"] == {"up": "PULL_UP", "down": "PULL_DOWN", "none": "DISABLED"}[row["phase"].split("_")[-1]] and row["lines"]["23" if gpio == "18" else "18"]["used"] is False, "Active pull/peer facts differ")
    joint, after = receipt["both_owned_input_down"], receipt["after_deinit18_with23_owned"]
    need(set(joint) == {"18", "23"} and all(r["used"] is True and r["direction"] == "INPUT" and r["bias"] == "PULL_DOWN" for r in joint.values()) and after["18"]["used"] is False and after["23"]["used"] is True and any(e["operation"] == "both:input_down" and e["result"] is True for e in events), "Independent dual ownership/release proof missing")
    decoded = {str(ch): decode(raw(directory / f"digital_{ch}.bin")) for ch in channels}
    boundary_low = all(c["initial_level"] == c["final_level"] == 0 for data in decoded.values() for c in data["chunks"])
    return {"capture": directory.name, "profile": profile, "analyzer_sha256": hashlib.sha256(raw(Path(__file__).absolute())).hexdigest(), "acquisition_sha256": hashlib.sha256(raw(directory / "acquisition.json")).hexdigest(), "helper_pid": receipt["pid"], "actual_ssh_returncode": acq["ssh_returncode"], "file_sha256": hashes, "events": events, "active_line_snapshots": receipt["active_line_snapshots"], "both_owned_input_down": joint, "after_deinit18_with23_owned": after, "initial_lines": receipt["initial_lines"], "final_lines": receipt["final_lines"], "raw_channels": decoded, "all_capture_boundaries_low": boundary_low, "parity_pass": None, "pi_and_saleae_clocks_aligned": False, "scope": "Physical GPIO functional observation only; every edge/run including shorts and censored boundaries retained, no filtering, phase-clock alignment, PWM timing verdict, parity, actuator or general compatibility claim."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("profile", choices=("pi4", "pi5")); parser.add_argument("directory", type=Path)
    args = parser.parse_args(); result = analyze(args.directory, args.profile)
    with (args.directory / "smoke-analysis.json").open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False); stream.write("\n")
    print(json.dumps({"capture": result["capture"], "all_capture_boundaries_low": result["all_capture_boundaries_low"], "high_run_counts": {ch: sum(len(c["all_high_runs"]) for c in data["chunks"]) for ch, data in result["raw_channels"].items()}, "parity_pass": None}))
