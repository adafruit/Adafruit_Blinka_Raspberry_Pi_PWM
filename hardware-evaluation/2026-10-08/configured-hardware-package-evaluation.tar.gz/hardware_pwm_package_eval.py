"""Finite GPIO18 qualification through an isolated production-package PWMOut.

No overlays, pinmux, GPIO23, PIO, or provider configuration are changed here.
Public API calls and cached requests are evidence of requests, not electrical
levels. Only a separately captured waveform can establish physical behavior.
"""

import argparse
import hashlib
import importlib.util
import json
import platform
import re
import signal
import socket
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

PACKAGE = "adafruit_blinka_raspberry_pi_pwm"
SOURCE_FILES = ("__init__.py", "_hardware.py", "_software.py")
ROOT_PATTERN = r"/tmp/blinka-hardware-pwm\.[A-Za-z0-9]{6}"
HOSTS = {
    "test2-pi4.local": {
        "model": "Raspberry Pi 4 Model B",
        "node": "pwm@7e20c000",
        "channel": 0,
    },
    "test-pi5.local": {
        "model": "Raspberry Pi 5 Model B",
        "node": "pwm@98000",
        "channel": 2,
    },
}
MODES = ("ordinary", "endpoints", "frequency", "lifecycle", "margins")
MAX_SEQUENCE_SECONDS = 8
WATCHDOG_SECONDS = 14


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def validate_manifest(manifest):
    require(
        isinstance(manifest, dict) and manifest.get("schema_version") == 1,
        "Invalid source manifest",
    )
    files = manifest.get("package_files")
    require(
        isinstance(files, dict) and set(files) == set(SOURCE_FILES),
        "Manifest must name exactly three production Python files",
    )
    require(
        all(
            isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
            for value in (*files.values(), manifest.get("helper_sha256"))
        ),
        "Invalid SHA256 in source manifest",
    )
    return manifest


def load_package(source_root, manifest_sha256):
    root = Path(source_root)
    require(
        re.fullmatch(ROOT_PATTERN, str(root)) is not None,
        "Requires the private /tmp hardware bench directory",
    )
    require(
        root.resolve(strict=True) == root and not root.is_symlink(),
        "Source root must not be redirected",
    )
    manifest_path = root / "source-manifest.json"
    require(
        not manifest_path.is_symlink() and digest(manifest_path) == manifest_sha256,
        "Source manifest digest mismatch",
    )
    manifest = validate_manifest(json.loads(manifest_path.read_text()))
    require(
        Path(__file__).resolve() == root / "hardware_pwm_package_eval.py",
        "Helper is not running from the isolated deployment",
    )
    require(
        digest(__file__) == manifest["helper_sha256"], "Running helper SHA256 mismatch"
    )
    package_dir = root / "src" / PACKAGE
    require(
        package_dir.resolve(strict=True) == package_dir,
        "Package path must not be redirected",
    )
    require(
        {entry.name for entry in package_dir.iterdir()} == set(SOURCE_FILES),
        "Package must contain exactly three source files, without bytecode caches",
    )
    actual = {}
    for name in SOURCE_FILES:
        path = package_dir / name
        require(
            path.is_file() and not path.is_symlink(),
            f"Source file is redirected: {name}",
        )
        actual[name] = digest(path)
        require(
            actual[name] == manifest["package_files"][name],
            f"Production source SHA256 mismatch: {name}",
        )
    require(
        not any(
            name == PACKAGE or name.startswith(PACKAGE + ".") for name in sys.modules
        ),
        "Production package was imported before source verification",
    )
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location(
        PACKAGE,
        package_dir / "__init__.py",
        submodule_search_locations=[str(package_dir)],
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[PACKAGE] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        for name in list(sys.modules):
            if name == PACKAGE or name.startswith(PACKAGE + "."):
                del sys.modules[name]
        raise
    for name, path in (
        (PACKAGE, package_dir / "__init__.py"),
        (PACKAGE + "._hardware", package_dir / "_hardware.py"),
        (PACKAGE + "._software", package_dir / "_software.py"),
    ):
        require(
            Path(sys.modules[name].__file__).resolve() == path,
            "Imported production module origin mismatch",
        )
    return module, {
        "manifest_sha256": manifest_sha256,
        "helper_sha256": digest(__file__),
        "package_files": actual,
        "package_root": str(package_dir),
        "version": module.__version__,
    }


def optional_read(path):
    try:
        return {"value": Path(path).read_text().rstrip("\0\n"), "error": None}
    except OSError as error:
        return {"value": None, "error": f"{type(error).__name__}: {error}"}


def system_snapshot():
    try:
        flags = subprocess.run(
            ["vcgencmd", "get_throttled"],
            capture_output=True,
            text=True,
            timeout=2,
            check=True,
        ).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        flags = None
    return {
        "temperature_millic": optional_read("/sys/class/thermal/thermal_zone0/temp")[
            "value"
        ],
        "throttled": flags,
        "model": optional_read("/proc/device-tree/model")["value"],
        "kernel": platform.release(),
        "boot_id": optional_read("/proc/sys/kernel/random/boot_id")["value"],
    }


def thermal_issues(snapshot):
    issues = []
    try:
        require(
            0 <= int(snapshot["temperature_millic"]) <= 70000,
            "Temperature exceeds the 70 C bench limit",
        )
    except (KeyError, TypeError, ValueError, RuntimeError) as error:
        issues.append(str(error))
    try:
        flags = snapshot["throttled"]
        require(
            flags.startswith("throttled=0x") and int(flags.split("=", 1)[1], 16) == 0,
            "Firmware limiting flags are not clear",
        )
    except (KeyError, TypeError, ValueError, AttributeError, RuntimeError) as error:
        issues.append(str(error))
    return issues


def provider_snapshot():
    """Read all provider/fan caches; never export, configure, or unbind them."""
    providers = []
    for chip in sorted(Path("/sys/class/pwm").glob("pwmchip*")):
        exports = [
            {
                "path": str(channel),
                "cache": {
                    name: optional_read(channel / name)
                    for name in ("period", "duty_cycle", "polarity", "enable")
                },
            }
            for channel in sorted(chip.glob("pwm[0-9]*"))
        ]
        providers.append(
            {
                "chip": str(chip),
                "of_node": str((chip / "device/of_node").resolve()),
                "driver": str((chip / "device/driver").resolve()),
                "npwm": optional_read(chip / "npwm"),
                "exports": exports,
            }
        )
    fans = [
        {
            "path": str(hwmon),
            "name": optional_read(hwmon / "name"),
            "fan1_input": optional_read(hwmon / "fan1_input"),
        }
        for hwmon in sorted(Path("/sys/class/hwmon").glob("hwmon*"))
        if (hwmon / "fan1_input").exists()
    ]
    return {
        "providers": providers,
        "fans": fans,
        "pwm_debug": optional_read("/sys/kernel/debug/pwm"),
        "cache_is_electrical_proof": False,
    }


class SafetySignals:
    """Defer repeated signals while ownership is latched or deinit is running."""

    def __init__(self):
        self.depth, self.received, self.previous = 0, [], {}

    def handler(self, signum, _frame):
        self.received.append(signum)
        if self.depth == 0:
            raise RuntimeError(f"Stopped by {signal.Signals(signum).name}")

    @contextmanager
    def atomic(self):
        count = len(self.received)
        self.depth += 1
        completed = False
        try:
            yield
            completed = True
        finally:
            self.depth -= 1
            if completed and self.depth == 0 and len(self.received) != count:
                raise RuntimeError("Signal received during ownership transition")

    @contextmanager
    def cleanup(self):
        self.depth += 1
        try:
            yield
        finally:
            self.depth -= 1

    def __enter__(self):
        for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM):
            self.previous[signum] = signal.signal(signum, self.handler)
        signal.alarm(WATCHDOG_SECONDS)
        return self

    def __exit__(self, *_args):
        signal.alarm(0)
        for signum, previous in self.previous.items():
            signal.signal(signum, previous)


def validate_route(module, host):
    route = module.discover(18)
    require(
        route is not None,
        "GPIO18 has no proven production hardware route; refusing software fallback",
    )
    expected = HOSTS[host]
    require(
        route.gpio == 18
        and route.channel == expected["channel"]
        and route.of_node.name == expected["node"],
        "Unexpected GPIO18 hardware provider/channel",
    )
    require(
        (route.chip / "device/of_node").resolve(strict=True)
        == route.of_node.resolve(strict=True),
        "Hardware chip and OF node identities disagree",
    )
    route.of_node.resolve(strict=True).relative_to(
        module._hardware.DEVICE_TREE.resolve(strict=True)
    )
    require(not route.path.exists(), "Refusing a pre-existing GPIO18 PWM export")
    return route


def identity(route):
    return {
        "gpio": route.gpio,
        "chip": str(route.chip),
        "of_node": str(route.of_node),
        "channel": route.channel,
        "controller": getattr(route, "controller", None),
        "clock_rate_hz": getattr(route, "clock_rate_hz", None),
        "clock_node": str(route.clock_node)
        if getattr(route, "clock_node", None) is not None
        else None,
        "clock_id": getattr(route, "clock_id", None),
        "assigned_clock_is_measured": False,
        "gpio_node": str(route.gpio_node),
        "pinctrl_nodes": [str(node) for node in route.pinctrl_nodes],
    }


def experiment(source_root, manifest_sha256, host, mode):
    require(
        host in HOSTS and mode in MODES, "Unknown authorized host or qualification mode"
    )
    require(
        sys.platform == "linux"
        and socket.gethostname().split(".")[0] == host.split(".")[0],
        "Helper must run on the explicitly selected authorized Pi",
    )
    module, sources = load_package(source_root, manifest_sha256)
    report = {
        "schema_version": 1,
        "ok": False,
        "host": host,
        "mode": mode,
        "source_proof": sources,
        "calls": [],
        "holds": [],
        "cleanup_errors": [],
        "begin_ns": time.monotonic_ns(),
        "max_sequence_seconds": MAX_SEQUENCE_SECONDS,
        "watchdog_seconds": WATCHDOG_SECONDS,
        "cache_is_electrical_proof": False,
        "phase_alignment_claimed": False,
    }
    outputs, route = [], None
    with SafetySignals() as guard:
        try:
            before = system_snapshot()
            report["thermal_before"] = before
            require(
                (before.get("model") or "").startswith(HOSTS[host]["model"] + " Rev "),
                "Selected host does not match the live Pi model",
            )
            require(
                not thermal_issues(before),
                "Thermal preflight rejected: " + "; ".join(thermal_issues(before)),
            )
            report["providers_before"] = provider_snapshot()
            active_start = time.monotonic()

            def call(action, requested, operation, output=None):
                event = {
                    "order": len(report["calls"]),
                    "action": action,
                    "requested": requested,
                    "begin_ns": time.monotonic_ns(),
                }
                report["calls"].append(event)
                try:
                    result = operation()
                    target = result if action == "construct" else output
                    event["deinitialized"] = target.deinitialized
                    if not target.deinitialized:
                        event["public_cache"] = {
                            "frequency": target.frequency,
                            "duty_cycle": target.duty_cycle,
                        }
                        event["sysfs_cache"] = target._engine._read_state()
                    event["cache_is_electrical_proof"] = False
                    event["success"] = True
                    return result
                except BaseException as error:
                    event["success"] = False
                    event["error"] = f"{type(error).__name__}: {error}"
                    event["notes"] = list(getattr(error, "__notes__", ()))
                    raise
                finally:
                    event["end_ns"] = time.monotonic_ns()

            def construct():
                nonlocal route
                with guard.atomic():
                    route = validate_route(module, host)
                    report["provider"] = identity(route)

                    def create():
                        output = module.PWMOut(
                            18, frequency=50, duty_cycle=0, variable_frequency=True
                        )
                        outputs.append(output)
                        require(
                            isinstance(output._engine, module.HardwarePWM),
                            "Public PWMOut selected a non-hardware engine",
                        )
                        require(
                            output._engine.route == route,
                            "Constructor selected a different hardware route",
                        )
                        return output

                    return call(
                        "construct",
                        {
                            "gpio": 18,
                            "frequency": 50,
                            "duty_cycle": 0,
                            "variable_frequency": True,
                        },
                        create,
                    )

            def hold(name, seconds, output=None):
                require(
                    time.monotonic() - active_start + seconds <= MAX_SEQUENCE_SECONDS,
                    "Finite qualification sequence exceeded 8 seconds",
                )
                event = {
                    "name": name,
                    "duration_seconds": seconds,
                    "begin_ns": time.monotonic_ns(),
                    "requested": None
                    if output is None
                    else {
                        "frequency": output.frequency,
                        "duty_cycle": output.duty_cycle,
                    },
                }
                report["holds"].append(event)
                try:
                    time.sleep(seconds)
                finally:
                    event["end_ns"] = time.monotonic_ns()

            def duty(output, value):
                call(
                    "set_duty_cycle",
                    {"duty_cycle": value},
                    lambda: setattr(output, "duty_cycle", value),
                    output,
                )

            def frequency(output, value):
                call(
                    "set_frequency",
                    {"frequency": value},
                    lambda: setattr(output, "frequency", value),
                    output,
                )

            def close(output, label):
                with guard.cleanup():
                    call(label, {"deinit": True}, output.deinit, output)

            output = construct()
            hold("initial_low", 0.25, output)
            if mode == "ordinary":
                for hz, fraction in (
                    (50, 4915),
                    (500, 32768),
                    (25000, 32768),
                    (50, 32768),
                ):
                    frequency(output, hz)
                    duty(output, fraction)
                    hold(f"ordinary_{hz}_{fraction}", 0.3, output)
            elif mode == "endpoints":
                for name, fraction, seconds in (
                    ("half_before_high", 32768, 0.4),
                    ("constant_high", 65535, 0.25),
                    ("half_after_high", 32768, 0.4),
                ):
                    duty(output, fraction)
                    hold(name, seconds, output)
            elif mode == "frequency":
                for name, fraction, seconds in (
                    ("half", 32768, 0.4),
                    ("high", 65535, 0.25),
                ):
                    duty(output, fraction)
                    hold(name + "_initial_50", seconds, output)
                    for hz in (500, 50, 25000):
                        frequency(output, hz)
                        hold(f"{name}_{hz}", seconds, output)
                frequency(output, 50)
            elif mode == "margins":
                for fraction in (1, 32768, 65534):
                    duty(output, fraction)
                    hold(f"margin_{fraction}", 0.4, output)
            else:
                duty(output, 65535)
                hold("high_before_close", 0.25, output)
                close(output, "deinit_from_high")
                hold("released_after_high", 0.25)
                output = construct()
                hold("reopened_low", 0.25, output)
                duty(output, 32768)
                hold("reopened_interior", 0.4, output)
                close(output, "deinit_from_interior")
                hold("released_final", 0.25)
            if mode != "lifecycle":
                duty(output, 0)
                hold("final_low", 0.25, output)
            report["sequence_elapsed_seconds"] = time.monotonic() - active_start
        except BaseException as error:  # noqa: BLE001 -- retain signal/interruption evidence
            report["error"] = f"{type(error).__name__}: {error}"
            report["error_notes"] = list(getattr(error, "__notes__", ()))
        finally:
            with guard.cleanup():
                for index, output in reversed(list(enumerate(outputs))):
                    if not output.deinitialized:
                        try:
                            call(
                                "finally_deinit",
                                {"output_index": index, "deinit": True},
                                output.deinit,
                                output,
                            )
                        except BaseException as error:  # noqa: BLE001 -- finish every cleanup
                            report["cleanup_errors"].append(
                                f"Output {index} deinit: {type(error).__name__}: {error}"
                            )
                try:
                    report["thermal_after"] = system_snapshot()
                    report["providers_after"] = provider_snapshot()
                except BaseException as error:  # noqa: BLE001 -- retain final metadata failure
                    report["cleanup_errors"].append(
                        f"Final metadata: {type(error).__name__}: {error}"
                    )
        report["signals_received"] = guard.received
    report["end_ns"] = time.monotonic_ns()
    report["sysfs_released"] = (
        bool(outputs)
        and all(output.deinitialized for output in outputs)
        and route is not None
        and not route.path.exists()
    )
    report["thermal_issues_after"] = thermal_issues(report.get("thermal_after", {}))
    report["ok"] = (
        "error" not in report
        and not report["cleanup_errors"]
        and not report["signals_received"]
        and report["sysfs_released"]
        and not report["thermal_issues_after"]
    )
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--host", required=True, choices=tuple(HOSTS))
    parser.add_argument("--mode", required=True, choices=MODES)
    args = parser.parse_args(argv)
    try:
        report = experiment(
            args.source_root, args.manifest_sha256, args.host, args.mode
        )
    except BaseException as error:  # noqa: BLE001 -- emit failure JSON even on interruption
        report = {
            "schema_version": 1,
            "ok": False,
            "host": args.host,
            "mode": args.mode,
            "error": f"{type(error).__name__}: {error}",
            "error_notes": list(getattr(error, "__notes__", ())),
            "cleanup_errors": [],
        }
    print(json.dumps(report, sort_keys=True))
    if not report["ok"]:
        print(
            report.get(
                "error", "Qualification rejected; inspect JSON cleanup/thermal evidence"
            ),
            file=sys.stderr,
        )
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
