"""Qualification-helper fakes: no hardware, subprocesses, or outside-tmp writes."""

import json
import re
import signal
import sys
from types import SimpleNamespace

import hardware_pwm_package_eval as bench
import pytest


@pytest.fixture(params=tuple(bench.HOSTS))
def fake_bench(tmp_path, monkeypatch, request):
    host = request.param
    expected = bench.HOSTS[host]
    tree = tmp_path / "tree"
    node = tree / expected["node"]
    node.mkdir(parents=True)
    chip = tmp_path / "pwmchip7"
    (chip / "device").mkdir(parents=True)
    (chip / "device/of_node").symlink_to(node)
    route = SimpleNamespace(
        gpio=18,
        channel=expected["channel"],
        chip=chip,
        of_node=node,
        path=chip / f"pwm{expected['channel']}",
        gpio_node=tree / "gpio",
        pinctrl_nodes=(tree / "pwm_pins",),
        controller="rp1" if expected["channel"] == 2 else "bcm",
        clock_rate_hz=50_000_000,
        clock_node=tree / "clock",
        clock_id=1,
    )
    settings = {"fail_duty": None, "cleanup_fail": False, "created": [], "guards": []}

    class Hardware:
        def __init__(self):
            self.route = route
            self.frequency, self.duty_cycle = 50, 0

        def _read_state(self):
            period = round(1e9 / self.frequency)
            return {
                "period": period,
                "duty_cycle": period * self.duty_cycle // 65535,
                "enable": 1,
                "polarity": "normal",
            }

    class PWM:
        def __init__(self, gpio, *, frequency, duty_cycle, variable_frequency):
            assert (gpio, frequency, duty_cycle, variable_frequency) == (
                18,
                50,
                0,
                True,
            )
            self._engine = Hardware()
            settings["created"].append(self)

        @property
        def deinitialized(self):
            return self._engine is None

        @property
        def frequency(self):
            return self._engine.frequency

        @frequency.setter
        def frequency(self, value):
            self._engine.frequency = value

        @property
        def duty_cycle(self):
            return self._engine.duty_cycle

        @duty_cycle.setter
        def duty_cycle(self, value):
            if value == settings["fail_duty"]:
                raise OSError("injected public setter failure")
            self._engine.duty_cycle = value

        def deinit(self):
            if settings["cleanup_fail"]:
                raise OSError("injected deinit failure")
            if settings.get("signal_cleanup"):
                guard = settings["guards"][-1]
                guard.handler(signal.SIGTERM, None)
                guard.handler(signal.SIGTERM, None)
            self._engine = None

    class Guard(bench.SafetySignals):
        def __init__(self):
            super().__init__()
            settings["guards"].append(self)

    class Clock:
        elapsed = 0.0

        def monotonic(self):
            self.elapsed += 0.00001
            return self.elapsed

        def monotonic_ns(self):
            return round(self.monotonic() * 1e9)

        def sleep(self, seconds):
            self.elapsed += seconds

    module = SimpleNamespace(
        PWMOut=PWM,
        HardwarePWM=Hardware,
        discover=lambda gpio: route,
        _hardware=SimpleNamespace(DEVICE_TREE=tree),
    )
    monkeypatch.setattr(
        bench, "load_package", lambda *args: (module, {"verified": True})
    )
    monkeypatch.setattr(
        bench,
        "system_snapshot",
        lambda: {
            "temperature_millic": "42000",
            "throttled": "throttled=0x0",
            "model": expected["model"] + " Rev 1.0",
        },
    )
    monkeypatch.setattr(
        bench, "provider_snapshot", lambda: {"providers": [], "fans": ["unchanged"]}
    )
    monkeypatch.setattr(bench, "SafetySignals", Guard)
    monkeypatch.setattr(bench, "time", Clock())
    monkeypatch.setattr(bench.sys, "platform", "linux")
    monkeypatch.setattr(
        bench.socket, "gethostname", lambda: host.removesuffix(".local")
    )
    alarms = []
    monkeypatch.setattr(
        bench.signal, "alarm", lambda seconds: alarms.append(seconds) or 0
    )
    monkeypatch.setattr(bench.signal, "signal", lambda *args: signal.SIG_DFL)
    return host, route, module, settings, alarms


@pytest.mark.parametrize("mode", bench.MODES)
def test_modes_use_public_api_and_always_release(fake_bench, mode):
    host, _, _, settings, alarms = fake_bench
    report = bench.experiment("unused", "unused", host, mode)
    assert report["ok"] and report["sysfs_released"]
    assert report["sequence_elapsed_seconds"] <= 8
    assert report["provider"]["assigned_clock_is_measured"] is False
    assert report["provider"]["clock_rate_hz"] == 50_000_000
    assert report["providers_before"] == report["providers_after"]
    assert all(output.deinitialized for output in settings["created"])
    assert all(event["end_ns"] >= event["begin_ns"] for event in report["calls"])
    assert report["phase_alignment_claimed"] is False
    assert alarms == [14, 0]
    if mode == "ordinary":
        assert [
            event["requested"]["frequency"]
            for event in report["calls"]
            if event["action"] == "set_frequency"
        ] == [50, 500, 25000, 50]
    if mode == "frequency":
        assert [
            event["requested"]["frequency"]
            for event in report["calls"]
            if event["action"] == "set_frequency"
        ] == [500, 50, 25000, 500, 50, 25000, 50]
    if mode == "lifecycle":
        assert len(settings["created"]) == 2
        assert [
            event["action"]
            for event in report["calls"]
            if event["action"].startswith("deinit_")
        ] == ["deinit_from_high", "deinit_from_interior"]


def test_missing_or_wrong_route_prevents_constructor(fake_bench):
    host, route, module, settings, _ = fake_bench
    route.channel = 3
    report = bench.experiment("unused", "unused", host, "ordinary")
    assert not report["ok"] and "provider/channel" in report["error"]
    assert settings["created"] == []
    module.discover = lambda gpio: None
    report = bench.experiment("unused", "unused", host, "ordinary")
    assert "refusing software fallback" in report["error"]
    assert settings["created"] == []


def test_setter_failure_and_cleanup_failure_are_both_retained(fake_bench):
    host, _, _, settings, _ = fake_bench
    settings.update(fail_duty=4915, cleanup_fail=True)
    report = bench.experiment("unused", "unused", host, "ordinary")
    assert not report["ok"] and "setter failure" in report["error"]
    assert "deinit failure" in report["cleanup_errors"][0]
    assert report["sysfs_released"] is False
    assert report["calls"][-1]["action"] == "finally_deinit"
    assert report["calls"][-1]["success"] is False


def test_repeated_signals_do_not_interrupt_finally_deinit(fake_bench):
    host, _, _, settings, _ = fake_bench
    settings["signal_cleanup"] = True
    report = bench.experiment("unused", "unused", host, "endpoints")
    assert report["signals_received"] == [signal.SIGTERM, signal.SIGTERM]
    assert report["sysfs_released"] and not report["ok"]
    assert not report["cleanup_errors"]


def test_signal_during_hold_still_runs_finally_deinit(fake_bench, monkeypatch):
    host, _, _, settings, _ = fake_bench

    def interrupted_sleep(_seconds):
        settings["guards"][-1].handler(signal.SIGTERM, None)

    monkeypatch.setattr(bench.time, "sleep", interrupted_sleep)
    report = bench.experiment("unused", "unused", host, "endpoints")
    assert report["sysfs_released"] and not report["ok"]
    assert "SIGTERM" in report["error"]
    assert report["calls"][-1]["action"] == "finally_deinit"
    assert report["calls"][-1]["success"] is True


def test_thermal_gate_precedes_constructor(fake_bench, monkeypatch):
    host, _, _, settings, _ = fake_bench
    snapshot = {
        "model": bench.HOSTS[host]["model"] + " Rev 1.0",
        "temperature_millic": "70001",
        "throttled": "throttled=0x0",
    }
    monkeypatch.setattr(bench, "system_snapshot", lambda: snapshot)
    report = bench.experiment("unused", "unused", host, "endpoints")
    assert not report["ok"] and "Thermal preflight" in report["error"]
    assert settings["created"] == []


@pytest.mark.parametrize("tamper", [None, "source", "helper", "manifest", "extra"])
def test_manifest_verifies_exact_sources_and_running_helper(
    tmp_path, monkeypatch, tamper
):
    root = tmp_path.resolve()
    package_dir = root / "src" / bench.PACKAGE
    package_dir.mkdir(parents=True)
    for name in bench.SOURCE_FILES:
        (package_dir / name).write_text(
            "__version__ = 'fixture'\nfrom . import _hardware, _software\n"
            if name == "__init__.py"
            else "# isolated fixture\n"
        )
    helper = root / "hardware_pwm_package_eval.py"
    helper.write_text("# helper fixture\n")
    manifest = {
        "schema_version": 1,
        "package_files": {
            name: bench.digest(package_dir / name) for name in bench.SOURCE_FILES
        },
        "helper_sha256": bench.digest(helper),
    }
    manifest_path = root / "source-manifest.json"
    manifest_path.write_text(json.dumps(manifest))
    expected = bench.digest(manifest_path)
    monkeypatch.setattr(bench, "ROOT_PATTERN", re.escape(str(root)))
    monkeypatch.setattr(bench, "__file__", str(helper))
    for name in list(sys.modules):
        if name == bench.PACKAGE or name.startswith(bench.PACKAGE + "."):
            monkeypatch.delitem(sys.modules, name)
    if tamper == "source":
        (package_dir / "_hardware.py").write_text("# changed\n")
    elif tamper == "helper":
        helper.write_text("# changed helper\n")
    elif tamper == "manifest":
        expected = "0" * 64
    elif tamper == "extra":
        (package_dir / "__pycache__").mkdir()
    try:
        if tamper is not None:
            with pytest.raises(RuntimeError, match="mismatch|exactly three"):
                bench.load_package(root, expected)
        else:
            module, proof = bench.load_package(root, expected)
            assert module.__version__ == "fixture"
            assert proof["package_files"] == manifest["package_files"]
    finally:
        for name in list(sys.modules):
            if name == bench.PACKAGE or name.startswith(bench.PACKAGE + "."):
                del sys.modules[name]
