"""Offline, conservative evidence for the isolated production-package captures.

Saleae time is the only waveform clock. Remote monotonic receipts establish
request order, not an offset, exact boundary, or electrical state. Boundary
pulses are retained; this analyzer makes no glitch-free or outgoing-pulse claim.
"""

import argparse
import hashlib
import json
import math
import statistics
from itertools import pairwise
from pathlib import Path

from hardware_pwm_package_eval import HOSTS, MODES, SOURCE_FILES, thermal_issues

CHANNELS = {"test2-pi4.local": 2, "test-pi5.local": 0}
RELATIVE_LIMIT = 0.002
MIN_STEADY_SECONDS = 0.15


def expected_holds(mode):
    low = [("initial_low", 0.25, 50, 0)]
    if mode == "ordinary":
        middle = [
            (f"ordinary_{f}_{d}", 0.3, f, d)
            for f, d in ((50, 4915), (500, 32768), (25000, 32768), (50, 32768))
        ]
    elif mode == "endpoints":
        middle = [
            ("half_before_high", 0.4, 50, 32768),
            ("constant_high", 0.25, 50, 65535),
            ("half_after_high", 0.4, 50, 32768),
        ]
    elif mode == "frequency":
        middle = []
        for name, duty, seconds in (("half", 32768, 0.4), ("high", 65535, 0.25)):
            first = 50 if name == "half" else 25000
            middle.append((name + "_initial_50", seconds, first, duty))
            middle.extend((f"{name}_{f}", seconds, f, duty) for f in (500, 50, 25000))
    elif mode == "margins":
        middle = [(f"margin_{d}", 0.4, 50, d) for d in (1, 32768, 65534)]
    elif mode == "lifecycle":
        return low + [
            ("high_before_close", 0.25, 50, 65535),
            ("released_after_high", 0.25, None, None),
            ("reopened_low", 0.25, 50, 0),
            ("reopened_interior", 0.4, 50, 32768),
            ("released_final", 0.25, None, None),
        ]
    else:
        raise ValueError("Unknown qualification mode")
    final_frequency = (
        50 if mode in ("ordinary", "endpoints", "frequency", "margins") else None
    )
    return low + middle + [("final_low", 0.25, final_frequency, 0)]


def expected_calls(mode):
    construct = (
        "construct",
        {"gpio": 18, "frequency": 50, "duty_cycle": 0, "variable_frequency": True},
    )
    duty = lambda value: ("set_duty_cycle", {"duty_cycle": value})
    frequency = lambda value: ("set_frequency", {"frequency": value})
    calls = [construct]
    if mode == "ordinary":
        for hz, fraction in ((50, 4915), (500, 32768), (25000, 32768), (50, 32768)):
            calls.extend((frequency(hz), duty(fraction)))
    elif mode == "endpoints":
        calls.extend(duty(value) for value in (32768, 65535, 32768))
    elif mode == "frequency":
        for fraction in (32768, 65535):
            calls.append(duty(fraction))
            calls.extend(frequency(hz) for hz in (500, 50, 25000))
        calls.append(frequency(50))
    elif mode == "margins":
        calls.extend(duty(value) for value in (1, 32768, 65534))
    elif mode == "lifecycle":
        return calls + [
            duty(65535),
            ("deinit_from_high", {"deinit": True}),
            construct,
            duty(32768),
            ("deinit_from_interior", {"deinit": True}),
        ]
    else:
        raise ValueError("Unknown qualification mode")
    return calls + [duty(0), ("finally_deinit", {"output_index": 0, "deinit": True})]


def receipt_gates(metadata, *, expected_manifest=None, remote_stdout=None):
    """Compare receipts and optional original manifest; no cache is level proof."""
    issues = []
    remote = metadata.get("remote", {})
    if not isinstance(remote, dict):
        remote = {}
    host, mode = metadata.get("host"), metadata.get("mode")
    if metadata.get("schema_version") != 1 or remote.get("schema_version") != 1:
        issues.append("Capture/remote receipt schema mismatch")
    if host not in HOSTS or mode not in MODES:
        issues.append("Unknown host or mode")
    if metadata.get("gpio") != 18 or metadata.get("saleae_channel") != CHANNELS.get(
        host
    ):
        issues.append("Unexpected GPIO/analyzer channel")
    if metadata.get("remote_returncode") != 0 or metadata.get("capture_errors") != []:
        issues.append("Capture or remote command did not complete cleanly")
    if metadata.get("remote_json_error") or metadata.get("digital_export_error"):
        issues.append("Capture receipt has an export/JSON error")
    if (
        remote.get("ok") is not True
        or remote.get("host") != host
        or remote.get("mode") != mode
    ):
        issues.append("Remote success/host/mode receipt mismatch")
    if (
        remote.get("sysfs_released") is not True
        or remote.get("cleanup_errors") != []
        or remote.get("signals_received") != []
        or "error" in remote
    ):
        issues.append("Remote cleanup/signal/error gate failed")
    for name in ("thermal_before", "thermal_after"):
        issues.extend(
            f"{name}: {issue}" for issue in thermal_issues(remote.get(name, {}))
        )
    if remote.get("thermal_issues_after") != []:
        issues.append("Remote thermal postflight gate failed")
    manifest = metadata.get("source_manifest", {})
    if not isinstance(manifest, dict):
        manifest = {}
    proof = remote.get("source_proof", {})
    files = manifest.get("package_files", {}) if isinstance(manifest, dict) else {}
    valid_hash = lambda value: (
        isinstance(value, str)
        and len(value) == 64
        and all(c in "0123456789abcdef" for c in value)
    )
    if (
        not isinstance(files, dict)
        or set(files) != set(SOURCE_FILES)
        or not all(valid_hash(value) for value in files.values())
        or not valid_hash(manifest.get("helper_sha256"))
        or not valid_hash(metadata.get("manifest_sha256"))
    ):
        issues.append("Malformed source hashes")
    if manifest.get("schema_version") != 1:
        issues.append("Source manifest schema mismatch")
    local_helper_hash = hashlib.sha256(
        Path(__file__).with_name("hardware_pwm_package_eval.py").read_bytes()
    ).hexdigest()
    if (
        not isinstance(proof, dict)
        or proof.get("manifest_sha256") != metadata.get("manifest_sha256")
        or proof.get("helper_sha256") != manifest.get("helper_sha256")
        or proof.get("package_files") != files
        or manifest.get("helper_sha256") != local_helper_hash
    ):
        issues.append(
            "Source-proof hashes disagree with recorded manifest/reviewed helper"
        )
    if expected_manifest is not None:
        original = Path(expected_manifest).read_bytes()
        if (
            hashlib.sha256(original).hexdigest() != metadata.get("manifest_sha256")
            or json.loads(original) != manifest
        ):
            issues.append("Original source manifest differs from capture receipt")
    if remote_stdout is not None:
        try:
            if json.loads(remote_stdout) != remote:
                issues.append("remote.stdout and results.json remote receipt disagree")
        except (ValueError, TypeError):
            issues.append("remote.stdout is not one JSON object")
    if mode in MODES:
        wanted = expected_holds(mode)
        holds = remote.get("holds", [])
        if not isinstance(holds, list) or len(holds) != len(wanted):
            issues.append(
                "Request-order hold sequence differs from reviewed experiment"
            )
        else:
            for hold, (name, seconds, frequency, duty) in zip(holds, wanted):
                requested = (
                    None
                    if frequency is None
                    else {"frequency": frequency, "duty_cycle": duty}
                )
                if (
                    not isinstance(hold, dict)
                    or hold.get("name") != name
                    or hold.get("duration_seconds") != seconds
                    or hold.get("requested") != requested
                ):
                    issues.append(f"Request-order hold mismatch: {name}")
        calls = remote.get("calls", [])
        wanted_calls = expected_calls(mode)
        if (
            not isinstance(calls, list)
            or len(calls) != len(wanted_calls)
            or any(
                not isinstance(call, dict)
                or call.get("success") is not True
                or call.get("order") != index
                for index, call in enumerate(calls)
            )
        ):
            issues.append("Missing, reordered, or failed public API call receipts")
        elif any(
            call.get("action") != action or call.get("requested") != requested
            for call, (action, requested) in zip(calls, wanted_calls)
        ):
            issues.append("Public API call sequence differs from reviewed experiment")
    return {
        "passed": not issues,
        "issues": issues,
        "original_manifest_verified": expected_manifest is not None,
        "remote_clock_alignment_used": False,
    }


def describe(values):
    if not values:
        return {"count": 0}
    return {
        "count": len(values),
        "min": min(values),
        "median": statistics.median(values),
        "max": max(values),
    }


def extract(chunks):
    """Keep every transition and every constant-level interval, including cuts."""
    edges, intervals, cycles = [], [], []
    for index, (initial, begin, end, rate, times) in enumerate(chunks):
        if (
            initial not in (0, 1)
            or not math.isfinite(begin)
            or not math.isfinite(end)
            or begin > end
            or any(not math.isfinite(t) or not begin <= t <= end for t in times)
            or any(a >= b for a, b in pairwise(times))
        ):
            raise ValueError("Invalid Saleae chunk")
        state, start, previous_edge = initial, begin, None
        chunk_edges = []
        for local_index, time in enumerate(times):
            edge_id = len(edges)
            intervals.append(
                {
                    "chunk": index,
                    "level": state,
                    "begin": start,
                    "end": time,
                    "seconds": time - start,
                    "begin_edge": previous_edge,
                    "end_edge": edge_id,
                    "capture_truncated": previous_edge is None,
                }
            )
            state = 1 - state
            edge = {
                "id": edge_id,
                "chunk": index,
                "time": time,
                "level_after": state,
                "classification": "boundary_or_unassigned",
            }
            edges.append(edge)
            chunk_edges.append(edge)
            start, previous_edge = time, edge_id
        intervals.append(
            {
                "chunk": index,
                "level": state,
                "begin": start,
                "end": end,
                "seconds": end - start,
                "begin_edge": previous_edge,
                "end_edge": None,
                "capture_truncated": True,
            }
        )
        for a, b, c in zip(chunk_edges, chunk_edges[1:], chunk_edges[2:]):
            if (a["level_after"], b["level_after"], c["level_after"]) == (1, 0, 1):
                period, high = c["time"] - a["time"], b["time"] - a["time"]
                cycles.append(
                    {
                        "id": len(cycles),
                        "chunk": index,
                        "begin": a["time"],
                        "end": c["time"],
                        "edge_ids": [a["id"], b["id"], c["id"]],
                        "period_seconds": period,
                        "high_seconds": high,
                        "duty_fraction": high / period,
                    }
                )
    return edges, intervals, cycles


def controller_tick(metadata, clock_hz=None, clock_basis=None):
    if clock_hz is not None:
        if not math.isfinite(clock_hz) or clock_hz <= 0:
            raise ValueError("Controller clock must be positive and finite")
        return 1 / clock_hz, (
            clock_basis or "device_tree_assignment"
        ) + "; nominal, not measured"
    provider = metadata.get("remote", {}).get("provider", {})
    rate = provider.get("clock_rate_hz")
    if isinstance(rate, (int, float)) and not isinstance(rate, bool) and rate > 0:
        return 1 / rate, "recorded assigned controller clock, not a measured clock"
    # No fallback is treated as proof: acceptance is withheld without a clock receipt.
    return None, "controller clock not in receipt; tolerance/acceptance unresolved"


def identify_groups(cycles, specs):
    """Coarse signatures locate phases; narrow tolerances never select samples.

    Distinct coarse runs must be unique and in request order. Tiny anomaly runs
    between the same signature are included in that group's checks, not removed.
    Long gaps always split groups. All discarded candidates remain in the ledger.
    """
    unique = list(dict.fromkeys((f, d) for _, _, f, d in specs))
    labels = []
    for cycle in cycles:
        candidates = []
        for frequency, duty in unique:
            period, fraction = 1 / frequency, duty / 65535
            if (
                abs(cycle["period_seconds"] / period - 1) < 0.15
                and abs(cycle["duty_fraction"] - fraction) < 0.08
            ):
                candidates.append((frequency, duty))
        labels.append(candidates[0] if len(candidates) == 1 else None)
    runs = []
    for cycle, label in zip(cycles, labels):
        if (
            runs
            and runs[-1]["label"] == label
            and runs[-1]["chunk"] == cycle["chunk"]
            and runs[-1]["cycles"][-1]["end"] == cycle["begin"]
        ):
            runs[-1]["cycles"].append(cycle)
        else:
            runs.append({"label": label, "chunk": cycle["chunk"], "cycles": [cycle]})
    changed = True
    while changed:
        changed = False
        for i in range(1, len(runs) - 1):
            left, middle, right = runs[i - 1 : i + 2]
            middle_seconds = middle["cycles"][-1]["end"] - middle["cycles"][0]["begin"]
            if (
                left["label"] is not None
                and left["label"] == right["label"]
                and left["chunk"] == middle["chunk"] == right["chunk"]
                and len(middle["cycles"]) <= 3
                and middle_seconds < 0.075
            ):
                runs[i - 1 : i + 2] = [
                    {
                        "label": left["label"],
                        "chunk": left["chunk"],
                        "cycles": left["cycles"] + middle["cycles"] + right["cycles"],
                    }
                ]
                changed = True
                break
    strong = [
        run
        for run in runs
        if run["label"] is not None
        and len(run["cycles"]) >= 5
        and run["cycles"][-1]["end"] - run["cycles"][0]["begin"] >= 0.18
    ]
    wanted = [(f, d) for _, _, f, d in specs]
    if [run["label"] for run in strong] != wanted:
        return (
            [],
            "Coarse waveform groups are missing, duplicated, or out of request order",
        )
    return strong, None


def analyze_chunks(
    metadata,
    chunks,
    *,
    expected_manifest=None,
    remote_stdout=None,
    controller_clock_hz=None,
    clock_basis=None,
):
    gates = receipt_gates(
        metadata, expected_manifest=expected_manifest, remote_stdout=remote_stdout
    )
    edges, intervals, cycles = extract(chunks)
    mode = metadata.get("mode")
    result = {
        "schema_version": 1,
        "host": metadata.get("host"),
        "mode": mode,
        "receipt_gates": gates,
        "acceptance": None,
        "phase_alignment": "request order and Saleae waveform only; no remote clock mapping",
        "claims_excluded": [
            "glitch-free transitions",
            "complete outgoing boundary pulse",
            "16-bit electrical resolution",
            "cache proves electrical level",
        ],
        "uncertainties": [],
        "steady_groups": [],
        "raw": {
            "chunks": len(chunks),
            "edges": len(edges),
            "complete_cycles": len(cycles),
            "high_seconds": describe([i["seconds"] for i in intervals if i["level"]]),
            "low_seconds": describe(
                [i["seconds"] for i in intervals if not i["level"]]
            ),
        },
    }
    if len(chunks) != 1:
        result["uncertainties"].append(
            "Multiple/discontinuous Saleae chunks; no cross-gap phase proof"
        )
    if mode not in MODES:
        result["uncertainties"].append("Unknown mode prevents request-order mapping")
        specs = []
    else:
        specs = [
            hold for hold in expected_holds(mode) if hold[2] and 0 < hold[3] < 65535
        ]
    groups, ambiguity = (
        identify_groups(cycles, specs)
        if specs
        else ([], "No ordinary request sequence")
    )
    if ambiguity:
        result["uncertainties"].append(ambiguity)
    tick, tick_basis = controller_tick(metadata, controller_clock_hz, clock_basis)
    result["controller_tick_seconds"], result["controller_tick_basis"] = (
        tick,
        tick_basis,
    )
    if tick is None:
        result["uncertainties"].append(tick_basis)
    selected = set()
    for run, (name, _, frequency, duty) in zip(groups, specs):
        # Guard exactly one complete cycle at each identifiable run boundary.
        # Those cycles and all their pulses remain in boundary_cycles below.
        steady = run["cycles"][1:-1]
        period, high = 1 / frequency, duty / 65535 / frequency
        rate = chunks[run["chunk"]][3] or metadata.get("sample_rate_hz")
        sample = 1 / rate if isinstance(rate, (int, float)) and rate > 0 else None
        group = {
            "name": name,
            "requested_frequency_hz": frequency,
            "requested_duty": duty,
            "target_duty_fraction": duty / 65535,
            "target_period_seconds": period,
            "target_high_seconds": high,
            "first_saleae_time": steady[0]["begin"],
            "last_saleae_time": steady[-1]["end"],
            "cycles": len(steady),
            "boundary_guard_complete_cycles": 2,
            "period_seconds": describe([c["period_seconds"] for c in steady]),
            "high_seconds": describe([c["high_seconds"] for c in steady]),
            "duty_fraction": describe([c["duty_fraction"] for c in steady]),
            "rp1_inclusive_period_may_add_one_clock_tick": metadata.get("host")
            == "test-pi5.local",
            "within_tolerance": None,
            "failing_cycle_ids": [],
        }
        if tick is not None and sample is not None:
            period_tolerance = RELATIVE_LIMIT * period + tick + 2 * sample
            high_tolerance = RELATIVE_LIMIT * high + tick + 2 * sample
            group["period_tolerance_seconds"] = period_tolerance
            group["high_tolerance_seconds"] = high_tolerance
            failed = [
                c["id"]
                for c in steady
                if abs(c["period_seconds"] - period) > period_tolerance
                or abs(c["high_seconds"] - high) > high_tolerance
            ]
            group["failing_cycle_ids"] = failed
            group["within_tolerance"] = not failed
        if steady[-1]["end"] - steady[0]["begin"] < MIN_STEADY_SECONDS:
            result["uncertainties"].append(
                f"{name}: less than 0.15 s complete steady cycles"
            )
        for cycle in steady:
            selected.add(cycle["id"])
            for edge_id in cycle["edge_ids"]:
                edges[edge_id]["classification"] = "steady:" + name
        result["steady_groups"].append(group)
    long_intervals = [
        dict(i, interior_edges=0)
        for i in intervals
        if i["seconds"] >= MIN_STEADY_SECONDS
    ]
    result["edge_free_intervals"] = long_intervals
    final = intervals[-1] if intervals else None
    result["final_tail"] = {
        "level": final["level"] if final else None,
        "seconds": final["seconds"] if final else 0,
        "low_at_least_0_15_seconds": bool(
            final and final["level"] == 0 and final["seconds"] >= MIN_STEADY_SECONDS
        ),
    }
    # Interval endpoints are boundary edges; only open interiors are edge-free.
    initial_low = bool(
        intervals
        and intervals[0]["level"] == 0
        and intervals[0]["seconds"] >= MIN_STEADY_SECONDS
    )
    result["initial_low_edge_free_observed"] = initial_low
    high_intervals = [i for i in long_intervals if i["level"]]
    result["identified_holds"] = []
    if mode == "endpoints" and len(groups) == 2:
        candidates = [
            i
            for i in high_intervals
            if groups[0]["cycles"][-1]["begin"] <= i["begin"]
            and i["end"] <= groups[1]["cycles"][0]["end"]
        ]
        if len(candidates) == 1 and candidates[0]["seconds"] >= 0.20:
            result["identified_holds"].append(dict(candidates[0], name="constant_high"))
        else:
            result["uncertainties"].append(
                "Constant-HIGH hold not uniquely identified between recovered groups"
            )
    elif mode == "frequency":
        result["frequency_high_request_receipts"] = [
            {
                "name": name,
                "duration_seconds": duration,
                "requested_frequency_hz": frequency,
                "requested_duty": duty,
            }
            for name, duration, frequency, duty in expected_holds(mode)
            if duty == 65535
        ]
        after_half = groups[-1]["cycles"][-1]["begin"] if groups else math.inf
        result["observed_high_frequency_plateaus"] = [
            i for i in high_intervals if i["begin"] >= after_half
        ]
        high_train_begin = (
            result["observed_high_frequency_plateaus"][0]["begin"]
            if result["observed_high_frequency_plateaus"]
            else math.inf
        )
        result["frequency_high_boundary_low_intervals"] = [
            i
            for i in intervals
            if i["level"] == 0
            and i["begin"] >= high_train_begin
            and i["end_edge"] is not None
        ]
        candidates = [i for i in high_intervals if i["seconds"] >= 0.85]
        if (
            len(candidates) == 1
            and len(groups) == 4
            and candidates[0]["begin"] >= groups[-1]["cycles"][-1]["begin"]
        ):
            result["identified_holds"].append(
                dict(
                    candidates[0],
                    name="aggregate_high_frequency_holds",
                    request_holds=result["frequency_high_request_receipts"],
                    individual_boundaries_identifiable=False,
                )
            )
        else:
            result["uncertainties"].append(
                "Aggregate edge-free HIGH frequency-hold span not uniquely identified"
            )
    elif mode == "lifecycle" and len(groups) == 1:
        high = [
            i
            for i in high_intervals
            if i["seconds"] >= 0.20 and i["end"] < groups[0]["cycles"][0]["begin"]
        ]
        low = [
            i
            for i in long_intervals
            if i["level"] == 0
            and i["seconds"] >= 0.40
            and high
            and high[0]["end"] <= i["begin"]
            and i["end"] <= groups[0]["cycles"][0]["begin"]
        ]
        if len(high) == 1 and len(low) == 1:
            result["identified_holds"].extend(
                [
                    dict(high[0], name="high_before_close"),
                    dict(
                        low[0],
                        name="aggregate_released_and_reopened_low",
                        individual_boundaries_identifiable=False,
                    ),
                ]
            )
        else:
            result["uncertainties"].append(
                "Lifecycle HIGH/released-reopened LOW span not uniquely identified"
            )
    if mode == "margins":
        result["margin_note"] = (
            "Duties 1 and 65534 are quantization evidence, not a 16-bit electrical-resolution guarantee"
        )
    failed = [
        g["name"] for g in result["steady_groups"] if g["within_tolerance"] is False
    ]
    if (
        not result["uncertainties"]
        and gates["passed"]
        and groups
        and all(g["within_tolerance"] is not None for g in result["steady_groups"])
    ):
        result["acceptance"] = (
            not failed
            and initial_low
            and result["final_tail"]["low_at_least_0_15_seconds"]
        )
    result["edge_accounting"] = {
        "total": len(edges),
        "steady": sum(e["classification"].startswith("steady:") for e in edges),
        "boundary_or_unassigned": sum(
            e["classification"] == "boundary_or_unassigned" for e in edges
        ),
    }
    result["boundary_cycles"] = [c for c in cycles if c["id"] not in selected]
    result["boundary_or_unassigned_intervals"] = [
        i
        for i in intervals
        if any(
            edge_id is None
            or edges[edge_id]["classification"] == "boundary_or_unassigned"
            for edge_id in (i["begin_edge"], i["end_edge"])
        )
    ]
    result["edge_ledger"] = edges
    return result


def analyze_directory(
    directory, *, expected_manifest=None, controller_clock_hz=None, clock_basis=None
):
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    # Importing the established parser performs no capture, SSH, or GPIO action.
    from capture_pwm import read_digital

    version, chunks = read_digital(
        directory / f"digital_{metadata['saleae_channel']}.bin"
    )
    result = analyze_chunks(
        metadata,
        chunks,
        expected_manifest=expected_manifest,
        remote_stdout=(directory / "remote.stdout").read_text(),
        controller_clock_hz=controller_clock_hz,
        clock_basis=clock_basis,
    )
    result["capture"] = str(directory.resolve())
    result["binary_version"] = version
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument(
        "--manifest", type=Path, help="Optional original serialized source manifest"
    )
    parser.add_argument(
        "--controller-clock-hz",
        type=float,
        help="Explicit nominal controller rate for quantization allowance only",
    )
    parser.add_argument(
        "--clock-basis",
        default="device_tree_assignment",
        help="Provenance of explicit nominal rate; does not make it measured",
    )
    parser.add_argument(
        "--full", action="store_true", help="Include full edge/boundary ledger"
    )
    args = parser.parse_args(argv)
    result = analyze_directory(
        args.directory,
        expected_manifest=args.manifest,
        controller_clock_hz=args.controller_clock_hz,
        clock_basis=args.clock_basis,
    )
    if not args.full:
        for key in (
            "edge_ledger",
            "boundary_cycles",
            "boundary_or_unassigned_intervals",
        ):
            result[key + "_count"] = len(result.pop(key))
        result["ledger_note"] = (
            "Use --full for every retained edge and boundary pulse; original binary is untouched"
        )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
