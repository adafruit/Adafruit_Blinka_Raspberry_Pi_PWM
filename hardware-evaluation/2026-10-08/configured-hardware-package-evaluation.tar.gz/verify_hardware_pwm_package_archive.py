"""Verify new archive bytes against originals without extraction or replay."""

import argparse
import hashlib
import json
import tarfile
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify(archive):
    lab = Path(__file__).resolve().parent
    package = lab.parent / "Adafruit_Blinka_Raspberry_Pi_PWM"
    names = [
        "hardware_pwm_package_eval.py",
        "capture_hardware_pwm_package.py",
        "test_hardware_pwm_package_eval.py",
        "test_capture_hardware_pwm_package.py",
        "hardware_pwm_package_analysis.py",
        "test_hardware_pwm_package_analysis.py",
        "verify_hardware_pwm_package_archive.py",
        "oct8-hardware-package-source-manifest.json",
        "oct8-hardware-package-criteria.json",
        "oct8-hardware-package-postflight-attempt.json",
        "oct8-package-pi4-postflight.txt",
        "oct8-package-pi4-postflight-r2.txt",
        "oct8-package-pi5-postflight.txt",
        "oct8-hardware-package-archive-with-appledouble.tar.gz",
        "oct8-hardware-package-initial-verification-empty.json",
        "oct8-hardware-package-archive-attempt.json",
    ]
    originals = {name: lab / name for name in names}
    for board in ("pi4", "pi5"):
        for mode in ("endpoints", "ordinary", "frequency", "lifecycle", "margins"):
            directory = lab / f"oct8-package-{board}-{mode}"
            assert directory.is_dir() and not directory.is_symlink()
            for path in directory.rglob("*"):
                assert not path.is_symlink(), path
                if path.is_file():
                    originals[str(path.relative_to(lab))] = path
    manifest = json.loads((lab / "oct8-hardware-package-source-manifest.json").read_text())
    source_proof = {}
    for name, expected in manifest["package_files"].items():
        relative = f"src/adafruit_blinka_raspberry_pi_pwm/{name}"
        originals[relative] = package / relative
        actual = digest(originals[relative].read_bytes())
        assert actual == expected, relative
        source_proof[name] = actual
    assert digest((lab / "hardware_pwm_package_eval.py").read_bytes()) == manifest["helper_sha256"]
    seen, members = set(), {}
    with tarfile.open(archive, "r:gz") as saved:
        for member in saved.getmembers():
            name = member.name
            assert not Path(name).is_absolute() and ".." not in Path(name).parts, name
            if member.isdir():
                continue
            assert member.isfile() and name in originals and name not in seen, name
            seen.add(name)
            with saved.extractfile(member) as stream:
                data = stream.read()
            original = originals[name].read_bytes()
            assert data == original and member.size == len(original), name
            members[name] = {"sha256": digest(data), "bytes": len(data)}
    assert seen == set(originals), set(originals) - seen
    raw = Path(archive).read_bytes()
    return {
        "schema_version": 1,
        "archive": Path(archive).name,
        "archive_sha256": digest(raw),
        "archive_bytes": len(raw),
        "regular_files": len(members),
        "all_original_bytes_match": True,
        "production_source_manifest_matches_originals": True,
        "production_package_files": source_proof,
        "members": members,
        "extraction_performed": False,
        "saved_sal_replay_performed": False,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    arguments = parser.parse_args()
    print(json.dumps(verify(arguments.archive), indent=2, sort_keys=True))
