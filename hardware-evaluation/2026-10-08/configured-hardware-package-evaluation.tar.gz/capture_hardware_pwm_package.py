"""Capture only the confirmed GPIO18 channel for isolated public-PWMOut tests.

This wrapper does not deploy files, configure providers, or analyze acceptance.
All SAL/raw data and remote output are retained, including helper failures.
"""

import argparse
import json
import re
import shlex
import struct
import subprocess
from pathlib import Path

from capture_pwm import DEVICE_ID, read_digital
from hardware_pwm_package_eval import MODES, ROOT_PATTERN, digest, validate_manifest
from saleae import automation

CHANNELS = {"test2-pi4.local": 2, "test-pi5.local": 0}


def decoded(value):
    return value.decode(errors="replace") if isinstance(value, bytes) else value or ""


def capture(args):
    if args.mode not in MODES:
        raise ValueError("Unknown qualification mode")
    if not re.fullmatch(ROOT_PATTERN, args.remote_root):
        raise ValueError("Requires the private /tmp hardware bench directory")
    if CHANNELS.get(args.host) != args.saleae_channel:
        raise ValueError("Confirm GPIO18 on Pi4/channel2 or Pi5/channel0")
    manifest = validate_manifest(json.loads(args.manifest.read_text()))
    if manifest["helper_sha256"] != digest(
        Path(__file__).with_name("hardware_pwm_package_eval.py")
    ):
        raise ValueError(
            "Manifest helper SHA256 does not match the reviewed local helper"
        )
    manifest_sha = digest(args.manifest)
    output = args.directory.resolve()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", output.name):
        raise ValueError("Use a simple new capture directory name")
    output.mkdir(parents=True, exist_ok=False)
    sample_rate = 100_000_000 if args.mode in ("endpoints", "margins") else 10_000_000
    invocation = shlex.join(
        [
            "/usr/bin/python3",
            "-B",
            args.remote_root + "/hardware_pwm_package_eval.py",
            "--source-root",
            args.remote_root,
            "--manifest-sha256",
            manifest_sha,
            "--host",
            args.host,
            "--mode",
            args.mode,
        ]
    )
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        f"pi@{args.host}",
        invocation,
    ]
    metadata = {
        "schema_version": 1,
        "host": args.host,
        "gpio": 18,
        "saleae_channel": args.saleae_channel,
        "mode": args.mode,
        "sample_rate_hz": sample_rate,
        "source_manifest": manifest,
        "manifest_sha256": manifest_sha,
        "remote_root": args.remote_root,
        "acceptance_analysis_performed": False,
        "phase_alignment_claimed": False,
        "capture_errors": [],
        "remote_returncode": None,
    }
    remote = subprocess.CompletedProcess(
        command, 125, "", "Remote command was not started"
    )
    failure = None
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            if not any(
                device.device_id == DEVICE_ID and not device.is_simulation
                for device in manager.get_devices()
            ):
                raise RuntimeError("Confirmed physical analyzer is not available")
            metadata["logic_version"] = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[args.saleae_channel],
                digital_sample_rate=sample_rate,
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as recorded:
                try:
                    remote = subprocess.run(
                        command, capture_output=True, text=True, check=False, timeout=20
                    )
                except subprocess.TimeoutExpired as error:
                    remote = subprocess.CompletedProcess(
                        command,
                        124,
                        decoded(error.stdout),
                        decoded(error.stderr) + "\nSSH timeout",
                    )
                finally:
                    for name, operation in (
                        ("stop", recorded.stop),
                        (
                            "save_capture",
                            lambda: recorded.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_raw_data_binary",
                            lambda: recorded.export_raw_data_binary(
                                str(output), digital_channels=[args.saleae_channel]
                            ),
                        ),
                    ):
                        try:
                            operation()
                        except BaseException as error:  # noqa: BLE001 -- attempt all artifact saves
                            metadata["capture_errors"].append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:  # noqa: BLE001 -- save evidence before reraising
        failure = error
        metadata["capture_errors"].append(
            f"Capture orchestration: {type(error).__name__}: {error}"
        )
    finally:
        metadata["remote_returncode"] = remote.returncode
        (output / "remote.stdout").write_text(decoded(remote.stdout))
        (output / "remote.stderr").write_text(decoded(remote.stderr))
        try:
            metadata["remote"] = json.loads(decoded(remote.stdout))
        except (ValueError, TypeError):
            metadata["remote_json_error"] = "Remote output is not one JSON object"
        binary = output / f"digital_{args.saleae_channel}.bin"
        if binary.is_file():
            try:
                version, chunks = read_digital(binary)
                metadata["digital_export"] = {
                    "version": version,
                    "chunks": len(chunks),
                    "edge_counts": [len(chunk[-1]) for chunk in chunks],
                    "acceptance_analysis_performed": False,
                }
            except (AssertionError, OSError, ValueError, struct.error) as error:
                metadata["digital_export_error"] = f"{type(error).__name__}: {error}"
        with (output / "results.json").open("x") as stream:
            json.dump(metadata, stream, indent=2)
            stream.write("\n")
    if failure is not None:
        raise failure
    if remote.returncode or metadata["capture_errors"]:
        raise RuntimeError(
            "Capture artifacts retained; remote/capture operation failed"
        )
    report = metadata.get("remote", {})
    if (
        not isinstance(report, dict)
        or report.get("ok") is not True
        or report.get("mode") != args.mode
        or report.get("host") != args.host
        or report.get("sysfs_released") is not True
    ):
        raise RuntimeError(
            "Capture retained; helper did not confirm expected mode, host and cleanup"
        )
    proof = report.get("source_proof", {})
    if (
        proof.get("manifest_sha256") != manifest_sha
        or proof.get("helper_sha256") != manifest["helper_sha256"]
        or proof.get("package_files") != manifest["package_files"]
    ):
        raise RuntimeError(
            "Capture retained; remote source proof disagrees with the reviewed manifest"
        )
    return metadata


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--host", required=True, choices=tuple(CHANNELS))
    parser.add_argument("--saleae-channel", required=True, type=int, choices=(0, 2))
    parser.add_argument("--mode", required=True, choices=MODES)
    args = parser.parse_args(argv)
    result = capture(args)
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "mode": args.mode,
                "remote_ok": result["remote"]["ok"],
                "acceptance_analysis_performed": False,
            }
        )
    )


if __name__ == "__main__":
    main()
