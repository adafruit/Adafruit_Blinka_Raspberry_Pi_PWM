"""Synthetic receipts and Saleae tuples only: no analyzer, SSH, or hardware."""

import copy
import hashlib
import json
from pathlib import Path

import pytest

import hardware_pwm_package_analysis as bench


def metadata(mode="ordinary", host="test2-pi4.local"):
    helper_hash = hashlib.sha256(
        Path(bench.__file__).with_name("hardware_pwm_package_eval.py").read_bytes()
    ).hexdigest()
    manifest = {
        "schema_version": 1,
        "helper_sha256": helper_hash,
        "package_files": {name: "a" * 64 for name in bench.SOURCE_FILES},
    }
    manifest_bytes = json.dumps(manifest, indent=2).encode()
    source_hash = hashlib.sha256(manifest_bytes).hexdigest()
    remote = {
        "schema_version": 1,
        "ok": True,
        "host": host,
        "mode": mode,
        "cleanup_errors": [],
        "signals_received": [],
        "sysfs_released": True,
        "thermal_before": {"temperature_millic": "40000", "throttled": "throttled=0x0"},
        "thermal_after": {"temperature_millic": "41000", "throttled": "throttled=0x0"},
        "thermal_issues_after": [],
        "provider": {"clock_rate_hz": 100_000_000},
        "source_proof": {
            "manifest_sha256": source_hash,
            "helper_sha256": helper_hash,
            "package_files": manifest["package_files"],
        },
        "holds": [
            {
                "name": name,
                "duration_seconds": duration,
                "requested": None
                if frequency is None
                else {"frequency": frequency, "duty_cycle": duty},
                "begin_ns": 98_000_000_000 + index * 1_000_000_000,
                "end_ns": 98_500_000_000 + index * 1_000_000_000,
            }
            for index, (name, duration, frequency, duty) in enumerate(
                bench.expected_holds(mode)
            )
        ],
        "calls": [
            {"order": index, "success": True, "action": action, "requested": requested}
            for index, (action, requested) in enumerate(bench.expected_calls(mode))
        ],
    }
    return {
        "schema_version": 1,
        "host": host,
        "mode": mode,
        "gpio": 18,
        "saleae_channel": bench.CHANNELS[host],
        "sample_rate_hz": 100_000_000,
        "source_manifest": manifest,
        "manifest_sha256": source_hash,
        "remote_returncode": 0,
        "capture_errors": [],
        "remote": remote,
    }, manifest_bytes


def waveform(mode="ordinary"):
    state, time, edges = 0, 0.4, []

    def set_level(at, level):
        nonlocal state
        if level != state:
            assert not edges or at > edges[-1]
            edges.append(at)
            state = level

    for _, duration, frequency, duty in bench.expected_holds(mode):
        end = time + duration
        if duty in (0, None):
            set_level(time, 0)
        elif duty == 65535:
            set_level(time, 1)
        else:
            period = 1 / frequency
            for cycle in range(round(duration * frequency)):
                rise = time + cycle * period
                fall = rise + period * duty / 65535
                set_level(rise, 1)
                set_level(fall, 0)
        time = end
    return [(0, 0.0, time + 0.15, 100_000_000.0, tuple(edges))]


@pytest.mark.parametrize("mode", bench.MODES)
def test_identifies_order_without_remote_clock_alignment(mode):
    receipt, _ = metadata(mode)
    result = bench.analyze_chunks(receipt, waveform(mode))
    assert result["receipt_gates"]["passed"]
    assert result["acceptance"] is True
    assert not result["uncertainties"]
    assert result["final_tail"]["low_at_least_0_15_seconds"]
    assert all(group["within_tolerance"] for group in result["steady_groups"])
    changed = copy.deepcopy(receipt)
    for hold in changed["remote"]["holds"]:
        hold["begin_ns"] += 987_000_000_000
        hold["end_ns"] += 987_000_000_000
    assert (
        bench.analyze_chunks(changed, waveform(mode))["steady_groups"]
        == result["steady_groups"]
    )
    accounting = result["edge_accounting"]
    assert (
        accounting["total"]
        == accounting["steady"] + accounting["boundary_or_unassigned"]
    )
    assert len(result["edge_ledger"]) == result["raw"]["edges"]


def test_steady_anomaly_not_removed_by_coarse_identification():
    receipt, _ = metadata("ordinary")
    initial, begin, end, rate, times = waveform("ordinary")[0]
    changed = list(times)
    # First request: 50 Hz, 7.5% high. Add 50 us to an interior falling edge.
    index = next(
        index
        for index, edge in enumerate(changed)
        if 0.79 < edge < 0.792 and index % 2 == 1
    )
    changed[index] += 50e-6
    result = bench.analyze_chunks(
        receipt, [(initial, begin, end, rate, tuple(changed))]
    )
    assert result["acceptance"] is False
    assert result["steady_groups"][0]["failing_cycle_ids"]
    assert len(result["edge_ledger"]) == len(times)


def test_high_hold_edge_prevents_endpoint_acceptance_and_is_retained():
    receipt, _ = metadata("endpoints")
    initial, begin, end, rate, times = waveform("endpoints")[0]
    changed = sorted([*times, 1.15, 1.150001])
    result = bench.analyze_chunks(
        receipt, [(initial, begin, end, rate, tuple(changed))]
    )
    assert result["acceptance"] is None
    assert any("HIGH" in issue for issue in result["uncertainties"])
    assert any(edge["time"] == 1.15 for edge in result["edge_ledger"])


def test_no_silent_boundary_pulse_removal():
    receipt, _ = metadata("endpoints")
    result = bench.analyze_chunks(receipt, waveform("endpoints"))
    assert result["boundary_cycles"]
    assert result["boundary_or_unassigned_intervals"]
    assert any(
        pulse["capture_truncated"]
        for pulse in result["boundary_or_unassigned_intervals"]
    )
    assert "glitch-free transitions" in result["claims_excluded"]
    assert "complete outgoing boundary pulse" in result["claims_excluded"]
    assert all(
        interval["interior_edges"] == 0 for interval in result["edge_free_intervals"]
    )


@pytest.mark.parametrize(
    "field", ["source", "thermal", "remote", "cleanup", "signal", "holds"]
)
def test_receipt_failures_prevent_acceptance(field):
    receipt, _ = metadata()
    if field == "source":
        receipt["remote"]["source_proof"]["helper_sha256"] = "b" * 64
    elif field == "thermal":
        receipt["remote"]["thermal_after"]["throttled"] = "throttled=0x10000"
    elif field == "remote":
        receipt["remote_returncode"] = 1
    elif field == "cleanup":
        receipt["remote"]["sysfs_released"] = False
    elif field == "signal":
        receipt["remote"]["signals_received"] = [15]
    else:
        receipt["remote"]["holds"].reverse()
    result = bench.analyze_chunks(receipt, waveform())
    assert result["acceptance"] is None
    assert not result["receipt_gates"]["passed"]
    assert result["receipt_gates"]["issues"]


def test_original_manifest_bytes_and_stdout_are_checked(tmp_path):
    receipt, raw_manifest = metadata()
    path = tmp_path / "manifest.json"
    path.write_bytes(raw_manifest)
    gate = bench.receipt_gates(
        receipt, expected_manifest=path, remote_stdout=json.dumps(receipt["remote"])
    )
    assert gate["passed"] and gate["original_manifest_verified"]
    path.write_bytes(raw_manifest + b"\n")
    assert not bench.receipt_gates(receipt, expected_manifest=path)["passed"]
    assert not bench.receipt_gates(receipt, remote_stdout="{}")["passed"]


def test_unknown_clock_and_missing_or_extra_groups_are_ambiguous():
    receipt, _ = metadata()
    receipt["remote"]["provider"]["clock_rate_hz"] = None
    result = bench.analyze_chunks(receipt, waveform())
    assert result["acceptance"] is None
    assert result["steady_groups"][0]["within_tolerance"] is None
    other = bench.analyze_chunks(metadata()[0], waveform("endpoints"))
    assert other["acceptance"] is None
    assert other["uncertainties"]


def test_same_level_frequency_boundaries_not_invented():
    receipt, _ = metadata("frequency", "test-pi5.local")
    result = bench.analyze_chunks(receipt, waveform("frequency"))
    high = result["identified_holds"][0]
    assert high["name"] == "aggregate_high_frequency_holds"
    assert high["individual_boundaries_identifiable"] is False
    assert len(high["request_holds"]) == 4
    assert high["request_holds"][0]["requested_frequency_hz"] == 25000
    assert high["interior_edges"] == 0


def test_discontinuous_chunks_do_not_create_cross_gap_cycles():
    receipt, _ = metadata("ordinary")
    initial, begin, end, rate, times = waveform()[0]
    cut = 1.0
    before = tuple(t for t in times if t < cut)
    after = tuple(t for t in times if t > cut)
    state = len(before) % 2
    result = bench.analyze_chunks(
        receipt,
        [(initial, begin, cut, rate, before), (state, cut + 1e-6, end, rate, after)],
    )
    assert result["acceptance"] is None
    assert any("chunks" in issue for issue in result["uncertainties"])
    assert result["raw"]["edges"] == len(before) + len(after)


def test_margins_describe_quantization_without_resolution_claim():
    receipt, _ = metadata("margins")
    result = bench.analyze_chunks(receipt, waveform("margins"))
    assert "not a 16-bit" in result["margin_note"]
    assert [group["requested_duty"] for group in result["steady_groups"]] == [
        1,
        32768,
        65534,
    ]
    assert result["steady_groups"][0]["high_tolerance_seconds"] > 10e-9


def test_short_final_low_is_failure_with_identifiable_phases():
    receipt, _ = metadata("ordinary")
    initial, begin, _end, rate, times = waveform()[0]
    result = bench.analyze_chunks(
        receipt, [(initial, begin, times[-1] + 0.1, rate, times)]
    )
    assert result["acceptance"] is False
    assert not result["final_tail"]["low_at_least_0_15_seconds"]
