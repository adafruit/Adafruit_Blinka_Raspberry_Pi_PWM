"""Fake capture/SSH lifecycle only; no external session or GPIO is opened."""

import importlib.util
import json
import shlex
import subprocess
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

import pytest


@pytest.fixture
def wrapper(monkeypatch):
    """Import with a stub vendor module; an installed Saleae SDK is unnecessary."""
    vendor = ModuleType("saleae")
    vendor.automation = SimpleNamespace()
    monkeypatch.setitem(sys.modules, "saleae", vendor)
    path = Path(__file__).with_name("capture_hardware_pwm_package.py")
    spec = importlib.util.spec_from_file_location("hardware_capture_fixture", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize("host", ("test2-pi4.local", "test-pi5.local"))
@pytest.mark.parametrize(
    "scenario",
    ["success", "failure", "timeout", "missing_device", "save_failure", "bad_source"],
)
def test_capture_retains_artifacts_and_source_proof(
    tmp_path, monkeypatch, wrapper, host, scenario
):
    bench = wrapper
    events = []
    manifest = {
        "schema_version": 1,
        "package_files": {
            name: "a" * 64 for name in ("__init__.py", "_hardware.py", "_software.py")
        },
        "helper_sha256": bench.digest(
            __file__.replace(
                "test_capture_hardware_pwm_package.py", "hardware_pwm_package_eval.py"
            )
        ),
    }
    manifest_path = tmp_path / "source-manifest.json"
    manifest_path.write_text(json.dumps(manifest))
    args = SimpleNamespace(
        directory=tmp_path / "capture",
        remote_root="/tmp/blinka-hardware-pwm.abc123",
        manifest=manifest_path,
        host=host,
        saleae_channel=bench.CHANNELS[host],
        mode="endpoints",
    )
    proof = {
        "manifest_sha256": bench.digest(manifest_path),
        "helper_sha256": manifest["helper_sha256"],
        "package_files": manifest["package_files"],
    }
    if scenario == "bad_source":
        proof["helper_sha256"] = "b" * 64
    report = {
        "ok": scenario != "failure",
        "mode": args.mode,
        "host": host,
        "sysfs_released": True,
        "source_proof": proof,
    }

    class Capture:
        def __enter__(self):
            events.append("capture")
            return self

        def __exit__(self, *args):
            events.append("closed")

        def stop(self):
            events.append("stop")

        def save_capture(self, path):
            events.append("sal")
            if scenario == "save_failure":
                raise OSError("fake save error")
            from pathlib import Path

            Path(path).write_bytes(b"fake sal")

        def export_raw_data_binary(self, path, *, digital_channels):
            events.append("binary")
            assert digital_channels == [args.saleae_channel]

    class Manager:
        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

        def get_devices(self):
            return (
                []
                if scenario == "missing_device"
                else [SimpleNamespace(device_id=bench.DEVICE_ID, is_simulation=False)]
            )

        def get_app_info(self):
            return SimpleNamespace(app_version="fixture")

        def start_capture(self, *, device_id, device_configuration):
            assert device_id == bench.DEVICE_ID
            assert device_configuration == {
                "enabled_digital_channels": [args.saleae_channel],
                "digital_sample_rate": 100_000_000,
            }
            return Capture()

    def run(command, **kwargs):
        events.append("ssh")
        assert kwargs == {
            "capture_output": True,
            "text": True,
            "check": False,
            "timeout": 20,
        }
        assert command[-2] == f"pi@{host}"
        tokens = shlex.split(command[-1])
        assert tokens == [
            "/usr/bin/python3",
            "-B",
            args.remote_root + "/hardware_pwm_package_eval.py",
            "--source-root",
            args.remote_root,
            "--manifest-sha256",
            bench.digest(manifest_path),
            "--host",
            host,
            "--mode",
            "endpoints",
        ]
        if scenario == "timeout":
            raise subprocess.TimeoutExpired(
                command, 20, output=b"partial output", stderr=b"partial error"
            )
        return subprocess.CompletedProcess(
            command, int(scenario == "failure"), json.dumps(report), "fixture stderr"
        )

    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=lambda **kwargs: Manager()),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )
    monkeypatch.setattr(bench.subprocess, "run", run)
    if scenario == "success":
        result = bench.capture(args)
        assert result["remote"]["ok"]
    else:
        with pytest.raises((RuntimeError, OSError)):
            bench.capture(args)
    metadata = json.loads((args.directory / "results.json").read_text())
    assert metadata["acceptance_analysis_performed"] is False
    assert (args.directory / "remote.stdout").exists()
    assert (args.directory / "remote.stderr").exists()
    if scenario != "missing_device":
        assert events[:5] == ["capture", "ssh", "stop", "sal", "binary"]
    if scenario == "timeout":
        assert metadata["remote_returncode"] == 124
        assert (args.directory / "remote.stdout").read_text() == "partial output"
    if scenario == "failure":
        assert metadata["remote"]["ok"] is False


def test_invalid_host_channel_and_root_refused_before_output(tmp_path, wrapper):
    bench = wrapper
    args = SimpleNamespace(
        directory=tmp_path / "capture",
        remote_root="/tmp/blinka-hardware-pwm.abc123",
        manifest=tmp_path / "missing",
        host="test2-pi4.local",
        saleae_channel=0,
        mode="ordinary",
    )
    with pytest.raises(ValueError, match="Confirm GPIO18"):
        bench.capture(args)
    args.remote_root = "/tmp/blinka-hardware-pwm.abc123/../other"
    with pytest.raises(ValueError, match="private /tmp"):
        bench.capture(args)
    assert not args.directory.exists()
