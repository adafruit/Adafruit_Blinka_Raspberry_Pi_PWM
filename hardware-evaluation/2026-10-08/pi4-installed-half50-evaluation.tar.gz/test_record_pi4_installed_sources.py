"""Offline negative closure/receipt tests; no remote process or GPIO use."""

import ast
import copy
import json

import pytest
import record_pi4_installed_sources as inventory


@pytest.fixture
def installed():
    wheels, _ = inventory.preparation.inputs()
    receipt = json.loads(inventory.preparation.output_path("install").read_text())
    return wheels, copy.deepcopy(receipt["operations"][0]["remote"])


def test_actual_frozen_local_requirements_and_failures(installed):
    wheels, observed = installed
    result = inventory.closure_audit(wheels, observed)
    assert result["whole_environment_clean"] is False
    assert result["pip_check_actual_returncode"] == 1
    assert result["pip_check_stdout_unchanged"] == observed["pip_check"]["stdout"]
    assert len(result["requirements"]) == 56
    assert (
        sum(item["active_for_target_no_extras"] for item in result["requirements"])
        == 26
    )
    assert all(item["satisfied"] for item in result["requirements"])
    assert len(result["pip_check_failure_classification"]) == 17
    assert all(
        item["neither_name_in_tested_closure"]
        for item in result["pip_check_failure_classification"]
    )


@pytest.mark.parametrize(
    "change",
    [
        "outdated",
        "missing",
        "implicated",
        "unknown_failure",
        "list_disagrees",
        "partial",
    ],
)
def test_closure_never_accepts_missing_or_ambiguous_evidence(installed, change):
    wheels, observed = installed
    if change == "outdated":
        observed["private_versions_after"]["adafruit-platformdetect"] = "1.0"
    elif change == "missing":
        del observed["private_versions_after"]["pyserial"]
    elif change == "implicated":
        lines = observed["pip_check"]["stdout"].splitlines()
        lines[0] = (
            "adafruit-blinka 9.0.5.dev74+pwmeval.beb49bf requires debconf, which is not installed."
        )
        observed["pip_check"]["stdout"] = "\n".join(lines) + "\n"
    elif change == "unknown_failure":
        observed["pip_check"]["stdout"] += "unrecognized failure\n"
    elif change == "list_disagrees":
        values = json.loads(observed["pip_list"]["stdout"])
        values.append({"name": "debconf", "version": "1.0"})
        observed["pip_list"]["stdout"] = json.dumps(values)
    else:
        observed["pip_check"]["stdout"] = (
            "\n".join(observed["pip_check"]["stdout"].splitlines()[:-1]) + "\n"
        )
    with pytest.raises(ValueError):
        inventory.closure_audit(wheels, observed)


def test_remote_source_is_standard_library_only_and_read_only():
    source = inventory.remote_code()
    tree = ast.parse(source)
    imports = [
        alias.name
        for node in ast.walk(tree)
        if isinstance(node, ast.Import)
        for alias in node.names
    ]
    assert set(imports) <= {
        "hashlib",
        "importlib.metadata",
        "json",
        "os",
        "pathlib",
        "platform",
        "re",
        "stat",
        "subprocess",
        "sys",
    }
    assert "sys.flags.no_site" in source
    assert "gpiodetect" in source and "pinctrl" in source
    assert "sudo" not in [
        value.value
        for value in ast.walk(tree)
        if isinstance(value, ast.Constant) and isinstance(value.value, str)
    ]
    assert not any(
        isinstance(node, ast.Attribute)
        and node.attr
        in {
            "write_bytes",
            "write_text",
            "mkdir",
            "unlink",
            "request_lines",
            "GPIO",
            "PWMOut",
        }
        for node in ast.walk(tree)
    )
    assert "helper_not_deployed_or_imported" in source
