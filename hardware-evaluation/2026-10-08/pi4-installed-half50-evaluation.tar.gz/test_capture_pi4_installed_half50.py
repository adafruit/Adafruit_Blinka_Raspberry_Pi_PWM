"""Recording-only Pi4 acquisition and synthetic raw-export tests.

No SSH, GPIO, real Saleae connection, sleeps or backend imports are performed.
Complete helper-contract receipts are synthetic, not physical provenance.
"""

import copy
import hashlib
import json
import shlex
import struct
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

import capture_pi4_installed_half50 as bench

ROOT = "/tmp/blinka-pwm-pi4-real-pin.abcd1234"


def put_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


@pytest.fixture(autouse=True)
def refuse_live_calls(monkeypatch):
    def forbidden(*_args, **_kwargs):
        raise AssertionError("A real acquisition/process/sleep is forbidden")

    monkeypatch.setattr(bench.subprocess, "run", forbidden)
    monkeypatch.setattr(bench.automation.Manager, "connect", forbidden)
    monkeypatch.setattr(bench.time, "sleep", forbidden)


@pytest.fixture
def inputs(tmp_path):
    return make_inputs(tmp_path)


def make_inputs(tmp_path):
    manifest = {
        "schema_version": 1,
        "remote_root": ROOT,
        "model": "Raspberry Pi 4 Model B Rev 1.4",
        "kernel": "6.18.50+rpt-rpi-v8",
        "python_version": "3.13.5",
        "boot_id": "5d3cf2af-f7f0-4199-a1d1-25958db13921",
        "controller": {
            "path": "/dev/gpiochip0",
            "name": "gpiochip0",
            "label": "pinctrl-bcm2711",
            "num_lines": 58,
            "device_number": "254:0",
            "of_node": "/sys/firmware/devicetree/base/soc/gpio@7e200000",
        },
        "distribution_versions": dict(bench.helper.KNOWN_VERSIONS),
        "boot_config_sha256": {
            "/boot/firmware/config.txt": "a" * 64,
            "/boot/config.txt": "b" * 64,
        },
        "sibling_pinctrl_stdout": "23: ip    pd | lo // GPIO23 = input\n",
        "source_paths": {
            key: (
                ROOT + "/" + key
                if key == bench.HELPER
                else "/usr/lib/python3/dist-packages/" + key
                if key.startswith("RPi/")
                else ROOT + "/venv/lib/python3.13/site-packages/" + key
            )
            for key in bench.helper.REQUIRED_SOURCES
        },
        "source_sha256": {key: "c" * 64 for key in bench.helper.REQUIRED_SOURCES},
    }
    manifest["source_sha256"][bench.HELPER] = bench.method_hashes()[bench.HELPER]
    manifest_path = tmp_path / "manifest.json"
    preflight_path = tmp_path / "preflight.json"
    receipt = {"accepted": True, "ssh_returncode": 0}
    put_json(manifest_path, manifest)
    put_json(preflight_path, receipt)
    plan = {
        "schema_version": 1,
        "capture_order": [name for name, _backend in bench.RUNS],
        "capture_backends": dict(bench.RUNS),
        "remote_root": ROOT,
        "remote_python": ROOT + "/venv/bin/python",
        "host": "test2-pi4.local",
        "manifest_sha256": bench.digest(manifest_path),
        "method_sha256": bench.method_hashes(),
        "outputs": [
            {"gpio": 18, "saleae_channel": 2},
            {"gpio": 23, "saleae_channel": 3},
        ],
        "frequency": 50,
        "duty_cycle": 32768,
        "hold_seconds": 3.0,
        "runtime_flags": {"short_slice": False, "shared": False},
        "preflight_receipt_path": str(preflight_path),
        "preflight_receipt_sha256": bench.digest(preflight_path),
    }
    plan_path = tmp_path / "plan.json"
    put_json(plan_path, plan)
    return SimpleNamespace(
        plan=plan,
        manifest=manifest,
        preflight=receipt,
        plan_path=plan_path,
        manifest_path=manifest_path,
        preflight_path=preflight_path,
        output=tmp_path / bench.RUNS[0][0],
    )


def helper_receipt(inputs, backend=None):
    backend = dict(bench.RUNS)[inputs.output.name] if backend is None else backend
    manifest = inputs.manifest
    result = {
        "schema_version": 1,
        "mode": bench.helper.MODE,
        "sequence_marker": bench.helper.SEQUENCE_MARKER,
        "backend": backend,
        "pid": 12345,
        "begin_ns": 1_000_000_000,
        "success": True,
        "inspect_only": False,
        "guarded_import_only_no_gpio_construction": False,
        "primary_error": None,
        "cleanup_errors": [],
        "waveform_accepted": None,
        "parity_pass": None,
        "manifest_sha256": bench.digest(inputs.manifest_path),
        "source_paths": manifest["source_paths"],
        "source_sha256": manifest["source_sha256"],
        "distribution_versions": manifest["distribution_versions"],
        "distribution_metadata_roots": {
            name: "/usr/lib/python3/dist-packages"
            if name == "RPi.GPIO"
            else ROOT + "/venv/lib/python3.13/site-packages"
            for name in manifest["distribution_versions"]
        },
        "python_executable": ROOT + "/venv/bin/python",
        "isolated_python": True,
        "noninteractive_no_runtime_installs": True,
        "inherited_environment": {},
        "runtime_flags": {"short_slice": False, "shared": False},
        "gpio_hooks_restored": True,
        "native_request_hook_restored": True,
        "bounded_python_run_confirmed": True,
        "installed_dispatch": {
            "real_board_used": True,
            "real_pwmio_used": True,
            "virtual_pwmio_export_used": False,
            "native_pwmio_identity_verified": True,
            "unwrapped_public_pwm_objects": True,
            "original_reference": bench.helper.ORIGINAL_MODULE + ".PWMOut",
            "board_id": "RASPBERRY_PI_4B",
            "chip_id": "BCM2XXX",
            "pin_class_module": bench.helper.PIN_MODULE,
            "target_pin_attribute": "D18",
            "target_pin_id": 18,
            "inactive_context_pin_id": 23,
            "missing_platform_dependencies": ["rpi_ws281x>=4.0.0"],
            "missing_neopixel_dependency_not_imported_or_installed": True,
        },
        "platform_preflight": {
            **{
                k: manifest[k]
                for k in (
                    "model",
                    "kernel",
                    "python_version",
                    "boot_id",
                    "boot_config_sha256",
                )
            },
            "temperature_millic": 35000,
            "registered_pwm_providers": [],
            "throttled": {
                "arguments": ["vcgencmd", "get_throttled"],
                "returncode": 0,
                "stdout": "throttled=0x0\n",
                "stderr": "",
            },
            "live_pwm_nodes": [
                {
                    "of_node": "/sys/firmware/devicetree/base/soc/pwm@" + address,
                    "status": "disabled",
                }
                for address in ("7e20c800", "7e20c000")
            ],
        },
        "events": [],
        "gpio_calls": [],
        "phases": [],
    }
    free = {
        "chip": {k: manifest["controller"][k] for k in ("name", "label", "num_lines")},
        "lines": [
            {
                "offset": gpio,
                "name": f"GPIO{gpio}",
                "used": False,
                "consumer": None,
                "direction": "INPUT",
            }
            for gpio in (18, 23)
        ],
        "read_only_chip_closed": True,
        "rpi_gpio_mmap_exclusivity_not_proved": True,
    }
    for name in (
        "free_lines_preimport",
        "free_lines_postimport",
        "free_lines_after_public_and_lab_cleanup",
    ):
        result[name] = copy.deepcopy(free)
    boundaries = (
        "platform_preflight",
        "postimport",
        "initial_low",
        "commanded_low",
        "release",
        "quiet_release_end",
    )
    result["boundary_low_confirmations"] = dict.fromkeys(boundaries, True)
    result["pin_boundaries"] = [
        {
            "boundary": name,
            "queries": [
                {
                    "arguments": ["pinctrl", "get", str(gpio)],
                    "returncode": 0,
                    "stderr": "",
                    "stdout": "18: ip    pd | lo // GPIO18 = input\n"
                    if gpio == 18
                    else manifest["sibling_pinctrl_stdout"],
                }
                for gpio in (18, 23)
            ],
        }
        for name in boundaries
    ]
    clock = 1_300_000_000
    for name, duty, duration in bench.helper.SEQUENCE[:3]:
        wait_begin = clock + 2_000_000
        wait_end = wait_begin + int(duration * 1_000_000_000)
        phase = {
            "name": name,
            "duty_u16": duty,
            "duration_seconds": duration,
            "begin_ns": clock,
            "end_ns": wait_end + 2_000_000,
            "api_readback": {"frequency": 50, "duty_u16": duty, "pin_id": 18},
            "api_readback_ns": clock + 1_000_000,
            "wait_begin_ns": wait_begin,
            "wait_end_ns": wait_end,
        }
        if duty == 0:
            phase["settled_low_confirmation_ns"] = wait_end + 1_000_000
        result["phases"].append(phase)
        clock = phase["end_ns"] + 10_000_000
    ctor = {
        "operation": "PWMOut.__init__",
        "scope": backend + ":constructor",
        "status": "ok",
        "begin_ns": 1_100_000_000,
        "end_ns": 1_200_000_000,
        "arguments": {
            "pin_attribute": "board.D18",
            "pin_id": 18,
            "frequency": 50,
            "duty_u16": 0,
            "variable_frequency": False,
        },
    }
    deinit = {
        "operation": "PWMOut.deinit",
        "scope": backend + ":public_deinit",
        "status": "ok",
        "begin_ns": clock,
        "end_ns": clock + 1_000_000,
        "arguments": None,
    }
    result["events"] = [
        ctor,
        *[
            {
                "operation": "PWMOut.duty_cycle",
                "scope": backend + ":" + phase["name"],
                "status": "ok",
                "begin_ns": phase["begin_ns"],
                "end_ns": phase["begin_ns"] + 500_000,
                "arguments": {"duty_u16": phase["duty_u16"]},
            }
            for phase in result["phases"][1:3]
        ],
        deinit,
    ]
    if backend == "native":

        def native_event(operation, scope, tick, arguments=None):
            return {
                "operation": operation,
                "scope": scope,
                "begin_ns": tick,
                "end_ns": tick + 500_000,
                "status": "ok",
                "arguments": arguments,
            }

        result["events"] = [
            native_event(
                "gpiod.request_lines",
                "native:constructor",
                1_101_000_000,
                {
                    "path": "/dev/gpiochip0",
                    "consumer": "adafruit-blinka-pwm",
                    "offsets": [18],
                },
            ),
            ctor,
            native_event(
                "owned_request.get_value", "native:initial_low", 1_201_000_000
            ),
            *result["events"][1:3],
            native_event(
                "owned_request.set_value(low)",
                "native:lab_owned_low",
                clock - 2_000_000,
            ),
            native_event(
                "owned_request.get_value", "native:lab_owned_read", clock - 1_000_000
            ),
            deinit,
        ]
        result.update(
            native_initial_low_confirmed=True,
            native_private_low_confirmed=True,
            native_request_released=True,
        )
    calls = [
        ("GPIO.setmode", "imports", [11]),
        ("GPIO.setwarnings", "imports", [False]),
    ] * 2
    if backend == "original":
        calls += [
            ("GPIO.setup", "original:constructor", [18, 0]),
            ("GPIO.PWM", "original:constructor", [18, 50]),
            ("GPIO.cleanup", "original:public_deinit", [18]),
        ]
    result["gpio_calls"] = [
        {
            "operation": op,
            "scope": scope,
            "arguments": {"args": args, "kwargs": {}},
            "attempted": True,
            "permitted": True,
            "success": True,
            "begin_ns": 1_010_000_000 + i * 1_000_000,
            "end_ns": 1_010_500_000 + i * 1_000_000,
        }
        for i, (op, scope, args) in enumerate(calls)
    ]
    if backend == "original":
        for index, tick in (
            (4, 1_102_000_000),
            (5, 1_103_000_000),
            (6, deinit["begin_ns"] + 100_000),
        ):
            result["gpio_calls"][index].update(begin_ns=tick, end_ns=tick + 500_000)
    quiet_begin = deinit["end_ns"] + 10_000_000
    result["phases"].append(
        {
            "name": "quiet_release",
            "duty_u16": None,
            "duration_seconds": 0.2,
            "begin_ns": quiet_begin,
            "end_ns": quiet_begin + 200_000_000,
        }
    )
    result["end_ns"] = quiet_begin + 220_000_000
    return result


def validate(fake, output=None):
    return bench.validate_inputs(
        fake.output if output is None else output,
        fake.plan_path,
        fake.manifest_path,
    )


def test_exact_predeclared_plan_source_and_fresh_output(inputs):
    output, plan, manifest, plan_hash, manifest_hash = validate(inputs)
    assert output == inputs.output
    assert plan == inputs.plan and manifest == inputs.manifest
    assert plan_hash == bench.digest(inputs.plan_path)
    assert manifest_hash == bench.digest(inputs.manifest_path)
    assert set(plan["method_sha256"]) == {
        "capture_pi4_installed_half50.py",
        "pi4_installed_pwm_half50_eval.py",
        "capture_pwm.py",
    }
    assert not output.exists()
    for name, backend in bench.RUNS:
        assert (
            validate(inputs, output.parent / name)[1]["capture_backends"][name]
            == backend
        )


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("schema_version", True),
        ("schema_version", "1"),
        ("schema_version", 2),
        ("capture_order", [name for name, _ in reversed(bench.RUNS)]),
        ("capture_backends", {name: "native" for name, _ in bench.RUNS}),
        ("remote_python", "/usr/bin/python3"),
        ("host", "test-pi5.local"),
        ("manifest_sha256", "0" * 64),
        ("method_sha256", {}),
        (
            "outputs",
            [{"gpio": 18, "saleae_channel": 0}, {"gpio": 23, "saleae_channel": 1}],
        ),
        (
            "outputs",
            [{"gpio": 23, "saleae_channel": 2}, {"gpio": 18, "saleae_channel": 3}],
        ),
        ("frequency", 500),
        ("frequency", 50.0),
        ("duty_cycle", 32767),
        ("duty_cycle", 32768.0),
        ("hold_seconds", 3),
        ("hold_seconds", 4.0),
        ("runtime_flags", {"short_slice": True, "shared": False}),
        ("runtime_flags", {"short_slice": False, "shared": True}),
        ("runtime_flags", {"short_slice": 0, "shared": False}),
        ("runtime_flags", {"short_slice": False, "shared": 0}),
    ],
)
def test_plan_contract_rejects_mutations_before_output(inputs, key, value):
    inputs.plan[key] = value
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        validate(inputs)
    assert not inputs.output.exists()


@pytest.mark.parametrize(
    "root",
    [
        "/tmp/blinka-pwm-pi4-real-pin.a",
        "/tmp/blinka-pwm-pi4-real-pin.ABCD1234",
        "/tmp/blinka-pwm-pi4-real-pin.abcd-123",
        "/tmp/blinka-pwm-pi4-real-pin.abcd12345",
        "/tmp/blinka-pwm-pi4-real-pin.abcd1234/child",
        "/tmp/blinka-pwm-native-dual.abcd1234",
        "tmp/blinka-pwm-pi4-real-pin.abcd1234",
        None,
    ],
)
def test_root_matches_exact_helper_scope(inputs, root):
    inputs.plan["remote_root"] = root
    inputs.plan["remote_python"] = str(root) + "/venv/bin/python"
    inputs.manifest["remote_root"] = root
    put_json(inputs.manifest_path, inputs.manifest)
    inputs.plan["manifest_sha256"] = bench.digest(inputs.manifest_path)
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError, match="Fresh Pi4 root"):
        validate(inputs)


@pytest.mark.parametrize("schema", [True, "1", 2, None])
def test_manifest_schema_is_exact_typed_one(inputs, schema):
    inputs.manifest["schema_version"] = schema
    put_json(inputs.manifest_path, inputs.manifest)
    inputs.plan["manifest_sha256"] = bench.digest(inputs.manifest_path)
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        validate(inputs)


def test_manifest_root_and_source_hashes_not_substitutable(inputs):
    inputs.manifest["remote_root"] = ROOT.replace("abcd1234", "fresh567")
    put_json(inputs.manifest_path, inputs.manifest)
    inputs.plan["manifest_sha256"] = bench.digest(inputs.manifest_path)
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        validate(inputs)
    inputs.manifest["remote_root"] = ROOT
    put_json(inputs.manifest_path, inputs.manifest)
    inputs.plan["manifest_sha256"] = bench.digest(inputs.manifest_path)
    inputs.plan["method_sha256"][bench.HELPER] = "0" * 64
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        validate(inputs)


@pytest.mark.parametrize(
    ("accepted", "actual"),
    [
        (False, 0),
        (1, 0),
        (None, 0),
        (True, False),
        (True, 0.0),
        (True, "0"),
        (True, None),
        (True, 1),
    ],
)
def test_preflight_requires_true_and_actual_typed_exit_zero(inputs, accepted, actual):
    put_json(inputs.preflight_path, {"accepted": accepted, "ssh_returncode": actual})
    inputs.plan["preflight_receipt_sha256"] = bench.digest(inputs.preflight_path)
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError, match="Actual successful preflight"):
        validate(inputs)
    assert not inputs.output.exists()


def test_changed_or_missing_preflight_is_refused(inputs):
    inputs.preflight_path.write_text(inputs.preflight_path.read_text() + "\n")
    with pytest.raises(ValueError, match="Unchanged successful preflight"):
        validate(inputs)
    inputs.plan["preflight_receipt_path"] = str(
        inputs.preflight_path.parent / "absent.json"
    )
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError, match="Regular canonical file"):
        validate(inputs)


@pytest.mark.parametrize("which", ["plan", "manifest", "preflight"])
def test_duplicate_json_keys_are_refused(inputs, which):
    path = getattr(inputs, which + "_path")
    key = "ssh_returncode" if which == "preflight" else "schema_version"
    original = path.read_text()
    path.write_text(original.replace("{", '{"' + key + '":0,', 1))
    if which == "manifest":
        inputs.plan["manifest_sha256"] = bench.digest(path)
        put_json(inputs.plan_path, inputs.plan)
    elif which == "preflight":
        inputs.plan["preflight_receipt_sha256"] = bench.digest(path)
        put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError, match="Duplicate JSON key"):
        validate(inputs)


@pytest.mark.parametrize("existing_kind", ["directory", "file", "symlink"])
def test_existing_output_is_untouched(inputs, existing_kind):
    if existing_kind == "directory":
        inputs.output.mkdir()
        (inputs.output / "foreign.txt").write_bytes(b"foreign evidence")
    elif existing_kind == "file":
        inputs.output.write_bytes(b"foreign evidence")
    else:
        target = inputs.output.parent / "foreign"
        target.mkdir()
        (target / "foreign.txt").write_bytes(b"foreign evidence")
        inputs.output.symlink_to(target, target_is_directory=True)
    with pytest.raises(ValueError):
        validate(inputs)
    evidence = (
        inputs.output if existing_kind == "file" else inputs.output / "foreign.txt"
    )
    assert evidence.read_bytes() == b"foreign evidence"


def test_symlink_parent_and_unapproved_capture_label_refused(inputs):
    target = inputs.output.parent / "target"
    target.mkdir()
    link = inputs.output.parent / "linked"
    link.symlink_to(target, target_is_directory=True)
    with pytest.raises(ValueError, match="traverse links"):
        validate(inputs, link / inputs.output.name)
    with pytest.raises(ValueError, match="predeclared"):
        validate(inputs, inputs.output.parent / "unapproved-capture")


def test_digest_and_write_new_keep_exclusive_regular_file_scope(tmp_path):
    path = tmp_path / "data.json"
    bench.write_new(path, {"preserved": True})
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        bench.write_new(path, {"overwritten": True})
    assert path.read_bytes() == before
    assert bench.digest(path) == hashlib.sha256(before).hexdigest()
    link = tmp_path / "alias.json"
    link.symlink_to(path)
    with pytest.raises(ValueError, match="Regular canonical file"):
        bench.digest(link)


def binary(path, chunks, version=0):
    content = struct.pack("<8sii", b"<SALEAE>", version, 0)
    if version:
        content += struct.pack("<Q", len(chunks))
    else:
        assert len(chunks) == 1
    for initial, begin, end, times in chunks:
        content += struct.pack("<I", initial)
        if version:
            content += struct.pack("<d", 100_000_000.0)
        content += struct.pack("<ddQ", begin, end, len(times))
        content += struct.pack("<" + "d" * len(times), *times)
    path.write_bytes(content)


def test_reconstruct_retains_every_uneven_interval_and_outlier(tmp_path):
    path = tmp_path / "digital_2.bin"
    times = [0.1, 0.11, 0.12, 0.131, 0.14, 0.170886, 0.18, 0.180001]
    binary(path, [(0, 0.0, 0.5, times)])
    report = bench.reconstruct(path, 10000.0)
    row = report["chunks"][0]
    assert report["no_interval_trimming_or_filtering"]
    assert report["raw_sha256"] == bench.digest(path)
    assert row["edges_s"] == times
    assert row["complete_high_intervals_s"] == [
        [times[i], times[i + 1]] for i in (0, 2, 4, 6)
    ]
    assert row["complete_low_intervals_s"] == [
        [times[i], times[i + 1]] for i in (1, 3, 5)
    ]
    assert row["highs_us"] == pytest.approx([10000, 11000, 30886, 1])
    assert row["lows_us"] == pytest.approx([10000, 9000, 9114])
    assert row["rise_periods_us"] == pytest.approx([20000, 20000, 40000])
    assert row["high_summary_us"]["count"] == 4
    assert row["high_summary_us"]["min"] == pytest.approx(1)
    assert row["high_summary_us"]["max"] == pytest.approx(30886)
    assert row["absolute_high_error_summary_us"]["max"] == pytest.approx(20886)
    assert row["quiet_low_tail_seconds"] == pytest.approx(0.319999)


@pytest.mark.parametrize(
    ("initial", "times", "highs", "lows", "final"),
    [
        (1, [0.1, 0.2, 0.35, 0.55], [[0.2, 0.35]], [[0.1, 0.2], [0.35, 0.55]], 1),
        (0, [0.1, 0.3, 0.4], [[0.1, 0.3]], [[0.3, 0.4]], 1),
        (1, [0.1], [], [], 0),
        (0, [], [], [], 0),
        (1, [], [], [], 1),
    ],
)
def test_boundary_fragments_are_not_invented_complete_pulses(
    tmp_path, initial, times, highs, lows, final
):
    path = tmp_path / "edges.bin"
    binary(path, [(initial, 0.0, 1.0, times)])
    row = bench.reconstruct(path, 10000.0)["chunks"][0]
    assert row["initial_level"] == initial and row["final_level"] == final
    assert row["edges_s"] == times
    assert row["complete_high_intervals_s"] == highs
    assert row["complete_low_intervals_s"] == lows
    assert row["initial_boundary"] == {
        "level": initial,
        "begin_s": 0.0,
        "end_s": times[0] if times else 1.0,
    }
    assert row["final_boundary"] == {
        "level": final,
        "begin_s": times[-1] if times else 0.0,
        "end_s": 1.0,
    }
    assert row["quiet_low_tail_seconds"] == (
        1.0 - (times[-1] if times else 0.0) if final == 0 else None
    )


def analysis_fixture(tmp_path, name, chunks, peer=None, version=0):
    inputs = make_inputs(tmp_path)
    directory = tmp_path / name
    directory.mkdir()
    binary(directory / "digital_2.bin", chunks, version)
    binary(
        directory / "digital_3.bin",
        [(0, 0.0, 1.0, [])] if peer is None else peer,
        version,
    )
    backend = dict(bench.RUNS)[name]
    for label, path in (
        ("plan.json", inputs.plan_path),
        ("manifest.json", inputs.manifest_path),
    ):
        (directory / label).write_bytes(path.read_bytes())
    (directory / "waveform.sal").write_bytes(b"recording-only SAL")
    put_json(directory / "remote.stdout", helper_receipt(inputs, backend))
    (directory / "remote.stderr").write_bytes(b"preserved informational fixture stderr")
    acquisition = {
        "schema_version": 1,
        "physical_device_id": bench.DEVICE_ID,
        "logic_version": "fake Logic2",
        "requested_sample_rate_hz": 100_000_000,
        "enabled_digital_channels": [2, 3],
        "glitch_filters": [],
        "lead_seconds": 0.5,
        "tail_seconds": 0.2,
        "actual_ssh_returncode": 0,
        "primary_error": None,
        "evidence_errors": [],
        "command": [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test2-pi4.local",
            shlex.join(
                [
                    ROOT + "/venv/bin/python",
                    "-I",
                    ROOT + "/" + bench.HELPER,
                    "--manifest",
                    ROOT + "/manifest.json",
                    "--backend",
                    backend,
                ]
            ),
        ],
        "helper_receipt_validated": True,
        "artifact_provenance": bench.artifact_provenance(
            directory,
            (
                "waveform.sal",
                "digital_2.bin",
                "digital_3.bin",
                "remote.stdout",
                "remote.stderr",
            ),
        ),
    }
    put_json(directory / "acquisition.json", acquisition)
    put_json(
        directory / "results.json",
        {
            "schema_version": 1,
            "capture": name,
            "backend": backend,
            "collection_success": True,
            "plan_sha256": bench.digest(directory / "plan.json"),
            "manifest_sha256": bench.digest(directory / "manifest.json"),
            "preflight_receipt_sha256": inputs.plan["preflight_receipt_sha256"],
            "method_sha256": bench.method_hashes(),
            "acquisition": acquisition,
            "remote": bench.read_json(directory / "remote.stdout"),
            "parity_pass": None,
            "waveform_accepted": None,
        },
    )
    return directory


@pytest.mark.parametrize("name", [bench.RUNS[0][0], bench.RUNS[1][0]])
def test_descriptive_analysis_low_peer_and_backend_specific_target(tmp_path, name):
    directory = analysis_fixture(
        tmp_path, name, [(0, 0.0, 1.0, [0.1, 0.11, 0.12, 0.131])]
    )
    report = bench.analyze(directory)
    assert report["single_train_with_untouched_low_peer_supported"]
    assert report["channels"]["3"]["chunks"][0]["edges_s"] == []
    assert report["channels"]["3"]["chunks"][0]["high_summary_us"] == {"count": 0}
    assert report["parity_pass"] is None
    assert report["electrical_and_pi_clocks_aligned"] is False
    assert report["target_high_us"] == (
        10000.0 if dict(bench.RUNS)[name] == "original" else 10000.153
    )


@pytest.mark.parametrize("peer", [[(1, 0.0, 1.0, [])], [(0, 0.0, 1.0, [0.2, 0.21])]])
def test_active_or_initially_high_peer_withholds_single_train_scope(tmp_path, peer):
    directory = analysis_fixture(
        tmp_path, bench.RUNS[0][0], [(0, 0.0, 1.0, [0.1, 0.11])], peer
    )
    report = bench.analyze(directory)
    assert not report["single_train_with_untouched_low_peer_supported"]
    assert report["channels"]["3"]["chunks"][0]["edges_s"] == peer[0][3]


@pytest.mark.parametrize(
    "chunks",
    [
        [(0, 0.0, 1.0, [])],
        [(1, 0.0, 1.0, [0.1, 0.2, 0.21])],
        [(0, 0.0, 1.0, [0.1, 0.11, 0.12])],
        [(0, 0.0, 0.2, [0.1, 0.11])],
    ],
)
def test_main_boundaries_no_pulses_or_short_tail_withhold_scope(tmp_path, chunks):
    directory = analysis_fixture(tmp_path, bench.RUNS[0][0], chunks)
    assert not bench.analyze(directory)[
        "single_train_with_untouched_low_peer_supported"
    ]


def test_multiple_gapped_chunks_keep_all_edges_without_cross_gap_intervals(tmp_path):
    chunks = [
        (0, 0.0, 0.5, [0.1, 0.11, 0.12, 0.131]),
        (1, 2.0, 3.0, [2.1, 2.2, 2.21, 2.3, 2.300001]),
    ]
    peer = [(0, 0.0, 0.5, []), (0, 2.0, 3.0, [])]
    directory = analysis_fixture(tmp_path, bench.RUNS[0][0], chunks, peer, version=1)
    report = bench.analyze(directory)
    assert not report["single_train_with_untouched_low_peer_supported"]
    raw = report["channels"]["2"]
    assert raw["binary_format_version"] == 1
    assert [row["edges_s"] for row in raw["chunks"]] == [chunks[0][3], chunks[1][3]]
    assert raw["chunks"][0]["rise_periods_us"] == pytest.approx([20000])
    assert raw["chunks"][1]["rise_periods_us"] == pytest.approx([100000])
    assert raw["chunks"][1]["highs_us"] == pytest.approx([10000, 1])
    assert all(row["sample_rate_in_export"] == 100_000_000.0 for row in raw["chunks"])
    assert report["parity_pass"] is None


def recording(
    monkeypatch,
    inputs,
    scenario="success",
    failures=(),
    receipt_override=None,
    artifact_fault=None,
):
    events = []
    receipt = helper_receipt(inputs) if receipt_override is None else receipt_override
    capture = MagicMock()
    capture.__enter__.return_value = capture

    def operation(name, body):
        def called(*args, **kwargs):
            events.append(name)
            if name in failures:
                raise OSError(name + " failed")
            return body(*args, **kwargs)

        return called

    capture.stop.side_effect = operation("stop", lambda: None)

    def saved(path, data):
        path = Path(path)
        if artifact_fault is not None and path.name == artifact_fault[0]:
            if artifact_fault[1] == "missing":
                return
            if artifact_fault[1] == "directory":
                path.mkdir()
                return
            if artifact_fault[1] == "symlink":
                target = path.with_name("foreign-artifact")
                target.write_bytes(b"foreign")
                path.symlink_to(target)
                return
            data = b""
        path.write_bytes(data)

    capture.save_capture.side_effect = operation(
        "save", lambda path: saved(path, b"recording-only SAL")
    )

    def export(path, **kwargs):
        assert kwargs == {"digital_channels": [2, 3]}
        for channel in (2, 3):
            saved(Path(path) / f"digital_{channel}.bin", b"recording-only raw")

    capture.export_raw_data_binary.side_effect = operation("export", export)
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake Logic2")
    manager.start_capture.return_value = capture
    if scenario == "connection":
        connect = MagicMock(side_effect=OSError("connection failed"))
    else:
        connect = MagicMock(return_value=manager)
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connect),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test2-pi4.local",
        ]
        assert shlex.split(command[-1]) == [
            ROOT + "/venv/bin/python",
            "-I",
            ROOT + "/" + bench.HELPER,
            "--manifest",
            ROOT + "/manifest.json",
            "--backend",
            dict(bench.RUNS)[inputs.output.name],
        ]
        assert set(kwargs) == {"stdin", "stdout", "stderr", "timeout", "check"}
        assert (
            kwargs["stdin"] == subprocess.DEVNULL
            and kwargs["timeout"] == 25
            and kwargs["check"] is False
        )
        kwargs["stderr"].write("retained stderr bytes\n")
        if scenario in ("timeout", "interrupt", "process_error"):
            kwargs["stdout"].write("partial stdout\n")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 25)
            if scenario == "interrupt":
                raise KeyboardInterrupt("recording interrupted")
            raise OSError("runner failed")
        content = json.dumps({**receipt, "success": scenario != "helper_failure"})
        if scenario == "duplicate_helper":
            content = content.replace("{", '{"success":true,', 1)
        kwargs["stdout"].write("not JSON\n" if scenario == "malformed" else content)
        actual = {"bool_exit": False, "string_exit": "0", "nonzero_exit": 7}.get(
            scenario, 0
        )
        return subprocess.CompletedProcess(command, actual)

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)

    def sleep(duration):
        events.append(("sleep", duration))
        if "tail" in failures and duration == 0.2:
            raise OSError("tail failed")

    monkeypatch.setattr(bench.time, "sleep", sleep)
    return SimpleNamespace(
        events=events, manager=manager, capture=capture, runner=runner, connect=connect
    )


def collected(inputs):
    return bench.collect(inputs.output, inputs.plan_path, inputs.manifest_path)


def test_recording_capture_exact_config_command_cleanup_and_retained_bytes(
    monkeypatch, inputs
):
    fake = recording(monkeypatch, inputs)
    assert collected(inputs) == 0
    assert fake.events == [
        ("sleep", 0.5),
        "ssh",
        ("sleep", 0.2),
        "stop",
        "save",
        "export",
    ]
    fake.connect.assert_called_once_with(port=10430, connect_timeout_seconds=5)
    fake.manager.start_capture.assert_called_once_with(
        device_id=bench.DEVICE_ID,
        device_configuration={
            "enabled_digital_channels": [2, 3],
            "digital_sample_rate": 100_000_000,
            "glitch_filters": [],
        },
    )
    result = json.loads((inputs.output / "results.json").read_text())
    acquisition = json.loads((inputs.output / "acquisition.json").read_text())
    assert result["collection_success"] and result["parity_pass"] is None
    assert result["acquisition"] == acquisition
    assert (
        acquisition["actual_ssh_returncode"] == 0
        and type(acquisition["actual_ssh_returncode"]) is int
    )
    assert acquisition["primary_error"] is None and acquisition["evidence_errors"] == []
    assert (inputs.output / "remote.stderr").read_bytes() == b"retained stderr bytes\n"
    assert (inputs.output / "plan.json").read_bytes() == inputs.plan_path.read_bytes()
    assert (
        inputs.output / "manifest.json"
    ).read_bytes() == inputs.manifest_path.read_bytes()
    assert (inputs.output / "waveform.sal").read_bytes() == b"recording-only SAL"
    assert [(inputs.output / f"digital_{c}.bin").read_bytes() for c in (2, 3)] == [
        b"recording-only raw"
    ] * 2
    fake.capture.__exit__.assert_called_once()
    fake.manager.__exit__.assert_called_once()


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "process_error",
        "bool_exit",
        "string_exit",
        "nonzero_exit",
        "malformed",
        "helper_failure",
    ],
)
def test_recording_failures_preserve_actual_exit_or_none_and_drain(
    monkeypatch, inputs, scenario
):
    fake = recording(monkeypatch, inputs, scenario)
    with pytest.raises(ValueError, match="all available evidence preserved"):
        collected(inputs)
    assert fake.events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
    result = json.loads((inputs.output / "results.json").read_text())
    acquisition = result["acquisition"]
    expected = (
        7
        if scenario == "nonzero_exit"
        else None
        if scenario
        in ("timeout", "interrupt", "process_error", "bool_exit", "string_exit")
        else 0
    )
    assert acquisition["actual_ssh_returncode"] == expected
    assert not result["collection_success"] and result["parity_pass"] is None
    assert (inputs.output / "remote.stderr").read_bytes() == b"retained stderr bytes\n"
    if scenario in ("timeout", "interrupt", "process_error"):
        assert (inputs.output / "remote.stdout").read_bytes() == b"partial stdout\n"
        assert acquisition["primary_error"] is not None
    assert (inputs.output / "waveform.sal").exists()
    assert all((inputs.output / f"digital_{c}.bin").exists() for c in (2, 3))
    fake.capture.__exit__.assert_called_once()
    fake.manager.__exit__.assert_called_once()


@pytest.mark.parametrize(
    "failures",
    [("tail",), ("stop",), ("save",), ("export",), ("tail", "stop", "save", "export")],
)
def test_each_cleanup_attempt_runs_in_order_after_prior_failure(
    monkeypatch, inputs, failures
):
    fake = recording(monkeypatch, inputs, failures=failures)
    with pytest.raises(ValueError):
        collected(inputs)
    assert fake.events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
    result = json.loads((inputs.output / "results.json").read_text())
    assert result["acquisition"]["actual_ssh_returncode"] == 0
    assert [
        e["operation"]
        for e in result["acquisition"]["evidence_errors"]
        if not e["operation"].startswith("saved_file:")
    ] == list(failures)
    assert not result["collection_success"]


def test_primary_timeout_is_not_replaced_by_save_export_failures(monkeypatch, inputs):
    fake = recording(monkeypatch, inputs, "timeout", failures=("save", "export"))
    with pytest.raises(ValueError):
        collected(inputs)
    result = json.loads((inputs.output / "results.json").read_text())
    assert result["acquisition"]["actual_ssh_returncode"] is None
    assert result["acquisition"]["primary_error"].startswith("TimeoutExpired:")
    assert [
        e["operation"]
        for e in result["acquisition"]["evidence_errors"]
        if not e["operation"].startswith("saved_file:")
    ] == [
        "save",
        "export",
        "parse_helper",
    ]
    assert fake.events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
    assert (inputs.output / "remote.stdout").read_bytes() == b"partial stdout\n"
    assert (inputs.output / "remote.stderr").read_bytes() == b"retained stderr bytes\n"


@pytest.mark.parametrize("scenario", ["simulation", "connection"])
def test_physical_device_and_connection_failure_never_launch_ssh(
    monkeypatch, inputs, scenario
):
    fake = recording(monkeypatch, inputs, scenario)
    with pytest.raises(ValueError):
        collected(inputs)
    fake.runner.assert_not_called()
    fake.manager.start_capture.assert_not_called()
    result = json.loads((inputs.output / "results.json").read_text())
    assert result["acquisition"]["actual_ssh_returncode"] is None
    assert result["acquisition"]["primary_error"] is not None
    assert (inputs.output / "remote.stdout").read_bytes() == b""
    assert (inputs.output / "remote.stderr").read_bytes() == b""


def test_collection_bad_gate_never_connects_or_creates_outputs(monkeypatch, inputs):
    fake = recording(monkeypatch, inputs)
    inputs.plan["host"] = "foreign.local"
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        collected(inputs)
    fake.connect.assert_not_called()
    fake.runner.assert_not_called()
    assert not inputs.output.exists()


def test_analysis_new_output_is_exclusive_and_plain_filename(monkeypatch, tmp_path):
    directory = analysis_fixture(
        tmp_path, bench.RUNS[0][0], [(0, 0.0, 1.0, [0.1, 0.11])]
    )
    assert bench.main(["analyze", str(directory)]) == 0
    path = directory / "half50-analysis.json"
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        bench.main(["analyze", str(directory)])
    assert path.read_bytes() == before
    for name in ("../foreign.json", "/tmp/foreign.json", ".", ".."):
        with pytest.raises(ValueError, match="plain output filename"):
            bench.main(["analyze", str(directory), "--output-name", name])


@pytest.mark.parametrize(
    "field,value",
    [
        ("source_sha256", {}),
        ("distribution_versions", {}),
        ("backend", "native"),
        ("sequence_marker", "other"),
        ("inspect_only", True),
        ("gpio_hooks_restored", 1),
        ("manifest_sha256", "0" * 64),
        ("phases", []),
        ("events", []),
        ("boundary_low_confirmations", {}),
        ("free_lines_after_public_and_lab_cleanup", {}),
    ],
)
def test_success_true_cannot_bypass_actual_helper_contract(
    monkeypatch, inputs, field, value
):
    remote = helper_receipt(inputs)
    remote[field] = value
    recording(monkeypatch, inputs, receipt_override=remote)
    with pytest.raises(ValueError, match="all available evidence preserved"):
        collected(inputs)
    result = bench.read_json(inputs.output / "results.json")
    assert result["acquisition"]["actual_ssh_returncode"] == 0
    assert not result["collection_success"] and result["remote"] == remote
    assert any(
        row["operation"] == "validate_helper"
        for row in result["acquisition"]["evidence_errors"]
    )


def test_native_release_proof_and_settle_timing_fail_closed(inputs):
    native = helper_receipt(inputs, "native")
    for field in (
        "native_initial_low_confirmed",
        "native_private_low_confirmed",
        "native_request_released",
    ):
        changed = copy.deepcopy(native)
        changed[field] = 1
        with pytest.raises(ValueError, match="Private native"):
            bench.validate_remote(
                changed, inputs.manifest, bench.digest(inputs.manifest_path), "native"
            )
    native["phases"][2]["settled_low_confirmation_ns"] = native["phases"][2][
        "wait_begin_ns"
    ]
    with pytest.raises(ValueError, match="follow settle"):
        bench.validate_remote(
            native, inputs.manifest, bench.digest(inputs.manifest_path), "native"
        )


def test_fresh_retry_labels_preserve_first_failed_capture():
    assert bench.RUNS == (
        ("oct8-pi4-installed-half50-original-r1c", "original"),
        ("oct8-pi4-installed-half50-native-r1c", "native"),
        ("oct8-pi4-installed-half50-native-r2c", "native"),
        ("oct8-pi4-installed-half50-original-r2c", "original"),
    )


@pytest.mark.parametrize("backend", ["original", "native"])
def test_helper_receipt_accepts_observed_output_low(inputs, backend):
    remote = helper_receipt(inputs, backend)
    remote["pin_boundaries"][2]["queries"][0]["stdout"] = (
        "18: op -- pn | lo // GPIO18 = output\n"
    )
    bench.validate_remote(
        remote, inputs.manifest, bench.digest(inputs.manifest_path), backend
    )


@pytest.mark.parametrize(
    "value",
    [
        "18: ip    pd | hi // GPIO18 = input\n",
        "18: a2    pd | lo // GPIO18 = PWM0\n",
        "18: op -- pn | hi // GPIO18 = output\n",
        "18: ip    pd | lo // GPIO18 = output\n",
        "18: op -- pn | lo // GPIO18 = input\n",
    ],
)
def test_helper_receipt_rejects_high_alt_or_mismatched_mode(inputs, value):
    remote = helper_receipt(inputs)
    remote["pin_boundaries"][2]["queries"][0]["stdout"] = value
    with pytest.raises(ValueError, match="Actual LOW"):
        bench.validate_remote(
            remote, inputs.manifest, bench.digest(inputs.manifest_path), "original"
        )


@pytest.mark.parametrize("name", ["waveform.sal", "digital_2.bin", "digital_3.bin"])
@pytest.mark.parametrize("kind", ["missing", "empty", "directory", "symlink"])
def test_sdk_success_without_nonempty_regular_saved_artifacts_is_not_collection_success(
    monkeypatch, inputs, name, kind
):
    fake = recording(monkeypatch, inputs, artifact_fault=(name, kind))
    with pytest.raises(ValueError, match="all available evidence preserved"):
        collected(inputs)
    result = bench.read_json(inputs.output / "results.json")
    assert (
        not result["collection_success"]
        and result["acquisition"]["actual_ssh_returncode"] == 0
    )
    assert result["acquisition"]["helper_receipt_validated"] is True
    assert any(
        row["operation"] == "saved_file:" + name
        for row in result["acquisition"]["evidence_errors"]
    )
    fake.capture.__exit__.assert_called_once()
    fake.manager.__exit__.assert_called_once()


def test_duplicate_helper_stdout_is_preserved_and_rejected(monkeypatch, inputs):
    recording(monkeypatch, inputs, "duplicate_helper")
    with pytest.raises(ValueError):
        collected(inputs)
    result = bench.read_json(inputs.output / "results.json")
    assert result["remote"] is None and not result["collection_success"]
    assert "Duplicate JSON key" in result["acquisition"]["evidence_errors"][0]["error"]
    assert (inputs.output / "remote.stdout").read_text().startswith('{"success":true,')


def test_offline_analysis_rejects_changed_saved_raw_and_duplicate_results(tmp_path):
    directory = analysis_fixture(
        tmp_path, bench.RUNS[0][0], [(0, 0.0, 1.0, [0.1, 0.11])]
    )
    raw = directory / "digital_2.bin"
    raw.write_bytes(raw.read_bytes() + b"changed")
    with pytest.raises(ValueError, match="artifact bytes"):
        bench.analyze(directory)
    result = directory / "results.json"
    result.write_text(result.read_text().replace("{", '{"backend":"original",', 1))
    with pytest.raises(ValueError, match="Duplicate JSON key"):
        bench.analyze(directory)


def test_nonfinite_json_and_success_only_offline_provenance_are_rejected(tmp_path):
    path = tmp_path / "nonfinite.json"
    path.write_text('{"value":NaN}')
    with pytest.raises(ValueError, match="Nonfinite"):
        bench.read_json(path)
    directory = analysis_fixture(
        tmp_path, bench.RUNS[0][0], [(0, 0.0, 1.0, [0.1, 0.11])]
    )
    put_json(
        directory / "results.json", {"backend": "original", "collection_success": True}
    )
    with pytest.raises(ValueError, match="predeclared capture"):
        bench.analyze(directory)
