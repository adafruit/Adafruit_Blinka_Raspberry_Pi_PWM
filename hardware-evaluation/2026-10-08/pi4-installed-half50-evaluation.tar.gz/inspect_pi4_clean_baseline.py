"""Read-only Pi4 reboot inspection; never claims/drives GPIO or changes PWM."""

import datetime
import hashlib
import importlib.util
import json
import os
import platform
import re
import shutil
import stat
import subprocess
from pathlib import Path


def query(arguments):
    try:
        result = subprocess.run(
            arguments, capture_output=True, text=True, timeout=8, check=False
        )
        return {
            "arguments": arguments,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except (OSError, subprocess.TimeoutExpired) as error:
        return {
            "arguments": arguments,
            "returncode": None,
            "error": type(error).__name__ + ": " + str(error),
        }


def text(path):
    try:
        return Path(path).read_bytes().rstrip(b"\0").decode().strip()
    except OSError as error:
        return {"error": type(error).__name__ + ": " + str(error)}


def strings(path):
    value = text(path)
    return value.split("\0") if isinstance(value, str) else value


def inspect():
    receipt = {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "hostname": platform.node(),
        "model": text("/sys/firmware/devicetree/base/model"),
        "kernel": platform.release(),
        "boot_id": text("/proc/sys/kernel/random/boot_id"),
        "python": platform.python_version(),
        "read_only": True,
        "no_gpio_claim_or_write": True,
        "no_board_pwmio_import": True,
    }
    receipt["pinctrl"] = [query(["pinctrl", "get", str(gpio)]) for gpio in (18, 23)]
    receipt["throttled"] = query(["vcgencmd", "get_throttled"])
    receipt["temperature_millic"] = text("/sys/class/thermal/thermal_zone0/temp")
    configs = {}
    for filename in ("/boot/firmware/config.txt", "/boot/config.txt"):
        path = Path(filename)
        if path.is_file():
            data = path.read_bytes()
            configs[filename] = {
                "resolved_path": str(path.resolve()),
                "sha256": hashlib.sha256(data).hexdigest(),
                "relevant_lines": [
                    {"line": index + 1, "text": line}
                    for index, line in enumerate(data.decode().splitlines())
                    if re.search(r"\b(?:dtoverlay|dtparam|include)\s*=|^\s*\[", line)
                ],
            }
    receipt["boot_configs"] = configs
    receipt["live_pwm_device_tree_nodes"] = [
        {
            "of_node": str(path.parent),
            "compatible": strings(path),
            "status": text(path.parent / "status")
            if (path.parent / "status").exists()
            else "okay (property absent)",
            "gpios_hex": (path.parent / "gpios").read_bytes().hex()
            if (path.parent / "gpios").exists()
            else None,
        }
        for path in Path("/sys/firmware/devicetree/base").rglob("compatible")
        if any("pwm" in item for item in strings(path))
    ]
    providers = []
    for path in sorted(Path("/sys/class/pwm").glob("pwmchip*")):
        node = path / "device/of_node"
        provider = {
            "sysfs_path": str(path),
            "resolved_path": str(path.resolve()),
            "npwm": text(path / "npwm"),
            "of_node": str(node.resolve()) if node.exists() else None,
            "compatible": strings(node / "compatible") if node.exists() else None,
            "exported_channels": [],
        }
        for channel in sorted(path.glob("pwm[0-9]*")):
            provider["exported_channels"].append(
                {
                    "path": str(channel),
                    "state": {
                        name: text(channel / name)
                        for name in ("enable", "period", "duty_cycle", "polarity")
                    },
                }
            )
        providers.append(provider)
    receipt["registered_pwm_providers"] = providers
    receipt["debug_pwm"] = query(["sudo", "-n", "cat", "/sys/kernel/debug/pwm"])
    if receipt["debug_pwm"].get("returncode") != 0:
        receipt["sudo_noninteractive_policy"] = query(["sudo", "-n", "-l"])
    gpio = []
    for path in sorted(Path("/sys/bus/gpio/devices").glob("gpiochip*")):
        node = path / "of_node"
        device = Path("/dev") / path.name
        information = {
            "sysfs_path": str(path),
            "of_node": str(node.resolve()) if node.exists() else None,
            "compatible": strings(node / "compatible") if node.exists() else None,
            "sysfs_device_number": text(path / "dev"),
        }
        if device.exists():
            metadata = device.stat()
            information.update(
                character_device=str(device),
                character_device_is_chr=stat.S_ISCHR(metadata.st_mode),
                character_device_number=f"{os.major(metadata.st_rdev)}:{os.minor(metadata.st_rdev)}",
            )
        gpio.append(information)
    receipt["gpio_providers"] = gpio
    receipt["gpioinfo_available"] = shutil.which("gpioinfo")
    if receipt["gpioinfo_available"]:
        version = query([receipt["gpioinfo_available"], "--version"])
        receipt["gpioinfo_version"] = version
        help_receipt = query([receipt["gpioinfo_available"], "--help"])
        receipt["gpioinfo_help"] = help_receipt
        for provider in gpio:
            if "brcm,bcm2711-gpio" not in (provider["compatible"] or []):
                continue
            chip_name = Path(provider["sysfs_path"]).name
            arguments = (
                [receipt["gpioinfo_available"], "-c", chip_name, "18", "23"]
                if "--chip" in help_receipt.get("stdout", "")
                else [receipt["gpioinfo_available"], chip_name]
            )
            receipt["header_line_ownership"] = query(arguments)
    else:
        spec = importlib.util.find_spec("gpiod")
        receipt["gpiod_python_available"] = spec is not None
        if spec is not None:
            import gpiod

            for provider in gpio:
                if "brcm,bcm2711-gpio" not in (provider["compatible"] or []):
                    continue
                chip = gpiod.Chip(provider["character_device"])
                try:
                    receipt["header_line_ownership"] = [
                        {
                            "offset": offset,
                            "used": (line := chip.get_line_info(offset)).used,
                            "consumer": line.consumer,
                            "direction": line.direction.name,
                        }
                        for offset in (18, 23)
                    ]
                finally:
                    chip.close()
    return receipt


if __name__ == "__main__":
    print(json.dumps(inspect(), indent=2))
