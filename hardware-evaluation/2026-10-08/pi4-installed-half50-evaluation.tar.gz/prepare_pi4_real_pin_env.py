"""Three explicit private Pi4 setup stages; no GPIO/package runtime imports.

Each stage owns fresh receipt/raw-output files and stops on any unproven result.
Only bootstrap creates a new /tmp root; transfer and install consume its receipt.
The 23 frozen wheels are installed offline into that private venv. System RPi.GPIO
is inherited unchanged, not installed, imported, uninstalled or copied.
"""

import argparse
import datetime
import email
import hashlib
import json
import re
import shlex
import subprocess
import zipfile
from pathlib import Path

LAB = Path(__file__).resolve().parent
WHEELHOUSE = Path("/private/tmp/blinka-installed-prep.1XpM16/wheelhouse")
PLAN = LAB / "oct7-installed-blinka-consumers-plan.json"
PLAN_SHA = "04869dae6b202202fc2c2b6bfdaa1dbaa7bcaf5a2f8a946ee65d81073a1c6161"
HOST = "pi@test2-pi4.local"
ROOT_PATTERN = r"/tmp/blinka-pwm-pi4-real-pin\.[a-z0-9_]{8}"
STEPS = ("bootstrap", "transfer", "install")
BOOT_ID = "5d3cf2af-f7f0-4199-a1d1-25958db13921"
CONFIGS = {
    "/boot/firmware/config.txt": "90a446821551a9df109ec1a77a79f6518fe974517d982d371c5e9efd6bbc98c3",
    "/boot/config.txt": "c39b0866eec314a741f6cba65f10937b914408d6660d5a81f6b3a9ce81471010",
}
RPI_SOURCES = {
    "/usr/lib/python3/dist-packages/RPi/GPIO/__init__.py": "ae9a2e82fe65195e0804ad6579fe3a87f916d4958e6761456eaf4ac53ce6f11d",
    "/usr/lib/python3/dist-packages/RPi/_GPIO.cpython-313-aarch64-linux-gnu.so": "854bbc7f89cfa2d38b9da9807881d61e25fa2d93f692e66b71d920c5dc854b94",
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def regular(path):
    path = Path(path)
    if not path.is_file() or path.is_symlink() or path.resolve() != path:
        raise ValueError("Canonical regular file required: " + str(path))
    return path


def inputs():
    regular(PLAN)
    if digest(PLAN) != PLAN_SHA:
        raise ValueError("Frozen wheel plan changed")
    wheels = json.loads(PLAN.read_text())["wheel_artifacts"]
    if len(wheels) != 23 or not WHEELHOUSE.is_dir() or WHEELHOUSE.is_symlink():
        raise ValueError("Exact 23-wheel directory required")
    if WHEELHOUSE.resolve() != WHEELHOUSE or {
        p.name for p in WHEELHOUSE.iterdir()
    } != set(wheels):
        raise ValueError("Wheelhouse is noncanonical or contains missing/extra files")
    versions = {}
    for name, expected in wheels.items():
        if not re.fullmatch(r"[A-Za-z0-9_.+\-]+\.whl", name):
            raise ValueError("Unsafe wheel name")
        path = regular(WHEELHOUSE / name)
        if (
            path.stat().st_size != expected["size_bytes"]
            or digest(path) != expected["sha256"]
        ):
            raise ValueError("Frozen wheel bytes changed: " + name)
        with zipfile.ZipFile(path) as wheel:
            entries = wheel.namelist()
            if len(entries) != len(set(entries)):
                raise ValueError("Duplicate wheel entries")
            for entry in entries:
                member = Path(entry)
                if (
                    member.is_absolute()
                    or ".." in member.parts
                    or (wheel.getinfo(entry).external_attr >> 16) & 0o170000 == 0o120000
                ):
                    raise ValueError("Unsafe wheel entry")
                if entry.endswith(".pth") or member.name in (
                    "sitecustomize.py",
                    "usercustomize.py",
                ):
                    raise ValueError("Wheel would introduce startup code")
            metadata = [
                name for name in entries if name.endswith(".dist-info/METADATA")
            ]
            if len(metadata) != 1:
                raise ValueError("Single wheel metadata required")
            message = email.message_from_bytes(wheel.read(metadata[0]))
            key = re.sub(r"[-_.]+", "-", message["Name"]).lower()
            if key in versions or key == "rpi-gpio":
                raise ValueError("Duplicate distribution or forbidden RPi.GPIO wheel")
            versions[key] = message["Version"]
    return wheels, versions


def remote_code(stage, wheels, versions, root=None):
    """Standard-library-only guard/receipts; runtime packages are never imported."""
    header = f"""
import hashlib,importlib.metadata,json,os,pathlib,platform,re,subprocess,sys,tempfile
stage={stage!r}
wheels={wheels!r}
versions={versions!r}
root_name={root!r}
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def regular(path):
    assert path.is_file() and not path.is_symlink() and path.resolve()==path,str(path)
    return path
def run(arguments):
    try:
        child=subprocess.run(arguments,stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=240,check=False,env={{**os.environ,'PIP_CONFIG_FILE':'/dev/null','PIP_DISABLE_PIP_VERSION_CHECK':'1','PIP_NO_CACHE_DIR':'1'}})
        return {{'arguments':arguments,'returncode':child.returncode,'stdout':child.stdout,'stderr':child.stderr,'error':None}}
    except (OSError,subprocess.TimeoutExpired) as error:
        return {{'arguments':arguments,'returncode':None,'error':type(error).__name__+': '+str(error)}}
def ok(result): return type(result.get('returncode')) is int and result['returncode']==0 and result.get('error') is None
def metadata(site):
    return {{re.sub(r'[-_.]+','-',item.metadata['Name']).lower():item.version for item in importlib.metadata.distributions(path=[str(site)])}}
assert sys.flags.isolated and sys.flags.no_site
assert os.getuid()==1000 and platform.node()=='test2-pi4'
assert platform.python_version()=='3.13.5' and platform.machine()=='aarch64'
assert platform.release()=='6.18.50+rpt-rpi-v8'
assert pathlib.Path('/proc/device-tree/model').read_bytes().rstrip(b'\\x00').decode()=='Raspberry Pi 4 Model B Rev 1.4'
assert pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()=={BOOT_ID!r}
for filename,expected in {CONFIGS!r}.items(): assert sha(regular(pathlib.Path(filename)))==expected
for filename,expected in {RPI_SOURCES!r}.items(): assert sha(regular(pathlib.Path(filename)))==expected
assert metadata(pathlib.Path('/usr/lib/python3/dist-packages')).get('rpi-gpio')=='0.7.1a4'
assert all(os.environ.get(name) is None for name in ('BLINKA_PWM_SHARED','BLINKA_PWM_SHORT_SLICE','PYTHONPATH','PYTHONHOME'))
for site in (pathlib.Path('/usr/lib/python3/dist-packages'),pathlib.Path('/usr/local/lib/python3.13/dist-packages')):
    assert not list(site.glob('*.pth')) and not (site/'sitecustomize.py').exists() and not (site/'usercustomize.py').exists()
def validate_root():
    assert type(root_name) is str and re.fullmatch({ROOT_PATTERN!r},root_name)
    root=pathlib.Path(root_name)
    assert root.is_dir() and not root.is_symlink() and root.resolve()==root
    assert root.stat().st_uid==os.getuid() and root.stat().st_mode & 0o777==0o700
    venv=root/'venv'; house=root/'wheelhouse'
    assert venv.is_dir() and not venv.is_symlink() and venv.resolve()==venv
    assert house.is_dir() and not house.is_symlink() and house.resolve()==house
    cfg=regular(venv/'pyvenv.cfg').read_text()
    assert 'include-system-site-packages = true' in cfg.lower()
    python=venv/'bin/python'
    assert python.is_file() and python.resolve()==pathlib.Path('/usr/bin/python3.13').resolve()
    return root,venv,house,str(python)
def wheel_proof(house):
    assert {{p.name for p in house.iterdir()}}==set(wheels)
    result={{}}
    for name,expected in wheels.items():
        path=regular(house/name)
        actual={{'sha256':sha(path),'size_bytes':path.stat().st_size}}
        assert actual==expected,name
        result[name]=actual
    return result
def emit(value):
    assert not any(name in sys.modules for name in ('board','pwmio','RPi.GPIO'))
    print(json.dumps({{'stage':stage,'root':root_name,'boot_id':{BOOT_ID!r},'rpi_gpio_sources':{RPI_SOURCES!r},'no_board_pwmio_RPi_GPIO_import':True,**value}},indent=2))
"""
    bodies = {
        "bootstrap": """
root=pathlib.Path(tempfile.mkdtemp(prefix='blinka-pwm-pi4-real-pin.',dir='/tmp'))
root_name=str(root)
assert re.fullmatch(r'/tmp/blinka-pwm-pi4-real-pin\\.[a-z0-9_]{8}',root_name)
assert root.stat().st_mode & 0o777==0o700 and not list(root.iterdir())
venv_result=run(['/usr/bin/python3','-I','-S','-m','venv','--system-site-packages',str(root/'venv')])
pip_result=None
if ok(venv_result):
    (root/'wheelhouse').mkdir(mode=0o700)
    root,venv,house,python=validate_root()
    pip_result=run([python,'-I','-m','pip','--isolated','--require-virtualenv','--version'])
emit({'accepted':ok(venv_result) and pip_result is not None and ok(pip_result),'venv_creation':venv_result,'pip_version':pip_result})
""",
        "transfer-precheck": """
root,venv,house,python=validate_root()
assert not list(house.iterdir())
emit({'accepted':True,'empty_wheelhouse':True})
""",
        "transfer-verify": """
root,venv,house,python=validate_root()
proof=wheel_proof(house)
emit({'accepted':True,'wheel_artifacts':proof})
""",
        "install": """
root,venv,house,python=validate_root()
proof=wheel_proof(house)
site=venv/'lib/python3.13/site-packages'
assert site.is_dir() and not site.is_symlink() and site.resolve()==site
before=metadata(site)
assert set(before)=={'pip'},before
pip=[python,'-I','-m','pip','--isolated','--require-virtualenv']
installation=run([*pip,'install','--ignore-installed','--prefix',str(venv),'--no-index','--no-deps','--no-input','--no-cache-dir','--report',str(root/'offline-install-report.json'),'--log',str(root/'offline-install.log'),*[str(house/name) for name in sorted(wheels)]])
after=metadata(site)
provenance_ok=all(after.get(name)==version for name,version in versions.items()) and set(after)==set(versions)|{'pip'} and 'rpi-gpio' not in after
check=run([*pip,'check']) if ok(installation) else None
listing=run([*pip,'list','--format=json']) if ok(installation) else None
for filename,expected in """
        + repr(RPI_SOURCES)
        + """.items(): assert sha(regular(pathlib.Path(filename)))==expected
emit({'accepted':ok(installation) and provenance_ok and check is not None and ok(check) and listing is not None and ok(listing),'wheel_artifacts':proof,'private_versions_before':before,'private_versions_after':after,'private_provenance_ok':provenance_ok,'pip_install':installation,'pip_check':check,'pip_list':listing,'system_RPi_GPIO_inherited_unchanged':True})
""",
    }
    return header + bodies[stage]


def output_path(step):
    return LAB / f"oct7-pi4-real-pin-env-{step}.json"


def prior(step, wheels):
    """Require this exact source's accepted prior chain and authentic raw bytes."""
    root = None
    proofs = {}
    for name in STEPS[: STEPS.index(step)]:
        path = regular(output_path(name))
        receipt = json.loads(path.read_text())
        if (
            receipt.get("accepted") is not True
            or receipt.get("preparer_sha256") != digest(__file__)
            or receipt.get("wheel_plan_sha256") != PLAN_SHA
            or receipt.get("wheel_artifacts") != wheels
        ):
            raise ValueError("Exact successful preparation chain required")
        current = receipt.get("root")
        if (
            type(current) is not str
            or re.fullmatch(ROOT_PATTERN, current) is None
            or (root is not None and root != current)
        ):
            raise ValueError("Prior root mismatch")
        root = current
        operations = receipt.get("operations", [])
        if [entry["name"] for entry in operations] != (
            ["bootstrap"]
            if name == "bootstrap"
            else ["transfer-precheck", "scp", "transfer-verify"]
        ):
            raise ValueError("Incomplete prior stage")
        for operation in operations:
            if (
                operation.get("error") is not None
                or type(operation.get("returncode")) is not int
                or operation["returncode"] != 0
            ):
                raise ValueError("Actual prior command zero required")
            for stream in ("stdout", "stderr"):
                raw = regular(Path(str(path) + "." + operation["name"] + "." + stream))
                if digest(raw) != operation[stream + "_sha256"]:
                    raise ValueError("Prior raw bytes changed")
            if operation["name"] != "scp":
                payload = json.loads(
                    Path(str(path) + "." + operation["name"] + ".stdout").read_text()
                )
                if (
                    payload != operation.get("remote")
                    or payload.get("accepted") is not True
                    or payload.get("root") != root
                    or payload.get("boot_id") != BOOT_ID
                ):
                    raise ValueError("Prior payload mismatch")
            if not successful(operation, root, wheels):
                raise ValueError("Prior typed results or proof mismatch")
        proofs[name] = digest(path)
    return root, proofs


def ssh(code):
    return [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        HOST,
        shlex.join(["/usr/bin/python3", "-I", "-S", "-c", code]),
    ]


def execute(name, arguments, output):
    """Capture only actual command status; exceptions/boolean statuses fail closed."""
    stdout = Path(str(output) + "." + name + ".stdout")
    stderr = Path(str(output) + "." + name + ".stderr")
    result, error = None, None
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            result = subprocess.run(
                arguments,
                stdin=subprocess.DEVNULL,
                stdout=out,
                stderr=err,
                timeout=300,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt) as failure:
            error = type(failure).__name__ + ": " + str(failure)
    actual = (
        result.returncode
        if result is not None and type(result.returncode) is int
        else None
    )
    operation = {
        "name": name,
        "arguments": arguments,
        "returncode": actual,
        "error": error,
        "stdout_sha256": digest(stdout),
        "stderr_sha256": digest(stderr),
    }
    if name != "scp" and error is None and actual == 0:
        try:
            operation["remote"] = json.loads(stdout.read_text())
        except (ValueError, UnicodeError) as failure:
            operation["error"] = "Invalid JSON stdout: " + str(failure)
    return operation


def child_zero(child):
    return (
        isinstance(child, dict)
        and type(child.get("returncode")) is int
        and child["returncode"] == 0
        and child.get("error") is None
    )


def successful(operation, root, wheels):
    if type(root) is not str or re.fullmatch(ROOT_PATTERN, root) is None:
        return False
    if (
        operation["error"] is not None
        or type(operation["returncode"]) is not int
        or operation["returncode"] != 0
    ):
        return False
    if operation["name"] == "scp":
        return True
    value = operation.get("remote", {})
    if not (
        value.get("accepted") is True
        and value.get("root") == root
        and value.get("stage") == operation["name"]
        and value.get("boot_id") == BOOT_ID
        and value.get("no_board_pwmio_RPi_GPIO_import") is True
        and value.get("rpi_gpio_sources") == RPI_SOURCES
    ):
        return False
    if operation["name"] == "bootstrap":
        return child_zero(value.get("venv_creation")) and child_zero(
            value.get("pip_version")
        )
    if operation["name"] == "transfer-precheck":
        return value.get("empty_wheelhouse") is True
    if value.get("wheel_artifacts") != wheels:
        return False
    if operation["name"] == "install":
        return (
            value.get("private_provenance_ok") is True
            and value.get("system_RPi_GPIO_inherited_unchanged") is True
            and all(
                child_zero(value.get(name))
                for name in ("pip_install", "pip_check", "pip_list")
            )
        )
    return operation["name"] == "transfer-verify"


def prepare(step):
    wheels, versions = inputs()
    root, prior_hashes = prior(step, wheels)
    output = output_path(step)
    names = (
        [step]
        if step != "transfer"
        else ["transfer-precheck", "scp", "transfer-verify"]
    )
    targets = [
        output,
        *[
            Path(str(output) + "." + name + "." + stream)
            for name in names
            for stream in ("stdout", "stderr")
        ],
    ]
    if any(path.exists() or path.is_symlink() for path in targets):
        raise ValueError("Exclusive fresh preparation evidence required")
    # Reserve the receipt before any remote mutation; a concurrent invocation fails.
    with output.open("x") as receipt_stream:
        operations = []
        codes = {}
        for name in names:
            if name == "scp":
                arguments = [
                    "scp",
                    "-B",
                    "-o",
                    "BatchMode=yes",
                    "-o",
                    "ConnectTimeout=8",
                    *[str(WHEELHOUSE / filename) for filename in sorted(wheels)],
                    HOST + ":" + root + "/wheelhouse/",
                ]
            else:
                codes[name] = remote_code(name, wheels, versions, root)
                arguments = ssh(codes[name])
            operation = execute(name, arguments, output)
            operations.append(operation)
            if step == "bootstrap":
                candidate = operation.get("remote", {}).get("root")
                root = (
                    candidate
                    if type(candidate) is str and re.fullmatch(ROOT_PATTERN, candidate)
                    else None
                )
            if not successful(operation, root, wheels):
                break
        accepted = len(operations) == len(names) and all(
            successful(entry, root, wheels) for entry in operations
        )
        receipt = {
            "schema_version": 1,
            "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "step": step,
            "root": root,
            "remote_python": root + "/venv/bin/python" if root else None,
            "preparer_sha256": digest(__file__),
            "wheel_plan_sha256": PLAN_SHA,
            "wheel_artifacts": wheels,
            "wheel_distribution_versions": versions,
            "prior_receipt_sha256": prior_hashes,
            "operations": operations,
            "remote_code": codes,
            "accepted": accepted,
            "scope": "Private offline setup only; no board/pwmio/RPi.GPIO import or GPIO calls; no sudo, system/user install or distro uninstall",
        }
        json.dump(receipt, receipt_stream, indent=2)
        receipt_stream.write("\n")
    print(
        json.dumps(
            {
                "step": step,
                "root": root,
                "accepted": accepted,
                "actual_returncodes": [entry["returncode"] for entry in operations],
            }
        )
    )
    return 0 if accepted else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", choices=STEPS)
    raise SystemExit(prepare(parser.parse_args().step))
