"""Offline guard/receipt fakes; never execute SSH, SCP, pip or remote code."""

import ast
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

import prepare_pi4_real_pin_env as preparer
import pytest

ROOT = "/tmp/blinka-pwm-pi4-real-pin.abcdefgh"


@pytest.fixture
def setup(tmp_path, monkeypatch):
    lab = tmp_path / "lab"
    lab.mkdir()
    house = tmp_path / "wheelhouse"
    house.mkdir()
    wheels = {}
    for index in range(23):
        name = f"fixture{index}-1.0-py3-none-any.whl"
        path = house / name
        with zipfile.ZipFile(path, "w") as wheel:
            wheel.writestr(
                f"fixture{index}-1.0.dist-info/METADATA",
                f"Name: fixture{index}\nVersion: 1.0\n",
            )
        wheels[name] = {
            "sha256": preparer.digest(path),
            "size_bytes": path.stat().st_size,
        }
    plan = lab / "plan.json"
    plan.write_text(json.dumps({"wheel_artifacts": wheels}))
    monkeypatch.setattr(preparer, "LAB", lab)
    monkeypatch.setattr(preparer, "WHEELHOUSE", house)
    monkeypatch.setattr(preparer, "PLAN", plan)
    monkeypatch.setattr(preparer, "PLAN_SHA", preparer.digest(plan))
    return lab, house, wheels


def payload(name, wheels):
    child = {"returncode": 0, "error": None}
    value = {
        "accepted": True,
        "stage": name,
        "root": ROOT,
        "boot_id": preparer.BOOT_ID,
        "rpi_gpio_sources": preparer.RPI_SOURCES,
        "no_board_pwmio_RPi_GPIO_import": True,
    }
    if name == "bootstrap":
        value.update(venv_creation=child.copy(), pip_version=child.copy())
    elif name == "transfer-precheck":
        value["empty_wheelhouse"] = True
    else:
        value["wheel_artifacts"] = wheels
    if name == "install":
        value.update(
            private_provenance_ok=True,
            system_RPi_GPIO_inherited_unchanged=True,
            pip_install=child.copy(),
            pip_check=child.copy(),
            pip_list=child.copy(),
        )
    return value


def fake_commands(monkeypatch, wheels, tweak=None):
    calls = []

    def run(arguments, **kwargs):
        calls.append(arguments)
        if arguments[0] == "scp":
            name, body = "scp", b""
        else:
            # Stage is a source assignment in the command, not actual execution.
            import shlex

            source = shlex.split(arguments[-1])[-1]
            syntax = ast.parse(source)
            name = next(
                ast.literal_eval(node.value)
                for node in syntax.body
                if isinstance(node, ast.Assign)
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == "stage"
            )
            body = json.dumps(payload(name, wheels)).encode()
        result = {"returncode": 0, "stdout": body, "stderr": b""}
        if tweak:
            tweak(name, result)
        kwargs["stdout"].write(result["stdout"])
        kwargs["stderr"].write(result["stderr"])
        return subprocess.CompletedProcess(arguments, result["returncode"])

    monkeypatch.setattr(preparer.subprocess, "run", run)
    return calls


def receipt(lab, stage):
    return json.loads((lab / f"oct7-pi4-real-pin-env-{stage}.json").read_text())


def test_successful_chain_exact_scp_and_offline_install(setup, monkeypatch):
    lab, house, wheels = setup
    calls = fake_commands(monkeypatch, wheels)
    for step in preparer.STEPS:
        assert preparer.prepare(step) == 0
    assert len(calls) == 5
    scp = calls[2]
    assert scp[6:-1] == [str(house / name) for name in sorted(wheels)]
    assert scp[-1] == preparer.HOST + ":" + ROOT + "/wheelhouse/"
    result = receipt(lab, "install")
    assert set(result["prior_receipt_sha256"]) == {"bootstrap", "transfer"}
    assert result["operations"][0]["returncode"] == 0
    code = result["remote_code"]["install"]
    for flag in (
        "--isolated",
        "--require-virtualenv",
        "--ignore-installed",
        "--prefix",
        "--no-index",
        "--no-deps",
        "--no-input",
        "--no-cache-dir",
    ):
        assert flag in code
    assert "'rpi-gpio' not in after" in code


@pytest.mark.parametrize("change", ["plan", "bytes", "size", "extra", "symlink"])
def test_local_bad_bytes_block_before_command(setup, monkeypatch, change):
    lab, house, wheels = setup
    calls = fake_commands(monkeypatch, wheels)
    path = house / next(iter(wheels))
    if change == "plan":
        preparer.PLAN.write_text("{}")
    elif change == "bytes":
        data = bytearray(path.read_bytes())
        data[-1] ^= 1
        path.write_bytes(data)
    elif change == "size":
        path.write_bytes(path.read_bytes() + b"x")
    elif change == "extra":
        (house / "extra.whl").touch()
    else:
        replacement = lab / "wheel"
        path.rename(replacement)
        path.symlink_to(replacement)
    with pytest.raises(ValueError):
        preparer.prepare("bootstrap")
    assert calls == []


def test_missing_prior_blocks(setup, monkeypatch):
    _, _, wheels = setup
    calls = fake_commands(monkeypatch, wheels)
    with pytest.raises(ValueError):
        preparer.prepare("transfer")
    assert calls == []


def test_exclusive_receipt_no_overwrite(setup, monkeypatch):
    lab, _, wheels = setup
    calls = fake_commands(monkeypatch, wheels)
    assert preparer.prepare("bootstrap") == 0
    before = {path: path.read_bytes() for path in lab.glob("oct7-*")}
    with pytest.raises(ValueError):
        preparer.prepare("bootstrap")
    assert len(calls) == 1
    assert before == {path: path.read_bytes() for path in before}


@pytest.mark.parametrize("status", [1, 255, False, None])
def test_actual_nonzero_or_untyped_exit_never_accepted(setup, monkeypatch, status):
    lab, _, wheels = setup
    fake_commands(
        monkeypatch, wheels, lambda _, result: result.update(returncode=status)
    )
    assert preparer.prepare("bootstrap") == 1
    result = receipt(lab, "bootstrap")
    assert result["accepted"] is False
    assert result["operations"][0]["returncode"] == (
        status if type(status) is int else None
    )


def test_timeout_receipt_preserved(setup, monkeypatch):
    lab, _, _ = setup

    def timeout(*args, **kwargs):
        kwargs["stderr"].write(b"partial error")
        raise subprocess.TimeoutExpired(args[0], 300)

    monkeypatch.setattr(preparer.subprocess, "run", timeout)
    assert preparer.prepare("bootstrap") == 1
    result = receipt(lab, "bootstrap")
    assert result["operations"][0]["returncode"] is None
    assert "TimeoutExpired" in result["operations"][0]["error"]
    assert (
        preparer.digest(
            Path(str(preparer.output_path("bootstrap")) + ".bootstrap.stderr")
        )
        == hashlib.sha256(b"partial error").hexdigest()
    )


@pytest.mark.parametrize(
    "field",
    [
        "root",
        "venv_creation",
        "pip_version",
        "rpi_gpio_sources",
        "no_board_pwmio_RPi_GPIO_import",
    ],
)
def test_remote_bootstrap_claim_must_have_valid_proofs(setup, monkeypatch, field):
    lab, _, wheels = setup

    def tweak(_, result):
        value = json.loads(result["stdout"])
        value[field] = (
            {"returncode": False} if field in ("venv_creation", "pip_version") else None
        )
        result["stdout"] = json.dumps(value).encode()

    fake_commands(monkeypatch, wheels, tweak)
    assert preparer.prepare("bootstrap") == 1
    assert receipt(lab, "bootstrap")["accepted"] is False


def test_scp_failure_stops_before_verify(setup, monkeypatch):
    lab, _, wheels = setup
    calls = fake_commands(monkeypatch, wheels)
    assert preparer.prepare("bootstrap") == 0
    calls = fake_commands(
        monkeypatch,
        wheels,
        lambda name, result: (
            result.update(returncode=1, stderr=b"scp failed") if name == "scp" else None
        ),
    )
    assert preparer.prepare("transfer") == 1
    assert len(calls) == 2
    result = receipt(lab, "transfer")
    assert [entry["name"] for entry in result["operations"]] == [
        "transfer-precheck",
        "scp",
    ]
    assert result["operations"][-1]["returncode"] == 1


@pytest.mark.parametrize(
    "field",
    [
        "pip_install",
        "pip_check",
        "pip_list",
        "private_provenance_ok",
        "wheel_artifacts",
    ],
)
def test_install_failure_claim_preserves_actual_child_results(
    setup, monkeypatch, field
):
    lab, _, wheels = setup
    fake_commands(monkeypatch, wheels)
    assert preparer.prepare("bootstrap") == 0
    assert preparer.prepare("transfer") == 0

    def tweak(_, result):
        value = json.loads(result["stdout"])
        value[field] = (
            {
                "returncode": 1,
                "stdout": "actual failed check",
                "stderr": "",
                "error": None,
            }
            if field.startswith("pip_")
            else None
        )
        result["stdout"] = json.dumps(value).encode()

    fake_commands(monkeypatch, wheels, tweak)
    assert preparer.prepare("install") == 1
    result = receipt(lab, "install")
    assert result["operations"][0]["returncode"] == 0  # SSH0 is not child success.
    assert result["operations"][0]["remote"][field] is not True


@pytest.mark.parametrize("change", ["receipt", "stdout", "source", "status"])
def test_tampered_prior_chain_blocks(setup, monkeypatch, change):
    lab, _, wheels = setup
    fake_commands(monkeypatch, wheels)
    assert preparer.prepare("bootstrap") == 0
    path = preparer.output_path("bootstrap")
    if change == "stdout":
        Path(str(path) + ".bootstrap.stdout").write_text("{}")
    else:
        value = json.loads(path.read_text())
        if change == "source":
            value["preparer_sha256"] = "0" * 64
        elif change == "status":
            value["operations"][0]["returncode"] = False
        else:
            value["accepted"] = False
        path.write_text(json.dumps(value))
    calls = fake_commands(monkeypatch, wheels)
    with pytest.raises(ValueError):
        preparer.prepare("transfer")
    assert calls == []


@pytest.mark.parametrize(
    "name", ["bootstrap", "transfer-precheck", "transfer-verify", "install"]
)
def test_remote_code_compiles_and_has_no_runtime_imports_or_gpio_operations(name):
    source = preparer.remote_code(name, {}, {}, None if name == "bootstrap" else ROOT)
    syntax = ast.parse(source)
    imports = []
    for node in ast.walk(syntax):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        if isinstance(node, ast.ImportFrom):
            imports.append(node.module)
    assert all(
        module.split(".")[0]
        in {
            "hashlib",
            "importlib",
            "json",
            "os",
            "pathlib",
            "platform",
            "re",
            "subprocess",
            "sys",
            "tempfile",
        }
        for module in imports
    )
    assert "sudo" not in source and "gpiochip" not in source and "gpiomem" not in source
    assert "-S" in source if name == "bootstrap" else "sys.flags.no_site" in source
    assert "mkdtemp(" in source if name == "bootstrap" else "mkdtemp(" not in source
