"""Read-only private Pi4 source/metadata inventory; no runtime package imports.

Run only after the main agent's frozen preparer installation. The helper is not
deployed/imported here: its exact local hash/path is separate deployment material.
Every observed private source must byte-match one member of the frozen wheels.
"""

import datetime
import email
import hashlib
import json
import re
import shlex
import subprocess
import zipfile
from pathlib import Path

import prepare_pi4_real_pin_env as preparation
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.utils import canonicalize_name

LAB = Path(__file__).resolve().parent
ROOT = "/tmp/blinka-pwm-pi4-real-pin.2y4fi6z0"
HELPER = "pi4_installed_pwm_half50_eval.py"
HELPER_SHA = "5c2ae21329b57dab3c4bf37010708eda8ffb6edd9485b3ecf3bd5519671fdb03"
OUTPUT = LAB / "oct8-pi4-installed-source-inventory.json"
KNOWN_VERSIONS = {
    "Adafruit-Blinka": "9.0.5.dev74+pwmeval.beb49bf",
    "Adafruit-Blinka-Raspberry-Pi-PWM": "0.0.1.dev0",
    "Adafruit-PlatformDetect": "3.89.1",
    "gpiod": "2.5.0",
    "packaging": "26.3",
    "RPi.GPIO": "0.7.1a4",
}
BLINKA_FILES = (
    "board.py",
    "pwmio.py",
    "board_imports.json",
    "microcontroller_imports.json",
    "microcontroller/__init__.py",
    "microcontroller/pin.py",
)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def inputs():
    wheels, versions = preparation.inputs()
    preparation.prior("install", wheels)
    path = preparation.output_path("install")
    receipt = json.loads(path.read_text())
    if (
        receipt.get("accepted") is not False
        or receipt.get("root") != ROOT
        or receipt.get("preparer_sha256") != preparation.digest(preparation.__file__)
        or receipt.get("wheel_plan_sha256") != preparation.PLAN_SHA
        or receipt.get("wheel_artifacts") != wheels
        or receipt.get("wheel_distribution_versions") != versions
    ):
        raise ValueError("Require preserved failed whole-environment receipt")
    operations = receipt.get("operations", [])
    if (
        len(operations) != 1
        or type(operations[0].get("returncode")) is not int
        or operations[0]["returncode"] != 0
        or operations[0].get("error") is not None
    ):
        raise ValueError("Actual typed SSH0 required")
    installed = operations[0]["remote"]
    if (
        installed.get("root") != ROOT
        or installed.get("accepted") is not False
        or installed.get("private_provenance_ok") is not True
        or installed.get("system_RPi_GPIO_inherited_unchanged") is not True
        or installed.get("wheel_artifacts") != wheels
        or not all(
            preparation.child_zero(installed.get(name))
            for name in ("pip_install", "pip_list")
        )
        or type(installed["pip_check"].get("returncode")) is not int
        or installed["pip_check"]["returncode"] != 1
        or installed["pip_check"].get("error") is not None
    ):
        raise ValueError(
            "Successful private installation/list and preserved actual check1 required"
        )
    for stream in ("stdout", "stderr"):
        raw = Path(str(path) + ".install." + stream)
        preparation.regular(raw)
        if digest(raw) != receipt["operations"][0][stream + "_sha256"]:
            raise ValueError("Frozen install raw bytes changed")
    payload = json.loads(Path(str(path) + ".install.stdout").read_text())
    if payload != receipt["operations"][0].get("remote"):
        raise ValueError("Install stdout payload mismatch")
    if digest(LAB / HELPER) != HELPER_SHA:
        raise ValueError("Frozen helper source changed")
    audit = closure_audit(wheels, installed)
    return wheels, versions, digest(path), audit


def closure_audit(wheels, installed):
    """Audit all frozen wheel requirements with no extras for the observed target."""
    environment = {
        "implementation_name": "cpython",
        "implementation_version": "3.13.5",
        "os_name": "posix",
        "platform_machine": "aarch64",
        "platform_release": "6.18.50+rpt-rpi-v8",
        "platform_system": "Linux",
        "platform_version": "",
        "python_full_version": "3.13.5",
        "platform_python_implementation": "CPython",
        "python_version": "3.13",
        "sys_platform": "linux",
        "extra": "",
    }
    versions = dict(installed["private_versions_after"])
    versions["rpi-gpio"] = "0.7.1a4"
    closure = set(versions) - {"pip"}
    checks = []
    for filename in sorted(wheels):
        with zipfile.ZipFile(preparation.WHEELHOUSE / filename) as wheel:
            names = [n for n in wheel.namelist() if n.endswith(".dist-info/METADATA")]
            if len(names) != 1:
                raise ValueError("Ambiguous wheel metadata")
            metadata = email.message_from_bytes(wheel.read(names[0]))
        name = canonicalize_name(metadata["Name"])
        if versions.get(name) != metadata["Version"]:
            raise ValueError("Private version mismatch: " + name)
        if metadata.get("Requires-Python") and not SpecifierSet(
            metadata["Requires-Python"]
        ).contains("3.13.5", prereleases=True):
            raise ValueError("Requires-Python mismatch: " + name)
        for raw in metadata.get_all("Requires-Dist", []):
            requirement = Requirement(raw)
            active = requirement.marker is None or requirement.marker.evaluate(
                environment=environment
            )
            selected = versions.get(canonicalize_name(requirement.name))
            okay = not active or (
                requirement.url is None
                and selected is not None
                and requirement.specifier.contains(selected, prereleases=True)
            )
            checks.append(
                {
                    "requester": name,
                    "requires_dist": raw,
                    "active_for_target_no_extras": active,
                    "selected_version": selected,
                    "satisfied": okay,
                }
            )
            if not okay:
                raise ValueError(
                    "Active wheel requirement missing/outdated: " + name + " -> " + raw
                )
    observed = {
        canonicalize_name(item["name"]): item["version"]
        for item in json.loads(installed["pip_list"]["stdout"])
    }
    classified = []
    for line in installed["pip_check"]["stdout"].splitlines():
        match = re.fullmatch(
            r"(\S+) (\S+) requires ([^,]+), which is not installed\.", line
        )
        if match is None:
            raise ValueError("Unclassified pip-check failure: " + line)
        requester, version, raw = match.groups()
        requirement = Requirement(raw)
        caller = canonicalize_name(requester)
        dependency = canonicalize_name(requirement.name)
        unrelated = caller not in closure and dependency not in closure
        if not unrelated or observed.get(caller) != version or dependency in observed:
            raise ValueError(
                "pip-check failure implicates closure or observation differs: " + line
            )
        classified.append(
            {
                "line": line,
                "requester": caller,
                "version": version,
                "dependency": dependency,
                "neither_name_in_tested_closure": True,
                "requester_version_observed": True,
                "required_dependency_absent_from_full_pip_list": True,
            }
        )
    if len(classified) != 17 or installed["pip_check"]["stderr"] != "":
        raise ValueError("Require all17 known failure lines and empty check stderr")
    return {
        "target_marker_environment": environment,
        "wheel_count": len(wheels),
        "tested_closure_versions": {name: versions[name] for name in sorted(closure)},
        "requirements": checks,
        "all_active_requirements_satisfied": True,
        "pip_check_actual_returncode": 1,
        "pip_check_stdout_unchanged": installed["pip_check"]["stdout"],
        "pip_check_stderr_unchanged": installed["pip_check"]["stderr"],
        "pip_check_failure_classification": classified,
        "all17_failures_outside_tested_closure": True,
        "whole_environment_clean": False,
        "scope": "No-extras private wheel closure plus inherited RPi.GPIO only; preserved failed whole-environment pip check is NOT accepted or relabeled",
    }


def remote_code():
    return f"""
import hashlib,importlib.metadata,json,os,pathlib,platform,re,stat,subprocess,sys
root=pathlib.Path({ROOT!r}); site=root/'venv/lib/python3.13/site-packages'
system=pathlib.Path('/usr/lib/python3/dist-packages')
assert sys.flags.isolated and sys.flags.no_site and sys.executable==str(root/'venv/bin/python')
assert root.is_dir() and not root.is_symlink() and root.resolve()==root
assert site.is_dir() and not site.is_symlink() and site.resolve()==site
assert not any(name in sys.modules for name in ('board','pwmio','RPi.GPIO','gpiod'))
assert not any(k.startswith('BLINKA_') or k in ('PYTHONPATH','PYTHONHOME') for k in os.environ)
source_paths={{}}; source_sha256={{}}; source_sizes={{}}
def add(key,path):
    assert key not in source_paths and path.is_file() and not path.is_symlink() and path.resolve()==path,key
    data=path.read_bytes(); source_paths[key]=str(path); source_sha256[key]=hashlib.sha256(data).hexdigest(); source_sizes[key]=len(data)
for key in {BLINKA_FILES!r}: add(key,site/key)
for package in ('adafruit_blinka','adafruit_blinka_raspberry_pi_pwm','gpiod','adafruit_platformdetect','packaging'):
    for path in sorted((site/package).rglob('*')):
        if not path.is_file() or path.suffix not in ('.py','.so'): continue
        key=path.relative_to(site).as_posix()
        if path.suffix=='.so':
            assert path.name.startswith(('_native.','_ext.')),str(path)
            key=(path.parent.relative_to(site)/(path.name.split('.')[0]+'.so')).as_posix()
        add(key,path)
for key,path in {preparation.RPI_SOURCES!r}.items():
    symbolic='RPi/_GPIO.so' if path and key.endswith('.so') else 'RPi/GPIO/__init__.py'
    add(symbolic,pathlib.Path(key))
parent=system/'RPi/__init__.py'
if parent.exists(): add('RPi/__init__.py',parent)
else: assert (system/'RPi').is_dir()
assert len(set(source_paths.values()))==len(source_paths)
distributions={{}}
for name,expected in {KNOWN_VERSIONS!r}.items():
    location=system if name=='RPi.GPIO' else site
    matches=[d for d in importlib.metadata.distributions(path=[str(location)]) if re.sub(r'[-_.]+','-',d.metadata['Name']).lower()==re.sub(r'[-_.]+','-',name).lower()]
    assert len(matches)==1 and matches[0].version==expected,name
    d=matches[0]; distributions[name]={{'version':d.version,'origin':str(d.locate_file('')),'requires_dist':d.metadata.get_all('Requires-Dist',[])}}
startup=[]
for directory in (site,system,pathlib.Path('/usr/local/lib/python3.13/dist-packages')):
    for path in [*directory.glob('*.pth'),directory/'sitecustomize.py',directory/'usercustomize.py']:
        if path.exists(): startup.append({{'path':str(path),'text_not_executed':path.read_text(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}})
def query(arguments):
    result=subprocess.run(arguments,capture_output=True,text=True,timeout=8,check=False,stdin=subprocess.DEVNULL)
    return {{'arguments':arguments,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}}
configs={{name:hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest() for name in {tuple(preparation.CONFIGS)!r}}}
info={{'model':pathlib.Path('/sys/firmware/devicetree/base/model').read_bytes().rstrip(b'\\x00').decode(),'kernel':platform.release(),'python_version':platform.python_version(),'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'boot_config_sha256':configs}}
assert info['boot_id']=={preparation.BOOT_ID!r} and info['boot_config_sha256']=={preparation.CONFIGS!r}
assert info['model']=='Raspberry Pi 4 Model B Rev 1.4' and info['kernel']=='6.18.50+rpt-rpi-v8' and info['python_version']=='3.13.5'
assert not any(name in sys.modules for name in ('board','pwmio','RPi.GPIO','gpiod'))
print(json.dumps({{'remote_root':str(root),'platform':info,'source_paths':source_paths,'source_sha256':source_sha256,'source_sizes':source_sizes,'distribution_metadata':distributions,'startup_files_not_executed':startup,'gpiodetect':query(['gpiodetect']),'pinctrl':[query(['pinctrl','get',str(gpio)]) for gpio in (18,23)],'all_private_versions':{{d.metadata['Name']:d.version for d in importlib.metadata.distributions(path=[str(site)])}},'no_runtime_package_import':True,'no_sudo_or_remote_write':True,'helper_not_deployed_or_imported':True}},indent=2))
"""


def source_proofs(remote, wheels):
    members = {}
    for filename in wheels:
        with zipfile.ZipFile(preparation.WHEELHOUSE / filename) as wheel:
            for member in wheel.namelist():
                if not member.endswith("/"):
                    members.setdefault(member, []).append(
                        (filename, hashlib.sha256(wheel.read(member)).hexdigest())
                    )
    checks = {}
    site = Path(ROOT) / "venv/lib/python3.13/site-packages"
    for key, filename in remote["source_paths"].items():
        path = Path(filename)
        if key.startswith("RPi/"):
            if filename not in preparation.RPI_SOURCES:
                if (
                    key != "RPi/__init__.py"
                    or filename != "/usr/lib/python3/dist-packages/RPi/__init__.py"
                ):
                    raise ValueError("Unexpected inherited system source")
                # Parent package is observational only; bootstrap pins actual driver.
                checks[key] = {"kind": "observed_system_RPi_parent_not_wheel_member"}
                continue
            if remote["source_sha256"][key] != preparation.RPI_SOURCES[filename]:
                raise ValueError("Inherited RPi.GPIO bytes changed")
            checks[key] = {"kind": "unchanged_exact_distro_RPi_GPIO"}
            continue
        member = path.relative_to(site).as_posix()
        matches = members.get(member, [])
        if len(matches) != 1 or remote["source_sha256"][key] != matches[0][1]:
            raise ValueError(
                "Private source does not match one frozen wheel member: " + key
            )
        checks[key] = {
            "kind": "exact_installed_wheel_member",
            "wheel": matches[0][0],
            "member": member,
        }
    return checks


def main():
    wheels, versions, install_sha, audit = inputs()
    code = remote_code()
    stdout, stderr = Path(str(OUTPUT) + ".stdout"), Path(str(OUTPUT) + ".stderr")
    if any(path.exists() or path.is_symlink() for path in (OUTPUT, stdout, stderr)):
        raise ValueError("Exclusive fresh inventory evidence required")
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        preparation.HOST,
        shlex.join([ROOT + "/venv/bin/python", "-I", "-S", "-"]),
    ]
    result, error, remote = None, None, None
    with (
        OUTPUT.open("x") as receipt_stream,
        stdout.open("xb") as out,
        stderr.open("xb") as err,
    ):
        try:
            result = subprocess.run(
                command,
                input=code.encode(),
                stdout=out,
                stderr=err,
                timeout=45,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt) as failure:
            error = type(failure).__name__ + ": " + str(failure)
        actual = (
            result.returncode
            if result is not None and type(result.returncode) is int
            else None
        )
        receipt = {
            "schema_version": 1,
            "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "ssh_returncode": actual,
            "error": error,
            "accepted": False,
            "recorder_sha256": digest(__file__),
            "preparer_sha256": digest(preparation.__file__),
            "install_receipt_sha256": install_sha,
            "wheel_plan_sha256": preparation.PLAN_SHA,
            "wheel_artifacts": wheels,
            "remote_command": command,
            "remote_code": code,
            "stdout_sha256": digest(stdout),
            "stderr_sha256": digest(stderr),
            "focused_dependency_closure_audit": audit,
            "whole_environment_clean": False,
        }
        try:
            if actual != 0 or error is not None:
                raise ValueError("Actual SSH0 required")
            remote = json.loads(stdout.read_text())
            receipt["remote"] = remote
            if (
                remote["remote_root"] != ROOT
                or remote["no_runtime_package_import"] is not True
                or remote["startup_files_not_executed"]
            ):
                raise ValueError("Root/import/startup gate failed")
            if {
                k: v["version"] for k, v in remote["distribution_metadata"].items()
            } != KNOWN_VERSIONS:
                raise ValueError("Selected versions mismatch")
            if remote["distribution_metadata"]["RPi.GPIO"]["requires_dist"] != []:
                raise ValueError(
                    "Unexpected inherited RPi.GPIO requirements need explicit audit"
                )
            expected = {**versions, "pip": remote["all_private_versions"].get("pip")}
            normalized = {
                key.lower().replace("_", "-").replace(".", "-"): value
                for key, value in remote["all_private_versions"].items()
            }
            if normalized != expected:
                raise ValueError("Private distribution closure mismatch")
            receipt["installed_source_checks"] = source_proofs(remote, wheels)
            receipt["helper_deployment_material"] = {
                "key": HELPER,
                "remote_path": ROOT + "/" + HELPER,
                "local_sha256": digest(LAB / HELPER),
                "not_yet_observed_remote": True,
            }
            receipt["accepted"] = True
        except Exception as failure:
            receipt["error"] = type(failure).__name__ + ": " + str(failure)
        json.dump(receipt, receipt_stream, indent=2)
        receipt_stream.write("\n")
    print(
        json.dumps(
            {
                "accepted": receipt["accepted"],
                "ssh_returncode": actual,
                "sources": len(receipt.get("installed_source_checks", {})),
                "error": receipt.get("error"),
            }
        )
    )
    return 0 if receipt["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
