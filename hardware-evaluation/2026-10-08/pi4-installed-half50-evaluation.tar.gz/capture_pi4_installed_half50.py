"""Narrow Pi4 real-Pin acquisition and untrimmed offline reconstruction.

Passive probes only: GPIO18/channel2, untouched GPIO23/channel3. Four fresh
idle captures alternate original/native order. No imports call hardware APIs.
Collection completion and descriptive waveform facts are separate from parity.
"""

import argparse
import hashlib
import json
import math
import re
import shlex
import statistics
import subprocess
import time
from itertools import pairwise
from pathlib import Path

from saleae import automation

import pi4_installed_pwm_half50_eval as helper
from capture_pwm import read_digital

DEVICE_ID = "81F8C2631DF5BF30"
HELPER = "pi4_installed_pwm_half50_eval.py"
RUNS = (
    ("oct8-pi4-installed-half50-original-r1c", "original"),
    ("oct8-pi4-installed-half50-native-r1c", "native"),
    ("oct8-pi4-installed-half50-native-r2c", "native"),
    ("oct8-pi4-installed-half50-original-r2c", "original"),
)
ROOT_PATTERN = r"/tmp/blinka-pwm-pi4-real-pin\.[a-z0-9_]{8}"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    path = Path(path).absolute()
    require(
        path.is_file() and not path.is_symlink() and path.resolve() == path,
        "Regular canonical file required: " + str(path),
    )
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result

    def nonfinite(value):
        raise ValueError("Nonfinite JSON number: " + value)

    return json.loads(
        Path(path).read_text(), object_pairs_hook=pairs, parse_constant=nonfinite
    )


def method_hashes():
    return {
        Path(__file__).name: digest(__file__),
        HELPER: digest(Path(__file__).parent / HELPER),
        "capture_pwm.py": digest(read_digital.__code__.co_filename),
    }


def validate_plan(plan, manifest, manifest_hash):
    require(
        isinstance(plan, dict) and isinstance(manifest, dict),
        "Plan/manifest objects required",
    )
    root = plan.get("remote_root")
    require(
        isinstance(root, str) and re.fullmatch(ROOT_PATTERN, root),
        "Fresh Pi4 root required",
    )
    try:
        helper.validate_manifest(manifest)
    except helper.BenchError as error:
        raise ValueError("Helper manifest contract: " + str(error)) from error
    require(
        type(plan.get("schema_version")) is int
        and plan["schema_version"] == 1
        and plan.get("capture_order") == [name for name, _backend in RUNS]
        and plan.get("capture_backends") == dict(RUNS)
        and plan.get("remote_python") == root + "/venv/bin/python"
        and plan.get("host") == "test2-pi4.local"
        and manifest["remote_root"] == root
        and plan.get("manifest_sha256") == manifest_hash
        and plan.get("method_sha256") == method_hashes()
        and manifest["source_sha256"][HELPER] == method_hashes()[HELPER]
        and plan.get("outputs")
        == [{"gpio": 18, "saleae_channel": 2}, {"gpio": 23, "saleae_channel": 3}]
        and type(plan.get("frequency")) is int
        and plan["frequency"] == 50
        and type(plan.get("duty_cycle")) is int
        and plan["duty_cycle"] == 32768
        and type(plan.get("hold_seconds")) is float
        and plan["hold_seconds"] == 3.0
        and plan.get("runtime_flags") == {"short_slice": False, "shared": False}
        and all(type(v) is bool for v in plan["runtime_flags"].values())
        and isinstance(plan.get("preflight_receipt_sha256"), str)
        and re.fullmatch(r"[0-9a-f]{64}", plan["preflight_receipt_sha256"]),
        "Frozen Pi4 source/runtime/protocol/wiring plan mismatch",
    )


def validate_remote(remote, manifest, manifest_hash, backend):
    """Bind a completed actual helper receipt, not a success-only transport shim."""
    require(isinstance(remote, dict), "Actual helper receipt required")
    root = manifest["remote_root"]
    require(
        type(remote.get("schema_version")) is int
        and remote["schema_version"] == 1
        and remote.get("mode") == helper.MODE
        and remote.get("sequence_marker") == helper.SEQUENCE_MARKER
        and remote.get("backend") == backend
        and remote.get("success") is True
        and remote.get("inspect_only") is False
        and remote.get("guarded_import_only_no_gpio_construction") is False
        and "primary_error" in remote
        and remote["primary_error"] is None
        and remote.get("cleanup_errors") == []
        and "waveform_accepted" in remote
        and remote["waveform_accepted"] is None
        and "parity_pass" in remote
        and remote["parity_pass"] is None
        and remote.get("manifest_sha256") == manifest_hash
        and remote.get("source_paths") == manifest["source_paths"]
        and remote.get("source_sha256") == manifest["source_sha256"]
        and remote.get("distribution_versions") == manifest["distribution_versions"]
        and remote.get("python_executable") == root + "/venv/bin/python"
        and remote.get("isolated_python") is True
        and remote.get("noninteractive_no_runtime_installs") is True
        and remote.get("inherited_environment") == {}
        and remote.get("runtime_flags") == {"short_slice": False, "shared": False}
        and all(type(v) is bool for v in remote["runtime_flags"].values())
        and remote.get("gpio_hooks_restored") is True
        and remote.get("native_request_hook_restored") is True
        and remote.get("bounded_python_run_confirmed") is True,
        "Helper source/version/backend/import/hooks/exit contract mismatch",
    )
    begin, end = remote.get("begin_ns"), remote.get("end_ns")
    require(
        type(remote.get("pid")) is int
        and remote["pid"] > 0
        and type(begin) is int
        and type(end) is int
        and 0 <= begin < end
        and end - begin < helper.MAX_RUN_SECONDS * 1_000_000_000,
        "Actual bounded helper PID/interval required",
    )
    metadata = remote.get("distribution_metadata_roots", {})
    require(
        isinstance(metadata, dict)
        and set(metadata) == set(manifest["distribution_versions"])
        and all(
            isinstance(path, str)
            and Path(path).is_absolute()
            and ".." not in Path(path).parts
            and (
                Path(path) == Path("/usr/lib/python3/dist-packages")
                if name == "RPi.GPIO"
                else Path(path).is_relative_to(root + "/venv")
            )
            for name, path in metadata.items()
        ),
        "Selected distribution metadata origins required",
    )
    dispatch = remote.get("installed_dispatch", {})
    expected = {
        "real_board_used": True,
        "real_pwmio_used": True,
        "virtual_pwmio_export_used": False,
        "native_pwmio_identity_verified": True,
        "unwrapped_public_pwm_objects": True,
        "original_reference": helper.ORIGINAL_MODULE + ".PWMOut",
        "board_id": "RASPBERRY_PI_4B",
        "chip_id": "BCM2XXX",
        "pin_class_module": helper.PIN_MODULE,
        "target_pin_attribute": "D18",
        "target_pin_id": 18,
        "inactive_context_pin_id": 23,
    }
    require(
        isinstance(dispatch, dict)
        and all(
            type(dispatch.get(k)) is type(v) and dispatch[k] == v
            for k, v in expected.items()
        )
        and dispatch.get("missing_platform_dependencies") in ([], ["rpi_ws281x>=4.0.0"])
        and dispatch.get("missing_neopixel_dependency_not_imported_or_installed")
        is (dispatch["missing_platform_dependencies"] != []),
        "Genuine installed dispatch/Pin/noninteractive dependency proof required",
    )
    platform_receipt = remote.get("platform_preflight", {})
    require(
        isinstance(platform_receipt, dict)
        and all(
            platform_receipt.get(k) == manifest[k]
            for k in (
                "model",
                "kernel",
                "python_version",
                "boot_id",
                "boot_config_sha256",
            )
        )
        and type(platform_receipt.get("temperature_millic")) is int
        and 0 < platform_receipt["temperature_millic"] < 55000
        and platform_receipt.get("registered_pwm_providers") == [],
        "Actual identity/config/temperature preflight required",
    )
    flags = platform_receipt.get("throttled", {})
    nodes = platform_receipt.get("live_pwm_nodes", [])
    require(
        flags.get("arguments") == ["vcgencmd", "get_throttled"]
        and type(flags.get("returncode")) is int
        and flags["returncode"] == 0
        and flags.get("stdout", "").strip() == "throttled=0x0"
        and len(nodes) == 2
        and {n.get("of_node") for n in nodes}
        == {
            "/sys/firmware/devicetree/base/soc/pwm@7e20c800",
            "/sys/firmware/devicetree/base/soc/pwm@7e20c000",
        }
        and all(n.get("status") == "disabled" for n in nodes),
        "Actual flags/disabled PWM providers required",
    )
    for key in (
        "free_lines_preimport",
        "free_lines_postimport",
        "free_lines_after_public_and_lab_cleanup",
    ):
        fact = remote.get(key, {})
        require(
            fact.get("chip")
            == {k: manifest["controller"][k] for k in ("name", "label", "num_lines")}
            and fact.get("read_only_chip_closed") is True
            and fact.get("rpi_gpio_mmap_exclusivity_not_proved") is True
            and isinstance(fact.get("lines"), list)
            and len(fact["lines"]) == 2
            and all(
                type(row.get("offset")) is int
                and row["offset"] == gpio
                and row.get("name") == f"GPIO{gpio}"
                and row.get("used") is False
                and row.get("consumer") in (None, "")
                and row.get("direction")
                in (("INPUT", "OUTPUT") if gpio == 18 else ("INPUT",))
                for row, gpio in zip(fact["lines"], (18, 23))
            ),
            "Actual free GPIO18/23 cleanup proof required: " + key,
        )
    boundaries = (
        "platform_preflight",
        "postimport",
        "initial_low",
        "commanded_low",
        "release",
        "quiet_release_end",
    )
    require(
        remote.get("boundary_low_confirmations") == dict.fromkeys(boundaries, True)
        and all(v is True for v in remote["boundary_low_confirmations"].values()),
        "All physical LOW boundary confirmations required",
    )
    pin_rows = remote.get("pin_boundaries", [])
    require(len(pin_rows) == len(boundaries), "Complete pin boundary queries required")
    for row, name in zip(pin_rows, boundaries):
        queries = row.get("queries", [])
        require(
            row.get("boundary") == name
            and len(queries) == 2
            and all(
                q.get("arguments") == ["pinctrl", "get", str(gpio)]
                and type(q.get("returncode")) is int
                and q["returncode"] == 0
                for q, gpio in zip(queries, (18, 23))
            )
            and re.fullmatch(
                helper.GPIO18_LOW_PATTERN,
                queries[0].get("stdout", ""),
            )
            and queries[1].get("stdout") == manifest["sibling_pinctrl_stdout"],
            "Actual LOW/untouched-sibling pin queries required",
        )
    phases = remote.get("phases", [])
    require(
        len(phases) == len(helper.SEQUENCE),
        "Complete finite four-phase protocol required",
    )
    previous = begin
    for phase, (name, duty, duration) in zip(phases, helper.SEQUENCE):
        pbegin, pend = phase.get("begin_ns"), phase.get("end_ns")
        require(
            phase.get("name") == name
            and type(phase.get("duty_u16")) is type(duty)
            and phase["duty_u16"] == duty
            and type(phase.get("duration_seconds")) is float
            and phase["duration_seconds"] == duration
            and type(pbegin) is int
            and type(pend) is int
            and previous <= pbegin < pend <= end,
            "Declared ordered helper phases/intervals required",
        )
        if duty is not None:
            stamps = [
                phase.get(k)
                for k in ("api_readback_ns", "wait_begin_ns", "wait_end_ns")
            ]
            require(
                all(type(t) is int for t in stamps)
                and pbegin <= stamps[0] <= stamps[1] < stamps[2] <= pend
                and stamps[2] - stamps[1] >= int(duration * 1_000_000_000)
                and phase.get("api_readback")
                == {"frequency": 50, "duty_u16": duty, "pin_id": 18},
                "Fixed API readback and full declared wait required",
            )
            if duty == 0:
                require(
                    type(phase.get("settled_low_confirmation_ns")) is int
                    and stamps[2] <= phase["settled_low_confirmation_ns"] <= pend,
                    "LOW confirmation must follow settle",
                )
        else:
            require(
                pend - pbegin >= int(duration * 1_000_000_000),
                "Full quiet-release wait required",
            )
        previous = pend
    events = remote.get("events", [])
    expected_events = [
        ("PWMOut.__init__", backend + ":constructor"),
        ("PWMOut.duty_cycle", backend + ":half50"),
        ("PWMOut.duty_cycle", backend + ":commanded_low"),
        ("PWMOut.deinit", backend + ":public_deinit"),
    ]
    if backend == "native":
        expected_events = [
            ("gpiod.request_lines", "native:constructor"),
            expected_events[0],
            ("owned_request.get_value", "native:initial_low"),
            *expected_events[1:3],
            ("owned_request.set_value(low)", "native:lab_owned_low"),
            ("owned_request.get_value", "native:lab_owned_read"),
            expected_events[-1],
        ]
        require(
            all(
                remote.get(k) is True
                for k in (
                    "native_initial_low_confirmed",
                    "native_private_low_confirmed",
                    "native_request_released",
                )
            ),
            "Private native initial/settled LOW and release required",
        )
    require(
        [(e.get("operation"), e.get("scope")) for e in events] == expected_events
        and all(
            e.get("status") == "ok"
            and type(e.get("begin_ns")) is int
            and type(e.get("end_ns")) is int
            and begin <= e["begin_ns"] <= e["end_ns"] <= end
            for e in events
        ),
        "Exact successful public/scoped helper actions required",
    )
    ctor = events[1] if backend == "native" else events[0]
    require(
        ctor.get("arguments")
        == {
            "pin_attribute": "board.D18",
            "pin_id": 18,
            "frequency": 50,
            "duty_u16": 0,
            "variable_frequency": False,
        }
        and ctor["end_ns"] <= phases[0]["begin_ns"]
        and events[-1]["begin_ns"] >= phases[2]["end_ns"]
        and events[-1]["end_ns"] <= phases[3]["begin_ns"],
        "Public construction/deinit must bracket finite phases",
    )
    duties = [e for e in events if e["operation"] == "PWMOut.duty_cycle"]
    require(
        [e.get("arguments") for e in duties] == [{"duty_u16": 32768}, {"duty_u16": 0}]
        and all(
            p["begin_ns"] <= e["begin_ns"] <= e["end_ns"] <= p["api_readback_ns"]
            for e, p in zip(duties, phases[1:3])
        ),
        "Actual half/zero public setters must match phase receipts",
    )
    if backend == "native":
        require(
            events[0].get("arguments")
            == {
                "path": manifest["controller"]["path"],
                "consumer": "adafruit-blinka-pwm",
                "offsets": [18],
            }
            and ctor["begin_ns"]
            <= events[0]["begin_ns"]
            <= events[0]["end_ns"]
            <= ctor["end_ns"]
            and ctor["end_ns"]
            <= events[2]["begin_ns"]
            <= events[2]["end_ns"]
            <= phases[0]["begin_ns"]
            and phases[2]["end_ns"]
            <= events[5]["begin_ns"]
            <= events[5]["end_ns"]
            <= events[6]["begin_ns"]
            <= events[6]["end_ns"]
            <= events[7]["begin_ns"],
            "Exact native private request/LOW-read/public-release ordering required",
        )
    calls = remote.get("gpio_calls", [])
    expected_calls = [
        ("GPIO.setmode", "imports", [11]),
        ("GPIO.setwarnings", "imports", [False]),
    ] * 2
    if backend == "original":
        expected_calls += [
            ("GPIO.setup", "original:constructor", [18, 0]),
            ("GPIO.PWM", "original:constructor", [18, 50]),
            ("GPIO.cleanup", "original:public_deinit", [18]),
        ]
        require(
            "original_lab_cleanup_basis" not in remote,
            "Failed-init lab cleanup is not normal public deinit proof",
        )
    require(
        [
            (c.get("operation"), c.get("scope"), c.get("arguments", {}).get("args"))
            for c in calls
        ]
        == expected_calls
        and all(
            c.get("attempted") is True
            and c.get("permitted") is True
            and c.get("success") is True
            and c.get("arguments", {}).get("kwargs") == {}
            and type(c.get("begin_ns")) is int
            and type(c.get("end_ns")) is int
            and begin <= c["begin_ns"] <= c["end_ns"] <= end
            for c in calls
        ),
        "Exact scoped GPIO calls/public-only target18 cleanup required",
    )
    require(
        all(c["end_ns"] <= ctor["begin_ns"] for c in calls[:4]),
        "GPIO metadata imports must precede construction",
    )
    if backend == "original":
        require(
            all(
                ctor["begin_ns"] <= c["begin_ns"] <= c["end_ns"] <= ctor["end_ns"]
                for c in calls[4:6]
            )
            and events[-1]["begin_ns"]
            <= calls[6]["begin_ns"]
            <= calls[6]["end_ns"]
            <= events[-1]["end_ns"],
            "Target18 setup/PWM and cleanup must be inside actual public calls",
        )


def artifact_provenance(directory, names):
    result = {}
    for name in names:
        path = Path(directory) / name
        sha = digest(path)
        size = path.stat().st_size
        require(size > 0, "Nonempty saved artifact required: " + name)
        result[name] = {"sha256": sha, "bytes": size}
    return result


def validate_inputs(directory, plan_path, manifest_path):
    directory = Path(directory).absolute()
    require(directory.resolve() == directory, "Output cannot traverse links")
    require(not directory.exists(), "Exclusive new capture directory required")
    plan_path, manifest_path = Path(plan_path), Path(manifest_path)
    plan_hash, manifest_hash = digest(plan_path), digest(manifest_path)
    plan, manifest = read_json(plan_path), read_json(manifest_path)
    validate_plan(plan, manifest, manifest_hash)
    require(directory.name in dict(RUNS), "Only predeclared capture labels allowed")
    preflight = Path(plan.get("preflight_receipt_path", ""))
    require(
        digest(preflight) == plan.get("preflight_receipt_sha256"),
        "Unchanged successful preflight required",
    )
    receipt = read_json(preflight)
    require(
        receipt.get("accepted") is True
        and type(receipt.get("ssh_returncode")) is int
        and receipt["ssh_returncode"] == 0,
        "Actual successful preflight required",
    )
    return directory, plan, manifest, plan_hash, manifest_hash


def collect(directory, plan_path, manifest_path):
    output, plan, manifest, plan_hash, manifest_hash = validate_inputs(
        directory, plan_path, manifest_path
    )
    output.mkdir(parents=True, exist_ok=False)
    for name, path in (("plan.json", plan_path), ("manifest.json", manifest_path)):
        with (output / name).open("xb") as stream:
            stream.write(Path(path).read_bytes())
    backend, root = dict(RUNS)[output.name], plan["remote_root"]
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test2-pi4.local",
        shlex.join(
            [
                plan["remote_python"],
                "-I",
                root + "/" + HELPER,
                "--manifest",
                root + "/manifest.json",
                "--backend",
                backend,
            ]
        ),
    ]
    remote, primary, version = None, None, None
    evidence_errors = []
    with (
        (output / "remote.stdout").open("x") as stdout,
        (output / "remote.stderr").open("x") as stderr,
    ):
        try:
            with automation.Manager.connect(
                port=10430, connect_timeout_seconds=5
            ) as manager:
                require(
                    any(
                        d.device_id == DEVICE_ID and not d.is_simulation
                        for d in manager.get_devices()
                    ),
                    "Physical Logic8 required",
                )
                version = manager.get_app_info().app_version
                config = automation.LogicDeviceConfiguration(
                    enabled_digital_channels=[2, 3],
                    digital_sample_rate=100_000_000,
                    glitch_filters=[],
                )
                with manager.start_capture(
                    device_id=DEVICE_ID, device_configuration=config
                ) as capture:
                    try:
                        time.sleep(0.5)
                        remote = subprocess.run(
                            command,
                            stdin=subprocess.DEVNULL,
                            stdout=stdout,
                            stderr=stderr,
                            timeout=25,
                            check=False,
                        )
                    except BaseException as error:  # noqa: BLE001 - drain/preserve on interrupt too
                        primary = type(error).__name__ + ": " + str(error)
                    finally:
                        for name, operation in (
                            ("tail", lambda: time.sleep(0.2)),
                            ("stop", capture.stop),
                            (
                                "save",
                                lambda: capture.save_capture(
                                    str(output / "waveform.sal")
                                ),
                            ),
                            (
                                "export",
                                lambda: capture.export_raw_data_binary(
                                    str(output), digital_channels=[2, 3]
                                ),
                            ),
                        ):
                            try:
                                operation()
                            except BaseException as error:  # noqa: BLE001 - attempt every evidence cleanup on interrupt
                                evidence_errors.append(
                                    {
                                        "operation": name,
                                        "error": type(error).__name__
                                        + ": "
                                        + str(error),
                                    }
                                )
        except BaseException as error:  # noqa: BLE001 - retain outer SDK/interrupt failure after cleanup
            if primary is None:
                primary = type(error).__name__ + ": " + str(error)
    actual = (
        remote.returncode
        if remote is not None and type(remote.returncode) is int
        else None
    )
    parsed = None
    try:
        parsed = read_json(output / "remote.stdout")
    except (ValueError, OSError) as error:
        evidence_errors.append(
            {
                "operation": "parse_helper",
                "error": type(error).__name__ + ": " + str(error),
            }
        )
    receipt_validated = False
    if parsed is not None:
        try:
            validate_remote(parsed, manifest, manifest_hash, backend)
            receipt_validated = True
        except (ValueError, TypeError, KeyError, AttributeError) as error:
            evidence_errors.append(
                {
                    "operation": "validate_helper",
                    "error": type(error).__name__ + ": " + str(error),
                }
            )
    artifacts = {}
    for name in ("waveform.sal", "digital_2.bin", "digital_3.bin"):
        try:
            artifacts.update(artifact_provenance(output, (name,)))
        except (ValueError, OSError) as error:
            evidence_errors.append(
                {
                    "operation": "saved_file:" + name,
                    "error": type(error).__name__ + ": " + str(error),
                }
            )
    for name in ("remote.stdout", "remote.stderr"):
        artifacts[name] = {
            "sha256": digest(output / name),
            "bytes": (output / name).stat().st_size,
        }
    success = (
        primary is None and not evidence_errors and actual == 0 and receipt_validated
    )
    acquisition = {
        "schema_version": 1,
        "physical_device_id": DEVICE_ID,
        "logic_version": version,
        "requested_sample_rate_hz": 100_000_000,
        "enabled_digital_channels": [2, 3],
        "glitch_filters": [],
        "lead_seconds": 0.5,
        "tail_seconds": 0.2,
        "actual_ssh_returncode": actual,
        "command": command,
        "primary_error": primary,
        "evidence_errors": evidence_errors,
        "artifact_provenance": artifacts,
        "helper_receipt_validated": receipt_validated,
    }
    write_new(output / "acquisition.json", acquisition)
    result = {
        "schema_version": 1,
        "capture": output.name,
        "backend": backend,
        "plan_sha256": plan_hash,
        "manifest_sha256": manifest_hash,
        "preflight_receipt_sha256": plan["preflight_receipt_sha256"],
        "method_sha256": method_hashes(),
        "acquisition": acquisition,
        "remote": parsed,
        "collection_success": success,
        "parity_pass": None,
        "waveform_accepted": None,
        "passive_probes_only": True,
    }
    write_new(output / "results.json", result)
    require(
        success, "Collection failed; all available evidence preserved: " + output.name
    )
    print(
        json.dumps(
            {
                "capture": output.name,
                "collection_success": True,
                "actual_ssh_returncode": actual,
            }
        )
    )
    return 0


def describe(values):
    if not values:
        return {"count": 0}
    ordered = sorted(values)
    return {
        "count": len(values),
        "min": ordered[0],
        "median": statistics.median(values),
        "mean": statistics.mean(values),
        "p95": ordered[math.ceil(len(values) * 0.95) - 1],
        "p99": ordered[math.ceil(len(values) * 0.99) - 1],
        "max": ordered[-1],
    }


def reconstruct(path, target_high_us):
    version, chunks = read_digital(Path(path))
    rows = []
    for initial, begin, end, sample_rate, times in chunks:
        rises = list(times[0 if initial == 0 else 1 :: 2])
        falls = list(times[1 if initial == 0 else 0 :: 2])
        highs = [
            [rise, fall] for rise, fall in zip(rises, falls[1:] if initial else falls)
        ]
        lows = [
            [fall, rise]
            for fall, rise in zip(falls, rises[1:] if not initial else rises)
        ]
        widths = [(fall - rise) * 1e6 for rise, fall in highs]
        final = initial ^ (len(times) % 2)
        periods = [(b - a) * 1e6 for a, b in pairwise(rises)]
        rows.append(
            {
                "initial_level": initial,
                "final_level": final,
                "begin_s": begin,
                "end_s": end,
                "sample_rate_in_export": sample_rate,
                "edges_s": list(times),
                "complete_high_intervals_s": highs,
                "complete_low_intervals_s": lows,
                "highs_us": widths,
                "lows_us": [(b - a) * 1e6 for a, b in lows],
                "rise_periods_us": periods,
                "high_summary_us": describe(widths),
                "period_summary_us": describe(periods),
                "absolute_high_error_summary_us": describe(
                    [abs(h - target_high_us) for h in widths]
                ),
                "initial_boundary": {
                    "level": initial,
                    "begin_s": begin,
                    "end_s": times[0] if times else end,
                },
                "final_boundary": {
                    "level": final,
                    "begin_s": times[-1] if times else begin,
                    "end_s": end,
                },
                "quiet_low_tail_seconds": end - (times[-1] if times else begin)
                if final == 0
                else None,
            }
        )
    return {
        "binary_format_version": version,
        "raw_sha256": digest(path),
        "chunks": rows,
        "no_interval_trimming_or_filtering": True,
    }


def analyze(directory):
    directory = Path(directory).absolute()
    require(directory.resolve() == directory, "Offline directory cannot traverse links")
    result = read_json(directory / "results.json")
    backend = dict(RUNS).get(directory.name)
    require(
        backend in ("original", "native")
        and backend == result.get("backend")
        and result.get("capture") == directory.name
        and result.get("collection_success") is True
        and type(result.get("schema_version")) is int
        and result["schema_version"] == 1
        and "parity_pass" in result
        and result["parity_pass"] is None
        and "waveform_accepted" in result
        and result["waveform_accepted"] is None,
        "Accepted predeclared capture required",
    )
    plan, manifest = (
        read_json(directory / "plan.json"),
        read_json(directory / "manifest.json"),
    )
    manifest_hash = digest(directory / "manifest.json")
    validate_plan(plan, manifest, manifest_hash)
    acquisition = read_json(directory / "acquisition.json")
    require(
        result.get("plan_sha256") == digest(directory / "plan.json")
        and result.get("manifest_sha256") == manifest_hash
        and result.get("method_sha256") == method_hashes()
        and result.get("preflight_receipt_sha256") == plan["preflight_receipt_sha256"]
        and result.get("acquisition") == acquisition
        and acquisition.get("helper_receipt_validated") is True
        and type(acquisition.get("actual_ssh_returncode")) is int
        and acquisition["actual_ssh_returncode"] == 0
        and "primary_error" in acquisition
        and acquisition["primary_error"] is None
        and acquisition.get("evidence_errors") == []
        and acquisition.get("physical_device_id") == DEVICE_ID
        and acquisition.get("requested_sample_rate_hz") == 100_000_000
        and acquisition.get("enabled_digital_channels") == [2, 3]
        and acquisition.get("glitch_filters") == []
        and acquisition.get("lead_seconds") == 0.5
        and acquisition.get("tail_seconds") == 0.2,
        "Offline saved plan/manifest/method/acquisition/actual-exit provenance mismatch",
    )
    command = [
        plan["remote_python"],
        "-I",
        plan["remote_root"] + "/" + HELPER,
        "--manifest",
        plan["remote_root"] + "/manifest.json",
        "--backend",
        backend,
    ]
    require(
        acquisition.get("command")
        == [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test2-pi4.local",
            shlex.join(command),
        ],
        "Offline actual recorded command mismatch",
    )
    remote = read_json(directory / "remote.stdout")
    require(
        result.get("remote") == remote, "Saved stdout/embedded helper receipt mismatch"
    )
    validate_remote(remote, manifest, manifest_hash, backend)
    expected = artifact_provenance(
        directory, ("waveform.sal", "digital_2.bin", "digital_3.bin")
    )
    for name in ("remote.stdout", "remote.stderr"):
        expected[name] = {
            "sha256": digest(directory / name),
            "bytes": (directory / name).stat().st_size,
        }
    require(
        acquisition.get("artifact_provenance") == expected,
        "Offline saved artifact bytes/provenance mismatch",
    )
    target = 10000.0 if backend == "original" else 10000.153
    channels = {
        str(channel): reconstruct(directory / f"digital_{channel}.bin", target)
        for channel in (2, 3)
    }
    main, peer = channels["2"]["chunks"], channels["3"]["chunks"]
    supported = (
        len(main) == len(peer) == 1
        and main[0]["initial_level"] == main[0]["final_level"] == 0
        and bool(main[0]["highs_us"])
        and main[0]["quiet_low_tail_seconds"] > 0.1
        and peer[0]["initial_level"] == peer[0]["final_level"] == 0
        and not peer[0]["edges_s"]
    )
    return {
        "schema_version": 1,
        "capture": directory.name,
        "backend": backend,
        "results_sha256": digest(directory / "results.json"),
        "target_high_us": target,
        "nominal_period_us": 20000.0,
        "channels": channels,
        "single_train_with_untouched_low_peer_supported": supported,
        "parity_pass": None,
        "electrical_and_pi_clocks_aligned": False,
        "scope": "Every complete interval and both boundaries retained. Finite idle real-Pin fixed50Hz descriptive evidence; no actuator, calibrated latency, whole-Blinka or quantitative parity verdict.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="operation", required=True)
    live = sub.add_parser("capture")
    live.add_argument("directory", type=Path)
    live.add_argument("--plan", type=Path, required=True)
    live.add_argument("--manifest", type=Path, required=True)
    offline = sub.add_parser("analyze")
    offline.add_argument("directory", type=Path)
    offline.add_argument("--output-name", default="half50-analysis.json")
    args = parser.parse_args(argv)
    if args.operation == "capture":
        return collect(args.directory, args.plan, args.manifest)
    require(
        Path(args.output_name).name == args.output_name
        and args.output_name not in ("", ".", ".."),
        "Exclusive plain output filename required",
    )
    write_new(args.directory / args.output_name, analyze(args.directory))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
