"""Offline Pi4 half50 audit with an independent Saleae v0 binary decoder.

No collector/parser/backend imports, subprocesses, hardware, SDK or network.
Every edge and interval is retained. Output creation is exclusive.
"""

import argparse
import hashlib
import json
import math
import re
import statistics
import struct
import tarfile
import zipfile
from pathlib import Path

FINAL_RUNS = (
    ("oct8-pi4-installed-half50-original-r1c", "original"),
    ("oct8-pi4-installed-half50-native-r1c", "native"),
    ("oct8-pi4-installed-half50-native-r2c", "native"),
    ("oct8-pi4-installed-half50-original-r2c", "original"),
)
OLDER_RUNS = (
    ("oct8-pi4-installed-half50-original-r1b", "original", True, "second"),
    ("oct8-pi4-installed-half50-original-r1", "original", False, "first"),
    ("oct8-pi4-installed-half50-native-r1b", "native", False, "second"),
)
ARCHIVES = {
    "first": (
        "oct8-pi4-first-failed-capture-method.tar.gz",
        "6ddb15b17fb50c267480a379d52e48a2ca5cf7a41e708057936eb24e1eeb337c",
    ),
    "second": (
        "oct8-pi4-second-failed-capture-method.tar.gz",
        "c5eee53fa1ff2aafe96754d19bfab67561c916f96685e12e2f79c4028a1e08ce",
    ),
}
METHODS = (
    "pi4_installed_pwm_half50_eval.py",
    "capture_pi4_installed_half50.py",
    "capture_pwm.py",
)
SEQUENCE = (
    ("initial_low", 0, 0.2),
    ("half50", 32768, 3.0),
    ("commanded_low", 0, 0.2),
    ("quiet_release", None, 0.2),
)
BOUNDARIES = (
    "platform_preflight",
    "postimport",
    "initial_low",
    "commanded_low",
    "release",
    "quiet_release_end",
)
LOW_PATTERN = (
    r"18: (?:ip +(?:pd|pu|pn) \| lo // GPIO18 = input"
    r"|op -- (?:pd|pu|pn) \| lo // GPIO18 = output)\n"
)
TOLERANCE = 1e-8


def regular_bytes(path, allow_empty=False):
    path = Path(path).absolute()
    if not path.is_file() or path.is_symlink() or path.resolve() != path:
        raise ValueError("Canonical regular file required: " + str(path))
    value = path.read_bytes()
    if not allow_empty and not value:
        raise ValueError("Nonempty file required: " + str(path))
    return value


def sha(value):
    return hashlib.sha256(value).hexdigest()


def load_bytes(value):
    def pairs(items):
        result = {}
        for key, item in items:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = item
        return result

    def reject(value):
        raise ValueError("Nonfinite JSON number: " + value)

    return json.loads(value, object_pairs_hook=pairs, parse_constant=reject)


def summary(values):
    if not values:
        return {"count": 0}
    ordered = sorted(values)
    return {
        "count": len(ordered),
        "min": ordered[0],
        "median": statistics.median(ordered),
        "mean": statistics.mean(ordered),
        "p95": ordered[math.ceil(0.95 * len(ordered)) - 1],
        "p99": ordered[math.ceil(0.99 * len(ordered)) - 1],
        "max": ordered[-1],
    }


def decode_v0(raw, target):
    """Decode global header and repeated chunks, toggling each segment's level."""
    if len(raw) < 44:
        raise ValueError("Truncated v0 binary")
    signature, version, kind = struct.unpack_from("<8sii", raw)
    if (signature, version, kind) != (b"<SALEAE>", 0, 0):
        raise ValueError("Only actual Saleae digital v0 exports are in scope")
    cursor, chunks, details = 16, [], []
    while cursor < len(raw):
        if len(raw) - cursor < 28:
            raise ValueError("Truncated chunk header")
        initial, begin, end, count = struct.unpack_from("<IddQ", raw, cursor)
        cursor += 28
        if initial not in (0, 1) or not math.isfinite(begin + end) or begin > end:
            raise ValueError("Invalid binary chunk state/extent")
        if count > (len(raw) - cursor) // 8:
            raise ValueError("Truncated transition array")
        edges = list(struct.unpack_from(f"<{count}d", raw, cursor))
        cursor += count * 8
        previous = begin
        for edge in edges:
            if not math.isfinite(edge) or not previous <= edge <= end:
                raise ValueError("Nonfinite/out-of-order/out-of-extent transition")
            previous = edge
        endpoints = [begin, *edges, end]
        segments, rises = [], []
        for index in range(len(endpoints) - 1):
            level = initial ^ (index & 1)
            segments.append(
                {
                    "level": level,
                    "begin_s": endpoints[index],
                    "end_s": endpoints[index + 1],
                    "duration_us": (endpoints[index + 1] - endpoints[index]) * 1e6,
                    "both_endpoints_are_transitions": 0 < index < len(edges),
                }
            )
            if index < len(edges) and level == 0:
                rises.append(edges[index])
        complete = [s for s in segments if s["both_endpoints_are_transitions"]]
        highs = [[s["begin_s"], s["end_s"]] for s in complete if s["level"] == 1]
        lows = [[s["begin_s"], s["end_s"]] for s in complete if s["level"] == 0]
        widths = [(stop - start) * 1e6 for start, stop in highs]
        low_widths = [(stop - start) * 1e6 for start, stop in lows]
        periods = [(rises[i] - rises[i - 1]) * 1e6 for i in range(1, len(rises))]
        first, last = segments[0], segments[-1]
        row = {
            "initial_level": initial,
            "final_level": initial ^ (len(edges) & 1),
            "begin_s": begin,
            "end_s": end,
            "sample_rate_in_export": None,
            "edges_s": edges,
            "complete_high_intervals_s": highs,
            "complete_low_intervals_s": lows,
            "highs_us": widths,
            "lows_us": low_widths,
            "rise_periods_us": periods,
            "high_summary_us": summary(widths),
            "period_summary_us": summary(periods),
            "absolute_high_error_summary_us": summary(
                [abs(w - target) for w in widths]
            ),
            "initial_boundary": {k: first[k] for k in ("level", "begin_s", "end_s")},
            "final_boundary": {k: last[k] for k in ("level", "begin_s", "end_s")},
            "quiet_low_tail_seconds": last["end_s"] - last["begin_s"]
            if last["level"] == 0
            else 0.0,
        }
        chunks.append(row)
        details.append(
            {
                "transition_count": count,
                "rise_count": len(rises),
                "rises_s": rises,
                "all_segments_including_censored_boundaries": segments,
                "low_summary_us": summary(low_widths),
                "absolute_period_error_summary_us": summary(
                    [abs(p - 20000.0) for p in periods]
                ),
                "signed_high_error_summary_us": summary([w - target for w in widths]),
                "zero_duration_segment_indices": [
                    i for i, s in enumerate(segments) if s["duration_us"] == 0
                ],
            }
        )
    return {"binary_format_version": version, "chunks": chunks}, details


class Checks:
    def __init__(self):
        self.rows = []
        self.comparison_leaf_count = 0
        self.differences = []

    def check(self, label, condition):
        self.rows.append({"check": label, "ok": bool(condition)})

    def compare(self, expected, observed, path):
        if isinstance(expected, dict) and isinstance(observed, dict):
            if set(expected) != set(observed):
                self.differences.append(
                    {
                        "path": path + ".keys",
                        "expected": list(expected),
                        "observed": list(observed),
                    }
                )
            for key in expected.keys() & observed.keys():
                self.compare(expected[key], observed[key], path + "." + str(key))
        elif isinstance(expected, list) and isinstance(observed, list):
            if len(expected) != len(observed):
                self.differences.append(
                    {
                        "path": path + ".length",
                        "expected": len(expected),
                        "observed": len(observed),
                    }
                )
            for index, (left, right) in enumerate(zip(expected, observed)):
                self.compare(left, right, path + f"[{index}]")
        else:
            self.comparison_leaf_count += 1
            ok = type(expected) is type(observed) and expected == observed
            if isinstance(expected, float) and type(observed) in (int, float):
                ok = math.isfinite(observed) and abs(expected - observed) <= TOLERANCE
            if not ok:
                self.differences.append(
                    {"path": path, "expected": expected, "observed": observed}
                )


def archive_methods(base, checks):
    result = {}
    for key, (name, expected) in ARCHIVES.items():
        raw = regular_bytes(base / name)
        checks.check("checkpoint SHA256: " + name, sha(raw) == expected)
        with tarfile.open(base / name, "r:gz") as archive:
            members = archive.getmembers()
            names = [m.name for m in members]
            if len(set(names)) != len(names) or any(
                not m.isfile()
                or Path(m.name).is_absolute()
                or ".." in Path(m.name).parts
                for m in members
            ):
                raise ValueError("Unsafe/nonregular checkpoint member")
            hashes = {
                m.name: sha(archive.extractfile(m).read())
                for m in members
                if m.name in METHODS
            }
        hashes["capture_pwm.py"] = sha(regular_bytes(base / "capture_pwm.py"))
        result[key] = {
            "path": str(base / name),
            "sha256": sha(raw),
            "method_sha256": hashes,
        }
    return result


def sal_metadata(path, checks):
    with zipfile.ZipFile(path) as saved:
        if len(saved.namelist()) != len(set(saved.namelist())):
            raise ValueError("Duplicate SAL members")
        meta_raw = saved.read("meta.json")
    meta = load_bytes(meta_raw)
    device = meta["data"]["legacyDevice"]
    settings = meta["data"]["legacySettings"]
    identity = f"{int(device['deviceId']):016X}"
    checks.check(
        "SAL physical Logic8/device ID",
        identity == "81F8C2631DF5BF30"
        and device["capabilities"]["isPhysicalDevice"] is True
        and device["isSimulation"] is False
        and device["deviceType"] == "Logic8",
    )
    checks.check(
        "SAL channel2/3 100MSa/s no filters",
        settings
        == {
            "enabledChannels": [
                {"type": "Digital", "index": 2},
                {"type": "Digital", "index": 3},
            ],
            "sampleRate": {"digital": 100000000},
            "glitchFilter": {"enabled": False, "channels": []},
        },
    )
    checks.check(
        "SAL no trimming",
        meta["data"]["captureSettings"]["commonCaptureSettings"]["trimAfterCapture"]
        is False,
    )
    checks.check(
        "SAL binData maps channel2/3",
        [(r["deviceChannel"], r["file"]) for r in meta["binData"]]
        == [(2, "./digital-2.bin"), (3, "./digital-3.bin")],
    )
    return {
        "meta_json_sha256": sha(meta_raw),
        "device_id_hex": identity,
        "device_type": device["deviceType"],
        "is_simulation": device["isSimulation"],
        "legacy_settings": settings,
        "bin_data": meta["binData"],
    }


def receipt_checks(
    remote, results, acquisition, manifest, plan, hashes, successful, backend, checks
):
    checks.check(
        "actual SSH exit is typed and expected",
        type(acquisition["actual_ssh_returncode"]) is int
        and acquisition["actual_ssh_returncode"] == (0 if successful else 1),
    )
    checks.check(
        "actual helper/collection success",
        remote["success"] is successful and results["collection_success"] is successful,
    )
    checks.check(
        "helper backend/mode/protocol",
        remote["backend"] == backend
        and results["backend"] == backend
        and remote["mode"] == "pi4-installed-real-pin-half50"
        and remote["sequence_marker"] == "pi4-real-pin-fixed50-half-v1",
    )
    checks.check(
        "manifest actual receipt hash",
        remote["manifest_sha256"]
        == results["manifest_sha256"]
        == hashes["manifest.json"]["sha256"],
    )
    checks.check(
        "plan actual bytes hash",
        results["plan_sha256"] == hashes["plan.json"]["sha256"],
    )
    checks.check(
        "manifest helper source bound to collector source pin",
        manifest["source_sha256"][METHODS[0]] == results["method_sha256"][METHODS[0]],
    )
    checks.check(
        "recorded method pins match plan",
        results["method_sha256"] == plan["method_sha256"],
    )
    checks.check(
        "actual selected source key sets",
        set(remote["source_paths"])
        == set(remote["source_sha256"])
        == set(manifest["source_paths"])
        == set(manifest["source_sha256"]),
    )
    mismatched_sources = []
    for key in sorted(manifest["source_paths"]):
        path, digest = remote["source_paths"].get(key), remote["source_sha256"].get(key)
        valid = (
            path == manifest["source_paths"][key]
            and digest == manifest["source_sha256"][key]
            and isinstance(digest, str)
            and re.fullmatch(r"[0-9a-f]{64}", digest) is not None
        )
        if not valid:
            mismatched_sources.append(key)
    checks.check("every selected source path/hash binds manifest", not mismatched_sources)
    sources = {
        "selected_source_count": len(manifest["source_paths"]),
        "mismatched_sources": mismatched_sources,
        "actual_recorded_source_sha256_map_fingerprint": sha(
            json.dumps(remote["source_sha256"], sort_keys=True).encode()
        ),
        "actual_recorded_source_path_map_fingerprint": sha(
            json.dumps(remote["source_paths"], sort_keys=True).encode()
        ),
        "critical_actual_source_fingerprints": {
            key: {
                "path": remote["source_paths"][key],
                "sha256": remote["source_sha256"][key],
            }
            for key in remote["source_paths"]
            if key == METHODS[0]
            or key in ("board.py", "pwmio.py")
            or key.startswith("RPi/")
            or key.startswith("adafruit_blinka_raspberry_pi_pwm/")
        },
    }
    checks.check(
        "distribution versions bind manifest",
        remote["distribution_versions"] == manifest["distribution_versions"],
    )
    checks.check(
        "isolated noninteractive unchanged runtime flags",
        remote["isolated_python"] is True
        and remote["noninteractive_no_runtime_installs"] is True
        and remote["runtime_flags"] == {"short_slice": False, "shared": False}
        and remote["python_executable"] == plan["remote_python"],
    )
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test2-pi4.local",
        f"{plan['remote_python']} -I {plan['remote_root']}/{METHODS[0]} --manifest {plan['remote_root']}/manifest.json --backend {backend}",
    ]
    checks.check(
        "recorded actual command binds root/Python/backend",
        acquisition["command"] == command,
    )
    platform = remote["platform_preflight"]
    checks.check(
        "platform boot/model/kernel/Python/config bind manifest",
        all(
            platform[key] == manifest[key]
            for key in (
                "model",
                "kernel",
                "python_version",
                "boot_id",
                "boot_config_sha256",
            )
        ),
    )
    checks.check(
        "platform no throttle or PWM providers",
        platform["throttled"]["returncode"] == 0
        and platform["throttled"]["stdout"] == "throttled=0x0\n"
        and platform["registered_pwm_providers"] == []
        and all(row["status"] == "disabled" for row in platform["live_pwm_nodes"]),
    )
    dispatch = remote["installed_dispatch"]
    checks.check(
        "real Pin/native dispatch not shim",
        all(
            dispatch[key] is True
            for key in (
                "real_board_used",
                "real_pwmio_used",
                "native_pwmio_identity_verified",
                "unwrapped_public_pwm_objects",
            )
        )
        and dispatch["virtual_pwmio_export_used"] is False
        and dispatch["target_pin_id"] == 18
        and dispatch["inactive_context_pin_id"] == 23
        and dispatch["pin_class_module"]
        == "adafruit_blinka.microcontroller.generic_linux.rpi_gpio_pin"
        and dispatch["board_id"] == "RASPBERRY_PI_4B"
        and dispatch["chip_id"] == "BCM2XXX",
    )
    checks.check(
        "known missing NeoPixel dependency is explicit",
        dispatch["missing_platform_dependencies"] == ["rpi_ws281x>=4.0.0"]
        and dispatch["missing_neopixel_dependency_not_imported_or_installed"] is True,
    )
    checks.check(
        "hooks restored even on failure",
        remote["gpio_hooks_restored"] is True
        and remote["native_request_hook_restored"] is True,
    )
    checks.check(
        "no parity claim in receipts",
        results["parity_pass"] is None
        and remote["parity_pass"] is None
        and remote["waveform_accepted"] is None,
    )
    for event in remote["events"]:
        checks.check(
            "event actual successful finite interval: "
            + event["operation"]
            + "/"
            + event["scope"],
            event["status"] == "ok"
            and remote["begin_ns"]
            <= event["begin_ns"]
            <= event["end_ns"]
            <= remote["end_ns"],
        )
    calls = remote["gpio_calls"]
    expected_calls = [
        ("GPIO.setmode", "imports", [11]),
        ("GPIO.setwarnings", "imports", [False]),
    ] * 2
    if backend == "original":
        expected_calls += [
            ("GPIO.setup", "original:constructor", [18, 0]),
            ("GPIO.PWM", "original:constructor", [18, 50]),
            ("GPIO.cleanup", "original:public_deinit", [18]),
        ]
    checks.check(
        "only recorded scoped GPIO18 mutations",
        [(r["operation"], r["scope"], r["arguments"]["args"]) for r in calls]
        == expected_calls
        and all(
            r["attempted"] is True
            and r["success"] is True
            and r["permitted"] is True
            and r["arguments"]["kwargs"] == {}
            for r in calls
        ),
    )
    if successful:
        checks.check(
            "successful primary/cleanup/bounded facts",
            remote["primary_error"] is None
            and remote["cleanup_errors"] == []
            and remote["bounded_python_run_confirmed"] is True
            and acquisition["helper_receipt_validated"] is True
            and acquisition["evidence_errors"] == [],
        )
        checks.check(
            "four declared phases",
            [
                (p["name"], p["duty_u16"], p["duration_seconds"])
                for p in remote["phases"]
            ]
            == list(SEQUENCE),
        )
        previous = remote["begin_ns"]
        for phase, (_name, duty, duration) in zip(remote["phases"], SEQUENCE):
            checks.check(
                "phase interval: " + phase["name"],
                previous <= phase["begin_ns"] <= phase["end_ns"] <= remote["end_ns"]
                and phase["end_ns"] - phase["begin_ns"] >= duration * 1e9,
            )
            previous = phase["end_ns"]
            if duty is not None:
                checks.check(
                    "phase readback/wait: " + phase["name"],
                    phase["api_readback"]
                    == {"frequency": 50, "duty_u16": duty, "pin_id": 18}
                    and phase["begin_ns"]
                    <= phase["api_readback_ns"]
                    <= phase["wait_begin_ns"]
                    <= phase["wait_end_ns"]
                    <= phase["end_ns"]
                    and phase["wait_end_ns"] - phase["wait_begin_ns"] >= duration * 1e9,
                )
                if duty == 0:
                    checks.check(
                        "LOW sampled after settling: " + phase["name"],
                        phase["wait_end_ns"]
                        <= phase["settled_low_confirmation_ns"]
                        <= phase["end_ns"],
                    )
        checks.check(
            "all LOW boundary confirmations",
            remote["boundary_low_confirmations"] == dict.fromkeys(BOUNDARIES, True),
        )
        checks.check(
            "all pin query boundary labels",
            [r["boundary"] for r in remote["pin_boundaries"]] == list(BOUNDARIES),
        )
        for boundary in remote["pin_boundaries"]:
            queries = boundary["queries"]
            checks.check(
                "actual pinctrl LOW/sibling: " + boundary["boundary"],
                len(queries) == 2
                and all(
                    q["arguments"] == ["pinctrl", "get", str(gpio)]
                    and type(q["returncode"]) is int
                    and q["returncode"] == 0
                    for q, gpio in zip(queries, (18, 23))
                )
                and re.fullmatch(LOW_PATTERN, queries[0]["stdout"]) is not None
                and queries[1]["stdout"] == manifest["sibling_pinctrl_stdout"],
            )
        free = remote["free_lines_after_public_and_lab_cleanup"]
        checks.check(
            "read-only controller/lines released after cleanup",
            free["chip"]
            == {k: manifest["controller"][k] for k in ("name", "label", "num_lines")}
            and free["read_only_chip_closed"] is True
            and free["rpi_gpio_mmap_exclusivity_not_proved"] is True
            and [r["offset"] for r in free["lines"]] == [18, 23]
            and all(
                r["used"] is False and r["consumer"] in (None, "")
                for r in free["lines"]
            ),
        )
        if backend == "native":
            checks.check(
                "native owned LOW/read/release positive proof",
                all(
                    remote[key] is True
                    for key in (
                        "native_initial_low_confirmed",
                        "native_private_low_confirmed",
                        "native_request_released",
                    )
                ),
            )
        else:
            checks.check(
                "original public target18 cleanup not lab failed-init substitute",
                "original_lab_cleanup_basis" not in remote,
            )
    else:
        checks.check(
            "failed attempt is not accepted",
            isinstance(remote["primary_error"], str)
            and bool(remote["primary_error"])
            and acquisition["helper_receipt_validated"] is False,
        )
    return sources


def audit_run(base, name, backend, successful, methods):
    directory, checks = base / name, Checks()
    target = 10000.153 if backend == "native" else 10000.0
    hashes, channels, details = {}, {}, {}
    # Decode both raw exports before loading their analysis report.
    for channel in (2, 3):
        filename = f"digital_{channel}.bin"
        raw = regular_bytes(directory / filename)
        channels[str(channel)], details[str(channel)] = decode_v0(raw, target)
        channels[str(channel)]["raw_sha256"] = sha(raw)
        channels[str(channel)]["no_interval_trimming_or_filtering"] = True
        hashes[filename] = {"sha256": sha(raw), "bytes": len(raw)}
    saved = {}
    for filename in (
        "plan.json",
        "manifest.json",
        "results.json",
        "acquisition.json",
        "remote.stdout",
        "remote.stderr",
        "waveform.sal",
    ):
        value = regular_bytes(
            directory / filename, allow_empty=filename == "remote.stderr"
        )
        hashes[filename] = {"sha256": sha(value), "bytes": len(value)}
        if filename.endswith(".json") or filename == "remote.stdout":
            saved[filename] = load_bytes(value)
    results, acquisition, remote = (
        saved["results.json"],
        saved["acquisition.json"],
        saved["remote.stdout"],
    )
    checks.check(
        "actual stdout receipt equals embedded receipt", remote == results["remote"]
    )
    checks.check(
        "acquisition equals embedded acquisition", acquisition == results["acquisition"]
    )
    checks.check("run actual capture label", results["capture"] == name)
    checks.check(
        "actual collected file hashes/sizes bind acquisition",
        all(hashes[k] == v for k, v in acquisition["artifact_provenance"].items()),
    )
    checks.check(
        "actual method checkpoint/current bytes bind receipt",
        methods == results["method_sha256"],
    )
    metadata = sal_metadata(directory / "waveform.sal", checks)
    sources = receipt_checks(
        remote,
        results,
        acquisition,
        saved["manifest.json"],
        saved["plan.json"],
        hashes,
        successful,
        backend,
        checks,
    )
    peer = channels["3"]["chunks"]
    peer_low = all(
        p["initial_level"] == p["final_level"] == 0 and not p["edges_s"] for p in peer
    )
    checks.check("control channel3 is whole-capture LOW/no edges", peer_low)
    checks.check(
        "both channels have identical capture extents",
        [(p["begin_s"], p["end_s"]) for p in peer]
        == [(p["begin_s"], p["end_s"]) for p in channels["2"]["chunks"]],
    )
    if successful:
        report_raw = regular_bytes(directory / "half50-analysis.json")
        hashes["half50-analysis.json"] = {
            "sha256": sha(report_raw),
            "bytes": len(report_raw),
        }
        report = load_bytes(report_raw)
        expected = {
            "schema_version": 1,
            "capture": name,
            "backend": backend,
            "results_sha256": hashes["results.json"]["sha256"],
            "target_high_us": target,
            "nominal_period_us": 20000.0,
            "channels": channels,
            "single_train_with_untouched_low_peer_supported": peer_low
            and sum(len(p["highs_us"]) for p in channels["2"]["chunks"]) > 0
            and all(
                p["initial_level"] == p["final_level"] == 0
                for p in channels["2"]["chunks"]
            ),
            "parity_pass": None,
            "electrical_and_pi_clocks_aligned": False,
            "scope": report["scope"],
        }
        checks.compare(expected, report, "analysis")
    return {
        "capture": name,
        "backend": backend,
        "final_protocol_run": name in dict(FINAL_RUNS),
        "recorded_collection_success": results["collection_success"],
        "actual_ssh_returncode": acquisition["actual_ssh_returncode"],
        "actual_helper_success": remote["success"],
        "actual_primary_error": remote["primary_error"],
        "actual_cleanup_errors": remote["cleanup_errors"],
        "helper_pid": remote["pid"],
        "actual_phases": remote["phases"],
        "actual_events": remote["events"],
        "actual_gpio_calls": remote["gpio_calls"],
        "actual_pin_boundaries": remote["pin_boundaries"],
        "shutdown_line_receipt": remote.get("free_lines_after_public_and_lab_cleanup"),
        "source_bindings": sources,
        "distribution_versions": remote["distribution_versions"],
        "installed_dispatch": remote["installed_dispatch"],
        "platform_preflight": remote["platform_preflight"],
        "data_file_sha256_and_sizes": hashes,
        "sal_metadata": metadata,
        "target_high_us": target,
        "independently_decoded_channels": channels,
        "additional_full_extent_facts": details,
        "checks": checks.rows,
        "failed_check_count": sum(not r["ok"] for r in checks.rows),
        "report_comparison_leaf_count": checks.comparison_leaf_count,
        "report_comparison_differences": checks.differences,
        "failed_attempt_acceptance_verdict": None,
        "parity_pass": None,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path(__file__).parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    base = args.base.absolute()
    output = args.output or base / "oct8-pi4-installed-half50-independent-audit.json"
    if output.exists() or output.is_symlink():
        raise ValueError("Exclusive new audit output required")
    for name, _backend in FINAL_RUNS:
        for filename in ("results.json", "half50-analysis.json"):
            regular_bytes(base / name / filename)
    checks = Checks()
    checkpoints = archive_methods(base, checks)
    current = {name: sha(regular_bytes(base / name)) for name in METHODS}
    runs = [
        audit_run(base, name, backend, True, current) for name, backend in FINAL_RUNS
    ]
    previous = [
        audit_run(base, name, backend, successful, checkpoints[key]["method_sha256"])
        for name, backend, successful, key in OLDER_RUNS
    ]
    audit = {
        "schema_version": 1,
        "audit_method": {
            "path": str(Path(__file__).absolute()),
            "sha256": sha(regular_bytes(__file__)),
        },
        "method": "Independent little-endian Saleae v0 global/chunk headers and state-toggled segments; all transition arrays, complete high/interior-low intervals, adjacent rises, initial/final censored segments retained; no trimming/filtering. Common descriptive statistics use arithmetic mean, median and empirical nearest-rank p95/p99; absolute numeric comparison tolerance 1e-8, exact keys/counts/states.",
        "method_differences": [
            "The audit constructs level-tagged segments, rather than invoking or importing collector reconstruct/read_digital.",
            "Additional audit-only low statistics, signed high errors, period errors, every boundary segment and zero-duration indices are retained.",
            "Target 10000.153us is the declared native rounded diagnostic basis; original target is 10000us. Both use nominal period 20000us; these bases are not a parity threshold.",
            "SAL container metadata is checked offline; no SDK connection or saved-SAL reexport was performed by this method.",
            "Recorded source/path/version attestations are bound to frozen manifest and captured bytes, not independently re-read from the Pi. Actual SSH statuses are recorded exits, not inferred local CLI statuses.",
        ],
        "scope_limitations": [
            "Finite idle real-Pin fixed50Hz runs only; no actuator, load, other frequency, PIO, NeoPixel or whole-Blinka compatibility evidence.",
            "Saleae and Pi monotonic clocks are not aligned; no exact API-to-edge latency or phase-adoption alignment is inferred.",
            "LOW/read/free receipts are sampled and scoped to the helper. Character-device free-line information does not prove RPi.GPIO mmap exclusivity; cancellation fallback is not continuous-low proof.",
            "The constant LOW sibling is whole-capture context, not a separately scheduled sibling exercise. Boundary fragments and all complete intervals are retained.",
            "The two failed attempts remain failures; native-r1b electrical data are descriptive only, despite a generated train/public deinit.",
        ],
        "checkpoint_methods": checkpoints,
        "checkpoint_checks": checks.rows,
        "final_runs": runs,
        "earlier_separate_observations": previous,
        "total_failed_checks": sum(not r["ok"] for r in checks.rows)
        + sum(r["failed_check_count"] for r in runs + previous),
        "total_report_comparison_leaf_count": sum(
            r["report_comparison_leaf_count"] for r in runs + previous
        ),
        "total_report_comparison_differences": sum(
            len(r["report_comparison_differences"]) for r in runs + previous
        ),
        "parity_pass": None,
    }
    with output.open("x") as stream:
        json.dump(audit, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(f"audit={output} sha256={sha(regular_bytes(output))}")
    print(
        f"failed_checks={audit['total_failed_checks']} compared_leaves={audit['total_report_comparison_leaf_count']} differences={audit['total_report_comparison_differences']}"
    )
    for run in runs:
        chunk = run["independently_decoded_channels"]["2"]["chunks"][0]
        error = chunk["absolute_high_error_summary_us"]
        print(
            f"{run['capture']}: highs={len(chunk['highs_us'])} lows={len(chunk['lows_us'])} periods={len(chunk['rise_periods_us'])} high_mean_us={chunk['high_summary_us']['mean']:.6f} abs_high_error_us mean={error['mean']:.6f} p95={error['p95']:.6f} p99={error['p99']:.6f} max={error['max']:.6f}"
        )


if __name__ == "__main__":
    main()
