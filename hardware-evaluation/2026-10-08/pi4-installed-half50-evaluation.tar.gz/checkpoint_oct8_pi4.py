"""Exclusive Oct8 Pi4 evidence archive; byte verification only, never replay.

The final r3 plan is pinned; postflight/audit and all final captures must exist.
All attempts and actual failed whole-environment installation receipts remain
unaltered. Previous wheel/source archives are hash references, not duplicated.
No GPIO, SSH, Saleae, installation, extraction or subprocess execution occurs.
An interrupted/failed archive leaves its marker and partial bytes in place.
"""

import datetime
import hashlib
import io
import json
import os
import stat
import tarfile
from pathlib import Path, PurePosixPath

LAB = Path(__file__).absolute().parent
REPO = LAB.parent / "Adafruit_Blinka_Raspberry_Pi_PWM"
ARCHIVE = REPO / "hardware-evaluation/2026-10-08/pi4-installed-half50-evaluation.tar.gz"
MARKER = LAB / "oct8-pi4-checkpoint-verification.json"
PLAN_NAME = "oct8-pi4-installed-half50-plan-r3.json"
PLAN_SHA256 = "347663e0fce2c2791866fdd5cbdb0b2ca811fb30a8745153576c5ab325b13994"
MANIFEST_NAME = "oct8-pi4-installed-half50-manifest-r3.json"
FINAL_CAPTURES = (
    "oct8-pi4-installed-half50-original-r1c",
    "oct8-pi4-installed-half50-native-r1c",
    "oct8-pi4-installed-half50-native-r2c",
    "oct8-pi4-installed-half50-original-r2c",
)
ATTEMPTS = (
    "oct8-pi4-installed-half50-original-r1",  # Failed output-LOW formatter gate.
    "oct8-pi4-installed-half50-original-r1b",  # Accepted, superseded final labels.
    "oct8-pi4-installed-half50-native-r1b",  # PWM ran; release verifier failed.
) + FINAL_CAPTURES
METHODS = (
    "pi4_installed_pwm_half50_eval.py",
    "capture_pi4_installed_half50.py",
    "test_pi4_installed_pwm_half50_eval.py",
    "test_capture_pi4_installed_half50.py",
    "prepare_pi4_half50_capture.py",
    "prepare_pi4_real_pin_env.py",
    "test_prepare_pi4_real_pin_env.py",
    "record_pi4_installed_sources.py",
    "test_record_pi4_installed_sources.py",
    "record_pi4_readonly_resume.py",
    "inspect_pi4_clean_baseline.py",
    "inspect_pi4_runtime_inventory.py",
    "capture_pwm.py",
    "audit_oct8_pi4_half50.py",
    "checkpoint_oct8_pi4.py",
)
RECEIPT_STEMS = (
    "oct7-pi4-clean-reboot-inspection",
    "oct7-pi4-clean-reboot-inspection-r2",
    "oct7-pi4-runtime-inventory",
    "oct8-pi4-readonly-resume",
    "oct8-pi4-installed-source-inventory",
    "oct8-pi4-post-failed-capture-readonly",
    "oct8-pi4-post-second-failed-capture-readonly",
    "oct8-pi4-final-readonly-postflight",
) + tuple(
    "oct8-pi4-half50-" + revision + operation
    for revision in ("", "r2-", "r3-")
    for operation in (
        "deployment-precheck",
        "helper-scp",
        "manifest-scp",
        "deployment-verify",
        "inspect-command",
    )
)
FILES = (
    METHODS
    + tuple(
        stem + ".json" + suffix
        for stem in RECEIPT_STEMS
        for suffix in ("", ".stdout", ".stderr")
    )
    + tuple(
        "oct8-pi4-installed-half50-" + kind + revision + ".json"
        for revision in ("", "-r2", "-r3")
        for kind in ("manifest", "preflight", "plan")
    )
    + (
        "oct7-pi4-preparation-checkpoint-input-pins.json",
        "oct7-installed-blinka-consumers-plan.json",
        "oct8-pi4-installed-half50-independent-audit.json",
        "oct8-pi4-first-failed-capture-method.tar.gz",
        "oct8-pi4-second-failed-capture-method.tar.gz",
    )
    + tuple(
        "oct7-pi4-real-pin-env-" + stage + ".json" + suffix
        for stage, operations in (
            ("bootstrap", ("bootstrap",)),
            ("transfer", ("transfer-precheck", "scp", "transfer-verify")),
            ("install", ("install",)),
        )
        for suffix in ("",)
        + tuple(
            "." + operation + "." + stream
            for operation in operations
            for stream in ("stdout", "stderr")
        )
    )
)
METHOD_ARCHIVE_PINS = {
    "oct8-pi4-first-failed-capture-method.tar.gz": "6ddb15b17fb50c267480a379d52e48a2ca5cf7a41e708057936eb24e1eeb337c",
    "oct8-pi4-second-failed-capture-method.tar.gz": "c5eee53fa1ff2aafe96754d19bfab67561c916f96685e12e2f79c4028a1e08ce",
}
REFERENCES = {
    "hardware-evaluation/2026-10-07/pi5-installed-blinka-consumer-evaluation.tar.gz": {
        "sha256": "59f3b680d1420faa9a11dbd1925ab24583bec181a4a70b24742404f99bda4748",
        "size_bytes": 6913796,
        "scope": "Exact23 wheels, original/patched Blinka and unchanged native sources; never installed/extracted here.",
    },
    "hardware-evaluation/2026-10-07/pi4-preparation-night-stop.tar.gz": {
        "sha256": "ca9e1d23c230ff7585aaf92a8d8818f06e3949dfab533f60cd15a4d69a694ec1",
        "size_bytes": 70905,
        "scope": "Historical night-stop methods, bootstrap and backend source-policy snapshots; not a fresh bench-state proof.",
    },
}
REQUIRED_CAPTURE_FILES = (
    "plan.json",
    "manifest.json",
    "remote.stdout",
    "remote.stderr",
    "results.json",
    "acquisition.json",
    "waveform.sal",
    "digital_2.bin",
    "digital_3.bin",
)
EMBEDDED_MANIFEST = "oct8-pi4-archive-file-manifest.json"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def regular_bytes(path):
    path = Path(path).absolute()
    require(
        path.resolve(strict=True) == path, "Linked/noncanonical input: " + str(path)
    )
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        require(
            stat.S_ISREG(os.fstat(stream.fileno()).st_mode),
            "Regular file required: " + str(path),
        )
        return stream.read()


def safe_name(name):
    require(
        isinstance(name, str) and bool(name), "Archive name must be a nonempty string"
    )
    path = PurePosixPath(name)
    require(
        str(path) == name
        and not path.is_absolute()
        and "\\" not in name
        and "\x00" not in name
        and all(
            part not in ("", ".", "..") and ":" not in part for part in name.split("/")
        ),
        "Unsafe archive name: " + str(name),
    )


def fingerprint(data):
    return {"sha256": hashlib.sha256(data).hexdigest(), "size_bytes": len(data)}


def inputs():
    require(
        isinstance(PLAN_SHA256, str) and len(PLAN_SHA256) == 64,
        "Final r3 PLAN_SHA256 must be frozen by root",
    )
    require(len(FILES) == len(set(FILES)), "Duplicate explicit file targets")
    files = {name: LAB / name for name in FILES}
    for name in ATTEMPTS:
        directory = LAB / name
        require(
            directory.is_dir() and directory.resolve(strict=True) == directory,
            "Missing/linked capture: " + name,
        )
        require(
            all((directory / part).is_file() for part in REQUIRED_CAPTURE_FILES),
            "Incomplete capture: " + name,
        )
        for path in sorted(directory.rglob("*")):
            require(
                not path.is_symlink() and path.resolve(strict=True) == path,
                "Linked capture member: " + str(path),
            )
            require(
                path.is_file() or path.is_dir(),
                "Unsupported capture member: " + str(path),
            )
            if path.is_file():
                key = str(path.relative_to(LAB))
                require(key not in files, "Duplicate archive member: " + key)
                files[key] = path
    facts = {}
    for name, path in files.items():
        safe_name(name)
        facts[name] = fingerprint(regular_bytes(path))
    require(EMBEDDED_MANIFEST not in files, "Manifest/input collision")
    require(facts[PLAN_NAME]["sha256"] == PLAN_SHA256, "Final plan changed")
    plan = json.loads(regular_bytes(LAB / PLAN_NAME))
    require(
        plan["capture_order"] == list(FINAL_CAPTURES), "Final capture order changed"
    )
    require(
        facts[MANIFEST_NAME]["sha256"] == plan["manifest_sha256"],
        "Final manifest changed",
    )
    preflight_name = "oct8-pi4-installed-half50-preflight-r3.json"
    require(
        plan["preflight_receipt_path"] == str(LAB / preflight_name)
        and facts[preflight_name]["sha256"] == plan["preflight_receipt_sha256"],
        "Final preflight changed",
    )
    for name, expected in plan["method_sha256"].items():
        require(
            name in facts and facts[name]["sha256"] == expected,
            "Executed final method changed: " + name,
        )
    for name, expected in METHOD_ARCHIVE_PINS.items():
        require(
            facts[name]["sha256"] == expected, "Failed-method archive changed: " + name
        )
    for name, expected in REFERENCES.items():
        actual = fingerprint(regular_bytes(REPO / name))
        require(
            actual == {key: expected[key] for key in actual},
            "Referenced archive changed: " + name,
        )
    for name in FINAL_CAPTURES:
        result = json.loads(regular_bytes(LAB / name / "results.json"))
        actual = result["acquisition"]["actual_ssh_returncode"]
        require(
            result["collection_success"] is True
            and type(actual) is int
            and actual == 0,
            "Final capture not accepted: " + name,
        )
    # Preserve accepted=false full pip-check/first-attempt receipts as bytes;
    # this archive never reclassifies them or claims the whole env is clean.
    return files, facts


def add_bytes(archive, name, data):
    safe_name(name)
    member = tarfile.TarInfo(name)
    member.size = len(data)
    member.mode = 0o600
    archive.addfile(member, io.BytesIO(data))


def main():
    require(not ARCHIVE.exists() and not ARCHIVE.is_symlink(), "Archive already exists")
    require(
        not MARKER.exists() and not MARKER.is_symlink(),
        "Checkpoint marker already exists",
    )
    files, facts = inputs()
    parent = ARCHIVE.parent.parent
    require(
        parent.is_dir() and parent.resolve(strict=True) == parent,
        "Canonical existing hardware-evaluation parent required",
    )
    if not ARCHIVE.parent.exists():
        ARCHIVE.parent.mkdir()
    require(
        ARCHIVE.parent.is_dir()
        and ARCHIVE.parent.resolve(strict=True) == ARCHIVE.parent,
        "Linked archive directory",
    )
    manifest = {
        "schema_version": 1,
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "checkpointer_sha256": facts[Path(__file__).name]["sha256"],
        "final_plan_sha256": PLAN_SHA256,
        "final_capture_order": list(FINAL_CAPTURES),
        "all_attempt_directories": list(ATTEMPTS),
        "files": facts,
        "referenced_immutable_archives_not_duplicated": REFERENCES,
        "scope": "Byte recovery only. No replay, extraction, hardware, whole-environment-clean, calibrated timing or parity claim. Both instrumentation failures and actual failed full pip-check receipt preserved unchanged.",
    }
    manifest_bytes = (json.dumps(manifest, indent=2, allow_nan=False) + "\n").encode()
    # Reserve the marker before writing any archive bytes. Never erase or retry
    # over an existing marker/partial archive after interruption or failure.
    with MARKER.open("x") as marker:
        with (
            ARCHIVE.open("xb") as stream,
            tarfile.open(fileobj=stream, mode="w:gz") as archive,
        ):
            for name, path in sorted(files.items()):
                data = regular_bytes(path)
                require(
                    fingerprint(data) == facts[name],
                    "Input changed during snapshot: " + name,
                )
                add_bytes(archive, name, data)
            add_bytes(archive, EMBEDDED_MANIFEST, manifest_bytes)
        seen = set()
        with tarfile.open(ARCHIVE, "r:gz") as archive:
            for member in archive:
                safe_name(member.name)
                require(
                    member.isfile() and member.name not in seen,
                    "Nonregular/duplicate tar member",
                )
                seen.add(member.name)
                stream = archive.extractfile(member)
                require(stream is not None, "Unreadable tar member")
                with stream:
                    data = stream.read()
                if member.name == EMBEDDED_MANIFEST:
                    require(data == manifest_bytes, "Embedded manifest differs")
                else:
                    require(member.name in files, "Unexpected tar member")
                    require(
                        data == regular_bytes(files[member.name])
                        and fingerprint(data) == facts[member.name],
                        "Tar/original bytes differ: " + member.name,
                    )
        require(seen == set(files) | {EMBEDDED_MANIFEST}, "Tar file set differs")
        report = {
            "archive": str(ARCHIVE),
            **fingerprint(regular_bytes(ARCHIVE)),
            "archive_regular_files": len(seen),
            "all_file_bytes_and_sizes_match_originals": True,
            "embedded_manifest": EMBEDDED_MANIFEST,
            "embedded_manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
            "references_verified_not_duplicated": REFERENCES,
            "safe_tar_read_only_no_extraction_or_replay": True,
        }
        json.dump(report, marker, indent=2, allow_nan=False)
        marker.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
