"""Fresh read-only Pi4 receipts; no sudo, runtime package import or GPIO claim."""

import ast
import datetime
import hashlib
import json
import shlex
import subprocess
from pathlib import Path

LAB = Path(__file__).resolve().parent
ROOT = "/tmp/blinka-pwm-pi4-real-pin.2y4fi6z0"
FROZEN = {
    "inspect_pi4_clean_baseline.py": "e050c6eb263765251a5760178cacbb95799fdcc15ab01ec7355d3aa1a90d1eae",
    "inspect_pi4_runtime_inventory.py": "5a4d349160bc730bd538a046e4f1b9e08703fccc19a7f95a674f89239bc0c7a4",
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def remote_code():
    """Reuse frozen query bodies, omitting sudo and Python GPIO fallback entirely."""
    sources = {}
    for filename, expected in FROZEN.items():
        path = LAB / filename
        if path.is_symlink() or digest(path) != expected:
            raise ValueError("Frozen inspection source changed")
        tree = ast.parse(path.read_text())
        tree.body = [node for node in tree.body if not isinstance(node, ast.If)]
        if filename == "inspect_pi4_clean_baseline.py":
            inspect = next(
                node
                for node in tree.body
                if isinstance(node, ast.FunctionDef) and node.name == "inspect"
            )
            inspect.body = [
                node
                for node in inspect.body
                if not (
                    isinstance(node, ast.Assign)
                    and isinstance(node.targets[0], ast.Subscript)
                    and isinstance(node.targets[0].slice, ast.Constant)
                    and node.targets[0].slice.value == "debug_pwm"
                )
                and not (
                    isinstance(node, ast.If)
                    and isinstance(node.test, ast.Compare)
                    and "debug_pwm" in ast.unparse(node.test)
                )
            ]
            gpio = next(
                node
                for node in inspect.body
                if isinstance(node, ast.If)
                and "gpioinfo_available" in ast.unparse(node.test)
            )
            gpio.orelse = []
            suffix = "\nbaseline=inspect()\nbaseline['sudo_queries']='omitted; no sudo executed'\nbaseline['python_gpio_fallback']='omitted; gpioinfo CLI required'\n"
        else:
            suffix = "\ninventory=inspect()\n"
        sources[filename] = ast.unparse(ast.fix_missing_locations(tree)) + suffix
    return (
        "\n".join(sources.values())
        + f"""
import importlib.metadata,sys
root=Path({ROOT!r})
root_status={{'path':str(root),'exists':root.exists(),'symlink':root.is_symlink()}}
if root.is_dir() and not root.is_symlink():
    root_status.update(resolved=str(root.resolve()),uid=root.stat().st_uid,mode=oct(stat.S_IMODE(root.stat().st_mode)),children=[p.name for p in sorted(root.iterdir())])
    for dirname in ('venv','wheelhouse'):
        directory=root/dirname
        root_status[dirname]={{'exists':directory.is_dir(),'symlink':directory.is_symlink(),'resolved':str(directory.resolve())}}
    cfg=root/'venv/pyvenv.cfg'
    if cfg.is_file() and not cfg.is_symlink():
        root_status['venv_config']={{'text':cfg.read_text(),'sha256':hashlib.sha256(cfg.read_bytes()).hexdigest()}}
    python=root/'venv/bin/python'
    root_status['python']={{'exists':python.is_file(),'resolved':str(python.resolve())}}
    house=root/'wheelhouse'
    if house.is_dir() and not house.is_symlink(): root_status['wheelhouse_entries']=[p.name for p in sorted(house.iterdir())]
    site=root/'venv/lib/python3.13/site-packages'
    if site.is_dir() and not site.is_symlink():
        root_status['private_distribution_metadata']=[{{'name':d.metadata['Name'],'version':d.version,'origin':str(d.locate_file(''))}} for d in importlib.metadata.distributions(path=[str(site)])]
processes=[]
for path in sorted(Path('/proc').glob('[0-9]*/cmdline')):
    try:
        pid=int(path.parent.name)
        if pid==os.getpid() or path.stat().st_uid!=os.getuid(): continue
        arguments=[value.decode(errors='replace') for value in path.read_bytes().split(b'\\x00') if value]
        if arguments: processes.append({{'pid':pid,'arguments':arguments}})
    except (OSError,ValueError): pass
stale=[item for item in processes if any(any(marker in argument.lower() for marker in ('blinka','pwm','stress','busy_loop','cpu_load')) for argument in item['arguments']) or Path(item['arguments'][0]).name=='yes']
assert not any(name in sys.modules for name in ('board','pwmio','RPi.GPIO'))
print(json.dumps({{'baseline':baseline,'inventory':inventory,'private_root':root_status,'pi_owned_processes':processes,'suspected_helper_or_load_processes':stale,'process_scan_scope':'current pi uid; cmdline markers blinka/pwm/stress/busy_loop/cpu_load or yes executable; current recorder excluded','no_board_pwmio_RPi_GPIO_import':True,'no_sudo':True,'no_remote_write':True}},indent=2))
"""
    )


def record(output):
    output = Path(output).resolve()
    if output.parent != LAB or not output.name.startswith("oct8-pi4-"):
        raise ValueError("Fresh oct8 LAB output required")
    stdout, stderr = Path(str(output) + ".stdout"), Path(str(output) + ".stderr")
    if any(path.exists() or path.is_symlink() for path in (output, stdout, stderr)):
        raise ValueError("Exclusive evidence required")
    code = remote_code()
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test2-pi4.local",
        shlex.join(["/usr/bin/python3", "-I", "-S", "-"]),
    ]
    result, error, remote = None, None, None
    with (
        output.open("x") as receipt_stream,
        stdout.open("xb") as out,
        stderr.open("xb") as err,
    ):
        try:
            result = subprocess.run(
                command,
                input=code.encode(),
                stdout=out,
                stderr=err,
                timeout=60,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt) as failure:
            error = type(failure).__name__ + ": " + str(failure)
        actual = (
            result.returncode
            if result is not None and type(result.returncode) is int
            else None
        )
        if actual == 0 and error is None:
            try:
                remote = json.loads(stdout.read_text())
            except (ValueError, UnicodeError) as failure:
                error = "Invalid JSON stdout: " + str(failure)
        receipt = {
            "schema_version": 1,
            "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "ssh_returncode": actual,
            "error": error,
            "recorder_sha256": digest(__file__),
            "reused_query_sha256": FROZEN,
            "remote_code_sha256": hashlib.sha256(code.encode()).hexdigest(),
            "remote_code": code,
            "remote_command": command,
            "stdout_sha256": digest(stdout),
            "stderr_sha256": digest(stderr),
            "remote": remote,
        }
        json.dump(receipt, receipt_stream, indent=2)
        receipt_stream.write("\n")
    print(json.dumps({"ssh_returncode": actual, "error": error, "output": str(output)}))
    return 0 if actual == 0 and error is None else 1


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output")
    raise SystemExit(record(parser.parse_args().output))
