"""Read-only package metadata/source inventory; no board/PWM/GPIO imports.

Every Python subprocess uses -I -S and scans distribution metadata explicitly:
site startup, .pth execution and package initialization are never performed.
"""

import datetime
import grp
import hashlib
import json
import os
import platform
import stat
import subprocess
from pathlib import Path

METADATA_CODE = r"""
import hashlib,importlib.metadata,json,pathlib,platform,re,sys
sites=json.loads(sys.argv[1])
selected={'adafruit-blinka','adafruit-platformdetect','adafruit-blinka-raspberry-pi-pwm','adafruit-circuitpython-motor','gpiod','rpi-gpio','rpi-lgpio','adafruit-lgpio','lgpio','packaging','adafruit-busdevice','adafruit-circuitpython-neopixel'}
distributions=[]
for site in sites:
    for distribution in importlib.metadata.distributions(path=[site]):
        name=distribution.metadata.get('Name','')
        normalized=re.sub(r'[-_.]+','-',name).lower()
        if normalized in selected:
            distributions.append({'name':name,'version':distribution.version,'site':site,'metadata_root':str(distribution.locate_file('')),'requires_dist':distribution.metadata.get_all('Requires-Dist',[]),'direct_url':distribution.read_text('direct_url.json')})
sources=[]
patterns=['board.py','pwmio.py','adafruit_blinka/__init__.py','adafruit_blinka/agnostic/__init__.py','adafruit_blinka/platform_dependencies.py','adafruit_blinka/microcontroller/bcm283x/pin.py','adafruit_blinka/microcontroller/generic_linux/rpi_gpio_pin.py','adafruit_blinka/microcontroller/generic_linux/rpi_gpio_pwmout.py','adafruit_blinka/microcontroller/generic_linux/lgpio_pin.py','adafruit_blinka/microcontroller/generic_linux/lgpio_pwmout.py','adafruit_blinka_raspberry_pi_pwm/__init__.py','adafruit_blinka_raspberry_pi_pwm/_software.py','adafruit_blinka_raspberry_pi_pwm/_native*.so','RPi/GPIO/__init__.py','RPi/_GPIO*.so','gpiod/__init__.py','gpiod/_ext*.so','adafruit_platformdetect/__init__.py','adafruit_motor/__init__.py','adafruit_motor/servo.py','adafruit_motor/motor.py','lgpio.py','_lgpio*.so']
startup_files=[]
for site in sites:
    directory=pathlib.Path(site)
    for pattern in patterns:
        for path in directory.glob(pattern):
            if path.is_file() and not path.is_symlink():
                data=path.read_bytes()
                source={'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
                if path.name=='pwmio.py':
                    source['raspberry_pi_dispatch_source']=data.decode().splitlines()[:35]
                sources.append(source)
    for path in [*directory.glob('*.pth'),*directory.glob('__editable__*finder.py'),directory/'sitecustomize.py',directory/'usercustomize.py']:
        if path.is_file() and not path.is_symlink():
            startup_files.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'text_not_executed':path.read_text()})
print(json.dumps({'python_executable':sys.executable,'python_version':platform.python_version(),'isolated':bool(sys.flags.isolated),'no_site_startup':bool(sys.flags.no_site),'metadata_scanned_sites':sites,'distributions':distributions,'selected_source_files':sources,'startup_files_preserved_not_executed':startup_files,'board_pwmio_RPi_GPIO_imported':any(name in sys.modules for name in ('board','pwmio','RPi.GPIO'))},indent=2))
"""


def query(arguments):
    try:
        result = subprocess.run(
            arguments, capture_output=True, text=True, timeout=15, check=False
        )
        return {
            "arguments": arguments,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        }
    except (OSError, subprocess.TimeoutExpired) as error:
        return {
            "arguments": arguments,
            "returncode": None,
            "error": type(error).__name__ + ": " + str(error),
        }


def inspect():
    receipt = {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "hostname": platform.node(),
        "kernel": platform.release(),
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        "read_only": True,
        "no_gpio_api_or_claim_or_write": True,
        "no_board_pwmio_RPi_GPIO_import": True,
        "current_uid": os.getuid(),
        "group_names": [grp.getgrgid(group).gr_name for group in os.getgroups()],
        "profile_environment": {
            key: os.environ.get(key)
            for key in ("BLINKA_PWM_SHARED", "BLINKA_PWM_SHORT_SLICE")
        },
    }
    devices = {}
    for filename in ("/dev/gpiomem", "/dev/gpiochip0"):
        path = Path(filename)
        if not path.exists():
            devices[filename] = {"exists": False}
            continue
        metadata = path.stat()
        devices[filename] = {
            "exists": True,
            "character_device": stat.S_ISCHR(metadata.st_mode),
            "mode": oct(stat.S_IMODE(metadata.st_mode)),
            "owner_uid": metadata.st_uid,
            "group": grp.getgrgid(metadata.st_gid).gr_name,
            "pi_can_read": os.access(path, os.R_OK),
            "pi_can_write": os.access(path, os.W_OK),
            "no_device_opened": True,
        }
    receipt["device_access"] = devices
    system_sites = [
        path
        for pattern in (
            "/usr/lib/python3/dist-packages",
            "/usr/local/lib/python*/dist-packages",
            "/usr/local/lib/python*/site-packages",
        )
        for path in Path("/").glob(pattern.lstrip("/"))
        if path.is_dir()
    ]
    receipt["system_runtime_metadata"] = query(
        [
            "/usr/bin/python3",
            "-I",
            "-S",
            "-c",
            METADATA_CODE,
            json.dumps([str(path) for path in system_sites]),
        ]
    )
    roots = [
        path
        for path in sorted(Path("/tmp").iterdir())
        if path.is_dir()
        and not path.is_symlink()
        and any(word in path.name.lower() for word in ("blinka", "pwm"))
    ]
    inspected = []
    source_patterns = (
        "setup.py",
        "pyproject.toml",
        "manifest.json",
        "*manifest.json",
        "src/native/*.c",
        "src/native/*.h",
        "src/adafruit_blinka_raspberry_pi_pwm/*.py",
        "src/pwmio.py",
        "baseline_pwmout.py",
        "rpi_gpio_pwmout.py",
        "native_pwm_consumers_eval.py",
        "installed_blinka_pwm_consumers_eval.py",
        "kernel_pwm_eval_pi4.py",
    )
    for root in roots:
        item = {
            "root": str(root),
            "immediate_children": [path.name for path in sorted(root.iterdir())],
            "private_runtimes": [],
            "source_snapshots": [],
        }
        for config in sorted(root.rglob("pyvenv.cfg")):
            if config.is_symlink():
                continue
            venv = config.parent
            python = venv / "bin/python"
            if not python.is_file():
                continue
            config_text = config.read_text()
            sites = list(venv.glob("lib/python*/site-packages"))
            if "include-system-site-packages = true" in config_text.lower():
                sites.extend(system_sites)
            item["private_runtimes"].append(
                {
                    "venv_root": str(venv),
                    "pyvenv_config": config_text,
                    "python_path": str(python),
                    "resolved_python": str(python.resolve()),
                    "metadata_only_query": query(
                        [
                            str(python),
                            "-I",
                            "-S",
                            "-c",
                            METADATA_CODE,
                            json.dumps([str(site) for site in sites]),
                        ]
                    ),
                }
            )
        snapshots = [
            root,
            *[
                path
                for path in root.iterdir()
                if path.is_dir()
                and not path.is_symlink()
                and path.name not in ("venv", ".venv", "build")
            ],
        ]
        seen = set()
        for directory in snapshots:
            if (directory / ".git").exists():
                item["source_snapshots"].append(
                    {
                        "directory": str(directory),
                        "git_head": query(
                            ["git", "-C", str(directory), "rev-parse", "HEAD"]
                        ),
                    }
                )
            for pattern in source_patterns:
                for path in directory.glob(pattern):
                    if not path.is_file() or path.is_symlink() or str(path) in seen:
                        continue
                    seen.add(str(path))
                    data = path.read_bytes()
                    item["source_snapshots"].append(
                        {
                            "path": str(path),
                            "sha256": hashlib.sha256(data).hexdigest(),
                            "bytes": len(data),
                        }
                    )
        inspected.append(item)
    receipt["existing_lab_roots"] = inspected
    receipt["metadata_query_source_sha256"] = hashlib.sha256(
        METADATA_CODE.encode()
    ).hexdigest()
    return receipt


if __name__ == "__main__":
    print(json.dumps(inspect(), indent=2))
