"""Narrow hash-bound deployment/import inspection and pre-capture plan.

No PWM construction or GPIO write is performed by this preparation script.
The deployed helper's --inspect route refuses claims and GPIO setup/write.
"""

import argparse
import datetime
import json
import shlex
import subprocess
from pathlib import Path

import capture_pi4_installed_half50 as capture
import pi4_installed_pwm_half50_eval as helper

LAB = Path(__file__).resolve().parent
ROOT = "/tmp/blinka-pwm-pi4-real-pin.2y4fi6z0"
HOST = "pi@test2-pi4.local"
INVENTORY = LAB / "oct8-pi4-installed-source-inventory.json"
MANIFEST = LAB / "oct8-pi4-installed-half50-manifest-r3.json"
PREFLIGHT = LAB / "oct8-pi4-installed-half50-preflight-r3.json"
PLAN = LAB / "oct8-pi4-installed-half50-plan-r3.json"
PREVIOUS = {
    "pi4_installed_pwm_half50_eval.py": "fe0d75ff07c6edbf0b61e9cb3dfc5751393bf68fda0baa1925d55ecf8c070984",
    "manifest.json": "afabdcc9baf046645131f6bafe89a63192da97850d48bebee687ebb8736d7dd9",
}


def receipt_path(name):
    return LAB / ("oct8-pi4-half50-r3-" + name + ".json")


def write_new(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def inventory():
    value = capture.read_json(INVENTORY)
    assert value["accepted"] is True and type(value["ssh_returncode"]) is int
    assert value["ssh_returncode"] == 0 and value["error"] is None
    for kind in ("stdout", "stderr"):
        path = Path(str(INVENTORY) + "." + kind)
        assert capture.digest(path) == value[kind + "_sha256"]
    remote = capture.read_json(Path(str(INVENTORY) + ".stdout"))
    assert remote == value["remote"] and remote["remote_root"] == ROOT
    assert remote["no_runtime_package_import"] is True
    assert remote["startup_files_not_executed"] == []
    closure = value["focused_dependency_closure_audit"]
    assert closure["all_active_requirements_satisfied"] is True
    assert closure["all17_failures_outside_tested_closure"] is True
    assert closure["whole_environment_clean"] is False
    return value, remote


def create_manifest():
    value, remote = inventory()
    manifest = {
        "schema_version": 1,
        "remote_root": ROOT,
        **remote["platform"],
        "controller": {
            "path": "/dev/gpiochip0",
            "name": "gpiochip0",
            "label": "pinctrl-bcm2711",
            "num_lines": 58,
            "device_number": "254:0",
            "of_node": "/sys/firmware/devicetree/base/soc/gpio@7e200000",
        },
        "sibling_pinctrl_stdout": "23: ip    pd | lo // GPIO23 = input\n",
        "distribution_versions": {
            k: v["version"] for k, v in remote["distribution_metadata"].items()
        },
        "source_paths": {
            **remote["source_paths"],
            helper.HELPER: ROOT + "/" + helper.HELPER,
        },
        "source_sha256": {
            **remote["source_sha256"],
            helper.HELPER: capture.digest(LAB / helper.HELPER),
        },
        "installed_inventory_sha256": capture.digest(INVENTORY),
        "focused_dependency_closure_only": True,
        "whole_environment_clean": False,
        "failed_full_install_receipt_sha256": value["install_receipt_sha256"],
    }
    helper.validate_manifest(manifest)
    write_new(MANIFEST, manifest)
    return 0


def ssh(code):
    return [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        HOST,
        shlex.join(["/usr/bin/python3", "-I", "-S", "-c", code]),
    ]


def execute(arguments, output):
    stdout, stderr = Path(str(output) + ".stdout"), Path(str(output) + ".stderr")
    assert not any(p.exists() or p.is_symlink() for p in (output, stdout, stderr))
    result, error = None, None
    with (
        output.open("x") as receipt,
        stdout.open("xb") as out,
        stderr.open("xb") as err,
    ):
        try:
            result = subprocess.run(
                arguments,
                stdin=subprocess.DEVNULL,
                stdout=out,
                stderr=err,
                timeout=45,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt) as failure:
            error = type(failure).__name__ + ": " + str(failure)
        actual = (
            result.returncode
            if result is not None and type(result.returncode) is int
            else None
        )
        value = {
            "command": arguments,
            "actual_returncode": actual,
            "error": error,
            "stdout_sha256": capture.digest(stdout),
            "stderr_sha256": capture.digest(stderr),
            "recorder_sha256": capture.digest(__file__),
        }
        json.dump(value, receipt, indent=2)
        receipt.write("\n")
    assert actual == 0 and error is None, str(output)
    return value, stdout


def deploy():
    inventory()
    manifest = capture.read_json(MANIFEST)
    helper.validate_manifest(manifest)
    assert manifest["source_sha256"][helper.HELPER] == capture.digest(
        LAB / helper.HELPER
    )
    code = f"""
import hashlib,pathlib
root=pathlib.Path({ROOT!r})
assert root.is_dir() and not root.is_symlink() and root.resolve()==root
assert root.stat().st_uid==1000 and root.stat().st_mode & 0o777==0o700
assert (root/'venv/pyvenv.cfg').is_file()
for name,digest in {PREVIOUS!r}.items():
    path=root/name
    assert path.is_file() and not path.is_symlink() and path.resolve()==path
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    for suffix in ('.incoming-r3','.second-failed-preserved'):
        fresh=root/(name+suffix)
        assert not fresh.exists() and not fresh.is_symlink(),str(fresh)
print('Prior helper/manifest bytes verified; fresh incoming and backup targets confirmed')
"""
    execute(ssh(code), receipt_path("deployment-precheck"))
    command = [
        "scp",
        "-B",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        str(LAB / helper.HELPER),
        HOST + ":" + ROOT + "/" + helper.HELPER + ".incoming-r3",
    ]
    execute(command, receipt_path("helper-scp"))
    command[-2:] = [str(MANIFEST), HOST + ":" + ROOT + "/manifest.json.incoming-r3"]
    execute(command, receipt_path("manifest-scp"))
    expected = {
        helper.HELPER: capture.digest(LAB / helper.HELPER),
        "manifest.json": capture.digest(MANIFEST),
    }
    code = f"""
import hashlib,json,pathlib
root=pathlib.Path({ROOT!r}); previous={PREVIOUS!r}; expected={expected!r}
assert root.is_dir() and not root.is_symlink() and root.resolve()==root
assert root.stat().st_uid==1000 and root.stat().st_mode & 0o777==0o700
for name,digest in previous.items():
    for suffix,wanted in (('',digest),('.incoming-r3',expected[name])):
        path=root/(name+suffix)
        assert path.is_file() and not path.is_symlink() and path.resolve()==path
        assert hashlib.sha256(path.read_bytes()).hexdigest()==wanted
    backup=root/(name+'.second-failed-preserved')
    assert not backup.exists() and not backup.is_symlink()
for name in previous:
    (root/name).rename(root/(name+'.second-failed-preserved'))
    (root/(name+'.incoming-r3')).rename(root/name)
actual={{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected}}
backups={{name:hashlib.sha256((root/(name+'.second-failed-preserved')).read_bytes()).hexdigest() for name in previous}}
assert actual==expected and backups==previous
print(json.dumps({{'revised':actual,'preserved_previous':backups}}))
"""
    execute(ssh(code), receipt_path("deployment-verify"))
    return 0


def inspect():
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        HOST,
        shlex.join(
            [
                ROOT + "/venv/bin/python",
                "-I",
                ROOT + "/" + helper.HELPER,
                "--manifest",
                ROOT + "/manifest.json",
                "--backend",
                "native",
                "--inspect",
            ]
        ),
    ]
    value, stdout = execute(command, receipt_path("inspect-command"))
    remote = capture.read_json(stdout)
    manifest = capture.read_json(MANIFEST)
    assert remote["success"] is True and remote["inspect_only"] is True
    assert remote["guarded_import_only_no_gpio_construction"] is True
    assert remote["phases"] == [] and remote["events"] == []
    assert remote["primary_error"] is None and remote["cleanup_errors"] == []
    assert (
        remote["gpio_hooks_restored"] is True
        and remote["native_request_hook_restored"] is True
    )
    assert remote["manifest_sha256"] == capture.digest(MANIFEST)
    assert remote["source_sha256"] == manifest["source_sha256"]
    assert remote["source_paths"] == manifest["source_paths"]
    assert remote["distribution_versions"] == manifest["distribution_versions"]
    assert all(
        c["operation"] in ("GPIO.setmode", "GPIO.setwarnings")
        and c["permitted"] is True
        and c["success"] is True
        and c["scope"] == "imports"
        for c in remote["gpio_calls"]
    )
    write_new(
        PREFLIGHT,
        {
            "accepted": True,
            "ssh_returncode": value["actual_returncode"],
            "remote": remote,
            "manifest_sha256": capture.digest(MANIFEST),
            "command_receipt_sha256": capture.digest(receipt_path("inspect-command")),
            "source_inventory_sha256": capture.digest(INVENTORY),
            "scope": "Guarded import-only; no PWM construction, GPIO setup/write/cleanup or package installation",
        },
    )
    return 0


def plan():
    value = capture.read_json(PREFLIGHT)
    assert (
        value["accepted"] is True
        and type(value["ssh_returncode"]) is int
        and value["ssh_returncode"] == 0
    )
    manifest = capture.read_json(MANIFEST)
    result = {
        "schema_version": 1,
        "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "capture_order": [name for name, _ in capture.RUNS],
        "capture_backends": dict(capture.RUNS),
        "remote_root": ROOT,
        "remote_python": ROOT + "/venv/bin/python",
        "host": "test2-pi4.local",
        "manifest_sha256": capture.digest(MANIFEST),
        "method_sha256": capture.method_hashes(),
        "outputs": [
            {"gpio": 18, "saleae_channel": 2},
            {"gpio": 23, "saleae_channel": 3},
        ],
        "frequency": 50,
        "duty_cycle": 32768,
        "hold_seconds": 3.0,
        "runtime_flags": {"short_slice": False, "shared": False},
        "preflight_receipt_path": str(PREFLIGHT),
        "preflight_receipt_sha256": capture.digest(PREFLIGHT),
        "no_load_no_pio": True,
        "parity_thresholds_declared": False,
        "scope": "Final finite real-Pin fixed50Hz functional and descriptive original/native comparison; every interval/boundary retained; no new broad matrix or default parity claim",
    }
    capture.validate_plan(result, manifest, capture.digest(MANIFEST))
    write_new(PLAN, result)
    return 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("manifest", "deploy", "inspect", "plan"))
    stages = {
        "manifest": create_manifest,
        "deploy": deploy,
        "inspect": inspect,
        "plan": plan,
    }
    raise SystemExit(stages[parser.parse_args().stage]())
