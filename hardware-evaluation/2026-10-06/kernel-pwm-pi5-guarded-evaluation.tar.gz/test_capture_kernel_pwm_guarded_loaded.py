"""Fake-only guarded load wrapper; no SSH, Saleae, GPIO or real CPU load."""

import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

import capture_kernel_pwm_guarded_loaded as bench

STEM = "guarded-bench-loaded-r2"
ROOT = "/tmp/blinka-pwm-oct6.ABC123"


@pytest.fixture(autouse=True)
def safe_directory(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)


def fake_handshake(monkeypatch, *, valid=True, capture_rc=0, load_rc=0):
    events, captures = [], []
    launch = {
        "schema_version": 1,
        "worker_source_sha256": bench.base.WORKER_SHA256,
        "event": "load_launched",
        "mode": "cpu-only-fixed-two-workers",
        "worker_count": 2 if valid else 4,
        "started_worker_count": 2,
        "worker_duration_seconds": 10,
        "launch_complete": True,
        "gpio_writes": False,
        "pwm_sysfs_access": False,
        "kernel_configuration_changes": False,
        "source_sha256": bench.base.LOAD_SHA256,
        "launcher_pid": 100,
        "owned_workers": [{"pid": 101, "reaped": False}, {"pid": 102, "reaped": False}],
    }

    def record(stem, remote_root, *, launch_callback):
        assert stem == STEM and remote_root == ROOT + "/cpu-load-eval"
        with Path(stem + ".load.stdout").open("x") as stream:
            stream.write(json.dumps(launch) + "\n")
            stream.flush()
            with Path(stem + ".load.stderr").open("x"):
                pass
            events.append("launch_persisted")
            launch_callback(launch)
            stream.write(json.dumps({"event": "load_completed"}) + "\n")
        events.append("load_drained")
        if load_rc:
            raise bench.base.recorder.LoadRecordingError("fake failed load", load_rc)
        return 0

    def capture(command, **kwargs):
        assert len(Path(STEM + ".load.stdout").read_text().splitlines()) == 1
        assert kwargs["timeout"] == 20 and kwargs["check"] is False
        assert kwargs["stdin"] == subprocess.DEVNULL
        events.append("capture_started")
        captures.append(command)
        kwargs["stdout"].write(b"fake capture stdout\n")
        kwargs["stderr"].write(b"fake capture stderr\n")
        return SimpleNamespace(returncode=capture_rc)

    monkeypatch.setattr(bench.base.recorder, "record", record)
    monkeypatch.setattr(bench.base.subprocess, "run", capture)
    return events, captures


@pytest.mark.parametrize("mode", bench.MODES)
def test_fixed_handshake_and_separate_immutable_receipts(monkeypatch, mode):
    original_modes = bench.base.MODES
    events, captures = fake_handshake(monkeypatch)
    result = bench.coordinate(STEM, ROOT, mode)
    assert events == ["launch_persisted", "capture_started", "load_drained"]
    script, subdir, child_mode = bench.MODES[mode]
    assert captures == [
        [
            sys.executable,
            str(Path(bench.__file__).with_name(script)),
            STEM,
            "--remote-root",
            ROOT + "/" + subdir,
            "--mode",
            child_mode,
        ]
    ]
    assert bench.base.MODES is original_modes
    assert result["sources_validated"] and result["coordination_success"]
    assert result["source_sha256"] == bench.source_hashes()
    assert result["errors"] == []
    assert result["overlap_verified"] is False and result["waveform_accepted"] is None
    assert json.loads(Path(STEM + bench.RECEIPT_SUFFIX).read_text()) == result
    base_receipt = json.loads(Path(STEM + ".coordination.json").read_text())
    assert base_receipt["mode"] == mode and base_receipt["coordination_success"]
    assert (
        base_receipt["coordinator_sha256"]
        == bench.EXPECTED_REUSED_SHA256["capture_kernel_pwm_loaded.py"]
    )
    assert (
        base_receipt["recorder_sha256"]
        == bench.EXPECTED_REUSED_SHA256["record_kernel_pwm_cpu_load.py"]
    )
    assert "sources_validated" not in base_receipt
    before = Path(STEM + ".coordination.json").read_bytes()
    with pytest.raises(FileExistsError):
        bench.coordinate(STEM, ROOT, mode)
    assert Path(STEM + ".coordination.json").read_bytes() == before


@pytest.mark.parametrize("name", bench.EXPECTED_REUSED_SHA256)
def test_each_changed_source_blocks_every_launch_and_records_actual_hash(
    monkeypatch, name
):
    events, captures = fake_handshake(monkeypatch)
    hashes = bench.source_hashes()
    hashes[name] = "0" * 64
    monkeypatch.setattr(bench, "source_hashes", lambda: hashes)
    result = bench.coordinate(STEM, ROOT, "guarded-direct")
    assert not result["sources_validated"] and not result["coordination_success"]
    assert name in result["errors"][0] and result["source_sha256"][name] == "0" * 64
    assert events == [] and captures == []
    assert list(Path.cwd().iterdir()) == [Path(STEM + bench.RECEIPT_SUFFIX).resolve()]


@pytest.mark.parametrize("suffix", bench.TARGET_SUFFIXES)
def test_each_existing_target_refuses_without_mutation(monkeypatch, suffix):
    events, captures = fake_handshake(monkeypatch)
    target = Path(STEM + suffix)
    with target.open("xb") as stream:
        stream.write(b"original evidence")
    with pytest.raises(FileExistsError):
        bench.coordinate(STEM, ROOT, "guarded-half50")
    assert target.read_bytes() == b"original evidence"
    assert events == [] and captures == []
    assert len(list(Path.cwd().iterdir())) == 1


def test_dangling_wrapper_receipt_refuses(monkeypatch):
    events, captures = fake_handshake(monkeypatch)
    target = Path(STEM + bench.RECEIPT_SUFFIX)
    target.symlink_to("missing-evidence")
    with pytest.raises(FileExistsError):
        bench.coordinate(STEM, ROOT, "guarded-direct")
    assert target.is_symlink() and events == [] and captures == []


@pytest.mark.parametrize(
    "stem,root,mode",
    [
        ("wrong-stem", ROOT, "guarded-direct"),
        ("../escape-loaded-r2", ROOT, "guarded-direct"),
        (STEM, ROOT + "/guarded-eval", "guarded-direct"),
        (STEM, ROOT, "settled-direct"),
        (STEM, ROOT, "frequency"),
    ],
)
def test_invalid_paths_or_modes_create_nothing(monkeypatch, stem, root, mode):
    events, captures = fake_handshake(monkeypatch)
    with pytest.raises(ValueError):
        bench.coordinate(stem, root, mode)
    assert events == [] and captures == [] and list(Path.cwd().iterdir()) == []


@pytest.mark.parametrize(
    "valid,capture_rc,load_rc", [(False, 0, 0), (True, 1, 0), (True, 0, 3)]
)
def test_frozen_launch_guard_and_failure_draining(
    monkeypatch, valid, capture_rc, load_rc
):
    original_modes = bench.base.MODES
    events, captures = fake_handshake(
        monkeypatch, valid=valid, capture_rc=capture_rc, load_rc=load_rc
    )
    result = bench.coordinate(STEM, ROOT, "guarded-direct")
    outcome = result["coordination_outcome"]
    assert result["sources_validated"] and not result["coordination_success"]
    assert result["errors"] and events[-1] == "load_drained"
    assert bool(captures) == valid and outcome["launch_validated"] == valid
    assert outcome["load_helper_returncode"] == load_rc
    assert bench.base.MODES is original_modes


@pytest.mark.parametrize("error", [OSError("failed"), KeyboardInterrupt("interrupted")])
def test_registry_restores_and_receipt_survives_base_exception(monkeypatch, error):
    original_modes = bench.base.MODES

    def fail(*_args):
        assert bench.base.MODES == bench.MODES
        raise error

    monkeypatch.setattr(bench.base, "coordinate", fail)
    result = bench.coordinate(STEM, ROOT, "guarded-half50")
    assert bench.base.MODES is original_modes and not result["coordination_success"]
    assert result["errors"] == [f"{type(error).__name__}: {error}"]
    assert json.loads(Path(STEM + bench.RECEIPT_SUFFIX).read_text()) == result
