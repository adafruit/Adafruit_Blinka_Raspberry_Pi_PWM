"""Offline fixed half50 sequence audit; earlier captures/predicates stay frozen.

The standalone event hook retains the settled ownership/readback/wait policy,
with only the permitted fixed-period half50 duty changed. No evidence is mapped
to a different duty and every physical transition is retained.
"""

import argparse
import copy
import json
import math
import re
from contextlib import contextmanager
from pathlib import Path

import analyze_kernel_pwm_settled as settled

base = settled.base
require = base.require
expected_actions = settled.expected_actions
MODE = "half50-direct"
SEQUENCE_MARKER = "half50-direct-v1"
STRATEGY = settled.STRATEGY
SOURCE_NAMES = settled.SOURCE_NAMES | {"kernel_pwm_half50_eval.py"}
PHASES = (
    ("low50_initial", 0.2, 50, 0),
    ("pwm50_d32768_initial", 0.4, 50, 32768),
    ("high50", 0.3, 50, 65535),
    ("pwm50_d32768_recovery", 0.4, 50, 32768),
    ("low50_final", 0.2, 50, 0),
)


@contextmanager
def half50_registry():
    """Narrow temporary additions; original registry objects always restored."""
    originals = {
        name: getattr(base, name)
        for name in ("SEQUENCES", "PATTERNS", "HOLD_DURATIONS", "PULSE_TARGETS")
    }
    additions = {
        "SEQUENCES": {MODE: PHASES},
        "PATTERNS": {MODE: ("half50", "constant_high", "half50")},
        "HOLD_DURATIONS": {MODE: (0.3,)},
        "PULSE_TARGETS": {"half50": (50, 32768)},
    }
    try:
        for name, original in originals.items():
            require(
                not set(original).intersection(additions[name]),
                "Half50 registry already active",
            )
            setattr(base, name, {**original, **additions[name]})
        yield
    finally:
        for name, original in originals.items():
            setattr(base, name, original)


def validate_events(output, phases, begin, end, waits):
    events = output.get("sysfs_events")
    require(isinstance(events, list) and events, "Missing sysfs event audit")
    generation = output["generation"]
    scopes = {phase["name"]: phase for phase in phases}
    reads = {name: [] for name in scopes}
    actions = {name: [] for name in scopes}
    cleanup_reads = []
    own_waits = [wait for wait in waits if wait["generation"] == generation]
    for ordered, label in ((events, "events"), (own_waits, "waits")):
        previous = begin
        for item in ordered:
            require(isinstance(item, dict), f"Settled {label} must contain objects")
            start, finish = item.get("begin_ns"), item.get("end_ns")
            require(
                type(start) is int
                and type(finish) is int
                and previous <= start <= finish <= end,
                f"Settled {label} clocks invalid or unordered",
            )
            previous = finish
    merged = [(event, False) for event in events] + [(wait, True) for wait in own_waits]
    merged.sort(key=lambda item: item[0]["begin_ns"])
    state, owned, exports, unexports, previous = {}, False, 0, 0, begin
    last_read = None
    allowed = {
        "period": (20_000_000,),
        "duty_cycle": (0, 10_000_152),
        "polarity": ("normal", "inversed"),
        "enable": (0, 1),
    }
    for event, is_wait in merged:
        start, finish, scope = event["begin_ns"], event["end_ns"], event.get("scope")
        require(previous <= start <= finish, "A sysfs action overlaps a strategy wait")
        previous = finish
        require(
            event.get("status") == "ok"
            and scope
            in ("initialization", "cleanup_period_recovery", "cleanup", *scopes),
            "Audit status/scope invalid",
        )
        if scope in scopes:
            phase = scopes[scope]
            require(
                phase["begin_ns"] <= start <= finish <= phase["readback_end_ns"],
                "Audit event/wait outside phase",
            )
        elif scope == "initialization":
            require(finish <= phases[0]["begin_ns"], "Initialization overlaps phases")
        else:
            require(start >= phases[-1]["readback_end_ns"], "Cleanup overlaps phases")
        if is_wait:
            duration = event.get("duration_seconds")
            require(
                scope in scopes
                and owned
                and type(duration) in (int, float)
                and math.isfinite(duration)
                and duration > 0
                and duration - 1e-6 <= (finish - start) / 1e9 <= duration + 1
                and finish <= phase["stable_begin_ns"],
                "Strategy wait duration/phase invalid",
            )
            require(
                state == event.get("state")
                and state.get("duty_cycle") == 0
                and state.get("enable") == 1
                and last_read is not None
                and last_read["scope"] == scope
                and last_read["state"] == state
                and last_read["end_ns"] <= start,
                "Strategy wait lacks preceding enabled zero-duty readback",
            )
            actions[scope].append(("wait", event.get("reason"), duration, dict(state)))
            continue
        operation = event.get("operation")
        require(operation in ("write", "readback"), "Audit operation invalid")
        if operation == "write":
            attribute, value = event.get("attribute"), event.get("value")
            if attribute in ("export", "unexport"):
                require(
                    event.get("path") == f"{output['chip']}/{attribute}" and value == 2,
                    "Ownership writes must target approved channel2",
                )
                if attribute == "export":
                    require(
                        not owned and not exports and scope == "initialization",
                        "Fresh ownership audit failed",
                    )
                    owned, exports = True, 1
                else:
                    require(
                        owned
                        and not unexports
                        and scope == "cleanup"
                        and state == base.state_for(50, 0, 0),
                        "Unexport must follow normal-low restored disabled state",
                    )
                    owned, unexports = False, 1
            else:
                require(
                    owned
                    and attribute in allowed
                    and value in allowed[attribute]
                    and event.get("path") == f"{output['chip']}/pwm2/{attribute}",
                    "Audit write path/attribute/value invalid",
                )
                require(
                    attribute != "period" or state.get("duty_cycle", 0) == 0,
                    "Period must change at zero duty",
                )
                if scope in scopes:
                    require(
                        state.get("enable") == 1 and attribute != "enable",
                        "Settled phases must stay enabled without enable toggles",
                    )
                    actions[scope].append(("write", attribute, value))
                else:
                    require(
                        attribute != "polarity" or state.get("enable") == 0,
                        "Initialization/cleanup polarity must switch disabled",
                    )
                state[attribute] = value
                last_read = None
                require(
                    state.get("polarity") != "inversed"
                    or state.get("duty_cycle", 0) == 0,
                    "Inversed state permits zero duty only",
                )
        else:
            require(
                owned
                and event.get("state") == event.get("expected") == state
                and set(state) == {"period", "duty_cycle", "polarity", "enable"},
                "Audit readback differs from expected/written state",
            )
            last_read = event
            if scope in scopes:
                require(state["enable"] == 1, "Phase readback must remain enabled")
                reads[scope].append(event)
            elif scope == "cleanup" and state == base.state_for(50, 0):
                cleanup_reads.append(event)
    require(
        exports == unexports == 1
        and not owned
        and events[0].get("attribute") == "export"
        and events[-1].get("attribute") == "unexport",
        "Audit needs one fresh export/final unexport",
    )
    require(
        len(cleanup_reads) >= 2
        and cleanup_reads[-1]["begin_ns"] - cleanup_reads[0]["end_ns"] >= 90_000_000,
        "Audit lacks settled enabled normal-low cleanup",
    )
    previous_state = base.state_for(50, 0)
    for phase in phases:
        name, target = phase["name"], phase["sysfs_readbacks"]["18"]
        require(
            actions[name] == expected_actions(previous_state, target),
            f"Phase {name} writes/waits differ from enabled settled policy",
        )
        final_reads = [read for read in reads[name] if read["state"] == target]
        require(
            any(read["end_ns"] <= phase["stable_begin_ns"] for read in final_reads)
            and any(read["begin_ns"] >= phase["end_ns"] for read in final_reads),
            "Audit lacks exact requested phase start/end readbacks",
        )
        previous_state = target


def validate_metadata(metadata, remote):
    require(
        isinstance(metadata, dict)
        and isinstance(remote, dict)
        and metadata.get("mode") == remote.get("mode") == MODE
        and metadata.get("sequence_marker")
        == remote.get("sequence_marker")
        == SEQUENCE_MARKER,
        "Expected exact fixed half50-direct-v1 sequence marker and mode",
    )
    require(
        metadata.get("remote") == remote, "remote.stdout disagrees with results.json"
    )
    provenance = remote.get("metadata")
    hashes = provenance.get("source_sha256") if isinstance(provenance, dict) else None
    require(
        isinstance(hashes, dict)
        and set(hashes) == SOURCE_NAMES
        and all(
            isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
            for value in hashes.values()
        ),
        "Missing exact five-source SHA256 provenance",
    )
    adapted_metadata, adapted_remote = copy.deepcopy(metadata), copy.deepcopy(remote)
    adapted_remote["metadata"]["source_sha256"].pop("kernel_pwm_half50_eval.py")
    adapted_metadata["remote"] = adapted_remote
    original = settled.validate_events
    try:
        settled.validate_events = validate_events
        with half50_registry():
            return settled.validate_metadata(adapted_metadata, adapted_remote)
    finally:
        settled.validate_events = original


def analyze(directory):
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    remote = json.loads((directory / "remote.stdout").read_text())
    mode = validate_metadata(metadata, remote)
    settings = base.validate_saved_capture(directory / "waveform.sal")
    waveform, edges = base.read_continuous(directory / "digital_0.bin")
    with half50_registry():
        physical = base.waveform_facts(mode, waveform, edges)
    return {
        "capture": directory.name,
        "mode": mode,
        "host": metadata["host"],
        "sequence_marker": SEQUENCE_MARKER,
        "transition_strategy": STRATEGY,
        "offline_analysis": True,
        "accepted": physical["accepted"],
        "rejection_reasons": physical["rejection_reasons"],
        "sample_rate_hz": base.SAMPLE_RATE_HZ,
        "saved_capture_settings": settings,
        "waveform": waveform,
        "physical": physical,
        "enabled_settled_audit_validated": True,
        "strategy_waits_reported": remote["strategy_waits"],
        "sysfs_released_reported": True,
        "cleanup_normal_low_confirmed_reported": True,
        "source_sha256_reported": remote["metadata"]["source_sha256"],
        "clock_alignment": "Pi monotonic phase clocks are not aligned to Saleae; no command latency claim.",
        "quantization": {
            "nominal_sample_interval_ns": 10,
            "timebase_calibrated": False,
            "width_bounds_include_clock_accuracy": False,
        },
        "limitation": "Finite 100 MSa/s digital threshold observation, no glitch filter: not analog proof "
        "or exclusion of sub-sample glitches. Every captured transition, including boundaries, is retained. "
        "Strategy waits and cached sysfs readbacks do not establish physical settling or latency.",
    }


def write_analysis(directory, output_name="analysis.json"):
    require(
        bool(output_name)
        and Path(output_name).name == output_name
        and output_name not in (".", ".."),
        "Output must be a filename inside capture directory",
    )
    result = analyze(directory)
    with (Path(directory) / output_name).open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output-name", default="analysis.json")
    args = parser.parse_args()
    try:
        report = write_analysis(args.directory, args.output_name)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["accepted"] else 1)


if __name__ == "__main__":
    main()
