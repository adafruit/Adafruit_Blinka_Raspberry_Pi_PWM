"""Fixed guarded captures with the frozen two-worker CPU-load coordinator.

No GPIO, load, recorder or capture implementation is added here. Source hashes
are checked before launch and only the coordinator's reviewed capture registry
is temporarily replaced. Its original receipt remains untouched; the separate
exclusive wrapper receipt is provenance/outcome, not proof of load overlap or
waveform acceptance. Independently audit the raw captures and Pi-clock receipts.
"""

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

import capture_kernel_pwm_loaded as base

MODES = {
    "guarded-direct": ("capture_kernel_pwm_guarded.py", "guarded-eval", "direct"),
    "guarded-half50": (
        "capture_kernel_pwm_guarded.py",
        "guarded-eval",
        "half50-direct",
    ),
}
EXPECTED_REUSED_SHA256 = {
    "capture_kernel_pwm_loaded.py": "479eade31269ee00535112eb99fedf92bb47dc0cb1d57c40534de829410eed4b",
    "record_kernel_pwm_cpu_load.py": "6f755cdb1d2a8dc4a2af72248ddda88740ab2a3ab123ac5a1afe82e52d06974d",
    "capture_kernel_pwm_guarded.py": "bd41cc2b8bcf68b9ccc303009aaa423f0ec68325d38a910c3ea91ffa4c1d254a",
}
RECEIPT_SUFFIX = ".guarded-coordinator.json"
TARGET_SUFFIXES = (
    "",
    ".load.stdout",
    ".load.stderr",
    ".capture.stdout",
    ".capture.stderr",
    ".coordination.json",
    RECEIPT_SUFFIX,
)


def source_hashes():
    paths = {
        "capture_kernel_pwm_loaded.py": Path(base.__file__),
        "record_kernel_pwm_cpu_load.py": Path(base.recorder.__file__),
        "capture_kernel_pwm_guarded.py": Path(__file__).with_name(
            "capture_kernel_pwm_guarded.py"
        ),
        Path(__file__).name: Path(__file__),
    }
    return {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in paths.items()
    }


def coordinate(stem, remote_root, mode):
    # Match the frozen coordinator's path restrictions before reserving a file.
    if not isinstance(stem, str) or not re.fullmatch(r"[A-Za-z0-9_-]+-loaded-r2", stem):
        raise ValueError("Use a fresh simple stem ending -loaded-r2")
    if not isinstance(remote_root, str) or not re.fullmatch(
        r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}", remote_root
    ):
        raise ValueError("Requires the isolated Pi 5 bench root")
    if mode not in MODES:
        raise ValueError("Only guarded-direct and guarded-half50 are approved")
    targets = [Path(stem + suffix) for suffix in TARGET_SUFFIXES]
    if any(path.exists() or path.is_symlink() for path in targets):
        raise FileExistsError("Fresh capture and receipt targets are required")
    summary = {
        "schema_version": 1,
        "stem": stem,
        "mode": mode,
        "remote_root": remote_root,
        "base_coordination_receipt": stem + ".coordination.json",
        "expected_reused_source_sha256": EXPECTED_REUSED_SHA256,
        "source_sha256": {},
        "sources_validated": False,
        "coordination_outcome": None,
        "coordination_success": False,
        "errors": [],
        "overlap_verified": False,
        "waveform_accepted": None,
    }
    with Path(stem + RECEIPT_SUFFIX).open("x") as stream:
        try:
            summary["source_sha256"] = source_hashes()
            mismatches = [
                name
                for name, expected in EXPECTED_REUSED_SHA256.items()
                if summary["source_sha256"].get(name) != expected
            ]
            if mismatches:
                raise ValueError(
                    "Frozen source hash mismatch: " + ", ".join(mismatches)
                )
            summary["sources_validated"] = True
            original_modes = base.MODES
            try:
                base.MODES = MODES
                result = base.coordinate(stem, remote_root, mode)
            finally:
                base.MODES = original_modes
            summary["coordination_outcome"] = {
                name: result[name]
                for name in (
                    "coordination_success",
                    "launch_validated",
                    "launch_validation_errors",
                    "capture_started",
                    "load_helper_returncode",
                    "load_recorder_exit_code",
                    "load_recorder_error",
                    "capture_returncode",
                    "capture_error",
                )
            }
            summary["coordination_success"] = result["coordination_success"]
            if not summary["coordination_success"]:
                summary["errors"].append(
                    "Frozen coordinator reported unsuccessful outcome"
                )
        except BaseException as error:  # noqa: BLE001 - retain interruption evidence.
            summary["errors"].append(f"{type(error).__name__}: {error}")
        finally:
            json.dump(summary, stream, indent=2)
            stream.write("\n")
            stream.flush()
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stem")
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--mode", choices=tuple(MODES), required=True)
    args = parser.parse_args(argv)
    try:
        result = coordinate(args.stem, args.remote_root, args.mode)
    except BaseException as error:  # noqa: BLE001 - CLI reports retained failures.
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        return 1
    print(
        json.dumps(
            {
                name: result[name]
                for name in (
                    "stem",
                    "mode",
                    "sources_validated",
                    "coordination_success",
                    "errors",
                )
            }
        )
    )
    return 0 if result["coordination_success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
