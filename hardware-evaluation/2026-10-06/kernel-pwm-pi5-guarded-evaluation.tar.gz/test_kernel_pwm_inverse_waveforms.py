"""Synthetic offline fixtures only: never connect to GPIO, SSH or Saleae."""

import json
import struct
import zipfile

import pytest

from analyze_kernel_pwm_inverse import (
    ACTIVE_DUTY_NS,
    MODE,
    OUTPUT,
    PERIOD_NS,
    PHASES,
    SAMPLE_RATE_HZ,
    analyze,
    expected_readback,
    write_analysis,
)


def pattern_edges():
    high = ACTIVE_DUTY_NS / 1e9
    def controls(offset):
        return [
            edge
            for index in range(20)
            for edge in (offset + index * 0.02, offset + index * 0.02 + high)
        ]

    return controls(0.4) + [1.0, 1.3, 1.5, 1.8] + controls(2.0)


def binary_export(
    path,
    edges,
    *,
    initial=0,
    begin=0.0,
    end=2.9,
    rate=SAMPLE_RATE_HZ,
    chunks=1,
    version=1,
):
    data = b"<SALEAE>" + struct.pack("<ii", version, 0)
    if version:
        data += struct.pack("<Q", chunks)
    for _ in range(chunks):
        data += struct.pack("<I", initial)
        if version:
            data += struct.pack("<d", rate)
        data += struct.pack("<ddQ", begin, end, len(edges))
        data += struct.pack(f"<{len(edges)}d", *edges)
    path.write_bytes(data)


def saved_capture(
    path,
    *,
    rate=SAMPLE_RATE_HZ,
    channels=None,
    glitch=None,
    simulated=False,
    device_id="9365449156077141808",
):
    data = {
        "legacySettings": {
            "enabledChannels": channels
            if channels is not None
            else [{"type": "Digital", "index": 0}],
            "sampleRate": {"digital": rate},
            "glitchFilter": glitch
            if glitch is not None
            else {"enabled": False, "channels": []},
        },
        "legacyDevice": {"isSimulation": simulated, "deviceId": device_id},
    }
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("meta.json", json.dumps({"version": 22, "data": data}))


def metadata_files(directory):
    """Generate helper-shaped audit times, intentionally unrelated to edges."""
    chip = "/sys/class/pwm/pwmchip1"
    start, tick = 90_000_000_000, 90_000_010_000
    events, phases, state = [], [], {}
    scope = "initialization"

    def write(attribute, value):
        nonlocal tick
        path = (
            f"{chip}/{attribute}"
            if attribute in ("export", "unexport")
            else f"{chip}/pwm2/{attribute}"
        )
        events.append(
            {
                "operation": "write",
                "scope": scope,
                "path": path,
                "attribute": attribute,
                "value": value,
                "begin_ns": tick,
                "end_ns": tick + 1000,
                "status": "ok",
            }
        )
        tick += 2000
        if attribute not in ("export", "unexport"):
            state[attribute] = value

    def read():
        nonlocal tick
        events.append(
            {
                "operation": "readback",
                "scope": scope,
                "expected": dict(state),
                "state": dict(state),
                "begin_ns": tick,
                "end_ns": tick + 1000,
                "status": "ok",
            }
        )
        tick += 2000
        return dict(state)

    for attribute, value in (
        ("export", 2),
        ("enable", 0),
        ("polarity", "normal"),
        ("period", PERIOD_NS),
        ("duty_cycle", 0),
        ("enable", 1),
    ):
        write(attribute, value)
    tick += 100_000_000
    read()
    for name, duration, polarity, duty, intent in PHASES:
        scope, begin = name, tick
        if state["polarity"] != polarity:
            write("enable", 0)
            write("polarity", polarity)
            write("duty_cycle", duty)
            read()
            write("enable", 1)
        else:
            write("duty_cycle", duty)
        initial_readback = read()
        stable = tick
        tick += round(duration * 1e9)
        hold_end = tick
        end_readback = read()
        phases.append(
            {
                "name": name,
                "duration_seconds": duration,
                "polarity": polarity,
                "duty_ns": duty,
                "duty_u16": 4915 if duty else 0,
                "intent": intent,
                "transition_begin_ns": begin,
                "begin_ns": begin,
                "stable_begin_ns": stable,
                "end_ns": hold_end,
                "readback_end_ns": tick,
                "sysfs_readbacks": {"18": initial_readback},
                "end_readbacks": {"18": end_readback},
            }
        )
    scope = "cleanup"
    for attribute, value in (("enable", 0), ("polarity", "normal"), ("duty_cycle", 0)):
        write(attribute, value)
    read()
    write("enable", 1)
    read()
    tick += 100_000_000
    read()
    write("enable", 0)
    read()
    write("unexport", 2)
    output = {
        "gpio": 18,
        "channel": 2,
        "chip": chip,
        "of_node": "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/pwm@98000",
        "compatible": ["raspberrypi,rp1-pwm"],
        "gpio_of_node": None,
        "backend": "rp1-pwm",
        "frequency": 50,
        "duty_u16": 4915,
        "period_ns": PERIOD_NS,
        "active_duty_ns": ACTIVE_DUTY_NS,
        "sysfs_events": events,
        "cleanup_low_confirmed": True,
        "cleanup_final_readback": expected_readback("normal", 0, 0),
        "released": True,
    }
    thermal = {"temperature_millic": "40000", "throttled": "throttled=0x0"}
    remote = {
        "schema_version": 1,
        "mode": MODE,
        "model": "Raspberry Pi 5 Model B Rev 1.0",
        "begin_ns": start,
        "end_ns": tick + 200_000_000,
        "phases": phases,
        "sysfs_released": True,
        "low_confirmed": True,
        "outputs": [output],
        "burner_pids": [],
        "hard_max_run_seconds": 14,
        "thermal": {"before": dict(thermal), "after": dict(thermal)},
        "cleanup_errors": [],
        "metadata": {
            "source_sha256": {
                "kernel_pwm_eval.py": "a" * 64,
                "kernel_pwm_inverse_eval.py": "b" * 64,
            }
        },
    }
    metadata = {
        "host": "test-pi5.local",
        "mode": MODE,
        "sample_rate_hz": SAMPLE_RATE_HZ,
        "outputs": [dict(OUTPUT)],
        "providers_left_loaded_until_reboot": True,
        "production_backend_unchanged": True,
        "remote": remote,
    }
    replace_metadata(directory, metadata)
    return metadata


def replace_metadata(directory, metadata):
    (directory / "remote.stdout").write_text(json.dumps(metadata["remote"]))
    (directory / "results.json").write_text(json.dumps(metadata))


@pytest.fixture
def capture(tmp_path):
    metadata_files(tmp_path)
    saved_capture(tmp_path / "waveform.sal")
    binary_export(tmp_path / "digital_0.bin", pattern_edges())
    return tmp_path


def test_topology_and_recovered_controls_without_clock_alignment(capture):
    report = analyze(capture)
    assert report["accepted"] is True
    assert report["physical"]["physical_sequence_validated"] is True
    assert report["physical"]["phase_alignment_proven"] is False
    assert report["physical"]["additional_captured_low_dips_inside_high_holds"] == 0
    assert [control["pulse_count"] for control in report["physical"]["controls"]] == [
        20,
        20,
    ]
    assert report["outputs"][0]["waveform"]["edge_count"] == 84
    assert report["saved_capture_settings"]["glitch_filter_enabled"] is False
    for hold in report["physical"]["inverse_zero_high_holds"]:
        assert hold["digitized_high_width_seconds"] == pytest.approx(0.3)
        assert hold["sampling_only_width_bounds_seconds"] == pytest.approx(
            [0.3 - 1e-8, 0.3 + 1e-8]
        )
    assert "not analog proof" in report["limitation"]
    assert report["quantization"]["timebase_calibrated"] is False


@pytest.mark.parametrize("version", [0, 1])
def test_both_documented_binary_versions(capture, version):
    binary_export(capture / "digital_0.bin", pattern_edges(), version=version)
    assert analyze(capture)["accepted"] is True


@pytest.mark.parametrize("dip_ns", [10, 20, 100])
@pytest.mark.parametrize("offset", [1.000001, 1.1, 1.299999, 1.6])
def test_no_digitized_low_dip_is_merged_or_filtered(capture, dip_ns, offset):
    edges = sorted(pattern_edges() + [offset, offset + dip_ns * 1e-9])
    binary_export(capture / "digital_0.bin", edges)
    with pytest.raises(ValueError, match="extra transitions|uninterrupted"):
        analyze(capture)


@pytest.mark.parametrize(
    "kwargs,match",
    [
        ({"initial": 1}, "start low"),
        ({"end": 2.45}, "final low tail"),
        ({"begin": 0.3}, "initial low coverage"),
        ({"rate": 10_000_000}, "sample rate"),
        ({"chunks": 2}, "continuous capture chunk"),
    ],
)
def test_binary_coverage_rate_and_state_rejections(capture, kwargs, match):
    binary_export(capture / "digital_0.bin", pattern_edges(), **kwargs)
    with pytest.raises(ValueError, match=match):
        analyze(capture)


def test_final_high_rejected(capture):
    binary_export(capture / "digital_0.bin", pattern_edges()[:-1])
    with pytest.raises(ValueError, match="finish low"):
        analyze(capture)


@pytest.mark.parametrize(
    "change,match",
    [
        ({"rate": 10_000_000}, "SAL must confirm 100"),
        ({"channels": [{"type": "Digital", "index": 1}]}, "channel0 only"),
        ({"glitch": {"enabled": True, "channels": [0]}}, "glitch filter"),
        ({"glitch": {"enabled": False, "channels": [0]}}, "glitch filter"),
        ({"simulated": True}, "non-simulated"),
        ({"device_id": "1234"}, "unexpected device"),
    ],
)
def test_saved_settings_are_required_not_just_requested(capture, change, match):
    saved_capture(capture / "waveform.sal", **change)
    with pytest.raises(ValueError, match=match):
        analyze(capture)


@pytest.mark.parametrize(
    "mutate,match",
    [
        (lambda m: m.update(host="test2-pi4.local"), "Pi 5 bench host"),
        (lambda m: m.update(sample_rate_hz=10_000_000), "100 MSa/s"),
        (lambda m: m.update(production_backend_unchanged=False), "backend unchanged"),
        (lambda m: m["outputs"][0].update(saleae_channel=1), "output mapping"),
        (lambda m: m["remote"].update(burner_pids=[1]), "no load workers"),
        (lambda m: m["remote"].update(low_confirmed=False), "cleanup errors"),
        (lambda m: m["remote"].update(cleanup_errors=["failed"]), "cleanup errors"),
        (lambda m: m["remote"]["outputs"][0].update(channel=3), "header RP1"),
        (
            lambda m: m["remote"]["outputs"][0].update(of_node="/rp1/pwm@9c000"),
            "header RP1",
        ),
        (
            lambda m: m["remote"]["outputs"][0].update(cleanup_low_confirmed=False),
            "Cleanup must confirm",
        ),
        (
            lambda m: m["remote"]["phases"][3].update(polarity="normal"),
            "polarity/duty/intent",
        ),
        (
            lambda m: m["remote"]["phases"][3].update(duty_ns=PERIOD_NS),
            "polarity/duty/intent",
        ),
        (
            lambda m: m["remote"]["phases"][3].update(duration_seconds=0.2),
            "requested duration",
        ),
        (
            lambda m: m["remote"]["phases"][3]["end_readbacks"]["18"].update(enable=0),
            "end_readbacks",
        ),
        (
            lambda m: m["remote"]["thermal"]["after"].update(throttled="throttled=0x1"),
            "thermal/firmware",
        ),
        (
            lambda m: m["remote"]["metadata"].update(source_sha256={}),
            "SHA256 provenance",
        ),
    ],
)
def test_strict_metadata_rejections(capture, mutate, match):
    metadata = json.loads((capture / "results.json").read_text())
    mutate(metadata)
    replace_metadata(capture, metadata)
    with pytest.raises(ValueError, match=match):
        analyze(capture)


@pytest.mark.parametrize(
    "mutate,match",
    [
        (lambda e: e[0].update(value=3), "channel2"),
        (
            lambda e: e[1].update(path="/sys/class/pwm/pwmchip0/pwm3/enable"),
            "unexpected path",
        ),
        (lambda e: e[1].update(status="error"), "operation/status/scope"),
        (lambda e: e[6]["state"].update(enable=0), "readback audit"),
        (
            lambda e: e[-1].update(scope="normal_low_final"),
            "outside its reported phase",
        ),
    ],
)
def test_sysfs_audit_rejections(capture, mutate, match):
    metadata = json.loads((capture / "results.json").read_text())
    mutate(metadata["remote"]["outputs"][0]["sysfs_events"])
    replace_metadata(capture, metadata)
    with pytest.raises(ValueError, match=match):
        analyze(capture)


def test_regular_controls_reject_missing_cycle(capture):
    edges = pattern_edges()
    del edges[8:10]
    binary_export(capture / "digital_0.bin", edges)
    with pytest.raises(ValueError, match="missing cycles"):
        analyze(capture)


def test_remote_copy_must_match(capture):
    remote = json.loads((capture / "remote.stdout").read_text())
    remote["low_confirmed"] = False
    (capture / "remote.stdout").write_text(json.dumps(remote))
    with pytest.raises(ValueError, match="disagrees"):
        analyze(capture)


def test_exclusive_writer_preserves_existing_output(capture):
    result = write_analysis(capture)
    original = (capture / "analysis.json").read_bytes()
    assert json.loads(original)["accepted"] == result["accepted"]
    with pytest.raises(FileExistsError):
        write_analysis(capture)
    assert (capture / "analysis.json").read_bytes() == original
    with pytest.raises(ValueError, match="filename"):
        write_analysis(capture, "../outside.json")
