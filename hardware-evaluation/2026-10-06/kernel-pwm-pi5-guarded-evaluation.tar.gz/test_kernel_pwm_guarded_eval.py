"""Bounded guarded-wait fake sysfs/signals only; never drive hardware."""

import hashlib
import importlib.util
import json
import signal
import sys
from pathlib import Path

import pytest

import test_kernel_pwm_settled_eval as settled_fakes

SCRIPT = Path(__file__).with_name("kernel_pwm_guarded_eval.py")
spec = importlib.util.spec_from_file_location("kernel_pwm_guarded_eval", SCRIPT)
bench = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = bench
spec.loader.exec_module(bench)
state, core = bench.state, bench.core


@pytest.fixture
def tree(tmp_path):
    return settled_fakes.state_fakes.inverse_fakes.common_fakes.tree.__wrapped__(
        tmp_path
    )


@pytest.fixture
def provider(tree):
    return core.discover(tree[1], tree[0])[1][0]


@pytest.fixture(autouse=True)
def fake_time_and_signals(monkeypatch):
    tick = 80_000_000_000

    def now():
        nonlocal tick
        tick += 1000
        return tick

    def sleep(duration):
        nonlocal tick
        tick += round(duration * 1e9)

    monkeypatch.setattr(bench.settled.time, "monotonic_ns", now)
    monkeypatch.setattr(bench.settled.time, "sleep", sleep)
    monkeypatch.setattr(state.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(state.signal, "signal", lambda _sig, _handler: signal.SIG_DFL)


def make_channel(provider, **kwargs):
    io = kwargs.pop("io", settled_fakes.EnabledIO())
    return bench.GuardedPWMChannel(provider, io=io, **kwargs), io


@pytest.mark.parametrize(
    "old,new,logical,seconds",
    [
        (50, 50, 65535, [0.021]),
        (500, 500, 65535, [0.003]),
        (50, 500, 32768, [0.021, 0.021]),
        (500, 50, 4915, [0.003, 0.021]),
    ],
)
def test_exact_old_new_period_mappings(provider, old, new, logical, seconds):
    channel, _io = make_channel(provider)
    channel.transition(old, 4915 if old == 50 else 32768)
    channel.strategy_waits.clear()
    channel.transition(new, logical)
    assert [wait["duration_seconds"] for wait in channel.strategy_waits] == seconds
    assert all(
        wait["status"] == "ok" and wait["guard_seconds"] == 0.001
        for wait in channel.strategy_waits
    )
    assert channel._guard_wait_context is None
    channel.close()
    assert channel.released and channel.cleanup_low_confirmed


@pytest.mark.parametrize("old,new", [(50, 500), (500, 50)])
def test_high_frequency_change_stays_enabled_inverse_zero(provider, old, new):
    channel, io = make_channel(provider)
    channel.transition(old, 65535)
    channel.strategy_waits.clear()
    io.log.clear()
    channel.transition(new, 65535)
    assert io.writes == [("period", 1_000_000_000 // new)]
    assert len(channel.strategy_waits) == 1
    wait = channel.strategy_waits[0]
    assert wait["duration_seconds"] == 0.021 and wait["reason"] == "period_settle"
    assert wait["state"] == state.requested_state(new, 65535)
    channel.close()


@pytest.mark.parametrize(
    "reason,duration,readback",
    [
        ("wrong", 0.04, state.requested_state(50, 0)),
        ("normal_zero_settle", 0.004, state.requested_state(50, 0)),
        ("normal_zero_settle", float("nan"), state.requested_state(50, 0)),
        ("normal_zero_settle", True, state.requested_state(50, 0)),
        ("normal_zero_settle", 0.04, state.requested_state(50, 4915)),
        ("period_settle", 0.004, state.requested_state(500, 0)),
    ],
)
def test_unapproved_wait_inputs_refused_without_wait(
    provider, reason, duration, readback
):
    channel, io = make_channel(provider)
    channel._guard_wait_context = {
        "old_period": 20_000_000,
        "new_period": 2_000_000,
        "period_polarity": "normal",
    }
    writes = len(io.log)
    with pytest.raises(core.BenchError):
        channel._wait_strategy(reason, duration, readback)
    assert channel.strategy_waits == [] and len(io.log) == writes
    channel._guard_wait_context = None
    channel.close()


@pytest.mark.parametrize("mode", bench.MODES)
def test_fixed_modes_schema_source_and_restoration(tree, monkeypatch, mode):
    found, io = settled_fakes.configure_experiment(tree, monkeypatch)
    originals = bench.settled.SettledPWMChannel, state.StatePWMChannel, state.SEQUENCES
    result = bench.experiment(mode)
    assert (
        bench.settled.SettledPWMChannel,
        state.StatePWMChannel,
        state.SEQUENCES,
    ) == originals
    assert result["transition_strategy"] == bench.STRATEGY
    assert result["sequence_marker"] == f"guarded-{mode}-v1"
    assert (
        result["guard_seconds"] == 0.001
        and result["guard_is_latency_guarantee"] is False
    )
    assert result["wait_policy"] == bench.WAIT_POLICY
    sequence = (
        bench.HALF50_PHASES if mode == bench.HALF50_MODE else state.SEQUENCES[mode]
    )
    assert [phase["name"] for phase in result["phases"]] == [
        phase[0] for phase in sequence
    ]
    for wait in result["strategy_waits"]:
        assert (
            wait["duration_seconds"] == wait["two_period_reference_seconds"] / 2 + 0.001
        )
        assert wait["duration_seconds"] == wait["nominal_period_seconds"] + 0.001
        assert wait["status"] == "ok" and wait["begin_ns"] < wait["end_ns"]
    assert (
        result["cleanup_errors"] == []
        and result["sysfs_released"]
        and result["low_confirmed"]
    )
    assert all(
        output["cleanup_final_readback"] == state.requested_state(50, 0) | {"enable": 0}
        for output in result["outputs"]
    )
    hashes = result["metadata"]["source_sha256"]
    assert set(hashes) == {
        "kernel_pwm_eval.py",
        "kernel_pwm_inverse_eval.py",
        "kernel_pwm_state_eval.py",
        "kernel_pwm_settled_eval.py",
        "kernel_pwm_guarded_eval.py",
    }
    assert (
        hashes["kernel_pwm_guarded_eval.py"]
        == hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
    )
    assert all(not provider.channel_path.exists() for provider in found)
    assert all(
        path.parent in (found[0].chip, found[0].channel_path) for path, _ in io.log
    )


@pytest.mark.parametrize("reason", ["normal_zero_settle", "period_settle"])
def test_signal_during_wait_restores_hooks_and_cleanup(tree, monkeypatch, reason):
    guard = core.SafetySignals()
    found, io = settled_fakes.configure_experiment(tree, monkeypatch, guard=guard)
    originals = bench.settled.SettledPWMChannel, state.StatePWMChannel, state.SEQUENCES
    original_sleep = bench.settled.time.sleep
    waits = 0

    def interrupt(duration):
        nonlocal waits
        if duration == 0.021:
            waits += 1
            if waits == (1 if reason == "normal_zero_settle" else 2):
                guard.handler(signal.SIGTERM, None)
        original_sleep(duration)

    monkeypatch.setattr(bench.settled.time, "sleep", interrupt)
    with pytest.raises(core.SafetyAbort):
        bench.experiment("frequency")
    assert (
        bench.settled.SettledPWMChannel,
        state.StatePWMChannel,
        state.SEQUENCES,
    ) == originals
    assert io.writes[-1] == ("unexport", 2)
    assert not found[0].channel_path.exists()


def test_period_error_restores_hooks_and_safe_cleanup(tree, monkeypatch):
    found, io = settled_fakes.configure_experiment(tree, monkeypatch)
    io.fail = ("period", 2)
    originals = bench.settled.SettledPWMChannel, state.StatePWMChannel, state.SEQUENCES
    with pytest.raises(OSError):
        bench.experiment("frequency")
    assert (
        bench.settled.SettledPWMChannel,
        state.StatePWMChannel,
        state.SEQUENCES,
    ) == originals
    assert not found[0].channel_path.exists()


@pytest.mark.parametrize("mode", ["other", None, True])
def test_invalid_modes_never_export(tree, monkeypatch, mode):
    _found, io = settled_fakes.configure_experiment(tree, monkeypatch)
    with pytest.raises(core.BenchError, match="fixed guarded"):
        bench.experiment(mode)
    assert io.log == []


def test_cli_failure_never_emits_success(tree, monkeypatch, capsys):
    _found, io = settled_fakes.configure_experiment(tree, monkeypatch)
    io.fail = ("export", 1)
    assert bench.main(["--mode", "direct"]) == 1
    captured = capsys.readouterr()
    assert captured.out == "" and "OSError" in captured.err


def test_cli_success_marked_characterization(tree, monkeypatch, capsys):
    settled_fakes.configure_experiment(tree, monkeypatch)
    assert bench.main(["--mode", "half50-direct"]) == 0
    assert json.loads(capsys.readouterr().out)["guard_is_latency_guarantee"] is False
