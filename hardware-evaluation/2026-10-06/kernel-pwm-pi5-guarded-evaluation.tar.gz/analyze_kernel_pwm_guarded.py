"""Offline one-period-plus-1ms diagnostic audit; frozen waveform rules unchanged.

Actual writes, waits, readbacks and every raw threshold edge remain evidence.
Only the expected wait policy is temporarily substituted in the original event
validators. No cached readback or userspace wait establishes electrical latency.
"""

import argparse
import copy
import json
import math
from contextlib import contextmanager, nullcontext
from pathlib import Path

import analyze_kernel_pwm_half50 as half50
import analyze_kernel_pwm_settled as settled

base = settled.base
require = base.require
MODES = ("direct", "frequency", "lifecycle", "half50-direct")
STRATEGY = "enabled-single-period-guard-v1"
GUARD_SECONDS = 0.001
WAIT_POLICY = "one applicable nominal requested period plus 1 ms characterization guard"
EXPECTED_SOURCE_HASHES = {
    "kernel_pwm_eval.py": "7cb4ea051e346b38b3276b92e5e0edcd9f24f4ed36f7d4f4eeffa4800f8e2111",
    "kernel_pwm_inverse_eval.py": "545b0fd16aaee668040f757be0e49e6021492ff5d64e13a94d8166983164fdbf",
    "kernel_pwm_state_eval.py": "9ba7b5ad0893fbc71d508e2f16a91e7f8b5808bc5d749c7c54210ed50186f7f4",
    "kernel_pwm_settled_eval.py": "ed6c22e6adc31977071c53c67f3267dcd29d92369746b4b5768f455f8f2ab33c",
    "kernel_pwm_guarded_eval.py": "142f0afcc8786252ade1a461386715d0d5dbb2f8394c26dcbb40eb34ab635b0b",
}
REFERENCE_ACTIONS = settled.expected_actions


def sequence_marker(mode):
    require(mode in MODES, "Unsupported guarded mode")
    return f"guarded-{mode}-v1"


def expected_actions(previous, target):
    """Keep each original write/state; change only the expected wait duration."""
    return [
        (action[0], action[1], action[2] / 2 + GUARD_SECONDS, action[3])
        if action[0] == "wait"
        else action
        for action in REFERENCE_ACTIONS(previous, target)
    ]


@contextmanager
def guarded_hooks(mode):
    originals = (
        settled.expected_actions,
        half50.expected_actions,
        settled.validate_events,
    )
    try:
        settled.expected_actions = expected_actions
        half50.expected_actions = expected_actions
        if mode == "half50-direct":
            settled.validate_events = half50.validate_events
        with half50.half50_registry() if mode == "half50-direct" else nullcontext():
            yield
    finally:
        (
            settled.expected_actions,
            half50.expected_actions,
            settled.validate_events,
        ) = originals


def validate_metadata(metadata, remote):
    require(
        isinstance(metadata, dict) and isinstance(remote, dict),
        "Guarded metadata must be objects",
    )
    mode = metadata.get("mode")
    require(mode in MODES and remote.get("mode") == mode, "Unexpected guarded mode")
    require(
        metadata.get("remote") == remote, "remote.stdout disagrees with results.json"
    )
    require(
        metadata.get("transition_strategy")
        == remote.get("transition_strategy")
        == STRATEGY
        and metadata.get("sequence_marker")
        == remote.get("sequence_marker")
        == sequence_marker(mode),
        "Guarded strategy/sequence marker mismatch",
    )
    require(
        remote.get("wait_policy") == WAIT_POLICY
        and type(remote.get("guard_seconds")) in (int, float)
        and remote["guard_seconds"] == GUARD_SECONDS
        and remote.get("guard_is_latency_guarantee") is False,
        "Guarded characterization wait policy mismatch",
    )
    provenance = remote.get("metadata")
    require(
        isinstance(provenance, dict)
        and provenance.get("source_sha256") == EXPECTED_SOURCE_HASHES,
        "Exact frozen five-source SHA256 provenance required",
    )
    waits = remote.get("strategy_waits")
    require(isinstance(waits, list), "Missing guarded strategy waits")
    for wait in waits:
        require(isinstance(wait, dict), "Invalid guarded strategy wait")
        nominal, guard, reference, duration = (
            wait.get(name)
            for name in (
                "nominal_period_seconds",
                "guard_seconds",
                "two_period_reference_seconds",
                "duration_seconds",
            )
        )
        require(
            all(
                type(value) in (int, float) and math.isfinite(value)
                for value in (nominal, guard, reference, duration)
            )
            and nominal in (0.002, 0.02)
            and guard == GUARD_SECONDS
            and reference == 2 * nominal
            and duration == nominal + guard,
            "Guarded wait nominal period/reference/1ms guard mismatch",
        )
    # Remove only the independently pinned new provenance key and adapt the
    # strategy marker in a copy. Actual events/waits/duties are never rewritten;
    # half50 uses its original registry and 10000152 ns permitted duty directly.
    adapted_metadata, adapted_remote = copy.deepcopy(metadata), copy.deepcopy(remote)
    adapted_remote["metadata"]["source_sha256"].pop("kernel_pwm_guarded_eval.py")
    adapted_metadata["transition_strategy"] = settled.STRATEGY
    adapted_remote["transition_strategy"] = settled.STRATEGY
    adapted_metadata["remote"] = adapted_remote
    with guarded_hooks(mode):
        return settled.validate_metadata(adapted_metadata, adapted_remote)


def analyze(directory):
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    remote = json.loads((directory / "remote.stdout").read_text())
    mode = validate_metadata(metadata, remote)
    settings = base.validate_saved_capture(directory / "waveform.sal")
    waveform, edges = base.read_continuous(directory / "digital_0.bin")
    with half50.half50_registry() if mode == "half50-direct" else nullcontext():
        physical = base.waveform_facts(mode, waveform, edges)
    return {
        "capture": directory.name,
        "mode": mode,
        "host": metadata["host"],
        "transition_strategy": STRATEGY,
        "sequence_marker": sequence_marker(mode),
        "wait_policy": WAIT_POLICY,
        "guard_is_latency_guarantee": False,
        "offline_analysis": True,
        "accepted": physical["accepted"],
        "rejection_reasons": physical["rejection_reasons"],
        "sample_rate_hz": base.SAMPLE_RATE_HZ,
        "saved_capture_settings": settings,
        "waveform": waveform,
        "physical": physical,
        "enabled_guarded_audit_validated": True,
        "strategy_waits_reported": remote["strategy_waits"],
        "sysfs_released_reported": True,
        "cleanup_normal_low_confirmed_reported": True,
        "source_sha256_reported": remote["metadata"]["source_sha256"],
        "clock_alignment": "Pi monotonic phase clocks are not aligned to Saleae; no command latency claim.",
        "quantization": {
            "nominal_sample_interval_ns": 10,
            "timebase_calibrated": False,
            "width_bounds_include_clock_accuracy": False,
        },
        "limitation": "Finite unfiltered 100 MSa/s digital threshold observation, not analog proof or exclusion of sub-sample glitches. Every captured transition and the original strict waveform predicates are retained. The 1ms guard is experimental, not a physical settling or latency guarantee.",
    }


def write_analysis(directory, output_name="analysis.json"):
    require(
        bool(output_name)
        and Path(output_name).name == output_name
        and output_name not in (".", ".."),
        "Output must be a filename inside capture directory",
    )
    report = analyze(directory)
    with (Path(directory) / output_name).open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output-name", default="analysis.json")
    args = parser.parse_args(argv)
    try:
        report = write_analysis(args.directory, args.output_name)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(report, indent=2))
    return 0 if report["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
