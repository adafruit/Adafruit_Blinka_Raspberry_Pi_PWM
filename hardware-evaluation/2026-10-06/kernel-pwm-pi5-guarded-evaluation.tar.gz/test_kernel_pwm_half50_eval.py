"""Fake-only fixed half50 sequence/provenance/abort checks."""

import hashlib
import importlib.util
import json
import signal
import sys
from pathlib import Path

import pytest

import test_kernel_pwm_settled_eval as settled_fakes

SCRIPT = Path(__file__).with_name("kernel_pwm_half50_eval.py")
spec = importlib.util.spec_from_file_location("kernel_pwm_half50_eval", SCRIPT)
half50 = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = half50
spec.loader.exec_module(half50)
state = half50.settled.state
core = state.core


@pytest.fixture
def tree(tmp_path):
    return settled_fakes.state_fakes.inverse_fakes.common_fakes.tree.__wrapped__(
        tmp_path
    )


@pytest.fixture(autouse=True)
def no_sleep_or_physical_signals(monkeypatch):
    monkeypatch.setattr(half50.settled.time, "sleep", lambda _seconds: None)
    monkeypatch.setattr(state.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(state.signal, "signal", lambda _sig, _handler: signal.SIG_DFL)


def test_fixed_sequence_mapping_waits_provenance_and_namespace_restoration(
    tree, monkeypatch
):
    found, io = settled_fakes.configure_experiment(tree, monkeypatch)
    original_sequences = state.SEQUENCES
    original_channel = state.StatePWMChannel
    result = half50.experiment()
    assert state.SEQUENCES is original_sequences
    assert state.StatePWMChannel is original_channel
    assert half50.MODE not in state.SEQUENCES
    assert result["mode"] == "half50-direct"
    assert result["sequence_marker"] == "half50-direct-v1"
    assert result["transition_strategy"] == "enabled-period-settled-v1"
    assert [phase["name"] for phase in result["phases"]] == [
        phase[0] for phase in half50.PHASES
    ]
    assert [phase["duration_seconds"] for phase in result["phases"]] == [
        0.2,
        0.4,
        0.3,
        0.4,
        0.2,
    ]
    assert [phase["duty_u16"] for phase in result["phases"]] == [
        0,
        32768,
        65535,
        32768,
        0,
    ]
    assert all(
        phase["frequency"] == 50 and phase["generation"] == 1
        for phase in result["phases"]
    )
    for phase in result["phases"]:
        assert phase["sysfs_readbacks"] == phase["end_readbacks"]
        assert phase["sysfs_readbacks"]["18"] == state.requested_state(
            50, phase["duty_u16"]
        )
    assert len(result["strategy_waits"]) == 1
    wait = result["strategy_waits"][0]
    assert wait["scope"] == "high50" and wait["reason"] == "normal_zero_settle"
    assert wait["duration_seconds"] == 0.04 and wait["status"] == "ok"
    assert wait["state"] == state.requested_state(50, 0)
    assert result["low_confirmed"] and result["sysfs_released"]
    assert result["cleanup_errors"] == [] and result["burner_pids"] == []
    output = result["outputs"][0]
    assert output["released"] and output["cleanup_low_confirmed"]
    assert output["cleanup_final_readback"] == state.requested_state(50, 0) | {
        "enable": 0
    }
    assert all(
        path.parent in (found[0].chip, found[0].channel_path) for path, _value in io.log
    )
    assert all(not provider.channel_path.exists() for provider in found)
    hashes = result["metadata"]["source_sha256"]
    assert set(hashes) == {
        "kernel_pwm_eval.py",
        "kernel_pwm_inverse_eval.py",
        "kernel_pwm_state_eval.py",
        "kernel_pwm_settled_eval.py",
        "kernel_pwm_half50_eval.py",
    }
    assert (
        hashes["kernel_pwm_half50_eval.py"]
        == hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
    )


def test_error_restores_namespaces_preserves_primary_and_cleans_low(
    tree, monkeypatch, capsys
):
    found, io = settled_fakes.configure_experiment(tree, monkeypatch)
    original_sequences = state.SEQUENCES
    original_channel = state.StatePWMChannel

    def fail_inversion(path, value):
        if path.name == "polarity" and value == "inversed":
            raise ValueError("half50 injected transition error")

    io.hook = fail_inversion
    assert half50.main([]) == 1
    captured = capsys.readouterr()
    assert (
        captured.out == ""
        and "ValueError: half50 injected transition error" in captured.err
    )
    assert (
        state.SEQUENCES is original_sequences
        and state.StatePWMChannel is original_channel
    )
    assert not found[0].channel_path.exists()
    assert io.writes[-1] == ("unexport", 2)


def test_signal_during_settle_restores_namespaces_and_safe_release(
    tree, monkeypatch, capsys
):
    guard = core.SafetySignals()
    found, io = settled_fakes.configure_experiment(tree, monkeypatch, guard=guard)
    original_sequences = state.SEQUENCES
    original_channel = state.StatePWMChannel

    def interrupt(duration):
        if duration == 0.04:
            guard.handler(signal.SIGTERM, None)

    monkeypatch.setattr(half50.settled.time, "sleep", interrupt)
    assert half50.main(["--mode", half50.MODE]) == 1
    captured = capsys.readouterr()
    assert captured.out == "" and "SafetyAbort" in captured.err
    assert (
        state.SEQUENCES is original_sequences
        and state.StatePWMChannel is original_channel
    )
    assert not found[0].channel_path.exists()
    assert ("polarity", "inversed") not in io.writes


def test_cleanup_failure_is_not_success_and_retains_ownership(
    tree, monkeypatch, capsys
):
    found, io = settled_fakes.configure_experiment(tree, monkeypatch)
    io.fail = ("unexport", 1)
    original_sequences = state.SEQUENCES
    assert half50.main([]) == 1
    captured = capsys.readouterr()
    assert captured.out == "" and "Cleanup failures:" in captured.err
    assert found[0].channel_path.exists() and state.SEQUENCES is original_sequences


def test_wrapped_failure_always_restores_sequences(monkeypatch):
    original_sequences = state.SEQUENCES

    def fail(mode):
        assert mode == half50.MODE
        assert state.SEQUENCES[mode] == half50.PHASES
        raise KeyboardInterrupt("wrapper interrupted")

    monkeypatch.setattr(half50.settled, "experiment", fail)
    with pytest.raises(KeyboardInterrupt):
        half50.experiment()
    assert state.SEQUENCES is original_sequences


@pytest.mark.parametrize("args", [[], ["--mode", "half50-direct"]])
def test_cli_fixed_mode_json(monkeypatch, capsys, args):
    monkeypatch.setattr(half50, "experiment", lambda: {"mode": half50.MODE})
    assert half50.main(args) == 0
    captured = capsys.readouterr()
    assert json.loads(captured.out) == {"mode": "half50-direct"}
    assert captured.err == ""
