"""Fixed lab characterization using one nominal period plus a 1 ms guard.

The frozen settled channel owns GPIO18/channel2 and retains its transition
writes and conservative cleanup. Only the two-period strategy waits change.
Nominal requested periods are not latch acknowledgments or calibrated clock
measurements; these shorter waits are not safety or production latency bounds.
No arbitrary pins, timings, production changes, MMIO, or scheduling changes.
"""

import argparse
import hashlib
import json
import math
import sys
from pathlib import Path

import kernel_pwm_settled_eval as settled

state = settled.state
core = state.core
STRATEGY = "enabled-single-period-guard-v1"
GUARD_SECONDS = 0.001
WAIT_POLICY = "one applicable nominal requested period plus 1 ms characterization guard"
HALF50_MODE = "half50-direct"
HALF50_PHASES = (
    ("low50_initial", 0.2, 50, 0),
    ("pwm50_d32768_initial", 0.4, 50, 32768),
    ("high50", 0.3, 50, 65535),
    ("pwm50_d32768_recovery", 0.4, 50, 32768),
    ("low50_final", 0.2, 50, 0),
)
MODES = ("direct", "frequency", "lifecycle", HALF50_MODE)
FrozenSettledPWMChannel = settled.SettledPWMChannel


def require(condition, message):
    if not condition:
        raise core.BenchError(message)


class GuardedPWMChannel(FrozenSettledPWMChannel):
    def __init__(self, provider, **kwargs):
        self._guard_wait_context = None
        super().__init__(provider, **kwargs)

    def transition(self, frequency, duty_u16):
        # This wrapper records only nominal context for validating wait inputs.
        # The inherited transition still performs every write/readback unchanged.
        target = state.requested_state(frequency, duty_u16)
        require(self._guard_wait_context is None, "Nested guarded transition")
        self._guard_wait_context = {
            "old_period": self.period_ns,
            "new_period": target["period"],
            "period_polarity": "inversed"
            if self.last_requested_duty_u16 == duty_u16 == 65535
            else "normal",
        }
        try:
            return super().transition(frequency, duty_u16)
        finally:
            self._guard_wait_context = None

    def _wait_strategy(self, reason, duration, readback):
        context = self._guard_wait_context
        require(
            context is not None and reason in ("normal_zero_settle", "period_settle"),
            "Guarded wait requires active transition and approved reason",
        )
        if reason == "normal_zero_settle":
            period = context["old_period"]
            expected_state = {
                "period": period,
                "duty_cycle": 0,
                "polarity": "normal",
                "enable": 1,
            }
        else:
            period = max(context["old_period"], context["new_period"])
            expected_state = {
                "period": context["new_period"],
                "duty_cycle": 0,
                "polarity": context["period_polarity"],
                "enable": 1,
            }
        reference = 2 * period / 1_000_000_000
        require(
            period in (2_000_000, 20_000_000)
            and type(duration) in (int, float)
            and math.isfinite(duration)
            and math.isclose(duration, reference, rel_tol=0, abs_tol=1e-12)
            and readback == expected_state,
            "Guarded wait duration/readback differs from exact old/new nominal period",
        )
        reduced = duration / 2 + GUARD_SECONDS
        count = len(self.strategy_waits)
        try:
            super()._wait_strategy(reason, reduced, readback)
        finally:
            if len(self.strategy_waits) > count:
                self.strategy_waits[-1].update(
                    nominal_period_seconds=period / 1_000_000_000,
                    guard_seconds=GUARD_SECONDS,
                    two_period_reference_seconds=duration,
                )


def experiment(mode):
    require(
        type(mode) is str and mode in MODES,
        "Only fixed guarded experiment modes are approved",
    )
    original_channel, original_sequences = settled.SettledPWMChannel, state.SEQUENCES
    try:
        settled.SettledPWMChannel = GuardedPWMChannel
        state.SEQUENCES = {**original_sequences, HALF50_MODE: HALF50_PHASES}
        result = settled.experiment(mode)
    finally:
        settled.SettledPWMChannel = original_channel
        state.SEQUENCES = original_sequences
    result.update(
        transition_strategy=STRATEGY,
        sequence_marker=f"guarded-{mode}-v1",
        guard_seconds=GUARD_SECONDS,
        wait_policy=WAIT_POLICY,
        guard_is_latency_guarantee=False,
    )
    result["metadata"]["source_sha256"]["kernel_pwm_guarded_eval.py"] = hashlib.sha256(
        Path(__file__).read_bytes()
    ).hexdigest()
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=MODES)
    args = parser.parse_args(argv)
    try:
        result = experiment(args.mode)
    except (core.BenchError, OSError, ValueError) as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
