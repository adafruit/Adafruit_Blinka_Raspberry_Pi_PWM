"""Fixed lab-only 50 Hz half-duty/direct-high/direct-recovery exercise.

Reuses the frozen enabled, period-settled transition owner and its conservative
normal-low cleanup. GPIO18 RP1 header channel 2 only; no additional frequencies,
providers or commands. Cached sysfs readback is not electrical proof.
"""

import argparse
import hashlib
import json
import sys
from pathlib import Path

import kernel_pwm_settled_eval as settled

MODE = "half50-direct"
SEQUENCE_MARKER = "half50-direct-v1"
PHASES = (
    ("low50_initial", 0.2, 50, 0),
    ("pwm50_d32768_initial", 0.4, 50, 32768),
    ("high50", 0.3, 50, 65535),
    ("pwm50_d32768_recovery", 0.4, 50, 32768),
    ("low50_final", 0.2, 50, 0),
)


def experiment():
    original = settled.state.SEQUENCES
    settled.state.SEQUENCES = {**original, MODE: PHASES}
    try:
        result = settled.experiment(MODE)
    finally:
        settled.state.SEQUENCES = original
    result["sequence_marker"] = SEQUENCE_MARKER
    result["metadata"]["source_sha256"]["kernel_pwm_half50_eval.py"] = hashlib.sha256(
        Path(__file__).read_bytes()
    ).hexdigest()
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=(MODE,), default=MODE)
    parser.parse_args(argv)
    try:
        result = experiment()
    except BaseException as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
