"""Fixed half50 fake-helper and synthetic-waveform checks; never use hardware."""

import copy
import json
import signal

import pytest

import analyze_kernel_pwm_half50 as analyzer
import test_kernel_pwm_half50_eval as helper_fakes
from test_kernel_pwm_inverse_waveforms import binary_export, saved_capture
from test_kernel_pwm_state_waveforms import train


def edges_for():
    return train(0.75, 50, 32768) + [1.19, 1.49] + train(1.50, 50, 32768)


def replace_metadata(directory, metadata):
    (directory / "results.json").write_text(json.dumps(metadata))
    (directory / "remote.stdout").write_text(json.dumps(metadata["remote"]))


@pytest.fixture
def metadata(tmp_path, monkeypatch):
    helper = helper_fakes.half50
    tick = 80_000_000_000

    def now():
        nonlocal tick
        tick += 1000
        return tick

    def sleep(duration):
        nonlocal tick
        tick += round(duration * 1e9)

    monkeypatch.setattr(helper.settled.time, "monotonic_ns", now)
    monkeypatch.setattr(helper.settled.time, "sleep", sleep)
    monkeypatch.setattr(helper_fakes.state.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(
        helper_fakes.state.signal, "signal", lambda _sig, _handler: signal.SIG_DFL
    )
    tree = helper_fakes.tree.__wrapped__(tmp_path)
    helper_fakes.settled_fakes.configure_experiment(tree, monkeypatch)
    remote = helper.experiment()
    for output in remote["outputs"]:
        fake_chip = output["chip"]
        output["chip"] = "/sys/class/pwm/pwmchip1"
        output["of_node"] = (
            "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/pwm@98000"
        )
        for event in output["sysfs_events"]:
            if "path" in event:
                event["path"] = event["path"].replace(fake_chip, output["chip"], 1)
    return {
        "mode": analyzer.MODE,
        "host": "test-pi5.local",
        "sample_rate_hz": 100_000_000,
        "transition_strategy": analyzer.STRATEGY,
        "sequence_marker": analyzer.SEQUENCE_MARKER,
        "production_backend_unchanged": True,
        "providers_left_loaded_until_reboot": True,
        "outputs": [
            {"gpio": 18, "saleae_channel": 0, "backend": "kernel-hardware-rp1"}
        ],
        "remote": remote,
    }


def fixture_files(directory, metadata, edges=None):
    replace_metadata(directory, metadata)
    saved_capture(directory / "waveform.sal")
    binary_export(
        directory / "digital_0.bin", edges_for() if edges is None else edges, end=2.6
    )
    return directory


def registry_objects():
    return {
        name: getattr(analyzer.base, name)
        for name in ("SEQUENCES", "PATTERNS", "HOLD_DURATIONS", "PULSE_TARGETS")
    }


def test_complete_half50_sequence_exact_audit_and_restored_registries(
    tmp_path, metadata
):
    untouched, registries = copy.deepcopy(metadata), registry_objects()
    original_audit = analyzer.settled.validate_events
    report = analyzer.analyze(fixture_files(tmp_path, metadata))
    assert report["accepted"] is True, report["rejection_reasons"]
    assert report["waveform"]["edge_count"] == 82
    assert [group["high_count"] for group in report["physical"]["groups"]] == [
        20,
        1,
        20,
    ]
    assert [group["category"] for group in report["physical"]["groups"]] == [
        "half50",
        "constant_high",
        "half50",
    ]
    assert report["physical"]["no_transition_trimming_or_glitch_filtering"]
    assert report["physical"]["phase_alignment_proven"] is False
    assert report["physical"]["ordinary_width_period_tolerance_percent"] == 2
    assert len(report["source_sha256_reported"]) == 5
    assert metadata == untouched
    assert analyzer.settled.validate_events is original_audit
    assert all(
        getattr(analyzer.base, name) is value for name, value in registries.items()
    )
    assert "half50" not in analyzer.base.PULSE_TARGETS


@pytest.mark.parametrize("width_ns", [10, 20])
def test_constant_high_dip_preserved_rejected(tmp_path, metadata, width_ns):
    edges = sorted(edges_for() + [1.3, 1.3 + width_ns / 1e9])
    report = analyzer.write_analysis(fixture_files(tmp_path, metadata, edges))
    assert report["accepted"] is False
    assert len(report["physical"]["sub_microsecond_low_runs"]) == 1
    assert json.loads((tmp_path / "analysis.json").read_text())["accepted"] is False


def test_short_last_outgoing_half50_pulse_rejected(tmp_path, metadata):
    edges = edges_for()
    edges[39] -= 0.001
    report = analyzer.analyze(fixture_files(tmp_path, metadata, edges))
    assert report["accepted"] is False
    assert len(report["physical"]["unexpected_high_runs"]) == 1
    assert report["physical"]["unexpected_high_runs"][0]["pair_index"] == 19


def test_incomplete_ordinary_period_rejected(tmp_path, metadata):
    edges = edges_for()
    edges[20] += 0.001
    edges[21] += 0.001
    report = analyzer.analyze(fixture_files(tmp_path, metadata, edges))
    assert report["accepted"] is False
    assert any(
        "irregular/incomplete periods" in reason
        for reason in report["rejection_reasons"]
    )


@pytest.mark.parametrize(
    "tamper",
    [
        "marker",
        "hash",
        "missing_wait",
        "short_wait",
        "wrong_duty",
        "borrowed_export",
        "cleanup",
    ],
)
def test_policy_and_provenance_invalidity_restores_old_hooks(
    tmp_path, metadata, tamper
):
    remote = metadata["remote"]
    if tamper == "marker":
        metadata["sequence_marker"] = "wrong"
    elif tamper == "hash":
        remote["metadata"]["source_sha256"].pop("kernel_pwm_half50_eval.py")
    elif tamper == "missing_wait":
        remote["strategy_waits"] = []
    elif tamper == "short_wait":
        remote["strategy_waits"][0]["end_ns"] -= 1_000_000
    elif tamper == "wrong_duty":
        remote["phases"][1]["duty_u16"] = 4915
    elif tamper == "borrowed_export":
        remote["outputs"][0]["sysfs_events"].pop(0)
    else:
        remote["outputs"][0]["cleanup_final_readback"]["enable"] = 1
    fixture_files(tmp_path, metadata)
    registries, audit = registry_objects(), analyzer.settled.validate_events
    with pytest.raises(ValueError):
        analyzer.analyze(tmp_path)
    assert analyzer.settled.validate_events is audit
    assert all(
        getattr(analyzer.base, name) is value for name, value in registries.items()
    )


def test_writer_exclusive(tmp_path, metadata):
    fixture_files(tmp_path, metadata)
    analyzer.write_analysis(tmp_path)
    with pytest.raises(FileExistsError):
        analyzer.write_analysis(tmp_path)
    with pytest.raises(ValueError, match="filename inside"):
        analyzer.write_analysis(tmp_path, "../analysis.json")
