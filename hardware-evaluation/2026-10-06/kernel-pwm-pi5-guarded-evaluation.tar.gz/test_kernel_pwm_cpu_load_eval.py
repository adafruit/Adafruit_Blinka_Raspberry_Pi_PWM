"""Fake-process safety tests plus one explicitly shortened local CPU smoke."""

import importlib.util
import json
import signal
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

SCRIPT = Path(__file__).with_name("kernel_pwm_cpu_load_eval.py")
spec = importlib.util.spec_from_file_location("kernel_pwm_cpu_load_eval", SCRIPT)
load = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = load
spec.loader.exec_module(load)


class FakeClock:
    def __init__(self):
        self.now_ns = 1_000_000_000_000

    def monotonic(self):
        return self.now_ns / 1_000_000_000

    def monotonic_ns(self):
        return self.now_ns


class FakeProcess:
    def __init__(
        self,
        clock,
        pid,
        *,
        guard=None,
        normal_timeout=False,
        ignore_term=False,
        kill_failure=False,
        terminate_failure=False,
        returncode=0,
        malformed=False,
        cleanup_signal=False,
    ):
        self.clock = clock
        self.pid = pid
        self.guard = guard
        self.normal_timeout = normal_timeout
        self.ignore_term = ignore_term
        self.kill_failure = kill_failure
        self.terminate_failure = terminate_failure
        self.normal_returncode = returncode
        self.malformed = malformed
        self.cleanup_signal = cleanup_signal
        self.returncode = None
        self.terminated = False
        self.killed = False
        self.calls = []
        self.clock.now_ns += 1_000
        self.begin_ns = clock.now_ns

    def poll(self):
        self.calls.append(("poll",))
        return self.returncode

    def terminate(self):
        self.calls.append(("terminate",))
        if self.cleanup_signal:
            self.guard.handler(signal.SIGTERM, None)
            self.guard.handler(signal.SIGHUP, None)
        if self.terminate_failure:
            raise PermissionError("owned terminate failed")
        self.terminated = True

    def kill(self):
        self.calls.append(("kill",))
        if self.kill_failure:
            raise PermissionError("owned kill failed")
        self.killed = True

    def communicate(self, *, timeout):
        self.calls.append(("communicate", timeout))
        if self.killed:
            self.returncode = -9
        elif self.terminated and not self.ignore_term:
            self.returncode = -15
        elif self.normal_timeout:
            raise subprocess.TimeoutExpired("fixed-worker", timeout)
        else:
            self.returncode = self.normal_returncode
        started = {
            "event": "worker_started",
            "pid": self.pid,
            "begin_ns": self.begin_ns,
            "duration_seconds": load.WORKER_SECONDS,
        }
        reports = [started]
        if self.returncode == 0:
            end_ns = self.begin_ns + int(load.WORKER_SECONDS * 1_000_000_000)
            self.clock.now_ns = max(self.clock.now_ns, end_ns + 1_000)
            reports.append(
                {
                    "event": "worker_completed",
                    "pid": self.pid,
                    "begin_ns": self.begin_ns,
                    "end_ns": end_ns,
                    "duration_seconds": load.WORKER_SECONDS,
                    "iterations": 10,
                }
            )
        if self.malformed:
            return "not json", ""
        return "\n".join(json.dumps(report) for report in reports) + "\n", ""


class Factory:
    def __init__(
        self, clock, *, fail_at=None, guard=None, spawn_signal=None, **options
    ):
        self.clock = clock
        self.fail_at = fail_at
        self.guard = guard
        self.spawn_signal = spawn_signal
        self.options = options
        self.processes = []
        self.calls = []

    def __call__(self, args, **kwargs):
        self.calls.append((args, kwargs))
        assert args == [sys.executable, "-c", load._worker_source()]
        assert "duration = 10\n" in args[-1]
        assert kwargs == {
            "stdin": subprocess.DEVNULL,
            "stdout": subprocess.PIPE,
            "stderr": subprocess.PIPE,
            "text": True,
        }
        if len(self.processes) == self.fail_at:
            raise ValueError("primary spawn failure")
        process = FakeProcess(
            self.clock, 100 + len(self.processes), guard=self.guard, **self.options
        )
        self.processes.append(process)
        if self.spawn_signal is not None:
            self.guard.handler(self.spawn_signal, None)
        return process


@pytest.fixture
def clock(monkeypatch):
    clock = FakeClock()
    monkeypatch.setattr(
        load,
        "time",
        SimpleNamespace(monotonic=clock.monotonic, monotonic_ns=clock.monotonic_ns),
    )
    return clock


@pytest.fixture(autouse=True)
def no_physical_signals(monkeypatch):
    monkeypatch.setattr(load.signal, "signal", lambda _sig, _handler: signal.SIG_DFL)


def test_fixed_two_cpu_only_workers_success_and_receipts(clock):
    factory, receipts = Factory(clock), []
    assert load.run_load(popen_factory=factory, emit=receipts.append) == 0
    assert [receipt["event"] for receipt in receipts] == [
        "load_launched",
        "load_completed",
    ]
    launched, completed = receipts
    assert launched["worker_count"] == 2 and launched["worker_duration_seconds"] == 10
    assert launched["started_worker_count"] == 2 and launched["launch_complete"]
    assert completed["success"] and completed["primary_error"] is None
    assert completed["cleanup_errors"] == [] and completed["signals_received"] == []
    assert (
        len(completed["source_sha256"]) == len(completed["worker_source_sha256"]) == 64
    )
    assert completed["gpio_writes"] is False and completed["pwm_sysfs_access"] is False
    assert completed["kernel_configuration_changes"] is False
    assert [record["pid"] for record in completed["owned_workers"]] == [100, 101]
    for record, process in zip(completed["owned_workers"], factory.processes):
        assert record["returncode"] == 0 and record["reaped"]
        assert (
            record["popen_begin_ns"] <= record["popen_end_ns"] <= record["completed_ns"]
        )
        assert record["worker_receipts"][1]["end_ns"] <= record["completed_ns"]
        assert "process" not in record
        assert not any(call[0] in ("terminate", "kill") for call in process.calls)


@pytest.mark.parametrize("fail_at", [0, 1])
def test_partial_spawn_failure_preserves_primary_and_reaps_only_owned(clock, fail_at):
    factory, receipts = Factory(clock, fail_at=fail_at), []
    assert load.run_load(popen_factory=factory, emit=receipts.append) == 1
    assert len(receipts) == 2
    assert not receipts[0]["launch_complete"]
    assert receipts[0]["started_worker_count"] == fail_at
    completed = receipts[1]
    assert completed["primary_error"] == "ValueError: primary spawn failure"
    assert not completed["success"]
    assert len(completed["owned_workers"]) == fail_at
    for record, process in zip(completed["owned_workers"], factory.processes):
        assert process.terminated and record["returncode"] == -15 and record["reaped"]


@pytest.mark.parametrize("signum", [signal.SIGTERM, signal.SIGINT, signal.SIGHUP])
def test_signal_during_spawn_latches_owner_then_stops_before_second_worker(
    clock, signum
):
    guard, receipts = load.LoadSignals(), []
    factory = Factory(clock, guard=guard, spawn_signal=signum)
    assert load.run_load(popen_factory=factory, emit=receipts.append, guard=guard) == 1
    assert len(factory.processes) == 1 and factory.processes[0].terminated
    assert receipts[1]["owned_workers"][0]["reaped"]
    assert receipts[1]["signals_received"] == [signum]
    assert "ownership handoff" in receipts[1]["primary_error"]
    assert guard.depth == 0


@pytest.mark.parametrize("signum", [signal.SIGTERM, signal.SIGINT, signal.SIGHUP])
def test_signal_after_launch_reaps_both_owned_workers(clock, signum):
    guard, receipts = load.LoadSignals(), []
    factory = Factory(clock, guard=guard)

    def emit(receipt):
        receipts.append(receipt)
        if receipt["event"] == "load_launched":
            guard.handler(signum, None)

    assert load.run_load(popen_factory=factory, emit=emit, guard=guard) == 1
    assert len(receipts) == 2 and not receipts[1]["success"]
    assert receipts[1]["signals_received"] == [signum]
    assert all(process.terminated for process in factory.processes)
    assert all(record["reaped"] for record in receipts[1]["owned_workers"])


def test_normal_timeout_has_shared_deadline_and_owned_kill_fallback(clock):
    factory, receipts = Factory(clock, normal_timeout=True, ignore_term=True), []
    assert load.run_load(popen_factory=factory, emit=receipts.append) == 1
    completed = receipts[1]
    assert "TimeoutExpired" in completed["primary_error"]
    assert not completed["success"] and completed["cleanup_errors"] == []
    for process, record in zip(factory.processes, completed["owned_workers"]):
        assert process.terminated and process.killed
        assert record["returncode"] == -9 and record["reaped"]
        waits = [call[1] for call in process.calls if call[0] == "communicate"]
        assert waits[-2:] == [load.TERMINATE_WAIT_SECONDS, load.KILL_WAIT_SECONDS]
        assert max(waits) <= 12


def test_cleanup_failures_latch_without_replacing_primary(clock):
    guard, receipts = load.LoadSignals(), []
    factory = Factory(
        clock,
        fail_at=1,
        guard=guard,
        normal_timeout=True,
        ignore_term=True,
        kill_failure=True,
        terminate_failure=True,
    )
    assert load.run_load(popen_factory=factory, emit=receipts.append, guard=guard) == 1
    completed = receipts[1]
    assert completed["primary_error"] == "ValueError: primary spawn failure"
    assert not completed["success"]
    assert any("terminate" in error for error in completed["cleanup_errors"])
    assert any("kill" in error for error in completed["cleanup_errors"])
    assert any("reap" in error for error in completed["cleanup_errors"])
    assert completed["owned_workers"][0]["reaped"] is False
    assert completed["owned_workers"][0]["completed_ns"] is None


def test_cleanup_defers_repeated_signals_until_both_owned_workers_reaped(clock):
    guard, receipts = load.LoadSignals(), []
    factory = Factory(clock, fail_at=1, guard=guard, cleanup_signal=True)
    assert load.run_load(popen_factory=factory, emit=receipts.append, guard=guard) == 1
    completed = receipts[1]
    assert completed["primary_error"] == "ValueError: primary spawn failure"
    assert completed["signals_received"] == [signal.SIGTERM, signal.SIGHUP]
    assert completed["owned_workers"][0]["reaped"] and guard.depth == 0


@pytest.mark.parametrize("options", [{"returncode": 3}, {"malformed": True}])
def test_bad_worker_completion_stops_remaining_owned_worker(clock, options):
    factory, receipts = Factory(clock, **options), []
    assert load.run_load(popen_factory=factory, emit=receipts.append) == 1
    assert not receipts[1]["success"] and "LoadError" in receipts[1]["primary_error"]
    assert not factory.processes[0].terminated  # Already reaped; do not signal it.
    assert factory.processes[1].terminated
    assert all(record["reaped"] for record in receipts[1]["owned_workers"])


def test_broken_launch_output_still_cleans_up_owned_processes(clock):
    factory, receipts = Factory(clock), []

    def emit(receipt):
        if receipt["event"] == "load_launched":
            raise BrokenPipeError("receipt pipe closed")
        receipts.append(receipt)

    assert load.run_load(popen_factory=factory, emit=emit) == 1
    assert all(process.terminated for process in factory.processes)
    assert all(record["reaped"] for record in receipts[0]["owned_workers"])
    assert "BrokenPipeError" in receipts[0]["primary_error"]


def test_signal_during_completion_receipt_fails_exit_after_workers_reaped(
    clock, capsys
):
    guard, receipts = load.LoadSignals(), []
    factory = Factory(clock, guard=guard)

    def emit(receipt):
        receipts.append(receipt)
        if receipt["event"] == "load_completed":
            guard.handler(signal.SIGTERM, None)

    assert load.run_load(popen_factory=factory, emit=emit, guard=guard) == 1
    assert len(receipts) == 2
    assert all(record["reaped"] for record in receipts[1]["owned_workers"])
    assert "receipt emission" in capsys.readouterr().err
    assert guard.received == [signal.SIGTERM] and guard.depth == 0


def test_broken_partial_launch_receipt_does_not_skip_worker_cleanup(clock):
    factory = Factory(clock, fail_at=1)

    def emit(_receipt):
        raise BrokenPipeError("closed output")

    assert load.run_load(popen_factory=factory, emit=emit) == 1
    assert factory.processes[0].terminated and factory.processes[0].returncode == -15


@pytest.mark.parametrize(
    "args", [["--seconds", "1"], ["--workers", "4"], ["--command", "anything"]]
)
def test_cli_has_no_user_selectable_load_parameters(monkeypatch, args):
    monkeypatch.setattr(
        load, "run_load", lambda: pytest.fail("Must reject before spawning")
    )
    with pytest.raises(SystemExit) as exc:
        load.main(args)
    assert exc.value.code == 2


def test_emit_is_single_json_line_and_flushed(monkeypatch):
    calls = []
    monkeypatch.setattr(
        load,
        "print",
        lambda *args, **kwargs: calls.append((args, kwargs)),
        raising=False,
    )
    load._emit({"event": "test"})
    assert json.loads(calls[0][0][0]) == {"event": "test"}
    assert calls[0][1] == {"flush": True}


def test_local_real_workers_expire_with_injected_short_duration(monkeypatch):
    # No Pi, GPIO/sysfs calls, or full ten-second load: 80 ms per local worker.
    monkeypatch.setattr(load, "WORKER_SECONDS", 0.08)
    receipts = []
    assert load.run_load(emit=receipts.append) == 0
    assert len(receipts) == 2 and receipts[1]["success"]
    records = receipts[1]["owned_workers"]
    assert len(records) == 2 and records[0]["pid"] != records[1]["pid"]
    assert all(record["reaped"] and record["returncode"] == 0 for record in records)
    assert all(
        record["worker_receipts"][1]["end_ns"]
        - record["worker_receipts"][0]["begin_ns"]
        >= 80_000_000
        for record in records
    )
