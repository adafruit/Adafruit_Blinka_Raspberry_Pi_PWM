"""Fake guarded acquisition orchestration and failure retention; no hardware."""

import json
import shlex
import subprocess
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

import capture_kernel_pwm_guarded as bench

ROOT = "/tmp/blinka-pwm-oct6.abc123/guarded-eval"


def configure(monkeypatch, mode, scenario):
    events = []
    capture = MagicMock()
    capture.__enter__.return_value = capture

    def save(path):
        events.append("save")
        if scenario == "save_error":
            raise OSError("save failed")

    capture.stop.side_effect = lambda: events.append("stop")
    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = lambda _path, **kwargs: events.append(
        ("export", kwargs["digital_channels"])
    )
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = (
        []
        if scenario == "missing_device"
        else [SimpleNamespace(device_id=bench.DEVICE_ID, is_simulation=False)]
    )
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    connection = MagicMock(return_value=manager)
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connection),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            "/usr/bin/python3",
            ROOT + "/kernel_pwm_guarded_eval.py",
            "--mode",
            mode,
        ]
        assert (
            kwargs["timeout"] == 30
            and kwargs["check"] is False
            and kwargs["text"] is True
        )
        assert set(kwargs) == {"stdout", "stderr", "text", "check", "timeout"}
        if scenario in ("timeout", "interrupt"):
            kwargs["stdout"].write("partial received bytes")
            kwargs["stderr"].write("partial diagnostic")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            raise KeyboardInterrupt("interrupted")
        remote = {
            "mode": mode,
            "transition_strategy": "wrong"
            if scenario == "wrong_strategy"
            else bench.STRATEGY,
            "sequence_marker": bench.sequence_marker(mode),
        }
        kwargs["stdout"].write(json.dumps(remote))
        return subprocess.CompletedProcess(
            command, 1 if scenario == "helper_failed" else 0
        )

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)

    def sleep(duration):
        events.append(("sleep", duration))
        if duration == 0.5 and scenario == "lead_interrupt":
            raise KeyboardInterrupt("lead interrupted")

    monkeypatch.setattr(bench.time, "sleep", sleep)

    def validate(metadata, remote):
        assert metadata["remote"] == remote
        assert (
            metadata["pre_helper_lead_seconds"] == 0.5
            and metadata["post_helper_tail_seconds"] == 0.2
        )
        assert metadata["remote_returncode"] == 0
        if remote["transition_strategy"] != bench.STRATEGY:
            raise ValueError("strategy mismatch")
        return mode

    monkeypatch.setattr(bench, "validate_metadata", validate)

    def analyze(directory):
        events.append("analysis")
        report = {
            "accepted": scenario != "waveform_rejected",
            "waveform": {"edge_count": 82},
        }
        (directory / "analysis.json").write_text(json.dumps(report))
        return report

    monkeypatch.setattr(bench, "write_analysis", analyze)
    return events, manager, runner


@pytest.mark.parametrize("mode", bench.MODES)
def test_all_modes_fixed_capture_configuration(monkeypatch, tmp_path, mode):
    events, manager, runner = configure(monkeypatch, mode, "success")
    report = bench.capture_test(tmp_path / "capture", ROOT, mode)
    assert report["accepted"] is True
    assert events == [
        ("sleep", 0.5),
        "ssh",
        ("sleep", 0.2),
        "stop",
        "save",
        ("export", [0]),
        "analysis",
    ]
    manager.start_capture.assert_called_once_with(
        device_id=bench.DEVICE_ID,
        device_configuration={
            "enabled_digital_channels": [0],
            "digital_sample_rate": 100_000_000,
        },
    )
    runner.assert_called_once()
    acquisition = json.loads((tmp_path / "capture" / "acquisition.json").read_text())
    assert (
        acquisition["remote_returncode"] == 0
        and acquisition["primary_error"] is None
        and acquisition["evidence_errors"] == []
    )


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "lead_interrupt",
        "save_error",
        "helper_failed",
        "wrong_strategy",
        "waveform_rejected",
        "missing_device",
    ],
)
def test_failure_receipts_and_remaining_save_attempts(monkeypatch, tmp_path, scenario):
    events, _manager, runner = configure(monkeypatch, "direct", scenario)
    output = tmp_path / "capture"
    with pytest.raises((RuntimeError, ValueError)):
        bench.capture_test(output, ROOT, "direct")
    acquisition = json.loads((output / "acquisition.json").read_text())
    if scenario == "missing_device":
        runner.assert_not_called()
        assert not events
    else:
        assert "stop" in events and "save" in events and ("export", [0]) in events
        assert ("sleep", 0.2) in events
    if scenario in ("timeout", "interrupt"):
        assert (output / "remote.stdout").read_text() == "partial received bytes"
        assert (output / "remote.stderr").read_text() == "partial diagnostic"
        assert acquisition["remote_returncode"] == (
            124 if scenario == "timeout" else None
        )
        assert acquisition["primary_error"]
    if scenario == "lead_interrupt":
        runner.assert_not_called()
        assert (output / "remote.stdout").read_bytes() == b""
    if scenario == "save_error":
        assert acquisition["evidence_errors"] == ["save_capture: OSError: save failed"]
    if scenario == "waveform_rejected":
        assert json.loads((output / "analysis.json").read_text())["accepted"] is False


@pytest.mark.parametrize(
    "root", ["/tmp", ROOT + "/../other", ROOT.replace("guarded-eval", "settled-eval")]
)
def test_invalid_root_never_invokes(monkeypatch, tmp_path, root):
    _events, _manager, runner = configure(monkeypatch, "direct", "success")
    with pytest.raises(ValueError, match="isolated"):
        bench.capture_test(tmp_path / "capture", root, "direct")
    assert not (tmp_path / "capture").exists()
    runner.assert_not_called()


def test_exclusive_directory_never_invokes(monkeypatch, tmp_path):
    _events, _manager, runner = configure(monkeypatch, "direct", "success")
    output = tmp_path / "capture"
    output.mkdir()
    with pytest.raises(FileExistsError):
        bench.capture_test(output, ROOT, "direct")
    runner.assert_not_called()
