"""Bounded fake-helper/synthetic-edge guarded audits; no hardware or SSH."""

import copy
import json

import pytest

import analyze_kernel_pwm_guarded as analyzer
import test_kernel_pwm_guarded_eval as helper_fakes
from test_kernel_pwm_half50_waveforms import edges_for as half50_edges
from test_kernel_pwm_inverse_waveforms import binary_export, saved_capture
from test_kernel_pwm_state_waveforms import edges_for as state_edges


@pytest.fixture
def metadata(tmp_path, monkeypatch):
    tree = helper_fakes.tree.__wrapped__(tmp_path)
    helper_fakes.settled_fakes.configure_experiment(tree, monkeypatch)
    helper_fakes.fake_time_and_signals.__wrapped__(monkeypatch)

    def generate(mode):
        remote = helper_fakes.bench.experiment(mode)
        for output in remote["outputs"]:
            fake_chip = output["chip"]
            output["chip"] = "/sys/class/pwm/pwmchip1"
            output["of_node"] = (
                "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/pwm@98000"
            )
            for event in output["sysfs_events"]:
                if "path" in event:
                    event["path"] = event["path"].replace(fake_chip, output["chip"], 1)
        return {
            "host": "test-pi5.local",
            "mode": mode,
            "sample_rate_hz": 100_000_000,
            "transition_strategy": analyzer.STRATEGY,
            "sequence_marker": analyzer.sequence_marker(mode),
            "production_backend_unchanged": True,
            "providers_left_loaded_until_reboot": True,
            "outputs": [
                {"gpio": 18, "saleae_channel": 0, "backend": "kernel-hardware-rp1"}
            ],
            "remote": remote,
        }

    return generate


def edges_for(mode):
    return half50_edges() if mode == "half50-direct" else state_edges(mode)


def fixture_files(directory, metadata, edges=None):
    (directory / "results.json").write_text(json.dumps(metadata))
    (directory / "remote.stdout").write_text(json.dumps(metadata["remote"]))
    saved_capture(directory / "waveform.sal")
    binary_export(
        directory / "digital_0.bin",
        edges_for(metadata["mode"]) if edges is None else edges,
        end=3.8,
    )
    return directory


def hook_objects():
    return (
        analyzer.settled.expected_actions,
        analyzer.half50.expected_actions,
        analyzer.settled.validate_events,
        analyzer.base.validate_events,
        *(
            getattr(analyzer.base, name)
            for name in ("SEQUENCES", "PATTERNS", "HOLD_DURATIONS", "PULSE_TARGETS")
        ),
    )


@pytest.mark.parametrize("mode", analyzer.MODES)
def test_all_modes_exact_fake_helper_and_frozen_physical_rules(
    tmp_path, metadata, mode
):
    data = metadata(mode)
    untouched, originals = copy.deepcopy(data), hook_objects()
    report = analyzer.analyze(fixture_files(tmp_path, data))
    assert report["accepted"] is True, report["rejection_reasons"]
    assert report["source_sha256_reported"] == analyzer.EXPECTED_SOURCE_HASHES
    assert report["physical"]["ordinary_width_period_tolerance_percent"] == 2
    assert report["physical"]["no_transition_trimming_or_glitch_filtering"] is True
    assert report["physical"]["phase_alignment_proven"] is False
    assert report["waveform"]["transition_seconds"] == edges_for(mode)
    assert all(
        wait["duration_seconds"] in (0.003, 0.021)
        for wait in report["strategy_waits_reported"]
    )
    if mode == "half50-direct":
        assert data["remote"]["phases"][1]["duty_ns"] == 10_000_152
        assert [g["high_count"] for g in report["physical"]["groups"]] == [20, 1, 20]
        assert "kernel_pwm_half50_eval.py" not in report["source_sha256_reported"]
    assert data == untouched
    assert all(before is after for before, after in zip(originals, hook_objects()))


@pytest.mark.parametrize("width_ns", [10, 20])
def test_high_dips_remain_raw_and_rejected(tmp_path, metadata, width_ns):
    edges = sorted(half50_edges() + [1.3, 1.3 + width_ns / 1e9])
    report = analyzer.write_analysis(
        fixture_files(tmp_path, metadata("half50-direct"), edges)
    )
    assert report["accepted"] is False
    assert report["waveform"]["edge_count"] == 84
    assert len(report["physical"]["sub_microsecond_low_runs"]) == 1
    assert json.loads((tmp_path / "analysis.json").read_text())["accepted"] is False


@pytest.mark.parametrize("mode", ["direct", "half50-direct"])
def test_partial_outgoing_pulse_is_not_trimmed(tmp_path, metadata, mode):
    edges = edges_for(mode)
    edges[39] -= 0.001
    report = analyzer.analyze(fixture_files(tmp_path, metadata(mode), edges))
    assert report["accepted"] is False
    assert report["physical"]["unexpected_high_runs"]


@pytest.mark.parametrize(
    "tamper",
    [
        "marker",
        "hash",
        "guard",
        "reference",
        "missing_wait",
        "short_wait",
        "wrong_duty",
        "borrowed_export",
    ],
)
def test_invalid_evidence_restores_all_original_hooks(tmp_path, metadata, tamper):
    data = metadata("half50-direct")
    remote = data["remote"]
    if tamper == "marker":
        data["sequence_marker"] = "wrong"
    elif tamper == "hash":
        remote["metadata"]["source_sha256"]["kernel_pwm_guarded_eval.py"] = "a" * 64
    elif tamper == "guard":
        remote["strategy_waits"][0]["guard_seconds"] = 0
    elif tamper == "reference":
        remote["strategy_waits"][0]["two_period_reference_seconds"] = 0.002
    elif tamper == "missing_wait":
        remote["strategy_waits"] = []
    elif tamper == "short_wait":
        remote["strategy_waits"][0]["end_ns"] -= 1_000_000
    elif tamper == "wrong_duty":
        remote["phases"][1]["duty_ns"] = 1_499_961
    else:
        remote["outputs"][0]["sysfs_events"].pop(0)
    originals = hook_objects()
    with pytest.raises(ValueError):
        analyzer.analyze(fixture_files(tmp_path, data))
    assert all(before is after for before, after in zip(originals, hook_objects()))


def test_exclusive_analysis_no_escape(tmp_path, metadata):
    fixture_files(tmp_path, metadata("direct"))
    analyzer.write_analysis(tmp_path)
    with pytest.raises(FileExistsError):
        analyzer.write_analysis(tmp_path)
    with pytest.raises(ValueError, match="filename inside"):
        analyzer.write_analysis(tmp_path, "../analysis.json")
