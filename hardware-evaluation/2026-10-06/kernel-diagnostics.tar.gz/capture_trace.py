"""Bounded Pi5 diagnostic of unchanged native scheduling with traced syscalls.

Only the confirmed GPIO18/channel0 and GPIO23/channel1 bench is supported.
Instrumentation perturbs timing; this is not a production performance benchmark.
"""

import argparse
import json
import re
import shlex
import subprocess
import uuid
from pathlib import Path

from capture_pwm import BENCH_ROOTS, DEVICE_ID, remote_code, summarize
from saleae import automation


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--shared", action="store_true")
    parser.add_argument("--duration", type=float, default=20)
    parser.add_argument("--load-workers", type=int, default=4)
    parser.add_argument(
        "--kernel",
        action="store_true",
        help="One approved private tracefs capture via non-interactive sudo",
    )
    args = parser.parse_args()
    if not re.fullmatch(r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}", args.remote_root):
        raise ValueError("Expected the fresh isolated October 6 bench directory")
    if not 2 <= args.duration <= 20 or not 0 <= args.load_workers <= 4:
        raise ValueError("Capture is bounded to 2..20 seconds and 0..4 burners")
    if args.kernel and (args.shared or args.duration != 20 or args.load_workers != 4):
        raise ValueError(
            "Approved kernel capture is per-output, 20 seconds, four burners"
        )
    host = "test-pi5.local"
    BENCH_ROOTS[host] = args.remote_root
    output = args.directory.resolve()
    output.mkdir(parents=True, exist_ok=False)
    if not re.fullmatch(r"[A-Za-z0-9_-]+", output.name):
        raise ValueError("Use a simple unambiguous capture directory name")
    remote_trace = f"{args.remote_root}/{output.name}.csv"
    source_path = f"{args.remote_root}/trace-source/src"
    specs = [
        {"gpio": 18, "frequency": 50, "duty": 4915},
        {"gpio": 23, "frequency": 500, "duty": 32768},
    ]
    code = remote_code(
        50,
        4915,
        "draft",
        duration=args.duration,
        load_workers=args.load_workers,
        short_slice=True,
        gpio=18,
        output_specs=specs,
        host=host,
        shared=args.shared,
    )
    anchor = "from adafruit_blinka_raspberry_pi_pwm import PWMOut, __version__"
    preflight = f"""
os.environ["PWM_TRACE_PATH"] = {remote_trace!r}
sys.path.insert(0, {source_path!r})
{anchor}
from adafruit_blinka_raspberry_pi_pwm import _native
if not Path(_native.__file__).resolve().is_relative_to(Path({source_path!r})):
    raise RuntimeError("Not using the isolated instrumented extension")
trace = ctypes.CDLL(_native.__file__)
trace.pwm_trace_status.restype = ctypes.c_int
trace_status = trace.pwm_trace_status()
if trace_status:
    raise OSError(trace_status, "Trace preflight failed before requesting any GPIO")
"""
    assert code.count(anchor) == 1
    code = code.replace(anchor, preflight)
    if args.kernel:
        # Trace setup can take up to eight seconds before active PWM. Keep the
        # bounded burners alive through the entire active interval; finally
        # still stops them immediately after output/helper cleanup.
        load_deadline = f"time.monotonic() + {args.duration + 5}"
        assert code.count(load_deadline) == 1
        code = code.replace(load_deadline, f"time.monotonic() + {args.duration + 15}")
        kernel_output = f"{args.remote_root}/{output.name}-kernel"
        instance_name = "blinka-pwm-oct6-" + uuid.uuid4().hex[:12]
        hook = f"""
        tids = [t["tid"] for t in thread_settings if t["tid"] != os.getpid()]
        if len(tids) != 2:
            raise RuntimeError("Cannot identify exactly two native PWM workers")
        Path({kernel_output!r}).mkdir(mode=0o700)
        lifecycle_events["load_worker_pids"] = [process.pid for process in load]
        lifecycle_events["load_watchdog_seconds"] = {args.duration + 15}
        kernel = subprocess.Popen(["sudo", "-n", "/usr/bin/python3",
            {str(Path(args.remote_root) / "kernel_trace_helper.py")!r},
            "--instance", {instance_name!r}, "--parent-pid", str(os.getpid()),
            "--worker-tids", ",".join(map(str, tids)), "--output-dir", {kernel_output!r}],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        def finish_kernel():
            timed_out = False
            try:
                stdout, stderr = kernel.communicate("STOP\\n", timeout=8)
            except subprocess.TimeoutExpired:
                timed_out = True
                if kernel.stdin and not kernel.stdin.closed:
                    kernel.stdin.close()
                kernel.terminate()  # sudo forwards TERM; helper runs its cleanup.
                try:
                    stdout, stderr = kernel.communicate(timeout=5)
                except subprocess.TimeoutExpired as exc:
                    raise RuntimeError("Kernel helper cleanup unconfirmed; check private instance") from exc
            lifecycle_events["kernel_helper_stdout"] = stdout
            lifecycle_events["kernel_helper_stderr"] = stderr
            if timed_out or kernel.returncode:
                raise RuntimeError("Kernel helper failed: " + stdout + stderr)
        stack.callback(finish_kernel)
        readable, _, _ = select.select([kernel.stdout], [], [], 8)
        if not readable:
            raise RuntimeError("Kernel helper readiness timed out")
        ready = json.loads(kernel.stdout.readline())
        if not ready.get("ready"):
            raise RuntimeError("Kernel helper did not become ready: " + json.dumps(ready))
        lifecycle_events["kernel_instance"] = ready["instance"]
"""
        code = "import select\n" + code
        anchor = "        active_before = resource.getrusage(resource.RUSAGE_SELF)"
        assert code.count(anchor) == 1
        code = code.replace(anchor, hook + "\n" + anchor)
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        f"pi@{host}",
        f"{args.remote_root}/venv/bin/python -c {shlex.quote(code)}",
    ]
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        assert any(
            d.device_id == DEVICE_ID and not d.is_simulation
            for d in manager.get_devices()
        )
        configuration = automation.LogicDeviceConfiguration(
            enabled_digital_channels=[0, 1], digital_sample_rate=10_000_000
        )
        with manager.start_capture(
            device_id=DEVICE_ID, device_configuration=configuration
        ) as capture:
            try:
                remote = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    check=False,
                    timeout=args.duration + (30 if args.kernel else 20),
                )
            except subprocess.TimeoutExpired as exc:
                # Preserve partial command output alongside the physical trace.
                def decoded(value):
                    return (
                        value.decode(errors="replace")
                        if isinstance(value, bytes)
                        else value or ""
                    )

                remote = subprocess.CompletedProcess(
                    command,
                    124,
                    decoded(exc.stdout),
                    decoded(exc.stderr) + "\nSSH capture timed out",
                )
            finally:
                capture.stop()
                capture.save_capture(str(output / "waveform.sal"))
                capture.export_raw_data_binary(str(output), digital_channels=[0, 1])
        (output / "remote.stdout").write_text(remote.stdout)
        (output / "remote.stderr").write_text(remote.stderr)
        assert remote.returncode == 0, remote.stderr
        footer = re.search(
            r"PWM_TRACE attempted=(\d+) written=(\d+) dropped=(\d+) "
            r"init_error=(\d+) io_error=(\d+) clock_error=(\d+)",
            remote.stderr,
        )
        assert footer, "Missing exit-time trace footer"
        attempted, written, dropped, init_error, io_error, clock_error = map(
            int, footer.groups()
        )
        assert attempted == written and not (
            dropped or init_error or io_error or clock_error
        )
        subprocess.run(
            [
                "scp",
                "-q",
                "-o",
                "BatchMode=yes",
                "-o",
                "ConnectTimeout=8",
                f"pi@{host}:{remote_trace}",
                str(output / "trace.csv"),
            ],
            check=True,
            timeout=20,
        )
        if args.kernel:
            for filename in ("kernel-trace.txt", "kernel-meta.json"):
                subprocess.run(
                    [
                        "scp",
                        "-q",
                        "-o",
                        "BatchMode=yes",
                        "-o",
                        "ConnectTimeout=8",
                        f"pi@{host}:{kernel_output}/{filename}",
                        str(output / filename),
                    ],
                    check=True,
                    timeout=20,
                )
            kernel_meta = json.loads((output / "kernel-meta.json").read_text())
            assert (
                kernel_meta["instance_removed"] and kernel_meta["top_state_unchanged"]
            )
            assert (
                not kernel_meta["error"] and kernel_meta["stop_reason"] == "parent_stop"
            )
        result = {
            "host": host,
            "backend": "instrumented-draft",
            "production_commit": "d5debaf0e5caafa1fdf5a7619e1ae2e8cd41f1f4",
            "output_duration_seconds": args.duration,
            "sample_rate_hz": 10_000_000,
            "logic_version": manager.get_app_info().app_version,
            "trace": {"attempted": attempted, "written": written, "dropped": dropped},
            "instrumentation_is_not_a_performance_benchmark": True,
            "remote": json.loads(remote.stdout),
            "outputs": [],
        }
        for channel, spec in enumerate(specs):
            result["outputs"].append(
                {
                    **spec,
                    "saleae_channel": channel,
                    "timing": summarize(
                        output / f"digital_{channel}.bin",
                        spec["frequency"],
                        spec["duty"],
                        "draft",
                    ),
                }
            )
        (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
        assert result["remote"]["thermal_acceptance"]["valid"], "Thermally rejected"
        for item in result["outputs"]:
            assert item["timing"]["final_state"] == 0
            assert item["timing"]["quiet_tail_seconds"] >= 0.1
        print(
            json.dumps(
                {
                    "capture": output.name,
                    "shared": args.shared,
                    "trace_records": written,
                    "temperature_after_millic": result["remote"]["system_after"][
                        "temperature_millic"
                    ],
                    "outputs": [
                        {
                            "gpio": o["gpio"],
                            "high_max_us": o["timing"]["high_us"]["max"],
                            "max_period_us": o["timing"]["period_us"]["max"],
                        }
                        for o in result["outputs"]
                    ],
                }
            )
        )


if __name__ == "__main__":
    main()
