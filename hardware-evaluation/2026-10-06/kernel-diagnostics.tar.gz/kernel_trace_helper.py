"""Root-only bounded tracefs helper; no GPIO, policy, sysctl, or global writes.

Parent PWM remains unprivileged. Controls one newly created, named instance;
stdin STOP/EOF or a 30-second watchdog stops tracing. Exports before removing
only that instance with tracefs's rmdir API. No recursive deletion is used.
"""

import argparse
import json
import os
import re
import select
import signal
import stat
import sys
import time
from pathlib import Path

TRACEFS = Path("/sys/kernel/tracing")
TOP_FILES = ("tracing_on", "current_tracer", "trace_clock", "buffer_size_kb")


def top_state():
    return {name: (TRACEFS / name).read_text().strip() for name in TOP_FILES}


def checked_write(path, value):
    with path.open("w") as stream:
        stream.write(str(value) + "\n")


def exclusive_output(directory_fd, name, data, uid, gid):
    fd = os.open(
        name,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
        0o600,
        dir_fd=directory_fd,
    )
    with os.fdopen(fd, "w") as stream:
        stream.write(data)
        stream.flush()
        os.fchown(stream.fileno(), uid, gid)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--instance", required=True)
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--worker-tids", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError("Invoke with non-interactive sudo")
    uid, gid = int(os.environ["SUDO_UID"]), int(os.environ["SUDO_GID"])
    if uid != 1000 or uid == 0:
        raise RuntimeError("Only the authorized Pi bench user is supported")
    if not re.fullmatch(r"blinka-pwm-oct6-[a-f0-9]{12}", args.instance):
        raise ValueError("Unexpected instance name")
    output = args.output_dir.resolve(strict=True)
    if not re.fullmatch(
        r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/[A-Za-z0-9_-]+-kernel", str(output)
    ):
        raise ValueError("Output must be the fresh isolated bench capture directory")
    # Pin both bench directories before privileged exports. No pathname is
    # resolved again when creating output files, even if pi renames a directory.
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    parent_fd = os.open(output.parent, flags)
    try:
        if os.fstat(parent_fd).st_uid != uid:
            raise ValueError("Bench directory must belong to the bench user")
        output_fd = os.open(output.name, flags, dir_fd=parent_fd)
    finally:
        os.close(parent_fd)
    if os.fstat(output_fd).st_uid != uid:
        raise ValueError("Output directory must belong to the bench user")
    if os.listdir(output_fd):
        raise ValueError("Output directory is not empty")
    workers = [int(value) for value in args.worker_tids.split(",")]
    if len(workers) != 2 or len(set(workers)) != 2:
        raise ValueError("Requires exactly two unique per-output worker TIDs")
    parent = Path("/proc") / str(args.parent_pid)
    if args.parent_pid <= 1 or parent.stat().st_uid != uid:
        raise ValueError("Parent is not the bench user's process")
    command = (parent / "cmdline").read_bytes().split(b"\0")[0].decode()
    if not re.fullmatch(
        r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/venv/bin/python", command
    ):
        raise ValueError("Parent is not the isolated bench Python")
    for tid in workers:
        task = parent / "task" / str(tid)
        if tid <= 1 or tid == args.parent_pid or task.stat().st_uid != uid:
            raise ValueError("Invalid live worker identity")

    pid_filter = " || ".join(f"pid == {tid}" for tid in workers)
    common_filter = " || ".join(f"common_pid == {tid}" for tid in workers)
    switch_filter = " || ".join(
        f"prev_pid == {tid} || next_pid == {tid}" for tid in workers
    )
    filters = {
        "sched/sched_waking": pid_filter,
        "sched/sched_wakeup": pid_filter,
        "sched/sched_migrate_task": pid_filter,
        "sched/sched_switch": switch_filter,
        "timer/hrtimer_init": common_filter,
        "timer/hrtimer_start": common_filter,
        "timer/hrtimer_cancel": common_filter,
        "timer/hrtimer_expire_entry": "function.function == hrtimer_wakeup",
    }
    before = top_state()
    instance = TRACEFS / "instances" / args.instance
    created = False
    identity = None
    meta = {
        "instance": args.instance,
        "parent_pid": args.parent_pid,
        "worker_tids": workers,
        "trace_clock": "mono",
        "filters": filters,
        "events": list(filters),
        "buffer_kb_per_cpu": 8192,
        "watchdog_seconds": 30,
        "top_before": before,
        "expiry_callback_filter_includes_other_sleepers": True,
    }
    enabled = []
    error = None

    def terminate(signum, frame):
        raise InterruptedError(f"Helper interrupted by signal {signum}")

    signal.signal(signal.SIGTERM, terminate)
    signal.signal(signal.SIGINT, terminate)
    signal.signal(signal.SIGHUP, terminate)
    try:
        instance.mkdir()  # Exclusive; never reuse somebody else's instance.
        created = True
        identity = instance.lstat().st_ino
        checked_write(instance / "tracing_on", 0)
        if (instance / "current_tracer").read_text().strip() != "nop":
            raise RuntimeError("New instance unexpectedly has an active tracer")
        if (
            "mono"
            not in (instance / "trace_clock")
            .read_text()
            .replace("[", "")
            .replace("]", "")
            .split()
        ):
            raise RuntimeError("Monotonic trace clock unavailable")
        checked_write(instance / "trace_clock", "mono")
        checked_write(instance / "buffer_size_kb", 8192)
        meta["filter_readback"] = {}
        meta["event_formats"] = {}
        for event, expression in filters.items():
            directory = instance / "events" / event
            if (directory / "enable").read_text().strip() != "0":
                raise RuntimeError("New event unexpectedly enabled")
            meta["event_formats"][event] = (directory / "format").read_text()
            checked_write(directory / "filter", expression)
            readback = (directory / "filter").read_text().strip()
            if (
                "parse_error" in readback
                or "^" in readback
                or not readback
                or readback == "none"
            ):
                raise RuntimeError(f"Invalid filter readback for {event}: {readback}")
            meta["filter_readback"][event] = readback
            checked_write(directory / "enable", 1)
            enabled.append(event)
        checked_write(instance / "tracing_on", 1)
        begin = time.monotonic_ns()
        checked_write(instance / "trace_marker", "BLINKA_PWM_KERNEL_BEGIN")
        end = time.monotonic_ns()
        meta["begin_marker_monotonic_bounds_ns"] = [begin, end]
        print(json.dumps({"ready": True, "instance": args.instance}), flush=True)
        deadline = time.monotonic() + 30
        request = b""
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                meta["stop_reason"] = "watchdog"
                break
            readable, _, _ = select.select([sys.stdin], [], [], remaining)
            if not readable:
                meta["stop_reason"] = "watchdog"
                break
            chunk = os.read(sys.stdin.fileno(), 64)
            request += chunk
            if not chunk or len(request) >= 64 or b"\n" in request:
                meta["stop_reason"] = (
                    "parent_stop" if request == b"STOP\n" else "parent_eof_or_invalid"
                )
                break
        begin = time.monotonic_ns()
        checked_write(instance / "trace_marker", "BLINKA_PWM_KERNEL_END")
        end = time.monotonic_ns()
        meta["end_marker_monotonic_bounds_ns"] = [begin, end]
    except BaseException as exc:
        error = repr(exc)
    finally:
        # Only a successfully created instance can enter cleanup. Export errors
        # leave its buffer disabled for recovery, never discard unsaved data.
        safe_to_export = False
        try:
            if created:
                current = instance.lstat()
                if not stat.S_ISDIR(current.st_mode) or (
                    identity is not None and current.st_ino != identity
                ):
                    raise RuntimeError("Trace instance identity changed")
                checked_write(instance / "tracing_on", 0)
                safe_to_export = True
                for event in enabled:
                    checked_write(instance / "events" / event / "enable", 0)
        except BaseException as exc:
            error = (error + "; " if error else "") + "disable: " + repr(exc)
        if safe_to_export:
            try:
                meta["per_cpu_stats"] = {
                    cpu.name: (cpu / "stats").read_text()
                    for cpu in sorted((instance / "per_cpu").iterdir())
                }
            except BaseException as exc:
                error = (error + "; " if error else "") + "stats: " + repr(exc)
            try:
                exclusive_output(
                    output_fd,
                    "kernel-trace.txt",
                    (instance / "trace").read_text(),
                    uid,
                    gid,
                )
                instance.rmdir()  # tracefs destroys its virtual children itself.
                meta["instance_removed"] = not instance.exists()
            except BaseException as exc:
                error = (error + "; " if error else "") + "export/removal: " + repr(exc)
        try:
            meta["top_after"] = top_state()
            meta["top_state_unchanged"] = meta["top_after"] == before
        except BaseException as exc:
            meta["top_state_unchanged"] = False
            error = (error + "; " if error else "") + "global readback: " + repr(exc)
        meta["error"] = error
        try:
            exclusive_output(
                output_fd,
                "kernel-meta.json",
                json.dumps(meta, indent=2) + "\n",
                uid,
                gid,
            )
        finally:
            os.close(output_fd)
    print(
        json.dumps(
            {
                "ready": False,
                "finished": True,
                "error": error,
                "instance_removed": meta.get("instance_removed", False),
                "top_state_unchanged": meta["top_state_unchanged"],
            }
        ),
        flush=True,
    )
    if error or not meta.get("instance_removed") or not meta["top_state_unchanged"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
