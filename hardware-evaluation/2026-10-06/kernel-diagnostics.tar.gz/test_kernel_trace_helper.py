"""Private tracefs helper tests using only an in-memory filesystem and mocks."""

import importlib.util
import json
import os
import stat
import sys
import types
from pathlib import Path, PurePosixPath

import pytest

BENCH = "/tmp/blinka-pwm-oct6.abc123"
OUTPUT = BENCH + "/capture-kernel"
INSTANCE_NAME = "blinka-pwm-oct6-abcdef012345"
TRACEFS = "/fake-tracefs"
INSTANCE = TRACEFS + "/instances/" + INSTANCE_NAME
EVENTS = (
    "sched/sched_waking",
    "sched/sched_wakeup",
    "sched/sched_migrate_task",
    "sched/sched_switch",
    "timer/hrtimer_init",
    "timer/hrtimer_start",
    "timer/hrtimer_cancel",
    "timer/hrtimer_expire_entry",
)


@pytest.mark.parametrize(
    "scenario",
    [
        "stop",
        "eof",
        "partial_watchdog",
        "export_failure",
        "stats_failure",
        "identity_changed",
        "existing_instance",
        "bad_filter",
    ],
)
def test_private_helper_lifecycle(monkeypatch, capsys, scenario):
    spec = importlib.util.spec_from_file_location(
        "kernel_trace_helper_under_test",
        Path(__file__).with_name("kernel_trace_helper.py"),
    )
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    files = {
        TRACEFS + "/tracing_on": "0\n",
        TRACEFS + "/current_tracer": "nop\n",
        TRACEFS + "/trace_clock": "[local] mono\n",
        TRACEFS + "/buffer_size_kb": "7\n",
    }
    original_globals = dict(files)
    directories = {TRACEFS, TRACEFS + "/instances", BENCH, OUTPUT}
    writes, exports, removed, closed, installed_handlers = [], {}, [], [], []
    calls = {"identity": 0, "select": 0, "clock": 0}
    # An unrelated existing instance is never modified or removed.
    other = TRACEFS + "/instances/unrelated"
    directories.add(other)
    files[other + "/trace"] = "unrelated data"
    if scenario == "existing_instance":
        directories.add(INSTANCE)
        files[INSTANCE + "/trace"] = "pre-existing data"

    class FakePath:
        def __init__(self, value):
            self.value = str(value)

        def __str__(self):
            return self.value

        def __truediv__(self, value):
            return FakePath(self.value + "/" + str(value))

        def __lt__(self, other):
            return self.value < other.value

        @property
        def name(self):
            return PurePosixPath(self.value).name

        @property
        def parent(self):
            return FakePath(str(PurePosixPath(self.value).parent))

        def resolve(self, *, strict):
            assert strict and self.value == OUTPUT
            return self

        def stat(self):
            assert self.value.startswith("/proc/100")
            return types.SimpleNamespace(st_uid=1000)

        def read_bytes(self):
            assert self.value == "/proc/100/cmdline"
            return (BENCH + "/venv/bin/python\0-c\0").encode()

        def lstat(self):
            assert self.value == INSTANCE and INSTANCE in directories
            calls["identity"] += 1
            inode = 42 + (scenario == "identity_changed" and calls["identity"] > 1)
            return types.SimpleNamespace(st_mode=stat.S_IFDIR | 0o700, st_ino=inode)

        def mkdir(self):
            assert self.value == INSTANCE
            if self.value in directories:
                raise FileExistsError("existing private instance")
            assert len(installed_handlers) == 3  # Handlers precede creation.
            directories.add(self.value)
            files.update(
                {
                    INSTANCE + "/tracing_on": "0\n",
                    INSTANCE + "/current_tracer": "nop\n",
                    INSTANCE + "/trace_clock": "[local] mono\n",
                    INSTANCE + "/buffer_size_kb": "7\n",
                    INSTANCE + "/trace": "captured fake kernel trace\n",
                }
            )
            for event in EVENTS:
                prefix = INSTANCE + "/events/" + event
                files[prefix + "/enable"] = "0\n"
                files[prefix + "/filter"] = "none\n"
                files[prefix + "/format"] = "fake event format\n"
            for cpu in ("cpu0", "cpu1"):
                files[INSTANCE + "/per_cpu/" + cpu + "/stats"] = "overrun: 0\n"

        def read_text(self):
            if scenario == "stats_failure" and self.value.endswith("cpu0/stats"):
                raise OSError("injected stats failure")
            if scenario == "bad_filter" and self.value.endswith("sched_waking/filter"):
                return "parse_error ^\n"
            return files[self.value]

        def iterdir(self):
            assert self.value == INSTANCE + "/per_cpu"
            return [self / cpu for cpu in ("cpu0", "cpu1")]

        def rmdir(self):
            assert self.value == INSTANCE
            assert "kernel-trace.txt" in exports  # Preserve unsaved buffers.
            assert files[INSTANCE + "/tracing_on"].strip() == "0"
            removed.append(self.value)
            directories.remove(self.value)

        def exists(self):
            return self.value in directories

    def open_directory(path, flags, *, dir_fd=None):
        assert flags & os.O_DIRECTORY and flags & os.O_NOFOLLOW and flags & os.O_CLOEXEC
        if dir_fd is None:
            assert str(path) == BENCH
            return 10
        assert dir_fd == 10 and str(path) == "capture-kernel"
        return 11

    def checked_write(path, value):
        assert path.value.startswith(INSTANCE + "/")
        assert scenario != "existing_instance"
        if scenario == "identity_changed" and calls["identity"] > 1:
            pytest.fail("must not modify an instance with mismatched identity")
        writes.append((path.value, str(value)))
        files[path.value] = str(value) + "\n"

    def exclusive_output(fd, name, data, uid, gid):
        assert (fd, uid, gid) == (11, 1000, 1000)
        assert name not in exports
        if scenario == "export_failure" and name == "kernel-trace.txt":
            raise OSError("injected export failure")
        exports[name] = data

    chunks = [b"ST", b"OP\n"] if scenario == "stop" else [b""]
    if scenario == "partial_watchdog":
        chunks = [b"ST"]

    def read(fd, length):
        assert (fd, length) == (99, 64)
        return chunks.pop(0)

    def select(readers, writers, errors, timeout):
        assert not writers and not errors and 0 < timeout <= 30
        calls["select"] += 1
        return (readers if chunks else []), [], []

    def clock():
        calls["clock"] += 1
        return calls["clock"] / 1000

    monkeypatch.setattr(helper, "Path", FakePath)
    monkeypatch.setattr(helper, "TRACEFS", FakePath(TRACEFS))
    monkeypatch.setattr(helper, "checked_write", checked_write)
    monkeypatch.setattr(helper, "exclusive_output", exclusive_output)
    monkeypatch.setattr(
        helper,
        "os",
        types.SimpleNamespace(
            geteuid=lambda: 0,
            environ={"SUDO_UID": "1000", "SUDO_GID": "1000"},
            O_RDONLY=os.O_RDONLY,
            O_DIRECTORY=os.O_DIRECTORY,
            O_NOFOLLOW=os.O_NOFOLLOW,
            O_CLOEXEC=os.O_CLOEXEC,
            open=open_directory,
            close=closed.append,
            fstat=lambda fd: types.SimpleNamespace(st_uid=1000),
            listdir=lambda fd: [],
            read=read,
        ),
    )
    monkeypatch.setattr(
        helper,
        "signal",
        types.SimpleNamespace(
            SIGTERM=15,
            SIGINT=2,
            SIGHUP=1,
            signal=lambda signum, handler: installed_handlers.append(signum),
        ),
    )
    monkeypatch.setattr(helper, "select", types.SimpleNamespace(select=select))
    monkeypatch.setattr(
        helper,
        "time",
        types.SimpleNamespace(
            monotonic=clock,
            monotonic_ns=lambda: int(clock() * 1e9),
        ),
    )
    fake_stdin = types.SimpleNamespace(fileno=lambda: 99)
    monkeypatch.setattr(sys, "stdin", fake_stdin)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "kernel_trace_helper.py",
            "--instance",
            INSTANCE_NAME,
            "--parent-pid",
            "100",
            "--worker-tids",
            "101,102",
            "--output-dir",
            OUTPUT,
        ],
    )
    failures = {
        "export_failure",
        "stats_failure",
        "identity_changed",
        "existing_instance",
        "bad_filter",
    }
    if scenario in failures:
        with pytest.raises(SystemExit) as raised:
            helper.main()
        assert raised.value.code == 1
    else:
        helper.main()
    meta = json.loads(exports["kernel-meta.json"])
    assert meta["top_state_unchanged"]
    assert all(files[path] == value for path, value in original_globals.items())
    assert other in directories and files[other + "/trace"] == "unrelated data"
    assert closed == [10, 11]
    assert meta["error"] is not None if scenario in failures else meta["error"] is None
    if scenario in ("identity_changed", "existing_instance", "export_failure"):
        assert not removed and INSTANCE in directories
        assert not meta.get("instance_removed", False)
    else:
        assert removed == [INSTANCE] and meta["instance_removed"]
    if scenario == "export_failure":
        assert files[INSTANCE + "/tracing_on"].strip() == "0"
        assert all(
            files[INSTANCE + "/events/" + event + "/enable"].strip() == "0"
            for event in EVENTS
        )
    if scenario == "existing_instance":
        assert not writes and files[INSTANCE + "/trace"] == "pre-existing data"
    if scenario == "stop":
        assert meta["stop_reason"] == "parent_stop" and calls["select"] == 2
    if scenario == "eof":
        assert meta["stop_reason"] == "parent_eof_or_invalid"
    if scenario == "partial_watchdog":
        assert meta["stop_reason"] == "watchdog" and calls["select"] == 2
    messages = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert messages[-1]["finished"] is True
    assert messages[-1]["top_state_unchanged"] is True
