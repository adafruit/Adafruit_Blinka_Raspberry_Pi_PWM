"""Correlate bounded native trace records with captured digital edge ordinals."""

import argparse
from bisect import bisect_left, bisect_right
import csv
import json
import statistics
from pathlib import Path

from capture_pwm import read_digital


def microseconds(value):
    return value / 1000


def analyze(directory):
    metadata = json.loads((directory / "results.json").read_text())
    with (directory / "trace.csv").open(newline="") as stream:
        rows = [{k: v if k == "kind" else int(v) for k, v in r.items()}
                for r in csv.DictReader(stream)]
    assert len(rows) == metadata["trace"]["written"]
    writes = sorted((r for r in rows if r["kind"] == "I"), key=lambda r: r["begin_ns"])
    assert all(r["result"] == 0 for r in writes), "GPIO ioctl failure in trace"
    # Runner keeps two outputs live; their initial main-thread writes occur in
    # specified constructor order before active duties. Fds are never recycled.
    fds = list(dict.fromkeys(r["fd"] for r in writes))
    assert len(fds) == len(metadata["outputs"]) == 2
    # Trace errno values come from the Linux bench, not the macOS analyzer host.
    timeouts = [r for r in rows if r["kind"] == "W" and r["result"] == 110]
    timeout_groups = {}
    for tid in {w["tid"] for w in timeouts}:
        group = sorted((w for w in timeouts if w["tid"] == tid), key=lambda w: w["begin_ns"])
        timeout_groups[tid] = ([w["begin_ns"] for w in group],
                               [w["end_ns"] for w in group], group)
    result = {"capture": directory.name, "instrumented_only": True,
              "shared": metadata["remote"]["optin_shared"],
              "trace_records": len(rows), "outputs": []}
    result["ioctl_wall_us"] = {"median": microseconds(statistics.median(
        r["end_ns"] - r["begin_ns"] for r in writes)),
        "max": microseconds(max(r["end_ns"] - r["begin_ns"] for r in writes))}
    worst = max(timeouts, key=lambda r: r["end_ns"] - r["deadline_ns"])
    result["worst_timeout"] = {"tid": worst["tid"],
        "lateness_us": microseconds(worst["end_ns"] - worst["deadline_ns"]),
        "wall_us": microseconds(worst["end_ns"] - worst["begin_ns"]),
        "cpu_us": microseconds(worst["cpu_ns"])}
    for fd, spec in zip(fds, metadata["outputs"]):
        events = []
        state = 0
        previous = None
        for r in (w for w in writes if w["fd"] == fd):
            if previous is not None:
                assert previous["end_ns"] <= r["begin_ns"], "Overlapping writes to one fd"
            previous = r
            if r["level"] != state:
                events.append(r)
                state = r["level"]
        _, chunks = read_digital(directory / f"digital_{spec['saleae_channel']}.bin")
        assert len(chunks) == 1, "Ordinal correlation requires a continuous capture"
        initial, _, _, _, edges = chunks[0]
        assert initial == state == 0
        assert len(edges) == len(events), "External/trace edge counts disagree"
        assert all(r["level"] == (1 if i % 2 == 0 else 0)
                   for i, r in enumerate(events))
        highs = []
        lower, upper = edges[0] + .05, edges[-2] - .05
        for i in range(0, len(edges) - 2, 2):
            if edges[i] < lower or edges[i + 2] > upper:
                continue
            rise, fall = events[i:i + 2]
            assert rise["tid"] == fall["tid"]
            beginnings, endings, group = timeout_groups[rise["tid"]]
            waits = [w for w in group[bisect_left(beginnings, rise["end_ns"]):
                                     bisect_right(beginnings, fall["begin_ns"])]
                     if w["end_ns"] <= fall["begin_ns"]]
            late = max(waits, key=lambda w: w["end_ns"] - w["deadline_ns"], default=None)
            before_index = bisect_right(endings, rise["begin_ns"]) - 1
            before_rise = group[before_index] if before_index >= 0 else None
            highs.append({"rise_seconds_analyzer": edges[i],
                "high_us_analyzer": (edges[i + 1] - edges[i]) * 1e6,
                "high_us_between_ioctl_starts": microseconds(fall["begin_ns"] - rise["begin_ns"]),
                "rise_ioctl_wall_us": microseconds(rise["end_ns"] - rise["begin_ns"]),
                "fall_ioctl_wall_us": microseconds(fall["end_ns"] - fall["begin_ns"]),
                "worker_tid": rise["tid"],
                "previous_timeout_before_rise": None if before_rise is None else {
                    "lateness_us": microseconds(before_rise["end_ns"] - before_rise["deadline_ns"]),
                    "wall_us": microseconds(before_rise["end_ns"] - before_rise["begin_ns"]),
                    "cpu_us": microseconds(before_rise["cpu_ns"]),
                    "after_wait_to_rise_ioctl_us": microseconds(rise["begin_ns"] - before_rise["end_ns"])},
                "largest_timeout_in_high": None if late is None else {
                    "lateness_us": microseconds(late["end_ns"] - late["deadline_ns"]),
                    "wall_us": microseconds(late["end_ns"] - late["begin_ns"]),
                    "cpu_us": microseconds(late["cpu_ns"]),
                    "after_wait_to_fall_ioctl_us": microseconds(fall["begin_ns"] - late["end_ns"])}})
        result["outputs"].append({"gpio": spec["gpio"], "fd": fd,
            "edge_count": len(edges), "matching_trace_transitions": len(events),
            "target_high_us": spec["timing"]["target_high_us"],
            "high_min_us": min(h["high_us_analyzer"] for h in highs),
            "high_max_us": max(h["high_us_analyzer"] for h in highs),
            "five_longest_highs": sorted(highs, key=lambda h: h["high_us_analyzer"], reverse=True)[:5],
            "five_shortest_highs": sorted(highs, key=lambda h: h["high_us_analyzer"])[:5]})
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output-name", default="trace-analysis.json")
    args = parser.parse_args()
    data = analyze(args.directory)
    if Path(args.output_name).name != args.output_name:
        raise ValueError("Output must be a filename in the capture directory")
    target = args.directory / args.output_name
    with target.open("x") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
    print(json.dumps(data, indent=2))
