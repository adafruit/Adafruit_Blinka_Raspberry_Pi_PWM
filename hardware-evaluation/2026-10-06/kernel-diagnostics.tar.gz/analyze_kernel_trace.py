#!/usr/bin/env python3
"""Offline, conservative attribution of native PWM intervals to tracefs events.

Usage: python analyze_kernel_trace.py CAPTURE [--top 5] [--output NAME.json]
       python analyze_kernel_trace.py --self-test

The native recorder uses CLOCK_MONOTONIC; kernel-meta.json must confirm the
tracefs ``mono`` clock. Saleae's clock is deliberately not aligned here. Only
exact native wait / adjacent wait-to-write intervals are reported, not padded
windows. Scheduler state may be seeded by preceding events. On-CPU time is not
application CPU time: it includes kernel execution and interrupt interference.

Linux 6.12 primary definitions checked for this parser:
https://github.com/torvalds/linux/blob/v6.12/include/trace/events/sched.h
https://github.com/torvalds/linux/blob/v6.12/include/trace/events/timer.h
"""

import argparse
import csv
import json
import re
import sys
from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from itertools import groupby
from pathlib import Path

EVENT_NAMES = {
    "sched_waking",
    "sched_wakeup",
    "sched_switch",
    "sched_migrate_task",
    "hrtimer_init",
    "hrtimer_start",
    "hrtimer_cancel",
    "hrtimer_expire_entry",
}
LINE_RE = re.compile(
    r"^\s*(?P<comm>.+)-(?P<tid>\d+)\s+\[(?P<cpu>\d+)\]\s+"
    r"(?P<flags>.*?)\s+(?P<stamp>\d+\.\d+):\s+"
    r"(?:(?:sched|timer):)?(?P<name>\w+):\s*(?P<body>.*)$"
)
FIELD_RE = re.compile(r"\b([a-zA-Z_]\w*)=([^\s]+)")
LOSS_KEYS = {"overrun", "commit overrun", "dropped events", "lost events"}
MARKER_LABELS = {"BLINKA_PWM_KERNEL_BEGIN", "BLINKA_PWM_KERNEL_END"}


def stamp_ns(value):
    whole, fraction = value.split(".")
    if len(fraction) > 9:
        raise ValueError("Trace timestamp has finer than nanosecond precision")
    return int(whole) * 1_000_000_000 + int(fraction.ljust(9, "0"))


def pointer(value):
    """Keep hashed %p tokens as identities; never interpret them as addresses."""
    if not value or not re.fullmatch(r"(?:0x)?[0-9a-fA-F]+", value):
        return None
    normalized = value.lower().removeprefix("0x").lstrip("0")
    return normalized or None


@dataclass
class Event:
    ns: int
    name: str
    tid: int
    cpu: int
    fields: dict
    line: int
    resolution_ns: int

    def integer(self, key, default=None):
        try:
            return int(self.fields[key], 10)
        except (KeyError, ValueError):
            return default

    def brief(self):
        return {
            "timestamp_ns": self.ns,
            "event": self.name,
            "cpu": self.cpu,
            "context_tid": self.tid,
            "fields": self.fields,
            "line": self.line,
        }


def parse_kernel(lines):
    events, issues = [], []
    losses = []
    for line_number, line in enumerate(lines, 1):
        if re.search(r"\bLOST\s+\d+\s+EVENTS\b", line, re.I):
            losses.append({"line": line_number, "text": line.strip()})
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = LINE_RE.match(line)
        if not match:
            if any(name + ":" in line for name in EVENT_NAMES):
                issues.append(f"Unparsed relevant kernel event at line {line_number}")
            continue
        values = match.groupdict()
        marker = (
            values["name"] in {"tracing_mark_write", "print"}
            and values["body"].strip() in MARKER_LABELS
        )
        if values["name"] not in EVENT_NAMES and not marker:
            continue
        fields = (
            {"label": values["body"].strip()}
            if marker
            else dict(FIELD_RE.findall(values["body"]))
        )
        fraction = values["stamp"].split(".")[1]
        event = Event(
            stamp_ns(values["stamp"]),
            values["name"],
            int(values["tid"]),
            int(values["cpu"]),
            fields,
            line_number,
            10 ** max(0, 9 - len(fraction)),
        )
        required = (
            ()
            if marker
            else {
                "sched_waking": ("pid",),
                "sched_wakeup": ("pid",),
                "sched_migrate_task": ("pid", "orig_cpu", "dest_cpu"),
                "sched_switch": ("prev_pid", "next_pid", "prev_state"),
                "hrtimer_init": ("hrtimer", "clockid"),
                "hrtimer_start": ("hrtimer", "expires", "softexpires"),
                "hrtimer_cancel": ("hrtimer",),
                "hrtimer_expire_entry": ("hrtimer", "function", "now"),
            }[event.name]
        )
        if any(key not in fields for key in required):
            issues.append(f"Missing fields in {event.name} at line {line_number}")
            continue
        events.append(event)
    events.sort(key=lambda event: (event.ns, event.line))
    return events, issues, losses


def validate_markers(events, metadata):
    issues, details, stamps = [], {}, []
    for kind in ("begin", "end"):
        label = f"BLINKA_PWM_KERNEL_{kind.upper()}"
        matches = [event for event in events if event.fields.get("label") == label]
        bounds = metadata.get(f"{kind}_marker_monotonic_bounds_ns")
        if len(matches) != 1 or not isinstance(bounds, list) or len(bounds) != 2:
            issues.append(f"No unique {kind} clock marker with monotonic bounds")
            continue
        marker = matches[0]
        lower, upper = bounds
        if not (
            isinstance(lower, int)
            and isinstance(upper, int)
            and lower <= upper
            and lower - marker.resolution_ns
            <= marker.ns
            <= upper + marker.resolution_ns
        ):
            issues.append(
                f"{kind.capitalize()} marker does not match its monotonic bounds"
            )
        details[kind] = {
            "timestamp_ns": marker.ns,
            "monotonic_bounds_ns": bounds,
            "line": marker.line,
            "text_resolution_ns": marker.resolution_ns,
        }
        stamps.append(marker.ns)
    if len(stamps) == 2 and stamps[0] >= stamps[1]:
        issues.append("Clock markers are not in start/end order")
    coverage = stamps if len(stamps) == 2 and stamps[0] < stamps[1] else None
    return issues, details, coverage


def metadata_losses(stats):
    """Accept tracefs per_cpu/*/stats as raw strings or parsed dictionaries."""
    found, examined = [], 0

    def visit(value, path):
        nonlocal examined
        if isinstance(value, str):
            for line in value.splitlines():
                if ":" not in line:
                    continue
                key, count = line.split(":", 1)
                normalized = key.strip().lower().replace("_", " ")
                if normalized in LOSS_KEYS:
                    examined += 1
                    try:
                        amount = int(count.strip())
                    except ValueError:
                        found.append(
                            {
                                "path": path,
                                "key": key,
                                "value": count,
                                "error": "invalid loss counter",
                            }
                        )
                    else:
                        if amount:
                            found.append({"path": path, "key": key, "value": amount})
        elif isinstance(value, dict):
            for key, child in value.items():
                normalized = str(key).strip().lower().replace("_", " ")
                if normalized in LOSS_KEYS:
                    examined += 1
                    try:
                        amount = int(child)
                    except (ValueError, TypeError):
                        found.append(
                            {
                                "path": path,
                                "key": key,
                                "value": child,
                                "error": "invalid loss counter",
                            }
                        )
                    else:
                        if amount:
                            found.append({"path": path, "key": key, "value": amount})
                else:
                    visit(child, f"{path}/{key}")
        elif isinstance(value, list):
            for index, child in enumerate(value):
                visit(child, f"{path}/{index}")

    visit(stats, "per_cpu_stats")
    return found, examined


@dataclass
class Timer:
    start: Event
    token: str
    clockid: str | None
    expires: int
    softexpires: int
    callback: Event | None = None
    closed: Event | None = None
    close_reason: str | None = None
    issues: list = field(default_factory=list)


def own_timers(events, tids):
    live, initialized, timers = {}, {}, []
    counts = Counter()
    lifecycle_times = defaultdict(list)
    for event in events:
        if not event.name.startswith("hrtimer_"):
            continue
        token = pointer(event.fields.get("hrtimer"))
        if token is None:
            counts["unusable_pointer_events"] += 1
            continue
        lifecycle_times[token].append(event)
        if event.name == "hrtimer_init" and event.tid in tids:
            initialized[token] = (event.tid, event.fields["clockid"])
            previous = live.pop(token, None)
            if previous:
                previous.closed, previous.close_reason = event, "reinitialized"
                previous.issues.append(
                    "Timer reinitialized before a recorded expiry/cancel"
                )
        elif event.name == "hrtimer_start" and event.tid in tids:
            expires, soft = event.integer("expires"), event.integer("softexpires")
            if expires is None or soft is None:
                counts["invalid_start_events"] += 1
                continue
            previous = live.pop(token, None)
            if previous:
                previous.closed, previous.close_reason = event, "rearmed"
            init = initialized.get(token)
            timer = Timer(
                event,
                token,
                init[1] if init and init[0] == event.tid else None,
                expires,
                soft,
            )
            if expires < soft:
                timer.issues.append("Latest expiry precedes earliest expiry")
            timers.append(timer)
            live[token] = timer
        elif event.name == "hrtimer_cancel" and event.tid in tids:
            timer = live.get(token)
            if timer and timer.start.tid == event.tid:
                live.pop(token)
                timer.closed, timer.close_reason = event, "cancelled"
        elif event.name == "hrtimer_expire_entry":
            timer = live.pop(token, None)
            if timer is None:
                counts["unmatched_expiry_events"] += 1
                continue
            if not event.fields["function"].startswith("hrtimer_wakeup"):
                timer.issues.append("Expiry callback is not hrtimer_wakeup")
                timer.closed, timer.close_reason = event, "different_callback"
                continue
            timer.callback, timer.closed, timer.close_reason = event, event, "expired"
            counts["matched_own_expiries"] += 1
    counts["own_starts"] = len(timers)
    counts["open_own_timers_at_trace_end"] = len(live)
    cross_cpu_ties = {}
    for token, group in lifecycle_times.items():
        grouped = defaultdict(list)
        for event in group:
            grouped[event.ns].append(event)
        cross_cpu_ties[token] = sorted(
            ns
            for ns, same_time in grouped.items()
            if len({event.cpu for event in same_time}) > 1
        )
    for timer in timers:
        ties = cross_cpu_ties[timer.token]
        end = timer.closed.ns if timer.closed else events[-1].ns
        if bisect_left(ties, timer.start.ns) < bisect_right(ties, end):
            timer.issues.append(
                "Cross-CPU timer lifecycle events have equal printed timestamps; generation order is ambiguous"
            )
    return timers, dict(counts)


class Scheduler:
    def __init__(self, events, tids):
        self.events = defaultdict(list)
        self.changes = defaultdict(list)
        self.ambiguous_times = defaultdict(list)
        for event in events:
            if not event.name.startswith("sched_"):
                continue
            targets = (
                {event.integer("prev_pid"), event.integer("next_pid")}
                if event.name == "sched_switch"
                else {event.integer("pid")}
            )
            for tid in targets & tids:
                self.events[tid].append(event)
        for tid, group in self.events.items():
            state = "unknown"
            for ns, same_time in groupby(group, key=lambda event: event.ns):
                block = list(same_time)
                new_state, actions = state, []
                for event in block:
                    action = None
                    if event.name == "sched_switch":
                        if event.integer("next_pid") == tid:
                            action = "on_cpu"
                        elif event.integer("prev_pid") == tid:
                            outgoing = event.fields["prev_state"]
                            action = (
                                "runnable_off_cpu"
                                if outgoing in {"R", "R+", "0"}
                                else "blocked_off_cpu"
                            )
                    elif event.name == "sched_wakeup" and new_state != "on_cpu":
                        action = "runnable_off_cpu"
                    if action:
                        new_state = action
                        actions.append((action, event.cpu))
                if (
                    len({action for action, _ in actions}) > 1
                    and len({cpu for _, cpu in actions}) > 1
                ):
                    new_state = "unknown"
                    self.ambiguous_times[tid].append(ns)
                if new_state != state:
                    self.changes[tid].append((ns, block[-1].line, new_state, block[-1]))
                    state = new_state
        self.times = {
            tid: [event.ns for event in group] for tid, group in self.events.items()
        }
        self.change_times = {
            tid: [change[0] for change in group] for tid, group in self.changes.items()
        }

    def between(self, tid, start, end):
        times, group = self.times.get(tid, []), self.events.get(tid, [])
        return group[bisect_left(times, start) : bisect_right(times, end)]

    def timeline(self, tid, start, end):
        changes = self.changes.get(tid, [])
        times = self.change_times.get(tid, [])
        index = bisect_right(times, start) - 1
        state = changes[index][2] if index >= 0 else "unknown"
        segments, position = [], start
        for ns, _, next_state, _ in changes[
            bisect_right(times, start) : bisect_right(times, end)
        ]:
            if ns > position:
                segments.append(
                    {
                        "start_ns": position,
                        "end_ns": ns,
                        "duration_ns": ns - position,
                        "state": state,
                    }
                )
            position, state = ns, next_state
        if end > position:
            segments.append(
                {
                    "start_ns": position,
                    "end_ns": end,
                    "duration_ns": end - position,
                    "state": state,
                }
            )
        totals = {
            name + "_ns": sum(
                segment["duration_ns"]
                for segment in segments
                if segment["state"] == name
            )
            for name in ("on_cpu", "runnable_off_cpu", "blocked_off_cpu", "unknown")
        }
        return {
            "start_ns": start,
            "end_ns": end,
            "duration_ns": end - start,
            "totals": totals,
            "segments": segments,
            "state_order_ambiguities_ns": [
                ns for ns in self.ambiguous_times.get(tid, []) if start <= ns <= end
            ],
            "events": [event.brief() for event in self.between(tid, start, end)],
        }


def analyze_wait(
    row, timers, scheduler, global_issues, resolution, alignment_verified=True
):
    start, end, deadline, tid = (
        row[key] for key in ("begin_ns", "end_ns", "deadline_ns", "tid")
    )
    issues = list(global_issues)
    candidates = [
        timer
        for timer in timers
        if timer.start.tid == tid
        and start <= timer.start.ns <= end
        and timer.softexpires == deadline
    ]
    output = {
        "native": row,
        "lateness_ns": end - deadline,
        "wait_wall_ns": end - start,
        "native_thread_cpu_ns": row["cpu_ns"],
        "scheduler": None,
        "late_tail_scheduler": None,
        "matching_start_count": len(candidates),
        "timer": None,
        "observations": [],
    }
    if not alignment_verified:
        output.update(
            attribution_status="suppressed_unverified_clock_alignment",
            issues=list(dict.fromkeys(issues)),
            cause_claim=None,
        )
        return output
    output["scheduler"] = scheduler.timeline(tid, start, end)
    output["late_tail_scheduler"] = scheduler.timeline(
        tid, max(start, min(deadline, end)), end
    )
    # More than one generation is not resolved by picking a convenient callback.
    if len(candidates) != 1:
        issues.append("No unique own timer start matching this wait's exact deadline")
    else:
        timer = candidates[0]
        issues.extend(timer.issues)
        if timer.clockid not in {"CLOCK_MONOTONIC", "1"}:
            issues.append("Matched timer's clock is missing or not CLOCK_MONOTONIC")
        callback = timer.callback
        details = {
            "pointer_token": timer.token,
            "clockid": timer.clockid,
            "start": timer.start.brief(),
            "softexpires_ns": timer.softexpires,
            "expires_ns": timer.expires,
            "permitted_slack_ns": timer.expires - timer.softexpires,
            "close_reason": timer.close_reason,
            "callback": None,
            "intervals_ns": {},
        }
        output["timer"] = details
        if callback is None or not start <= callback.ns <= end:
            issues.append("No matching live own timer callback inside the native wait")
        else:
            details["callback"] = callback.brief()
            interval = details["intervals_ns"]
            interval["deadline_to_callback"] = callback.ns - deadline
            interval["softexpires_to_callback"] = callback.ns - timer.softexpires
            interval["expires_to_callback"] = callback.ns - timer.expires
            following = [
                event
                for event in scheduler.between(tid, callback.ns, end)
                if (event.ns, event.line) >= (callback.ns, callback.line)
            ]
            waking = next(
                (event for event in following if event.name == "sched_waking"), None
            )
            wake = next(
                (
                    event
                    for event in following
                    if event.name == "sched_wakeup"
                    and (
                        waking is None
                        or (event.ns, event.line) >= (waking.ns, waking.line)
                    )
                ),
                None,
            )
            switch = next(
                (
                    event
                    for event in following
                    if event.name == "sched_switch"
                    and event.integer("next_pid") == tid
                    and (wake is None or (event.ns, event.line) >= (wake.ns, wake.line))
                ),
                None,
            )
            details["following_waking"] = waking.brief() if waking else None
            details["following_wakeup"] = wake.brief() if wake else None
            details["following_switch_in"] = switch.brief() if switch else None
            if waking:
                interval["callback_to_waking"] = waking.ns - callback.ns
            if wake:
                interval["callback_to_wakeup"] = wake.ns - callback.ns
            if waking and wake:
                interval["waking_to_wakeup"] = wake.ns - waking.ns
            if wake and switch:
                interval["wakeup_to_switch_in"] = switch.ns - wake.ns
            if switch:
                interval["callback_to_switch_in"] = switch.ns - callback.ns
                interval["switch_in_to_wait_end"] = end - switch.ns
            if not (waking and wake and switch):
                issues.append(
                    "Callback lacks a complete waking/wakeup/switch-in chain; already-running races are possible"
                )
            chain = [event for event in (callback, waking, wake, switch) if event]
            if any(
                previous.ns == current.ns and previous.cpu != current.cpu
                for previous, current in zip(chain, chain[1:])
            ):
                issues.append(
                    "Cross-CPU chain steps have equal printed timestamps; their order is ambiguous"
                )
            if callback.ns - timer.expires > resolution:
                output["observations"].append(
                    "Matched callback observed after latest permitted timer expiry"
                )
            if wake and switch and switch.ns - wake.ns > resolution:
                output["observations"].append(
                    "Target observed runnable before its next switch-in"
                )
            if switch:
                after = scheduler.timeline(tid, switch.ns, end)["totals"]
                if after["runnable_off_cpu_ns"] > resolution:
                    output["observations"].append(
                        "Additional runnable off-CPU time after first resumption"
                    )
                if after["blocked_off_cpu_ns"] > resolution:
                    output["observations"].append(
                        "Worker became non-runnable again after first resumption; reason not established"
                    )
    if output["scheduler"]["totals"]["unknown_ns"]:
        issues.append("Scheduler state is unknown during part of this interval")
    if output["scheduler"]["state_order_ambiguities_ns"]:
        issues.append("Cross-CPU scheduler state changes have equal printed timestamps")
    output["attribution_status"] = (
        "incomplete_or_ambiguous" if issues else "complete_observed_chain"
    )
    output["issues"] = list(dict.fromkeys(issues))
    output["cause_claim"] = None
    return output


def analyze_gap(
    wait, write, scheduler, global_issues, resolution, gpio, alignment_verified=True
):
    start, end, tid = wait["end_ns"], write["begin_ns"], wait["tid"]
    timeline = scheduler.timeline(tid, start, end)
    issues = list(global_issues)
    if not alignment_verified:
        return {
            "worker_tid": tid,
            "gpio": gpio,
            "wait": wait,
            "write": write,
            "gap_ns": end - start,
            "scheduler": None,
            "observations": [],
            "issues": list(dict.fromkeys(issues)),
            "attribution_status": "suppressed_unverified_clock_alignment",
            "cause_claim": None,
        }
    if timeline["totals"]["unknown_ns"]:
        issues.append("Scheduler state is unknown during part of this interval")
    if timeline["state_order_ambiguities_ns"]:
        issues.append("Cross-CPU scheduler state changes have equal printed timestamps")
    observations = []
    if timeline["totals"]["runnable_off_cpu_ns"] > resolution:
        observations.append(
            "Runnable off-CPU interval between measured wait end and ioctl start"
        )
    if timeline["totals"]["blocked_off_cpu_ns"] > resolution:
        observations.append(
            "Non-runnable interval between measured wait end and ioctl start; blocking reason not established"
        )
    if not observations:
        observations.append(
            "No resolved off-CPU interval; on-CPU time does not establish application computation"
        )
    return {
        "worker_tid": tid,
        "gpio": gpio,
        "wait": wait,
        "write": write,
        "gap_ns": end - start,
        "scheduler": timeline,
        "observations": observations,
        "issues": list(dict.fromkeys(issues)),
        "attribution_status": "incomplete_or_ambiguous"
        if issues
        else "complete_observed_timeline",
        "cause_claim": None,
    }


def read_native(path):
    with path.open(newline="") as stream:
        rows = [
            {key: value if key == "kind" else int(value) for key, value in row.items()}
            for row in csv.DictReader(stream)
        ]
    required = {
        "seq",
        "kind",
        "tid",
        "fd",
        "level",
        "result",
        "begin_ns",
        "end_ns",
        "deadline_ns",
        "cpu_ns",
    }
    if any(
        set(row) != required
        or row["kind"] not in {"W", "I"}
        or row["end_ns"] < row["begin_ns"]
        for row in rows
    ):
        raise ValueError("Invalid native recorder rows")
    if len({row["seq"] for row in rows}) != len(rows):
        raise ValueError("Duplicate native recorder sequence numbers")
    return sorted(rows, key=lambda row: (row["begin_ns"], row["seq"]))


def analyze(directory, top=5):
    metadata = json.loads((directory / "kernel-meta.json").read_text())
    result_metadata = json.loads((directory / "results.json").read_text())
    rows = read_native(directory / "trace.csv")
    events, issues, text_losses = parse_kernel(
        (directory / "kernel-trace.txt").read_text().splitlines()
    )
    tids = {int(tid) for tid in metadata["worker_tids"]}
    if not tids or not events or not rows:
        raise ValueError("Capture lacks worker TIDs, kernel events, or native records")
    clock = metadata.get("trace_clock", metadata.get("clock"))
    if clock != "mono":
        issues.append(
            "Metadata does not confirm tracefs mono clock; cross-source attribution is unverified"
        )
    marker_issues, marker_details, marker_coverage = validate_markers(events, metadata)
    issues.extend(marker_issues)
    if metadata.get("error"):
        issues.append("Kernel capture helper reports an error")
    if metadata.get("instance_removed") is False:
        issues.append("Kernel capture helper did not remove its instance normally")
    if metadata.get("stop_reason") != "parent_stop":
        issues.append("Kernel capture did not report the normal parent stop")
    losses, checked = metadata_losses(metadata.get("per_cpu_stats", {}))
    if losses or text_losses:
        issues.append(
            "Kernel trace reports lost/overwritten events; attribution is incomplete"
        )
    if not checked:
        issues.append("No recognized kernel loss counters; completeness is unverified")
    trace_meta = result_metadata.get("trace", {})
    if trace_meta.get("written") != len(rows) or trace_meta.get("dropped") != 0:
        issues.append(
            "Native trace count or dropped-record metadata does not verify completeness"
        )
    if any(trace_meta.get(key, 0) for key in ("clock_error", "io_error", "init_error")):
        issues.append("Native recorder reports a clock, I/O, or initialization error")
    if any(row["kind"] == "I" and row["result"] for row in rows):
        issues.append("Native trace includes failed GPIO writes")
    native_tids = {row["tid"] for row in rows if row["kind"] == "W"}
    if native_tids != tids:
        issues.append("Kernel worker TIDs differ from native waiting TIDs")
    counts = Counter(event.name for event in events)
    for name in EVENT_NAMES - {"sched_migrate_task"}:
        if not counts[name]:
            issues.append(f"No parsed {name} event; event coverage is incomplete")
    resolution = max(event.resolution_ns for event in events)
    timers, timer_counts = own_timers(events, tids)
    if timer_counts.get("unusable_pointer_events") or timer_counts.get(
        "invalid_start_events"
    ):
        issues.append(
            "Unusable timer pointer/start records prevent complete lifecycle attribution"
        )
    scheduler = Scheduler(events, tids)
    alignment_verified = clock == "mono" and not marker_issues
    starts, ends = marker_coverage if marker_coverage else (events[0].ns, events[-1].ns)
    # Map GPIO only using the runner's documented fixed constructor order.
    fds = list(dict.fromkeys(row["fd"] for row in rows if row["kind"] == "I"))
    specifications = result_metadata.get("outputs", [])
    fd_gpio = (
        {fd: spec.get("gpio") for fd, spec in zip(fds, specifications)}
        if len(fds) == len(specifications)
        else {}
    )
    workers = []
    for tid in sorted(tids):
        group = [row for row in rows if row["tid"] == tid]
        timeouts = [row for row in group if row["kind"] == "W" and row["result"] == 110]
        waits = sorted(
            timeouts, key=lambda row: row["end_ns"] - row["deadline_ns"], reverse=True
        )[:top]
        pairs = [
            (previous, current)
            for previous, current in zip(group, group[1:])
            if previous["kind"] == "W"
            and current["kind"] == "I"
            and previous["end_ns"] <= current["begin_ns"]
        ]
        pairs.sort(
            key=lambda pair: pair[1]["begin_ns"] - pair[0]["end_ns"], reverse=True
        )

        def interval_issues(start, end):
            found = list(issues)
            if start < starts or end > ends:
                found.append(
                    "Native interval is not fully bracketed by kernel trace timestamps"
                )
            return found

        workers.append(
            {
                "tid": tid,
                "native_record_count": len(group),
                "timeout_count": len(timeouts),
                "adjacent_wait_write_count": len(pairs),
                "largest_timeout_waits": [
                    analyze_wait(
                        row,
                        timers,
                        scheduler,
                        interval_issues(row["begin_ns"], row["end_ns"]),
                        resolution,
                        alignment_verified,
                    )
                    for row in waits
                ],
                "largest_post_wait_write_gaps": [
                    analyze_gap(
                        wait,
                        write,
                        scheduler,
                        interval_issues(wait["end_ns"], write["begin_ns"]),
                        resolution,
                        fd_gpio.get(write["fd"]),
                        alignment_verified,
                    )
                    for wait, write in pairs[:top]
                ],
            }
        )
    return {
        "capture": directory.name,
        "instrumented_only": True,
        "clock": {
            "native": "CLOCK_MONOTONIC",
            "kernel_metadata": clock,
            "text_resolution_ns": resolution,
            "markers": marker_details,
            "marker_alignment_verified": alignment_verified,
            "saleae_alignment": "not attempted",
        },
        "kernel_event_counts": dict(counts),
        "timer_matching": timer_counts,
        "completeness": {
            "issues": list(dict.fromkeys(issues)),
            "text_losses": text_losses,
            "metadata_losses": losses,
            "loss_counters_checked": checked,
        },
        "gap_policy": "Adjacent same-TID W -> I records only; no intervening native operation",
        "interpretation": [
            "Intervals are exact native timestamps with no padding; preceding scheduler events only seed state.",
            "Equal text timestamps do not establish cross-CPU order below the reported resolution.",
            "Timer matching assumes stable hashed-pointer identity and complete own init/start/cancel events.",
            "Following wakeup events are observed sequence candidates, not independent proof of causal linkage.",
            "Non-runnable time does not identify futex/mutex contention; on-CPU time is not pure application CPU.",
            "Native wait includes mutex reacquisition; wait-to-write gaps include recorder bookkeeping.",
            "No kernel root cause is asserted, including when an observed chain is complete.",
        ],
        "workers": workers,
    }


def self_test():
    def line(ns, name, body, tid=11, cpu=0):
        return f"python-3-{tid} [{cpu:03d}] d... {ns // 1_000_000_000}.{ns % 1_000_000_000:09d}: {name}: {body}"

    text = [
        line(900, "sched_switch", "prev_pid=1 prev_state=R next_pid=11"),
        line(1100, "hrtimer_init", "hrtimer=001abc clockid=CLOCK_MONOTONIC mode=ABS"),
        line(
            1200,
            "hrtimer_start",
            "hrtimer=001abc function=hrtimer_wakeup expires=2100 softexpires=2000 mode=ABS",
        ),
        line(1300, "sched_switch", "prev_pid=11 prev_state=S next_pid=9"),
        line(
            2200,
            "hrtimer_expire_entry",
            "hrtimer=001abc function=hrtimer_wakeup now=2150",
            tid=9,
        ),
        line(2300, "sched_waking", "pid=11 prio=120 target_cpu=0", tid=9),
        line(2400, "sched_wakeup", "pid=11 prio=120 target_cpu=0", tid=9),
        line(3500, "sched_switch", "prev_pid=9 prev_state=R next_pid=11", tid=9),
        line(3600, "hrtimer_cancel", "hrtimer=001abc"),
        line(4100, "sched_switch", "prev_pid=11 prev_state=R+ next_pid=9"),
        line(5100, "sched_migrate_task", "pid=11 orig_cpu=0 dest_cpu=1", tid=9),
        line(6100, "sched_switch", "prev_pid=9 prev_state=R next_pid=11", tid=9, cpu=1),
    ]
    events, issues, losses = parse_kernel(text)
    assert not issues and not losses and len(events) == len(text)
    timers, counts = own_timers(events, {11})
    assert counts["matched_own_expiries"] == 1
    scheduler = Scheduler(events, {11})
    row = {
        "seq": 1,
        "kind": "W",
        "tid": 11,
        "fd": -1,
        "level": -1,
        "result": 110,
        "begin_ns": 1000,
        "end_ns": 4000,
        "deadline_ns": 2000,
        "cpu_ns": 20,
    }
    wait = analyze_wait(row, timers, scheduler, [], 1)
    assert wait["attribution_status"] == "complete_observed_chain", wait
    assert wait["timer"]["intervals_ns"]["expires_to_callback"] == 100
    assert wait["timer"]["intervals_ns"]["wakeup_to_switch_in"] == 1100
    assert wait["scheduler"]["totals"]["blocked_off_cpu_ns"] == 1100
    write = dict(
        row, seq=2, kind="I", begin_ns=7000, end_ns=7100, fd=3, level=1, result=0
    )
    gap = analyze_gap(row, write, scheduler, [], 1, 23)
    assert gap["scheduler"]["totals"]["runnable_off_cpu_ns"] == 2000
    assert sum(gap["scheduler"]["totals"].values()) == 3000
    assert all(
        4000 <= event["timestamp_ns"] <= 7000 for event in gap["scheduler"]["events"]
    )
    assert scheduler.timeline(11, 4200, 6000)["totals"]["runnable_off_cpu_ns"] == 1800
    tied = text + [
        line(4100, "sched_switch", "prev_pid=9 prev_state=R next_pid=11", tid=9, cpu=1)
    ]
    tied_scheduler = Scheduler(parse_kernel(tied)[0], {11})
    assert tied_scheduler.timeline(11, 4200, 5000)["totals"]["unknown_ns"] == 800
    assert tied_scheduler.timeline(11, 4000, 5000)["state_order_ambiguities_ns"] == [
        4100
    ]
    reversed_chain = (
        text[:6]
        + [
            line(
                2400,
                "sched_switch",
                "prev_pid=9 prev_state=R next_pid=11",
                tid=9,
                cpu=1,
            ),
            line(2400, "sched_wakeup", "pid=11 prio=120 target_cpu=1", tid=9),
        ]
        + text[8:]
    )
    reversed_events = parse_kernel(reversed_chain)[0]
    reversed_wait = analyze_wait(
        row,
        own_timers(reversed_events, {11})[0],
        Scheduler(reversed_events, {11}),
        [],
        1,
    )
    assert reversed_wait["timer"]["following_switch_in"] is None
    assert reversed_wait["attribution_status"] == "incomplete_or_ambiguous"
    cancelled = text[:4] + [line(1400, "hrtimer_cancel", "hrtimer=001abc")] + text[4:]
    cancelled_timers, _ = own_timers(parse_kernel(cancelled)[0], {11})
    assert cancelled_timers[0].callback is None
    assert (
        analyze_wait(row, cancelled_timers, scheduler, [], 1)["attribution_status"]
        == "incomplete_or_ambiguous"
    )
    multiple = (
        text[:3]
        + [
            line(
                1250,
                "hrtimer_start",
                "hrtimer=001abc expires=2100 softexpires=2000 mode=ABS",
            )
        ]
        + text[3:]
    )
    multiple_timers, _ = own_timers(parse_kernel(multiple)[0], {11})
    assert analyze_wait(row, multiple_timers, scheduler, [], 1)["timer"] is None
    assert pointer("(____ptrval____)") is None
    assert stamp_ns("123456.123456789") == 123456123456789
    assert metadata_losses(
        {"cpu0": "overrun: 0\ncommit overrun: 0\ndropped events: 2"}
    ) == ([{"path": "per_cpu_stats/cpu0", "key": "dropped events", "value": 2}], 3)
    assert metadata_losses({"cpu0": {"overrun": 0, "dropped_events": 0}}) == ([], 2)
    contaminated = analyze_wait(row, timers, scheduler, ["lost events"], 1)
    assert contaminated["attribution_status"] == "incomplete_or_ambiguous"
    assert (
        analyze_wait(row, timers, scheduler, ["clock mismatch"], 1, False)["scheduler"]
        is None
    )
    assert (
        analyze_gap(row, write, scheduler, ["clock mismatch"], 1, 23, False)[
            "scheduler"
        ]
        is None
    )
    markers = [
        line(800, "tracing_mark_write", "BLINKA_PWM_KERNEL_BEGIN"),
        line(8000, "tracing_mark_write", "BLINKA_PWM_KERNEL_END"),
    ]
    marker_events = parse_kernel(markers)[0]
    marker_meta = {
        "begin_marker_monotonic_bounds_ns": [790, 810],
        "end_marker_monotonic_bounds_ns": [7990, 8010],
    }
    assert validate_markers(marker_events, marker_meta)[0] == []
    marker_meta["end_marker_monotonic_bounds_ns"] = [9000, 9100]
    assert validate_markers(marker_events, marker_meta)[0]
    _, _, lost = parse_kernel(["CPU:0 [LOST 3 EVENTS]"])
    assert lost
    print("Kernel trace analyzer self-tests passed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", nargs="?", type=Path)
    parser.add_argument(
        "--top",
        type=int,
        default=5,
        help="Top intervals of each type per worker (1..20)",
    )
    parser.add_argument(
        "--output", help="New JSON filename inside capture directory; never overwrite"
    )
    parser.add_argument(
        "--summary",
        action="store_true",
        help="Print concise CLI summary instead of full JSON",
    )
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if args.directory is None or not 1 <= args.top <= 20:
        parser.error("A capture directory and --top in 1..20 are required")
    result = analyze(args.directory, args.top)
    if args.output:
        if Path(args.output).name != args.output or args.output in {".", ".."}:
            parser.error("--output must be a filename inside the capture directory")
        with (args.directory / args.output).open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
    if args.summary:
        print(
            f"{result['capture']}: kernel text resolution {result['clock']['text_resolution_ns']} ns"
        )
        for issue in result["completeness"]["issues"]:
            print(f"  WARNING: {issue}")
        for worker in result["workers"]:
            print(f"  TID {worker['tid']}: {worker['timeout_count']} timeouts")
            for item in worker["largest_timeout_waits"]:
                spans = (item["timer"] or {}).get("intervals_ns", {})
                print(
                    f"    W#{item['native']['seq']} late {item['lateness_ns'] / 1000:.3f} us; "
                    f"callback-minus-latest {spans.get('expires_to_callback', 'unknown')} ns; "
                    f"wakeup-to-run {spans.get('wakeup_to_switch_in', 'unknown')} ns; "
                    f"{item['attribution_status']}"
                )
            for item in worker["largest_post_wait_write_gaps"]:
                totals = (item["scheduler"] or {}).get("totals", {})
                print(
                    f"    W#{item['wait']['seq']} -> I#{item['write']['seq']} GPIO{item['gpio']}: "
                    f"gap {item['gap_ns'] / 1000:.3f} us; runnable off-CPU "
                    f"{totals.get('runnable_off_cpu_ns', 'unknown')} ns; blocked "
                    f"{totals.get('blocked_off_cpu_ns', 'unknown')} ns; {item['attribution_status']}"
                )
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError) as error:
        print(f"kernel trace analysis failed: {error}", file=sys.stderr)
        sys.exit(1)
