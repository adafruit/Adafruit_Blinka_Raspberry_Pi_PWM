"""Generated kernel-capture lifecycle checks: no SSH, GPIO, sudo, or tracefs."""

import ast
import importlib.util
import io
import json
import subprocess
import sys
import types
from contextlib import ExitStack
from pathlib import Path, PurePosixPath

import pytest

ROOT = "/tmp/blinka-pwm-oct6.abc123"


@pytest.fixture
def generated_code(monkeypatch, tmp_path):
    """Capture the SSH payload, aborting before any external process runs."""

    class Captured(Exception):
        pass

    class Capture:
        def __enter__(self):
            return self

        def __exit__(self, *arguments):
            pass

        def stop(self):
            pass

        def save_capture(self, path):
            pass

        def export_raw_data_binary(self, path, **kwargs):
            pass

    class Manager(Capture):
        def get_devices(self):
            return [
                types.SimpleNamespace(device_id="81F8C2631DF5BF30", is_simulation=False)
            ]

        def start_capture(self, **kwargs):
            return Capture()

    saleae = types.ModuleType("saleae")
    saleae.automation = types.SimpleNamespace(
        Manager=types.SimpleNamespace(connect=lambda **kwargs: Manager()),
        LogicDeviceConfiguration=lambda **kwargs: kwargs,
    )
    monkeypatch.setitem(sys.modules, "saleae", saleae)
    monkeypatch.syspath_prepend(str(Path(__file__).parent))
    spec = importlib.util.spec_from_file_location(
        "capture_trace_harness_under_test", Path(__file__).with_name("capture_trace.py")
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    captured = []

    def intercept(command, **kwargs):
        assert command[0] == "ssh"
        assert command[-2] == "pi@test-pi5.local"
        import shlex

        invocation = shlex.split(command[-1])
        assert invocation[:2] == [ROOT + "/venv/bin/python", "-c"]
        captured.append(invocation[2])
        raise Captured()

    monkeypatch.setattr(module.subprocess, "run", intercept)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_trace.py",
            str(tmp_path / "harness"),
            "--remote-root",
            ROOT,
            "--kernel",
        ],
    )
    with pytest.raises(Captured):
        module.main()
    assert len(captured) == 1
    # Compile the WHOLE payload too; execute only its isolated lifecycle function.
    compile(captured[0], "generated-kernel-capture", "exec")
    return captured[0]


@pytest.mark.parametrize(
    "scenario",
    [
        "success",
        "ready_timeout",
        "ready_false",
        "active_failure",
        "wrong_workers",
        "communicate_timeout",
        "reap_timeout",
    ],
)
def test_kernel_callback_and_pwm_cleanup(generated_code, scenario):
    events, outputs, children, sleeps, directories = [], [], [], [], []

    class PWM:
        def __init__(self, pin, *, frequency, duty_cycle):
            assert (pin, frequency) in ((18, 50), (23, 500))
            assert duty_cycle == 0
            self.pin, self.duty_cycle, self.closed = pin, duty_cycle, False
            outputs.append(self)

        def __enter__(self):
            return self

        def __exit__(self, *arguments):
            self.closed = True
            events.append("close:" + str(self.pin))

    class FakePath:
        def __init__(self, value):
            self.value = str(value)

        @property
        def name(self):
            return PurePosixPath(self.value).name

        def __truediv__(self, value):
            return FakePath(self.value + "/" + str(value))

        def iterdir(self):
            assert self.value == "/proc/self/task"
            tids = [100, 101] if scenario == "wrong_workers" else [100, 101, 102]
            return [FakePath(self.value + "/" + str(tid)) for tid in tids]

        def read_text(self):
            assert self.name == "sched"
            return "se.slice : 100000\n"

        def mkdir(self, *, mode):
            assert mode == 0o700
            assert self.value == ROOT + "/harness-kernel"
            directories.append(self.value)

    class Kernel:
        def __init__(self, command, **kwargs):
            assert command[:4] == [
                "sudo",
                "-n",
                "/usr/bin/python3",
                ROOT + "/kernel_trace_helper.py",
            ]
            arguments = dict(zip(command[4::2], command[5::2]))
            assert arguments["--parent-pid"] == "100"
            assert arguments["--worker-tids"] == "101,102"
            assert arguments["--output-dir"] == ROOT + "/harness-kernel"
            assert arguments["--instance"].startswith("blinka-pwm-oct6-")
            assert kwargs["text"] is True
            self.stdout = io.StringIO(
                json.dumps(
                    {
                        "ready": scenario != "ready_false",
                        "instance": arguments["--instance"],
                    }
                )
                + "\n"
            )
            self.stdin = io.StringIO()
            self.stderr = io.StringIO()
            self.returncode = None
            self.requests = []
            children.append(self)

        def communicate(self, request=None, *, timeout):
            assert timeout <= 30
            assert all(not output.closed for output in outputs)
            if request is None:
                assert self.stdin.closed
                assert events == ["kernel_stop", "kernel_term"]
                if scenario == "reap_timeout":
                    raise subprocess.TimeoutExpired("fake-kernel", timeout)
                self.returncode = 0
                events.append("kernel_reaped")
                return '{"finished":true}\n', ""
            assert request == "STOP\n"  # Actual newline, not a literal backslash-n.
            if scenario == "success":
                assert all(output.duty_cycle == 0 for output in outputs)
                assert sleeps == [0.2, 20.0, 0.2]
            self.requests.append(request)
            events.append("kernel_stop")
            if scenario in ("communicate_timeout", "reap_timeout"):
                raise subprocess.TimeoutExpired("fake-kernel", timeout)
            self.returncode = 0
            return '{"finished":true}\n', ""

        def terminate(self):
            assert self.stdin.closed
            events.append("kernel_term")

        def wait(self, *, timeout):
            assert timeout <= 30
            self.returncode = 0
            return 0

        def poll(self):
            return self.returncode

    class FakeTime:
        ticks = 0

        @classmethod
        def monotonic(cls):
            cls.ticks += 0.001
            return cls.ticks

        @staticmethod
        def sleep(duration):
            sleeps.append(duration)
            if scenario == "active_failure" and duration == 20:
                raise RuntimeError("injected active wait failure")

    def select(readers, writers, errors, timeout):
        assert timeout <= 30 and not writers and not errors
        return ([] if scenario == "ready_timeout" else readers), [], []

    resource = types.SimpleNamespace(
        RUSAGE_SELF=0,
        getrusage=lambda who: types.SimpleNamespace(ru_utime=0.0, ru_stime=0.0),
    )
    environment = {
        "PWMOut": PWM,
        "ExitStack": ExitStack,
        "Path": FakePath,
        "time": FakeTime,
        "json": json,
        "resource": resource,
        "SimpleNamespace": types.SimpleNamespace,
        "os": types.SimpleNamespace(
            getpid=lambda: 100,
            PRIO_PROCESS=0,
            sched_getscheduler=lambda tid: 0,
            getpriority=lambda kind, tid: 0,
            sched_getaffinity=lambda tid: {0, 1, 2, 3},
        ),
        "subprocess": types.SimpleNamespace(
            PIPE=object(), Popen=Kernel, TimeoutExpired=subprocess.TimeoutExpired
        ),
        "select": types.SimpleNamespace(select=select),
        "load": [
            types.SimpleNamespace(pid=200 + i, poll=lambda: None) for i in range(4)
        ],
        "thread_settings": [],
        "active_stats": {},
        "lifecycle_events": {},
    }
    parsed = ast.parse(generated_code)
    function = next(
        node
        for node in parsed.body
        if isinstance(node, ast.FunctionDef) and node.name == "run_output"
    )
    isolated = ast.Module(body=[function], type_ignores=[])
    # Only the trusted generated lifecycle function runs, with all I/O faked.
    exec(compile(isolated, "isolated-run-output", "exec"), environment)  # noqa: S102
    if scenario == "success":
        environment["run_output"]()
    else:
        with pytest.raises(RuntimeError):
            environment["run_output"]()
    assert len(outputs) == 2 and all(output.closed for output in outputs)
    assert events[-2:] == ["close:23", "close:18"]
    if scenario == "wrong_workers":
        assert not children and not directories
    else:
        assert len(children) == 1 and children[0].requests == ["STOP\n"]
        prefix = ["kernel_stop"]
        if scenario in ("communicate_timeout", "reap_timeout"):
            prefix.append("kernel_term")
        if scenario == "communicate_timeout":
            prefix.append("kernel_reaped")
        assert events == prefix + ["close:23", "close:18"]
