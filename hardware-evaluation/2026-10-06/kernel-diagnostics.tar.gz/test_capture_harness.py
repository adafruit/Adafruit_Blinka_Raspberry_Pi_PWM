"""Local, no-hardware checks for generated bench programs and thermal gates."""

import ast
from contextlib import ExitStack
from types import SimpleNamespace
import unittest

from capture_pwm import remote_code, thermal_issues


class HarnessTests(unittest.TestCase):
    def test_thermal_gate(self):
        good = {"temperature_millic": "65000", "throttled": "throttled=0x0"}
        self.assertEqual(thermal_issues(good, 65000), [])
        self.assertTrue(thermal_issues({**good, "temperature_millic": "65001"}, 65000))
        self.assertEqual(thermal_issues({**good, "temperature_millic": "75000"}, 75000), [])
        self.assertTrue(thermal_issues({**good, "temperature_millic": "75001"}, 75000))
        for flag in (None, "malformed", "throttled=0x8", "throttled=0x80000", "throttled=0xe0008"):
            self.assertTrue(thermal_issues({**good, "throttled": flag}, 65000))
        self.assertTrue(thermal_issues({}, 65000))

    def run_generated_output(self, backend, retire=False, failure=None):
        specs = [{"gpio": 18, "frequency": 50, "duty": 4915},
                 {"gpio": 23, "frequency": 500, "duty": 32768}]
        source = remote_code(50, 4915, backend, duration=20,
                             output_specs=specs, retire_first=retire,
                             host="test-pi5.local" if backend == "lgpio" else "test2-pi4.local")
        compile(source, "generated-bench", "exec")
        tree = ast.parse(source)
        run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run_output")
        program = ast.fix_missing_locations(ast.Module(body=[run], type_ignores=[]))
        created = []

        class FakePWM:
            def __init__(self, pin, frequency, duty_cycle):
                if failure == "second-start" and created:
                    raise RuntimeError("injected second constructor failure")
                self.pin, self.frequency = pin, frequency
                self.closed = False
                self.values = [duty_cycle]
                created.append(self)

            def __enter__(self):
                return self

            def __exit__(self, *args):
                self.deinit()

            def deinit(self):
                self.closed = True

            @property
            def duty_cycle(self):
                return self.values[-1]

            @duty_cycle.setter
            def duty_cycle(self, value):
                assert not self.closed, "Attempted update after deinit"
                self.values.append(value)

        class FakeTime:
            value = 0

            def sleep(self, seconds):
                if failure == "active-wait" and seconds > 1:
                    raise RuntimeError("injected active wait failure")
                self.value += seconds

            def monotonic(self):
                return self.value

        class FakeTask:
            def __init__(self, name):
                self.name = name

            def __truediv__(self, other):
                return self

            def read_text(self):
                return "se.slice : 2100000"

        class FakePath:
            def __init__(self, path):
                self.path = path

            def iterdir(self):
                return [FakeTask(str(tid)) for tid in (100, 101, 102)]

        namespace = {
            "PWMOut": FakePWM, "ExitStack": ExitStack, "time": FakeTime(),
            "Path": FakePath, "SimpleNamespace": SimpleNamespace,
            "os": SimpleNamespace(getpid=lambda: 100, sched_getscheduler=lambda tid: 0,
                PRIO_PROCESS=0, getpriority=lambda *args: 0,
                sched_getaffinity=lambda tid: {0, 1, 2, 3}),
            "resource": SimpleNamespace(RUSAGE_SELF=0,
                getrusage=lambda kind: SimpleNamespace(ru_utime=0, ru_stime=0)),
            "load": [], "lifecycle_events": {},
        }
        exec(compile(program, "generated-run-output", "exec"), namespace)
        if failure:
            with self.assertRaises(RuntimeError):
                namespace["run_output"]()
        else:
            namespace["run_output"]()
            self.assertEqual(len(created), 2)
            self.assertEqual(namespace["active_stats"]["elapsed_seconds"], 20)
            self.assertEqual(bool(namespace["lifecycle_events"]), retire)
            for spec, output in zip(specs, created):
                self.assertEqual(output.values, [0, spec["duty"], 0])
                pin_id = output.pin.id if backend in ("rpi_gpio", "lgpio") else output.pin
                self.assertEqual(pin_id, spec["gpio"])
        self.assertTrue(all(output.closed for output in created))

    def test_dual_lifecycle_and_failure_cleanup(self):
        for backend in ("draft", "rpi_gpio", "lgpio"):
            for retire in (False, True):
                with self.subTest(backend=backend, retire=retire):
                    self.run_generated_output(backend, retire)
            for failure in ("second-start", "active-wait"):
                with self.subTest(backend=backend, failure=failure):
                    self.run_generated_output(backend, failure=failure)

    def test_invalid_pin_configuration(self):
        for specs in ([{"gpio": 18, "frequency": 500, "duty": 32768}],
                      [{"gpio": 18, "frequency": 500, "duty": 32768}] * 2):
            with self.assertRaises(ValueError):
                remote_code(500, 32768, "draft", output_specs=specs)

    def test_baseline_host_pairings(self):
        with self.assertRaises(ValueError):
            remote_code(500, 32768, "lgpio", host="test2-pi4.local")
        with self.assertRaises(ValueError):
            remote_code(500, 32768, "rpi_gpio", host="test-pi5.local")
        with self.assertRaises(ValueError):
            remote_code(500, 32768, "draft", host="unapproved-host")


if __name__ == "__main__":
    unittest.main()
