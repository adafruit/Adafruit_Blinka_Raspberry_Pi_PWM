"""Fake fixed half50 capture orchestration; no hardware or external calls."""

import json
import shlex
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

import capture_kernel_pwm_half50 as bench


@pytest.mark.parametrize("mode", bench.MODES)
@pytest.mark.parametrize(
    "scenario",
    [
        "success",
        "helper_failure",
        "timeout",
        "wrong_strategy",
        "wrong_sequence",
        "cleanup_failure",
        "missing_device",
        "simulation",
        "waveform_rejected",
    ],
)
def test_capture(monkeypatch, tmp_path, mode, scenario):
    events = []
    capture = MagicMock()
    capture.__enter__.return_value = capture
    capture.stop.side_effect = lambda: events.append("stop")
    capture.save_capture.side_effect = lambda path: events.append("save")
    capture.export_raw_data_binary.side_effect = lambda path, **kw: events.append(
        ("export", kw["digital_channels"])
    )
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = (
        []
        if scenario == "missing_device"
        else [
            SimpleNamespace(
                device_id=bench.DEVICE_ID,
                is_simulation=scenario == "simulation",
            )
        ]
    )
    manager.start_capture.return_value = capture
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    connection = MagicMock(return_value=manager)
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connection),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert capture.__enter__.called
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            "/usr/bin/python3",
            "/tmp/blinka-pwm-oct6.abc123/half50-eval/kernel_pwm_half50_eval.py",
            "--mode",
            mode,
        ]
        assert kwargs == {
            "capture_output": True,
            "text": True,
            "check": False,
            "timeout": 30,
        }
        if scenario == "timeout":
            raise subprocess.TimeoutExpired(command, 30, b"partial", b"failed")
        return subprocess.CompletedProcess(
            command,
            int(scenario == "helper_failure"),
            json.dumps(
                {
                    "mode": mode,
                    "transition_strategy": "wrong"
                    if scenario == "wrong_strategy"
                    else bench.STRATEGY,
                    "sequence_marker": "wrong"
                    if scenario == "wrong_sequence"
                    else bench.SEQUENCE_MARKER,
                    "sysfs_released": True,
                    "low_confirmed": True,
                    "cleanup_errors": ["failed"]
                    if scenario == "cleanup_failure"
                    else [],
                }
            ),
            "",
        )

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(
        bench.time,
        "sleep",
        lambda duration: events.append(
            ("lead" if duration == 0.5 else "tail", duration)
        ),
    )

    def analyze(directory, name):
        events.append("analysis")
        result = json.loads((directory / "results.json").read_text())
        assert result["transition_strategy"] == bench.STRATEGY
        assert result["mode"] == mode
        assert result["sequence_marker"] == bench.SEQUENCE_MARKER
        report = {"accepted": scenario != "waveform_rejected"}
        (directory / name).write_text(json.dumps(report))
        return report

    monkeypatch.setattr(bench, "write_analysis", analyze)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_half50.py",
            str(tmp_path / "capture"),
            "--remote-root",
            "/tmp/blinka-pwm-oct6.abc123/half50-eval",
            "--mode",
            mode,
        ],
    )
    if scenario == "success":
        bench.main()
    else:
        with pytest.raises(RuntimeError):
            bench.main()
    connection.assert_called_once_with(port=10430, connect_timeout_seconds=5)
    if scenario in ("missing_device", "simulation"):
        runner.assert_not_called()
        manager.start_capture.assert_not_called()
        assert events == []
    else:
        manager.start_capture.assert_called_once_with(
            device_id=bench.DEVICE_ID,
            device_configuration={
                "enabled_digital_channels": [0],
                "digital_sample_rate": 100_000_000,
            },
        )
        expected = [
            ("lead", 0.5),
            "ssh",
            ("tail", 0.2),
            "stop",
            "save",
            ("export", [0]),
        ]
        if scenario in ("success", "waveform_rejected"):
            expected.append("analysis")
        assert events == expected
        assert (tmp_path / "capture" / "remote.stdout").is_file()
        if scenario == "waveform_rejected":
            assert (
                json.loads((tmp_path / "capture" / "analysis.json").read_text())[
                    "accepted"
                ]
                is False
            )


@pytest.mark.parametrize(
    "remote_root",
    [
        "",
        "/tmp",
        "/tmp/blinka-pwm-oct6.abc123/state-eval",
        "/tmp/blinka-pwm-oct6.abc123/half50-eval/../other",
    ],
)
def test_reject_other_directory(monkeypatch, tmp_path, remote_root):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_half50.py",
            str(tmp_path / "capture"),
            "--remote-root",
            remote_root,
            "--mode",
            bench.MODE,
        ],
    )
    with pytest.raises(ValueError, match="isolated Pi 5"):
        bench.main()
    assert not (tmp_path / "capture").exists()


def test_existing_capture_directory_never_overwritten(monkeypatch, tmp_path):
    output = tmp_path / "capture"
    output.mkdir()
    evidence = output / "remote.stdout"
    evidence.write_text("original")
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_half50.py",
            str(output),
            "--remote-root",
            "/tmp/blinka-pwm-oct6.abc123/half50-eval",
        ],
    )
    connect = MagicMock()
    monkeypatch.setattr(bench.automation.Manager, "connect", connect)
    with pytest.raises(FileExistsError):
        bench.main()
    assert evidence.read_text() == "original"
    connect.assert_not_called()
