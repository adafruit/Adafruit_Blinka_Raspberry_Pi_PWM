"""Offline synthetic Saleae fixtures: no Pi, GPIO, sysfs, or Saleae connection."""

import json
import struct

import pytest
from analyze_kernel_pwm_eval import ENDPOINT_DUTIES, OUTPUTS, analyze, write_analysis


def binary_export(
    path, edges, *, initial=0, begin=0.0, end=2.0, rate=10_000_000, chunks=1
):
    data = b"<SALEAE>" + struct.pack("<iiQ", 1, 0, chunks)
    for _ in range(chunks):
        data += struct.pack("<IdddQ", initial, rate, begin, end, len(edges))
        data += struct.pack(f"<{len(edges)}d", *edges)
    path.write_bytes(data)


def metadata_files(directory, mode, sample_rate_hz=10_000_000):
    duties = (
        ENDPOINT_DUTIES
        if mode == "endpoints"
        else (
            {"18": 0, "23": 0},
            {"18": 4915, "23": 32768},
            {"18": 0, "23": 0},
        )
    )
    phases, tick = [], 10_000_000_000
    for index, states in enumerate(duties):
        duration = (
            (3.0 if mode == "idle" else 20.0)
            if mode != "endpoints" and index == 1
            else 0.2
        )
        end = tick + round(duration * 1e9)
        phases.append(
            {
                "name": f"phase-{index}",
                "duration_seconds": duration,
                "duties": states,
                "begin_ns": tick,
                "end_ns": end,
            }
        )
        tick = end
    remote = {
        "mode": mode,
        "phases": phases,
        "sysfs_released": True,
        "burner_pids": [101, 102, 103, 104] if mode == "loaded" else [],
        "burner_watchdog_seconds": 25,
    }
    metadata = {
        "mode": mode,
        "host": "test-pi5.local",
        "sample_rate_hz": sample_rate_hz,
        "outputs": list(OUTPUTS),
        "remote": remote,
    }
    (directory / "remote.stdout").write_text(json.dumps(remote) + "\n")
    (directory / "results.json").write_text(json.dumps(metadata) + "\n")
    (directory / "waveform.sal").write_bytes(
        b"synthetic fixture; binary exports tested separately"
    )
    return metadata


def replace_metadata(directory, metadata):
    (directory / "remote.stdout").write_text(json.dumps(metadata["remote"]) + "\n")
    (directory / "results.json").write_text(json.dumps(metadata) + "\n")


@pytest.fixture(params=[10_000_000, 100_000_000], ids=["10MSa", "100MSa"])
def endpoints(tmp_path, request):
    rate = request.param
    metadata_files(tmp_path, "endpoints", rate)
    binary_export(tmp_path / "digital_0.bin", (0.2, 0.4, 1.0, 1.2), rate=rate)
    binary_export(tmp_path / "digital_1.bin", (0.6, 0.8, 1.001, 1.201), rate=rate)
    return tmp_path


def test_endpoint_physical_pattern_and_independence(endpoints):
    result = analyze(endpoints)
    assert result["endpoints"]["physical_sequence_validated"] is True
    assert result["endpoints"]["phase_alignment_proven"] is False
    assert result["endpoints"]["both_high_overlap_seconds"] == pytest.approx(0.199)
    assert [entry["waveform"]["edge_count"] for entry in result["outputs"]] == [4, 4]
    rate = json.loads((endpoints / "results.json").read_text())["sample_rate_hz"]
    assert result["sample_rate_hz"] == rate
    assert result["quantization"]["nominal_sample_interval_us"] == 1e6 / rate
    assert all(
        output["waveform"]["header_sample_rate_hz"] == rate
        for output in result["outputs"]
    )
    assert result["quantization"]["timebase_calibrated"] is False


def test_both_channels_must_observe_the_independent_highs(endpoints):
    rate = json.loads((endpoints / "results.json").read_text())["sample_rate_hz"]
    binary_export(
        endpoints / "digital_1.bin", (0.6, 0.8, 1.001, 1.201), begin=0.5, rate=rate
    )
    with pytest.raises(ValueError, match="full edge sequence"):
        analyze(endpoints)


@pytest.mark.parametrize(
    "edges,kwargs,match",
    [
        ((0.2, 0.4, 0.5, 0.51, 1.0, 1.2), {}, "four endpoint transitions"),
        (
            (0.2, 0.4, 0.99, 0.991, 1.0, 1.001, 1.002, 1.003, 1.004, 1.2),
            {},
            "four endpoint transitions",
        ),
        ((0.2, 0.4, 1.0, 1.2), {"initial": 1}, "did not start low"),
        ((0.2, 0.4, 1.0), {}, "did not finish low"),
        ((0.2, 0.4, 1.0, 1.2), {"end": 1.25}, "stable low tail"),
        ((0.2, 0.3, 1.0, 1.2), {}, "static high holds"),
        ((0.5, 0.7, 1.0, 1.2), {}, "Independent GPIO18-high"),
        ((0.2, 0.4, 1.2, 1.4), {}, "both-high overlap"),
        ((0.2, 0.4, 1.0, 1.2), {"rate": 1_000_000}, "sample rate"),
        ((0.2, 0.4, 1.0, 1.2), {"chunks": 2}, "continuous capture chunk"),
    ],
)
def test_endpoint_rejections(endpoints, edges, kwargs, match):
    kwargs = {
        "rate": json.loads((endpoints / "results.json").read_text())["sample_rate_hz"],
        **kwargs,
    }
    binary_export(endpoints / "digital_0.bin", edges, **kwargs)
    with pytest.raises(ValueError, match=match):
        analyze(endpoints)


@pytest.mark.parametrize(
    "mutation,match",
    [
        (lambda m: m["remote"].update(sysfs_released=False), "sysfs release"),
        (lambda m: m["remote"].update(mode="idle"), "Remote mode"),
        (
            lambda m: m["remote"]["phases"][1].update(duties={"18": 0, "23": 65535}),
            "duties",
        ),
        (lambda m: m["remote"]["phases"][1].update(duration_seconds=0.1), "0.2 s"),
        (
            lambda m: m["remote"]["phases"][1].update(begin_ns=None),
            "monotonic timestamps",
        ),
        (lambda m: m["outputs"][0].update(saleae_channel=1), "mapping"),
        (lambda m: m["remote"].update(burner_pids=[101]), "worker PIDs"),
    ],
)
def test_metadata_rejections(endpoints, mutation, match):
    metadata = json.loads((endpoints / "results.json").read_text())
    mutation(metadata)
    replace_metadata(endpoints, metadata)
    with pytest.raises(ValueError, match=match):
        analyze(endpoints)


def test_remote_copy_must_match(endpoints):
    remote = json.loads((endpoints / "remote.stdout").read_text())
    remote["sysfs_released"] = False
    (endpoints / "remote.stdout").write_text(json.dumps(remote))
    with pytest.raises(ValueError, match="disagrees"):
        analyze(endpoints)


@pytest.mark.parametrize("rate", [0, 1_000_000, 50_000_000, 200_000_000])
def test_unsupported_endpoint_rate_rejected(tmp_path, rate):
    metadata_files(tmp_path, "endpoints", rate)
    with pytest.raises(ValueError, match="Endpoints require"):
        analyze(tmp_path)


@pytest.mark.parametrize("mode", ["idle", "loaded"])
def test_100MSa_only_allowed_for_endpoints(tmp_path, mode):
    metadata_files(tmp_path, mode, 100_000_000)
    with pytest.raises(ValueError, match="idle/loaded require 10 MSa/s"):
        analyze(tmp_path)


def test_each_channel_header_rate_must_match_metadata(endpoints):
    rate = json.loads((endpoints / "results.json").read_text())["sample_rate_hz"]
    wrong_rate = 100_000_000 if rate == 10_000_000 else 10_000_000
    binary_export(
        endpoints / "digital_1.bin", (0.6, 0.8, 1.001, 1.201), rate=wrong_rate
    )
    with pytest.raises(ValueError, match="sample rate does not match metadata"):
        analyze(endpoints)


@pytest.mark.parametrize("mode", ["idle", "loaded"])
def test_pwm_uses_complete_trimmed_cycles(tmp_path, mode):
    metadata_files(tmp_path, mode)
    duration = 3 if mode == "idle" else 20
    for spec in OUTPUTS:
        period = 1 / spec["frequency"]
        high = period * spec["duty"] / 65535
        edges = [
            edge
            for index in range(spec["frequency"] * duration)
            for edge in (0.4 + index * period, 0.4 + index * period + high)
        ]
        binary_export(
            tmp_path / f"digital_{spec['saleae_channel']}.bin", edges, end=duration + 1
        )
    result = analyze(tmp_path)
    assert "endpoints" not in result
    for output in result["outputs"]:
        timing = output["timing"]
        assert timing["steady_state_trim_seconds_each_end"] == 0.05
        assert 0 < timing["period_us"]["count"] < output["frequency"] * duration
        assert timing["mean_frequency_hz"] == pytest.approx(output["frequency"])
        assert timing["mean_duty_percent"] == pytest.approx(
            output["duty"] / 65535 * 100
        )
        assert timing["estimated_omitted_cycles"] is None
        assert timing["final_state"] == 0


@pytest.mark.parametrize(
    "pids",
    [
        [],
        [101, 102, 103],
        [101, 101, 103, 104],
        [101, 102, 0, 104],
        [101, 102, True, 104],
    ],
)
def test_loaded_requires_four_distinct_positive_integer_worker_pids(tmp_path, pids):
    metadata = metadata_files(tmp_path, "loaded")
    metadata["remote"]["burner_pids"] = pids
    replace_metadata(tmp_path, metadata)
    with pytest.raises(ValueError, match="worker PIDs"):
        analyze(tmp_path)


@pytest.mark.parametrize("mode,wrong_duration", [("idle", 20), ("loaded", 3)])
def test_active_duration_must_match_mode(tmp_path, mode, wrong_duration):
    metadata = metadata_files(tmp_path, mode)
    metadata["remote"]["phases"][1]["duration_seconds"] = wrong_duration
    replace_metadata(tmp_path, metadata)
    with pytest.raises(ValueError, match="mode should request"):
        analyze(tmp_path)


def test_exclusive_output_preserves_existing_analysis(endpoints):
    original = write_analysis(endpoints)
    saved = (endpoints / "analysis.json").read_bytes()
    assert json.loads(saved)["mode"] == original["mode"]
    with pytest.raises(FileExistsError):
        write_analysis(endpoints)
    assert (endpoints / "analysis.json").read_bytes() == saved
    with pytest.raises(ValueError, match="filename"):
        write_analysis(endpoints, "../outside.json")
