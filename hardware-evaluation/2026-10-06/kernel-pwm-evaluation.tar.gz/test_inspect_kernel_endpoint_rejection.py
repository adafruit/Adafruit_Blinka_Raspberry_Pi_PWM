"""Synthetic rejection-report checks; no analyzer or GPIO access."""

import pytest
from inspect_kernel_endpoint_rejection import inspect
from test_kernel_pwm_waveforms import binary_export, metadata_files


@pytest.mark.parametrize("rate", [10_000_000, 100_000_000])
def test_explain_notch_without_accepting_endpoint(tmp_path, rate):
    metadata_files(tmp_path, "endpoints", rate)
    binary_export(
        tmp_path / "digital_0.bin", (0.2, 0.22, 0.22000002, 0.4, 1.0, 1.2), rate=rate
    )
    binary_export(tmp_path / "digital_1.bin", (0.6, 0.8, 1.001, 1.201), rate=rate)
    result = inspect(tmp_path)
    assert result["accepted"] is False
    assert "four endpoint transitions" in result["rejection"]
    assert result["nominal_sample_interval_ns"] == 1e9 / rate
    assert result["outputs"][0]["sub_microsecond_interior_low_count"] == 1
    assert result["outputs"][0]["digitized_low_width_ns"] == pytest.approx([20])
    assert result["outputs"][1]["sub_microsecond_interior_low_count"] == 0


def test_never_reclassify_clean_endpoint_as_failure(tmp_path):
    metadata_files(tmp_path, "endpoints")
    binary_export(tmp_path / "digital_0.bin", (0.2, 0.4, 1.0, 1.2))
    binary_export(tmp_path / "digital_1.bin", (0.6, 0.8, 1.001, 1.201))
    with pytest.raises(ValueError, match="Expected a rejected"):
        inspect(tmp_path)
