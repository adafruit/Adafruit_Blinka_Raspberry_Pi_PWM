"""Local orchestration checks; no SSH, analyzer connection, or physical GPIO."""

import json
import shlex
import subprocess
import sys
from types import SimpleNamespace

import capture_kernel_pwm as bench
import pytest


@pytest.mark.parametrize(
    "scenario",
    ["success", "helper_failure", "timeout", "bad_cleanup", "missing_device"],
)
@pytest.mark.parametrize("sample_rate", [10_000_000, 100_000_000])
def test_capture_lifecycle(monkeypatch, tmp_path, scenario, sample_rate):
    events = []
    mode = "endpoints" if sample_rate == 100_000_000 else "idle"

    class Capture:
        def __enter__(self):
            events.append("capture")
            return self

        def __exit__(self, *_args):
            events.append("capture_closed")

        def stop(self):
            events.append("stop")

        def save_capture(self, path):
            events.append("save")
            assert path.endswith("/waveform.sal")

        def export_raw_data_binary(self, path, *, digital_channels):
            events.append("export")
            assert digital_channels == [0, 1]

    class Manager:
        def __enter__(self):
            events.append("manager")
            return self

        def __exit__(self, *_args):
            events.append("manager_closed")

        def get_devices(self):
            return (
                []
                if scenario == "missing_device"
                else [SimpleNamespace(device_id=bench.DEVICE_ID, is_simulation=False)]
            )

        def start_capture(self, *, device_id, device_configuration):
            assert device_id == bench.DEVICE_ID
            assert device_configuration == {
                "enabled_digital_channels": [0, 1],
                "digital_sample_rate": sample_rate,
            }
            return Capture()

        def get_app_info(self):
            return SimpleNamespace(app_version="fake")

    def connect(*, port, connect_timeout_seconds):
        assert port == 10430 and connect_timeout_seconds == 5
        return Manager()

    def run(command, *, capture_output, text, check, timeout):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            "/usr/bin/python3",
            "/tmp/blinka-pwm-oct6.abc123/kernel_pwm_eval.py",
            "--mode",
            mode,
        ]
        assert capture_output and text and not check and timeout == 45
        if scenario == "timeout":
            raise subprocess.TimeoutExpired(
                command, timeout, output=b"partial", stderr=b"error"
            )
        return subprocess.CompletedProcess(
            command,
            int(scenario == "helper_failure"),
            json.dumps({"mode": mode, "sysfs_released": scenario != "bad_cleanup"}),
            "",
        )

    def analyze(directory, name):
        events.append("analysis")
        assert name == "analysis.json"
        assert (directory / "results.json").is_file()
        return {"ok": True}

    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connect),
            LogicDeviceConfiguration=lambda **kw: kw,
        ),
    )
    monkeypatch.setattr(bench.subprocess, "run", run)
    monkeypatch.setattr(bench, "write_analysis", analyze)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm.py",
            str(tmp_path / "capture"),
            "--remote-root",
            "/tmp/blinka-pwm-oct6.abc123",
            "--mode",
            mode,
            "--sample-rate-hz",
            str(sample_rate),
        ],
    )
    if scenario == "success":
        bench.main()
        assert events == [
            "manager",
            "capture",
            "ssh",
            "stop",
            "save",
            "export",
            "capture_closed",
            "manager_closed",
            "analysis",
        ]
    else:
        with pytest.raises(RuntimeError):
            bench.main()
        if scenario == "missing_device":
            assert events == ["manager", "manager_closed"]
        else:
            assert events == [
                "manager",
                "capture",
                "ssh",
                "stop",
                "save",
                "export",
                "capture_closed",
                "manager_closed",
            ]
            assert (tmp_path / "capture" / "remote.stdout").is_file()
            assert (tmp_path / "capture" / "remote.stderr").is_file()


@pytest.mark.parametrize(
    "remote_root", ["/tmp/", "/tmp/blinka-pwm-oct6.abc123/../elsewhere", ""]
)
def test_reject_unapproved_remote_root(monkeypatch, tmp_path, remote_root):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm.py",
            str(tmp_path / "capture"),
            "--remote-root",
            remote_root,
            "--mode",
            "idle",
        ],
    )
    with pytest.raises(ValueError, match="isolated Pi 5"):
        bench.main()
    assert not (tmp_path / "capture").exists()
