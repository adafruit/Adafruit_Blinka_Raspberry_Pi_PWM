"""Explain rejected static endpoints offline; never convert a failure to a pass."""

import argparse
import json
from pathlib import Path

from analyze_kernel_pwm_eval import analyze, read_continuous, validate_metadata


def inspect(directory):
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    remote = json.loads((directory / "remote.stdout").read_text())
    if validate_metadata(metadata, remote) != "endpoints":
        raise ValueError("Endpoint captures only")
    try:
        analyze(directory)
    except ValueError as error:
        rejection = str(error)
    else:
        raise ValueError("Expected a rejected endpoint capture")
    outputs = []
    for gpio, channel in ((18, 0), (23, 1)):
        waveform, edges = read_continuous(
            directory / f"digital_{channel}.bin", metadata["sample_rate_hz"]
        )
        lows = [(edges[i], edges[i + 1]) for i in range(1, len(edges) - 1, 2)]
        # Diagnostic classification only: the strict validator above still rejects
        # every extra edge, regardless of how short it is.
        notches = [(begin, end) for begin, end in lows if end - begin < 1e-6]
        outputs.append(
            {
                "gpio": gpio,
                "saleae_channel": channel,
                "waveform": waveform,
                "transition_seconds": list(edges),
                "sub_microsecond_interior_low_count": len(notches),
                "digitized_low_width_ns": [
                    (end - begin) * 1e9 for begin, end in notches
                ],
                "interior_low_begin_seconds": [begin for begin, _ in notches],
            }
        )
    return {
        "capture": directory.name,
        "accepted": False,
        "rejection": rejection,
        "sample_rate_hz": metadata["sample_rate_hz"],
        "nominal_sample_interval_ns": 1e9 / metadata["sample_rate_hz"],
        "timebase_calibrated": False,
        "width_note": "Digitized threshold crossings, not analog pulse-width proof.",
        "sysfs_released_reported": remote["sysfs_released"],
        "outputs": outputs,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    report = inspect(args.directory)
    with (args.directory / "endpoint-rejection.json").open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report))


if __name__ == "__main__":
    main()
