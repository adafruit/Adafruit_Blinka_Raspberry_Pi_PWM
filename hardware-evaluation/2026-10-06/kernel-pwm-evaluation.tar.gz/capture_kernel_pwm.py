"""Approved Pi5 kernel PWM captures; does not configure overlays or invoke sudo.

GPIO18 hardware PWM/channel0 and GPIO23 kernel software PWM/channel1 only.
Requires the reviewed providers to have been explicitly enabled beforehand.
The remote helper owns only its new sysfs exports; providers remain until reboot.
"""

import argparse
import json
import re
import shlex
import subprocess
from pathlib import Path

from analyze_kernel_pwm_eval import write_analysis
from capture_pwm import DEVICE_ID
from saleae import automation


def decoded(value):
    return value.decode(errors="replace") if isinstance(value, bytes) else value or ""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument(
        "--mode", choices=("endpoints", "idle", "loaded"), required=True
    )
    parser.add_argument(
        "--sample-rate-hz",
        type=int,
        choices=(10_000_000, 100_000_000),
        default=10_000_000,
    )
    args = parser.parse_args()
    if args.sample_rate_hz != 10_000_000 and args.mode != "endpoints":
        raise ValueError(
            "Higher sampling rate is restricted to the endpoint diagnostic"
        )
    if not re.fullmatch(r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}", args.remote_root):
        raise ValueError("Requires the isolated Pi 5 bench directory")
    output = args.directory.resolve()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", output.name):
        raise ValueError("Use a simple capture directory name")
    output.mkdir(parents=True, exist_ok=False)
    host = "test-pi5.local"
    invocation = shlex.join(
        [
            "/usr/bin/python3",
            args.remote_root + "/kernel_pwm_eval.py",
            "--mode",
            args.mode,
        ]
    )
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        f"pi@{host}",
        invocation,
    ]
    # Connect the analyzer before launching anything that can drive a GPIO.
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        if not any(
            device.device_id == DEVICE_ID and not device.is_simulation
            for device in manager.get_devices()
        ):
            raise RuntimeError("Confirmed analyzer is not available")
        config = automation.LogicDeviceConfiguration(
            enabled_digital_channels=[0, 1], digital_sample_rate=args.sample_rate_hz
        )
        with manager.start_capture(
            device_id=DEVICE_ID, device_configuration=config
        ) as capture:
            try:
                remote = subprocess.run(
                    command, capture_output=True, text=True, check=False, timeout=45
                )
            except subprocess.TimeoutExpired as exc:
                remote = subprocess.CompletedProcess(
                    command,
                    124,
                    decoded(exc.stdout),
                    decoded(exc.stderr) + "\nSSH timeout",
                )
            finally:
                capture.stop()
                capture.save_capture(str(output / "waveform.sal"))
                capture.export_raw_data_binary(str(output), digital_channels=[0, 1])
        (output / "remote.stdout").write_text(remote.stdout)
        (output / "remote.stderr").write_text(remote.stderr)
        if remote.returncode:
            raise RuntimeError(
                f"Capture saved; helper failed ({remote.returncode}): {remote.stderr}"
            )
        remote_data = json.loads(remote.stdout)
        if (
            remote_data.get("mode") != args.mode
            or remote_data.get("sysfs_released") is not True
        ):
            raise RuntimeError("Helper did not confirm the expected mode and cleanup")
        result = {
            "host": host,
            "mode": args.mode,
            "sample_rate_hz": args.sample_rate_hz,
            "logic_version": manager.get_app_info().app_version,
            "providers_left_loaded_until_reboot": True,
            "production_backend_unchanged": True,
            "outputs": [
                {
                    "gpio": 18,
                    "saleae_channel": 0,
                    "frequency": 50,
                    "duty": 4915,
                    "backend": "kernel-hardware-rp1",
                },
                {
                    "gpio": 23,
                    "saleae_channel": 1,
                    "frequency": 500,
                    "duty": 32768,
                    "backend": "kernel-software-pwm-gpio",
                },
            ],
            "remote": remote_data,
        }
        with (output / "results.json").open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
    report = write_analysis(output, "analysis.json")
    print(json.dumps({"capture": output.name, "mode": args.mode, "analysis": report}))


if __name__ == "__main__":
    main()
