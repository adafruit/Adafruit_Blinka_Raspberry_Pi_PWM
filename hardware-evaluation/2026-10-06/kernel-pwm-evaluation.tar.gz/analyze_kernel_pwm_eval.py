"""Offline checks for the Pi 5 hardware/kernel-pwm-gpio bench capture.

GPIO18 is Saleae channel 0 (50 Hz, duty 4915); GPIO23 is channel 1
(500 Hz, duty 32768). This script never connects to the Pi or Saleae.
Endpoint phases are checked from physical edges, not by aligning the Pi's
monotonic timestamps with the analyzer clock. No timebase calibration is made.
"""

import argparse
import json
import math
import struct
from pathlib import Path

from capture_pwm import read_digital, summarize

SAMPLE_RATE_HZ = 10_000_000
ENDPOINT_SAMPLE_RATES_HZ = (SAMPLE_RATE_HZ, 100_000_000)
OUTPUTS = (
    {"gpio": 18, "saleae_channel": 0, "frequency": 50, "duty": 4915},
    {"gpio": 23, "saleae_channel": 1, "frequency": 500, "duty": 32768},
)
ENDPOINT_DUTIES = (
    {"18": 0, "23": 0},
    {"18": 65535, "23": 0},
    {"18": 0, "23": 0},
    {"18": 0, "23": 65535},
    {"18": 0, "23": 0},
    {"18": 65535, "23": 65535},
    {"18": 0, "23": 0},
)
ENDPOINT_SPAN_BOUNDS_SECONDS = (0.15, 0.35)


def require(condition, message):
    """Keep validation active even when Python runs with optimizations."""
    if not condition:
        raise ValueError(message)


def validate_metadata(metadata, remote):
    """Validate requested phase states without correlating different clocks."""
    require(
        isinstance(metadata, dict) and isinstance(remote, dict),
        "Capture and remote metadata must be JSON objects",
    )
    require(
        metadata.get("remote") == remote,
        "remote.stdout disagrees with results.json remote metadata",
    )
    mode = metadata.get("mode")
    require(mode in ("endpoints", "idle", "loaded"), "Unknown capture mode")
    require(remote.get("mode") == mode, "Remote mode disagrees with capture mode")
    require(
        metadata.get("host") == "test-pi5.local", "Expected the authorized Pi 5 bench"
    )
    allowed_rates = (
        ENDPOINT_SAMPLE_RATES_HZ if mode == "endpoints" else (SAMPLE_RATE_HZ,)
    )
    require(
        metadata.get("sample_rate_hz") in allowed_rates,
        "Endpoints require 10 or 100 MSa/s; idle/loaded require 10 MSa/s",
    )
    specs = metadata.get("outputs")
    require(
        isinstance(specs, list) and len(specs) == 2,
        "Expected two output specifications",
    )
    require(
        all(isinstance(spec, dict) for spec in specs), "Invalid output specification"
    )
    for actual, expected in zip(specs, OUTPUTS):
        require(
            all(actual.get(key) == value for key, value in expected.items()),
            "Output GPIO/channel/frequency/duty mapping does not match this bench",
        )
    require(
        remote.get("sysfs_released") is True,
        "Remote metadata does not confirm sysfs release; this is not physical low proof",
    )
    burner_pids = remote.get("burner_pids")
    require(
        isinstance(burner_pids, list)
        and all(type(pid) is int and pid > 0 for pid in burner_pids)
        and len(set(burner_pids)) == len(burner_pids)
        and len(burner_pids) == (4 if mode == "loaded" else 0),
        "Mode requires four distinct load worker PIDs only for loaded captures",
    )
    phases = remote.get("phases")
    expected_duties = (
        ENDPOINT_DUTIES
        if mode == "endpoints"
        else (
            {"18": 0, "23": 0},
            {"18": 4915, "23": 32768},
            {"18": 0, "23": 0},
        )
    )
    require(
        isinstance(phases, list) and len(phases) == len(expected_duties),
        "Metadata does not describe the expected phase sequence",
    )
    previous_end = None
    for index, (phase, duties) in enumerate(zip(phases, expected_duties)):
        require(
            isinstance(phase, dict) and phase.get("duties") == duties,
            f"Phase {index} has unexpected endpoint/active duties",
        )
        duration = phase.get("duration_seconds")
        require(
            type(duration) in (int, float) and math.isfinite(duration) and duration > 0,
            f"Phase {index} has no valid requested duration",
        )
        if mode == "endpoints" or index != 1:
            require(
                math.isclose(duration, 0.2, rel_tol=0, abs_tol=1e-9),
                f"Phase {index} should request a 0.2 s static hold",
            )
        else:
            expected_duration = 3.0 if mode == "idle" else 20.0
            require(
                math.isclose(duration, expected_duration, rel_tol=0, abs_tol=1e-9),
                f"{mode} mode should request {expected_duration:g} s of PWM",
            )
        begin, end = phase.get("begin_ns"), phase.get("end_ns")
        require(
            type(begin) is int and type(end) is int and 0 <= begin < end,
            f"Phase {index} has invalid remote monotonic timestamps",
        )
        require(
            previous_end is None or previous_end <= begin,
            "Remote phase intervals are out of order",
        )
        previous_end = end
    return mode


def read_continuous(path, expected_sample_rate):
    """Reuse the existing parser and reject gaps or mismatched sample rates."""
    try:
        version, chunks = read_digital(path)
    except (AssertionError, EOFError, OSError, ValueError, struct.error) as error:
        raise ValueError(f"Invalid digital export {path.name}: {error}") from error
    require(len(chunks) == 1, f"{path.name} requires one continuous capture chunk")
    initial, begin, end, sample_rate, edges = chunks[0]
    require(
        math.isfinite(begin) and math.isfinite(end) and begin < end,
        f"{path.name} has invalid capture bounds",
    )
    if sample_rate is not None:
        require(
            sample_rate == expected_sample_rate,
            f"{path.name} sample rate does not match metadata ({expected_sample_rate:g} Sa/s)",
        )
    final = initial ^ (len(edges) % 2)
    quiet_tail = end - edges[-1] if edges else end - begin
    require(initial == 0, f"{path.name} did not start low")
    require(final == 0, f"{path.name} did not finish low")
    require(quiet_tail >= 0.1, f"{path.name} lacks a stable low tail of at least 0.1 s")
    return {
        "binary_format_version": version,
        "chunks": len(chunks),
        "header_sample_rate_hz": sample_rate,
        "begin_seconds": begin,
        "end_seconds": end,
        "initial_state": initial,
        "final_state": final,
        "quiet_tail_seconds": quiet_tail,
        "edge_count": len(edges),
    }, edges


def validate_endpoints(waveforms):
    """Check the ordered 00,10,00,01,00,11,00 pattern from Saleae edges."""
    lower, upper = ENDPOINT_SPAN_BOUNDS_SECONDS
    spans = []
    for spec, (waveform, edges) in zip(OUTPUTS, waveforms):
        require(
            len(edges) == 4,
            f"GPIO{spec['gpio']} requires exactly four endpoint transitions; extra toggles rejected",
        )
        highs = [(edges[index], edges[index + 1]) for index in (0, 2)]
        require(
            all(lower <= fall - rise <= upper for rise, fall in highs),
            f"GPIO{spec['gpio']} static high holds are not within 0.15–0.35 s",
        )
        waveform["transition_seconds"] = list(edges)
        waveform["high_spans_seconds"] = [fall - rise for rise, fall in highs]
        spans.append(highs)
    (first18, both18), (first23, both23) = spans
    # The first high on each pin must leave the other pin entirely low. Exact
    # edge count plus ordering proves this without using remote phase times.
    gap_between_independent = first23[0] - first18[1]
    gap_before_both = min(both18[0], both23[0]) - first23[1]
    require(
        lower <= gap_between_independent <= upper,
        "Independent GPIO18-high then GPIO23-high phases lack the expected low gap",
    )
    require(
        lower <= gap_before_both <= upper,
        "GPIO23-only high must finish before the both-high phase, with a low gap",
    )
    overlap = min(both18[1], both23[1]) - max(both18[0], both23[0])
    require(
        lower <= overlap <= upper,
        "The second high spans do not show the expected static both-high overlap",
    )
    return {
        "physical_sequence_validated": True,
        "sequence_gpio18_gpio23": ["00", "10", "00", "01", "00", "11", "00"],
        "high_hold_bounds_seconds": [lower, upper],
        "independent_low_gap_seconds": gap_between_independent,
        "low_gap_before_both_high_seconds": gap_before_both,
        "both_high_overlap_seconds": overlap,
        "phase_alignment_proven": False,
        "scope": "Static endpoint levels and independent pins only; overlap is not PWM phase alignment.",
    }


def analyze(directory):
    """Return validated offline analysis without changing any capture artifact."""
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    remote = json.loads((directory / "remote.stdout").read_text())
    mode = validate_metadata(metadata, remote)
    sample_rate = metadata["sample_rate_hz"]
    require(
        (directory / "waveform.sal").is_file(), "Missing saved waveform.sal capture"
    )
    waveforms = [
        read_continuous(
            directory / f"digital_{spec['saleae_channel']}.bin", sample_rate
        )
        for spec in OUTPUTS
    ]
    common_begin = max(waveform["begin_seconds"] for waveform, _ in waveforms)
    common_end = min(waveform["end_seconds"] for waveform, _ in waveforms)
    require(common_begin < common_end, "Channels have no common observation interval")
    require(
        all(
            common_begin <= edge <= common_end
            for _, edges in waveforms
            for edge in edges
        ),
        "Both channels must cover the full edge sequence to establish independent levels",
    )
    common_last_edge = max(
        (edge for _, edges in waveforms for edge in edges), default=common_begin
    )
    require(
        common_end - common_last_edge >= 0.1,
        "Channels lack a common stable final low tail of at least 0.1 s",
    )
    result = {
        "capture": directory.name,
        "mode": mode,
        "host": metadata["host"],
        "offline_analysis": True,
        "sysfs_released_reported": True,
        "burner_pids": remote["burner_pids"],
        "sample_rate_hz": sample_rate,
        "common_observation_interval_seconds": [common_begin, common_end],
        "quantization": {
            "nominal_sample_interval_us": 1e6 / sample_rate,
            "timebase_calibrated": False,
            "note": "Sampling quantization is not a bound on analyzer clock accuracy.",
        },
        "clock_alignment": "Saleae timestamps are not aligned to remote monotonic timestamps.",
        "outputs": [],
    }
    if mode == "endpoints":
        result["endpoints"] = validate_endpoints(waveforms)
    for spec, (waveform, _) in zip(OUTPUTS, waveforms):
        output = {**spec, "waveform": waveform}
        if mode != "endpoints":
            try:
                timing = summarize(
                    directory / f"digital_{spec['saleae_channel']}.bin",
                    spec["frequency"],
                    spec["duty"],
                    "kernel",
                )
            except AssertionError as error:
                raise ValueError(
                    f"GPIO{spec['gpio']} PWM analysis rejected: {error}"
                ) from error
            # summarize's omission estimate is specific to the draft scheduler.
            timing["estimated_omitted_cycles"] = None
            timing["omitted_cycle_estimation_note"] = (
                "Not inferred for kernel/hardware PWM."
            )
            output["timing"] = timing
        result["outputs"].append(output)
    return result


def write_analysis(directory, output_name="analysis.json"):
    """Analyze and exclusively create one new file inside the capture folder."""
    require(
        bool(output_name)
        and Path(output_name).name == output_name
        and output_name not in (".", ".."),
        "Output must be a filename in the capture directory",
    )
    result = analyze(directory)
    with (Path(directory) / output_name).open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output-name", default="analysis.json")
    args = parser.parse_args()
    try:
        result = write_analysis(args.directory, args.output_name)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
