"""Offline original-lgpio update characterization, without a parity verdict.

Every captured threshold edge is retained. Width bins describe these fixed
protocols, not acceptance thresholds. Pi call clocks are not aligned to Saleae.
Integer-percent quantization in the unchanged original is reported explicitly.
"""

import argparse
import itertools
import json
from pathlib import Path

from analyze_kernel_pwm_inverse import read_continuous, require, validate_saved_capture
from capture_pwm import describe

WIDTH_BINS = {
    "servo50_rounded8pct": 1600.0,
    "half500_rounded50pct": 1000.0,
    "half50_rounded50pct": 10000.0,
}


def width_bin(width_us):
    if width_us >= 100000:
        return "constant_high"
    for name, nominal in WIDTH_BINS.items():
        if 0.98 * nominal <= width_us <= 1.02 * nominal:
            return name
    return "unmatched_high_run"


def waveform_facts(waveform, edges):
    require(len(edges) % 2 == 0, "Low-start/end trace must contain complete high runs")
    highs = [
        {
            "pair_index": index,
            "rise_seconds": rise,
            "fall_seconds": fall,
            "width_us": (fall - rise) * 1e6,
            "width_bin": width_bin((fall - rise) * 1e6),
        }
        for index, (rise, fall) in enumerate(zip(edges[::2], edges[1::2]))
    ]
    lows = [
        {"fall_seconds": fall, "rise_seconds": rise, "width_ns": (rise - fall) * 1e9}
        for fall, rise in zip(edges[1::2], edges[2::2])
    ]
    groups = []
    for label, values in itertools.groupby(highs, key=lambda item: item["width_bin"]):
        values = list(values)
        periods = [
            (second["rise_seconds"] - first["rise_seconds"]) * 1e6
            for first, second in itertools.pairwise(values)
        ]
        groups.append(
            {
                "width_bin": label,
                "high_count": len(values),
                "first_pair_index": values[0]["pair_index"],
                "last_pair_index": values[-1]["pair_index"],
                "first_rise_seconds": values[0]["rise_seconds"],
                "last_fall_seconds": values[-1]["fall_seconds"],
                "high_us": describe([item["width_us"] for item in values]),
                "rise_to_rise_us": describe(periods) if periods else None,
            }
        )
    boundaries = [
        {
            "from_bin": first["width_bin"],
            "to_bin": second["width_bin"],
            "low_gap_seconds": second["first_rise_seconds"]
            - first["last_fall_seconds"],
            "rise_to_rise_seconds": second["first_rise_seconds"]
            - highs[first["last_pair_index"]]["rise_seconds"],
        }
        for first, second in itertools.pairwise(groups)
    ]
    waveform["transition_seconds"] = list(edges)
    return {
        "all_high_runs": highs,
        "all_interior_low_runs": lows,
        "groups": groups,
        "boundaries": boundaries,
        "constant_high_holds": [
            item for item in highs if item["width_bin"] == "constant_high"
        ],
        "unmatched_high_runs": [
            item for item in highs if item["width_bin"] == "unmatched_high_run"
        ],
        "sub_microsecond_low_runs": [item for item in lows if item["width_ns"] < 1000],
        "width_bins_are_diagnostic_not_acceptance_thresholds": True,
        "ordinary_bin_tolerance_percent": 2,
        "nominal_width_bins_us": WIDTH_BINS.copy(),
        "phase_alignment_proven": False,
        "no_transition_trimming_or_glitch_filtering": True,
    }


def analyze(directory):
    # The collector checks only receipts/provenance; it does not import this
    # analyzer, change pulse predicates, or label collection success as parity.
    from capture_kernel_pwm_lgpio_baseline import read_json, validate_remote

    directory = Path(directory)
    metadata = read_json((directory / "results.json").read_text())
    remote = read_json((directory / "remote.stdout").read_text())
    mode = metadata.get("mode")
    validate_remote(remote, mode)
    require(metadata.get("remote") == remote, "Remote receipt/metadata disagree")
    require(
        metadata.get("backend") == "original-blinka-lgpio"
        and metadata.get("collection_success") is True
        and type(metadata.get("remote_returncode")) is int
        and metadata["remote_returncode"] == 0
        and metadata.get("parity_evaluated") is False
        and "parity_pass" in metadata
        and metadata["parity_pass"] is None
        and "waveform_accepted" in metadata
        and metadata["waveform_accepted"] is None,
        "Expected successful collection without a waveform/parity verdict",
    )
    acquisition = read_json((directory / "acquisition.json").read_text())
    require(
        acquisition.get("mode") == mode
        and acquisition.get("backend") == "original-blinka-lgpio"
        and type(acquisition.get("remote_returncode")) is int
        and acquisition["remote_returncode"] == 0
        and "primary_error" in acquisition
        and acquisition["primary_error"] is None
        and acquisition.get("evidence_errors") == [],
        "Original acquisition failed or reported incomplete evidence",
    )
    require(metadata.get("host") == "test-pi5.local", "Wrong bench host")
    require(
        metadata.get("sample_rate_hz") == 100_000_000, "Wrong requested sample rate"
    )
    require(
        metadata.get("outputs")
        == [{"gpio": 18, "saleae_channel": 0, "backend": "original-blinka-lgpio"}],
        "Wrong baseline output mapping",
    )
    settings = validate_saved_capture(directory / "waveform.sal")
    waveform, edges = read_continuous(directory / "digital_0.bin")
    physical = waveform_facts(waveform, edges)
    setters = [
        {
            "operation": event["operation"],
            "scope": event["scope"],
            "arguments": event["arguments"],
            "begin_ns": event["begin_ns"],
            "end_ns": event["end_ns"],
            "caller_duration_us": (event["end_ns"] - event["begin_ns"]) / 1000,
        }
        for event in remote["events"]
        if event["operation"] in ("PWMOut.frequency", "PWMOut.duty_cycle")
    ]
    return {
        "capture": directory.name,
        "mode": mode,
        "backend": "original-blinka-lgpio",
        "collection_success": True,
        "characterization_only": True,
        "parity_pass": None,
        "saved_capture_settings": settings,
        "waveform": waveform,
        "physical": physical,
        "caller_updates": setters,
        "phase_api_update_durations_us": [
            {
                "name": phase["name"],
                "duration_us": (phase["stable_begin_ns"] - phase["begin_ns"]) / 1000,
            }
            for phase in remote["phases"]
        ],
        "source_sha256": remote["source_sha256"],
        "quantization": {
            "original_pwm_duty_is_rounded_integer_percent": True,
            "logical4915_percent": 100 * 4915 / 65535,
            "logical4915_actual_rounded_percent": 8,
            "nominal_sample_interval_ns": 10,
            "timebase_calibrated": False,
        },
        "clock_alignment": "Pi API timings are not aligned to Saleae; no command-to-edge latency claim.",
        "caller_timing_includes_instrumentation": True,
        "limitation": "Finite unfiltered digital-threshold observation, not analog proof or exclusion of sub-sample glitches. Width grouping does not establish parity or identify command instants.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args(argv)
    report = analyze(args.directory)
    with (args.directory / "analysis.json").open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "edges": report["waveform"]["edge_count"],
                "groups": [
                    (group["width_bin"], group["high_count"])
                    for group in report["physical"]["groups"]
                ],
                "parity_pass": None,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
