"""Pure offline width grouping checks; no hardware or mocked parity verdicts."""

import analyze_kernel_pwm_lgpio_baseline as analysis
import pytest


def test_all_edges_and_unmatched_transients_are_retained():
    edges = [1.0, 1.0014, 1.02, 1.0214, 1.04, 1.04004, 1.042, 1.043, 1.1, 1.4]
    wave = {}
    result = analysis.waveform_facts(wave, edges)
    assert wave["transition_seconds"] == edges
    assert len(result["all_high_runs"]) == 5
    assert len(result["all_interior_low_runs"]) == 4
    assert [item["width_bin"] for item in result["groups"]] == [
        "servo50_rounded7pct",
        "unmatched_high_run",
        "half500_rounded50pct",
        "constant_high",
    ]
    assert result["groups"][0]["high_count"] == 2
    assert result["groups"][0]["rise_to_rise_us"]["mean"] == pytest.approx(20000)
    assert result["unmatched_high_runs"][0]["width_us"] == pytest.approx(40)
    assert result["constant_high_holds"][0]["width_us"] == pytest.approx(300000)
    assert result["width_bins_are_diagnostic_not_acceptance_thresholds"]
    assert not result["phase_alignment_proven"]
    assert "accepted" not in result and "parity_pass" not in result


def test_tiny_low_dip_is_not_merged_out_of_long_high():
    wave = {}
    result = analysis.waveform_facts(wave, [1.0, 1.3, 1.30000001, 1.6])
    assert len(result["constant_high_holds"]) == 2
    assert len(result["sub_microsecond_low_runs"]) == 1
    assert result["sub_microsecond_low_runs"][0]["width_ns"] == pytest.approx(10)


@pytest.mark.parametrize(
    "width,label",
    [
        (1000, "half500_rounded50pct"),
        (1400, "servo50_rounded7pct"),
        (10000, "half50_rounded50pct"),
        (1500, "unmatched_high_run"),
        (100000, "constant_high"),
    ],
)
def test_explicit_bins_account_for_original_integer_percent_rounding(width, label):
    assert analysis.width_bin(width) == label


def test_servo_rounding_is_derived_from_original_formula_not_half_percent_guess():
    assert 100 * 4915 / 65535 < 7.5
    assert analysis.ROUNDED_SERVO_PERCENT == 7
    assert analysis.WIDTH_BINS["servo50_rounded7pct"] == pytest.approx(1400)


def test_odd_edge_trace_rejected_not_truncated():
    with pytest.raises(ValueError, match="complete high runs"):
        analysis.waveform_facts({}, [1, 2, 3])
