"""Fake baseline collection only; no GPIO, SSH, or waveform/parity verdict."""

import copy
import json
import shlex
import subprocess
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_kernel_pwm_lgpio_baseline as bench
import kernel_pwm_lgpio_baseline_eval as helper
import pytest
import test_kernel_pwm_lgpio_baseline_eval as helper_fakes

ROOT = "/tmp/blinka-pwm-oct6.abc123/lgpio-baseline-eval"
environment = helper_fakes.environment


def remote(mode="direct"):
    clock = 1_000_000_000
    phases = []
    for name, duration, frequency, duty in bench.SEQUENCES[mode]:
        begin = clock
        stable = begin + 1_000_000
        end = stable + round(duration * 1_000_000_000)
        clock = end + 1_000
        phases.append(
            {
                "name": name,
                "generation": 1,
                "frequency": frequency,
                "duty_u16": duty,
                "baseline_duty_percent": round(duty / 65535 * 100),
                "duration_seconds": duration,
                "intent": "low"
                if duty == 0
                else "constant_high"
                if duty == 65535
                else "interior_pwm",
                "begin_ns": begin,
                "transition_begin_ns": begin,
                "stable_begin_ns": stable,
                "end_ns": end,
                "readback_end_ns": clock,
                "api_state": {
                    "frequency": frequency,
                    "duty_cycle": duty,
                    "enabled": True,
                },
            }
        )
    return {
        "schema_version": 1,
        "mode": mode,
        "sequence_marker": f"original-lgpio-{mode}-v1",
        "backend": bench.BACKEND,
        "baseline_commit": bench.BASELINE_COMMIT,
        "gpio": 18,
        "helper_pid": 123,
        "begin_ns": 1_000_000_000,
        "end_ns": clock + 100_000_000,
        "source_sha256": dict(bench.SOURCE_HASHES),
        "characterization_only": True,
        "production_backend_unchanged": True,
        "parity_pass": None,
        "api_readbacks_are_not_electrical": True,
        "success": True,
        "completed_normally": True,
        "fresh_claim_accepted": True,
        "gpio18_released": True,
        "chip_closed": True,
        "low_confirmed": True,
        "cleanup_final_readback": {"gpio_level": 0, "tx_busy": 0},
        "cleanup_errors": [],
        "signals_received": [],
        "primary_error": None,
        "identity": {
            "gpio": 18,
            "gpiochip_index": 4,
            "gpiochip": "/dev/gpiochip4",
            "gpiochip_device_number": "254:4",
            "label": "pinctrl-rp1",
            "compatible": ["raspberrypi,rp1-gpio"],
            "kernel_release": "6.12.75+rpt-rpi-2712",
            "model": "Raspberry Pi 5 Model B Rev 1.0",
            "boot_id": "12345678-1234-1234-1234-123456789abc",
            "of_node": "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/gpio@d0000",
        },
        "chip_info": [0, 54, "gpiochip4", "pinctrl-rp1"],
        "preclaim_mode": 0,
        "preclaim_line_info": [0, 18, 0, "GPIO18", ""],
        "lgpio_version": "fake-distro-lgpio",
        "phases": phases,
        "events": [{"operation": "PWMOut.__init__", "status": "ok"}],
        "before": {"temperature_millic": "42000", "throttled": "throttled=0x0"},
        "after": {"temperature_millic": "42500", "throttled": "throttled=0x0"},
    }


def configure(monkeypatch, mode, scenario):
    events = []
    capture = MagicMock()
    capture.__enter__.return_value = capture

    def save(path):
        events.append("save")
        if scenario == "save_error":
            raise OSError("save failed")

    capture.stop.side_effect = lambda: events.append("stop")
    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = lambda _path, **kwargs: events.append(
        ("export", kwargs["digital_channels"])
    )
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=MagicMock(return_value=manager)),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            "/usr/bin/python3",
            ROOT + "/kernel_pwm_lgpio_baseline_eval.py",
            "--mode",
            mode,
        ]
        assert set(kwargs) == {"stdout", "stderr", "check", "text", "timeout"}
        assert (
            kwargs["timeout"] == 30
            and kwargs["check"] is False
            and kwargs["text"] is True
        )
        if scenario in ("timeout", "interrupt"):
            kwargs["stdout"].write("partial receipt")
            kwargs["stderr"].write("partial diagnostic")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            raise KeyboardInterrupt("interrupted")
        data = remote(mode)
        if scenario == "wrong_hash":
            data["source_sha256"]["baseline_pwmout.py"] = "a" * 64
        if scenario == "wrong_schema":
            data["schema_version"] = True
        if scenario == "cleanup_failed":
            data["cleanup_errors"] = ["failed"]
        kwargs["stdout"].write(json.dumps(data))
        return subprocess.CompletedProcess(
            command, 1 if scenario == "helper_failed" else 0
        )

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)

    def sleep(duration):
        events.append(("sleep", duration))
        if duration == 0.5 and scenario == "lead_interrupt":
            raise KeyboardInterrupt("lead interrupted")

    monkeypatch.setattr(bench.time, "sleep", sleep)
    return events, manager, runner


@pytest.mark.parametrize("mode", bench.MODES)
def test_fixed_modes_collect_without_pulse_or_parity_verdict(
    monkeypatch, tmp_path, mode
):
    events, manager, runner = configure(monkeypatch, mode, "success")
    result = bench.capture_test(tmp_path / "capture", ROOT, mode)
    assert events == [
        ("sleep", 0.5),
        "ssh",
        ("sleep", 0.2),
        "stop",
        "save",
        ("export", [0]),
    ]
    manager.start_capture.assert_called_once_with(
        device_id=bench.DEVICE_ID,
        device_configuration={
            "enabled_digital_channels": [0],
            "digital_sample_rate": 100_000_000,
        },
    )
    runner.assert_called_once()
    assert result["collection_success"] is True
    assert (
        result["backend"] == bench.BACKEND
        and result["outputs"][0]["backend"] == bench.BACKEND
    )
    assert (
        result["waveform_accepted"] is None
        and result["parity_pass"] is None
        and result["parity_evaluated"] is False
    )
    assert result["analysis_deferred"] is True and "accepted" not in result
    assert not (tmp_path / "capture" / "analysis.json").exists()
    assert json.loads((tmp_path / "capture" / "results.json").read_text()) == result


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "lead_interrupt",
        "save_error",
        "helper_failed",
        "wrong_hash",
        "wrong_schema",
        "cleanup_failed",
        "simulation",
    ],
)
def test_failure_retention_no_acceptance_claim(monkeypatch, tmp_path, scenario):
    events, _manager, runner = configure(monkeypatch, "direct", scenario)
    output = tmp_path / "capture"
    with pytest.raises((RuntimeError, ValueError)):
        bench.capture_test(output, ROOT, "direct")
    acquisition = json.loads((output / "acquisition.json").read_text())
    if scenario == "simulation":
        runner.assert_not_called()
        assert not events
    else:
        assert "stop" in events and "save" in events and ("export", [0]) in events
        assert ("sleep", 0.2) in events
    if scenario in ("timeout", "interrupt"):
        assert (output / "remote.stdout").read_text() == "partial receipt"
        assert (output / "remote.stderr").read_text() == "partial diagnostic"
        assert acquisition["remote_returncode"] == (
            124 if scenario == "timeout" else None
        )
        assert acquisition["primary_error"]
    if scenario == "lead_interrupt":
        runner.assert_not_called()
        assert (output / "remote.stdout").read_bytes() == b""
    if scenario == "save_error":
        assert acquisition["evidence_errors"] == ["save_capture: OSError: save failed"]
    if scenario in ("wrong_hash", "wrong_schema", "cleanup_failed"):
        result = json.loads((output / "results.json").read_text())
        assert (
            result["collection_success"] is False and result["receipt_validation_error"]
        )
        assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert not (output / "analysis.json").exists()


@pytest.mark.parametrize(
    "root",
    ["/tmp", ROOT + "/../other", ROOT.replace("lgpio-baseline-eval", "guarded-eval")],
)
def test_invalid_root_never_invokes(monkeypatch, tmp_path, root):
    _events, _manager, runner = configure(monkeypatch, "direct", "success")
    with pytest.raises(ValueError, match="isolated"):
        bench.capture_test(tmp_path / "capture", root, "direct")
    assert not (tmp_path / "capture").exists()
    runner.assert_not_called()


def test_exclusive_outputs_never_invoke(monkeypatch, tmp_path):
    _events, _manager, runner = configure(monkeypatch, "direct", "success")
    output = tmp_path / "capture"
    output.mkdir()
    with pytest.raises(FileExistsError):
        bench.capture_test(output, ROOT, "direct")
    runner.assert_not_called()


@pytest.mark.parametrize(
    "tamper",
    [
        "backend",
        "parity",
        "bool_low",
        "gpiochip",
        "hot",
        "flags",
        "signal",
        "chip_info",
        "claimed_mode",
        "claimed_line",
        "foreign_user",
        "device_number",
    ],
)
def test_schema_and_success_gates_only(tamper):
    data = remote()
    if tamper == "backend":
        data["backend"] = "kernel-hardware-rp1"
    elif tamper == "parity":
        data["parity_pass"] = True
    elif tamper == "bool_low":
        data["cleanup_final_readback"]["gpio_level"] = False
    elif tamper == "gpiochip":
        data["identity"]["gpiochip"] = "/dev/gpiochip0"
    elif tamper == "hot":
        data["after"]["temperature_millic"] = "71000"
    elif tamper == "flags":
        data["before"]["throttled"] = "throttled=0x1"
    elif tamper == "signal":
        data["signals_received"] = [15]
    elif tamper == "chip_info":
        data["chip_info"][3] = "pinctrl-bcm2712"
    elif tamper == "claimed_mode":
        data["preclaim_mode"] = 1
    elif tamper == "claimed_line":
        data["preclaim_line_info"][2] = 1
    elif tamper == "foreign_user":
        data["preclaim_line_info"][4] = "foreign"
    else:
        data["identity"]["gpiochip_device_number"] = "bad"
    with pytest.raises(ValueError):
        bench.validate_remote(data, "direct")


def test_identity_index_not_hardcoded_and_no_input_mutation():
    data = remote()
    data["identity"].update(gpiochip_index=7, gpiochip="/dev/gpiochip7")
    untouched = copy.deepcopy(data)
    bench.validate_remote(data, "direct")
    assert data == untouched


@pytest.mark.parametrize(
    "tamper",
    [
        "count",
        "name",
        "generation",
        "duration",
        "frequency",
        "duty",
        "rounded_percent",
        "intent",
        "bool_clock",
        "begin_transition",
        "stable_end",
        "out_of_run",
        "overlap",
        "api_state",
        "bool_api",
    ],
)
def test_exact_fixed_phase_protocol_required(tamper):
    data = remote()
    phase = data["phases"][1]
    if tamper == "count":
        data["phases"].pop()
    elif tamper == "name":
        phase["name"] = "arbitrary"
    elif tamper == "generation":
        phase["generation"] = True
    elif tamper == "duration":
        phase["duration_seconds"] = 0.3
    elif tamper == "frequency":
        phase["frequency"] = 500
    elif tamper == "duty":
        phase["duty_u16"] = 32768
    elif tamper == "rounded_percent":
        phase["baseline_duty_percent"] = 8
    elif tamper == "intent":
        phase["intent"] = "constant_high"
    elif tamper == "bool_clock":
        phase["begin_ns"] = True
    elif tamper == "begin_transition":
        phase["transition_begin_ns"] += 1
    elif tamper == "stable_end":
        phase["stable_begin_ns"] = phase["end_ns"]
    elif tamper == "out_of_run":
        data["end_ns"] = phase["end_ns"]
    elif tamper == "overlap":
        phase["begin_ns"] = phase["transition_begin_ns"] = (
            data["phases"][0]["end_ns"] - 1
        )
    elif tamper == "api_state":
        phase["api_state"]["duty_cycle"] = 32768
    else:
        data["phases"][0]["api_state"]["duty_cycle"] = False
    with pytest.raises(ValueError):
        bench.validate_remote(data, "direct")


def test_validator_rejects_unapproved_mode():
    data = remote()
    data["mode"] = "lifecycle"
    data["sequence_marker"] = "original-lgpio-lifecycle-v1"
    with pytest.raises(ValueError, match="Unsupported"):
        bench.validate_remote(data, "lifecycle")


@pytest.mark.parametrize("mode", bench.MODES)
def test_actual_fake_helper_receipt_matches_collector(environment, mode):
    receipt = helper.experiment(mode)
    bench.validate_remote(receipt, mode)
    assert receipt["source_sha256"] == bench.SOURCE_HASHES


@pytest.mark.parametrize(
    "text", ['{"schema_version":1,"schema_version":1}', '{"value":NaN}', "[]"]
)
def test_malformed_json_rejected(text):
    with pytest.raises(ValueError):
        bench.read_json(text)
