"""Bounded Pi5 diagnostic of unchanged native scheduling with traced syscalls.

Only the confirmed GPIO18/channel0 and GPIO23/channel1 bench is supported.
Instrumentation perturbs timing; this is not a production performance benchmark.
"""

import argparse
import json
import re
import shlex
import subprocess
from pathlib import Path

from saleae import automation

from capture_pwm import BENCH_ROOTS, DEVICE_ID, remote_code, summarize


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--shared", action="store_true")
    parser.add_argument("--duration", type=float, default=20)
    parser.add_argument("--load-workers", type=int, default=4)
    args = parser.parse_args()
    if not re.fullmatch(r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}", args.remote_root):
        raise ValueError("Expected the fresh isolated October 6 bench directory")
    if not 2 <= args.duration <= 20 or not 0 <= args.load_workers <= 4:
        raise ValueError("Capture is bounded to 2..20 seconds and 0..4 burners")
    host = "test-pi5.local"
    BENCH_ROOTS[host] = args.remote_root
    output = args.directory.resolve()
    output.mkdir(parents=True, exist_ok=False)
    if not re.fullmatch(r"[A-Za-z0-9_-]+", output.name):
        raise ValueError("Use a simple unambiguous capture directory name")
    remote_trace = f"{args.remote_root}/{output.name}.csv"
    source_path = f"{args.remote_root}/trace-source/src"
    specs = [{"gpio": 18, "frequency": 50, "duty": 4915},
             {"gpio": 23, "frequency": 500, "duty": 32768}]
    code = remote_code(50, 4915, "draft", duration=args.duration,
                       load_workers=args.load_workers, short_slice=True, gpio=18,
                       output_specs=specs, host=host, shared=args.shared)
    anchor = "from adafruit_blinka_raspberry_pi_pwm import PWMOut, __version__"
    preflight = f"""
os.environ["PWM_TRACE_PATH"] = {remote_trace!r}
sys.path.insert(0, {source_path!r})
{anchor}
from adafruit_blinka_raspberry_pi_pwm import _native
if not Path(_native.__file__).resolve().is_relative_to(Path({source_path!r})):
    raise RuntimeError("Not using the isolated instrumented extension")
trace = ctypes.CDLL(_native.__file__)
trace.pwm_trace_status.restype = ctypes.c_int
trace_status = trace.pwm_trace_status()
if trace_status:
    raise OSError(trace_status, "Trace preflight failed before requesting any GPIO")
"""
    assert code.count(anchor) == 1
    code = code.replace(anchor, preflight)
    command = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8", f"pi@{host}",
               f"{args.remote_root}/venv/bin/python -c {shlex.quote(code)}"]
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        assert any(d.device_id == DEVICE_ID and not d.is_simulation
                   for d in manager.get_devices())
        configuration = automation.LogicDeviceConfiguration(
            enabled_digital_channels=[0, 1], digital_sample_rate=10_000_000)
        with manager.start_capture(device_id=DEVICE_ID,
                                   device_configuration=configuration) as capture:
            try:
                remote = subprocess.run(command, capture_output=True, text=True,
                                        timeout=args.duration + 20)
            finally:
                capture.stop()
                capture.save_capture(str(output / "waveform.sal"))
                capture.export_raw_data_binary(str(output), digital_channels=[0, 1])
        (output / "remote.stdout").write_text(remote.stdout)
        (output / "remote.stderr").write_text(remote.stderr)
        assert remote.returncode == 0, remote.stderr
        footer = re.search(r"PWM_TRACE attempted=(\d+) written=(\d+) dropped=(\d+) "
                           r"init_error=(\d+) io_error=(\d+) clock_error=(\d+)", remote.stderr)
        assert footer, "Missing exit-time trace footer"
        attempted, written, dropped, init_error, io_error, clock_error = map(int, footer.groups())
        assert attempted == written and not (dropped or init_error or io_error or clock_error)
        subprocess.run(["scp", "-q", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8",
                        f"pi@{host}:{remote_trace}", str(output / "trace.csv")],
                       check=True, timeout=20)
        result = {"host": host, "backend": "instrumented-draft",
                  "production_commit": "d5debaf0e5caafa1fdf5a7619e1ae2e8cd41f1f4",
                  "output_duration_seconds": args.duration,
                  "sample_rate_hz": 10_000_000,
                  "logic_version": manager.get_app_info().app_version,
                  "trace": {"attempted": attempted, "written": written,
                            "dropped": dropped},
                  "instrumentation_is_not_a_performance_benchmark": True,
                  "remote": json.loads(remote.stdout), "outputs": []}
        for channel, spec in enumerate(specs):
            result["outputs"].append({**spec, "saleae_channel": channel,
                "timing": summarize(output / f"digital_{channel}.bin",
                                    spec["frequency"], spec["duty"], "draft")})
        (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
        assert result["remote"]["thermal_acceptance"]["valid"], "Thermally rejected"
        for item in result["outputs"]:
            assert item["timing"]["final_state"] == 0
            assert item["timing"]["quiet_tail_seconds"] >= 0.1
        print(json.dumps({"capture": output.name, "shared": args.shared,
                          "trace_records": written,
                          "temperature_after_millic": result["remote"]["system_after"]["temperature_millic"],
                          "outputs": [{"gpio": o["gpio"],
                              "high_max_us": o["timing"]["high_us"]["max"],
                              "max_period_us": o["timing"]["period_us"]["max"]}
                              for o in result["outputs"]]}))


if __name__ == "__main__":
    main()
