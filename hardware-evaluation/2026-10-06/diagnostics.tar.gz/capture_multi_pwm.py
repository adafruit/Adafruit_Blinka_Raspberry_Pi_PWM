"""Bounded two-output measurements on GPIO18/channel0 and GPIO23/channel1.

Shares the single-output harness's backend, thermal gates, cleanup, and parser.
The Pi 4 bench has a heatsink and a direct 5V fan, not a GPIO18 Fan SHIM.
"""

import argparse
import json
import shlex
import subprocess
from pathlib import Path

from saleae import automation

from capture_pwm import BENCH_ROOTS, DEVICE_ID, remote_code, summarize


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--frequency18", type=int, default=500)
    parser.add_argument("--frequency23", type=int, default=500)
    parser.add_argument("--duty18", type=int, default=32768)
    parser.add_argument("--duty23", type=int, default=32768)
    parser.add_argument("--duration", type=float, default=20)
    parser.add_argument("--load-workers", type=int, default=4)
    parser.add_argument("--backend", choices=("draft", "rpi_gpio", "lgpio"), default="draft")
    parser.add_argument("--host", choices=tuple(BENCH_ROOTS), default="test2-pi4.local")
    parser.add_argument("--short-slice", action="store_true")
    parser.add_argument("--shared", action="store_true")
    parser.add_argument("--retire-first", action="store_true",
                        help="Deinit GPIO18 halfway through while GPIO23 continues")
    args = parser.parse_args()
    assert 2 <= args.duration <= 30 and 0 <= args.load_workers <= 4
    assert not args.short_slice or args.backend == "draft"
    assert not args.shared or args.backend == "draft"
    specs = [{"gpio": 18, "frequency": args.frequency18, "duty": args.duty18},
             {"gpio": 23, "frequency": args.frequency23, "duty": args.duty23}]
    code = remote_code(args.frequency18, args.duty18, args.backend,
                       duration=args.duration, load_workers=args.load_workers,
                       short_slice=args.short_slice, gpio=18, output_specs=specs,
                       retire_first=args.retire_first, host=args.host, shared=args.shared)
    output = args.directory.resolve()
    output.mkdir(parents=True, exist_ok=False)
    command = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8",
               f"pi@{args.host}",
               f"{BENCH_ROOTS[args.host]}/venv/bin/python -c {shlex.quote(code)}"]
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        assert any(d.device_id == DEVICE_ID and not d.is_simulation
                   for d in manager.get_devices())
        configuration = automation.LogicDeviceConfiguration(
            enabled_digital_channels=[0, 1], digital_sample_rate=10_000_000)
        with manager.start_capture(device_id=DEVICE_ID,
                                   device_configuration=configuration) as capture:
            try:
                remote = subprocess.run(command, capture_output=True, text=True,
                                        timeout=args.duration + 20)
            finally:
                capture.stop()
                capture.save_capture(str(output / "waveform.sal"))
                capture.export_raw_data_binary(str(output), digital_channels=[0, 1])
        (output / "remote.stdout").write_text(remote.stdout)
        (output / "remote.stderr").write_text(remote.stderr)
        assert remote.returncode == 0, remote.stderr
        result = {"host": args.host, "backend": args.backend,
                  "output_duration_seconds": args.duration,
                  "retire_first": args.retire_first,
                  "sample_rate_hz": 10_000_000,
                  "logic_version": manager.get_app_info().app_version,
                  "remote": json.loads(remote.stdout), "outputs": []}
        for channel, spec in enumerate(specs):
            result["outputs"].append({**spec, "saleae_channel": channel,
                "timing": summarize(output / f"digital_{channel}.bin",
                                    spec["frequency"], spec["duty"], args.backend)})
        (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
        assert result["remote"]["thermal_acceptance"]["valid"], "Thermally rejected; capture saved"
        if args.retire_first:
            first, second = [o["timing"] for o in result["outputs"]]
            assert first["quiet_tail_seconds"] > args.duration / 2 - 0.1
            assert second["quiet_tail_seconds"] < first["quiet_tail_seconds"] - args.duration / 3
        active = result["remote"]["active_interval"]
        print(json.dumps({"capture": output.name, "backend": args.backend,
            "short_slice": args.short_slice, "shared": args.shared,
            "retire_first": args.retire_first,
            "temperature_after_millic": result["remote"]["system_after"]["temperature_millic"],
            "throttled_after": result["remote"]["system_after"]["throttled"],
            "slices_ns": [t["slice_ns"] for t in result["remote"]["thread_settings"]],
            "cpu_percent_one_core": 100 * (active["cpu_user_seconds"] + active["cpu_system_seconds"]) / active["elapsed_seconds"],
            "outputs": [{"gpio": o["gpio"], "mean_hz": o["timing"]["mean_frequency_hz"],
                "gaps": o["timing"]["long_gaps_over_150_percent_median"],
                "max_period_us": o["timing"]["period_us"]["max"],
                "high_min_us": o["timing"]["high_us"]["min"],
                "high_max_us": o["timing"]["high_us"]["max"],
                "final_state": o["timing"]["final_state"]} for o in result["outputs"]]}))


if __name__ == "__main__":
    main()
