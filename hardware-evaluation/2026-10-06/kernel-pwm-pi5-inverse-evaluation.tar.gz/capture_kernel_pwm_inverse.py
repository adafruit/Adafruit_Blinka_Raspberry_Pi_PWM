"""Bounded Pi 5 RP1 inverse-zero endpoint diagnostic on GPIO18/channel0.

No sudo, overlay changes, PIO, kernel patches or production backend changes.
The isolated helper restores normal-polarity low before releasing its export.
Providers remain loaded until reboot; this script must never remove them.
"""

import argparse
import json
import re
import shlex
import subprocess
from pathlib import Path

from saleae import automation

from analyze_kernel_pwm_inverse import write_analysis
from capture_pwm import DEVICE_ID

MODE = "inverse-endpoints"
SAMPLE_RATE_HZ = 100_000_000


def decoded(value):
    return value.decode(errors="replace") if isinstance(value, bytes) else value or ""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    args = parser.parse_args()
    if not re.fullmatch(
        r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/inverse-eval", args.remote_root
    ):
        raise ValueError("Requires the isolated Pi 5 inverse diagnostic directory")
    output = args.directory.resolve()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", output.name):
        raise ValueError("Use a simple capture directory name")
    output.mkdir(parents=True, exist_ok=False)
    invocation = shlex.join(
        ["/usr/bin/python3", args.remote_root + "/kernel_pwm_inverse_eval.py"]
    )
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        invocation,
    ]
    # Analyzer availability is checked before anything can drive GPIO18.
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        if not any(
            device.device_id == DEVICE_ID and not device.is_simulation
            for device in manager.get_devices()
        ):
            raise RuntimeError("Confirmed analyzer is not available")
        config = automation.LogicDeviceConfiguration(
            enabled_digital_channels=[0], digital_sample_rate=SAMPLE_RATE_HZ
        )
        with manager.start_capture(
            device_id=DEVICE_ID, device_configuration=config
        ) as capture:
            try:
                remote = subprocess.run(
                    command, capture_output=True, text=True, check=False, timeout=30
                )
            except subprocess.TimeoutExpired as exc:
                remote = subprocess.CompletedProcess(
                    command,
                    124,
                    decoded(exc.stdout),
                    decoded(exc.stderr) + "\nSSH timeout",
                )
            finally:
                capture.stop()
                capture.save_capture(str(output / "waveform.sal"))
                capture.export_raw_data_binary(str(output), digital_channels=[0])
        (output / "remote.stdout").write_text(remote.stdout)
        (output / "remote.stderr").write_text(remote.stderr)
        if remote.returncode:
            raise RuntimeError(
                f"Capture saved; helper failed ({remote.returncode}): {remote.stderr}"
            )
        remote_data = json.loads(remote.stdout)
        if (
            remote_data.get("mode") != MODE
            or remote_data.get("sysfs_released") is not True
            or remote_data.get("low_confirmed") is not True
            or remote_data.get("cleanup_errors") != []
        ):
            raise RuntimeError("Helper did not confirm expected mode and low cleanup")
        result = {
            "host": "test-pi5.local",
            "mode": MODE,
            "sample_rate_hz": SAMPLE_RATE_HZ,
            "logic_version": manager.get_app_info().app_version,
            "providers_left_loaded_until_reboot": True,
            "production_backend_unchanged": True,
            "outputs": [
                {
                    "gpio": 18,
                    "saleae_channel": 0,
                    "frequency": 50,
                    "duty": 4915,
                    "backend": "kernel-hardware-rp1",
                }
            ],
            "remote": remote_data,
        }
        with (output / "results.json").open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
    report = write_analysis(output, "analysis.json")
    print(json.dumps({"capture": output.name, "mode": MODE, "analysis": report}))


if __name__ == "__main__":
    main()
