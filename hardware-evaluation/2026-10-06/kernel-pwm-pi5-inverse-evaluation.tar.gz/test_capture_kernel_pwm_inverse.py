"""Fake capture orchestration only: no SSH, Saleae, or physical GPIO."""

import json
import shlex
import subprocess
import sys
from types import SimpleNamespace

import pytest

import capture_kernel_pwm_inverse as bench


@pytest.mark.parametrize(
    "scenario",
    [
        "success",
        "helper_failure",
        "timeout",
        "bad_cleanup",
        "not_low",
        "cleanup_errors",
        "wrong_mode",
        "missing_device",
        "simulated_device",
    ],
)
def test_capture_lifecycle(monkeypatch, tmp_path, scenario):
    events = []

    class Capture:
        def __enter__(self):
            events.append("capture")
            return self

        def __exit__(self, *_args):
            events.append("capture_closed")

        def stop(self):
            events.append("stop")

        def save_capture(self, path):
            events.append("save")
            assert path.endswith("/waveform.sal")

        def export_raw_data_binary(self, path, *, digital_channels):
            events.append("export")
            assert digital_channels == [0]

    class Manager:
        def __enter__(self):
            events.append("manager")
            return self

        def __exit__(self, *_args):
            events.append("manager_closed")

        def get_devices(self):
            if scenario == "missing_device":
                return []
            return [
                SimpleNamespace(
                    device_id=bench.DEVICE_ID,
                    is_simulation=scenario == "simulated_device",
                )
            ]

        def start_capture(self, *, device_id, device_configuration):
            assert device_id == bench.DEVICE_ID
            assert device_configuration == {
                "enabled_digital_channels": [0],
                "digital_sample_rate": 100_000_000,
            }
            return Capture()

        def get_app_info(self):
            return SimpleNamespace(app_version="fake")

    def connect(*, port, connect_timeout_seconds):
        assert port == 10430 and connect_timeout_seconds == 5
        return Manager()

    def run(command, *, capture_output, text, check, timeout):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            "/usr/bin/python3",
            "/tmp/blinka-pwm-oct6.abc123/inverse-eval/kernel_pwm_inverse_eval.py",
        ]
        assert capture_output and text and not check and timeout == 30
        if scenario == "timeout":
            raise subprocess.TimeoutExpired(
                command, timeout, output=b"partial", stderr=b"error"
            )
        return subprocess.CompletedProcess(
            command,
            int(scenario == "helper_failure"),
            json.dumps(
                {
                    "mode": "wrong" if scenario == "wrong_mode" else bench.MODE,
                    "sysfs_released": scenario != "bad_cleanup",
                    "low_confirmed": scenario != "not_low",
                    "cleanup_errors": ["failed"]
                    if scenario == "cleanup_errors"
                    else [],
                }
            ),
            "",
        )

    def analyze(directory, name):
        events.append("analysis")
        assert name == "analysis.json"
        result = json.loads((directory / "results.json").read_text())
        assert result["outputs"] == [
            {
                "gpio": 18,
                "saleae_channel": 0,
                "frequency": 50,
                "duty": 4915,
                "backend": "kernel-hardware-rp1",
            }
        ]
        return {"ok": True}

    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connect),
            LogicDeviceConfiguration=lambda **kw: kw,
        ),
    )
    monkeypatch.setattr(bench.subprocess, "run", run)
    monkeypatch.setattr(bench, "write_analysis", analyze)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_inverse.py",
            str(tmp_path / "capture"),
            "--remote-root",
            "/tmp/blinka-pwm-oct6.abc123/inverse-eval",
        ],
    )
    if scenario == "success":
        bench.main()
        assert events == [
            "manager",
            "capture",
            "ssh",
            "stop",
            "save",
            "export",
            "capture_closed",
            "manager_closed",
            "analysis",
        ]
    else:
        with pytest.raises(RuntimeError):
            bench.main()
        if scenario in ("missing_device", "simulated_device"):
            assert events == ["manager", "manager_closed"]
        else:
            assert events == [
                "manager",
                "capture",
                "ssh",
                "stop",
                "save",
                "export",
                "capture_closed",
                "manager_closed",
            ]
            assert (tmp_path / "capture" / "remote.stdout").is_file()
            assert (tmp_path / "capture" / "remote.stderr").is_file()


@pytest.mark.parametrize(
    "remote_root",
    [
        "",
        "/tmp/",
        "/tmp/blinka-pwm-oct6.abc123",
        "/tmp/blinka-pwm-oct6.abc123/inverse-eval/../elsewhere",
    ],
)
def test_reject_unapproved_directory(monkeypatch, tmp_path, remote_root):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_inverse.py",
            str(tmp_path / "capture"),
            "--remote-root",
            remote_root,
        ],
    )
    with pytest.raises(ValueError, match="isolated Pi 5"):
        bench.main()
    assert not (tmp_path / "capture").exists()
