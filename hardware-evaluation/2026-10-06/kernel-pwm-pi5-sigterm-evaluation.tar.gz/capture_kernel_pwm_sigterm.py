"""Capture only the fixed lab self-SIGTERM-high test; preserve failure evidence."""

import argparse
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

from saleae import automation

from analyze_kernel_pwm_sigterm import (
    MODE,
    OUTPUT_MAPPING,
    RETURN_SEMANTICS,
    SEQUENCE_MARKER,
    STRATEGY,
    read_json,
    validate_metadata,
    write_analysis,
)
from capture_pwm import DEVICE_ID


def _write(output, name, value):
    with (output / name).open("x") as stream:
        stream.write(value)


def capture_test(directory, remote_root):
    if not re.fullmatch(
        r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/sigterm-eval", remote_root
    ):
        raise ValueError("Requires the isolated Pi 5 sigterm-eval directory")
    output = Path(directory).resolve()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", output.name):
        raise ValueError("Use a simple capture directory name")
    output.mkdir(parents=True, exist_ok=False)
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(
            [
                "/usr/bin/python3",
                remote_root + "/kernel_pwm_sigterm_eval.py",
                "--mode",
                MODE,
            ]
        ),
    ]
    remote = None
    primary, evidence_errors, logic_version = None, [], None
    timing = {}
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            if not any(
                device.device_id == DEVICE_ID and not device.is_simulation
                for device in manager.get_devices()
            ):
                raise RuntimeError("Confirmed analyzer is not available")
            logic_version = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[0], digital_sample_rate=100_000_000
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as capture:
                try:
                    timing["lead_begin_ns"] = time.monotonic_ns()
                    time.sleep(0.5)
                    timing["lead_end_ns"] = time.monotonic_ns()
                    # File-backed pipes retain partial SSH output on timeout
                    # or interruption, including bytes unavailable on an
                    # exception from subprocess.run(capture_output=True).
                    with (output / "remote.stdout").open("x") as stdout_file:
                        with (output / "remote.stderr").open("x") as stderr_file:
                            remote = subprocess.run(
                                command,
                                stdout=stdout_file,
                                stderr=stderr_file,
                                text=True,
                                check=False,
                                timeout=30,
                            )
                except subprocess.TimeoutExpired as error:
                    remote = subprocess.CompletedProcess(command, 124)
                    primary = error
                except BaseException as error:
                    primary = error
                    remote = subprocess.CompletedProcess(command, None)
                finally:
                    # A lead interruption can happen before either stream is
                    # opened; preserve explicit empty artifacts in that case.
                    for name in ("remote.stdout", "remote.stderr"):
                        try:
                            if not (output / name).exists():
                                _write(output, name, "")
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
                    for name, action in (
                        ("tail", lambda: time.sleep(1.2)),
                        ("stop", capture.stop),
                        (
                            "save_capture",
                            lambda: capture.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_binary",
                            lambda: capture.export_raw_data_binary(
                                str(output), digital_channels=[0]
                            ),
                        ),
                    ):
                        try:
                            if name == "tail":
                                timing["tail_begin_ns"] = time.monotonic_ns()
                            action()
                            if name == "tail":
                                timing["tail_end_ns"] = time.monotonic_ns()
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:
        if primary is None:
            primary = error
        else:
            evidence_errors.append(f"acquisition: {type(error).__name__}: {error}")
    acquisition = {
        "mode": MODE,
        "remote_root": remote_root,
        "remote_command": command,
        "remote_returncode": None if remote is None else remote.returncode,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 1.2,
        "local_timing_ns": timing,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None
        if primary is None
        else f"{type(primary).__name__}: {primary}",
        "evidence_errors": evidence_errors,
    }
    _write(output, "acquisition.json", json.dumps(acquisition, indent=2) + "\n")
    if primary is not None or evidence_errors:
        raise RuntimeError(
            f"Capture failure evidence retained: {acquisition['primary_error'] or '; '.join(evidence_errors)}"
        ) from primary
    if remote is None or remote.returncode != 0:
        raise RuntimeError("Capture saved; expected-abort helper did not exit0")
    remote_data = read_json((output / "remote.stdout").read_text())
    metadata = {
        "host": "test-pi5.local",
        "mode": MODE,
        "transition_strategy": STRATEGY,
        "sequence_marker": SEQUENCE_MARKER,
        "sample_rate_hz": 100_000_000,
        "logic_version": logic_version,
        "providers_left_loaded_until_reboot": True,
        "production_backend_unchanged": True,
        "outputs": OUTPUT_MAPPING,
        "remote": remote_data,
        "remote_returncode": remote.returncode,
        "expected_abort_observed": remote_data.get("expected_abort_observed"),
        "completed_normally": remote_data.get("completed_normally"),
        "helper_returncode_semantics": RETURN_SEMANTICS,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 1.2,
    }
    _write(output, "results.json", json.dumps(metadata, indent=2) + "\n")
    validate_metadata(metadata, remote_data)
    report = write_analysis(output)
    if report.get("accepted") is not True:
        raise RuntimeError("Rejected raw capture and analysis preserved")
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--mode", choices=(MODE,), default=MODE)
    args = parser.parse_args(argv)
    report = capture_test(args.directory, args.remote_root)
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "mode": MODE,
                "accepted": report["accepted"],
                "edge_count": report.get("waveform", {}).get("edge_count"),
                "expected_abort_observed": True,
                "completed_normally": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
