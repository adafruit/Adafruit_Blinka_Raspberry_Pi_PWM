"""Synthetic signal-helper metadata/waveform audit; never hardware/OS signals."""

import copy
import json

import pytest

import analyze_kernel_pwm_sigterm as analyzer
import test_kernel_pwm_sigterm_eval as helper_fakes
from test_kernel_pwm_inverse_waveforms import binary_export, saved_capture


@pytest.fixture
def metadata(tmp_path, monkeypatch):
    tree = helper_fakes.tree.__wrapped__(tmp_path)
    helper_fakes.configured.__wrapped__(tree, monkeypatch)
    remote = helper_fakes.bench.experiment()
    for output in remote["outputs"]:
        fake_chip = output["chip"]
        output["chip"] = "/sys/class/pwm/pwmchip1"
        output["of_node"] = (
            "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/pwm@98000"
        )
        for event in output["sysfs_events"]:
            if "path" in event:
                event["path"] = event["path"].replace(fake_chip, output["chip"], 1)
    return {
        "mode": analyzer.MODE,
        "host": "test-pi5.local",
        "sample_rate_hz": 100_000_000,
        "transition_strategy": analyzer.STRATEGY,
        "sequence_marker": analyzer.SEQUENCE_MARKER,
        "production_backend_unchanged": True,
        "providers_left_loaded_until_reboot": True,
        "outputs": copy.deepcopy(analyzer.OUTPUT_MAPPING),
        "remote": remote,
        "remote_returncode": 0,
        "helper_returncode_semantics": analyzer.RETURN_SEMANTICS,
        "expected_abort_observed": True,
        "completed_normally": False,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 1.2,
    }


def files(directory, metadata, edges=None, end=2.6):
    (directory / "results.json").write_text(json.dumps(metadata))
    (directory / "remote.stdout").write_text(json.dumps(metadata["remote"]))
    saved_capture(directory / "waveform.sal")
    binary_export(
        directory / "digital_0.bin", [0.84, 1.14] if edges is None else edges, end=end
    )
    return directory


def test_expected_abort_exact_sources_and_frozen_hooks_restored(tmp_path, metadata):
    original = copy.deepcopy(metadata)
    registry, audit = analyzer.base.SEQUENCES, analyzer.base.validate_events
    report = analyzer.analyze(files(tmp_path, metadata))
    assert report["accepted"], report["rejection_reasons"]
    assert report["waveform"]["edge_count"] == 2
    assert report["physical"]["every_edge_seconds"] == [0.84, 1.14]
    assert report["physical"]["high_runs"][0]["width_seconds"] == pytest.approx(0.3)
    assert report["expected_abort_observed"] and not report["completed_normally"]
    assert report["source_sha256_reported"] == analyzer.SOURCE_HASHES
    assert report["post_abort_thermal_independently_validated"]
    assert not report["physical"]["signal_edge_alignment_proven"]
    assert metadata == original
    assert analyzer.base.SEQUENCES is registry
    assert analyzer.base.validate_events is audit


@pytest.mark.parametrize("width_ns", [10, 20, 1000])
def test_dip_edges_never_filtered_and_rejected(tmp_path, metadata, width_ns):
    edges = [0.84, 0.99, 0.99 + width_ns / 1e9, 1.14]
    report = analyzer.write_analysis(files(tmp_path, metadata, edges))
    assert not report["accepted"]
    assert report["physical"]["every_edge_seconds"] == edges
    assert report["physical"]["edge_count"] == 4
    assert report["physical"]["no_transition_trimming_or_glitch_filtering"]
    assert json.loads((tmp_path / "analysis.json").read_text())["accepted"] is False


@pytest.mark.parametrize("width", [0.249, 0.351, 0.4])
def test_short_or_long_high_rejected_actual_width_retained(tmp_path, metadata, width):
    report = analyzer.analyze(files(tmp_path, metadata, [0.84, 0.84 + width]))
    assert not report["accepted"]
    assert report["physical"]["high_runs"][0]["width_seconds"] == pytest.approx(width)


def test_initial_and_final_quiet_coverage_predicates(tmp_path, metadata):
    report = analyzer.analyze(files(tmp_path, metadata, [0.49, 0.79]))
    assert not report["accepted"]
    assert any("Initial low" in value for value in report["rejection_reasons"])
    report = analyzer.analyze(files(tmp_path, metadata, [1.2, 1.5]))
    assert not report["accepted"]
    assert any("Persistent final" in value for value in report["rejection_reasons"])


@pytest.mark.parametrize(
    "target,key,value",
    [
        ("metadata", "completed_normally", True),
        ("remote", "completed_normally", True),
        ("remote", "schema_version", True),
        ("metadata", "expected_abort_observed", False),
        ("remote", "expected_abort_observed", False),
        ("metadata", "remote_returncode", 1),
        ("metadata", "remote_returncode", False),
        ("metadata", "post_helper_tail_seconds", 0.2),
        ("remote", "signals_received", []),
        ("remote", "signals_received", [2]),
        ("remote", "signals_received", [15, 15]),
        ("remote", "outcome", "completed"),
        ("remote", "cleanup_errors", ["failed"]),
        ("remote", "post_abort_thermal_independently_validated", False),
        (
            "remote",
            "expected_abort_exception",
            {"type": "SafetyAbort", "message": "Stopped by SIGINT"},
        ),
    ],
)
def test_wrong_expected_abort_contract_restores_frozen_registry(
    tmp_path, metadata, target, key, value
):
    (metadata if target == "metadata" else metadata["remote"])[key] = value
    registry, audit = analyzer.base.SEQUENCES, analyzer.base.validate_events
    with pytest.raises(ValueError):
        analyzer.analyze(files(tmp_path, metadata))
    assert analyzer.base.SEQUENCES is registry
    assert analyzer.base.validate_events is audit


@pytest.mark.parametrize(
    "key,value",
    [
        ("target_pid", 999999),
        ("helper_pid", 0),
        ("signal_number", 2),
        ("operation", "kill-other"),
        ("guard_depth", 1),
        ("guard_depth", False),
        ("status", "returned_without_abort"),
        ("begin_ns", 1),
        ("end_ns", 10**20),
    ],
)
def test_wrong_self_signal_trigger(tmp_path, metadata, key, value):
    metadata["remote"]["trigger"][key] = value
    with pytest.raises(ValueError):
        analyzer.analyze(files(tmp_path, metadata))


@pytest.mark.parametrize(
    "tamper",
    [
        "hash",
        "missing_hash",
        "fan",
        "borrowed_export",
        "extra_unexport",
        "missing_wait",
        "short_wait",
        "cleanup_before_trigger",
        "cleanup_readback",
        "cleanup_type",
        "path_present",
        "thermal_after_cleanup",
        "thermal_after_abort",
        "phase_state",
    ],
)
def test_exact_ownership_waits_provenance_and_independent_thermal(
    tmp_path, metadata, tamper
):
    remote = metadata["remote"]
    output = remote["outputs"][0]
    if tamper == "hash":
        remote["metadata"]["source_sha256"]["kernel_pwm_sigterm_eval.py"] = "f" * 64
    elif tamper == "missing_hash":
        remote["metadata"]["source_sha256"].pop("kernel_pwm_settled_eval.py")
    elif tamper == "fan":
        output["of_node"] = output["of_node"].replace("pwm@98000", "pwm@9c000")
    elif tamper == "borrowed_export":
        output["sysfs_events"].pop(0)
    elif tamper == "extra_unexport":
        output["sysfs_events"].append(copy.deepcopy(output["sysfs_events"][-1]))
    elif tamper == "missing_wait":
        remote["strategy_waits"] = []
    elif tamper == "short_wait":
        remote["strategy_waits"][0]["end_ns"] -= 1_000_000
    elif tamper == "cleanup_before_trigger":
        remote["trigger"]["end_ns"] = remote["end_ns"]
    elif tamper == "cleanup_readback":
        output["cleanup_final_readback"]["polarity"] = "inversed"
    elif tamper == "cleanup_type":
        output["cleanup_final_readback"]["enable"] = False
    elif tamper == "path_present":
        output["export_path_absent"] = False
    elif tamper == "thermal_after_cleanup":
        remote["thermal"]["after_cleanup"]["temperature_millic"] = "76000"
    elif tamper == "thermal_after_abort":
        remote["thermal"]["after"]["throttled"] = "throttled=0x1"
    else:
        remote["phases"][-1]["end_readbacks"]["18"]["enable"] = 0
    with pytest.raises(ValueError):
        analyzer.analyze(files(tmp_path, metadata))


def test_saved_settings_binary_validators_are_unchanged(tmp_path, metadata):
    files(tmp_path, metadata)
    saved_capture(tmp_path / "waveform.sal", glitch={"enabled": True, "channels": [0]})
    with pytest.raises(ValueError):
        analyzer.analyze(tmp_path)
    saved_capture(tmp_path / "waveform.sal")
    binary_export(tmp_path / "digital_0.bin", [0.84, 1.14], rate=50_000_000, end=2.6)
    with pytest.raises(ValueError):
        analyzer.analyze(tmp_path)


def test_exclusive_writer_and_original_artifacts_preserved(tmp_path, metadata):
    files(tmp_path, metadata)
    originals = {
        path: path.read_bytes() for path in tmp_path.iterdir() if path.is_file()
    }
    analyzer.write_analysis(tmp_path)
    assert all(path.read_bytes() == content for path, content in originals.items())
    with pytest.raises(FileExistsError):
        analyzer.write_analysis(tmp_path)
    with pytest.raises(ValueError):
        analyzer.write_analysis(tmp_path, "../results.json")
