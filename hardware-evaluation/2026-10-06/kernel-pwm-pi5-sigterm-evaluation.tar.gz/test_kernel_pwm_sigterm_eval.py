"""Fake self-signal delivery/sysfs only; no OS signals or hardware actions."""

import hashlib
import importlib.util
import json
import signal
import sys
from pathlib import Path

import pytest

import test_kernel_pwm_settled_eval as settled_fakes

SCRIPT = Path(__file__).with_name("kernel_pwm_sigterm_eval.py")
spec = importlib.util.spec_from_file_location("kernel_pwm_sigterm_eval", SCRIPT)
bench = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = bench
spec.loader.exec_module(bench)
state, core = bench.state, bench.core


@pytest.fixture
def tree(tmp_path):
    return settled_fakes.state_fakes.inverse_fakes.common_fakes.tree.__wrapped__(
        tmp_path
    )


@pytest.fixture
def configured(tree, monkeypatch):
    found, io = settled_fakes.configure_experiment(tree, monkeypatch)
    tick = 80_000_000_000
    handlers, kills, alarms = {}, [], []
    snapshots = [
        {"temperature_millic": "42000", "throttled": "throttled=0x0"} for _ in range(3)
    ]

    def now():
        nonlocal tick
        tick += 1000
        return tick

    def sleep(duration):
        nonlocal tick
        tick += round(duration * 1e9)

    def set_handler(signum, handler):
        prior = handlers.get(signum, signal.SIG_DFL)
        handlers[signum] = handler
        return prior

    def kill(pid, signum):
        kills.append((pid, signum))
        assert pid == bench.os.getpid() and signum == signal.SIGTERM
        assert callable(handlers[signum])
        assert io.read(found[0].channel_path / "polarity") == "inversed"
        assert io.read(found[0].channel_path / "duty_cycle") == "0"
        assert io.read(found[0].channel_path / "enable") == "1"
        handlers[signum](signum, None)

    monkeypatch.setattr(bench.time, "monotonic_ns", now)
    monkeypatch.setattr(bench.time, "sleep", sleep)
    monkeypatch.setattr(bench.signal, "signal", set_handler)
    monkeypatch.setattr(
        bench.signal, "getsignal", lambda signum: handlers.get(signum, signal.SIG_DFL)
    )
    monkeypatch.setattr(
        bench.signal, "alarm", lambda duration: alarms.append(duration) or 0
    )
    monkeypatch.setattr(bench.os, "kill", kill)
    monkeypatch.setattr(core, "system_snapshot", lambda: dict(snapshots.pop(0)))
    return {
        "found": found,
        "io": io,
        "handlers": handlers,
        "kills": kills,
        "alarms": alarms,
        "snapshots": snapshots,
    }


def original_hooks():
    return (
        state.SEQUENCES,
        state.run_phase,
        state.StatePWMChannel,
        core.discover,
        core.system_snapshot,
        core.debug_metadata,
    )


def test_expected_self_sigterm_cleanup_actual_refs_schema_and_restoration(configured):
    originals = original_hooks()
    result = bench.experiment()
    assert original_hooks() == originals
    assert (
        result["mode"] == "sigterm-high"
        and result["sequence_marker"] == "sigterm-high-v1"
    )
    assert result["outcome"] == "expected-sigterm-abort-cleaned"
    assert (
        result["expected_abort_observed"] is True
        and result["completed_normally"] is False
    )
    assert result["signals_received"] == [int(signal.SIGTERM)]
    assert configured["kills"] == [(bench.os.getpid(), signal.SIGTERM)]
    assert configured["snapshots"] == []
    assert all(handler == signal.SIG_DFL for handler in configured["handlers"].values())
    assert configured["alarms"][0] == 14 and configured["alarms"][-1] == 0
    assert [phase["name"] for phase in result["phases"]] == [
        spec[0] for spec in bench.PHASES
    ]
    assert result["phases"][-1]["end_readbacks"] == {
        "18": state.requested_state(50, 65535)
    }
    trigger = result["trigger"]
    assert trigger["target_pid"] == trigger["helper_pid"] == result["helper_pid"]
    assert trigger["operation"] == "os.kill-self" and trigger["guard_depth"] == 0
    assert (
        trigger["status"] == "safety_abort_raised"
        and trigger["exception"] == "Stopped by SIGTERM"
    )
    assert (
        result["phases"][-1]["readback_end_ns"]
        <= trigger["begin_ns"]
        <= trigger["end_ns"]
    )
    output = result["outputs"][0]
    cleanup = [
        event
        for event in output["sysfs_events"]
        if event["scope"].startswith("cleanup")
    ]
    assert trigger["end_ns"] <= cleanup[0]["begin_ns"]
    assert output["cleanup_final_readback"] == state.requested_state(50, 0) | {
        "enable": 0
    }
    assert (
        output["export_path_absent"]
        and output["released"]
        and output["cleanup_low_confirmed"]
    )
    assert (
        result["cleanup_errors"] == []
        and result["post_abort_thermal_independently_validated"]
    )
    assert (
        len(result["strategy_waits"]) == 1
        and result["strategy_waits"][0]["duration_seconds"] == 0.04
    )
    hashes = result["metadata"]["source_sha256"]
    assert set(hashes) == {
        "kernel_pwm_eval.py",
        "kernel_pwm_inverse_eval.py",
        "kernel_pwm_state_eval.py",
        "kernel_pwm_settled_eval.py",
        "kernel_pwm_sigterm_eval.py",
    }
    assert (
        hashes["kernel_pwm_sigterm_eval.py"]
        == hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
    )
    assert all(not provider.channel_path.exists() for provider in configured["found"])
    assert all(
        path.parent
        in (configured["found"][0].chip, configured["found"][0].channel_path)
        for path, _ in configured["io"].log
    )


@pytest.mark.parametrize("scenario", ["no_delivery", "wrong_signal", "kill_error"])
def test_wrong_or_missing_abort_fails_after_cleanup(configured, monkeypatch, scenario):
    originals = original_hooks()

    def bad_kill(pid, signum):
        configured["kills"].append((pid, signum))
        if scenario == "wrong_signal":
            configured["handlers"][signal.SIGINT](signal.SIGINT, None)
        elif scenario == "kill_error":
            raise PermissionError("injected self signal failure")

    monkeypatch.setattr(bench.os, "kill", bad_kill)
    with pytest.raises((core.BenchError, PermissionError)):
        bench.experiment()
    assert original_hooks() == originals
    assert len(configured["kills"]) == 1
    assert not configured["found"][0].channel_path.exists()


def test_unexport_failure_never_reports_safe_expected_abort(configured):
    configured["io"].fail = ("unexport", 1)
    originals = original_hooks()
    with pytest.raises(core.BenchError, match="release|normal-low"):
        bench.experiment()
    assert original_hooks() == originals
    assert configured["found"][0].channel_path.exists()


def test_second_deferred_sigterm_rejected_without_interrupting_cleanup(configured):
    delivered = False

    def during_cleanup(path, value):
        nonlocal delivered
        if (
            not delivered
            and path.name == "enable"
            and value == 0
            and configured["io"].counts["enable"] >= 3
        ):
            delivered = True
            configured["handlers"][signal.SIGTERM](signal.SIGTERM, None)

    configured["io"].hook = during_cleanup
    with pytest.raises(core.BenchError, match="Exactly one SIGTERM"):
        bench.experiment()
    assert delivered and not configured["found"][0].channel_path.exists()


def test_guard_must_still_be_active_before_self_signal(configured, monkeypatch):
    monkeypatch.setattr(bench.signal, "getsignal", lambda _signum: signal.SIG_DFL)
    with pytest.raises(core.BenchError, match="active guard"):
        bench.experiment()
    assert (
        configured["kills"] == [] and not configured["found"][0].channel_path.exists()
    )


@pytest.mark.parametrize("when", [1, 2])
@pytest.mark.parametrize("problem", ["temperature", "flags"])
def test_cleanup_and_independent_postabort_thermal_gates(configured, when, problem):
    snapshot = configured["snapshots"][when]
    snapshot["temperature_millic" if problem == "temperature" else "throttled"] = (
        "76000" if problem == "temperature" else "throttled=0x1"
    )
    with pytest.raises(core.BenchError, match="thermal gate"):
        bench.experiment()
    assert not configured["found"][0].channel_path.exists()
    assert len(configured["kills"]) == 1


def test_preflight_hot_never_exports_or_self_signals(configured):
    configured["snapshots"][0]["temperature_millic"] = "66000"
    originals = original_hooks()
    with pytest.raises(core.BenchError, match="preflight"):
        bench.experiment()
    assert original_hooks() == originals and configured["kills"] == []
    assert configured["io"].log == []


def test_preexisting_export_never_borrowed_or_signalled(configured):
    configured["found"][0].channel_path.mkdir()
    with pytest.raises(core.BenchError, match="existing exported"):
        bench.experiment()
    assert configured["kills"] == [] and configured["io"].log == []


def test_main_distinguishes_expected_abort_from_ordinary_completion(configured, capsys):
    assert bench.main([]) == 0
    output = json.loads(capsys.readouterr().out)
    assert output["expected_abort_observed"] and output["completed_normally"] is False


def test_main_failure_never_emits_success_json(configured, monkeypatch, capsys):
    monkeypatch.setattr(bench.os, "kill", lambda _pid, _signum: None)
    assert bench.main([]) == 1
    captured = capsys.readouterr()
    assert captured.out == "" and "SafetyAbort" in captured.err


def test_no_cli_signal_pid_or_other_mode_authority(configured):
    with pytest.raises(SystemExit):
        bench.main(["--mode", "direct"])
    with pytest.raises(SystemExit):
        bench.main(["--pid", "1"])
    assert configured["io"].log == [] and configured["kills"] == []
