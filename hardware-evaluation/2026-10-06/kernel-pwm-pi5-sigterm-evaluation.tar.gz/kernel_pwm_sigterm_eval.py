"""Fixed lab-only self-SIGTERM during enabled inverse-zero GPIO18 high.

Only this helper's own PID is signalled, once, after the original high phase
returns under the frozen SafetySignals guard. The existing experiment performs
conservative normal-low close before re-raising. Expected abort is distinct from
ordinary completion, and independent post-abort thermal checks gate the report.
The normal-operation watchdog does not bound signal-deferred cleanup. Nothing
here kills unrelated processes, removes providers, or modifies production code.
"""

import argparse
import hashlib
import json
import os
import signal
import sys
import time
from pathlib import Path

import kernel_pwm_settled_eval as settled

state = settled.state
core = state.core
MODE = "sigterm-high"
SEQUENCE_MARKER = "sigterm-high-v1"
PHASES = (
    ("low50_initial", 0.2, 50, 0),
    ("high50_before_sigterm", 0.3, 50, 65535),
)


def require(condition, message):
    if not condition:
        raise core.BenchError(message)


def experiment():
    begin = time.monotonic_ns()
    helper_pid = os.getpid()
    require(type(helper_pid) is int and helper_pid > 0, "Invalid self PID")
    channels, captured_phases, discovered, snapshots, metadata_refs = [], [], [], [], []
    trigger = None
    expected_abort = None
    originals = {
        "sequences": state.SEQUENCES,
        "run_phase": state.run_phase,
        "discover": core.discover,
        "snapshot": core.system_snapshot,
        "metadata": core.debug_metadata,
    }

    def record_discover():
        value = originals["discover"]()
        discovered.append(value)
        return value

    def record_snapshot():
        value = originals["snapshot"]()
        snapshots.append(value)
        return value

    def record_metadata():
        value = originals["metadata"]()
        metadata_refs.append(value)
        return value

    def run_phase(channel, phases, *args):
        nonlocal trigger
        if not channels:
            channels.append(channel)
            captured_phases.append(phases)
        require(
            channels == [channel] and captured_phases == [phases],
            "Unexpected channel/generation",
        )
        originals["run_phase"](channel, phases, *args)
        if args[0] != "high50_before_sigterm":
            return
        guard = channel.guard
        require(
            trigger is None
            and len(phases) == 2
            and phases[-1]["end_readbacks"] == {"18": state.requested_state(50, 65535)}
            and guard is not None
            and guard.depth == 0
            and guard.received == []
            and signal.getsignal(signal.SIGTERM) == guard.handler
            and channel.owned
            and not channel.released,
            "Self-signal requires completed enabled inverse-zero high under active guard",
        )
        trigger = {
            "operation": "os.kill-self",
            "helper_pid": helper_pid,
            "target_pid": helper_pid,
            "signal_number": int(signal.SIGTERM),
            "signal_name": "SIGTERM",
            "phase": "high50_before_sigterm",
            "begin_ns": time.monotonic_ns(),
            "state": dict(phases[-1]["end_readbacks"]["18"]),
            "guard_depth": guard.depth,
        }
        try:
            os.kill(helper_pid, signal.SIGTERM)
        except core.SafetyAbort as exc:
            trigger.update(status="safety_abort_raised", exception=str(exc))
            raise
        else:
            trigger["status"] = "returned_without_abort"
            raise core.BenchError("Self SIGTERM did not raise expected SafetyAbort")
        finally:
            trigger["end_ns"] = time.monotonic_ns()

    try:
        state.SEQUENCES = {**originals["sequences"], MODE: PHASES}
        state.run_phase = run_phase
        core.discover = record_discover
        core.system_snapshot = record_snapshot
        core.debug_metadata = record_metadata
        try:
            settled.experiment(MODE)
        except core.SafetyAbort as exc:
            require(
                trigger is not None
                and trigger.get("status") == "safety_abort_raised"
                and str(exc) == trigger.get("exception") == "Stopped by SIGTERM",
                "Abort was not the expected recorded self SIGTERM",
            )
            expected_abort = exc
        else:
            raise core.BenchError(
                "Unexpected ordinary completion without expected abort"
            )
    finally:
        state.SEQUENCES = originals["sequences"]
        state.run_phase = originals["run_phase"]
        core.discover = originals["discover"]
        core.system_snapshot = originals["snapshot"]
        core.debug_metadata = originals["metadata"]

    require(
        expected_abort is not None
        and len(channels) == len(captured_phases) == 1
        and len(discovered) == len(metadata_refs) == 1
        and len(snapshots) == 2,
        "Expected abort evidence is incomplete",
    )
    channel = channels[0]
    phases = captured_phases[0]
    require(
        channel.guard.received == [signal.SIGTERM],
        "Exactly one SIGTERM must be recorded",
    )
    state.require_release(channel)
    require(
        not channel.owned
        and not channel.path.exists()
        and channel.cleanup_errors == []
        and channel.period_ns == 20_000_000
        and channel.frequency == 50
        and channel.cleanup_final_readback
        == state.requested_state(50, 0) | {"enable": 0},
        "Expected abort did not complete error-free fresh normal-low release",
    )
    ownership = [
        event
        for event in channel.events
        if event.get("attribute") in ("export", "unexport")
    ]
    require(
        len(ownership) == 2
        and ownership[0] is channel.events[0]
        and ownership[1] is channel.events[-1]
        and ownership[0].get("attribute") == "export"
        and ownership[1].get("attribute") == "unexport"
        and all(
            event.get("value") == 2 and event.get("status") == "ok"
            for event in ownership
        )
        and all(event.get("status") == "ok" for event in channel.events),
        "Expected abort must retain one successful fresh export/final unexport audit",
    )
    before, after_cleanup = snapshots
    # The frozen experiment re-raises its primary before checking its after
    # snapshot; independently gate that snapshot and a fresh post-abort sample.
    after = core.system_snapshot()
    for label, snapshot, limit in (
        ("before", before, 65000),
        ("after_cleanup", after_cleanup, 75000),
        ("after_abort", after, 75000),
    ):
        issues = core.thermal_issues(snapshot, limit)
        require(not issues, f"{label} thermal gate failed: {'; '.join(issues)}")
    export_path_absent = not channel.path.exists()
    require(
        export_path_absent,
        "Export path reappeared after abort cleanup; never borrow it",
    )
    end = time.monotonic_ns()
    require(
        end - begin < 15_000_000_000,
        "Expected-abort experiment exceeded sub-15-second bound",
    )
    model, providers = discovered[0]
    metadata = dict(metadata_refs[0])
    metadata["source_sha256"] = {
        name: hashlib.sha256(Path(path).read_bytes()).hexdigest()
        for name, path in (
            ("kernel_pwm_eval.py", core.__file__),
            ("kernel_pwm_inverse_eval.py", state.inverse.__file__),
            ("kernel_pwm_state_eval.py", state.__file__),
            ("kernel_pwm_settled_eval.py", settled.__file__),
            ("kernel_pwm_sigterm_eval.py", __file__),
        )
    }
    return {
        "schema_version": 1,
        "mode": MODE,
        "sequence_marker": SEQUENCE_MARKER,
        "transition_strategy": settled.STRATEGY,
        "transition_policy": "enabled zero-duty/period-settled scalar writes; conservative disabled abort cleanup",
        "outcome": "expected-sigterm-abort-cleaned",
        "expected_abort_observed": True,
        "completed_normally": False,
        "expected_abort_exception": {
            "type": "SafetyAbort",
            "message": str(expected_abort),
        },
        "signals_received": [int(signum) for signum in channel.guard.received],
        "trigger": trigger,
        "model": model,
        "helper_pid": helper_pid,
        "begin_ns": begin,
        "end_ns": end,
        "phases": phases,
        "outputs": [
            {
                **channel.provider.identity(),
                "backend": "rp1-pwm",
                "generation": channel.generation,
                "frequency": channel.frequency,
                "period_ns": channel.period_ns,
                "last_requested_frequency": channel.last_requested_frequency,
                "last_requested_duty_u16": channel.last_requested_duty_u16,
                "sysfs_events": channel.events,
                "released": channel.released,
                "cleanup_low_confirmed": channel.cleanup_low_confirmed,
                "cleanup_final_readback": channel.cleanup_final_readback,
                "export_path_absent": export_path_absent,
            }
        ],
        "strategy_waits": channel.strategy_waits,
        "lifecycle_quiet_intervals": [],
        "sysfs_released": True,
        "low_confirmed": True,
        "low_confirmation_semantics": "normal-zero enabled cached command/readback plus settle; electrical evidence is separate",
        "discovered_untouched_outputs": [providers[1].identity()],
        "burner_pids": [],
        "hard_max_run_seconds": state.MAX_RUN_SECONDS,
        "watchdog_scope": "normal operation only; low recovery cleanup defers signals",
        "thermal": {"before": before, "after_cleanup": after_cleanup, "after": after},
        "post_abort_thermal_independently_validated": True,
        "cleanup_errors": channel.cleanup_errors,
        "metadata": metadata,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=(MODE,), default=MODE)
    parser.parse_args(argv)
    try:
        result = experiment()
    except (core.BenchError, OSError, ValueError) as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
