"""Only fake capture APIs/subprocesses; no signals, SSH or acquisition."""

import json
import shlex
import subprocess
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

import capture_kernel_pwm_sigterm as bench


@pytest.fixture
def configured(monkeypatch):
    events = []
    capture = MagicMock()
    capture.__enter__.return_value = capture
    capture.stop.side_effect = lambda: events.append("stop")
    capture.save_capture.side_effect = lambda _path: events.append("save")
    capture.export_raw_data_binary.side_effect = lambda _path, **kw: events.append(
        ("export", kw["digital_channels"])
    )
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(device_id=bench.DEVICE_ID, is_simulation=False)
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    connect = MagicMock(return_value=manager)
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connect),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )
    remote = {
        "mode": bench.MODE,
        "sequence_marker": bench.SEQUENCE_MARKER,
        "transition_strategy": bench.STRATEGY,
        "expected_abort_observed": True,
        "completed_normally": False,
    }

    def run(command, **kwargs):
        events.append("ssh")
        assert capture.__enter__.called
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            "/usr/bin/python3",
            "/tmp/blinka-pwm-oct6.abc123/sigterm-eval/kernel_pwm_sigterm_eval.py",
            "--mode",
            bench.MODE,
        ]
        assert set(kwargs) == {"stdout", "stderr", "text", "check", "timeout"}
        assert (
            kwargs["text"] is True
            and kwargs["check"] is False
            and kwargs["timeout"] == 30
        )
        assert kwargs["stdout"].mode == kwargs["stderr"].mode == "x"
        kwargs["stdout"].write(json.dumps(remote))
        return subprocess.CompletedProcess(command, 0)

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(
        bench.time, "sleep", lambda duration: events.append(("sleep", duration))
    )

    def validate(metadata, value):
        assert metadata["remote"] == value
        assert metadata["remote_returncode"] == 0
        assert (
            metadata["expected_abort_observed"] and not metadata["completed_normally"]
        )
        assert metadata["helper_returncode_semantics"] == bench.RETURN_SEMANTICS

    monkeypatch.setattr(bench, "validate_metadata", validate)

    def analyze(directory):
        events.append("analyze")
        report = {"accepted": True, "waveform": {"edge_count": 2}}
        (directory / "analysis.json").write_text(json.dumps(report))
        return report

    monkeypatch.setattr(bench, "write_analysis", analyze)
    return SimpleNamespace(
        events=events,
        capture=capture,
        manager=manager,
        connect=connect,
        runner=runner,
        remote=remote,
    )


def execute(tmp_path):
    return bench.capture_test(
        tmp_path / "capture", "/tmp/blinka-pwm-oct6.abc123/sigterm-eval"
    )


def test_fixed_capture_timing_expected_abort_semantics(configured, tmp_path):
    assert execute(tmp_path)["accepted"]
    assert configured.events == [
        ("sleep", 0.5),
        "ssh",
        ("sleep", 1.2),
        "stop",
        "save",
        ("export", [0]),
        "analyze",
    ]
    configured.connect.assert_called_once_with(port=10430, connect_timeout_seconds=5)
    configured.manager.start_capture.assert_called_once_with(
        device_id=bench.DEVICE_ID,
        device_configuration={
            "enabled_digital_channels": [0],
            "digital_sample_rate": 100_000_000,
        },
    )
    result = json.loads((tmp_path / "capture" / "results.json").read_text())
    assert result["post_helper_tail_seconds"] == 1.2
    assert result["expected_abort_observed"] and not result["completed_normally"]


@pytest.mark.parametrize(
    "scenario", ["nonzero", "timeout", "interrupt", "malformed", "metadata", "rejected"]
)
def test_failure_evidence_retained(configured, tmp_path, monkeypatch, scenario):
    if scenario in ("nonzero", "timeout", "interrupt", "malformed"):

        def failed_run(command, **kwargs):
            kwargs["stdout"].write("not json" if scenario == "malformed" else "partial")
            kwargs["stderr"].write("failed")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            if scenario == "interrupt":
                raise KeyboardInterrupt("fake interruption")
            return subprocess.CompletedProcess(command, int(scenario == "nonzero"))

        configured.runner.side_effect = failed_run
    elif scenario == "metadata":
        monkeypatch.setattr(
            bench, "validate_metadata", MagicMock(side_effect=ValueError("wrong abort"))
        )
    else:

        def rejected(directory):
            report = {"accepted": False}
            (directory / "analysis.json").write_text(json.dumps(report))
            return report

        monkeypatch.setattr(bench, "write_analysis", rejected)
    with pytest.raises((RuntimeError, ValueError)):
        execute(tmp_path)
    output = tmp_path / "capture"
    assert (output / "remote.stdout").exists() and (output / "remote.stderr").exists()
    assert (output / "acquisition.json").exists()
    assert configured.capture.stop.called and configured.capture.save_capture.called
    assert configured.capture.export_raw_data_binary.called
    if scenario == "timeout":
        assert (output / "remote.stdout").read_text() == "partial"
        assert (
            json.loads((output / "acquisition.json").read_text())["remote_returncode"]
            == 124
        )
    if scenario == "interrupt":
        assert (output / "remote.stdout").read_text() == "partial"
        assert (output / "remote.stderr").read_text() == "failed"
        assert (
            "KeyboardInterrupt"
            in json.loads((output / "acquisition.json").read_text())["primary_error"]
        )
    if scenario == "rejected":
        assert json.loads((output / "analysis.json").read_text())["accepted"] is False


@pytest.mark.parametrize("step", ["stop", "save_capture", "export_raw_data_binary"])
def test_acquisition_failure_retains_remote_and_attempts_all_exports(
    configured, tmp_path, step
):
    getattr(configured.capture, step).side_effect = RuntimeError(
        "fake acquisition failure"
    )
    with pytest.raises(RuntimeError, match="evidence retained"):
        execute(tmp_path)
    output = tmp_path / "capture"
    assert (output / "remote.stdout").exists()
    assert json.loads((output / "acquisition.json").read_text())["evidence_errors"]
    assert configured.capture.stop.called and configured.capture.save_capture.called
    assert configured.capture.export_raw_data_binary.called
    assert "analyze" not in configured.events


@pytest.mark.parametrize("scenario", ["missing", "simulation", "connect", "start"])
def test_no_remote_if_acquisition_cannot_start(configured, tmp_path, scenario):
    if scenario == "missing":
        configured.manager.get_devices.return_value = []
    elif scenario == "simulation":
        configured.manager.get_devices.return_value[0].is_simulation = True
    elif scenario == "connect":
        configured.connect.side_effect = RuntimeError("no connection")
    else:
        configured.manager.start_capture.side_effect = RuntimeError("no acquisition")
    with pytest.raises(RuntimeError):
        execute(tmp_path)
    configured.runner.assert_not_called()
    assert json.loads((tmp_path / "capture" / "acquisition.json").read_text())[
        "primary_error"
    ]


def test_tail_interrupt_does_not_prevent_evidence_preservation(
    configured, tmp_path, monkeypatch
):
    def sleep(duration):
        if duration == 1.2:
            raise KeyboardInterrupt("tail signal")

    monkeypatch.setattr(bench.time, "sleep", sleep)
    with pytest.raises(RuntimeError):
        execute(tmp_path)
    assert configured.capture.stop.called and configured.capture.save_capture.called
    assert configured.capture.export_raw_data_binary.called
    assert (tmp_path / "capture" / "remote.stdout").exists()


def test_existing_directory_exclusive_never_contact_hardware(configured, tmp_path):
    output = tmp_path / "capture"
    output.mkdir()
    (output / "results.json").write_text("original")
    with pytest.raises(FileExistsError):
        execute(tmp_path)
    configured.connect.assert_not_called()
    assert (output / "results.json").read_text() == "original"


@pytest.mark.parametrize(
    "root",
    [
        "/tmp",
        "/tmp/blinka-pwm-oct6.abc123/half50-eval",
        "/tmp/blinka-pwm-oct6.abc123/sigterm-eval/../other",
    ],
)
def test_other_remote_directory_rejected_without_side_effects(
    configured, tmp_path, root
):
    with pytest.raises(ValueError):
        bench.capture_test(tmp_path / "capture", root)
    configured.connect.assert_not_called()
    assert not (tmp_path / "capture").exists()
