"""Offline strict self-SIGTERM-high audit; no hardware and no edge filtering.

Exit0 from this dedicated helper means expected-abort checks passed, never
ordinary completion. Frozen SAL/binary/settled-ownership validators are reused
unchanged. Pi clocks are not mapped to Saleae edges or signal response latency.
"""

import argparse
import copy
import json
from pathlib import Path

import analyze_kernel_pwm_settled as settled
from analyze_kernel_pwm_cpu_load import _constant, _object

base = settled.base
require = base.require
MODE = "sigterm-high"
SEQUENCE_MARKER = "sigterm-high-v1"
STRATEGY = settled.STRATEGY
PHASES = (("low50_initial", 0.2, 50, 0), ("high50_before_sigterm", 0.3, 50, 65535))
SOURCE_HASHES = {
    "kernel_pwm_eval.py": "7cb4ea051e346b38b3276b92e5e0edcd9f24f4ed36f7d4f4eeffa4800f8e2111",
    "kernel_pwm_inverse_eval.py": "545b0fd16aaee668040f757be0e49e6021492ff5d64e13a94d8166983164fdbf",
    "kernel_pwm_state_eval.py": "9ba7b5ad0893fbc71d508e2f16a91e7f8b5808bc5d749c7c54210ed50186f7f4",
    "kernel_pwm_settled_eval.py": "ed6c22e6adc31977071c53c67f3267dcd29d92369746b4b5768f455f8f2ab33c",
    "kernel_pwm_sigterm_eval.py": "2db935b3e86c75f12354fc5cfbe2fbeb8fdc016b62dcc93776eff69fafaa7279",
}
OUTPUT_MAPPING = [{"gpio": 18, "saleae_channel": 0, "backend": "kernel-hardware-rp1"}]
RETURN_SEMANTICS = (
    "exit0 confirms expected SIGTERM abort and safety checks, not ordinary completion"
)


def read_json(text):
    value = json.loads(text, object_pairs_hook=_object, parse_constant=_constant)
    require(isinstance(value, dict), "Expected JSON object")
    return value


def validate_metadata(metadata, remote):
    require(
        isinstance(metadata, dict) and isinstance(remote, dict),
        "Metadata must be objects",
    )
    require(
        type(remote.get("schema_version")) is int
        and remote["schema_version"] == 1
        and type(remote.get("hard_max_run_seconds")) is int
        and remote["hard_max_run_seconds"] == 14,
        "Exact helper schema/watchdog integers required",
    )
    for document in (metadata, remote):
        require(
            document.get("mode") == MODE
            and document.get("sequence_marker") == SEQUENCE_MARKER
            and document.get("transition_strategy") == STRATEGY
            and document.get("expected_abort_observed") is True
            and document.get("completed_normally") is False,
            "Expected separate fixed SIGTERM-abort markers, not ordinary completion",
        )
    require(
        type(metadata.get("remote_returncode")) is int
        and metadata["remote_returncode"] == 0
        and metadata.get("helper_returncode_semantics") == RETURN_SEMANTICS
        and metadata.get("pre_helper_lead_seconds") == 0.5
        and metadata.get("post_helper_tail_seconds") == 1.2,
        "Missing exact capture timing/exit0 expected-abort semantics",
    )
    require(
        remote.get("outcome") == "expected-sigterm-abort-cleaned"
        and remote.get("expected_abort_exception")
        == {"type": "SafetyAbort", "message": "Stopped by SIGTERM"}
        and remote.get("signals_received") == [15]
        and all(type(number) is int for number in remote["signals_received"])
        and remote.get("post_abort_thermal_independently_validated") is True,
        "Expected exactly one observed SIGTERM SafetyAbort and post-abort checks",
    )
    pid, trigger = remote.get("helper_pid"), remote.get("trigger")
    require(
        type(pid) is int and pid > 0 and isinstance(trigger, dict),
        "Invalid self PID/trigger",
    )
    expected = {
        "operation": "os.kill-self",
        "helper_pid": pid,
        "target_pid": pid,
        "signal_number": 15,
        "signal_name": "SIGTERM",
        "phase": PHASES[-1][0],
        "state": base.state_for(50, 65535),
        "guard_depth": 0,
        "status": "safety_abort_raised",
        "exception": "Stopped by SIGTERM",
    }
    for key, value in expected.items():
        require(
            type(trigger.get(key)) is type(value) and trigger.get(key) == value,
            f"Self-SIGTERM trigger {key} mismatch",
        )
    provenance = remote.get("metadata")
    hashes = provenance.get("source_sha256") if isinstance(provenance, dict) else None
    require(hashes == SOURCE_HASHES, "Exact five frozen source hashes required")
    adapted_metadata, adapted_remote = copy.deepcopy(metadata), copy.deepcopy(remote)
    adapted_remote["metadata"]["source_sha256"].pop("kernel_pwm_sigterm_eval.py")
    adapted_metadata["remote"] = adapted_remote
    require(
        metadata.get("remote") == remote, "remote.stdout disagrees with results.json"
    )
    original = base.SEQUENCES
    try:
        require(MODE not in original, "SIGTERM metadata registry already active")
        base.SEQUENCES = {**original, MODE: PHASES}
        settled.validate_metadata(adapted_metadata, adapted_remote)
    finally:
        base.SEQUENCES = original
    require(
        remote["end_ns"] - remote["begin_ns"] < 15_000_000_000,
        "Expected-abort helper exceeded sub-15-second bound",
    )
    start, finish = trigger.get("begin_ns"), trigger.get("end_ns")
    require(
        type(start) is int
        and type(finish) is int
        and remote["phases"][-1]["readback_end_ns"]
        <= start
        <= finish
        <= remote["end_ns"],
        "Self-SIGTERM trigger must follow completed high phase",
    )
    output = remote["outputs"][0]
    require(
        json.dumps(metadata["outputs"], sort_keys=True)
        == json.dumps(OUTPUT_MAPPING, sort_keys=True),
        "Exact GPIO18/channel0 mapping types required",
    )
    states = [trigger["state"], output["cleanup_final_readback"]]
    for phase in remote["phases"]:
        for key in ("generation", "frequency", "duty_u16", "period_ns", "duty_ns"):
            require(type(phase.get(key)) is int, f"Exact phase {key} integer required")
        states.extend([phase["sysfs_readbacks"]["18"], phase["end_readbacks"]["18"]])
    for event in output["sysfs_events"]:
        if event["operation"] == "write":
            require(
                type(event["value"])
                is (str if event["attribute"] == "polarity" else int),
                "Exact sysfs write value type required",
            )
        else:
            states.extend([event["state"], event["expected"]])
    for state in states:
        require(
            set(state) == {"period", "duty_cycle", "polarity", "enable"}
            and all(
                type(state[key]) is int for key in ("period", "duty_cycle", "enable")
            )
            and type(state["polarity"]) is str,
            "Exact cached sysfs state types required",
        )
    require(
        output.get("export_path_absent") is True,
        "Export path not absent after abort cleanup",
    )
    cleanup = [
        event
        for event in output["sysfs_events"]
        if event["scope"] in ("cleanup_period_recovery", "cleanup")
    ]
    require(
        cleanup and finish <= cleanup[0]["begin_ns"],
        "Abort cleanup did not follow signal trigger",
    )
    snapshot = remote["thermal"].get("after_cleanup")
    require(
        isinstance(snapshot, dict) and not base.thermal_issues(snapshot, 75000),
        "Independent after-cleanup thermal/firmware gate failed",
    )
    return MODE


def waveform_facts(waveform, edges):
    reasons = []
    if len(edges) != 2:
        reasons.append(
            "Requires exactly two unfiltered edges: one continuous high then persistent low"
        )
    high_runs = [
        {"rise_seconds": rise, "fall_seconds": fall, "width_seconds": fall - rise}
        for rise, fall in zip(edges[::2], edges[1::2])
    ]
    if len(edges) == 2 and not 0.25 <= edges[1] - edges[0] <= 0.35:
        reasons.append("Continuous high must be the requested 0.3 s ±.05 s")
    if waveform["initial_low_seconds"] < 0.5:
        reasons.append("Initial low observation must cover at least .5 s")
    if waveform["quiet_tail_seconds"] < 1.2:
        reasons.append("Persistent final low must cover at least 1.2 s")
    return {
        "accepted": not reasons,
        "rejection_reasons": reasons,
        "edge_count": len(edges),
        "high_runs": high_runs,
        "every_edge_seconds": list(edges),
        "expected_edge_count": 2,
        "expected_high_seconds": 0.3,
        "high_bounds_seconds": [0.25, 0.35],
        "initial_low_seconds": waveform["initial_low_seconds"],
        "persistent_final_low_seconds": waveform["quiet_tail_seconds"],
        "no_transition_trimming_or_glitch_filtering": True,
        "signal_edge_alignment_proven": False,
    }


def analyze(directory):
    directory = Path(directory)
    metadata = read_json((directory / "results.json").read_text())
    remote = read_json((directory / "remote.stdout").read_text())
    validate_metadata(metadata, remote)
    settings = base.validate_saved_capture(directory / "waveform.sal")
    waveform, edges = base.read_continuous(directory / "digital_0.bin")
    physical = waveform_facts(waveform, edges)
    return {
        "capture": directory.name,
        "mode": MODE,
        "sequence_marker": SEQUENCE_MARKER,
        "transition_strategy": STRATEGY,
        "host": metadata["host"],
        "offline_analysis": True,
        "accepted": physical["accepted"],
        "rejection_reasons": physical["rejection_reasons"],
        "expected_abort_observed": True,
        "completed_normally": False,
        "helper_returncode_semantics": RETURN_SEMANTICS,
        "sample_rate_hz": base.SAMPLE_RATE_HZ,
        "saved_capture_settings": settings,
        "waveform": waveform,
        "physical": physical,
        "trigger_reported": remote["trigger"],
        "signals_received_reported": remote["signals_received"],
        "strategy_waits_reported": remote["strategy_waits"],
        "source_sha256_reported": remote["metadata"]["source_sha256"],
        "sysfs_released_reported": True,
        "cleanup_normal_low_confirmed_reported": True,
        "post_abort_thermal_independently_validated": True,
        "clock_alignment": "Pi monotonic trigger clocks are not aligned to Saleae; no signal-to-edge latency claim.",
        "quantization": {
            "nominal_sample_interval_ns": 10,
            "timebase_calibrated": False,
            "width_bounds_include_clock_accuracy": False,
        },
        "limitation": "Finite unfiltered 100 MSa/s digital threshold observation, not analog proof or exclusion of sub-sample glitches. All captured edges are retained. Cached readbacks are command evidence, not electrical proof.",
    }


def write_analysis(directory, output_name="analysis.json"):
    require(
        bool(output_name)
        and Path(output_name).name == output_name
        and output_name not in (".", ".."),
        "Output must be a filename inside capture directory",
    )
    report = analyze(directory)
    with (Path(directory) / output_name).open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args(argv)
    try:
        report = write_analysis(args.directory)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(report, indent=2))
    return 0 if report["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
