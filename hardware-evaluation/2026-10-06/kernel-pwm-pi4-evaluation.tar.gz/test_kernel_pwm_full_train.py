"""Quick synthetic fixtures for offline, untrimmed kernel PWM analysis."""

import json
import sys

import analyze_kernel_pwm_full_train as full
import pytest
from test_kernel_pwm_waveforms_pi4 import (
    binary_export,
    metadata_files,
    replace_metadata,
)


@pytest.fixture(params=["pi4", "pi5"])
def ordinary(tmp_path, request):
    metadata = metadata_files(tmp_path, "idle")
    if request.param == "pi5":
        metadata["host"] = "test-pi5.local"
        for output in metadata["outputs"]:
            output["saleae_channel"] -= 2
            output.pop("backend")
        replace_metadata(tmp_path, metadata)
    for output in metadata["outputs"]:
        period = 1 / output["frequency"]
        high = period * output["duty"] / 65535
        count = 16 if output["gpio"] == 18 else 160
        edges = [
            time
            for i in range(count)
            for time in (0.2 + i * period, 0.2 + i * period + high)
        ]
        # Startup and final high exceptions lie outside the strict 50 ms trim.
        edges[1] = edges[0] + high / 2
        edges[-1] = edges[-2] + high / 4
        binary_export(tmp_path / f"digital_{output['saleae_channel']}.bin", edges)
    return tmp_path


def test_both_benches_all_highs_and_static_tail_exclusion(ordinary):
    result = full.analyze(ordinary)
    is_pi4 = result["host"] == full.pi4.HOST
    assert (
        result["strict_bench_analyzer"] == (full.pi4 if is_pi4 else full.pi5).__name__
    )
    assert result["steady_state_trim_seconds_each_end"] == 0
    assert result["estimated_omitted_cycles"] is None
    assert result["quantization"]["timebase_calibrated"] is False
    assert "not aligned" in result["clock_alignment"]
    for output, count in zip(result["outputs"], (16, 160)):
        high = output["high_us"]
        assert high["count"] == count
        assert output["period_us"]["count"] == count - 1
        assert output["low_us"]["count"] == count - 1
        assert high["min"] == pytest.approx(high["target_us"] / 4)
        assert high["first_interval"]["duration_us"] == pytest.approx(
            high["target_us"] / 2
        )
        assert high["last_interval"]["duration_us"] == pytest.approx(
            high["target_us"] / 4
        )
        assert high["min_interval"] == high["last_interval"]
        assert high["absolute_error_us"]["max"] == pytest.approx(
            high["target_us"] * 0.75
        )
        event = high["absolute_error_us"]["max_error_interval"]
        assert event == high["last_interval"]
        assert event["start_saleae_seconds"] == pytest.approx(
            output["first_rise_saleae_seconds"]
            + event["start_relative_to_first_rise_seconds"]
        )
        assert output["leading_static_low_seconds"] == pytest.approx(0.2)
        assert output["trailing_static_low_seconds"] > 1
    assert not (ordinary / full.OUTPUT_NAME).exists()


def test_strict_validation_not_bypassed(ordinary):
    metadata = json.loads((ordinary / "results.json").read_text())
    metadata["outputs"][0]["saleae_channel"] = 7
    replace_metadata(ordinary, metadata)
    with pytest.raises(ValueError, match="mapping"):
        full.analyze(ordinary)


def test_strict_binary_validation_not_bypassed(ordinary):
    metadata = json.loads((ordinary / "results.json").read_text())
    channel = metadata["outputs"][0]["saleae_channel"]
    (ordinary / f"digital_{channel}.bin").write_bytes(b"bad")
    with pytest.raises(ValueError, match="Invalid digital export"):
        full.analyze(ordinary)


def test_endpoints_refused_after_strict_analyzer(tmp_path, monkeypatch):
    metadata_files(tmp_path, "endpoints")
    binary_export(tmp_path / "digital_2.bin", (0.2, 0.4, 1.0, 1.2))
    binary_export(tmp_path / "digital_3.bin", (0.6, 0.8, 1.001, 1.201))
    called = []
    strict = full.pi4.analyze

    def tracked(directory):
        called.append(directory)
        return strict(directory)

    monkeypatch.setattr(full.pi4, "analyze", tracked)
    with pytest.raises(ValueError, match="refuses endpoints"):
        full.analyze(tmp_path)
    assert called == [tmp_path]


def test_exclusive_report_creation_does_not_overwrite(ordinary):
    before = {
        path.name: path.read_bytes() for path in ordinary.iterdir() if path.is_file()
    }
    result = full.write_analysis(ordinary)
    assert json.loads((ordinary / full.OUTPUT_NAME).read_text()) == result
    report = (ordinary / full.OUTPUT_NAME).read_bytes()
    with pytest.raises(FileExistsError):
        full.write_analysis(ordinary)
    assert (ordinary / full.OUTPUT_NAME).read_bytes() == report
    for name, data in before.items():
        assert (ordinary / name).read_bytes() == data


def test_cli_read_only_by_default(ordinary, monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["full-train", str(ordinary)])
    full.main()
    assert json.loads(capsys.readouterr().out)["offline_analysis"] is True
    assert not (ordinary / full.OUTPUT_NAME).exists()


def test_cli_exclusively_writes_report(ordinary, monkeypatch, capsys):
    monkeypatch.setattr(sys, "argv", ["full-train", str(ordinary), "--write"])
    full.main()
    assert json.loads(capsys.readouterr().out) == json.loads(
        (ordinary / full.OUTPUT_NAME).read_text()
    )
    with pytest.raises(SystemExit) as error:
        full.main()
    assert error.value.code == 2


def test_untrimmed_startup_and_last_periods_not_discarded(ordinary):
    metadata = json.loads((ordinary / "results.json").read_text())
    channel = metadata["outputs"][1]["saleae_channel"]
    rises = [0.2 + i * 0.002 for i in range(160)]
    rises[1] += 0.000020
    rises[-1] -= 0.000015
    edges = [time for rise in rises for time in (rise, rise + 0.001)]
    binary_export(ordinary / f"digital_{channel}.bin", edges)
    output = full.analyze(ordinary)["outputs"][1]
    assert output["period_us"]["first_interval"]["duration_us"] == pytest.approx(2020)
    assert output["period_us"]["last_interval"]["duration_us"] == pytest.approx(1985)
    assert output["period_us"]["max"] == pytest.approx(2020)
    assert output["period_us"]["min"] == pytest.approx(1980)
    assert output["low_us"]["first_interval"]["duration_us"] == pytest.approx(1020)
    assert output["low_us"]["last_interval"]["duration_us"] == pytest.approx(985)


def test_interval_extreme_ties_use_first_and_errors_use_target():
    result = full.interval_summary([(0, 0.001), (0.002, 0.003)], 1100, 0)
    assert result["min_interval"]["interval_index_zero_based"] == 0
    assert result["max_interval"]["interval_index_zero_based"] == 0
    assert result["absolute_error_us"]["min"] == pytest.approx(100)


def test_unknown_host_refused(ordinary):
    metadata = json.loads((ordinary / "results.json").read_text())
    metadata["host"] = "unapproved.local"
    replace_metadata(ordinary, metadata)
    with pytest.raises(ValueError, match="Unknown Pi 4/Pi 5"):
        full.analyze(ordinary)
