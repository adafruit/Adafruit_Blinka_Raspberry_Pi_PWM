"""Synthetic Pi4 Saleae fixtures; no Pi, GPIO, sysfs, or Saleae connection."""

import json
import struct
import sys

import analyze_kernel_pwm_eval as pi5_analyzer
import capture_pwm
import pytest
from analyze_kernel_pwm_eval_pi4 import (
    ENDPOINT_DUTIES,
    HOST,
    OUTPUTS,
    SAMPLE_RATE_HZ,
    analyze,
    main,
    write_analysis,
)


def binary_export(
    path,
    edges,
    *,
    initial=0,
    begin=0.0,
    end=2.0,
    rate=None,
    chunks=1,
    version=1,
):
    if rate is None:
        rate = json.loads((path.parent / "results.json").read_text())["sample_rate_hz"]
    data = b"<SALEAE>" + struct.pack("<ii", version, 0)
    if version:
        data += struct.pack("<Q", chunks)
    for _ in range(chunks):
        data += struct.pack("<I", initial)
        if version:
            data += struct.pack("<d", rate)
        data += struct.pack("<ddQ", begin, end, len(edges))
        data += struct.pack(f"<{len(edges)}d", *edges)
    path.write_bytes(data)


def metadata_files(directory, mode, sample_rate_hz=SAMPLE_RATE_HZ):
    duties = (
        ENDPOINT_DUTIES
        if mode == "endpoints"
        else (
            {"18": 0, "23": 0},
            {"18": 4915, "23": 32768},
            {"18": 0, "23": 0},
        )
    )
    phases, tick = [], 10_000_000_000
    for index, states in enumerate(duties):
        duration = (
            (3.0 if mode == "idle" else 20.0)
            if mode != "endpoints" and index == 1
            else 0.2
        )
        end = tick + round(duration * 1e9)
        phases.append(
            {
                "name": f"phase-{index}",
                "duration_seconds": duration,
                "duties": dict(states),
                "begin_ns": tick,
                "end_ns": end,
            }
        )
        tick = end
    remote = {
        "mode": mode,
        "phases": phases,
        "sysfs_released": True,
        "burner_pids": [101, 102, 103, 104] if mode == "loaded" else [],
        "burner_watchdog_seconds": 25,
    }
    metadata = {
        "mode": mode,
        "host": HOST,
        "sample_rate_hz": sample_rate_hz,
        "outputs": [dict(spec) for spec in OUTPUTS],
        "remote": remote,
    }
    replace_metadata(directory, metadata)
    (directory / "waveform.sal").write_bytes(
        b"synthetic fixture; binary exports tested separately"
    )
    return metadata


def replace_metadata(directory, metadata):
    (directory / "remote.stdout").write_text(json.dumps(metadata["remote"]) + "\n")
    (directory / "results.json").write_text(json.dumps(metadata) + "\n")


@pytest.fixture(params=[10_000_000, 100_000_000], ids=["10MSa", "100MSa"])
def endpoints(tmp_path, request):
    metadata_files(tmp_path, "endpoints", request.param)
    binary_export(tmp_path / "digital_2.bin", (0.2, 0.4, 1.0, 1.2))
    binary_export(tmp_path / "digital_3.bin", (0.6, 0.8, 1.001, 1.201))
    return tmp_path


def test_endpoint_physical_pattern_independence_and_pi4_routing(endpoints):
    result = analyze(endpoints)
    assert result["host"] == "test2-pi4.local"
    assert result["offline_analysis"] is True
    assert result["endpoints"]["physical_sequence_validated"] is True
    assert result["endpoints"]["sequence_gpio18_gpio23"] == [
        "00",
        "10",
        "00",
        "01",
        "00",
        "11",
        "00",
    ]
    assert result["endpoints"]["phase_alignment_proven"] is False
    assert result["endpoints"]["both_high_overlap_seconds"] == pytest.approx(0.199)
    assert [entry["saleae_channel"] for entry in result["outputs"]] == [2, 3]
    assert [entry["backend"] for entry in result["outputs"]] == [
        "kernel-hardware-bcm",
        "kernel-software-pwm-gpio",
    ]
    assert [entry["waveform"]["edge_count"] for entry in result["outputs"]] == [4, 4]
    rate = json.loads((endpoints / "results.json").read_text())["sample_rate_hz"]
    assert result["sample_rate_hz"] == rate
    assert result["quantization"]["nominal_sample_interval_us"] == 1e6 / rate
    assert result["quantization"]["timebase_calibrated"] is False
    assert "not a bound" in result["quantization"]["note"]
    assert "not aligned" in result["clock_alignment"]
    assert all(
        output["waveform"]["header_sample_rate_hz"] == rate
        for output in result["outputs"]
    )


def test_legacy_header_does_not_invent_verified_sample_rate(endpoints):
    binary_export(endpoints / "digital_2.bin", (0.2, 0.4, 1.0, 1.2), version=0)
    result = analyze(endpoints)
    assert result["outputs"][0]["waveform"]["header_sample_rate_hz"] is None
    assert result["quantization"]["timebase_calibrated"] is False


@pytest.mark.parametrize("channel", [2, 3])
def test_extra_endpoint_edges_rejected_without_filtering(endpoints, channel):
    edges = (
        (0.2, 0.4, 0.99, 0.991, 1.0, 1.2)
        if channel == 2
        else (0.6, 0.8, 0.99, 0.991, 1.001, 1.201)
    )
    binary_export(endpoints / f"digital_{channel}.bin", edges)
    with pytest.raises(ValueError, match="four endpoint transitions"):
        analyze(endpoints)


def test_hardware_endpoint_nanosecond_notch_rejected_without_filtering(endpoints):
    # A short notch in a static hardware high is still two extra physical
    # edges. Do not excuse it merely because normal PWM timings look good.
    binary_export(endpoints / "digital_2.bin", (0.2, 0.3, 0.30000008, 0.4, 1.0, 1.2))
    with pytest.raises(ValueError, match="four endpoint transitions"):
        analyze(endpoints)


@pytest.mark.parametrize(
    "edges,kwargs,match",
    [
        ((0.2, 0.4, 1.0, 1.2), {"initial": 1}, "did not start low"),
        ((0.2, 0.4, 1.0), {}, "did not finish low"),
        ((0.2, 0.4, 1.0, 1.2), {"end": 1.25}, "stable low tail"),
        ((0.2, 0.3, 1.0, 1.2), {}, "static high holds"),
        ((0.5, 0.7, 1.0, 1.2), {}, "Independent GPIO18-high"),
        ((0.2, 0.4, 1.2, 1.4), {}, "both-high overlap"),
        ((0.2, 0.4, 1.0, 1.2), {"rate": 1_000_000}, "sample rate"),
        ((0.2, 0.4, 1.0, 1.2), {"chunks": 2}, "continuous capture chunk"),
        ((0.2, 0.4, 1.0, 1.2), {"initial": 2}, "Invalid digital export"),
        ((0.2, 0.4, 1.2, 1.0), {}, "Invalid digital export"),
        ((0.2, 0.4, 1.0, 1.0), {}, "Invalid digital export"),
        ((0.2, 0.4, 1.0, 2.1), {}, "Invalid digital export"),
        ((), {"begin": float("nan")}, "invalid capture bounds"),
    ],
)
def test_waveform_rejections(endpoints, edges, kwargs, match):
    binary_export(endpoints / "digital_2.bin", edges, **kwargs)
    with pytest.raises(ValueError, match=match):
        analyze(endpoints)


@pytest.mark.parametrize("data", [b"bad", b"<SALEAE>", b"<SALEAE>" + bytes(100)])
def test_invalid_headers_rejected(endpoints, data):
    (endpoints / "digital_2.bin").write_bytes(data)
    with pytest.raises(ValueError, match="Invalid digital export"):
        analyze(endpoints)


def test_both_channels_must_observe_independent_highs(endpoints):
    binary_export(endpoints / "digital_3.bin", (0.6, 0.8, 1.001, 1.201), begin=0.5)
    with pytest.raises(ValueError, match="full edge sequence"):
        analyze(endpoints)


def test_channels_require_common_final_low_tail(endpoints):
    binary_export(endpoints / "digital_2.bin", (0.2, 0.4, 1.0, 1.2), end=1.31)
    binary_export(endpoints / "digital_3.bin", (0.6, 0.8, 1.001, 1.251))
    with pytest.raises(ValueError, match="common stable final low tail"):
        analyze(endpoints)


def test_channels_require_common_observation_interval(endpoints):
    binary_export(endpoints / "digital_2.bin", (), begin=0.0, end=0.2)
    binary_export(endpoints / "digital_3.bin", (), begin=1.0, end=2.0)
    with pytest.raises(ValueError, match="no common observation interval"):
        analyze(endpoints)


@pytest.mark.parametrize(
    "mutation,match",
    [
        (lambda m: m.update(host="test-pi5.local"), "authorized Pi 4"),
        (lambda m: m["remote"].update(sysfs_released=False), "sysfs release"),
        (lambda m: m["remote"].update(mode="idle"), "Remote mode"),
        (lambda m: m.update(mode="other"), "Unknown capture mode"),
        (lambda m: m["remote"].update(phases=[]), "phase sequence"),
        (
            lambda m: m["remote"]["phases"][1].update(duties={"18": 0, "23": 65535}),
            "duties",
        ),
        (lambda m: m["remote"]["phases"][1].update(duration_seconds=0.1), "0.2 s"),
        (
            lambda m: m["remote"]["phases"][1].update(duration_seconds=float("nan")),
            "valid requested duration",
        ),
        (
            lambda m: m["remote"]["phases"][1].update(begin_ns=None),
            "monotonic timestamps",
        ),
        (
            lambda m: m["remote"]["phases"][1].update(begin_ns=1, end_ns=2),
            "out of order",
        ),
        (lambda m: m["outputs"][0].update(saleae_channel=0), "mapping"),
        (lambda m: m["outputs"][1].update(saleae_channel=1), "mapping"),
        (lambda m: m["outputs"][0].update(backend="kernel-hardware-rp1"), "mapping"),
        (lambda m: m["outputs"][1].update(frequency=50), "mapping"),
        (lambda m: m["outputs"][0].update(duty=32768), "mapping"),
        (lambda m: m["outputs"].reverse(), "mapping"),
    ],
)
def test_metadata_rejections(endpoints, mutation, match):
    metadata = json.loads((endpoints / "results.json").read_text())
    mutation(metadata)
    replace_metadata(endpoints, metadata)
    with pytest.raises(ValueError, match=match):
        analyze(endpoints)


def test_remote_copy_must_match(endpoints):
    remote = json.loads((endpoints / "remote.stdout").read_text())
    remote["sysfs_released"] = False
    (endpoints / "remote.stdout").write_text(json.dumps(remote))
    with pytest.raises(ValueError, match="disagrees"):
        analyze(endpoints)


@pytest.mark.parametrize("mode", ["endpoints", "idle", "loaded"])
@pytest.mark.parametrize("rate", [0, 1_000_000, 50_000_000, 200_000_000])
def test_unsupported_sample_rates_rejected_for_all_modes(tmp_path, mode, rate):
    metadata_files(tmp_path, mode, rate)
    with pytest.raises(ValueError, match="Endpoints require 10 or 100 MSa/s"):
        analyze(tmp_path)


@pytest.mark.parametrize("mode", ["idle", "loaded"])
def test_100MSa_only_allowed_for_endpoints(tmp_path, mode):
    metadata_files(tmp_path, mode, 100_000_000)
    with pytest.raises(ValueError, match="idle/loaded require 10 MSa/s"):
        analyze(tmp_path)


@pytest.mark.parametrize("channel", [2, 3])
def test_each_channel_header_rate_must_match_metadata(endpoints, channel):
    rate = json.loads((endpoints / "results.json").read_text())["sample_rate_hz"]
    wrong_rate = 100_000_000 if rate == SAMPLE_RATE_HZ else SAMPLE_RATE_HZ
    edges = (0.2, 0.4, 1.0, 1.2) if channel == 2 else (0.6, 0.8, 1.001, 1.201)
    binary_export(endpoints / f"digital_{channel}.bin", edges, rate=wrong_rate)
    with pytest.raises(ValueError, match="sample rate does not match metadata"):
        analyze(endpoints)


@pytest.mark.parametrize("mode", ["idle", "loaded"])
def test_pwm_uses_complete_trimmed_cycles(tmp_path, mode):
    metadata_files(tmp_path, mode)
    duration = 3 if mode == "idle" else 20
    for spec in OUTPUTS:
        period = 1 / spec["frequency"]
        high = period * spec["duty"] / 65535
        edges = [
            edge
            for index in range(spec["frequency"] * duration)
            for edge in (0.4 + index * period, 0.4 + index * period + high)
        ]
        binary_export(
            tmp_path / f"digital_{spec['saleae_channel']}.bin", edges, end=duration + 1
        )
    result = analyze(tmp_path)
    assert "endpoints" not in result
    assert result["burner_pids"] == ([101, 102, 103, 104] if mode == "loaded" else [])
    for output in result["outputs"]:
        timing = output["timing"]
        assert timing["steady_state_trim_seconds_each_end"] == 0.05
        assert 0 < timing["period_us"]["count"] < output["frequency"] * duration
        assert timing["mean_frequency_hz"] == pytest.approx(output["frequency"])
        assert timing["mean_duty_percent"] == pytest.approx(
            output["duty"] / 65535 * 100
        )
        assert timing["high_us"]["mean"] == pytest.approx(timing["target_high_us"])
        assert timing["estimated_omitted_cycles"] is None
        assert (
            timing["omitted_cycle_estimation_note"]
            == "Not inferred for kernel/hardware PWM."
        )
        assert timing["final_state"] == 0


@pytest.mark.parametrize(
    "pids",
    [
        [],
        [101, 102, 103],
        [101, 101, 103, 104],
        [101, 102, 0, 104],
        [101, 102, True, 104],
        [101, 102, 103.0, 104],
        [101, 102, 103, -1],
    ],
)
def test_loaded_requires_four_distinct_positive_integer_worker_pids(tmp_path, pids):
    metadata = metadata_files(tmp_path, "loaded")
    metadata["remote"]["burner_pids"] = pids
    replace_metadata(tmp_path, metadata)
    with pytest.raises(ValueError, match="worker PIDs"):
        analyze(tmp_path)


@pytest.mark.parametrize("mode", ["endpoints", "idle"])
def test_nonloaded_modes_require_no_worker_pids(tmp_path, mode):
    metadata = metadata_files(tmp_path, mode)
    metadata["remote"]["burner_pids"] = [101, 102, 103, 104]
    replace_metadata(tmp_path, metadata)
    with pytest.raises(ValueError, match="worker PIDs"):
        analyze(tmp_path)


@pytest.mark.parametrize("mode,wrong_duration", [("idle", 20), ("loaded", 3)])
def test_active_duration_must_match_mode(tmp_path, mode, wrong_duration):
    metadata = metadata_files(tmp_path, mode)
    metadata["remote"]["phases"][1]["duration_seconds"] = wrong_duration
    replace_metadata(tmp_path, metadata)
    with pytest.raises(ValueError, match="mode should request"):
        analyze(tmp_path)


def test_offline_analysis_does_not_mutate_pi5_globals_or_connect(
    endpoints, monkeypatch
):
    original = (
        tuple(dict(spec) for spec in pi5_analyzer.OUTPUTS),
        pi5_analyzer.SAMPLE_RATE_HZ,
    )

    def unexpected_hardware_call(*args, **kwargs):
        pytest.fail("Offline analysis attempted hardware access")

    monkeypatch.setattr(
        capture_pwm.automation.Manager, "connect", unexpected_hardware_call
    )
    monkeypatch.setattr(capture_pwm.subprocess, "run", unexpected_hardware_call)
    monkeypatch.setattr(capture_pwm.subprocess, "Popen", unexpected_hardware_call)
    analyze(endpoints)
    binary_export(endpoints / "digital_2.bin", (0.2, 0.4, 0.9, 0.91, 1.0, 1.2))
    with pytest.raises(ValueError, match="four endpoint transitions"):
        analyze(endpoints)
    assert (pi5_analyzer.OUTPUTS, pi5_analyzer.SAMPLE_RATE_HZ) == original


def test_exclusive_output_preserves_existing_analysis(endpoints):
    original = write_analysis(endpoints)
    saved = (endpoints / "analysis.json").read_bytes()
    assert json.loads(saved) == original
    with pytest.raises(FileExistsError):
        write_analysis(endpoints)
    assert (endpoints / "analysis.json").read_bytes() == saved
    with pytest.raises(ValueError, match="filename"):
        write_analysis(endpoints, "../outside.json")


def test_cli_exclusively_creates_custom_output(endpoints, monkeypatch, capsys):
    monkeypatch.setattr(
        sys, "argv", ["analyzer", str(endpoints), "--output-name", "check.json"]
    )
    main()
    assert json.loads(capsys.readouterr().out)["host"] == HOST
    assert (endpoints / "check.json").is_file()
    with pytest.raises(SystemExit) as exc:
        main()
    assert exc.value.code == 2
    assert "File exists" in capsys.readouterr().err
