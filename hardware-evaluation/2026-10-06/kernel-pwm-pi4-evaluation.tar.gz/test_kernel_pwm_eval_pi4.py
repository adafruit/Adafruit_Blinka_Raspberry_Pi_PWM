"""Pi 4 helper tests use fake OF/sysfs trees only; never access bench hardware."""

import errno
import importlib.util
import json
import signal
import struct
import sys
from pathlib import Path

import pytest


def load_module(name, filename):
    spec = importlib.util.spec_from_file_location(
        name, Path(__file__).with_name(filename)
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


core = load_module("kernel_pwm_eval", "kernel_pwm_eval.py")
bench = load_module("kernel_pwm_eval_pi4", "kernel_pwm_eval_pi4.py")


def write_cells(path, *values):
    path.write_bytes(struct.pack(">" + "I" * len(values), *values))


def add_chip(sysfs, index, node, npwm):
    chip = sysfs / f"pwmchip{index}"
    (chip / "device").mkdir(parents=True)
    (chip / "device" / "of_node").symlink_to(node, target_is_directory=True)
    (chip / "npwm").write_text(str(npwm))
    (chip / "export").touch()
    (chip / "unexport").touch()
    return chip


@pytest.fixture
def tree(tmp_path):
    dt = tmp_path / "device-tree"
    dt.mkdir()
    (dt / "model").write_bytes(bench.AUTHORIZED_MODEL.encode() + b"\0")
    gpio = dt / "soc" / "gpio@7e200000"
    gpio.mkdir(parents=True)
    (gpio / "compatible").write_bytes(b"brcm,bcm2711-gpio\0brcm,bcm2835-gpio\0")
    write_cells(gpio / "#gpio-cells", 2)
    write_cells(gpio / "phandle", 0x12345678)
    header = gpio.parent / "pwm@7e20c000"
    header.mkdir()
    (header / "compatible").write_bytes(b"brcm,bcm2835-pwm\0")
    software = dt / "pwm_gpio@17"
    software.mkdir()
    (software / "compatible").write_bytes(b"pwm-gpio\0")
    write_cells(software / "gpios", 0x12345678, 23, 0)
    audio = gpio.parent / "pwm@7e20c800"
    audio.mkdir()
    (audio / "compatible").write_bytes(b"brcm,bcm2835-pwm\0")
    sysfs = tmp_path / "pwm"
    sysfs.mkdir()
    for index, node, count in ((17, header, 2), (3, software, 1), (0, audio, 2)):
        add_chip(sysfs, index, node, count)
    return dt, sysfs


def providers(tree):
    dt, sysfs = tree
    return bench.discover(sysfs, dt)[1]


class FakeIO(core.SysfsIO):
    def __init__(self, *, export_busy=False, fail_unexport=False):
        self.log = []
        self.export_busy = export_busy
        self.fail_unexport = fail_unexport

    def write(self, path, value):
        self.log.append((path, value))
        if path.name == "export":
            if self.export_busy:
                raise OSError(errno.EBUSY, "already requested")
            channel = path.parent / f"pwm{value}"
            channel.mkdir()
            for name, initial in (
                ("period", 0),
                ("duty_cycle", 0),
                ("enable", 0),
                ("polarity", "normal"),
            ):
                (channel / name).write_text(str(initial))
        elif path.name == "unexport":
            if self.fail_unexport:
                raise OSError("injected unexport failure")
            channel = path.parent / f"pwm{value}"
            for name in ("period", "duty_cycle", "enable", "polarity"):
                (channel / name).unlink()
            channel.rmdir()
        else:
            super().write(path, value)


def test_discovery_uses_of_identity_and_channel_zero_not_chip_number(tree):
    model, found = bench.discover(tree[1], tree[0])
    assert model == "Raspberry Pi 4 Model B Rev 1.4"
    assert [
        (provider.gpio, provider.chip.name, provider.channel) for provider in found
    ] == [(18, "pwmchip17", 0), (23, "pwmchip3", 0)]
    assert all(isinstance(provider, core.Provider) for provider in found)
    assert found[0].of_node.name == "pwm@7e20c000"
    assert found[0].compatible == ("brcm,bcm2835-pwm",)
    assert found[1].gpio_of_node == str(tree[0] / "soc" / "gpio@7e200000")


@pytest.mark.parametrize(
    "model",
    [
        "Raspberry Pi 4 Model B Rev 1.0",
        "Raspberry Pi 4 Model B Rev 1.4 other",
        "Raspberry Pi 5 Model B Rev 1.0",
    ],
)
def test_only_exact_authorized_model_is_accepted(tree, model):
    (tree[0] / "model").write_bytes(model.encode() + b"\0")
    with pytest.raises(core.BenchError, match="Only Raspberry Pi 4 Model B Rev 1.4"):
        bench.discover(tree[1], tree[0])


@pytest.mark.parametrize(
    "handle,pin,flags",
    [(0x78563412, 23, 0), (0x12345678, 22, 0), (0x12345678, 23, 1)],
)
def test_gpio_specifier_is_big_endian_exact_handle_pin_and_polarity(
    tree, handle, pin, flags
):
    write_cells(tree[0] / "pwm_gpio@17" / "gpios", handle, pin, flags)
    with pytest.raises(core.BenchError):
        bench.discover(tree[1], tree[0])


@pytest.mark.parametrize("gpio_cells", [0, 1, 3])
def test_gpio_provider_requires_two_cells(tree, gpio_cells):
    write_cells(tree[0] / "soc" / "gpio@7e200000" / "#gpio-cells", gpio_cells)
    with pytest.raises(core.BenchError, match="GPIO cell count"):
        bench.discover(tree[1], tree[0])


@pytest.mark.parametrize("property_name", ["phandle", "linux,phandle"])
def test_each_supported_phandle_name_is_accepted(tree, property_name):
    gpio = tree[0] / "soc" / "gpio@7e200000"
    (gpio / "phandle").unlink()
    write_cells(gpio / property_name, 0x12345678)
    assert providers(tree)[1].gpio_of_node == str(gpio)


@pytest.mark.parametrize("handles", [(), (0,), (0x12345678, 1)])
def test_invalid_phandle_properties_are_rejected(tree, handles):
    gpio = tree[0] / "soc" / "gpio@7e200000"
    if handles:
        write_cells(gpio / "phandle", *handles)
    else:
        (gpio / "phandle").unlink()
    with pytest.raises(core.BenchError, match="phandle"):
        bench.discover(tree[1], tree[0])


def test_inconsistent_dual_phandles_are_rejected(tree):
    write_cells(tree[0] / "soc" / "gpio@7e200000" / "linux,phandle", 0x87654321)
    with pytest.raises(core.BenchError, match="inconsistent"):
        bench.discover(tree[1], tree[0])


def test_gpio_provider_must_be_bcm2711_not_rp1(tree):
    (tree[0] / "soc" / "gpio@7e200000" / "compatible").write_bytes(
        b"raspberrypi,rp1-gpio\0"
    )
    with pytest.raises(core.BenchError, match="one BCM2711 GPIO"):
        bench.discover(tree[1], tree[0])


def test_audio_controller_is_never_a_header_fallback(tree):
    (tree[0] / "soc" / "pwm@7e20c000" / "compatible").write_bytes(
        b"unapproved-controller\0"
    )
    with pytest.raises(core.BenchError, match="GPIO18"):
        bench.discover(tree[1], tree[0])


def test_header_pwm_and_gpio_must_share_parent(tree):
    header = tree[0] / "elsewhere" / "pwm@7e20c000"
    header.mkdir(parents=True)
    (header / "compatible").write_bytes(b"brcm,bcm2835-pwm\0")
    link = tree[1] / "pwmchip17" / "device" / "of_node"
    link.unlink()
    link.symlink_to(header, target_is_directory=True)
    with pytest.raises(core.BenchError, match="same BCM2711 bus"):
        bench.discover(tree[1], tree[0])


@pytest.mark.parametrize("index,count", [(17, 1), (17, 4), (3, 2)])
def test_provider_channel_counts_are_exact(tree, index, count):
    (tree[1] / f"pwmchip{index}" / "npwm").write_text(str(count))
    with pytest.raises(core.BenchError):
        bench.discover(tree[1], tree[0])


def test_duplicate_header_provider_is_rejected(tree):
    add_chip(tree[1], 29, tree[0] / "soc" / "pwm@7e20c000", 2)
    with pytest.raises(core.BenchError, match="GPIO18.*exactly one"):
        bench.discover(tree[1], tree[0])


def test_duplicate_gpio_controller_is_rejected(tree):
    gpio = tree[0] / "soc" / "gpio@other"
    gpio.mkdir()
    (gpio / "compatible").write_bytes(b"brcm,bcm2711-gpio\0")
    write_cells(gpio / "#gpio-cells", 2)
    write_cells(gpio / "phandle", 0x9999)
    with pytest.raises(core.BenchError, match="one BCM2711 GPIO"):
        bench.discover(tree[1], tree[0])


@pytest.mark.parametrize("gpio", [18, 23])
def test_existing_export_is_refused_without_touching_it(tree, gpio):
    provider = next(item for item in providers(tree) if item.gpio == gpio)
    provider.channel_path.mkdir()
    with pytest.raises(core.BenchError, match="existing exported"):
        bench.discover(tree[1], tree[0])
    io = FakeIO()
    with pytest.raises(core.BenchError, match="existing exported"):
        core.PWMChannel(provider, 50, 4915, io=io)
    assert io.log == []
    assert provider.channel_path.exists()


def test_outside_device_tree_node_is_rejected(tree, tmp_path):
    node = tmp_path / "untrusted" / "pwm@7e20c000"
    node.mkdir(parents=True)
    (node / "compatible").write_bytes(b"brcm,bcm2835-pwm\0")
    link = tree[1] / "pwmchip17" / "device" / "of_node"
    link.unlink()
    link.symlink_to(node, target_is_directory=True)
    with pytest.raises(core.BenchError, match="outside the live device tree"):
        bench.discover(tree[1], tree[0])


def test_proxy_changes_discovery_and_backend_but_restores_core(monkeypatch):
    original = core.discover
    sentinel = {
        "outputs": [
            {"gpio": 18, "backend": "rp1-pwm"},
            {"gpio": 23, "backend": "pwm-gpio"},
        ]
    }

    def experiment(mode):
        assert mode == "idle"
        assert core.discover is bench.discover
        return sentinel

    monkeypatch.setattr(core, "experiment", experiment)
    assert bench.experiment("idle") is sentinel
    assert [output["backend"] for output in sentinel["outputs"]] == [
        "bcm2835-pwm",
        "pwm-gpio",
    ]
    assert core.discover is original


@pytest.mark.parametrize("failure", [core.BenchError("failure"), KeyboardInterrupt()])
def test_proxy_restores_core_discovery_on_every_failure(monkeypatch, failure):
    original = core.discover

    def fail(_mode):
        assert core.discover is bench.discover
        raise failure

    monkeypatch.setattr(core, "experiment", fail)
    with pytest.raises(type(failure)) as error:
        bench.experiment("endpoints")
    assert error.value is failure
    assert core.discover is original


@pytest.fixture
def fake_experiment(tree, monkeypatch):
    discovered = providers(tree)
    monkeypatch.setattr(bench, "discover", lambda: (bench.AUTHORIZED_MODEL, discovered))
    monkeypatch.setattr(core, "debug_metadata", lambda: {"fake": True})
    snapshot = {"temperature_millic": "42000", "throttled": "throttled=0x0"}
    monkeypatch.setattr(core, "system_snapshot", lambda: dict(snapshot))
    monkeypatch.setattr(core.time, "sleep", lambda _seconds: None)
    alarms = []
    monkeypatch.setattr(core.signal, "alarm", lambda seconds: alarms.append(seconds))
    handlers = []
    monkeypatch.setattr(
        core.signal, "signal", lambda sig, handler: handlers.append((sig, handler))
    )
    io = FakeIO()
    monkeypatch.setattr(core, "SysfsIO", lambda: io)
    children = []

    class Child:
        def __init__(self, pid):
            self.pid = pid
            self.finished = False

        def poll(self):
            return 0 if self.finished else None

        def terminate(self):
            self.finished = True

        def wait(self, timeout):
            assert self.finished
            return 0

    def spawn(args, **_kwargs):
        assert "deadline = time.monotonic() + 25" in args[2]
        child = Child(100 + len(children))
        children.append(child)
        return child

    monkeypatch.setattr(core.subprocess, "Popen", spawn)
    return discovered, io, alarms, handlers, children


@pytest.mark.parametrize(
    "mode,durations",
    [("endpoints", [0.2] * 7), ("idle", [0.2, 3.0, 0.2]), ("loaded", [0.2, 20.0, 0.2])],
)
def test_all_modes_reuse_core_phases_and_safety_with_fake_io(
    fake_experiment, mode, durations
):
    discovered, io, alarms, handlers, children = fake_experiment
    original = core.discover
    result = bench.experiment(mode)
    assert core.discover is original
    assert result["model"] == bench.AUTHORIZED_MODEL
    assert result["mode"] == mode and result["sysfs_released"] is True
    assert result["cleanup_errors"] == []
    assert all(not provider.channel_path.exists() for provider in discovered)
    assert [output["backend"] for output in result["outputs"]] == [
        "bcm2835-pwm",
        "pwm-gpio",
    ]
    assert [output["channel"] for output in result["outputs"]] == [0, 0]
    assert [
        (output["frequency"], output["duty_u16"]) for output in result["outputs"]
    ] == [(50, 4915), (500, 32768)]
    assert [phase["duration_seconds"] for phase in result["phases"]] == durations
    assert all(
        phase["begin_ns"] <= phase["stable_begin_ns"] <= phase["end_ns"]
        for phase in result["phases"]
    )
    if mode == "endpoints":
        assert [phase["duties"] for phase in result["phases"]] == [
            {"18": 0, "23": 0},
            {"18": 65535, "23": 0},
            {"18": 0, "23": 0},
            {"18": 0, "23": 65535},
            {"18": 0, "23": 0},
            {"18": 65535, "23": 65535},
            {"18": 0, "23": 0},
        ]
    else:
        assert result["phases"][1]["duties"] == {"18": 4915, "23": 32768}
    assert alarms == [30, 0, 0]
    assert len(handlers) == 8
    assert {sig for sig, _handler in handlers} == {
        signal.SIGTERM,
        signal.SIGINT,
        signal.SIGHUP,
        signal.SIGALRM,
    }
    assert result["burner_watchdog_seconds"] == 25
    assert result["hard_max_run_seconds"] == 30
    assert len(children) == (4 if mode == "loaded" else 0)
    assert all(child.finished for child in children)
    assert len([path for path, _value in io.log if path.name == "unexport"]) == 2


def test_export_ebusy_is_preserved_without_stealing_or_unexporting(fake_experiment):
    _discovered, io, _alarms, _handlers, _children = fake_experiment
    io.export_busy = True
    original = core.discover
    with pytest.raises(OSError) as error:
        bench.experiment("idle")
    assert error.value.errno == errno.EBUSY
    assert core.discover is original
    assert [(path.name, value) for path, value in io.log] == [("export", 0)]


def test_signal_between_constructor_return_and_tracking_still_releases_export(
    fake_experiment, monkeypatch
):
    discovered, io, _alarms, _handlers, _children = fake_experiment
    original_channel = core.PWMChannel
    original_discover = core.discover
    initialized = []

    def interrupted_handoff(*args, **kwargs):
        # The real constructor has completed; its rollback handler cannot help now.
        channel = original_channel(*args, **kwargs)
        initialized.append(channel)
        kwargs["guard"].handler(signal.SIGTERM, None)
        return channel

    monkeypatch.setattr(core, "PWMChannel", interrupted_handoff)
    with pytest.raises(core.SafetyAbort) as error:
        bench.experiment("idle")
    assert "Signal received during PWM ownership transition" in str(error.value)
    assert core.discover is original_discover
    assert len(initialized) == 1
    assert initialized[0].released and not initialized[0].owned
    assert all(not provider.channel_path.exists() for provider in discovered)
    assert [(path.name, value) for path, value in io.log][-3:] == [
        ("duty_cycle", 0),
        ("enable", 0),
        ("unexport", 0),
    ]


def test_main_success_is_json_only_after_releasing_fake_exports(
    fake_experiment, capsys
):
    discovered = fake_experiment[0]
    assert bench.main(["--mode", "idle"]) == 0
    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["sysfs_released"] is True and captured.err == ""
    assert all(not provider.channel_path.exists() for provider in discovered)


def test_main_emits_no_json_when_cleanup_fails(fake_experiment, capsys):
    fake_experiment[1].fail_unexport = True
    assert bench.main(["--mode", "idle"]) == 1
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "Cleanup failures" in captured.err
    assert "cleanup failed" in captured.err
