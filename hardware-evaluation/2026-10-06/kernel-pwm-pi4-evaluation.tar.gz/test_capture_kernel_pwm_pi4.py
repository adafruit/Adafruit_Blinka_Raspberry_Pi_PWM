"""Pi 4 capture lifecycle with fake analyzer/SSH only."""

import json
import shlex
import subprocess
import sys
from types import SimpleNamespace

import capture_kernel_pwm_pi4 as bench
import pytest


@pytest.mark.parametrize(
    "scenario", ["success", "failure", "timeout", "bad_cleanup", "no_device"]
)
@pytest.mark.parametrize("sample_rate", [10_000_000, 100_000_000])
def test_capture_cleanup_and_routing(monkeypatch, tmp_path, scenario, sample_rate):
    events = []

    class Capture:
        def __enter__(self):
            return self

        def __exit__(self, *_args):
            pass

        def stop(self):
            events.append("stop")

        def save_capture(self, path):
            events.append("save")
            assert path.endswith("waveform.sal")

        def export_raw_data_binary(self, path, *, digital_channels):
            events.append("export")
            assert digital_channels == [2, 3]

    class Manager(Capture):
        def get_devices(self):
            return (
                []
                if scenario == "no_device"
                else [SimpleNamespace(device_id=bench.DEVICE_ID, is_simulation=False)]
            )

        def start_capture(self, *, device_id, device_configuration):
            assert device_id == bench.DEVICE_ID
            assert device_configuration == {
                "enabled_digital_channels": [2, 3],
                "digital_sample_rate": sample_rate,
            }
            events.append("capture")
            return Capture()

        def get_app_info(self):
            return SimpleNamespace(app_version="fake")

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test2-pi4.local",
        ]
        assert shlex.split(command[-1]) == [
            "/usr/bin/python3",
            "/tmp/blinka-pwm-pi4-oct6.abc123/kernel_pwm_eval_pi4.py",
            "--mode",
            "endpoints",
        ]
        assert kwargs == {
            "capture_output": True,
            "text": True,
            "check": False,
            "timeout": 45,
        }
        if scenario == "timeout":
            raise subprocess.TimeoutExpired(
                command, 45, output=b"partial", stderr=b"error"
            )
        return subprocess.CompletedProcess(
            command,
            int(scenario == "failure"),
            json.dumps(
                {"mode": "endpoints", "sysfs_released": scenario != "bad_cleanup"}
            ),
            "",
        )

    def analyze(directory, name):
        events.append("analysis")
        results = json.loads((directory / "results.json").read_text())
        assert name == "analysis.json"
        assert results["outputs"][0] == {
            "gpio": 18,
            "saleae_channel": 2,
            "frequency": 50,
            "duty": 4915,
            "backend": "kernel-hardware-bcm",
        }
        assert results["outputs"][1]["saleae_channel"] == 3
        return {"ok": True}

    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=lambda **_kw: Manager()),
            LogicDeviceConfiguration=lambda **kw: kw,
        ),
    )
    monkeypatch.setattr(bench.subprocess, "run", run)
    monkeypatch.setattr(bench, "write_analysis", analyze)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_pi4.py",
            str(tmp_path / "capture"),
            "--remote-root",
            "/tmp/blinka-pwm-pi4-oct6.abc123",
            "--mode",
            "endpoints",
            "--sample-rate-hz",
            str(sample_rate),
        ],
    )
    if scenario == "success":
        bench.main()
        assert events == ["capture", "ssh", "stop", "save", "export", "analysis"]
    else:
        with pytest.raises(RuntimeError):
            bench.main()
        assert events == (
            []
            if scenario == "no_device"
            else ["capture", "ssh", "stop", "save", "export"]
        )


@pytest.mark.parametrize(
    "path",
    ["/tmp", "/tmp/blinka-pwm-oct6.abc123", "/tmp/blinka-pwm-pi4-oct6.abc123/../other"],
)
def test_reject_wrong_remote_root(monkeypatch, tmp_path, path):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_pi4.py",
            str(tmp_path / "capture"),
            "--remote-root",
            path,
            "--mode",
            "idle",
        ],
    )
    with pytest.raises(ValueError, match="isolated Pi 4"):
        bench.main()
    assert not (tmp_path / "capture").exists()
