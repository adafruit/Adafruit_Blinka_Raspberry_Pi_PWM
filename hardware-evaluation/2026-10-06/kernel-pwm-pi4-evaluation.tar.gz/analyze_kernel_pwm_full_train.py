"""Untrimmed, offline timing of validated Pi 4/Pi 5 ordinary PWM captures.

The corresponding strict bench analyzer runs first. Endpoint captures are
refused. Every recorded rise-to-fall high is included, including the final
high; lows and periods require a following rise. Initial/final static low
holds are reported separately, not treated as PWM lows. No edges are filtered.
Saleae timestamps are not aligned to the remote clock, and sampling resolution
is not a claim of analyzer timebase calibration. The CLI is read-only unless
--write is supplied; that option exclusively creates full-train-analysis.json.
"""

import argparse
import json
from pathlib import Path

import analyze_kernel_pwm_eval as pi5
import analyze_kernel_pwm_eval_pi4 as pi4
from capture_pwm import describe

OUTPUT_NAME = "full-train-analysis.json"


def interval_summary(intervals, target_us, first_rise):
    """Describe intervals and locate extrema; equal extrema use the first."""
    pi5.require(bool(intervals), "No complete full-train intervals recorded")
    durations = [(end - start) * 1e6 for start, end in intervals]
    errors = [abs(value - target_us) for value in durations]

    def event(index):
        start, end = intervals[index]
        return {
            "interval_index_zero_based": index,
            "duration_us": durations[index],
            "absolute_error_us": errors[index],
            "start_saleae_seconds": start,
            "end_saleae_seconds": end,
            "start_relative_to_first_rise_seconds": start - first_rise,
            "end_relative_to_first_rise_seconds": end - first_rise,
        }

    return {
        **describe(durations),
        "target_us": target_us,
        "min_interval": event(min(range(len(durations)), key=durations.__getitem__)),
        "max_interval": event(max(range(len(durations)), key=durations.__getitem__)),
        "absolute_error_us": {
            **describe(errors),
            "max_error_interval": event(
                max(range(len(errors)), key=errors.__getitem__)
            ),
        },
        "first_interval": event(0),
        "last_interval": event(len(intervals) - 1),
    }


def analyze(directory):
    """Validate the bench capture, then report every observed PWM interval."""
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    pi5.require(isinstance(metadata, dict), "Capture metadata must be a JSON object")
    host = metadata.get("host")
    pi5.require(host in (pi4.HOST, "test-pi5.local"), "Unknown Pi 4/Pi 5 bench host")
    analyzer = pi4 if host == pi4.HOST else pi5
    validated = analyzer.analyze(directory)
    pi5.require(
        validated["mode"] != "endpoints", "Full-train analysis refuses endpoints"
    )
    result = {
        "capture": directory.name,
        "host": validated["host"],
        "mode": validated["mode"],
        "offline_analysis": True,
        "strict_bench_analyzer": analyzer.__name__,
        "sample_rate_hz": validated["sample_rate_hz"],
        "quantization": validated["quantization"],
        "clock_alignment": validated["clock_alignment"],
        "steady_state_trim_seconds_each_end": 0,
        "interval_scope": (
            "All rise-to-fall highs, fall-to-next-rise lows, and rise-to-next-rise "
            "periods. Static leading/trailing low holds excluded from PWM lows."
        ),
        "estimated_omitted_cycles": None,
        "omitted_cycle_estimation_note": "Not inferred for kernel/hardware PWM.",
        "outputs": [],
    }
    for output in validated["outputs"]:
        channel = output["saleae_channel"]
        waveform, edges = pi5.read_continuous(
            directory / f"digital_{channel}.bin", validated["sample_rate_hz"]
        )
        rises, falls = edges[::2], edges[1::2]
        pi5.require(
            len(rises) >= 2 and len(rises) == len(falls), "Incomplete pulse train"
        )
        first_rise = rises[0]
        period_target = 1e6 / output["frequency"]
        high_target = period_target * output["duty"] / 65535
        result["outputs"].append(
            {
                **{
                    key: value
                    for key, value in output.items()
                    if key not in ("timing", "waveform")
                },
                "waveform": waveform,
                "first_rise_saleae_seconds": first_rise,
                "last_fall_saleae_seconds": falls[-1],
                "leading_static_low_seconds": first_rise - waveform["begin_seconds"],
                "trailing_static_low_seconds": waveform["end_seconds"] - falls[-1],
                "period_us": interval_summary(
                    list(zip(rises, rises[1:])), period_target, first_rise
                ),
                "high_us": interval_summary(
                    list(zip(rises, falls)), high_target, first_rise
                ),
                "low_us": interval_summary(
                    list(zip(falls, rises[1:])), period_target - high_target, first_rise
                ),
            }
        )
    return result


def write_analysis(directory):
    """Exclusively create the fixed new report; never overwrite any artifact."""
    result = analyze(directory)
    with (Path(directory) / OUTPUT_NAME).open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument(
        "--write", action="store_true", help=f"Exclusively create {OUTPUT_NAME}"
    )
    args = parser.parse_args()
    try:
        result = (
            write_analysis(args.directory) if args.write else analyze(args.directory)
        )
    except (ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
