"""Offline checks for the Pi 4 hardware/kernel-pwm-gpio bench capture.

GPIO18 is Saleae channel 2 (BCM hardware, 50 Hz, duty 4915); GPIO23 is
channel 3 (pwm-gpio software, 500 Hz, duty 32768). Endpoints allow 10 or
100 MSa/s; idle and loaded captures require 10 MSa/s.
This script never connects to the Pi or Saleae. Physical endpoint edges are
checked without aligning Saleae time to the Pi's monotonic clock. Sampling
quantization is not analyzer timebase calibration or analog-level evidence.
"""

import argparse
import json
import math
from pathlib import Path

from analyze_kernel_pwm_eval import (
    ENDPOINT_DUTIES,
    read_continuous,
    require,
    validate_endpoints,
)
from capture_pwm import summarize

HOST = "test2-pi4.local"
SAMPLE_RATE_HZ = 10_000_000
ENDPOINT_SAMPLE_RATES_HZ = (SAMPLE_RATE_HZ, 100_000_000)
OUTPUTS = (
    {
        "gpio": 18,
        "saleae_channel": 2,
        "frequency": 50,
        "duty": 4915,
        "backend": "kernel-hardware-bcm",
    },
    {
        "gpio": 23,
        "saleae_channel": 3,
        "frequency": 500,
        "duty": 32768,
        "backend": "kernel-software-pwm-gpio",
    },
)


def validate_metadata(metadata, remote):
    """Require Pi4 routing and phase requests, without correlating clocks."""
    require(
        isinstance(metadata, dict) and isinstance(remote, dict),
        "Capture and remote metadata must be JSON objects",
    )
    require(
        metadata.get("remote") == remote,
        "remote.stdout disagrees with results.json remote metadata",
    )
    mode = metadata.get("mode")
    require(mode in ("endpoints", "idle", "loaded"), "Unknown capture mode")
    require(remote.get("mode") == mode, "Remote mode disagrees with capture mode")
    require(metadata.get("host") == HOST, "Expected the authorized Pi 4 bench")
    allowed_rates = (
        ENDPOINT_SAMPLE_RATES_HZ if mode == "endpoints" else (SAMPLE_RATE_HZ,)
    )
    require(
        metadata.get("sample_rate_hz") in allowed_rates,
        "Endpoints require 10 or 100 MSa/s; idle/loaded require 10 MSa/s",
    )
    specs = metadata.get("outputs")
    require(
        isinstance(specs, list) and len(specs) == 2,
        "Expected two output specifications",
    )
    require(
        all(isinstance(spec, dict) for spec in specs), "Invalid output specification"
    )
    for actual, expected in zip(specs, OUTPUTS):
        require(
            all(actual.get(key) == value for key, value in expected.items()),
            "Output GPIO/channel/frequency/duty/backend mapping does not match this bench",
        )
    require(
        remote.get("sysfs_released") is True,
        "Remote metadata does not confirm sysfs release; this is not physical low proof",
    )
    burner_pids = remote.get("burner_pids")
    require(
        isinstance(burner_pids, list)
        and all(type(pid) is int and pid > 0 for pid in burner_pids)
        and len(set(burner_pids)) == len(burner_pids)
        and len(burner_pids) == (4 if mode == "loaded" else 0),
        "Mode requires four distinct load worker PIDs only for loaded captures",
    )
    phases = remote.get("phases")
    expected_duties = (
        ENDPOINT_DUTIES
        if mode == "endpoints"
        else (
            {"18": 0, "23": 0},
            {"18": 4915, "23": 32768},
            {"18": 0, "23": 0},
        )
    )
    require(
        isinstance(phases, list) and len(phases) == len(expected_duties),
        "Metadata does not describe the expected phase sequence",
    )
    previous_end = None
    for index, (phase, duties) in enumerate(zip(phases, expected_duties)):
        require(
            isinstance(phase, dict) and phase.get("duties") == duties,
            f"Phase {index} has unexpected endpoint/active duties",
        )
        duration = phase.get("duration_seconds")
        require(
            type(duration) in (int, float) and math.isfinite(duration) and duration > 0,
            f"Phase {index} has no valid requested duration",
        )
        if mode == "endpoints" or index != 1:
            require(
                math.isclose(duration, 0.2, rel_tol=0, abs_tol=1e-9),
                f"Phase {index} should request a 0.2 s static hold",
            )
        else:
            expected_duration = 3.0 if mode == "idle" else 20.0
            require(
                math.isclose(duration, expected_duration, rel_tol=0, abs_tol=1e-9),
                f"{mode} mode should request {expected_duration:g} s of PWM",
            )
        begin, end = phase.get("begin_ns"), phase.get("end_ns")
        require(
            type(begin) is int and type(end) is int and 0 <= begin < end,
            f"Phase {index} has invalid remote monotonic timestamps",
        )
        require(
            previous_end is None or previous_end <= begin,
            "Remote phase intervals are out of order",
        )
        previous_end = end
    return mode


def analyze(directory: Path) -> dict:
    """Return validated offline analysis without changing capture artifacts."""
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    remote = json.loads((directory / "remote.stdout").read_text())
    mode = validate_metadata(metadata, remote)
    sample_rate = metadata["sample_rate_hz"]
    require(
        (directory / "waveform.sal").is_file(), "Missing saved waveform.sal capture"
    )
    waveforms = [
        read_continuous(
            directory / f"digital_{spec['saleae_channel']}.bin", sample_rate
        )
        for spec in OUTPUTS
    ]
    common_begin = max(waveform["begin_seconds"] for waveform, _ in waveforms)
    common_end = min(waveform["end_seconds"] for waveform, _ in waveforms)
    require(common_begin < common_end, "Channels have no common observation interval")
    require(
        all(
            common_begin <= edge <= common_end
            for _, edges in waveforms
            for edge in edges
        ),
        "Both channels must cover the full edge sequence to establish independent levels",
    )
    common_last_edge = max(
        (edge for _, edges in waveforms for edge in edges), default=common_begin
    )
    require(
        common_end - common_last_edge >= 0.1,
        "Channels lack a common stable final low tail of at least 0.1 s",
    )
    result = {
        "capture": directory.name,
        "mode": mode,
        "host": HOST,
        "offline_analysis": True,
        "sysfs_released_reported": True,
        "burner_pids": remote["burner_pids"],
        "sample_rate_hz": sample_rate,
        "common_observation_interval_seconds": [common_begin, common_end],
        "quantization": {
            "nominal_sample_interval_us": 1e6 / sample_rate,
            "timebase_calibrated": False,
            "note": "Sampling quantization is not a bound on analyzer clock accuracy.",
        },
        "clock_alignment": "Saleae timestamps are not aligned to remote monotonic timestamps.",
        "outputs": [],
    }
    if mode == "endpoints":
        # The unchanged helper consumes only the identical GPIO18/GPIO23
        # static endpoint pattern; it does not consume Saleae routing or host.
        # Every extra edge is rejected, including on the hardware PWM pin.
        result["endpoints"] = validate_endpoints(waveforms)
    for spec, (waveform, _) in zip(OUTPUTS, waveforms):
        output = {**spec, "waveform": waveform}
        if mode != "endpoints":
            try:
                timing = summarize(
                    directory / f"digital_{spec['saleae_channel']}.bin",
                    spec["frequency"],
                    spec["duty"],
                    "kernel",
                )
            except AssertionError as error:
                raise ValueError(
                    f"GPIO{spec['gpio']} PWM analysis rejected: {error}"
                ) from error
            timing["estimated_omitted_cycles"] = None
            timing["omitted_cycle_estimation_note"] = (
                "Not inferred for kernel/hardware PWM."
            )
            output["timing"] = timing
        result["outputs"].append(output)
    return result


def write_analysis(directory: Path, output_name="analysis.json") -> dict:
    """Analyze and exclusively create one new file inside the capture folder."""
    require(
        bool(output_name)
        and Path(output_name).name == output_name
        and output_name not in (".", ".."),
        "Output must be a filename in the capture directory",
    )
    result = analyze(directory)
    with (Path(directory) / output_name).open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output-name", default="analysis.json")
    args = parser.parse_args()
    try:
        result = write_analysis(args.directory, args.output_name)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
