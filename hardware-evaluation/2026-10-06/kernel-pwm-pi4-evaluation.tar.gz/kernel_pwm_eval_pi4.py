"""Evaluation-only helper for the dedicated Raspberry Pi 4 Model B Rev 1.4 bench.

Run beside kernel_pwm_eval.py on the already configured, authorized bench:
    /usr/bin/python3 kernel_pwm_eval_pi4.py --mode endpoints|idle|loaded

GPIO18 uses the BCM2835 header PWM controller's channel 0; GPIO23 uses
pwm-gpio channel 0. The second BCM controller (audio) is never selected.
The run drives only its freshly exported PWM outputs. It does not change overlays,
pin multiplexing, ownership of pre-existing exports, or production code.
The Pi 5 helper supplies the unchanged ownership, timing, thermal, signal, load,
and cleanup logic. Success JSON is emitted only after it confirms cleanup.
"""

import argparse
import json
import sys
from pathlib import Path

import kernel_pwm_eval as core

AUTHORIZED_MODEL = "Raspberry Pi 4 Model B Rev 1.4"
HEADER_PWM_NODE = "pwm@7e20c000"


def discover(sysfs_pwm=core.SYSFS_PWM, device_tree=core.DEVICE_TREE):
    """Identify only this Pi 4 bench by live OF properties, not pwmchip numbers."""
    device_tree = Path(device_tree).resolve(strict=True)
    model = core.strings(device_tree / "model")[0]
    if model != AUTHORIZED_MODEL:
        raise core.BenchError(f"Only {AUTHORIZED_MODEL} is authorized, got {model!r}")

    gpio_nodes = {}
    for compatible_path in device_tree.rglob("compatible"):
        if "brcm,bcm2711-gpio" not in core.strings(compatible_path):
            continue
        node = compatible_path.parent
        if core.cells(node / "#gpio-cells") != (2,):
            raise core.BenchError(f"Unexpected BCM2711 GPIO cell count at {node}")
        handles = set()
        for name in ("phandle", "linux,phandle"):
            prop = node / name
            if prop.exists():
                values = core.cells(prop)
                if len(values) != 1 or values[0] == 0:
                    raise core.BenchError(f"Invalid BCM2711 GPIO phandle at {node}")
                handles.add(values[0])
        if len(handles) != 1:
            raise core.BenchError(
                f"Missing or inconsistent BCM2711 GPIO phandle at {node}"
            )
        handle = handles.pop()
        if handle in gpio_nodes:
            raise core.BenchError("Duplicate BCM2711 GPIO phandle")
        gpio_nodes[handle] = node
    if len(gpio_nodes) != 1:
        raise core.BenchError("Cannot identify exactly one BCM2711 GPIO provider")
    gpio_node = next(iter(gpio_nodes.values()))

    candidates = {18: [], 23: []}
    for chip in sorted(Path(sysfs_pwm).glob("pwmchip*")):
        node_link = chip / "device" / "of_node"
        if not node_link.exists():
            continue
        node = node_link.resolve(strict=True)
        try:
            node.relative_to(device_tree)
        except ValueError as exc:
            raise core.BenchError(
                f"OF node is outside the live device tree: {node}"
            ) from exc
        compatible = tuple(core.strings(node / "compatible"))
        npwm = int((chip / "npwm").read_text().strip())
        if "brcm,bcm2835-pwm" in compatible and node.name == HEADER_PWM_NODE:
            if node.parent != gpio_node.parent:
                raise core.BenchError(
                    "Header PWM and GPIO providers are not on the same BCM2711 bus"
                )
            if npwm != 2:
                raise core.BenchError(
                    f"Unexpected BCM2835 header PWM channel count: {npwm}"
                )
            candidates[18].append(core.Provider(18, chip, node, 0, compatible))
        elif "pwm-gpio" in compatible:
            gpios = core.cells(node / "gpios")
            if len(gpios) != 3:
                raise core.BenchError(
                    f"Unexpected pwm-gpio OF GPIO specifier at {node}"
                )
            handle, pin, flags = gpios
            if pin != 23:
                continue
            if handle not in gpio_nodes or flags != 0 or npwm != 1:
                raise core.BenchError(
                    "GPIO23 PWM must use BCM2711 GPIO23, normal polarity, one channel"
                )
            candidates[23].append(
                core.Provider(23, chip, node, 0, compatible, str(gpio_nodes[handle]))
            )
        # In particular, pwm@7e20c800 is the audio controller, not GPIO18.

    providers = []
    for gpio in (18, 23):
        if len(candidates[gpio]) != 1:
            raise core.BenchError(
                f"GPIO{gpio}: require exactly one approved PWM provider"
            )
        provider = candidates[gpio][0]
        if provider.channel_path.exists():
            raise core.BenchError(
                f"Refusing existing exported channel: {provider.channel_path}"
            )
        providers.append(provider)
    return model, providers


def experiment(mode):
    """Use the unchanged core experiment; this standalone CLI is single-threaded."""
    original_discover = core.discover
    core.discover = discover
    try:
        result = core.experiment(mode)
    finally:
        core.discover = original_discover
    for output in result["outputs"]:
        if output["gpio"] == 18:
            output["backend"] = "bcm2835-pwm"
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mode", required=True, choices=("endpoints", "idle", "loaded")
    )
    args = parser.parse_args(argv)
    try:
        result = experiment(args.mode)
    except BaseException as exc:  # noqa: BLE001 -- never emit success JSON on failure
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
