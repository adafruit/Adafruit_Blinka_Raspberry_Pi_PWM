"""Record bounded, approved Pi 5 GPIO18 state-transition diagnostics.

No provider removal, sudo, PIO, or production backend changes. Each fresh
capture preserves raw evidence even when the offline waveform check rejects it.
"""

import argparse
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

from saleae import automation

from analyze_kernel_pwm_state import write_analysis
from capture_pwm import DEVICE_ID

SAMPLE_RATE_HZ = 100_000_000
MODES = ("direct", "frequency", "lifecycle")


def decoded(value):
    return value.decode(errors="replace") if isinstance(value, bytes) else value or ""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--mode", choices=MODES, required=True)
    args = parser.parse_args()
    if not re.fullmatch(
        r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/state-eval", args.remote_root
    ):
        raise ValueError("Requires the isolated Pi 5 state diagnostic directory")
    output = args.directory.resolve()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", output.name):
        raise ValueError("Use a simple capture directory name")
    output.mkdir(parents=True, exist_ok=False)
    invocation = shlex.join(
        [
            "/usr/bin/python3",
            args.remote_root + "/kernel_pwm_state_eval.py",
            "--mode",
            args.mode,
        ]
    )
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        invocation,
    ]
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        if not any(
            device.device_id == DEVICE_ID and not device.is_simulation
            for device in manager.get_devices()
        ):
            raise RuntimeError("Confirmed analyzer is not available")
        configuration = automation.LogicDeviceConfiguration(
            enabled_digital_channels=[0], digital_sample_rate=SAMPLE_RATE_HZ
        )
        with manager.start_capture(
            device_id=DEVICE_ID, device_configuration=configuration
        ) as capture:
            try:
                remote = subprocess.run(
                    command, capture_output=True, text=True, check=False, timeout=30
                )
            except subprocess.TimeoutExpired as exc:
                remote = subprocess.CompletedProcess(
                    command,
                    124,
                    decoded(exc.stdout),
                    decoded(exc.stderr) + "\nSSH timeout",
                )
            finally:
                # Close-from-high modes have no final 0.2 s phase. Keep observing
                # after helper exit to independently check a sufficiently long
                # physical low tail, including after a failed helper.
                time.sleep(0.2)
                capture.stop()
                capture.save_capture(str(output / "waveform.sal"))
                capture.export_raw_data_binary(str(output), digital_channels=[0])
        (output / "remote.stdout").write_text(remote.stdout)
        (output / "remote.stderr").write_text(remote.stderr)
        if remote.returncode:
            raise RuntimeError(
                f"Capture saved; helper failed ({remote.returncode}): {remote.stderr}"
            )
        remote_data = json.loads(remote.stdout)
        if (
            remote_data.get("mode") != args.mode
            or remote_data.get("sysfs_released") is not True
            or remote_data.get("low_confirmed") is not True
            or remote_data.get("cleanup_errors") != []
        ):
            raise RuntimeError("Helper did not confirm expected mode and low cleanup")
        result = {
            "host": "test-pi5.local",
            "mode": args.mode,
            "sample_rate_hz": SAMPLE_RATE_HZ,
            "logic_version": manager.get_app_info().app_version,
            "providers_left_loaded_until_reboot": True,
            "production_backend_unchanged": True,
            "outputs": [
                {"gpio": 18, "saleae_channel": 0, "backend": "kernel-hardware-rp1"}
            ],
            "remote": remote_data,
        }
        with (output / "results.json").open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
    report = write_analysis(output, "analysis.json")
    print(
        json.dumps(
            {
                "capture": output.name,
                "mode": args.mode,
                "accepted": report.get("accepted"),
                "edge_count": report.get("waveform", {}).get("edge_count"),
                "rejection_reasons": report.get("rejection_reasons", []),
            }
        )
    )
    if report.get("accepted") is not True:
        raise RuntimeError(
            "Raw capture and rejected analysis preserved; investigate before acceptance"
        )


if __name__ == "__main__":
    main()
