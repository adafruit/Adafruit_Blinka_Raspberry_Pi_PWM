"""Fake state-test orchestration; never uses SSH, Saleae, or physical GPIO."""

import json
import shlex
import subprocess
import sys
from types import SimpleNamespace

import pytest

import capture_kernel_pwm_state as bench


@pytest.mark.parametrize("mode", bench.MODES)
@pytest.mark.parametrize(
    "scenario",
    [
        "success",
        "helper_failure",
        "timeout",
        "not_low",
        "cleanup_error",
        "missing_device",
        "simulation",
        "waveform_rejected",
    ],
)
def test_lifecycle(monkeypatch, tmp_path, mode, scenario):
    events = []

    class Capture:
        def __enter__(self):
            events.append("capture")
            return self

        def __exit__(self, *_args):
            events.append("capture_closed")

        def stop(self):
            events.append("stop")

        def save_capture(self, path):
            events.append("save")
            assert path.endswith("/waveform.sal")

        def export_raw_data_binary(self, path, *, digital_channels):
            events.append("export")
            assert digital_channels == [0]

    class Manager:
        def __enter__(self):
            events.append("manager")
            return self

        def __exit__(self, *_args):
            events.append("manager_closed")

        def get_devices(self):
            return (
                []
                if scenario == "missing_device"
                else [
                    SimpleNamespace(
                        device_id=bench.DEVICE_ID,
                        is_simulation=scenario == "simulation",
                    )
                ]
            )

        def start_capture(self, *, device_id, device_configuration):
            assert device_id == bench.DEVICE_ID
            assert device_configuration == {
                "enabled_digital_channels": [0],
                "digital_sample_rate": 100_000_000,
            }
            return Capture()

        def get_app_info(self):
            return SimpleNamespace(app_version="fake")

    def connect(*, port, connect_timeout_seconds):
        assert port == 10430 and connect_timeout_seconds == 5
        return Manager()

    def run(command, *, capture_output, text, check, timeout):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            "/usr/bin/python3",
            "/tmp/blinka-pwm-oct6.abc123/state-eval/kernel_pwm_state_eval.py",
            "--mode",
            mode,
        ]
        assert capture_output and text and not check and timeout == 30
        if scenario == "timeout":
            raise subprocess.TimeoutExpired(command, timeout, b"partial", b"error")
        return subprocess.CompletedProcess(
            command,
            int(scenario == "helper_failure"),
            json.dumps(
                {
                    "mode": mode,
                    "sysfs_released": True,
                    "low_confirmed": scenario != "not_low",
                    "cleanup_errors": ["failed"] if scenario == "cleanup_error" else [],
                }
            ),
            "",
        )

    def analyze(directory, name):
        events.append("analysis")
        result = json.loads((directory / "results.json").read_text())
        assert result["mode"] == mode
        assert result["outputs"] == [
            {
                "gpio": 18,
                "saleae_channel": 0,
                "backend": "kernel-hardware-rp1",
            }
        ]
        report = {"accepted": scenario != "waveform_rejected"}
        (directory / name).write_text(json.dumps(report))
        return report

    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connect),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )
    monkeypatch.setattr(bench.subprocess, "run", run)
    monkeypatch.setattr(
        bench.time, "sleep", lambda duration: events.append(("tail", duration))
    )
    monkeypatch.setattr(bench, "write_analysis", analyze)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_state.py",
            str(tmp_path / "capture"),
            "--remote-root",
            "/tmp/blinka-pwm-oct6.abc123/state-eval",
            "--mode",
            mode,
        ],
    )
    if scenario == "success":
        bench.main()
    else:
        with pytest.raises(RuntimeError):
            bench.main()
    if scenario in ("missing_device", "simulation"):
        assert events == ["manager", "manager_closed"]
    else:
        expected = [
            "manager",
            "capture",
            "ssh",
            ("tail", 0.2),
            "stop",
            "save",
            "export",
            "capture_closed",
            "manager_closed",
        ]
        if scenario in ("success", "waveform_rejected"):
            expected.append("analysis")
        assert events == expected
        assert (tmp_path / "capture" / "remote.stdout").is_file()
        assert (tmp_path / "capture" / "remote.stderr").is_file()
        if scenario == "waveform_rejected":
            assert (
                json.loads((tmp_path / "capture" / "analysis.json").read_text())[
                    "accepted"
                ]
                is False
            )


@pytest.mark.parametrize(
    "remote_root",
    [
        "",
        "/tmp/",
        "/tmp/blinka-pwm-oct6.abc123/inverse-eval",
        "/tmp/blinka-pwm-oct6.abc123/state-eval/../other",
    ],
)
def test_wrong_directory_refused(monkeypatch, tmp_path, remote_root):
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "capture_kernel_pwm_state.py",
            str(tmp_path / "capture"),
            "--remote-root",
            remote_root,
            "--mode",
            "direct",
        ],
    )
    with pytest.raises(ValueError, match="isolated Pi 5"):
        bench.main()
    assert not (tmp_path / "capture").exists()
