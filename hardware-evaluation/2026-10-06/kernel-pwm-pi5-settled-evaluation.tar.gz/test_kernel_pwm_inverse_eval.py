"""Fake sysfs only: no Pi, GPIO libraries, subprocesses, or physical signals."""

import errno
import importlib.util
import json
import signal
import sys
from collections import Counter
from pathlib import Path

import pytest

import test_kernel_pwm_eval as common_fakes

SCRIPT = Path(__file__).with_name("kernel_pwm_inverse_eval.py")
spec = importlib.util.spec_from_file_location("kernel_pwm_inverse_eval", SCRIPT)
inverse = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = inverse
spec.loader.exec_module(inverse)
core = inverse.core


@pytest.fixture
def tree(tmp_path):
    return common_fakes.tree.__wrapped__(tmp_path)


class FakeIO(core.SysfsIO):
    def __init__(self):
        self.log = []
        self.counts = Counter()
        self.fail = None
        self.read_fail = None
        self.hook = None

    @property
    def writes(self):
        return [(path.name, value) for path, value in self.log]

    def write(self, path, value):
        self.log.append((path, value))
        self.counts[path.name] += 1
        if self.fail == (path.name, self.counts[path.name]):
            raise OSError(f"injected {path.name} failure")
        if path.name == "export":
            channel = path.parent / f"pwm{value}"
            if channel.exists():
                raise OSError(errno.EBUSY, "already requested")
            channel.mkdir()
            for name, initial in (
                ("period", 0),
                ("duty_cycle", 0),
                ("enable", 0),
                ("polarity", "normal"),
            ):
                (channel / name).write_text(str(initial))
        elif path.name == "unexport":
            channel = path.parent / f"pwm{value}"
            for name in ("period", "duty_cycle", "enable", "polarity"):
                (channel / name).unlink()
            channel.rmdir()
        else:
            if path.name == "polarity" and super().read(path.parent / "enable") != "0":
                raise OSError("test requires disabled polarity changes")
            if (
                path.name == "duty_cycle"
                and int(super().read(path.parent / "period")) <= 0
            ):
                raise OSError("period must be positive before duty write")
            super().write(path, value)
        if self.hook:
            self.hook(path, value)

    def read(self, path):
        if self.read_fail == path.name:
            raise OSError(f"injected {path.name} read failure")
        return super().read(path)


@pytest.fixture
def provider(tree):
    return core.discover(tree[1], tree[0])[1][0]


@pytest.fixture(autouse=True)
def no_sleep_or_physical_signals(monkeypatch):
    monkeypatch.setattr(inverse.time, "sleep", lambda _seconds: None)
    monkeypatch.setattr(inverse.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(inverse.signal, "signal", lambda _sig, _handler: signal.SIG_DFL)


def make_channel(provider, **kwargs):
    io = kwargs.pop("io", FakeIO())
    channel = inverse.InversePWMChannel(provider, io=io, **kwargs)
    return channel, io


def configure_experiment(tree, monkeypatch, *, snapshots=None, guard=None):
    found = core.discover(tree[1], tree[0])[1]
    monkeypatch.setattr(
        core, "discover", lambda: ("Raspberry Pi 5 Model B Rev 1.0", found)
    )
    monkeypatch.setattr(core, "debug_metadata", lambda: {"fake": True})
    if snapshots is None:
        monkeypatch.setattr(
            core,
            "system_snapshot",
            lambda: {
                "temperature_millic": "42000",
                "throttled": "throttled=0x0",
            },
        )
    else:
        snapshots = iter(snapshots)
        monkeypatch.setattr(core, "system_snapshot", lambda: next(snapshots))
    io = FakeIO()
    monkeypatch.setattr(core, "SysfsIO", lambda: io)
    if guard is not None:
        monkeypatch.setattr(core, "SafetySignals", lambda: guard)
    return found, io


def test_approved_provider_only_and_no_existing_export(provider, tree):
    found = core.discover(tree[1], tree[0])[1]
    io = FakeIO()
    with pytest.raises(core.BenchError, match="Only GPIO18"):
        inverse.InversePWMChannel(found[1], io=io)
    assert io.log == []
    provider.channel_path.mkdir()
    with pytest.raises(core.BenchError, match="existing exported"):
        inverse.InversePWMChannel(provider, io=io)
    assert io.log == []


def test_initialization_and_inverse_zero_readback(provider):
    channel, io = make_channel(provider)
    assert io.writes == [
        ("export", 2),
        ("enable", 0),
        ("polarity", "normal"),
        ("period", 20_000_000),
        ("duty_cycle", 0),
        ("enable", 1),
    ]
    io.log.clear()
    state = channel.transition("inversed", 0)
    assert state == {
        "period": 20_000_000,
        "duty_cycle": 0,
        "polarity": "inversed",
        "enable": 1,
    }
    assert io.writes == [
        ("enable", 0),
        ("polarity", "inversed"),
        ("duty_cycle", 0),
        ("enable", 1),
    ]
    with pytest.raises(core.BenchError, match="Unexpected GPIO18"):
        channel.readback("normal", 0, 1)
    channel.close()
    assert channel.released and channel.cleanup_low_confirmed


def test_same_polarity_normal_controls_do_not_toggle_enable(provider):
    channel, io = make_channel(provider)
    io.log.clear()
    channel.transition("normal", channel.active_duty_ns)
    channel.transition("normal", 0)
    assert io.writes == [("duty_cycle", channel.active_duty_ns), ("duty_cycle", 0)]
    channel.close()


@pytest.mark.parametrize(
    "polarity,duty",
    [
        ("inverse", 0),
        ("inverted", 0),
        ("inversed", 1499961),
        ("normal", 20_000_000),
    ],
)
def test_unapproved_transitions_refused_before_writes(provider, polarity, duty):
    channel, io = make_channel(provider)
    count = len(io.log)
    with pytest.raises(core.BenchError):
        channel.transition(polarity, duty)
    assert len(io.log) == count
    channel.close()


def test_cleanup_from_inverse_requires_normal_low_before_release(provider):
    sleeps = []
    channel, io = make_channel(provider)
    channel.transition("inversed", 0)
    io.log.clear()
    original_sleep = inverse.time.sleep
    inverse.time.sleep = sleeps.append
    try:
        channel.close()
    finally:
        inverse.time.sleep = original_sleep
    assert io.writes == [
        ("enable", 0),
        ("polarity", "normal"),
        ("duty_cycle", 0),
        ("enable", 1),
        ("enable", 0),
        ("unexport", 2),
    ]
    assert sleeps == [0.1]
    assert channel.cleanup_final_readback == {
        "period": 20_000_000,
        "duty_cycle": 0,
        "polarity": "normal",
        "enable": 0,
    }
    assert not channel.path.exists() and channel.released and not channel.owned
    assert channel.cleanup_errors == []
    count = len(io.log)
    channel.close()
    assert len(io.log) == count


@pytest.mark.parametrize(
    "failure",
    [
        ("enable", 1),
        ("polarity", 1),
        ("period", 1),
        ("duty_cycle", 1),
        ("enable", 2),
    ],
)
def test_constructor_failure_preserves_error_and_recovers_registered_owner(
    provider, failure
):
    io = FakeIO()
    io.fail = failure
    registry, errors = [], []
    with pytest.raises(OSError, match=f"injected {failure[0]} failure"):
        inverse.InversePWMChannel(
            provider, io=io, register=registry.append, cleanup_errors=errors
        )
    assert len(registry) == 1
    assert registry[0].released and registry[0].cleanup_low_confirmed
    assert not provider.channel_path.exists()
    assert errors == []


def test_export_failure_never_borrows_or_unexports(provider):
    io = FakeIO()
    io.fail = ("export", 1)
    errors, registry = [], []
    with pytest.raises(OSError, match="injected export"):
        inverse.InversePWMChannel(
            provider, io=io, register=registry.append, cleanup_errors=errors
        )
    assert io.writes == [("export", 2)]
    assert not registry[0].owned and not registry[0].released
    assert errors == []


@pytest.mark.parametrize(
    "failure",
    [
        ("polarity", 1),
        ("duty_cycle", 1),
        ("enable", 2),
    ],
)
def test_failed_inverse_transition_preserves_primary_and_safe_cleanup(
    provider, failure
):
    channel, io = make_channel(provider)
    io.counts.clear()
    io.fail = failure
    with pytest.raises(OSError, match=f"injected {failure[0]} failure"):
        try:
            channel.transition("inversed", 0)
        finally:
            channel.close()
    assert channel.released and channel.cleanup_low_confirmed
    assert channel.cleanup_errors == []
    assert any(event["status"] == "error" for event in channel.events)


@pytest.mark.parametrize(
    "failure",
    [
        ("enable", 1),
        ("polarity", 1),
        ("duty_cycle", 1),
        ("enable", 2),
        ("enable", 3),
        ("unexport", 1),
    ],
)
def test_each_cleanup_write_failure_is_reported_and_retains_owned_export(
    provider, failure
):
    channel, io = make_channel(provider)
    channel.transition("inversed", 0)
    io.log.clear()
    io.counts.clear()
    io.fail = failure
    channel.close()
    assert channel.cleanup_errors
    assert any("injected" in error for error in channel.cleanup_errors)
    assert channel.owned and not channel.released and channel.path.exists()
    if failure[0] in ("polarity", "duty_cycle") or failure == ("enable", 1):
        assert ("enable", 1) not in io.writes
    if failure != ("unexport", 1):
        assert ("unexport", 2) not in io.writes
    assert any(event["status"] == "error" for event in channel.events)


@pytest.mark.parametrize("attribute", ["polarity", "duty_cycle", "period", "enable"])
def test_cleanup_read_failure_retains_export_and_still_attempts_disable(
    provider, attribute
):
    channel, io = make_channel(provider)
    channel.transition("inversed", 0)
    io.log.clear()
    io.read_fail = attribute
    channel.close()
    assert channel.owned and not channel.released and channel.path.exists()
    assert io.writes[-1] == ("enable", 0)
    assert ("enable", 1) not in io.writes
    assert ("unexport", 2) not in io.writes
    assert channel.cleanup_errors


def test_signal_in_export_is_deferred_until_owner_and_registry_are_latched(provider):
    guard, io, registry = core.SafetySignals(), FakeIO(), []
    io.hook = lambda path, _value: (
        guard.handler(signal.SIGTERM, None) if path.name == "export" else None
    )
    with pytest.raises(core.SafetyAbort, match="ownership transition"):
        inverse.InversePWMChannel(
            provider, io=io, guard=guard, register=registry.append
        )
    assert len(registry) == 1 and registry[0].released
    assert ("unexport", 2) in io.writes
    assert guard.received == [signal.SIGTERM]


def test_repeated_signals_do_not_interrupt_cleanup(provider):
    guard = core.SafetySignals()
    channel, io = make_channel(provider, guard=guard)
    channel.transition("inversed", 0)
    io.hook = lambda _path, _value: guard.handler(signal.SIGTERM, None)
    channel.close()
    assert channel.released and channel.cleanup_errors == []
    assert len(guard.received) == 6 and guard.depth == 0
    with pytest.raises(core.SafetyAbort):
        guard.handler(signal.SIGINT, None)


def test_success_fixed_phases_provenance_and_only_header_exports(tree, monkeypatch):
    found, io = configure_experiment(tree, monkeypatch)
    sleeps = []
    monkeypatch.setattr(inverse.time, "sleep", sleeps.append)
    result = inverse.experiment()
    assert result["mode"] == "inverse-endpoints"
    assert result["sysfs_released"] and result["low_confirmed"]
    assert result["helper_pid"] > 0 and result["hard_max_run_seconds"] == 14
    assert result["burner_pids"] == [] and result["cleanup_errors"] == []
    assert sum(
        phase["duration_seconds"] for phase in result["phases"]
    ) == pytest.approx(2.4)
    assert [phase["name"] for phase in result["phases"]] == [
        phase[0] for phase in inverse.PHASES
    ]
    assert sleeps == [0.1] + [phase[1] for phase in inverse.PHASES] + [0.1]
    assert [(path, value) for path, value in io.log if path.name == "export"] == [
        (found[0].chip / "export", 2)
    ]
    assert all(
        path.parent in (found[0].chip, found[0].channel_path) for path, _value in io.log
    )
    assert all(not provider.channel_path.exists() for provider in found)
    assert result["discovered_untouched_outputs"] == [found[1].identity()]
    assert result["outputs"][0]["cleanup_final_readback"]["polarity"] == "normal"
    assert set(result["metadata"]["source_sha256"]) == {
        "kernel_pwm_inverse_eval.py",
        "kernel_pwm_eval.py",
    }
    assert all(
        len(value) == 64 for value in result["metadata"]["source_sha256"].values()
    )
    for phase in result["phases"]:
        assert phase["sysfs_readbacks"] == phase["end_readbacks"]
        assert (
            phase["transition_begin_ns"] <= phase["stable_begin_ns"] <= phase["end_ns"]
        )
        state = phase["sysfs_readbacks"]["18"]
        assert (
            state["polarity"] == phase["polarity"]
            and state["duty_cycle"] == phase["duty_ns"]
        )
        assert state["enable"] == 1
    assert [
        phase["polarity"]
        for phase in result["phases"]
        if phase["intent"] == "constant_high"
    ] == ["inversed"] * 2
    assert all(
        value != 20_000_000 for path, value in io.log if path.name == "duty_cycle"
    )


@pytest.mark.parametrize(
    "snapshot",
    [
        {},
        {"temperature_millic": "66000", "throttled": "throttled=0x0"},
        {"temperature_millic": "42000", "throttled": "throttled=0x10000"},
    ],
)
def test_thermal_preflight_is_fail_closed_before_export(tree, monkeypatch, snapshot):
    _found, io = configure_experiment(tree, monkeypatch, snapshots=[snapshot, snapshot])
    with pytest.raises(core.BenchError, match="Thermal preflight"):
        inverse.experiment()
    assert io.log == []


def test_postrun_thermal_failure_releases_low_but_emits_no_json(
    tree, monkeypatch, capsys
):
    safe = {"temperature_millic": "42000", "throttled": "throttled=0x0"}
    hot = {"temperature_millic": "76000", "throttled": "throttled=0x0"}
    found, _io = configure_experiment(tree, monkeypatch, snapshots=[safe, hot])
    assert inverse.main([]) == 1
    captured = capsys.readouterr()
    assert captured.out == "" and "Post-run thermal" in captured.err
    assert not found[0].channel_path.exists()


@pytest.mark.parametrize("during_cleanup", [False, True])
def test_signal_abort_restores_low_and_never_returns_success(
    tree, monkeypatch, capsys, during_cleanup
):
    guard = core.SafetySignals()
    found, io = configure_experiment(tree, monkeypatch, guard=guard)

    def interrupt(path, value):
        if (during_cleanup and path.name == "unexport") or (
            not during_cleanup and path.name == "polarity" and value == "inversed"
        ):
            guard.handler(signal.SIGTERM, None)

    io.hook = interrupt
    assert inverse.main([]) == 1
    captured = capsys.readouterr()
    assert captured.out == "" and "SafetyAbort" in captured.err
    assert not found[0].channel_path.exists()
    assert io.writes[-6:] == [
        ("enable", 0),
        ("polarity", "normal"),
        ("duty_cycle", 0),
        ("enable", 1),
        ("enable", 0),
        ("unexport", 2),
    ]


def test_cleanup_failure_blocks_json_and_primary_error_is_not_replaced(
    tree, monkeypatch, capsys
):
    found, io = configure_experiment(tree, monkeypatch)
    original_write = io.write

    def failure(path, value):
        if path.name == "polarity" and value == "inversed":
            io.fail = ("duty_cycle", io.counts["duty_cycle"] + 1)
            raise ValueError("primary transition error")
        original_write(path, value)

    io.write = failure
    assert inverse.main([]) == 1
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "ValueError: primary transition error" in captured.err
    assert "Cleanup failures:" in captured.err and "injected duty_cycle" in captured.err
    assert found[0].channel_path.exists()


def test_cli_success_is_machine_readable(monkeypatch, capsys):
    monkeypatch.setattr(inverse, "experiment", lambda: {"mode": inverse.MODE})
    assert inverse.main([]) == 0
    captured = capsys.readouterr()
    assert json.loads(captured.out) == {"mode": "inverse-endpoints"}
    assert captured.err == ""
