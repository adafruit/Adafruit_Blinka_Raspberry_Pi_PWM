"""Bounded fake sysfs and synthetic digital evidence; no GPIO or SSH."""

import copy
import json
import signal

import pytest

import analyze_kernel_pwm_settled as analyzer
import analyze_kernel_pwm_state as base
import test_kernel_pwm_settled_eval as helper_fakes
from test_kernel_pwm_inverse_waveforms import binary_export, saved_capture
from test_kernel_pwm_state_waveforms import edges_for


def replace_metadata(directory, metadata):
    (directory / "results.json").write_text(json.dumps(metadata))
    (directory / "remote.stdout").write_text(json.dumps(metadata["remote"]))


@pytest.fixture
def fake_result(tmp_path, monkeypatch):
    """Run the actual helper solely against the existing fake filesystem."""
    helper = helper_fakes.settled
    tick = 80_000_000_000

    def now():
        nonlocal tick
        tick += 1000
        return tick

    def sleep(duration):
        nonlocal tick
        tick += round(duration * 1e9)

    monkeypatch.setattr(helper.time, "monotonic_ns", now)
    monkeypatch.setattr(helper.time, "sleep", sleep)
    monkeypatch.setattr(helper.state.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(
        helper.state.signal, "signal", lambda _sig, _handler: signal.SIG_DFL
    )
    tree = helper_fakes.state_fakes.inverse_fakes.common_fakes.tree.__wrapped__(
        tmp_path
    )
    helper_fakes.configure_experiment(tree, monkeypatch)

    def generate(mode):
        remote = helper.experiment(mode)
        # Fake provider paths are mapped to synthetic bench identities solely
        # for fixtures. Every action/readback/wait comes from the actual helper.
        for output in remote["outputs"]:
            fake_chip = output["chip"]
            output["chip"] = "/sys/class/pwm/pwmchip1"
            output["of_node"] = (
                "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/pwm@98000"
            )
            for event in output["sysfs_events"]:
                if "path" in event:
                    event["path"] = event["path"].replace(fake_chip, output["chip"], 1)
        return {
            "mode": mode,
            "host": "test-pi5.local",
            "sample_rate_hz": 100_000_000,
            "transition_strategy": analyzer.STRATEGY,
            "production_backend_unchanged": True,
            "providers_left_loaded_until_reboot": True,
            "outputs": [
                {"gpio": 18, "saleae_channel": 0, "backend": "kernel-hardware-rp1"}
            ],
            "remote": remote,
        }

    return generate


def fixture_files(directory, metadata, *, edges=None):
    replace_metadata(directory, metadata)
    saved_capture(directory / "waveform.sal")
    mode = metadata["mode"]
    binary_export(
        directory / "digital_0.bin",
        edges_for(mode) if edges is None else edges,
        end=3.8 if mode == "direct" else 3.2,
    )
    return directory


@pytest.mark.parametrize("mode", ["direct", "frequency", "lifecycle"])
def test_real_fake_helper_audit_and_unchanged_physical_predicate(
    tmp_path, fake_result, mode
):
    metadata = fake_result(mode)
    untouched = copy.deepcopy(metadata)
    report = analyzer.analyze(fixture_files(tmp_path, metadata))
    assert report["accepted"] is True, report["rejection_reasons"]
    assert report["enabled_settled_audit_validated"] is True
    assert set(report["source_sha256_reported"]) == analyzer.SOURCE_NAMES
    assert report["physical"] == base.waveform_facts(mode, {}, edges_for(mode))
    assert metadata == untouched


@pytest.mark.parametrize("width_ns", [10, 20])
def test_high_dip_is_preserved_and_rejected(tmp_path, fake_result, width_ns):
    metadata = fake_result("direct")
    edges = sorted(edges_for("direct") + [2.5002, 2.5002 + width_ns / 1e9])
    report = analyzer.write_analysis(fixture_files(tmp_path, metadata, edges=edges))
    assert report["accepted"] is False
    assert len(report["physical"]["sub_microsecond_low_runs"]) == 1
    assert json.loads((tmp_path / "analysis.json").read_text())["accepted"] is False


def test_partial_boundary_pulse_is_not_trimmed(tmp_path, fake_result):
    edges = sorted(edges_for("direct") + [0.795, 0.7951])
    report = analyzer.analyze(
        fixture_files(tmp_path, fake_result("direct"), edges=edges)
    )
    assert not report["accepted"]
    assert len(report["physical"]["unexpected_high_runs"]) == 1
    assert report["physical"]["no_transition_trimming_or_glitch_filtering"]


def test_inversion_before_wait_finishes_is_invalid(tmp_path, fake_result):
    metadata = fake_result("direct")
    remote = metadata["remote"]
    wait = remote["strategy_waits"][0]
    inversion = next(
        event
        for event in remote["outputs"][0]["sysfs_events"]
        if event.get("scope") == wait["scope"] and event.get("attribute") == "polarity"
    )
    inversion["begin_ns"] = wait["end_ns"] - 2000
    inversion["end_ns"] = wait["end_ns"] - 1000
    fixture_files(tmp_path, metadata)
    with pytest.raises(ValueError, match="overlaps a strategy wait"):
        analyzer.analyze(tmp_path)


def test_period_shrink_at_nonzero_duty_is_invalid(tmp_path, fake_result):
    metadata = fake_result("frequency")
    events = metadata["remote"]["outputs"][0]["sysfs_events"]
    zero = next(
        event
        for event in events
        if event.get("scope") == "pwm500_d32768"
        and event.get("attribute") == "duty_cycle"
        and event.get("value") == 0
    )
    zero["value"] = 1_499_961
    fixture_files(tmp_path, metadata)
    with pytest.raises(ValueError, match="readback differs|zero duty"):
        analyzer.analyze(tmp_path)


@pytest.mark.parametrize(
    "tamper", ["missing_export", "released_false", "wrong_channel"]
)
def test_release_cannot_borrow_ownership(tmp_path, fake_result, tamper):
    metadata = fake_result("lifecycle")
    output = metadata["remote"]["outputs"][1]
    if tamper == "missing_export":
        output["sysfs_events"].pop(0)
    elif tamper == "released_false":
        output["released"] = False
    else:
        output["sysfs_events"][0]["value"] = 3
    fixture_files(tmp_path, metadata)
    with pytest.raises(ValueError):
        analyzer.analyze(tmp_path)


@pytest.mark.parametrize(
    "tamper",
    ["short_wait", "missing_wait", "wrong_generation", "extra_hash", "wrong_marker"],
)
def test_required_strategy_evidence_is_strict(tmp_path, fake_result, tamper):
    metadata = fake_result("direct")
    remote = metadata["remote"]
    if tamper == "short_wait":
        remote["strategy_waits"][0]["end_ns"] -= 1_000_000
    elif tamper == "missing_wait":
        remote["strategy_waits"].pop(0)
    elif tamper == "wrong_generation":
        remote["strategy_waits"][0]["generation"] = 2
    elif tamper == "extra_hash":
        remote["metadata"]["source_sha256"]["other.py"] = "a" * 64
    else:
        metadata["transition_strategy"] = "settled-enabled"
    fixture_files(tmp_path, metadata)
    original = base.validate_events
    with pytest.raises(ValueError):
        analyzer.analyze(tmp_path)
    assert base.validate_events is original


def test_writer_exclusive_and_no_path_escape(tmp_path, fake_result):
    fixture_files(tmp_path, fake_result("direct"))
    analyzer.write_analysis(tmp_path)
    with pytest.raises(FileExistsError):
        analyzer.write_analysis(tmp_path)
    with pytest.raises(ValueError, match="filename inside"):
        analyzer.write_analysis(tmp_path, "../analysis.json")
