"""Offline GPIO18 state/frequency/lifecycle checks; never connect to hardware.

All threshold transitions are retained. A waveform rejection is saved with
accepted=false and measured facts; invalid metadata or saved settings raise.
Pi phase clocks are not aligned with Saleae, so no command latency is inferred.
"""

import argparse
import itertools
import json
import math
import re
from pathlib import Path

from analyze_kernel_pwm_inverse import read_continuous, require, validate_saved_capture
from capture_pwm import describe, thermal_issues

SEQUENCES = {
    "direct": (
        ("low50_initial", 0.2, 50, 0),
        ("control50_d4915", 0.4, 50, 4915),
        ("high50_first", 0.3, 50, 65535),
        ("recovery50_d4915", 0.4, 50, 4915),
        ("high50_second", 0.3, 50, 65535),
        ("recovery500_d32768", 0.4, 500, 32768),
        ("high500", 0.3, 500, 65535),
        ("high50_after_frequency", 0.3, 50, 65535),
        ("recovery50_final_d4915", 0.4, 50, 4915),
        ("low50_final", 0.2, 50, 0),
    ),
    "frequency": (
        ("low50_initial", 0.2, 50, 0),
        ("pwm50_d4915_initial", 0.4, 50, 4915),
        ("pwm500_d32768", 0.4, 500, 32768),
        ("pwm50_d4915_recovery", 0.4, 50, 4915),
        ("low50_before_high", 0.2, 50, 0),
        ("high50_first", 0.3, 50, 65535),
        ("high500", 0.3, 500, 65535),
        ("high50_after_frequency", 0.3, 50, 65535),
        ("low50_final", 0.2, 50, 0),
    ),
    "lifecycle": (
        ("generation1_low50", 0.2, 50, 0),
        ("generation1_pwm50_d4915", 0.4, 50, 4915),
        ("generation1_high50", 0.3, 50, 65535),
        ("generation2_low50", 0.2, 50, 0),
        ("generation2_pwm500_d32768", 0.4, 500, 32768),
        ("generation2_high500", 0.3, 500, 65535),
    ),
}
PATTERNS = {
    "direct": (
        "servo50",
        "constant_high",
        "servo50",
        "constant_high",
        "half500",
        "constant_high",
        "servo50",
    ),
    "frequency": ("servo50", "half500", "servo50", "constant_high"),
    "lifecycle": ("servo50", "constant_high", "half500", "constant_high"),
}
HOLD_DURATIONS = {
    "direct": (0.3, 0.3, 0.6),
    "frequency": (0.9,),
    "lifecycle": (0.3, 0.3),
}
PULSE_TARGETS = {"servo50": (50, 4915), "half500": (500, 32768)}
SAMPLE_RATE_HZ = 100_000_000


def state_for(frequency, logical, enable=1):
    period = 1_000_000_000 // frequency
    return {
        "period": period,
        "duty_cycle": 0 if logical == 65535 else period * logical // 65535,
        "polarity": "inversed" if logical == 65535 else "normal",
        "enable": enable,
    }


def validate_metadata(metadata, remote):
    require(
        isinstance(metadata, dict) and isinstance(remote, dict),
        "Metadata must be objects",
    )
    mode = metadata.get("mode")
    require(
        mode in SEQUENCES and remote.get("mode") == mode, "Unexpected state test mode"
    )
    require(
        metadata.get("remote") == remote, "remote.stdout disagrees with results.json"
    )
    require(metadata.get("host") == "test-pi5.local", "Expected Pi 5 bench host")
    require(
        type(metadata.get("sample_rate_hz")) is int
        and metadata["sample_rate_hz"] == SAMPLE_RATE_HZ,
        "State tests require 100 MSa/s",
    )
    require(
        metadata.get("production_backend_unchanged") is True
        and metadata.get("providers_left_loaded_until_reboot") is True,
        "Expected unchanged production backend and retained temporary providers",
    )
    require(
        metadata.get("outputs")
        == [{"gpio": 18, "saleae_channel": 0, "backend": "kernel-hardware-rp1"}],
        "State captures require GPIO18/channel0 only",
    )
    require(
        remote.get("schema_version") == 1
        and isinstance(remote.get("model"), str)
        and remote["model"].startswith("Raspberry Pi 5 Model B"),
        "Expected Pi 5 helper schema1",
    )
    require(
        remote.get("sysfs_released") is True
        and remote.get("low_confirmed") is True
        and remote.get("cleanup_errors") == []
        and remote.get("burner_pids") == [],
        "Cleanup/release/low confirmation or no-load contract failed",
    )
    require(
        remote.get("hard_max_run_seconds") == 14,
        "Expected 14 s normal-operation watchdog",
    )
    begin, end = remote.get("begin_ns"), remote.get("end_ns")
    require(
        type(begin) is int and type(end) is int and 0 <= begin < end,
        "Invalid remote run bounds",
    )
    phases = remote.get("phases")
    require(
        isinstance(phases, list) and len(phases) == len(SEQUENCES[mode]),
        "Unexpected phase count",
    )
    previous_end = begin
    for index, (phase, spec) in enumerate(zip(phases, SEQUENCES[mode])):
        name, duration, frequency, logical = spec
        generation = 2 if mode == "lifecycle" and index >= 3 else 1
        state = state_for(frequency, logical)
        intent = (
            "constant_high"
            if logical == 65535
            else "low"
            if logical == 0
            else "interior_pwm"
        )
        require(
            isinstance(phase, dict)
            and all(
                phase.get(key) == value
                for key, value in {
                    "name": name,
                    "generation": generation,
                    "frequency": frequency,
                    "duty_u16": logical,
                    "period_ns": state["period"],
                    "duty_ns": state["duty_cycle"],
                    "polarity": state["polarity"],
                    "intent": intent,
                }.items()
            ),
            f"Phase {index} name/generation/frequency/duty/state differs from protocol",
        )
        value = phase.get("duration_seconds")
        require(
            type(value) in (int, float)
            and math.isfinite(value)
            and math.isclose(value, duration, rel_tol=0, abs_tol=1e-9),
            f"Phase {index} duration mismatch",
        )
        ticks = [
            phase.get(key)
            for key in (
                "begin_ns",
                "transition_begin_ns",
                "stable_begin_ns",
                "end_ns",
                "readback_end_ns",
            )
        ]
        require(
            all(type(tick) is int for tick in ticks)
            and previous_end
            <= ticks[0]
            == ticks[1]
            <= ticks[2]
            < ticks[3]
            <= ticks[4]
            <= end,
            f"Phase {index} clocks invalid or unordered",
        )
        require(
            duration - 1e-6 <= (ticks[3] - ticks[2]) / 1e9 <= duration + 1,
            f"Phase {index} stable duration inconsistent with request",
        )
        previous_end = ticks[4]
        require(
            phase.get("sysfs_readbacks") == phase.get("end_readbacks") == {"18": state},
            f"Phase {index} readbacks do not confirm exact requested state",
        )
    outputs = remote.get("outputs")
    count = 2 if mode == "lifecycle" else 1
    require(
        isinstance(outputs, list) and len(outputs) == count,
        "Unexpected output generation count",
    )
    for generation, output in enumerate(outputs, 1):
        require(
            isinstance(output, dict)
            and output.get("generation") == generation
            and output.get("gpio") == 18
            and output.get("channel") == 2
            and output.get("backend") == "rp1-pwm"
            and output.get("compatible") == ["raspberrypi,rp1-pwm"]
            and output.get("gpio_of_node") is None
            and isinstance(output.get("of_node"), str)
            and output["of_node"].endswith("/rp1/pwm@98000")
            and isinstance(output.get("chip"), str)
            and re.fullmatch(r"/sys/class/pwm/pwmchip[0-9]+", output["chip"]),
            "Provider must be approved header RP1 PWM0/channel2 generation",
        )
        own_phases = [phase for phase in phases if phase["generation"] == generation]
        require(
            output.get("last_requested_frequency") == own_phases[-1]["frequency"]
            and output.get("last_requested_duty_u16") == own_phases[-1]["duty_u16"],
            "Output last-requested state disagrees with generation phases",
        )
        require(
            output.get("frequency") == 50
            and output.get("period_ns") == 20_000_000
            and output.get("released") is True
            and output.get("cleanup_low_confirmed") is True
            and output.get("cleanup_final_readback") == state_for(50, 0, 0),
            "Each generation must restore normal-zero 20ms disabled state and release",
        )
        validate_events(output, own_phases, begin, end)
    quiet = remote.get("lifecycle_quiet_intervals")
    if mode != "lifecycle":
        require(quiet == [], "Quiet generation interval belongs only to lifecycle mode")
    else:
        require(
            isinstance(quiet, list) and len(quiet) == 1 and isinstance(quiet[0], dict),
            "Lifecycle requires one quiet released-generation interval",
        )
        interval = quiet[0]
        first_end = outputs[0]["sysfs_events"][-1]["end_ns"]
        second_begin = outputs[1]["sysfs_events"][0]["begin_ns"]
        q_begin, q_end = interval.get("begin_ns"), interval.get("end_ns")
        require(
            interval.get("after_generation") == 1
            and interval.get("duration_seconds") == 0.2
            and interval.get("sysfs_released") is True
            and type(q_begin) is int
            and type(q_end) is int
            and first_end <= q_begin < q_end <= second_begin
            and 0.2 - 1e-6 <= (q_end - q_begin) / 1e9 <= 1.2,
            "Lifecycle quiet interval must separate successful release and fresh export",
        )
        require(
            outputs[0]["chip"] == outputs[1]["chip"]
            and outputs[0]["of_node"] == outputs[1]["of_node"],
            "Lifecycle generations must use the same provider",
        )
    for when, limit in (("before", 65000), ("after", 75000)):
        thermal = remote.get("thermal")
        snapshot = thermal.get(when) if isinstance(thermal, dict) else None
        require(
            isinstance(snapshot, dict) and not thermal_issues(snapshot, limit),
            "Remote thermal/firmware gate failed",
        )
    provenance = remote.get("metadata")
    hashes = provenance.get("source_sha256") if isinstance(provenance, dict) else None
    require(
        isinstance(hashes, dict)
        and set(hashes)
        == {
            "kernel_pwm_eval.py",
            "kernel_pwm_inverse_eval.py",
            "kernel_pwm_state_eval.py",
        }
        and all(
            isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
            for value in hashes.values()
        ),
        "Missing exact helper source SHA256 provenance",
    )
    return mode


def validate_events(output, phases, begin, end):
    events = output.get("sysfs_events")
    require(isinstance(events, list) and events, "Missing sysfs event audit")
    state, owned, exports, unexports, previous = {}, False, 0, 0, begin
    scopes = {phase["name"]: phase for phase in phases}
    reads = {name: [] for name in scopes}
    cleanup_reads = []
    allowed = {
        "period": (2_000_000, 20_000_000),
        "duty_cycle": (0, 1_499_961, 1_000_015),
        "polarity": ("normal", "inversed"),
        "enable": (0, 1),
    }
    for event in events:
        require(
            isinstance(event, dict)
            and event.get("status") == "ok"
            and event.get("operation") in ("write", "readback")
            and event.get("scope")
            in ("initialization", "cleanup_period_recovery", "cleanup", *scopes),
            "Audit operation/status/scope invalid",
        )
        start, finish = event.get("begin_ns"), event.get("end_ns")
        require(
            type(start) is int
            and type(finish) is int
            and previous <= start <= finish <= end,
            "Audit clocks invalid or unordered",
        )
        previous = finish
        scope = event["scope"]
        if scope in scopes:
            phase = scopes[scope]
            require(
                phase["begin_ns"] <= start <= finish <= phase["readback_end_ns"],
                "Audit event outside phase",
            )
        elif scope == "initialization":
            require(
                finish <= phases[0]["begin_ns"], "Initialization audit overlaps phases"
            )
        else:
            require(
                start >= phases[-1]["readback_end_ns"], "Cleanup audit overlaps phases"
            )
        if event["operation"] == "write":
            attribute, value = event.get("attribute"), event.get("value")
            if attribute in ("export", "unexport"):
                require(
                    event.get("path") == f"{output['chip']}/{attribute}" and value == 2,
                    "Ownership writes must target approved channel2",
                )
                if attribute == "export":
                    require(
                        not owned and not exports and scope == "initialization",
                        "Fresh ownership audit failed",
                    )
                    owned, exports = True, 1
                else:
                    require(
                        owned
                        and not unexports
                        and scope == "cleanup"
                        and state == state_for(50, 0, 0),
                        "Unexport must follow normal-low restored disabled state",
                    )
                    owned, unexports = False, 1
            else:
                require(
                    owned
                    and attribute in allowed
                    and value in allowed[attribute]
                    and event.get("path") == f"{output['chip']}/pwm2/{attribute}",
                    "Audit write path/attribute/value invalid",
                )
                require(
                    attribute != "polarity" or state.get("enable") == 0,
                    "Polarity must switch disabled",
                )
                require(
                    attribute != "period" or state.get("duty_cycle", 0) == 0,
                    "Period must change at zero duty",
                )
                state[attribute] = value
                require(
                    state.get("polarity") != "inversed"
                    or state.get("duty_cycle", 0) == 0,
                    "Inversed state permits zero duty only",
                )
        else:
            require(
                owned
                and event.get("state") == event.get("expected") == state
                and set(state) == {"period", "duty_cycle", "polarity", "enable"},
                "Audit readback differs from expected/written state",
            )
            if scope in scopes:
                target = dict(phase["sysfs_readbacks"]["18"], enable=state["enable"])
                require(state == target, "Audit readback differs from phase state")
                reads[scope].append(event)
            elif scope == "cleanup" and state == state_for(50, 0):
                cleanup_reads.append(event)
    require(
        exports == unexports == 1
        and not owned
        and events[0].get("attribute") == "export"
        and events[-1].get("attribute") == "unexport",
        "Audit needs one fresh export/final unexport",
    )
    require(
        len(cleanup_reads) >= 2
        and cleanup_reads[-1]["begin_ns"] - cleanup_reads[0]["end_ns"] >= 90_000_000,
        "Audit lacks settled enabled normal-low cleanup",
    )
    for name, phase in scopes.items():
        enabled = [event for event in reads[name] if event["state"]["enable"] == 1]
        require(
            any(event["end_ns"] <= phase["stable_begin_ns"] for event in enabled)
            and any(event["begin_ns"] >= phase["end_ns"] for event in enabled),
            "Audit lacks phase start/end readbacks",
        )


def pulse_category(width):
    if width >= 0.1:
        return "constant_high"
    for category, (frequency, duty) in PULSE_TARGETS.items():
        target = state_for(frequency, duty)["duty_cycle"] / 1e9
        if target * 0.98 <= width <= target * 1.02:
            return category
    return "unexpected_high"


def waveform_facts(mode, waveform, edges):
    reasons, highs, lows = [], [], []
    for index, (rise, fall) in enumerate(zip(edges[::2], edges[1::2])):
        width = fall - rise
        highs.append(
            {
                "pair_index": index,
                "rise_seconds": rise,
                "fall_seconds": fall,
                "width_us": width * 1e6,
                "category": pulse_category(width),
            }
        )
    for fall, rise in zip(edges[1::2], edges[2::2]):
        lows.append(
            {
                "fall_seconds": fall,
                "rise_seconds": rise,
                "width_ns": (rise - fall) * 1e9,
            }
        )
    unexpected = [high for high in highs if high["category"] == "unexpected_high"]
    if unexpected:
        reasons.append(
            f"{len(unexpected)} unexpected/partial high pulses; no boundary pulse was trimmed"
        )
    tiny_lows = [low for low in lows if low["width_ns"] < 1000]
    if tiny_lows:
        reasons.append(
            f"{len(tiny_lows)} sub-microsecond captured low dips/boundary transients"
        )
    groups = []
    for category, values in itertools.groupby(highs, key=lambda high: high["category"]):
        values = list(values)
        group = {
            "category": category,
            "high_count": len(values),
            "first_pair_index": values[0]["pair_index"],
            "last_pair_index": values[-1]["pair_index"],
            "first_rise_seconds": values[0]["rise_seconds"],
            "last_fall_seconds": values[-1]["fall_seconds"],
        }
        if category in PULSE_TARGETS:
            frequency, _ = PULSE_TARGETS[category]
            periods = [
                (second["rise_seconds"] - first["rise_seconds"]) * 1e6
                for first, second in itertools.pairwise(values)
            ]
            group["high_us"] = describe([value["width_us"] for value in values])
            group["period_us"] = describe(periods) if periods else None
            if not periods or any(
                not 0.98 * 1e6 / frequency <= value <= 1.02 * 1e6 / frequency
                for value in periods
            ):
                reasons.append(
                    f"{category} train has irregular/incomplete periods; all periods were checked"
                )
            if abs(len(values) - round(0.4 * frequency)) > 1:
                reasons.append(
                    f"{category} train pulse count does not match a 0.4 s request within one cycle"
                )
        groups.append(group)
    observed = tuple(group["category"] for group in groups)
    if observed != PATTERNS[mode]:
        reasons.append(
            "Physical PWM/high-hold topology does not match requested sequence"
        )
    holds = [high for high in highs if high["category"] == "constant_high"]
    if len(holds) != len(HOLD_DURATIONS[mode]):
        reasons.append(
            "Constant-high hold count differs; a captured transition split or added a hold"
        )
    for index, (hold, target) in enumerate(zip(holds, HOLD_DURATIONS[mode])):
        width = hold["width_us"] / 1e6
        hold["sampling_only_width_bounds_seconds"] = [width - 1e-8, width + 1e-8]
        if not target - 0.05 <= width <= target + 0.05:
            reasons.append(
                f"High hold {index + 1} width does not match approximately {target:g} s"
            )
    boundaries = []
    for first, second in itertools.pairwise(groups):
        boundary = {
            "from_category": first["category"],
            "to_category": second["category"],
            "low_gap_seconds": second["first_rise_seconds"]
            - first["last_fall_seconds"],
        }
        if first["category"] in PULSE_TARGETS and second["category"] in PULSE_TARGETS:
            prior = highs[first["last_pair_index"]]
            following = highs[second["first_pair_index"]]
            period = following["rise_seconds"] - prior["rise_seconds"]
            boundary["rise_to_rise_seconds"] = period
            frequencies = [
                PULSE_TARGETS[group["category"]][0] for group in (first, second)
            ]
            if not any(
                0.98 / frequency <= period <= 1.02 / frequency
                for frequency in frequencies
            ):
                reasons.append(
                    "Frequency-change boundary period matches neither complete configured period"
                )
        boundaries.append(boundary)
    if (
        mode == "frequency"
        and observed == PATTERNS[mode]
        and not 0.15 <= boundaries[-1]["low_gap_seconds"] <= 0.27
    ):
        reasons.append(
            "Frequency test lacks normal-low separator before continuous high"
        )
    if (
        mode == "lifecycle"
        and observed == PATTERNS[mode]
        and not 0.45 <= boundaries[1]["low_gap_seconds"] <= 1.0
    ):
        reasons.append("Lifecycle lacks physical quiet/reopened-low interval")
    waveform["transition_seconds"] = list(edges)
    return {
        "accepted": not reasons,
        "rejection_reasons": reasons,
        "all_high_runs": highs,
        "all_interior_low_runs": lows,
        "unexpected_high_runs": unexpected,
        "sub_microsecond_low_runs": tiny_lows,
        "groups": groups,
        "boundaries": boundaries,
        "constant_high_holds": holds,
        "expected_topology": list(PATTERNS[mode]),
        "expected_constant_high_seconds": list(HOLD_DURATIONS[mode]),
        "phase_alignment_proven": False,
        "ordinary_width_period_tolerance_percent": 2,
        "no_transition_trimming_or_glitch_filtering": True,
    }


def analyze(directory):
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    remote = json.loads((directory / "remote.stdout").read_text())
    mode = validate_metadata(metadata, remote)
    settings = validate_saved_capture(directory / "waveform.sal")
    waveform, edges = read_continuous(directory / "digital_0.bin")
    physical = waveform_facts(mode, waveform, edges)
    return {
        "capture": directory.name,
        "mode": mode,
        "host": metadata["host"],
        "offline_analysis": True,
        "accepted": physical["accepted"],
        "rejection_reasons": physical["rejection_reasons"],
        "sample_rate_hz": SAMPLE_RATE_HZ,
        "saved_capture_settings": settings,
        "waveform": waveform,
        "physical": physical,
        "sysfs_released_reported": True,
        "cleanup_normal_low_confirmed_reported": True,
        "source_sha256_reported": remote["metadata"]["source_sha256"],
        "clock_alignment": "Pi monotonic phase clocks are not aligned to Saleae; no command latency claim.",
        "quantization": {
            "nominal_sample_interval_ns": 10,
            "timebase_calibrated": False,
            "width_bounds_include_clock_accuracy": False,
        },
        "limitation": "Finite 100 MSa/s digital threshold observation, no glitch filter: not analog proof "
        "or exclusion of sub-sample glitches. Every captured transition, including boundaries, is retained.",
    }


def write_analysis(directory, output_name="analysis.json"):
    require(
        bool(output_name)
        and Path(output_name).name == output_name
        and output_name not in (".", ".."),
        "Output must be a filename inside capture directory",
    )
    result = analyze(directory)
    with (Path(directory) / output_name).open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output-name", default="analysis.json")
    args = parser.parse_args()
    try:
        report = write_analysis(args.directory, args.output_name)
    except (ValueError, OSError) as error:
        parser.error(str(error))
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["accepted"] else 1)


if __name__ == "__main__":
    main()
