"""Only fake providers and temporary files; never invokes bench hardware."""

import errno
import importlib.util
import signal
import struct
import sys
from pathlib import Path

import pytest

SCRIPT = Path(__file__).with_name("kernel_pwm_eval.py")
spec = importlib.util.spec_from_file_location("kernel_pwm_eval", SCRIPT)
bench = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = bench
spec.loader.exec_module(bench)


def write_cells(path, *values):
    path.write_bytes(struct.pack(">" + "I" * len(values), *values))


@pytest.fixture
def tree(tmp_path):
    dt = tmp_path / "device-tree"
    dt.mkdir()
    (dt / "model").write_bytes(b"Raspberry Pi 5 Model B Rev 1.0\0")
    rp1 = dt / "axi" / "pcie@120000" / "rp1"
    gpio = rp1 / "gpio@d0000"
    gpio.mkdir(parents=True)
    (gpio / "compatible").write_bytes(b"raspberrypi,rp1-gpio\0")
    write_cells(gpio / "#gpio-cells", 2)
    write_cells(gpio / "phandle", 0x1234)
    header = rp1 / "pwm@98000"
    header.mkdir()
    (header / "compatible").write_bytes(b"raspberrypi,rp1-pwm\0")
    software = dt / "pwm-gpio"
    software.mkdir()
    (software / "compatible").write_bytes(b"pwm-gpio\0")
    write_cells(software / "gpios", 0x1234, 23, 0)
    fan = rp1 / "pwm@9c000"
    fan.mkdir()
    (fan / "compatible").write_bytes(b"raspberrypi,rp1-pwm\0")
    sysfs = tmp_path / "pwm"
    sysfs.mkdir()
    for index, node, count in ((8, header, 4), (2, software, 1), (11, fan, 4)):
        chip = sysfs / f"pwmchip{index}"
        (chip / "device").mkdir(parents=True)
        (chip / "device" / "of_node").symlink_to(node, target_is_directory=True)
        (chip / "npwm").write_text(str(count))
        (chip / "export").touch()
        (chip / "unexport").touch()
    return dt, sysfs


class FakeIO(bench.SysfsIO):
    def __init__(self, *, fail=None, export_busy=False):
        self.log = []
        self.fail = fail
        self.export_busy = export_busy

    def write(self, path, value):
        self.log.append((path.name, value))
        if path.name == "export":
            if self.export_busy:
                raise OSError(errno.EBUSY, "already requested")
            channel = path.parent / f"pwm{value}"
            channel.mkdir()
            for name, initial in (
                ("period", 0),
                ("duty_cycle", 0),
                ("enable", 0),
                ("polarity", "normal"),
            ):
                (channel / name).write_text(str(initial))
        elif path.name == "unexport":
            if self.fail == "unexport":
                raise OSError("injected unexport failure")
            channel = path.parent / f"pwm{value}"
            for name in ("period", "duty_cycle", "enable", "polarity"):
                (channel / name).unlink()
            channel.rmdir()
        else:
            if path.name == self.fail:
                raise OSError(f"injected {self.fail} failure")
            if (
                path.name == "duty_cycle"
                and int(self.read(path.parent / "period")) <= 0
            ):
                raise OSError("period must be positive before duty write")
            super().write(path, value)


def providers(tree):
    dt, sysfs = tree
    return bench.discover(sysfs, dt)[1]


def test_discovery_uses_identity_not_chip_number_and_excludes_fan(tree):
    model, found = bench.discover(tree[1], tree[0])
    assert model == "Raspberry Pi 5 Model B Rev 1.0"
    assert [
        (provider.gpio, provider.chip.name, provider.channel) for provider in found
    ] == [(18, "pwmchip8", 2), (23, "pwmchip2", 0)]
    assert found[1].gpio_of_node.endswith("gpio@d0000")


@pytest.mark.parametrize(
    "handle,pin,flags", [(0x9999, 23, 0), (0x1234, 22, 0), (0x1234, 23, 1)]
)
def test_gpio_provider_refuses_wrong_handle_pin_and_polarity(tree, handle, pin, flags):
    write_cells(tree[0] / "pwm-gpio" / "gpios", handle, pin, flags)
    with pytest.raises(bench.BenchError):
        bench.discover(tree[1], tree[0])


def test_pio_and_fan_are_not_approved_header_providers(tree):
    header = providers(tree)[0].of_node
    (header / "compatible").write_bytes(b"raspberrypi,rp1-pio\0")
    with pytest.raises(bench.BenchError, match="GPIO18"):
        bench.discover(tree[1], tree[0])


def test_wrong_model_and_preexisting_export_refused_without_writes(tree):
    found = providers(tree)
    found[0].channel_path.mkdir()
    with pytest.raises(bench.BenchError, match="existing exported"):
        bench.discover(tree[1], tree[0])
    io = FakeIO()
    with pytest.raises(bench.BenchError, match="existing exported"):
        bench.PWMChannel(found[0], 50, 4915, io=io)
    assert io.log == []
    (tree[0] / "model").write_bytes(b"Raspberry Pi 4 Model B Rev 1.0\0")
    with pytest.raises(bench.BenchError, match="Only Raspberry Pi 5"):
        bench.discover(tree[1], tree[0])


def test_fresh_export_sequence_and_close_are_low_then_disable_unexport(
    tree, monkeypatch
):
    sleeps = []
    monkeypatch.setattr(bench.time, "sleep", sleeps.append)
    io = FakeIO()
    channel = bench.PWMChannel(providers(tree)[0], 50, 4915, io=io)
    assert io.log == [
        ("export", 2),
        ("enable", 0),
        ("polarity", "normal"),
        ("period", 20_000_000),
        ("duty_cycle", 0),
        ("enable", 1),
    ]
    assert channel.readback(0, 1)["period"] == 20_000_000
    channel.set_duty(channel.period_ns)
    channel.close()
    assert io.log[-3:] == [("duty_cycle", 0), ("enable", 0), ("unexport", 2)]
    assert sleeps == [0.1, 0.1]
    assert channel.released and not channel.owned and not channel.path.exists()
    size = len(io.log)
    channel.close()
    assert len(io.log) == size


def test_export_ebusy_never_triggers_unexport(tree, monkeypatch):
    monkeypatch.setattr(bench.time, "sleep", lambda _seconds: None)
    io = FakeIO(export_busy=True)
    with pytest.raises(OSError) as error:
        bench.PWMChannel(providers(tree)[0], 50, 4915, io=io)
    assert error.value.errno == errno.EBUSY
    assert io.log == [("export", 2)]


def test_export_permission_ready_timeout_still_releases_own_export(tree, monkeypatch):
    monkeypatch.setattr(bench.time, "sleep", lambda _seconds: None)
    ticks = iter(range(100))
    monkeypatch.setattr(bench.time, "monotonic", lambda: next(ticks))
    monkeypatch.setattr(bench.os, "access", lambda _path, _mode: False)
    io = FakeIO()
    with pytest.raises(bench.BenchError, match="not readable/writable"):
        bench.PWMChannel(providers(tree)[0], 50, 4915, io=io)
    assert io.log[-1] == ("unexport", 2)
    assert not providers(tree)[0].channel_path.exists()


def test_constructor_rollback_preserves_primary_and_latches_cleanup_errors(
    tree, monkeypatch
):
    monkeypatch.setattr(bench.time, "sleep", lambda _seconds: None)
    io = FakeIO(fail="period")
    errors = []
    with pytest.raises(OSError, match="injected period failure"):
        bench.PWMChannel(providers(tree)[0], 50, 4915, io=io, cleanup_errors=errors)
    assert io.log[-3:] == [("duty_cycle", 0), ("enable", 0), ("unexport", 2)]
    assert errors and "low" in errors[0]
    assert not providers(tree)[0].channel_path.exists()


def test_unexport_failure_is_latched_not_reported_as_release(tree, monkeypatch):
    monkeypatch.setattr(bench.time, "sleep", lambda _seconds: None)
    io = FakeIO(fail="unexport")
    errors = []
    channel = bench.PWMChannel(
        providers(tree)[0], 50, 4915, io=io, cleanup_errors=errors
    )
    channel.close()
    assert channel.owned and not channel.released
    assert any("unexport" in error for error in errors)
    assert any("remains exported" in error for error in errors)


def test_signal_during_export_latches_ownership_before_rollback(tree, monkeypatch):
    monkeypatch.setattr(bench.time, "sleep", lambda _seconds: None)
    guard = bench.SafetySignals()
    io = FakeIO()
    original = io.write

    def interrupted_export(path, value):
        original(path, value)
        if path.name == "export":
            guard.handler(signal.SIGTERM, None)

    io.write = interrupted_export
    errors = []
    with pytest.raises(bench.SafetyAbort):
        bench.PWMChannel(
            providers(tree)[0], 50, 4915, io=io, guard=guard, cleanup_errors=errors
        )
    assert ("unexport", 2) in io.log
    assert not providers(tree)[0].channel_path.exists()


def test_repeat_signal_does_not_interrupt_cleanup():
    guard = bench.SafetySignals()
    with guard.cleanup():
        guard.handler(signal.SIGTERM, None)
        guard.handler(signal.SIGALRM, None)
    assert guard.received == [signal.SIGTERM, signal.SIGALRM]


@pytest.mark.parametrize(
    "mode,expected_durations",
    [("endpoints", [0.2] * 7), ("idle", [0.2, 3.0, 0.2]), ("loaded", [0.2, 20.0, 0.2])],
)
def test_complete_modes_are_fake_only_and_release_before_json(
    tree, monkeypatch, mode, expected_durations
):
    found = providers(tree)
    monkeypatch.setattr(
        bench, "discover", lambda: ("Raspberry Pi 5 Model B Rev 1.0", found)
    )
    monkeypatch.setattr(bench, "debug_metadata", lambda: {"fake": True})
    snapshot = {"temperature_millic": "42000", "throttled": "throttled=0x0"}
    monkeypatch.setattr(bench, "system_snapshot", lambda: dict(snapshot))
    monkeypatch.setattr(bench.time, "sleep", lambda _seconds: None)
    monkeypatch.setattr(bench.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(bench.signal, "signal", lambda _sig, _handler: signal.SIG_DFL)
    fake_io = FakeIO()
    monkeypatch.setattr(bench, "SysfsIO", lambda: fake_io)
    children = []

    class Child:
        def __init__(self, pid):
            self.pid = pid
            self.finished = False

        def poll(self):
            return 0 if self.finished else None

        def terminate(self):
            self.finished = True

        def wait(self, timeout):
            assert self.finished
            return 0

    def spawn(_args, **_kwargs):
        child = Child(100 + len(children))
        children.append(child)
        return child

    monkeypatch.setattr(bench.subprocess, "Popen", spawn)
    result = bench.experiment(mode)
    assert result["mode"] == mode and result["sysfs_released"] is True
    assert [
        phase["duration_seconds"] for phase in result["phases"]
    ] == expected_durations
    assert all(not provider.channel_path.exists() for provider in found)
    assert all(child.finished for child in children)
    assert len(result["burner_pids"]) == (4 if mode == "loaded" else 0)
    if mode == "endpoints":
        assert [phase["duties"] for phase in result["phases"]] == [
            {"18": 0, "23": 0},
            {"18": 65535, "23": 0},
            {"18": 0, "23": 0},
            {"18": 0, "23": 65535},
            {"18": 0, "23": 0},
            {"18": 65535, "23": 65535},
            {"18": 0, "23": 0},
        ]
    else:
        assert result["phases"][1]["duties"] == {"18": 4915, "23": 32768}


@pytest.mark.parametrize(
    "snapshot",
    [
        {},
        {"temperature_millic": "66000", "throttled": "throttled=0x0"},
        {"temperature_millic": "42000", "throttled": "throttled=0x10000"},
    ],
)
def test_thermal_gate_is_fail_closed(snapshot):
    assert bench.thermal_issues(snapshot, 65000)


def test_main_emits_no_success_json_on_cleanup_failure(monkeypatch, capsys):
    def fail(_mode):
        raise bench.BenchError("cleanup failed")

    monkeypatch.setattr(bench, "experiment", fail)
    assert bench.main(["--mode", "idle"]) == 1
    captured = capsys.readouterr()
    assert captured.out == ""
    assert "cleanup failed" in captured.err
