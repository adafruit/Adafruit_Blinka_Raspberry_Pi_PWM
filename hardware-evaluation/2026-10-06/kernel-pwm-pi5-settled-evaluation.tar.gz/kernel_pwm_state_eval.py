"""Evaluation-only GPIO18 logical endpoint/frequency/lifecycle exercise.

Only the approved Pi 5 header RP1 channel 2 is freshly exported. Frozen inverse
and core helpers supply discovery, signal ownership, readback, thermal gates and
normal-low release. Logical duty 65535 is deliberately represented as inversed
polarity with raw duty zero; no normal full-period duty is ever requested.
Sysfs readbacks describe cached driver state, not measured electrical state.
The 14 s alarm bounds normal operation; signal-deferred cleanup may finish after
that watchdog, but an elapsed run of 15 s or more cannot return success JSON.
"""

import argparse
import hashlib
import json
import os
import signal
import sys
import time
from contextlib import nullcontext
from pathlib import Path

import kernel_pwm_inverse_eval as inverse

core = inverse.core
BenchError = core.BenchError
SafetyAbort = core.SafetyAbort
MAX_RUN_SECONDS = 14
FREQUENCIES = (50, 500)
LOGICAL_DUTIES = (0, 4915, 32768, 65535)
SEQUENCES = {
    "direct": (
        ("low50_initial", 0.2, 50, 0),
        ("control50_d4915", 0.4, 50, 4915),
        ("high50_first", 0.3, 50, 65535),
        ("recovery50_d4915", 0.4, 50, 4915),
        ("high50_second", 0.3, 50, 65535),
        ("recovery500_d32768", 0.4, 500, 32768),
        ("high500", 0.3, 500, 65535),
        ("high50_after_frequency", 0.3, 50, 65535),
        ("recovery50_final_d4915", 0.4, 50, 4915),
        ("low50_final", 0.2, 50, 0),
    ),
    "frequency": (
        ("low50_initial", 0.2, 50, 0),
        ("pwm50_d4915_initial", 0.4, 50, 4915),
        ("pwm500_d32768", 0.4, 500, 32768),
        ("pwm50_d4915_recovery", 0.4, 50, 4915),
        ("low50_before_high", 0.2, 50, 0),
        ("high50_first", 0.3, 50, 65535),
        ("high500", 0.3, 500, 65535),
        ("high50_after_frequency", 0.3, 50, 65535),
        ("low50_final", 0.2, 50, 0),
    ),
    "lifecycle": (
        ("generation1_low50", 0.2, 50, 0),
        ("generation1_pwm50_d4915", 0.4, 50, 4915),
        ("generation1_high50", 0.3, 50, 65535),
        ("generation2_low50", 0.2, 50, 0),
        ("generation2_pwm500_d32768", 0.4, 500, 32768),
        ("generation2_high500", 0.3, 500, 65535),
    ),
}


def requested_state(frequency, duty_u16):
    if (
        type(frequency) is not int
        or frequency not in FREQUENCIES
        or type(duty_u16) is not int
        or duty_u16 not in LOGICAL_DUTIES
    ):
        raise BenchError(
            "Only frequencies 50/500 and logical duties 0/4915/32768/65535 are approved"
        )
    period_ns = 1_000_000_000 // frequency
    return {
        "period": period_ns,
        "duty_cycle": 0 if duty_u16 == 65535 else period_ns * duty_u16 // 65535,
        "polarity": "inversed" if duty_u16 == 65535 else "normal",
        "enable": 1,
    }


class StatePWMChannel(inverse.InversePWMChannel):
    """Extend only laboratory transitions; inherit the frozen safe-low close.

    These fields exist before super().__init__, whose failure rollback dispatches
    to this close method. Period acceptance and Python tracking are signal-atomic.
    """

    def __init__(self, provider, *, generation=1, **kwargs):
        self.generation = generation
        self.last_requested_frequency = 50
        self.last_requested_duty_u16 = 0
        super().__init__(provider, **kwargs)

    def _track_period(self, period_ns):
        if period_ns not in (20_000_000, 2_000_000):
            raise BenchError(f"Unexpected accepted PWM period: {period_ns}")
        self.period_ns = period_ns
        self.frequency = 1_000_000_000 // period_ns
        self.active_duty_ns = period_ns * inverse.DUTY_U16 // 65535
        self.period_ready = True

    def _set_period(self, frequency):
        period_ns = 1_000_000_000 // frequency
        with self.guard.atomic() if self.guard else nullcontext():
            try:
                self._write("period", period_ns)
            except BaseException:
                # A failed userspace write can be ambiguous. Adopt a valid live
                # cached period for recovery rather than assume the old value.
                try:
                    self._track_period(int(self.io.read(self.path / "period")))
                except BaseException:
                    self.period_ready = False
                raise
            else:
                self._track_period(period_ns)

    def transition(self, frequency, duty_u16):
        target = requested_state(frequency, duty_u16)
        if not self.owned:
            raise BenchError("Missing ownership")
        current_polarity = self.io.read(self.path / "polarity")
        if current_polarity not in ("normal", "inversed"):
            raise BenchError(f"Unexpected starting polarity: {current_polarity!r}")
        change_period = target["period"] != self.period_ns
        change_polarity = target["polarity"] != current_polarity
        if change_period or change_polarity:
            self._write("enable", 0)
            # Duty must be zero before a period shrink, even when disabled:
            # RP1 .apply still programs its registers for disabled cached states.
            self._write("duty_cycle", 0)
            if change_polarity:
                self._write("polarity", target["polarity"])
            if change_period:
                self._set_period(frequency)
            self._write("duty_cycle", target["duty_cycle"])
            self.readback(target["polarity"], target["duty_cycle"], 0)
            self._write("enable", 1)
        else:
            self._write("duty_cycle", target["duty_cycle"])
        state = self.readback(target["polarity"], target["duty_cycle"], 1)
        self.last_requested_frequency = frequency
        self.last_requested_duty_u16 = duty_u16
        return state

    def close(self):
        if not self.owned:
            return
        with self.guard.cleanup() if self.guard else nullcontext():
            self.scope = "cleanup_period_recovery"

            def attempt(name, operation):
                try:
                    operation()
                except BaseException as exc:
                    self.cleanup_errors.append(
                        f"GPIO18 {name}: {type(exc).__name__}: {exc}"
                    )

            attempt("period recovery disable", lambda: self._write("enable", 0))
            # Constructor failures may leave period zero. Increasing directly to
            # the known 20 ms fallback is then safe while disabled; positive
            # periods are first zeroed before any recovery period application.
            try:
                current_period = int(self.io.read(self.path / "period"))
            except BaseException as exc:
                self.cleanup_errors.append(
                    f"GPIO18 period recovery read: {type(exc).__name__}: {exc}"
                )
                current_period = None
            if current_period != 0:
                attempt(
                    "period recovery zero duty", lambda: self._write("duty_cycle", 0)
                )
            attempt("recover known 20 ms period", lambda: self._set_period(50))
            # The inherited close gates enabling on normal+zero+valid-period
            # readbacks, verifies a settled low command, and retains ownership
            # whenever that recovery or final disable cannot be confirmed.
            super().close()


def run_phase(channel, phases, name, duration, frequency, duty_u16):
    target = requested_state(frequency, duty_u16)
    channel.scope = name
    transition_begin = time.monotonic_ns()
    state = channel.transition(frequency, duty_u16)
    stable_begin = time.monotonic_ns()
    time.sleep(duration)
    hold_end = time.monotonic_ns()
    end_state = channel.readback(target["polarity"], target["duty_cycle"], 1)
    phases.append(
        {
            "name": name,
            "generation": channel.generation,
            "frequency": frequency,
            "duty_u16": duty_u16,
            "period_ns": target["period"],
            "duty_ns": target["duty_cycle"],
            "polarity": target["polarity"],
            "intent": "constant_high"
            if duty_u16 == 65535
            else "low"
            if duty_u16 == 0
            else "interior_pwm",
            "duration_seconds": duration,
            "transition_begin_ns": transition_begin,
            "begin_ns": transition_begin,
            "stable_begin_ns": stable_begin,
            "end_ns": hold_end,
            "readback_end_ns": time.monotonic_ns(),
            "sysfs_readbacks": {"18": state},
            "end_readbacks": {"18": end_state},
        }
    )


def require_release(channel):
    if not (
        channel.released
        and channel.cleanup_low_confirmed
        and channel.cleanup_final_readback
        == {
            "period": channel.period_ns,
            "duty_cycle": 0,
            "polarity": "normal",
            "enable": 0,
        }
    ):
        raise BenchError(
            f"Generation {channel.generation}: cannot confirm normal-low command and export release"
        )


def experiment(mode):
    if mode not in SEQUENCES:
        raise BenchError("Invalid state experiment mode")
    channels, phases, cleanup_errors, quiet_intervals = [], [], [], []
    primary = primary_traceback = after = None
    start = time.monotonic_ns()
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            model, providers = core.discover()
            metadata = core.debug_metadata()
            metadata["source_sha256"] = {
                name: hashlib.sha256(Path(path).read_bytes()).hexdigest()
                for name, path in (
                    ("kernel_pwm_state_eval.py", __file__),
                    ("kernel_pwm_inverse_eval.py", inverse.__file__),
                    ("kernel_pwm_eval.py", core.__file__),
                )
            }
            before = core.system_snapshot()
            issues = core.thermal_issues(before, 65000)
            if issues:
                raise BenchError(
                    "Thermal preflight failed before PWM startup: " + "; ".join(issues)
                )
            channel = StatePWMChannel(
                providers[0],
                guard=guard,
                cleanup_errors=cleanup_errors,
                register=channels.append,
            )
            for index, args in enumerate(SEQUENCES[mode]):
                if mode == "lifecycle" and index == 3:
                    channel.close()
                    require_release(channel)
                    if cleanup_errors:
                        raise BenchError(
                            "Generation 1 cleanup failed; refusing generation 2"
                        )
                    if guard.received:
                        raise SafetyAbort(
                            "Termination signal received during generation 1 cleanup"
                        )
                    quiet_begin = time.monotonic_ns()
                    time.sleep(0.2)
                    quiet_intervals.append(
                        {
                            "after_generation": 1,
                            "duration_seconds": 0.2,
                            "begin_ns": quiet_begin,
                            "end_ns": time.monotonic_ns(),
                            "sysfs_released": True,
                        }
                    )
                    channel = StatePWMChannel(
                        providers[0],
                        generation=2,
                        guard=guard,
                        cleanup_errors=cleanup_errors,
                        register=channels.append,
                    )
                run_phase(channel, phases, *args)
        except BaseException as exc:
            primary, primary_traceback = exc, exc.__traceback__
        finally:
            with guard.cleanup():
                signal.alarm(0)
                for channel in channels:
                    try:
                        channel.close()
                    except BaseException as exc:
                        cleanup_errors.append(
                            f"GPIO18 cleanup: {type(exc).__name__}: {exc}"
                        )
                try:
                    after = core.system_snapshot()
                except BaseException as exc:
                    cleanup_errors.append(
                        f"Post-run snapshot: {type(exc).__name__}: {exc}"
                    )
            if guard.received and primary is None:
                primary = SafetyAbort("Termination signal received during cleanup")
    if cleanup_errors:
        print("Cleanup failures: " + "; ".join(cleanup_errors), file=sys.stderr)
        if primary is None:
            primary = BenchError("PWM cleanup failed")
    if primary is not None:
        raise primary.with_traceback(primary_traceback)
    issues = core.thermal_issues(after, 75000)
    if issues:
        raise BenchError("Post-run thermal gate failed: " + "; ".join(issues))
    end = time.monotonic_ns()
    if end - start >= 15_000_000_000:
        raise BenchError("Experiment exceeded the authorized sub-15-second bound")
    if len(channels) != (2 if mode == "lifecycle" else 1):
        raise BenchError("Unexpected owned generation count")
    for channel in channels:
        require_release(channel)
    return {
        "schema_version": 1,
        "mode": mode,
        "model": model,
        "helper_pid": os.getpid(),
        "begin_ns": start,
        "end_ns": end,
        "phases": phases,
        "lifecycle_quiet_intervals": quiet_intervals,
        "sysfs_released": True,
        "low_confirmed": True,
        "low_confirmation_semantics": "normal-zero enabled cached sysfs command/readback plus settle; not electrical proof",
        "outputs": [
            {
                **channel.provider.identity(),
                "backend": "rp1-pwm",
                "generation": channel.generation,
                "frequency": channel.frequency,
                "period_ns": channel.period_ns,
                "last_requested_frequency": channel.last_requested_frequency,
                "last_requested_duty_u16": channel.last_requested_duty_u16,
                "sysfs_events": channel.events,
                "released": channel.released,
                "cleanup_low_confirmed": channel.cleanup_low_confirmed,
                "cleanup_final_readback": channel.cleanup_final_readback,
            }
            for channel in channels
        ],
        "discovered_untouched_outputs": [providers[1].identity()],
        "burner_pids": [],
        "hard_max_run_seconds": MAX_RUN_SECONDS,
        "watchdog_scope": "normal operation only; low recovery cleanup defers signals",
        "thermal": {"before": before, "after": after},
        "cleanup_errors": cleanup_errors,
        "metadata": metadata,
        "transition_policy": "disable for polarity or frequency changes; zero duty before period change",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=tuple(SEQUENCES))
    args = parser.parse_args(argv)
    try:
        result = experiment(args.mode)
    except BaseException as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
