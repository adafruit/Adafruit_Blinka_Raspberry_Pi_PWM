"""Bounded synthetic state fixtures only; no hardware, SSH or production writes."""

import json

import pytest

from analyze_kernel_pwm_state import SEQUENCES, analyze, state_for, write_analysis
from test_kernel_pwm_inverse_waveforms import binary_export, saved_capture


def train(start, frequency, duty):
    high = state_for(frequency, duty)["duty_cycle"] / 1e9
    return [
        edge
        for index in range(round(0.4 * frequency))
        for edge in (start + index / frequency, start + index / frequency + high)
    ]


def edges_for(mode):
    if mode == "direct":
        return (
            train(0.4, 50, 4915)
            + [0.8, 1.1]
            + train(1.1001, 50, 4915)
            + [1.5001, 1.8001]
            + train(1.8002, 500, 32768)
            + [2.2002, 2.8002]
            + train(2.8003, 50, 4915)
        )
    if mode == "frequency":
        return (
            train(0.4, 50, 4915)
            + train(0.8, 500, 32768)
            + train(1.2, 50, 4915)
            + [1.8, 2.7]
        )
    return train(0.4, 50, 4915) + [0.8, 1.1] + train(1.7, 500, 32768) + [2.1, 2.4]


def replace_metadata(directory, metadata):
    (directory / "results.json").write_text(json.dumps(metadata))
    (directory / "remote.stdout").write_text(json.dumps(metadata["remote"]))


def metadata_files(directory, mode):
    chip, start, tick = "/sys/class/pwm/pwmchip1", 80_000_000_000, 80_000_010_000
    phases, outputs, quiet = [], [], []
    count = 2 if mode == "lifecycle" else 1
    for generation in range(1, count + 1):
        events, state = [], {}
        scope = "initialization"
        scope_holder = {"scope": scope}

        def write(
            attribute,
            value,
            *,
            audit_events=events,
            audit_state=state,
            audit_scope=scope_holder,
        ):
            nonlocal tick
            path = (
                f"{chip}/{attribute}"
                if attribute in ("export", "unexport")
                else f"{chip}/pwm2/{attribute}"
            )
            audit_events.append(
                {
                    "operation": "write",
                    "scope": audit_scope["scope"],
                    "path": path,
                    "attribute": attribute,
                    "value": value,
                    "begin_ns": tick,
                    "end_ns": tick + 1000,
                    "status": "ok",
                }
            )
            tick += 2000
            if attribute not in ("export", "unexport"):
                audit_state[attribute] = value

        def read(*, audit_events=events, audit_state=state, audit_scope=scope_holder):
            nonlocal tick
            audit_events.append(
                {
                    "operation": "readback",
                    "scope": audit_scope["scope"],
                    "expected": dict(audit_state),
                    "state": dict(audit_state),
                    "begin_ns": tick,
                    "end_ns": tick + 1000,
                    "status": "ok",
                }
            )
            tick += 2000
            return dict(audit_state)

        for attribute, value in (
            ("export", 2),
            ("enable", 0),
            ("polarity", "normal"),
            ("period", 20_000_000),
            ("duty_cycle", 0),
            ("enable", 1),
        ):
            write(attribute, value)
        tick += 100_000_000
        read()
        sequence = SEQUENCES[mode]
        if mode == "lifecycle":
            sequence = sequence[:3] if generation == 1 else sequence[3:]
        for name, duration, frequency, logical in sequence:
            target = state_for(frequency, logical)
            scope, begin = name, tick
            scope_holder["scope"] = scope
            changed = (
                state["period"] != target["period"]
                or state["polarity"] != target["polarity"]
            )
            if changed:
                write("enable", 0)
                write("duty_cycle", 0)
                write("period", target["period"])
                write("polarity", target["polarity"])
            write("duty_cycle", target["duty_cycle"])
            if changed:
                write("enable", 1)
            start_state = read()
            stable = tick
            tick += round(duration * 1e9)
            hold_end = tick
            end_state = read()
            intent = (
                "constant_high"
                if logical == 65535
                else "low"
                if logical == 0
                else "interior_pwm"
            )
            phases.append(
                {
                    "name": name,
                    "generation": generation,
                    "frequency": frequency,
                    "duty_u16": logical,
                    "period_ns": target["period"],
                    "duty_ns": target["duty_cycle"],
                    "polarity": target["polarity"],
                    "intent": intent,
                    "duration_seconds": duration,
                    "begin_ns": begin,
                    "transition_begin_ns": begin,
                    "stable_begin_ns": stable,
                    "end_ns": hold_end,
                    "readback_end_ns": tick,
                    "sysfs_readbacks": {"18": start_state},
                    "end_readbacks": {"18": end_state},
                }
            )
        scope = "cleanup_period_recovery"
        scope_holder["scope"] = scope
        for attribute, value in (
            ("enable", 0),
            ("duty_cycle", 0),
            ("period", 20_000_000),
        ):
            write(attribute, value)
        scope = "cleanup"
        scope_holder["scope"] = scope
        for attribute, value in (
            ("enable", 0),
            ("polarity", "normal"),
            ("duty_cycle", 0),
        ):
            write(attribute, value)
        read()
        write("enable", 1)
        read()
        tick += 100_000_000
        read()
        write("enable", 0)
        read()
        write("unexport", 2)
        outputs.append(
            {
                "gpio": 18,
                "channel": 2,
                "chip": chip,
                "of_node": "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/pwm@98000",
                "compatible": ["raspberrypi,rp1-pwm"],
                "gpio_of_node": None,
                "backend": "rp1-pwm",
                "generation": generation,
                "frequency": 50,
                "period_ns": 20_000_000,
                "last_requested_frequency": frequency,
                "last_requested_duty_u16": logical,
                "sysfs_events": events,
                "released": True,
                "cleanup_low_confirmed": True,
                "cleanup_final_readback": state_for(50, 0, 0),
            }
        )
        if generation < count:
            begin = tick
            tick += 200_000_000
            quiet.append(
                {
                    "after_generation": 1,
                    "duration_seconds": 0.2,
                    "begin_ns": begin,
                    "end_ns": tick,
                    "sysfs_released": True,
                }
            )
    thermal = {"temperature_millic": "40000", "throttled": "throttled=0x0"}
    remote = {
        "mode": mode,
        "schema_version": 1,
        "model": "Raspberry Pi 5 Model B Rev 1.0",
        "begin_ns": start,
        "end_ns": tick + 200_000_000,
        "phases": phases,
        "outputs": outputs,
        "lifecycle_quiet_intervals": quiet,
        "sysfs_released": True,
        "low_confirmed": True,
        "cleanup_errors": [],
        "burner_pids": [],
        "hard_max_run_seconds": 14,
        "thermal": {"before": dict(thermal), "after": dict(thermal)},
        "metadata": {
            "source_sha256": {
                "kernel_pwm_eval.py": "a" * 64,
                "kernel_pwm_inverse_eval.py": "b" * 64,
                "kernel_pwm_state_eval.py": "c" * 64,
            }
        },
    }
    metadata = {
        "mode": mode,
        "host": "test-pi5.local",
        "sample_rate_hz": 100_000_000,
        "production_backend_unchanged": True,
        "providers_left_loaded_until_reboot": True,
        "outputs": [
            {"gpio": 18, "saleae_channel": 0, "backend": "kernel-hardware-rp1"}
        ],
        "remote": remote,
    }
    replace_metadata(directory, metadata)
    return metadata


def fixture_files(directory, mode):
    metadata_files(directory, mode)
    saved_capture(directory / "waveform.sal")
    binary_export(
        directory / "digital_0.bin",
        edges_for(mode),
        end=3.8 if mode == "direct" else 3.2,
    )
    return directory


@pytest.mark.parametrize(
    "mode,edges,holds",
    [("direct", 526, 3), ("frequency", 482, 1), ("lifecycle", 444, 2)],
)
def test_complete_patterns_include_every_transition(tmp_path, mode, edges, holds):
    report = analyze(fixture_files(tmp_path, mode))
    assert report["accepted"] is True, report["rejection_reasons"]
    assert report["waveform"]["edge_count"] == edges
    assert len(report["physical"]["constant_high_holds"]) == holds
    assert len(report["physical"]["all_high_runs"]) * 2 == edges
    assert report["physical"]["phase_alignment_proven"] is False
    assert report["physical"]["no_transition_trimming_or_glitch_filtering"] is True
    assert "not analog proof" in report["limitation"]


@pytest.mark.parametrize(
    "mode,position",
    [
        ("direct", 0.801499961),
        ("direct", 0.95),
        ("direct", 2.5002),
        ("frequency", 1.800001),
        ("frequency", 2.1),
        ("frequency", 2.699999),
        ("lifecycle", 0.95),
        ("lifecycle", 2.25),
    ],
)
@pytest.mark.parametrize("dip_ns", [10, 20])
def test_tiny_dips_anywhere_are_rejected_without_filtering(
    tmp_path, mode, position, dip_ns
):
    fixture_files(tmp_path, mode)
    edges = sorted(edges_for(mode) + [position, position + dip_ns / 1e9])
    binary_export(tmp_path / "digital_0.bin", edges, end=3.8)
    report = analyze(tmp_path)
    assert report["accepted"] is False
    assert report["physical"]["sub_microsecond_low_runs"]
    assert report["waveform"]["transition_seconds"] == edges


def test_boundary_partial_high_pulse_is_retained_and_rejected(tmp_path):
    fixture_files(tmp_path, "frequency")
    edges = edges_for("frequency")
    edges[41] = edges[40] + 0.0005
    binary_export(tmp_path / "digital_0.bin", edges, end=3.2)
    report = analyze(tmp_path)
    assert report["accepted"] is False
    assert report["physical"]["unexpected_high_runs"][0]["width_us"] == pytest.approx(
        500
    )
    assert report["waveform"]["edge_count"] == len(edges)
    assert any(
        "no boundary pulse was trimmed" in reason
        for reason in report["rejection_reasons"]
    )


def test_frequency_boundary_period_is_not_silently_excluded(tmp_path):
    fixture_files(tmp_path, "frequency")
    edges = edges_for("frequency")
    for index in range(40, len(edges)):
        edges[index] += 0.001
    binary_export(tmp_path / "digital_0.bin", edges, end=3.2)
    report = analyze(tmp_path)
    assert report["accepted"] is False
    assert any("boundary period" in reason for reason in report["rejection_reasons"])


@pytest.mark.parametrize(
    "mutate,match",
    [
        (lambda m: m.update(host="test2-pi4.local"), "Pi 5 bench host"),
        (lambda m: m["remote"]["phases"][2].update(polarity="normal"), "state differs"),
        (
            lambda m: m["remote"]["phases"][2]["end_readbacks"]["18"].update(enable=0),
            "readbacks",
        ),
        (lambda m: m["remote"]["outputs"][0].update(channel=3), "Provider"),
        (
            lambda m: m["remote"]["outputs"][0]["cleanup_final_readback"].update(
                polarity="inversed"
            ),
            "restore normal-zero",
        ),
        (lambda m: m["remote"].update(low_confirmed=False), "Cleanup/release"),
    ],
)
def test_metadata_contract_failures(tmp_path, mutate, match):
    fixture_files(tmp_path, "direct")
    metadata = json.loads((tmp_path / "results.json").read_text())
    mutate(metadata)
    replace_metadata(tmp_path, metadata)
    with pytest.raises(ValueError, match=match):
        analyze(tmp_path)


def test_lifecycle_requires_release_before_fresh_generation(tmp_path):
    fixture_files(tmp_path, "lifecycle")
    metadata = json.loads((tmp_path / "results.json").read_text())
    metadata["remote"]["lifecycle_quiet_intervals"][0]["sysfs_released"] = False
    replace_metadata(tmp_path, metadata)
    with pytest.raises(ValueError, match="quiet interval"):
        analyze(tmp_path)


def test_rejected_analysis_is_preserved_without_claiming_pass(tmp_path):
    fixture_files(tmp_path, "direct")
    edges = sorted(edges_for("direct") + [0.95, 0.95000001])
    binary_export(tmp_path / "digital_0.bin", edges, end=3.8)
    report = write_analysis(tmp_path)
    assert report["accepted"] is False
    saved = (tmp_path / "analysis.json").read_bytes()
    assert json.loads(saved)["accepted"] is False
    with pytest.raises(FileExistsError):
        write_analysis(tmp_path)
    assert (tmp_path / "analysis.json").read_bytes() == saved
    with pytest.raises(ValueError, match="filename"):
        write_analysis(tmp_path, "../overwrite.json")


@pytest.mark.parametrize(
    "initial,truncate,match", [(1, False, "start low"), (0, True, "finish low")]
)
def test_initial_final_electrical_low_is_separate_from_cleanup_reports(
    tmp_path, initial, truncate, match
):
    fixture_files(tmp_path, "direct")
    edges = edges_for("direct")[:-1] if truncate else edges_for("direct")
    binary_export(tmp_path / "digital_0.bin", edges, initial=initial, end=3.8)
    with pytest.raises(ValueError, match=match):
        analyze(tmp_path)
