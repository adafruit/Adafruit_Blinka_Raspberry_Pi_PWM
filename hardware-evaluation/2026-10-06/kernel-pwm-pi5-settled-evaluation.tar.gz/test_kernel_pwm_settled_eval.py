"""Fake-only enabled transition tests; no GPIO, SSH, or physical signals."""

import importlib.util
import json
import signal
import sys
from pathlib import Path

import pytest

import test_kernel_pwm_state_eval as state_fakes

SCRIPT = Path(__file__).with_name("kernel_pwm_settled_eval.py")
spec = importlib.util.spec_from_file_location("kernel_pwm_settled_eval", SCRIPT)
settled = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = settled
spec.loader.exec_module(settled)
state = settled.state
core = state.core
RealSysfsIO = core.SysfsIO


class EnabledIO(state_fakes.FakeIO):
    def write(self, path, value):
        if path.name != "polarity":
            return super().write(path, value)
        self.log.append((path, value))
        self.counts[path.name] += 1
        if self.fail == (path.name, self.counts[path.name]):
            raise OSError("injected polarity failure")
        RealSysfsIO.write(self, path, value)
        if self.hook:
            self.hook(path, value)


@pytest.fixture
def tree(tmp_path):
    return state_fakes.inverse_fakes.common_fakes.tree.__wrapped__(tmp_path)


@pytest.fixture
def provider(tree):
    return core.discover(tree[1], tree[0])[1][0]


@pytest.fixture(autouse=True)
def no_sleep_or_physical_signals(monkeypatch):
    monkeypatch.setattr(settled.time, "sleep", lambda _seconds: None)
    monkeypatch.setattr(state.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(state.signal, "signal", lambda _sig, _handler: signal.SIG_DFL)


def make_channel(provider, **kwargs):
    io = kwargs.pop("io", EnabledIO())
    return settled.SettledPWMChannel(provider, io=io, **kwargs), io


def configure_experiment(tree, monkeypatch, *, guard=None):
    found, _unused_io = state_fakes.configure_experiment(tree, monkeypatch, guard=guard)
    io = EnabledIO()
    monkeypatch.setattr(core, "SysfsIO", lambda: io)
    return found, io


def test_normal_interior_to_high_waits_after_zero_before_inversion(
    provider, monkeypatch
):
    channel, io = make_channel(provider)
    channel.transition(50, 4915)
    io.log.clear()
    steps = []
    original_write = io.write

    def record_write(path, value):
        steps.append((path.name, value))
        original_write(path, value)

    io.write = record_write
    monkeypatch.setattr(
        settled.time, "sleep", lambda duration: steps.append(("wait", duration))
    )
    result = channel.transition(50, 65535)
    assert steps == [("duty_cycle", 0), ("wait", 0.04), ("polarity", "inversed")]
    assert result == state.requested_state(50, 65535)
    assert channel.strategy_waits[-1]["state"] == state.requested_state(50, 0)
    assert channel.strategy_waits[-1]["reason"] == "normal_zero_settle"
    assert channel.strategy_waits[-1]["status"] == "ok"
    channel.close()


def test_normal_frequency_change_waits_before_and_after_period(provider, monkeypatch):
    channel, io = make_channel(provider)
    channel.transition(50, 4915)
    io.log.clear()
    steps = []
    original_write = io.write

    def record_write(path, value):
        steps.append((path.name, value))
        original_write(path, value)

    io.write = record_write
    monkeypatch.setattr(
        settled.time, "sleep", lambda duration: steps.append(("wait", duration))
    )
    result = channel.transition(500, 32768)
    assert steps == [
        ("duty_cycle", 0),
        ("wait", 0.04),
        ("period", 2_000_000),
        ("wait", 0.04),
        ("duty_cycle", 2_000_000 * 32768 // 65535),
    ]
    assert result == state.requested_state(500, 32768)
    assert [event["reason"] for event in channel.strategy_waits] == [
        "normal_zero_settle",
        "period_settle",
    ]
    assert all(
        event["state"]["enable"] == 1 and event["state"]["duty_cycle"] == 0
        for event in channel.strategy_waits
    )
    channel.close()


def test_high_frequency_change_keeps_inversed_enabled_zero(provider, monkeypatch):
    channel, io = make_channel(provider)
    channel.transition(50, 65535)
    io.log.clear()
    channel.strategy_waits.clear()
    sleeps = []
    monkeypatch.setattr(settled.time, "sleep", sleeps.append)
    result = channel.transition(500, 65535)
    assert io.writes == [("period", 2_000_000)]
    assert sleeps == [0.04]
    assert result == state.requested_state(500, 65535)
    assert len(channel.strategy_waits) == 1
    assert channel.strategy_waits[0]["reason"] == "period_settle"
    assert channel.strategy_waits[0]["state"] == state.requested_state(500, 65535)
    channel.close()


def test_high_to_normal_changes_polarity_before_active_duty(provider):
    channel, io = make_channel(provider)
    channel.transition(50, 65535)
    io.log.clear()
    channel.strategy_waits.clear()
    channel.transition(50, 4915)
    assert io.writes == [
        ("polarity", "normal"),
        ("duty_cycle", 20_000_000 * 4915 // 65535),
    ]
    assert channel.strategy_waits == []
    channel.close()


def test_same_frequency_normal_duties_have_no_enable_toggle_or_wait(provider):
    channel, io = make_channel(provider)
    io.log.clear()
    channel.transition(50, 4915)
    channel.transition(50, 32768)
    channel.transition(50, 0)
    assert all(attribute == "duty_cycle" for attribute, _value in io.writes)
    assert channel.strategy_waits == []
    channel.close()


@pytest.mark.parametrize("reason", ["normal_zero_settle", "period_settle"])
def test_signal_during_strategy_wait_aborts_and_conservative_close_recovers(
    provider, monkeypatch, reason
):
    guard = core.SafetySignals()
    channel, io = make_channel(provider, guard=guard)
    channel.transition(50, 4915)
    count = 0

    def interrupt(_duration):
        nonlocal count
        count += 1
        if count == (1 if reason == "normal_zero_settle" else 2):
            guard.handler(signal.SIGTERM, None)

    monkeypatch.setattr(settled.time, "sleep", interrupt)
    with pytest.raises(core.SafetyAbort):
        channel.transition(500, 32768)
    assert channel.strategy_waits[-1]["reason"] == reason
    assert channel.strategy_waits[-1]["status"] == "error"
    assert "SafetyAbort" in channel.strategy_waits[-1]["error"]
    monkeypatch.setattr(settled.time, "sleep", lambda _seconds: None)
    channel.close()
    assert channel.released and channel.cleanup_low_confirmed
    assert io.writes[-1] == ("unexport", 2)


@pytest.mark.parametrize("accepted", [False, True])
def test_period_acceptance_error_tracks_actual_state_and_safe_close(provider, accepted):
    channel, io = make_channel(provider)
    channel.transition(50, 65535)
    io.counts.clear()
    if accepted:

        def failed_after_apply(path, value):
            if path.name == "period" and value == 2_000_000:
                raise OSError("accepted period then error")

        io.hook = failed_after_apply
    else:
        io.fail = ("period", 1)
    with pytest.raises(OSError):
        channel.transition(500, 65535)
    assert channel.period_ns == (2_000_000 if accepted else 20_000_000)
    channel.close()
    assert channel.released and channel.period_ns == 20_000_000


@pytest.mark.parametrize("mode", ["direct", "frequency", "lifecycle"])
def test_all_modes_metadata_wait_audit_and_class_restoration(tree, monkeypatch, mode):
    found, io = configure_experiment(tree, monkeypatch)
    original = state.StatePWMChannel
    result = settled.experiment(mode)
    assert state.StatePWMChannel is original
    assert result["mode"] == mode and result["transition_strategy"] == settled.STRATEGY
    assert result["low_confirmed"] and result["sysfs_released"]
    assert result["strategy_waits"]
    assert set(result["metadata"]["source_sha256"]) == {
        "kernel_pwm_settled_eval.py",
        "kernel_pwm_state_eval.py",
        "kernel_pwm_inverse_eval.py",
        "kernel_pwm_eval.py",
    }
    generations = {output["generation"] for output in result["outputs"]}
    for wait in result["strategy_waits"]:
        assert wait["generation"] in generations and wait["status"] == "ok"
        assert wait["duration_seconds"] in (0.004, 0.04)
        assert wait["begin_ns"] <= wait["end_ns"]
        assert wait["state"]["duty_cycle"] == 0 and wait["state"]["enable"] == 1
    for output in result["outputs"]:
        writes = [
            event for event in output["sysfs_events"] if event["operation"] == "write"
        ]
        assert not any(
            event["attribute"] == "enable"
            for event in writes
            if event["scope"]
            not in ("initialization", "cleanup", "cleanup_period_recovery")
        )
        assert output["cleanup_final_readback"] == state.requested_state(50, 0) | {
            "enable": 0
        }
        assert output["released"] and output["cleanup_low_confirmed"]
    assert all(not provider.channel_path.exists() for provider in found)
    assert all(
        path.parent in (found[0].chip, found[0].channel_path) for path, _value in io.log
    )


def test_failure_restores_wrapper_class_and_never_prints_success(
    tree, monkeypatch, capsys
):
    _found, io = configure_experiment(tree, monkeypatch)
    original = state.StatePWMChannel

    def fail_inversion(path, value):
        if path.name == "polarity" and value == "inversed":
            raise ValueError("failed enabled inversion")

    io.hook = fail_inversion
    assert settled.main(["--mode", "direct"]) == 1
    assert state.StatePWMChannel is original
    captured = capsys.readouterr()
    assert captured.out == "" and "failed enabled inversion" in captured.err


def test_lifecycle_cleanup_signal_still_prevents_second_export(
    tree, monkeypatch, capsys
):
    guard = core.SafetySignals()
    found, io = configure_experiment(tree, monkeypatch, guard=guard)
    io.hook = lambda path, _value: (
        guard.handler(signal.SIGTERM, None) if path.name == "unexport" else None
    )
    assert settled.main(["--mode", "lifecycle"]) == 1
    assert len([value for path, value in io.log if path.name == "export"]) == 1
    assert not found[0].channel_path.exists()
    assert capsys.readouterr().out == ""


def test_cleanup_failure_is_inherited_and_retains_export(provider):
    channel, io = make_channel(provider)
    channel.transition(500, 65535)
    io.counts.clear()
    io.fail = ("polarity", 1)
    channel.close()
    assert channel.owned and not channel.released and channel.path.exists()
    assert channel.cleanup_errors


def test_cli_success_json(monkeypatch, capsys):
    monkeypatch.setattr(settled, "experiment", lambda mode: {"mode": mode})
    assert settled.main(["--mode", "frequency"]) == 0
    captured = capsys.readouterr()
    assert json.loads(captured.out) == {"mode": "frequency"}
    assert captured.err == ""
