"""Short, evaluation-only Pi 5 GPIO18 inverse-zero endpoint experiment.

Run beside the unchanged kernel_pwm_eval.py with no arguments. Only a fresh
RP1 header PWM@98000 channel 2 is exported. GPIO23 and the fan are not touched.
The sysfs state is evidence of commands, not proof of electrical endpoint quality;
the independently recorded, unfiltered capture supplies finite digital evidence.
The 14-second alarm bounds normal operation; cleanup defers signals to finish
normal-low recovery. Elapsed time of 15 seconds or more cannot report success.
Success is one JSON object, emitted only after verified normal-low cleanup.
"""

import argparse
import hashlib
import json
import os
import signal
import sys
import time
from contextlib import nullcontext
from pathlib import Path

import kernel_pwm_eval as core

BenchError = core.BenchError
SafetyAbort = core.SafetyAbort
FREQUENCY = 50
DUTY_U16 = 4915
MAX_RUN_SECONDS = 14
MODE = "inverse-endpoints"
PHASES = (
    ("normal_low_initial", 0.2, "normal", "low"),
    ("normal_active_control", 0.4, "normal", "interior_pwm"),
    ("normal_low_before_inverse", 0.2, "normal", "low"),
    ("inverse_zero_high_1", 0.3, "inversed", "constant_high"),
    ("normal_low_between_inverse", 0.2, "normal", "low"),
    ("inverse_zero_high_2", 0.3, "inversed", "constant_high"),
    ("normal_low_after_inverse", 0.2, "normal", "low"),
    ("normal_active_recovery", 0.4, "normal", "interior_pwm"),
    ("normal_low_final", 0.2, "normal", "low"),
)


class InversePWMChannel:
    """Independent owner: core PWMChannel.close assumes normal polarity.

    Register before exporting under the same signal guard as the ownership latch.
    Constructor rollback therefore never strands an unregistered owned channel.
    """

    def __init__(
        self, provider, *, io=None, guard=None, cleanup_errors=None, register=None
    ):
        self.provider = provider
        self.frequency = FREQUENCY
        self.duty_u16 = DUTY_U16
        self.period_ns = round(1_000_000_000 / FREQUENCY)
        self.active_duty_ns = self.period_ns * DUTY_U16 // 65535
        self.io = io if io is not None else core.SysfsIO()
        self.guard = guard
        self.cleanup_errors = cleanup_errors if cleanup_errors is not None else []
        self.owned = False
        self.released = False
        self.period_ready = False
        self.cleanup_low_confirmed = False
        self.cleanup_final_readback = None
        self.events = []
        self.scope = "initialization"
        if (
            provider.gpio != 18
            or provider.channel != 2
            or provider.of_node.name != "pwm@98000"
            or "raspberrypi,rp1-pwm" not in provider.compatible
        ):
            raise BenchError("Only GPIO18 RP1 header PWM@98000 channel 2 is authorized")
        if self.path.exists():
            raise BenchError(f"Refusing existing exported channel: {self.path}")
        try:
            with self.guard.atomic() if self.guard else nullcontext():
                if register is not None:
                    register(self)
                self._write_path(self.provider.chip / "export", provider.channel)
                self.owned = True
            deadline = time.monotonic() + core.EXPORT_READY_SECONDS
            attributes = [
                self.path / name
                for name in ("enable", "polarity", "period", "duty_cycle")
            ]
            while not all(
                path.exists() and os.access(path, os.R_OK | os.W_OK)
                for path in attributes
            ):
                if time.monotonic() >= deadline:
                    raise BenchError(
                        f"Export attributes not readable/writable: {self.path}"
                    )
                time.sleep(0.01)
            self._write("enable", 0)
            self._write("polarity", "normal")
            self._write("period", self.period_ns)
            self.period_ready = True
            self._write("duty_cycle", 0)
            self._write("enable", 1)
            time.sleep(core.LOW_SETTLE_SECONDS)
            self.readback("normal", 0, 1)
        except BaseException:
            self.close()
            raise

    @property
    def path(self):
        return self.provider.channel_path

    def _write_path(self, path, value):
        event = {
            "operation": "write",
            "scope": self.scope,
            "path": str(path),
            "attribute": path.name,
            "value": value,
            "begin_ns": time.monotonic_ns(),
        }
        try:
            self.io.write(path, value)
        except BaseException as exc:
            event.update(status="error", error=f"{type(exc).__name__}: {exc}")
            raise
        else:
            event["status"] = "ok"
        finally:
            event["end_ns"] = time.monotonic_ns()
            self.events.append(event)

    def _write(self, attribute, value):
        self._write_path(self.path / attribute, value)

    def readback(self, expected_polarity, expected_duty, expected_enable):
        event = {
            "operation": "readback",
            "scope": self.scope,
            "begin_ns": time.monotonic_ns(),
            "expected": {
                "period": self.period_ns,
                "duty_cycle": expected_duty,
                "polarity": expected_polarity,
                "enable": expected_enable,
            },
        }
        try:
            state = {
                name: self.io.read(self.path / name)
                for name in ("period", "duty_cycle", "polarity", "enable")
            }
            for name in ("period", "duty_cycle", "enable"):
                state[name] = int(state[name])
            event["state"] = state
            if state != event["expected"]:
                raise BenchError(f"Unexpected GPIO18 sysfs readback: {state}")
        except BaseException as exc:
            event.update(status="error", error=f"{type(exc).__name__}: {exc}")
            raise
        else:
            event["status"] = "ok"
            return state
        finally:
            event["end_ns"] = time.monotonic_ns()
            self.events.append(event)

    def transition(self, polarity, duty_ns):
        if not self.owned or polarity not in ("normal", "inversed"):
            raise BenchError("Invalid polarity or missing ownership")
        if duty_ns not in (0, self.active_duty_ns):
            raise BenchError("Only zero and the approved interior duty are authorized")
        if polarity == "inversed" and duty_ns != 0:
            raise BenchError("Inversed polarity is authorized only with zero duty")
        current = self.io.read(self.path / "polarity")
        if current not in ("normal", "inversed"):
            raise BenchError(f"Unexpected starting polarity: {current!r}")
        if current != polarity:
            # Conservative first experiment: switch polarity only while disabled.
            self._write("enable", 0)
            self._write("polarity", polarity)
            self._write("duty_cycle", duty_ns)
            self.readback(polarity, duty_ns, 0)
            self._write("enable", 1)
        else:
            # Ordinary low/interior controls intentionally do not toggle enable.
            self._write("duty_cycle", duty_ns)
        return self.readback(polarity, duty_ns, 1)

    def close(self):
        if not self.owned:
            return
        with self.guard.cleanup() if self.guard else nullcontext():
            self.scope = "cleanup"

            def attempt(name, operation):
                try:
                    return True, operation()
                except BaseException as exc:
                    self.cleanup_errors.append(
                        f"GPIO18 {name}: {type(exc).__name__}: {exc}"
                    )
                    return False, None

            disabled, _ = attempt("initial disable", lambda: self._write("enable", 0))
            normal, _ = attempt(
                "restore normal polarity", lambda: self._write("polarity", "normal")
            )
            if not self.period_ready:
                ready, _ = attempt(
                    "recover period", lambda: self._write("period", self.period_ns)
                )
                self.period_ready = ready
            zero, _ = attempt("normal zero duty", lambda: self._write("duty_cycle", 0))
            prepared, _ = attempt(
                "prepared low readback", lambda: self.readback("normal", 0, 0)
            )
            # Never turn on inverse-zero or an unknown/nonzero duty after a failure.
            if disabled and normal and zero and self.period_ready and prepared:
                enabled, _ = attempt(
                    "enable normal low", lambda: self._write("enable", 1)
                )
                low, _ = attempt(
                    "enabled low readback", lambda: self.readback("normal", 0, 1)
                )
                if enabled and low:
                    settled, _ = attempt(
                        "low settle", lambda: time.sleep(core.LOW_SETTLE_SECONDS)
                    )
                    confirmed, _ = attempt(
                        "settled low readback", lambda: self.readback("normal", 0, 1)
                    )
                    self.cleanup_low_confirmed = settled and confirmed
            final_disabled, _ = attempt(
                "final disable", lambda: self._write("enable", 0)
            )
            final_ok, final_state = attempt(
                "final low readback", lambda: self.readback("normal", 0, 0)
            )
            self.cleanup_final_readback = final_state if final_ok else None
            if self.cleanup_low_confirmed and final_disabled and final_ok:
                attempt(
                    "unexport",
                    lambda: self._write_path(
                        self.provider.chip / "unexport", self.provider.channel
                    ),
                )
            else:
                self.cleanup_errors.append(
                    "GPIO18 safe normal-low cleanup not confirmed; export retained"
                )
            if self.path.exists():
                self.cleanup_errors.append("GPIO18 remains exported")
            else:
                self.owned = False
                self.released = True


def run_phase(channel, phases, name, duration, polarity, intent):
    duty_ns = channel.active_duty_ns if intent == "interior_pwm" else 0
    channel.scope = name
    transition_begin = time.monotonic_ns()
    state = channel.transition(polarity, duty_ns)
    stable_begin = time.monotonic_ns()
    time.sleep(duration)
    hold_end = time.monotonic_ns()
    end_state = channel.readback(polarity, duty_ns, 1)
    phases.append(
        {
            "name": name,
            "duration_seconds": duration,
            "intent": intent,
            "polarity": polarity,
            "duty_ns": duty_ns,
            "duty_u16": DUTY_U16 if intent == "interior_pwm" else 0,
            "transition_begin_ns": transition_begin,
            "begin_ns": transition_begin,
            "stable_begin_ns": stable_begin,
            "end_ns": hold_end,
            "readback_end_ns": time.monotonic_ns(),
            "sysfs_readbacks": {"18": state},
            "end_readbacks": {"18": end_state},
        }
    )


def experiment():
    channels, phases, cleanup_errors = [], [], []
    primary = primary_traceback = after = None
    start = time.monotonic_ns()
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            model, providers = core.discover()
            metadata = core.debug_metadata()
            metadata["source_sha256"] = {
                "kernel_pwm_inverse_eval.py": hashlib.sha256(
                    Path(__file__).read_bytes()
                ).hexdigest(),
                "kernel_pwm_eval.py": hashlib.sha256(
                    Path(core.__file__).read_bytes()
                ).hexdigest(),
            }
            before = core.system_snapshot()
            issues = core.thermal_issues(before, 65000)
            if issues:
                raise BenchError(
                    "Thermal preflight failed before PWM startup: " + "; ".join(issues)
                )
            channel = InversePWMChannel(
                providers[0],
                guard=guard,
                cleanup_errors=cleanup_errors,
                register=channels.append,
            )
            for args in PHASES:
                run_phase(channel, phases, *args)
        except BaseException as exc:
            primary, primary_traceback = exc, exc.__traceback__
        finally:
            with guard.cleanup():
                signal.alarm(0)
                for channel in channels:
                    try:
                        channel.close()
                    except BaseException as exc:
                        cleanup_errors.append(
                            f"GPIO18 cleanup: {type(exc).__name__}: {exc}"
                        )
                try:
                    after = core.system_snapshot()
                except BaseException as exc:
                    cleanup_errors.append(
                        f"Post-run snapshot: {type(exc).__name__}: {exc}"
                    )
            if guard.received and primary is None:
                primary = SafetyAbort("Termination signal received during cleanup")
    if cleanup_errors:
        print("Cleanup failures: " + "; ".join(cleanup_errors), file=sys.stderr)
        if primary is None:
            primary = BenchError("PWM cleanup failed")
    if primary is not None:
        raise primary.with_traceback(primary_traceback)
    issues = core.thermal_issues(after, 75000)
    if issues:
        raise BenchError("Post-run thermal gate failed: " + "; ".join(issues))
    end = time.monotonic_ns()
    if end - start >= 15_000_000_000:
        raise BenchError("Experiment exceeded the authorized sub-15-second bound")
    if len(channels) != 1 or not all(
        channel.released
        and channel.cleanup_low_confirmed
        and channel.cleanup_final_readback
        == {
            "period": channel.period_ns,
            "duty_cycle": 0,
            "polarity": "normal",
            "enable": 0,
        }
        for channel in channels
    ):
        raise BenchError(
            "Cannot confirm GPIO18 normal-low state and fresh export release"
        )
    return {
        "schema_version": 1,
        "mode": MODE,
        "model": model,
        "begin_ns": start,
        "end_ns": end,
        "phases": phases,
        "sysfs_released": True,
        "low_confirmed": True,
        "low_confirmation_semantics": "normal-zero enabled sysfs command/readback plus settle; not electrical proof",
        "helper_pid": os.getpid(),
        "outputs": [
            {
                **channel.provider.identity(),
                "backend": "rp1-pwm",
                "frequency": channel.frequency,
                "duty_u16": channel.duty_u16,
                "period_ns": channel.period_ns,
                "active_duty_ns": channel.active_duty_ns,
                "sysfs_events": channel.events,
                "cleanup_low_confirmed": channel.cleanup_low_confirmed,
                "cleanup_final_readback": channel.cleanup_final_readback,
                "released": channel.released,
            }
            for channel in channels
        ],
        "discovered_untouched_outputs": [providers[1].identity()],
        "burner_pids": [],
        "hard_max_run_seconds": MAX_RUN_SECONDS,
        "watchdog_scope": "normal operation only; low recovery cleanup defers signals",
        "thermal": {"before": before, "after": after},
        "cleanup_errors": cleanup_errors,
        "metadata": metadata,
        "transition_policy": "disable only for polarity changes; cleanup always disables",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args(argv)
    try:
        result = experiment()
    except BaseException as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
