"""Lab-only enabled, period-settled RP1 PWM transition characterization.

The approved logical states, ownership, thermal gates and conservative cleanup
come from the frozen state helper. Ordinary transitions remain enabled: outgoing
normal PWM is first commanded to zero for two current periods, and changed
periods settle for two maximum old/new periods before active duty or inversion.
This exercises scalar sysfs behavior; it is not an atomic API or production fix.
Cached sysfs readbacks and strategy waits are not electrical measurements.
"""

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import kernel_pwm_state_eval as state

core = state.core
STRATEGY = "enabled-period-settled-v1"
ConservativePWMChannel = state.StatePWMChannel


class SettledPWMChannel(ConservativePWMChannel):
    def __init__(self, provider, **kwargs):
        self.strategy_waits = []
        super().__init__(provider, **kwargs)

    def _wait_strategy(self, reason, duration, readback):
        event = {
            "generation": self.generation,
            "scope": self.scope,
            "reason": reason,
            "duration_seconds": duration,
            "begin_ns": time.monotonic_ns(),
            "state": dict(readback),
        }
        try:
            time.sleep(duration)
        except BaseException as exc:
            event.update(status="error", error=f"{type(exc).__name__}: {exc}")
            raise
        else:
            event["status"] = "ok"
        finally:
            event["end_ns"] = time.monotonic_ns()
            self.strategy_waits.append(event)

    def transition(self, frequency, duty_u16):
        target = state.requested_state(frequency, duty_u16)
        if not self.owned:
            raise core.BenchError("Missing ownership")
        old_period = self.period_ns
        current_polarity = self.io.read(self.path / "polarity")
        current_duty = int(self.io.read(self.path / "duty_cycle"))
        if current_polarity not in ("normal", "inversed") or (
            current_polarity == "inversed" and current_duty != 0
        ):
            raise core.BenchError(
                "Unexpected starting polarity or inversed nonzero duty"
            )
        self.readback(current_polarity, current_duty, 1)
        change_period = target["period"] != old_period
        if current_polarity == "inversed" and target["polarity"] == "normal":
            # Raw zero is already established. Remove inversion while enabled
            # before requesting a nonzero duty or a different normal period.
            self._write("polarity", "normal")
            self.readback("normal", 0, 1)
            current_polarity, current_duty = "normal", 0
        if current_polarity == "normal" and (
            target["polarity"] == "inversed" or change_period
        ):
            self._write("duty_cycle", 0)
            zero_state = self.readback("normal", 0, 1)
            self._wait_strategy(
                "normal_zero_settle", 2 * old_period / 1_000_000_000, zero_state
            )
            current_duty = 0
        if change_period:
            # Both normal and inversed branches have a verified enabled raw-zero
            # state. Already-high period changes intentionally keep inversion.
            self.readback(current_polarity, 0, 1)
            self._set_period(frequency)
            zero_state = self.readback(current_polarity, 0, 1)
            self._wait_strategy(
                "period_settle",
                2 * max(old_period, target["period"]) / 1_000_000_000,
                zero_state,
            )
        if target["polarity"] == "inversed":
            if current_polarity == "normal":
                self._write("polarity", "inversed")
        else:
            self._write("duty_cycle", target["duty_cycle"])
        final_state = self.readback(target["polarity"], target["duty_cycle"], 1)
        self.last_requested_frequency = frequency
        self.last_requested_duty_u16 = duty_u16
        return final_state


def experiment(mode):
    instances = []

    class RecordedChannel(SettledPWMChannel):
        def __init__(self, provider, **kwargs):
            instances.append(self)
            super().__init__(provider, **kwargs)

    original = state.StatePWMChannel
    state.StatePWMChannel = RecordedChannel
    try:
        result = state.experiment(mode)
    finally:
        state.StatePWMChannel = original
    result["transition_strategy"] = STRATEGY
    result["transition_policy"] = (
        "enabled zero-duty/period-settled scalar writes; conservative disabled cleanup"
    )
    result["strategy_waits"] = [
        event for channel in instances for event in channel.strategy_waits
    ]
    result["metadata"]["source_sha256"]["kernel_pwm_settled_eval.py"] = hashlib.sha256(
        Path(__file__).read_bytes()
    ).hexdigest()
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", required=True, choices=tuple(state.SEQUENCES))
    args = parser.parse_args(argv)
    try:
        result = experiment(args.mode)
    except BaseException as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
