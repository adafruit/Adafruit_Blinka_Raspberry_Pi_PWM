"""Bounded fake-sysfs state tests; never invoke GPIO, SSH or subprocesses."""

import importlib.util
import json
import signal
import sys
from pathlib import Path

import pytest

import test_kernel_pwm_inverse_eval as inverse_fakes

SCRIPT = Path(__file__).with_name("kernel_pwm_state_eval.py")
spec = importlib.util.spec_from_file_location("kernel_pwm_state_eval", SCRIPT)
state = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = state
spec.loader.exec_module(state)
core = state.core
FakeIO = inverse_fakes.FakeIO


@pytest.fixture
def tree(tmp_path):
    return inverse_fakes.common_fakes.tree.__wrapped__(tmp_path)


@pytest.fixture
def provider(tree):
    return core.discover(tree[1], tree[0])[1][0]


@pytest.fixture(autouse=True)
def no_sleep_or_physical_signals(monkeypatch):
    monkeypatch.setattr(state.time, "sleep", lambda _seconds: None)
    monkeypatch.setattr(state.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(state.signal, "signal", lambda _sig, _handler: signal.SIG_DFL)


def make_channel(provider, **kwargs):
    io = kwargs.pop("io", FakeIO())
    channel = state.StatePWMChannel(provider, io=io, **kwargs)
    return channel, io


def configure_experiment(tree, monkeypatch, *, guard=None, snapshots=None):
    found = core.discover(tree[1], tree[0])[1]
    monkeypatch.setattr(
        core, "discover", lambda: ("Raspberry Pi 5 Model B Rev 1.0", found)
    )
    monkeypatch.setattr(core, "debug_metadata", lambda: {"fake": True})
    safe = {"temperature_millic": "42000", "throttled": "throttled=0x0"}
    if snapshots is None:
        monkeypatch.setattr(core, "system_snapshot", lambda: dict(safe))
    else:
        snapshots = iter(snapshots)
        monkeypatch.setattr(core, "system_snapshot", lambda: next(snapshots))
    io = FakeIO()
    monkeypatch.setattr(core, "SysfsIO", lambda: io)
    if guard is not None:
        monkeypatch.setattr(core, "SafetySignals", lambda: guard)
    return found, io


@pytest.mark.parametrize("frequency", [50, 500])
@pytest.mark.parametrize("duty", [0, 4915, 32768, 65535])
def test_approved_logical_states_exact_mapping(frequency, duty):
    result = state.requested_state(frequency, duty)
    period = 1_000_000_000 // frequency
    assert result == {
        "period": period,
        "enable": 1,
        "polarity": "inversed" if duty == 65535 else "normal",
        "duty_cycle": 0 if duty == 65535 else period * duty // 65535,
    }


@pytest.mark.parametrize(
    "frequency,duty",
    [
        (0, 0),
        (60, 4915),
        (50, 65534),
        (50.0, 4915),
        (True, 0),
        (50, float("nan")),
        (float("inf"), 4915),
        (50, True),
    ],
)
def test_invalid_requests_refused_without_writes(provider, frequency, duty):
    channel, io = make_channel(provider)
    count = len(io.log)
    with pytest.raises(core.BenchError, match="Only frequencies"):
        channel.transition(frequency, duty)
    assert len(io.log) == count
    channel.close()


def test_period_shrink_zeroes_duty_before_period_and_tracks_acceptance(provider):
    channel, io = make_channel(provider)
    channel.transition(50, 4915)
    io.log.clear()
    result = channel.transition(500, 32768)
    assert io.writes == [
        ("enable", 0),
        ("duty_cycle", 0),
        ("period", 2_000_000),
        ("duty_cycle", 2_000_000 * 32768 // 65535),
        ("enable", 1),
    ]
    assert result == state.requested_state(500, 32768)
    assert channel.frequency == 500 and channel.period_ns == 2_000_000
    channel.close()
    assert channel.released and channel.cleanup_low_confirmed
    assert channel.period_ns == 20_000_000


def test_high_never_requests_normal_full_duty_and_returns_directly_to_interior(
    provider,
):
    channel, io = make_channel(provider)
    channel.transition(50, 65535)
    assert channel.readback("inversed", 0, 1)["duty_cycle"] == 0
    result = channel.transition(500, 32768)
    assert result == state.requested_state(500, 32768)
    assert all(
        value not in (20_000_000, 2_000_000)
        for path, value in io.log
        if path.name == "duty_cycle"
    )
    channel.close()


def test_same_period_and_polarity_ordinary_duty_change_keeps_enabled(provider):
    channel, io = make_channel(provider)
    io.log.clear()
    channel.transition(50, 32768)
    channel.transition(50, 0)
    assert io.writes == [("duty_cycle", 20_000_000 * 32768 // 65535), ("duty_cycle", 0)]
    channel.close()


def test_preexisting_export_and_non_header_are_never_borrowed(provider, tree):
    io = FakeIO()
    found = core.discover(tree[1], tree[0])[1]
    with pytest.raises(core.BenchError, match="Only GPIO18"):
        state.StatePWMChannel(found[1], io=io)
    provider.channel_path.mkdir()
    with pytest.raises(core.BenchError, match="existing exported"):
        state.StatePWMChannel(provider, io=io)
    assert io.log == []


def test_constructor_period_failure_preserves_primary_and_registered_recovery(provider):
    io = FakeIO()
    io.fail = ("period", 1)
    errors, registry = [], []
    with pytest.raises(OSError, match="injected period failure"):
        state.StatePWMChannel(
            provider, io=io, cleanup_errors=errors, register=registry.append
        )
    assert len(registry) == 1 and registry[0].released
    assert registry[0].period_ns == 20_000_000 and registry[0].cleanup_low_confirmed
    assert errors == []


@pytest.mark.parametrize("accepted_before_error", [False, True])
def test_period_write_failure_tracks_actual_accepted_period_then_recovers(
    provider, accepted_before_error
):
    channel, io = make_channel(provider)
    channel.transition(50, 65535)
    io.counts.clear()
    if accepted_before_error:
        io.hook = lambda path, value: (
            (_ for _ in ()).throw(OSError("accepted then failed"))
            if path.name == "period" and value == 2_000_000
            else None
        )
    else:
        io.fail = ("period", 1)
    with pytest.raises(OSError):
        channel.transition(500, 32768)
    assert channel.period_ns == (2_000_000 if accepted_before_error else 20_000_000)
    assert channel.frequency == (500 if accepted_before_error else 50)
    channel.close()
    assert channel.period_ns == 20_000_000 and channel.released
    assert channel.cleanup_errors == []


def test_signal_during_period_write_updates_tracking_before_abort(provider):
    guard = core.SafetySignals()
    channel, io = make_channel(provider, guard=guard)
    io.hook = lambda path, value: (
        guard.handler(signal.SIGTERM, None)
        if path.name == "period" and value == 2_000_000
        else None
    )
    with pytest.raises(core.SafetyAbort, match="ownership transition"):
        channel.transition(500, 32768)
    assert channel.period_ns == 2_000_000 and channel.frequency == 500
    channel.close()
    assert channel.released and channel.period_ns == 20_000_000


def test_signal_during_initial_export_registers_and_recovers_owner(provider):
    guard, io, registry = core.SafetySignals(), FakeIO(), []
    io.hook = lambda path, _value: (
        guard.handler(signal.SIGTERM, None) if path.name == "export" else None
    )
    with pytest.raises(core.SafetyAbort):
        state.StatePWMChannel(provider, io=io, guard=guard, register=registry.append)
    assert len(registry) == 1 and registry[0].released
    assert not provider.channel_path.exists()


@pytest.mark.parametrize(
    "failure",
    [
        ("polarity", 1),
        ("duty_cycle", 2),
        ("enable", 3),
        ("enable", 4),
        ("unexport", 1),
    ],
)
def test_unsafe_cleanup_failure_retains_export(provider, failure):
    channel, io = make_channel(provider)
    channel.transition(500, 65535)
    io.counts.clear()
    io.log.clear()
    io.fail = failure
    channel.close()
    assert channel.owned and not channel.released and channel.path.exists()
    assert channel.cleanup_errors and any(
        "injected" in item for item in channel.cleanup_errors
    )
    if failure[0] in ("polarity", "duty_cycle"):
        assert ("enable", 1) not in io.writes


def test_recovery_read_failure_latches_error_even_if_final_low_releases(provider):
    channel, io = make_channel(provider)
    original_read = io.read
    failed = False

    def fail_once(path):
        nonlocal failed
        if path.name == "period" and not failed:
            failed = True
            raise OSError("recovery read failed")
        return original_read(path)

    io.read = fail_once
    channel.close()
    assert channel.released and channel.cleanup_low_confirmed
    assert any("recovery read failed" in error for error in channel.cleanup_errors)


@pytest.mark.parametrize("mode", ["direct", "frequency", "lifecycle"])
def test_modes_release_all_generations_and_never_touch_other_outputs(
    tree, monkeypatch, mode
):
    found, io = configure_experiment(tree, monkeypatch)
    sleeps = []
    monkeypatch.setattr(state.time, "sleep", sleeps.append)
    result = state.experiment(mode)
    assert (
        result["mode"] == mode and result["sysfs_released"] and result["low_confirmed"]
    )
    assert result["helper_pid"] > 0 and result["cleanup_errors"] == []
    assert result["burner_pids"] == []
    assert [phase["name"] for phase in result["phases"]] == [
        phase[0] for phase in state.SEQUENCES[mode]
    ]
    count = 2 if mode == "lifecycle" else 1
    assert len(result["outputs"]) == count
    assert [output["generation"] for output in result["outputs"]] == list(
        range(1, count + 1)
    )
    for output in result["outputs"]:
        assert output["cleanup_low_confirmed"] and output["released"]
        assert output["frequency"] == 50 and output["period_ns"] == 20_000_000
        assert output["cleanup_final_readback"] == state.requested_state(50, 0) | {
            "enable": 0
        }
    for phase in result["phases"]:
        assert phase["sysfs_readbacks"] == phase["end_readbacks"]
        assert phase["sysfs_readbacks"]["18"] == state.requested_state(
            phase["frequency"], phase["duty_u16"]
        )
        assert phase["period_ns"] == phase["sysfs_readbacks"]["18"]["period"]
        assert phase["duty_ns"] == phase["sysfs_readbacks"]["18"]["duty_cycle"]
    assert len([value for path, value in io.log if path.name == "export"]) == count
    assert len([value for path, value in io.log if path.name == "unexport"]) == count
    assert all(
        path.parent in (found[0].chip, found[0].channel_path) for path, _value in io.log
    )
    assert all(not provider.channel_path.exists() for provider in found)
    assert set(result["metadata"]["source_sha256"]) == {
        "kernel_pwm_state_eval.py",
        "kernel_pwm_inverse_eval.py",
        "kernel_pwm_eval.py",
    }
    if mode == "lifecycle":
        assert [phase["generation"] for phase in result["phases"]] == [1] * 3 + [2] * 3
        assert len(result["lifecycle_quiet_intervals"]) == 1
        assert result["lifecycle_quiet_intervals"][0]["duration_seconds"] == 0.2
        assert sleeps == [0.1, 0.2, 0.4, 0.3, 0.1, 0.2, 0.1, 0.2, 0.4, 0.3, 0.1]
        assert [path.name for path, _value in io.log].index("unexport") < [
            path.name for path, _value in io.log
        ].index("export", 1)
    else:
        assert result["lifecycle_quiet_intervals"] == []


def test_lifecycle_cleanup_failure_prevents_second_export_and_no_success_json(
    tree, monkeypatch, capsys
):
    _found, io = configure_experiment(tree, monkeypatch)
    io.fail = ("unexport", 1)
    assert state.main(["--mode", "lifecycle"]) == 1
    assert len([value for path, value in io.log if path.name == "export"]) == 1
    captured = capsys.readouterr()
    assert captured.out == "" and "Cleanup failures:" in captured.err


def test_signal_during_lifecycle_close_prevents_second_generation(
    tree, monkeypatch, capsys
):
    guard = core.SafetySignals()
    found, io = configure_experiment(tree, monkeypatch, guard=guard)
    io.hook = lambda path, _value: (
        guard.handler(signal.SIGTERM, None) if path.name == "unexport" else None
    )
    assert state.main(["--mode", "lifecycle"]) == 1
    assert len([value for path, value in io.log if path.name == "export"]) == 1
    assert not found[0].channel_path.exists()
    captured = capsys.readouterr()
    assert captured.out == "" and "SafetyAbort" in captured.err


def test_thermal_preflight_refuses_all_exports(tree, monkeypatch, capsys):
    bad = {"temperature_millic": "66000", "throttled": "throttled=0x0"}
    _found, io = configure_experiment(tree, monkeypatch, snapshots=[bad, bad])
    assert state.main(["--mode", "direct"]) == 1
    assert io.log == [] and capsys.readouterr().out == ""


def test_cli_json_success(monkeypatch, capsys):
    monkeypatch.setattr(state, "experiment", lambda mode: {"mode": mode})
    assert state.main(["--mode", "frequency"]) == 0
    captured = capsys.readouterr()
    assert json.loads(captured.out) == {"mode": "frequency"}
    assert captured.err == ""
