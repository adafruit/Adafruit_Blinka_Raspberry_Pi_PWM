"""Exclusive marker recovery archive; inspect, safely extract, replay every report."""

import hashlib
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

LAB = Path(__file__).resolve().parent
ARCHIVE = (
    LAB.parent
    / "Adafruit_Blinka_Raspberry_Pi_PWM/hardware-evaluation/2026-10-07/pi5-electrical-marker-evaluation.tar.gz"
)
CAPTURES = json.loads((LAB / "oct7-gpio-pwm-marker-plan.json").read_text())[
    "capture_order"
]
TARGETS = CAPTURES + [
    "gpio_pwm_marker_eval.py",
    "capture_gpio_pwm_marker.py",
    "analyze_gpio_pwm_marker.py",
    "test_gpio_pwm_marker_eval.py",
    "test_capture_gpio_pwm_marker.py",
    "test_analyze_gpio_pwm_marker.py",
    "native_pwm_updates_eval.py",
    "native_pwm_half50_eval.py",
    "kernel_pwm_lgpio_baseline_eval.py",
    "kernel_pwm_eval.py",
    "baseline_pwmout.py",
    "lgpio_pin.py",
    "capture_native_pwm_half50.py",
    "capture_kernel_pwm_lgpio_baseline.py",
    "capture_pwm.py",
    "analyze_kernel_pwm_inverse.py",
    "test_native_pwm_updates_eval.py",
    "test_native_pwm_half50_eval.py",
    "test_kernel_pwm_lgpio_baseline_eval.py",
    "oct7-gpio-pwm-marker-plan.json",
    "oct7-gpio-pwm-marker-manifest.json",
    "oct7-gpio-pwm-marker-preflight.json",
    "oct7-gpio-pwm-marker-postflight.json",
    "oct7-gpio-pwm-marker-independent-audit.json",
    "marker-notes.txt",
    "oct7-native-half50-runtime",
    "checkpoint_gpio_pwm_marker.py",
]
REPLAY = r"""
import json,pathlib,sys
sys.path.insert(0,sys.argv[1])
import analyze_gpio_pwm_marker as analysis
root=pathlib.Path(sys.argv[1])
names=json.loads((root/"oct7-gpio-pwm-marker-plan.json").read_text())["capture_order"]
for name in names:
    assert analysis.analyze(root/name)==json.loads((root/name/"analysis.json").read_text()),name
print(json.dumps({"marker_reports_reproduced":len(names)}))
"""


def main():
    if len(TARGETS) != len(set(TARGETS)):
        raise ValueError("Duplicate recovery targets")
    files = {}
    for name in TARGETS:
        path = LAB / name
        if not path.exists() or path.is_symlink():
            raise ValueError("Missing or linked target: " + name)
        for member in [path] if path.is_file() else sorted(path.rglob("*")):
            if member.is_symlink() or not (member.is_file() or member.is_dir()):
                raise ValueError("Unsupported member: " + str(member))
            if member.is_file():
                files[str(member.relative_to(LAB))] = hashlib.sha256(
                    member.read_bytes()
                ).hexdigest()
    with (
        ARCHIVE.open("xb") as stream,
        tarfile.open(fileobj=stream, mode="w:gz") as archive,
    ):
        for name in TARGETS:
            archive.add(LAB / name, arcname=name)
    extracted = Path(
        tempfile.mkdtemp(prefix="blinka-marker-checkpoint-", dir="/private/tmp")
    )
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if (
                path.is_absolute()
                or ".." in path.parts
                or not (member.isfile() or member.isdir())
            ):
                raise ValueError("Unsafe archive member: " + member.name)
        archive.extractall(extracted, filter="data")
    recovered = {
        str(path.relative_to(extracted)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in extracted.rglob("*")
        if path.is_file()
    }
    if recovered != files:
        raise ValueError("Archive file set/bytes differ")
    result = subprocess.run(
        [sys.executable, "-c", REPLAY, str(extracted)],
        cwd=extracted,
        capture_output=True,
        text=True,
        check=True,
    )
    report = {
        "archive": str(ARCHIVE),
        "size_bytes": ARCHIVE.stat().st_size,
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "top_level_targets": len(TARGETS),
        "regular_files": len(files),
        "safe_extraction": str(extracted),
        "all_file_bytes_match": True,
        "replay": json.loads(result.stdout),
        "replay_stderr": result.stderr,
    }
    with (LAB / "oct7-gpio-pwm-marker-checkpoint-verification.json").open(
        "x"
    ) as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
