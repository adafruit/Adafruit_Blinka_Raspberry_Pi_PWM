"""Fake-only two-channel acquisition and marker receipt validation tests."""

import hashlib
import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_gpio_pwm_marker as bench
import pytest
import test_gpio_pwm_marker_eval as helper_fakes

ROOT = "/tmp/blinka-pwm-gpio-marker.abc123"
PYTHON = "/tmp/blinka-pwm-oct6.F3SDcm/venv/bin/python"
old_environment = helper_fakes.old_environment
native_environment = helper_fakes.native_environment
original_environment = helper_fakes.original_environment
environment = helper_fakes.environment


def configure(monkeypatch, backend="native", scenario="success"):
    events = []
    manifest = {"schema_version": 1, "source_sha256": {"fake": "a" * 64}}
    receipt = {
        "backend": bench.BACKEND_NAMES[backend],
        "manifest_path": ROOT + "/manifest.json",
    }
    monkeypatch.setattr(bench.helper, "load_manifest", lambda _path: manifest)
    local = MagicMock(return_value=manifest["source_sha256"])
    validate = MagicMock()
    if scenario == "bad_receipt":
        validate.side_effect = ValueError("bad marker receipt")
    monkeypatch.setattr(bench, "validate_local_manifest", local)
    monkeypatch.setattr(bench, "validate_remote", validate)
    capture = MagicMock()
    capture.__enter__.return_value = capture
    capture.stop.side_effect = lambda: events.append("stop")

    def save(path):
        events.append("save")
        if scenario == "save_error":
            raise OSError("save failed")
        Path(path).write_bytes(b"fake SAL")

    def export(path, **kwargs):
        assert kwargs == {"digital_channels": [0, 1]}
        events.append("export")
        (Path(path) / "digital_0.bin").write_bytes(b"fake PWM edges")
        if scenario != "missing_marker":
            (Path(path) / "digital_1.bin").write_bytes(b"fake marker edges")

    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = export
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=MagicMock(return_value=manager)),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            PYTHON,
            ROOT + "/gpio_pwm_marker_eval.py",
            "--backend",
            backend,
            "--manifest",
            ROOT + "/manifest.json",
        ]
        assert set(kwargs) == {"stdout", "stderr", "text", "check", "timeout"}
        assert (
            kwargs["text"] is True
            and kwargs["check"] is False
            and kwargs["timeout"] == 30
        )
        if scenario in ("timeout", "interrupt"):
            kwargs["stdout"].write("partial receipt")
            kwargs["stderr"].write("partial diagnostic")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            raise KeyboardInterrupt("interrupted")
        kwargs["stdout"].write(json.dumps(receipt))
        return subprocess.CompletedProcess(
            command, 1 if scenario == "helper_failed" else 0
        )

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(
        bench.time, "sleep", lambda duration: events.append(("sleep", duration))
    )
    return events, manager, runner, local, validate, manifest, receipt


@pytest.mark.parametrize("backend", bench.BACKENDS)
def test_capture_both_unfiltered_channels_and_defer_verdict(
    monkeypatch, tmp_path, backend
):
    events, manager, runner, _local, validate, manifest, receipt = configure(
        monkeypatch, backend
    )
    output = tmp_path / "capture"
    result = bench.capture_test(
        output, ROOT, PYTHON, backend, tmp_path / "manifest.json"
    )
    assert events == [("sleep", 0.5), "ssh", ("sleep", 0.2), "stop", "save", "export"]
    manager.start_capture.assert_called_once_with(
        device_id="81F8C2631DF5BF30",
        device_configuration={
            "enabled_digital_channels": [0, 1],
            "digital_sample_rate": 100_000_000,
        },
    )
    runner.assert_called_once()
    validate.assert_called_once_with(receipt, backend, manifest)
    assert result["collection_success"] is True
    assert result["outputs"] == [
        {"gpio": 18, "saleae_channel": 0, "backend": bench.BACKEND_NAMES[backend]},
        {"gpio": 23, "saleae_channel": 1, "backend": "gpiod-marker"},
    ]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert result["parity_evaluated"] is False and result["analysis_deferred"] is True
    assert json.loads((output / "manifest.json").read_text()) == manifest
    assert json.loads((output / "results.json").read_text()) == result
    assert (output / "waveform.sal").read_bytes() == b"fake SAL"
    assert (output / "digital_0.bin").read_bytes() == b"fake PWM edges"
    assert (output / "digital_1.bin").read_bytes() == b"fake marker edges"


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "save_error",
        "missing_marker",
        "simulation",
        "helper_failed",
        "bad_receipt",
    ],
)
def test_failures_keep_metadata_and_available_raw_evidence(
    monkeypatch, tmp_path, scenario
):
    events, _manager, runner, _local, _validate, _manifest, _receipt = configure(
        monkeypatch, scenario=scenario
    )
    output = tmp_path / "capture"
    with pytest.raises((ValueError, RuntimeError, KeyboardInterrupt)):
        bench.capture_test(output, ROOT, PYTHON, "native", tmp_path / "manifest.json")
    acquisition = json.loads((output / "acquisition.json").read_text())
    result = json.loads((output / "results.json").read_text())
    assert result["collection_success"] is False and result["receipt_validation_error"]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    if scenario == "simulation":
        runner.assert_not_called()
        assert not events
    else:
        assert events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
        assert (output / "digital_0.bin").is_file()
        if scenario != "missing_marker":
            assert (output / "digital_1.bin").is_file()
    if scenario in ("timeout", "interrupt"):
        assert (output / "remote.stdout").read_text() == "partial receipt"
        assert (output / "remote.stderr").read_text() == "partial diagnostic"
        assert acquisition["remote_returncode"] == (
            124 if scenario == "timeout" else None
        )
    if scenario == "save_error":
        assert acquisition["evidence_errors"] == ["save_capture: OSError: save failed"]


@pytest.mark.parametrize(
    "root,python,backend",
    [
        ("/tmp", PYTHON, "native"),
        (ROOT, PYTHON + ";unsafe", "lgpio"),
        (ROOT, PYTHON, "other"),
    ],
)
def test_invalid_remote_inputs_refuse_before_output_and_ssh(
    monkeypatch, tmp_path, root, python, backend
):
    _events, _manager, runner, local, _validate, _manifest, _receipt = configure(
        monkeypatch
    )
    with pytest.raises(ValueError):
        bench.capture_test(
            tmp_path / "capture", root, python, backend, tmp_path / "manifest.json"
        )
    runner.assert_not_called()
    local.assert_not_called()
    assert not (tmp_path / "capture").exists()


def test_exclusive_output_preserves_existing_evidence(monkeypatch, tmp_path):
    _events, _manager, runner, _local, _validate, _manifest, _receipt = configure(
        monkeypatch
    )
    output = tmp_path / "capture"
    output.mkdir()
    sentinel = output / "previous.txt"
    sentinel.write_text("keep")
    with pytest.raises(FileExistsError):
        bench.capture_test(output, ROOT, PYTHON, "native", tmp_path / "manifest.json")
    assert sentinel.read_text() == "keep"
    runner.assert_not_called()


def test_local_manifest_checks_python_but_not_pi_binaries(monkeypatch):
    directory = Path(bench.__file__).parent
    package = (
        directory.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src/adafruit_blinka_raspberry_pi_pwm"
    )
    paths = [
        directory / name
        for name in (
            "gpio_pwm_marker_eval.py",
            "native_pwm_updates_eval.py",
            "native_pwm_half50_eval.py",
            "kernel_pwm_lgpio_baseline_eval.py",
            "kernel_pwm_eval.py",
            "baseline_pwmout.py",
            "lgpio_pin.py",
        )
    ]
    hashes = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths
    }
    hashes.update(
        {
            "adafruit_blinka_raspberry_pi_pwm/" + name: hashlib.sha256(
                (package / name).read_bytes()
            ).hexdigest()
            for name in ("__init__.py", "_software.py")
        }
    )
    hashes["adafruit_blinka_raspberry_pi_pwm/_native.so"] = "f" * 64
    monkeypatch.setattr(bench.helper, "validate_manifest", lambda _manifest: hashes)
    assert bench.validate_local_manifest({}) == hashes
    hashes["adafruit_blinka_raspberry_pi_pwm/_software.py"] = "0" * 64
    with pytest.raises(ValueError, match="local production"):
        bench.validate_local_manifest({})


def test_cli_requires_backend_and_reports_no_waveform_verdict(
    monkeypatch, tmp_path, capsys
):
    capture = MagicMock(return_value={"collection_success": True})
    monkeypatch.setattr(bench, "capture_test", capture)
    args = [
        str(tmp_path / "capture"),
        "--remote-root",
        ROOT,
        "--remote-python",
        PYTHON,
        "--manifest",
        str(tmp_path / "manifest.json"),
    ]
    with pytest.raises(SystemExit) as error:
        bench.main(args)
    assert error.value.code == 2
    capture.assert_not_called()
    assert bench.main(args + ["--backend", "lgpio"]) == 0
    capture.assert_called_once_with(
        tmp_path / "capture", ROOT, PYTHON, "lgpio", tmp_path / "manifest.json"
    )
    summary = json.loads(capsys.readouterr().out)
    assert summary["backend"] == "original-blinka-lgpio"
    assert summary["waveform_accepted"] is None and summary["parity_evaluated"] is False


@pytest.mark.parametrize("backend", bench.BACKENDS)
def test_real_public_api_fake_marker_receipts_validate(environment, backend):
    _native, _original, _marker, _guard, manifest, _sleeps = environment
    receipt = bench.helper.experiment(backend, ROOT + "/manifest.json")
    assert receipt["success"]
    bench.validate_remote(receipt, backend, manifest)
    assert bench.validate_local_manifest(manifest) == manifest["source_sha256"]


@pytest.mark.parametrize(
    "backend,problem",
    [
        ("native", "order"),
        ("native", "bounds"),
        ("lgpio", "line"),
        ("lgpio", "release"),
    ],
)
def test_actual_marker_receipt_rejects_invalid_order_bounds_and_ownership(
    environment, backend, problem
):
    _native, _original, _marker, _guard, manifest, _sleeps = environment
    receipt = bench.helper.experiment(backend, ROOT + "/manifest.json")
    assert receipt["success"]
    if problem == "order":
        index = next(
            i
            for i, event in enumerate(receipt["setter_events"])
            if event["operation"] == "PWMOut.frequency"
        )
        events = receipt["setter_events"]
        events[index], events[index + 1] = events[index + 1], events[index]
    elif problem == "bounds":
        receipt["setter_events"][0]["caller_end_ns"] = receipt["end_ns"]
    elif problem == "line":
        event = next(
            event for event in receipt["events"] if event["operation"] == "tx_pwm"
        )
        event["arguments"]["gpio"] = 23
    else:
        receipt["marker"]["gpio23_released"] = False
    with pytest.raises(ValueError):
        bench.validate_remote(receipt, backend, manifest)
