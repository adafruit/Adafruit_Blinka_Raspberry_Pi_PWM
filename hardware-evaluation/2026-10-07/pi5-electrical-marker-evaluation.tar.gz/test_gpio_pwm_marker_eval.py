"""Marker/PWM ownership fakes; no real GPIO, SSH, processes or native worker."""

import hashlib
import signal
from enum import Enum
from pathlib import Path
from types import SimpleNamespace

import gpio_pwm_marker_eval as bench
import pytest
import test_kernel_pwm_lgpio_baseline_eval as original_fakes
import test_native_pwm_updates_eval as native_fakes

ROOT = "/tmp/blinka-pwm-gpio-marker.abc123"
old_environment = native_fakes.old_environment
native_environment = native_fakes.environment
original_environment = original_fakes.environment


class Direction(Enum):
    OUTPUT = "output"


@pytest.fixture
def environment(native_environment, original_environment, monkeypatch):
    native_state, guard, public_module, _native_manifest, _old_sleeps = (
        native_environment
    )
    original, _dt, _pwm, _original_sleeps = original_environment
    marker = SimpleNamespace(
        claimed=False, foreign=False, level=0, log=[], fail=None, hook=None
    )
    identity = dict(native_fakes.old_fakes.IDENTITY)
    value = native_fakes.old_fakes.Value

    def note(name, *args):
        marker.log.append((name, *args))
        if marker.hook:
            marker.hook(name)
        if marker.fail == name:
            raise OSError("injected marker " + name)

    class Chip:
        def __init__(self, path):
            assert path == identity["gpiochip"]
            note("chip_open")

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            note("chip_close")

        def get_info(self):
            return SimpleNamespace(name="gpiochip4", label="pinctrl-rp1", num_lines=54)

        def get_line_info(self, offset):
            assert offset in (18, 23)
            note("line_info", offset)
            if offset == 23:
                used, consumer = (
                    marker.claimed or marker.foreign,
                    "foreign"
                    if marker.foreign
                    else "blinka-pwm-setter-marker"
                    if marker.claimed
                    else None,
                )
            else:
                used = native_state.claimed or original.claimed or original.foreign
                consumer = (
                    "foreign" if original.foreign else "pwm-owner" if used else None
                )
            return SimpleNamespace(
                offset=offset, name="GPIO" + str(offset), used=used, consumer=consumer
            )

    class Request:
        offsets = [23]
        chip_name = "gpiochip4"

        def set_value(self, offset, level):
            assert offset == 23 and marker.claimed
            note("high" if level is value.ACTIVE else "low", offset)
            marker.level = level.value

        def get_value(self, offset):
            assert offset == 23 and marker.claimed
            note("read", offset)
            return value.ACTIVE if marker.level else value.INACTIVE

        def release(self):
            note("release")
            marker.claimed = False

    def request_lines(path, *, consumer, config):
        assert path == identity["gpiochip"] and consumer == "blinka-pwm-setter-marker"
        assert (
            set(config) == {23}
            and config[23].direction is Direction.OUTPUT
            and config[23].output_value is value.INACTIVE
        )
        note("request_begin")
        marker.claimed = True
        request = Request()
        note("claim")
        return request

    library = SimpleNamespace(
        __version__="2.5.0",
        Chip=Chip,
        request_lines=request_lines,
        LineSettings=lambda **kwargs: SimpleNamespace(**kwargs),
        line=SimpleNamespace(Value=value, Direction=Direction),
    )
    package = (
        Path(bench.__file__).resolve().parent.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src"
        / bench.base.PACKAGE
    )
    hashes = {name: "a" * 64 for name in bench.SOURCE_KEYS}
    hashes.update(bench.SOURCE_PINS)
    hashes["gpio_pwm_marker_eval.py"] = hashlib.sha256(
        Path(bench.__file__).read_bytes()
    ).hexdigest()
    hashes[bench.base.PACKAGE + "/__init__.py"] = hashlib.sha256(
        (package / "__init__.py").read_bytes()
    ).hexdigest()
    hashes[bench.base.PACKAGE + "/_software.py"] = hashlib.sha256(
        (package / "_software.py").read_bytes()
    ).hexdigest()
    manifest = {"schema_version": 1, "source_sha256": hashes}
    monkeypatch.setattr(bench, "approved_manifest_path", lambda path: Path(path))
    monkeypatch.setattr(bench, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(bench, "source_hashes", lambda: dict(hashes))
    monkeypatch.setattr(bench, "load_libraries", lambda: (library, original))
    monkeypatch.setattr(bench, "load_native_api", lambda: public_module)
    monkeypatch.setattr(bench.baseline, "preflight", lambda: dict(identity))
    monkeypatch.setattr(
        bench.core,
        "system_snapshot",
        lambda: {"temperature_millic": "42000", "throttled": "throttled=0x0"},
    )
    clock, sleeps = [1_000_000_000], []

    def now():
        clock[0] += 1_000
        return clock[0]

    def sleep(duration):
        sleeps.append(duration)
        clock[0] += round(duration * 1_000_000_000)

    monkeypatch.setattr(bench.time, "monotonic_ns", now)
    monkeypatch.setattr(bench.time, "sleep", sleep)
    return native_state, original, marker, guard, manifest, sleeps


@pytest.mark.parametrize("backend", bench.BACKENDS)
def test_both_public_apis_exact_phase_order_and_all_marker_bounds(environment, backend):
    native_state, original, marker, _guard, manifest, sleeps = environment
    receipt = bench.experiment(backend, ROOT + "/manifest.json")
    assert receipt["success"] and receipt["source_sha256"] == manifest["source_sha256"]
    assert receipt["variable_frequency"] is (backend == "native")
    assert len(receipt["phases"]) == 31 and receipt["sequence_setter_count"] == 32
    assert len(receipt["setter_events"]) == (33 if backend == "native" else 32)
    assert [
        (p["name"], p["duration_seconds"], p["frequency"], p["duty_u16"])
        for p in receipt["phases"]
    ] == list(bench.SEQUENCE)
    assert sleeps == [p[1] for p in bench.SEQUENCE] + [0.1]
    assert sum(p[1] for p in bench.SEQUENCE) == pytest.approx(2.059)
    previous_end = receipt["begin_ns"]
    for index, event in enumerate(receipt["setter_events"]):
        assert event["ordinal"] == index and event["status"] == "ok"
        clocks = [
            event[key]
            for key in (
                "begin_ns",
                "marker_high_begin_ns",
                "marker_high_end_ns",
                "caller_begin_ns",
                "caller_end_ns",
                "marker_low_begin_ns",
                "marker_low_end_ns",
                "end_ns",
            )
        ]
        assert (
            clocks == sorted(clocks)
            and previous_end <= clocks[0] <= clocks[-1] <= receipt["end_ns"]
        )
        previous_end = clocks[-1]
        assert event["primary_error"] is None and event["marker_low_error"] is None
    assert sum(row[0] == "high" for row in marker.log) == len(receipt["setter_events"])
    assert (
        not marker.claimed
        and marker.level == 0
        and not native_state.claimed
        and not original.claimed
    )
    assert (
        receipt["marker"]["initial_low_confirmed"]
        and receipt["marker"]["final_low_confirmed"]
        and receipt["marker"]["gpio23_released"]
    )
    assert receipt["marker"]["cleanup_final_readback"] == {
        "gpio_level": 0,
        "inactive": True,
    }
    assert receipt["gpio18_released"] and receipt["low_confirmed"]
    assert (
        receipt["primary_error"] is None
        and receipt["cleanup_errors"] == []
        and receipt["signals_received"] == []
    )


@pytest.mark.parametrize("backend", bench.BACKENDS)
def test_marker_is_high_during_actual_caller_setters(environment, backend):
    native_state, original, marker, *_rest = environment
    if backend == "native":
        native_state.hook = lambda name: (
            (_ for _ in ()).throw(AssertionError("not high"))
            if name == "configure" and marker.level != 1
            else None
        )
    else:
        count = [0]

        def hook(name, _args):
            if name == "tx":
                count[0] += 1
                if 2 <= count[0] <= 33:
                    assert marker.level == 1

        original.hook = hook
    assert bench.experiment(backend, ROOT + "/manifest.json")["success"]


@pytest.mark.parametrize("line", [18, 23])
def test_foreign_line_refused_without_marker_or_pwm_drives(environment, line):
    _native, original, marker, *_rest = environment
    if line == 18:
        original.foreign = True
    else:
        marker.foreign = True
    receipt = bench.experiment("native", ROOT + "/manifest.json")
    assert not receipt["success"] and "already claimed" in receipt["primary_error"]
    assert not any(row[0] in ("claim", "high", "low", "release") for row in marker.log)
    assert not any(row[0] in ("claim", "tx", "write", "free") for row in original.log)


@pytest.mark.parametrize("failure", ["high", "low"])
def test_marker_write_failure_retained_and_both_cleanup_paths_attempted(
    environment, failure
):
    native, _original, marker, *_rest = environment
    marker.fail = failure
    receipt = bench.experiment("native", ROOT + "/manifest.json")
    assert not receipt["success"] and "injected marker" in receipt["primary_error"]
    assert receipt["setter_events"] and receipt["setter_events"][0]["status"] == "error"
    assert any(row[0] == "low" for row in marker.log) and any(
        row[0] == "release" for row in marker.log
    )
    assert not marker.claimed and not native.claimed and receipt["gpio18_released"]
    if failure == "low":
        assert (
            receipt["setter_events"][0]["marker_low_error"]
            and receipt["cleanup_errors"]
        )


def test_caller_error_keeps_failed_pulse_and_original_primary_error(environment):
    native, _original, marker, *_rest = environment
    native.fail = "configure"
    receipt = bench.experiment("native", ROOT + "/manifest.json")
    event = receipt["setter_events"][0]
    assert not receipt["success"] and "injected configure" in receipt["primary_error"]
    assert (
        event["caller_begin_ns"] < event["caller_end_ns"]
        and event["marker_low_begin_ns"] < event["marker_low_end_ns"]
    )
    assert (
        event["primary_error"] == "OSError: injected configure"
        and event["status"] == "error"
    )
    assert (
        not marker.claimed
        and not native.claimed
        and receipt["gpio18_released"]
        and receipt["marker"]["gpio23_released"]
    )


@pytest.mark.parametrize("at", ["claim", "high"])
def test_signal_during_marker_claim_or_pulse_releases_only_private_lines(
    environment, at
):
    native, _original, marker, guard, *_rest = environment
    fired = False

    def hook(name):
        nonlocal fired
        if name == at and not fired:
            fired = True
            guard.handler(signal.SIGTERM, None)

    marker.hook = hook
    receipt = bench.experiment("native", ROOT + "/manifest.json")
    assert not receipt["success"] and "SafetyAbort" in receipt["primary_error"]
    assert receipt["signals_received"] == [signal.SIGTERM]
    assert (
        receipt["marker"]["gpio23_released"]
        and marker.level == 0
        and not marker.claimed
        and not native.claimed
    )
    if at == "high":
        assert (
            receipt["setter_events"][0]["status"] == "error"
            and receipt["gpio18_released"]
        )


def test_failed_pwm_constructor_still_releases_marker(environment):
    native, _original, marker, *_rest = environment
    native.fail = "construct"
    receipt = bench.experiment("native", ROOT + "/manifest.json")
    assert "injected construct" in receipt["primary_error"] and not receipt["success"]
    assert (
        receipt["marker"]["gpio23_released"]
        and receipt["marker"]["final_low_confirmed"]
        and not marker.claimed
    )
    assert any(e["operation"] == "PWMOut.deinit" for e in receipt["events"])


@pytest.mark.parametrize("failure", ["pwm_stop", "marker_release"])
def test_independent_cleanup_failures_are_receipted(environment, failure):
    native, _original, marker, *_rest = environment
    if failure == "pwm_stop":
        native.fail = "stop"
    else:
        marker.fail = "release"
    receipt = bench.experiment("native", ROOT + "/manifest.json")
    assert (
        not receipt["success"]
        and receipt["completed_normally"]
        and receipt["primary_error"] is None
    )
    assert (
        receipt["cleanup_errors"] and receipt["gpio18_released"] and not native.claimed
    )
    if failure == "pwm_stop":
        assert receipt["marker"]["gpio23_released"] and not marker.claimed
    else:
        assert not receipt["marker"]["gpio23_released"] and marker.claimed


@pytest.mark.parametrize("problem", ["hash", "pin", "flag"])
def test_source_or_flag_gate_precedes_any_line_claim(environment, monkeypatch, problem):
    _native, original, marker, _guard, manifest, _sleeps = environment
    if problem == "hash":
        monkeypatch.setattr(
            bench,
            "source_hashes",
            lambda: {**manifest["source_sha256"], "gpiod/_ext.so": "0" * 64},
        )
    elif problem == "pin":
        manifest["source_sha256"]["native_pwm_updates_eval.py"] = "0" * 64
    else:
        monkeypatch.setenv("BLINKA_PWM_SHORT_SLICE", "1")
    receipt = bench.experiment("native", ROOT + "/manifest.json")
    assert not receipt["success"] and receipt["primary_error"]
    assert marker.log == [] and original.log == []


def test_selected_source_keys_and_immutable_pins_are_exact():
    assert len(bench.SOURCE_KEYS) == 18
    for name, digest in bench.SOURCE_PINS.items():
        assert (
            hashlib.sha256(
                Path(bench.__file__).with_name(name).read_bytes()
            ).hexdigest()
            == digest
        )
