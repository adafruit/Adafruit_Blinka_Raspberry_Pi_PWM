"""Marker audit fakes: no hardware, SSH, worker or native implementation calls."""

import copy
import json
import struct
import zipfile

import analyze_gpio_pwm_marker as audit
import pytest
import test_gpio_pwm_marker_eval as helper_fakes

old_environment = helper_fakes.old_environment
native_environment = helper_fakes.native_environment
original_environment = helper_fakes.original_environment
environment = helper_fakes.environment


def channel(edges, end=4.0):
    waveform = {
        "begin_seconds": 0.0,
        "end_seconds": end,
        "initial_state": 0,
        "final_state": 0,
        "edge_count": len(edges),
    }
    return audit.channel_facts(waveform, edges)


def event(
    ordinal, duty, frequency=50, category="sequence", operation="PWMOut.duty_cycle"
):
    return {
        "ordinal": ordinal,
        "category": category,
        "scope": f"scope{ordinal}",
        "phase_index": ordinal if category == "sequence" else None,
        "operation": operation,
        "arguments": {"frequency": frequency, "duty_u16": duty},
        "caller_begin_ns": 1000,
        "caller_end_ns": 2000,
        "begin_ns": 900,
        "end_ns": 2100,
    }


def test_frozen_plan_and_complete_selected_source_contract():
    plan = audit.read_plan()
    assert len(plan["sequence"]) == 31
    assert plan["sequence_setter_count"] == 32
    assert len(plan["manifest"]["source_sha256"]) == 18
    assert plan["capture"]["marker_gpio"] == 23


def test_changed_plan_refused(tmp_path):
    path = tmp_path / "changed.json"
    path.write_text(json.dumps(audit.read_plan()))
    with pytest.raises(ValueError, match="Frozen marker plan"):
        audit.read_plan(path)


def test_every_high_low_and_period_retained_including_60ms_and_10ns_dip():
    edges = [0.5, 0.5015, 0.52, 0.58, 0.58000001, 0.64]
    facts = channel(edges)
    assert facts["waveform"]["transition_seconds"] == edges
    assert len(facts["all_high_runs"]) == 3
    assert (
        len(facts["all_interior_low_runs"])
        == len(facts["all_adjacent_rise_intervals"])
        == 2
    )
    assert len(facts["descriptive_high_runs_over_30ms"]) == 2
    assert len(facts["sub_microsecond_low_runs"]) == 1
    assert facts["long_high_width_does_not_prove_command_or_application"]


@pytest.mark.parametrize("remove", [True, False])
def test_marker_count_mismatch_fails_closed_even_for_tiny_extra_pulse(remove):
    pwm = channel([0.5, 0.5015])
    markers = channel(
        [0.6, 0.600001] if remove else [0.6, 0.600001, 0.60000101, 0.600002]
    )
    events = [event(0, 4915), event(1, 65535)] if remove else [event(0, 4915)]
    with pytest.raises(ValueError, match="count mismatch"):
        audit.marker_facts(pwm, markers, events)


def test_ordinals_not_pulse_width_guessing_establish_pairing():
    with pytest.raises(ValueError, match="ordinals"):
        audit.marker_facts(
            channel([0.5, 0.5015]), channel([0.6, 0.600001]), [event(1, 4915)]
        )


@pytest.mark.parametrize("edge,expected", [(0.81, [9990, 10000]), (0.800005, [-5, 5])])
def test_low_at_marker_sustained_high_signed_physical_interval(edge, expected):
    pwm = channel([0.7, 0.7015, edge, 0.87])
    markers = channel([0.6, 0.60001, 0.8, 0.80001])
    facts = audit.marker_facts(pwm, markers, [event(0, 4915), event(1, 65535)])
    observation = facts[1]["sustained_high_rise_observation"]
    assert observation is not None
    assert observation["signed_observed_interval_us"] == pytest.approx(expected)
    assert not facts[1]["application_instant_identified"]
    assert facts[1]["nearby_complete_pwm_high_runs"]
    assert facts[1]["nearby_pwm_adjacent_rise_intervals"]


@pytest.mark.parametrize("start", [0.799, 0.8])
def test_already_high_or_sample_tied_endpoint_is_ambiguous(start):
    facts = audit.marker_facts(
        channel([0.7, 0.7015, start, 0.87]),
        channel([0.6, 0.60001, 0.8, 0.80001]),
        [event(0, 4915), event(1, 65535)],
    )
    assert facts[1]["sustained_high_rise_observation"] is None
    assert "Ambiguous" in facts[1]["interpretation"]
    if start == 0.8:
        assert facts[1]["pwm_level_at_marker_start"] == {
            "immediately_before": 0,
            "immediately_after": 1,
            "pwm_edge_at_same_timestamp": True,
        }


def test_nonunique_sustained_runs_are_not_arbitrarily_selected():
    pwm = channel([0.7, 0.7015, 0.81, 0.85, 0.86, 0.9])
    facts = audit.marker_facts(
        pwm, channel([0.6, 0.60001, 0.8, 0.80001]), [event(0, 4915), event(1, 65535)]
    )
    assert facts[1]["sustained_high_candidate_pair_indices"] == [1, 2]
    assert facts[1]["sustained_high_rise_observation"] is None


def test_run_after_next_marker_is_not_associated_with_previous_endpoint():
    pwm = channel([0.7, 0.7015, 0.9, 0.96])
    facts = audit.marker_facts(
        pwm,
        channel([0.6, 0.60001, 0.8, 0.80001, 0.85, 0.85001]),
        [event(0, 4915), event(1, 65535), event(2, 4915)],
    )
    assert facts[1]["sustained_high_candidate_pair_indices"] == []
    assert facts[1]["sustained_high_rise_observation"] is None


def test_zero_while_low_and_recovery_fall_are_not_adoption_latency():
    events = [
        event(0, 4915),
        event(1, 65535),
        event(2, 4915),
        event(3, 0),
        event(4, 0, category="safety_cleanup", operation="PWMOut.duty_cycle_zero"),
    ]
    pwm = channel([0.7, 0.7015, 0.81, 0.900005])
    markers = channel(
        [0.6, 0.60001, 0.8, 0.80001, 0.9, 0.90001, 1.1, 1.10001, 1.2, 1.20001]
    )
    facts = audit.marker_facts(pwm, markers, events)
    assert facts[2]["first_subsequent_fall_observation"][
        "signed_observed_interval_us"
    ] == pytest.approx([-5, 5])
    assert "pulse-high duration" in facts[2]["interpretation"]
    assert facts[3]["pwm_level_at_marker_start"]["immediately_after"] == 0
    assert facts[3]["first_subsequent_fall_observation"] is None
    assert facts[4]["category"] == "safety_cleanup"
    assert facts[4]["sustained_high_rise_observation"] is None
    assert all(not fact["application_instant_identified"] for fact in facts)


def saved_capture(tmp_path, monkeypatch, environment, backend="native"):
    _native, _original, _marker, _guard, manifest, _sleeps = environment
    remote = audit.collector.helper.experiment(
        backend, helper_fakes.ROOT + "/manifest.json"
    )
    assert remote["success"]
    audit.collector.validate_remote(remote, backend, manifest)
    plan = copy.deepcopy(audit.read_plan())
    plan.update(manifest=manifest, remote_root=helper_fakes.ROOT)
    monkeypatch.setattr(audit, "read_plan", lambda _path=None: plan)
    directory = tmp_path / ("fake-" + backend + "-marker")
    directory.mkdir()
    acquisition = {
        "mode": audit.collector.MODE,
        "backend": audit.collector.BACKEND_NAMES[backend],
        "backend_selector": backend,
        "remote_root": helper_fakes.ROOT,
        "remote_returncode": 0,
        "primary_error": None,
        "evidence_errors": [],
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
    }
    metadata = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": audit.collector.MODE,
        "backend": audit.collector.BACKEND_NAMES[backend],
        "backend_selector": backend,
        "sequence_marker": audit.collector.SEQUENCE_MARKER,
        "sample_rate_hz": 100000000,
        "production_backend_unchanged": True,
        "collection_success": True,
        "remote_returncode": 0,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "waveform_accepted": None,
        "parity_pass": None,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "remote": remote,
        "outputs": [
            {
                "gpio": 18,
                "saleae_channel": 0,
                "backend": audit.collector.BACKEND_NAMES[backend],
            },
            {"gpio": 23, "saleae_channel": 1, "backend": "gpiod-marker"},
        ],
    }
    for name, value in (
        ("results.json", metadata),
        ("acquisition.json", acquisition),
        ("manifest.json", manifest),
        ("remote.stdout", remote),
    ):
        (directory / name).write_text(json.dumps(value) + "\n")
    settings = {
        "legacySettings": {
            "enabledChannels": [
                {"type": "Digital", "index": 0},
                {"type": "Digital", "index": 1},
            ],
            "sampleRate": {"digital": 100000000},
            "glitchFilter": {"enabled": False, "channels": []},
        },
        "legacyDevice": {"isSimulation": False, "deviceId": "81F8C2631DF5BF30"},
    }
    with zipfile.ZipFile(directory / "waveform.sal", "w") as archive:
        archive.writestr("meta.json", json.dumps({"data": settings}))
    edges = [0.75, 0.7515, 0.77, 0.7715, 0.85, 0.91]
    marker_edges = [
        x
        for i in range(len(remote["setter_events"]))
        for x in (0.6 + i * 0.07, 0.60001 + i * 0.07)
    ]
    for index, values in ((0, edges), (1, marker_edges)):
        (directory / f"digital_{index}.bin").write_bytes(
            b"<SALEAE>"
            + struct.pack("<iiIddQ", 0, 0, 0, 0, 4, len(values))
            + struct.pack("<" + str(len(values)) + "d", *values)
        )
    return directory, metadata, acquisition, remote, manifest


@pytest.mark.parametrize("backend", ["native", "lgpio"])
def test_valid_receipts_two_channels_and_cleanup_count(
    tmp_path, monkeypatch, environment, backend
):
    directory, _metadata, _acquisition, remote, _manifest = saved_capture(
        tmp_path, monkeypatch, environment, backend
    )
    report = audit.analyze(directory)
    assert report["strict_marker_ordinal_pairing_validated"]
    assert report["sequence_marker_count"] == 32
    assert report["cleanup_marker_count"] == (1 if backend == "native" else 0)
    assert len(report["marker_observations"]) == len(remote["setter_events"])
    assert not report["application_latency_measured"]
    assert not report["pi_saleae_clocks_aligned"]
    assert report["physical_channels_share_acquisition_timestamps"]
    assert report["waveform_accepted"] is report["parity_pass"] is None


@pytest.mark.parametrize(
    "scenario",
    [
        "manifest",
        "metadata",
        "acquisition",
        "remote",
        "raw_extra",
        "raw_order",
        "raw_bounds",
        "sal_filter",
    ],
)
def test_invalid_evidence_fails_without_output(
    tmp_path, monkeypatch, environment, scenario
):
    directory, metadata, acquisition, remote, manifest = saved_capture(
        tmp_path, monkeypatch, environment
    )
    if scenario == "manifest":
        manifest["source_sha256"]["gpiod/_ext.so"] = "b" * 64
        (directory / "manifest.json").write_text(json.dumps(manifest))
    elif scenario == "metadata":
        metadata["schema_version"] = True
        (directory / "results.json").write_text(json.dumps(metadata))
    elif scenario == "acquisition":
        acquisition["evidence_errors"] = ["failed export"]
        (directory / "acquisition.json").write_text(json.dumps(acquisition))
    elif scenario == "remote":
        remote["setter_events"][0]["ordinal"] = 1
        (directory / "remote.stdout").write_text(json.dumps(remote))
    elif scenario == "raw_extra":
        with (directory / "digital_1.bin").open("ab") as stream:
            stream.write(b"extra")
    elif scenario == "raw_order":
        blob = bytearray((directory / "digital_1.bin").read_bytes())
        struct.pack_into("<d", blob, 52, 0.5)
        (directory / "digital_1.bin").write_bytes(blob)
    elif scenario == "raw_bounds":
        blob = bytearray((directory / "digital_1.bin").read_bytes())
        struct.pack_into("<d", blob, 28, 4.1)
        (directory / "digital_1.bin").write_bytes(blob)
    else:
        with zipfile.ZipFile(directory / "waveform.sal", "r") as archive:
            data = json.loads(archive.read("meta.json"))
        data["data"]["legacySettings"]["glitchFilter"]["enabled"] = True
        with zipfile.ZipFile(directory / "waveform.sal", "w") as archive:
            archive.writestr("meta.json", json.dumps(data))
    with pytest.raises(ValueError):
        audit.analyze(directory)
    assert not (directory / "marker-analysis.json").exists()


def test_exclusive_output_refuses_existing_and_dangling(tmp_path):
    directory = tmp_path / "capture"
    directory.mkdir()
    path = directory / "marker-analysis.json"
    path.write_text("preserved")
    with pytest.raises(ValueError, match="Exclusive"):
        audit.main([str(directory)])
    assert path.read_text() == "preserved"
    dangling = directory / "dangling.json"
    dangling.symlink_to(directory / "missing")
    with pytest.raises(ValueError, match="Exclusive"):
        audit.main([str(directory), "--output-name", "dangling.json"])
