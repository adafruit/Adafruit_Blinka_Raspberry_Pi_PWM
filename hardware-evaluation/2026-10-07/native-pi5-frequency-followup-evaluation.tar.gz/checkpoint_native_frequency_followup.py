"""Recoverable follow-up archive, with exact bytes and offline report replay."""

import hashlib
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

import checkpoint_native_updates as previous

LAB = Path(__file__).resolve().parent
ARCHIVE = (
    previous.REPO
    / "hardware-evaluation/2026-10-07/native-pi5-frequency-followup-evaluation.tar.gz"
)
PLAN = json.loads((LAB / "oct7-native-frequency-loaded-followup-plan.json").read_text())
NEW_CAPTURES = PLAN["capture_order"]
TARGETS = (
    previous.TARGETS
    + NEW_CAPTURES
    + [
        name + suffix
        for name in NEW_CAPTURES
        for suffix in (
            ".load.stdout",
            ".load.stderr",
            ".capture.stdout",
            ".capture.stderr",
            ".updates-coordination.json",
        )
    ]
    + [
        "checkpoint_native_frequency_followup.py",
        "analyze_native_frequency_loaded_followup.py",
        "test_analyze_native_frequency_loaded_followup.py",
        "oct7-native-frequency-loaded-followup-plan.json",
        "oct7-native-frequency-loaded-followup-distributions.json",
        "record_native_frequency_followup_postflight.py",
        "oct7-native-frequency-followup-postflight.json",
        "oct7-native-frequency-followup-postflight.json.stdout",
        "oct7-native-frequency-followup-postflight.json.stderr",
        "oct7-native-frequency-followup-independent-audit.json",
        "oct7-native-frequency-followup-notes.txt",
    ]
)

REPLAY = (
    previous.REPLAY
    + r"""
import analyze_native_frequency_loaded_followup as followup
import checkpoint_native_frequency_followup as current
for name in current.NEW_CAPTURES:
    directory = root/name
    actual = analysis.analyze(directory) if "-native-" in name else original.analyze(directory)
    assert same(actual, directory/"analysis.json"), name
assert same(followup.analyze(root), root/"oct7-native-frequency-loaded-followup-distributions.json")
print(json.dumps({"new_capture_reports_reproduced":8,"distribution_report_reproduced":True}))
"""
)


def main():
    if len(TARGETS) != len(set(TARGETS)):
        raise ValueError("Duplicate checkpoint targets")
    regular = {}
    for name in TARGETS:
        path = LAB / name
        if not path.exists() or path.is_symlink():
            raise ValueError("Missing or linked target: " + name)
        for member in [path] if path.is_file() else sorted(path.rglob("*")):
            if member.is_symlink() or not (member.is_file() or member.is_dir()):
                raise ValueError("Unsupported target member: " + str(member))
            if member.is_file():
                regular[str(member.relative_to(LAB))] = hashlib.sha256(
                    member.read_bytes()
                ).hexdigest()
    with (
        ARCHIVE.open("xb") as stream,
        tarfile.open(fileobj=stream, mode="w:gz") as archive,
    ):
        for name in TARGETS:
            archive.add(LAB / name, arcname=name)
    extracted = Path(
        tempfile.mkdtemp(
            prefix="blinka-frequency-followup-checkpoint-", dir="/private/tmp"
        )
    )
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if (
                path.is_absolute()
                or ".." in path.parts
                or not (member.isfile() or member.isdir())
            ):
                raise ValueError("Unsafe archive member: " + member.name)
        archive.extractall(extracted, filter="data")
    recovered = {
        str(path.relative_to(extracted)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in extracted.rglob("*")
        if path.is_file()
    }
    if recovered != regular:
        raise ValueError("Recovered file set or bytes differ")
    result = subprocess.run(
        [sys.executable, "-c", REPLAY, str(extracted)],
        cwd=extracted,
        capture_output=True,
        text=True,
        check=True,
    )
    replay = [json.loads(line) for line in result.stdout.splitlines()]
    report = {
        "archive": str(ARCHIVE),
        "size_bytes": ARCHIVE.stat().st_size,
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "top_level_targets": len(TARGETS),
        "regular_files": len(regular),
        "safe_extraction": str(extracted),
        "all_file_bytes_match": True,
        "replay": replay,
        "replay_stderr": result.stderr,
    }
    with (LAB / "oct7-native-frequency-followup-checkpoint-verification.json").open(
        "x"
    ) as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
