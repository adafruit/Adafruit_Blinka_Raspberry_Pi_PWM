"""Read-only postflight for the fixed eight-capture frequency follow-up."""

import hashlib
import json
import shlex
import subprocess
from pathlib import Path

from record_native_updates_postflight import BOOT_ID, BOOT_SHA, REMOTE, REMOTE_PYTHON


def main():
    plan = json.loads(
        Path("oct7-native-frequency-loaded-followup-plan.json").read_text()
    )
    pids = set(
        json.loads(Path("oct7-native-updates-postflight.json").read_text())[
            "inspected_pids"
        ]
    )
    for name in plan["capture_order"]:
        pwm = json.loads((Path(name) / "remote.stdout").read_text())
        coordination = json.loads(Path(name + ".updates-coordination.json").read_text())
        if (
            pwm["success"] is not True
            or coordination["coordination_success"] is not True
        ):
            raise ValueError("Postflight requires completed captures")
        pids.add(pwm["helper_pid"])
        for line in Path(name + ".load.stdout").read_text().splitlines():
            load = json.loads(line)
            pids.add(load["launcher_pid"])
            pids.update(worker["pid"] for worker in load["owned_workers"])
    if not pids or not all(type(pid) is int and pid > 1 for pid in pids):
        raise ValueError("Invalid PID set")
    output = Path("oct7-native-frequency-followup-postflight.json")
    targets = [output, Path(str(output) + ".stdout"), Path(str(output) + ".stderr")]
    if any(path.exists() or path.is_symlink() for path in targets):
        raise ValueError("Require fresh postflight outputs")
    code = REMOTE.replace("PIDS", repr(json.dumps(sorted(pids))))
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([REMOTE_PYTHON, "-c", code]),
    ]
    with targets[1].open("xb") as stdout, targets[2].open("xb") as stderr:
        result = subprocess.run(
            command, stdout=stdout, stderr=stderr, timeout=20, check=False
        )
    remote = json.loads(targets[1].read_text()) if result.returncode == 0 else None
    accepted = (
        result.returncode == 0
        and remote["boot_id"] == BOOT_ID
        and remote["boot_config_sha256"] == BOOT_SHA
        and remote["gpiochip"]["label"] == "pinctrl-rp1"
        and not any(remote["pid_exists"].values())
        and all(
            line["used"] is False and not line["consumer"] for line in remote["lines"]
        )
        and remote["throttled"]["returncode"] == 0
        and remote["throttled"]["stdout"].strip() == "throttled=0x0"
        and remote["pwm"]["returncode"] == 0
        and "platform/1f0009c000.pwm" in remote["pwm"]["stdout"]
        and "cooling_fan" in remote["pwm"]["stdout"]
        and "1f00098000" not in remote["pwm"]["stdout"]
        and "pwm-gpio" not in remote["pwm"]["stdout"]
    )
    report = {
        "ssh_returncode": result.returncode,
        "accepted": bool(accepted),
        "inspected_pids": sorted(pids),
        "remote": remote,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Read-only postflight; no waveform/parity or analog guarantee",
    }
    with output.open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {"accepted": bool(accepted), "pids_inspected": len(pids), "remote": remote},
            indent=2,
        )
    )
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
