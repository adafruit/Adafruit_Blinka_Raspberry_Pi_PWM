"""Offline distribution/receipt fakes only; never capture or launch workers."""

import copy
import json
from pathlib import Path

import analyze_native_frequency_loaded_followup as audit
import pytest
import test_analyze_kernel_pwm_cpu_load as load_fakes
import test_analyze_native_pwm_updates as waveform_fakes


def test_frozen_plan_matches_existing_protocol_and_sources():
    plan = audit.read_plan()
    assert len(plan["capture_order"]) == len(set(plan["capture_order"])) == 8
    assert [pair["backend_order"] for pair in plan["matched_pairs"]] == [
        ["lgpio", "native"],
        ["native", "lgpio"],
        ["lgpio", "native"],
        ["native", "lgpio"],
    ]
    assert plan["loaded_pressure"]["worker_count"] == 2
    assert plan["loaded_pressure"]["duration_seconds"] == 10
    assert plan["prior_evidence"]["included_separately_not_pooled_with_followup"]
    assert plan["distribution_specification"]["descriptive_exceedance_cutoffs_us"] == [
        50,
        100,
        250,
    ]


def test_changed_plan_is_refused(tmp_path):
    path = tmp_path / "changed.json"
    path.write_text(json.dumps(audit.read_plan()))
    with pytest.raises(ValueError, match="Frozen follow-up plan changed"):
        audit.read_plan(path)


def test_empty_singleton_and_type7_quantiles_and_strict_cutoffs():
    empty = audit.distribution([])
    assert empty["count"] == 0 and empty["max_us"] is None
    assert empty["p50_us"] is empty["p95_us"] is empty["p99_us"] is None
    assert empty["exceedance_counts"] == {"50": 0, "100": 0, "250": 0}
    single = audit.distribution([330.018])
    assert (
        single["max_us"]
        == single["p50_us"]
        == single["p95_us"]
        == single["p99_us"]
        == 330.018
    )
    result = audit.distribution([330, 0, 250, 50, 100])
    assert result["p50_us"] == 100
    assert result["p95_us"] == pytest.approx(314)
    assert result["p99_us"] == pytest.approx(326.8)
    assert result["exceedance_counts"] == {"50": 3, "100": 2, "250": 1}
    assert result["exceedance_counts_are_descriptive_not_acceptance_gates"]


def test_cutoff_equality_noise_rule_does_not_change_stored_maximum():
    result = audit.distribution([50, 50 + 1e-9, 50.000001, 100, 250])
    assert result["exceedance_counts"] == {"50": 3, "100": 1, "250": 0}
    assert audit.distribution([50 + 1e-9])["max_us"] == 50 + 1e-9


@pytest.mark.parametrize("bad", [-1, float("nan"), float("inf")])
def test_nonfinite_or_negative_absolute_errors_rejected(bad):
    with pytest.raises(ValueError, match="finite and nonnegative"):
        audit.distribution([bad])


@pytest.mark.parametrize("backend", ["native", "original"])
def test_all_nearest_servo_anomalies_and_boundary_edges_count(backend):
    edges = waveform_fakes.protocol_edges("frequency", backend)
    target = audit.updates.target(50, 4915, backend)["high_us"]
    edges[39] = edges[38] + (target + 330.018) / 1e6
    report = waveform_fakes.report("frequency", edges, backend)
    distributions = audit.high_distributions([report])
    servo = distributions["servo50_d4915"]
    assert servo["count"] == 40
    assert servo["max_us"] == pytest.approx(330.018)
    assert servo["exceedance_counts"] == {"50": 1, "100": 1, "250": 1}
    assert report["physical"]["unmatched_high_runs"][0]["pair_index"] == 19
    assert report["waveform"]["transition_seconds"] == edges
    assert len(report["physical"]["all_adjacent_rise_intervals"]) == len(edges) // 2 - 1


def test_legitimate_intermediate_is_separate_but_not_erased():
    edges = waveform_fakes.protocol_edges("frequency")
    edges[41] = edges[40] + 149.996 / 1e6
    report = waveform_fakes.report("frequency", edges)
    result = audit.high_distributions([report])
    assert result["half500_d32768"]["count"] == 199
    assert len(report["physical"]["intermediate_width_high_runs"]) == 1
    assert len(report["physical"]["all_high_runs"]) == len(edges) // 2
    assert report["waveform"]["transition_seconds"] == edges


def receipt_files(tmp_path, backend="native"):
    plan = audit.read_plan()
    directory = tmp_path / ("fake-" + backend + "-frequency-loaded-r1")
    directory.mkdir()
    launch, completion, remote = load_fakes.documents()
    remote.update(mode="frequency", success=True, gpio18_released=True)
    (directory / "remote.stdout").write_text(json.dumps(remote) + "\n")
    directory.with_name(directory.name + ".load.stdout").write_text(
        json.dumps(launch) + "\n" + json.dumps(completion) + "\n"
    )
    directory.with_name(directory.name + ".load.stderr").write_text("")
    overlap = audit.loaded.overlap(
        directory.with_name(directory.name + ".load.stdout"), directory
    )
    command = [
        "python",
        "capture_native_pwm_updates.py"
        if backend == "native"
        else "capture_kernel_pwm_lgpio_baseline.py",
        directory.name,
        "--remote-root",
        "/tmp/fake",
        "--mode",
        "frequency",
    ]
    coordination = {
        "schema_version": 1,
        "stem": directory.name,
        "backend": backend,
        "mode": "frequency",
        "launch_validated": True,
        "launch_validation_errors": [],
        "coordination_success": True,
        "capture_error": None,
        "load_recorder_error": None,
        "capture_returncode": 0,
        "load_helper_returncode": 0,
        "load_recorder_exit_code": 0,
        "waveform_accepted": None,
        "parity_pass": None,
        "source_sha256": {
            name: plan["fixed_local_source_sha256"][name]
            for name in (
                "capture_pwm_updates_loaded.py",
                "record_kernel_pwm_cpu_load.py",
                "capture_kernel_pwm_loaded.py",
            )
        },
        "capture_begin_local_ns": 1,
        "capture_end_local_ns": 2,
        "capture_command": command,
        "launch_receipt": launch,
        "overlap": overlap,
    }
    path = directory.with_name(directory.name + ".updates-coordination.json")
    path.write_text(json.dumps(coordination) + "\n")
    return directory, plan, coordination, path, remote, launch, completion


def test_actual_workers_raw_receipts_and_stored_overlap_agree(tmp_path):
    directory, plan, _coordination, _path, _remote, _launch, _completion = (
        receipt_files(tmp_path)
    )
    coordination, overlap = audit.validate_coordination(directory, "native", plan)
    assert (
        coordination["capture_returncode"]
        == coordination["load_helper_returncode"]
        == 0
    )
    assert overlap["all_phases_bracketed_by_each_worker"]
    assert overlap["entire_helper_bracketed_by_each_worker"]
    assert len(overlap["workers"]) == 2
    assert all(worker["elapsed_ns"] >= 10_000_000_000 for worker in overlap["workers"])


@pytest.mark.parametrize(
    "key,bad",
    [
        ("capture_returncode", 1),
        ("load_helper_returncode", 1),
        ("load_recorder_exit_code", 1),
        ("capture_returncode", False),
        ("coordination_success", False),
        ("mode", "direct"),
        ("launch_validated", False),
        ("waveform_accepted", True),
        ("capture_error", "failure"),
        ("capture_begin_local_ns", True),
    ],
)
def test_failed_or_wrong_coordinator_evidence_rejected(tmp_path, key, bad):
    directory, plan, coordination, path, *_ = receipt_files(tmp_path)
    coordination[key] = bad
    path.write_text(json.dumps(coordination) + "\n")
    with pytest.raises(ValueError):
        audit.validate_coordination(directory, "native", plan)


@pytest.mark.parametrize(
    "scenario", ["source", "launch", "overlap", "stderr", "worker", "phase"]
)
def test_falsified_receipts_or_unbracketed_phase_rejected(tmp_path, scenario):
    directory, plan, coordination, path, remote, _launch, completion = receipt_files(
        tmp_path
    )
    if scenario == "source":
        coordination["source_sha256"]["capture_pwm_updates_loaded.py"] = "0" * 64
    elif scenario == "launch":
        coordination["launch_receipt"]["started_worker_count"] = 1
    elif scenario == "overlap":
        coordination["overlap"]["workers"][0]["phase_overlaps"][0]["overlap_ns"] = 0
    elif scenario == "stderr":
        directory.with_name(directory.name + ".load.stderr").write_text("error")
    elif scenario == "worker":
        completion["owned_workers"][0]["worker_receipts"][1]["iterations"] = 0
        load_fakes.sync_stdout(completion["owned_workers"][0])
        launch = load_fakes.documents()[0]
        directory.with_name(directory.name + ".load.stdout").write_text(
            json.dumps(launch) + "\n" + json.dumps(completion) + "\n"
        )
    else:
        remote["phases"][0]["begin_ns"] = 1_050_000_000
        (directory / "remote.stdout").write_text(json.dumps(remote) + "\n")
    path.write_text(json.dumps(coordination) + "\n")
    with pytest.raises(ValueError):
        audit.validate_coordination(directory, "native", plan)


@pytest.mark.parametrize("backend", ["native", "lgpio"])
def test_capture_composition_keeps_full_facts_and_per_backend_targets(
    tmp_path, monkeypatch, backend
):
    directory, plan, *_ = receipt_files(tmp_path, backend)
    report = waveform_fakes.report(
        "frequency",
        backend="native" if backend == "native" else "original",
        name=directory.name,
    )
    report.update(
        source_manifest=plan["native_source_manifest"],
        source_sha256={},
        saved_capture_settings={},
    )
    for name in ("results.json", "acquisition.json"):
        (directory / name).write_text(
            json.dumps(
                {
                    "pre_helper_lead_seconds": 0.5,
                    "post_helper_tail_seconds": 0.2,
                    "local_timing_not_aligned_to_pi_or_saleae": True,
                    "remote_root": "/tmp/fake",
                }
            )
        )
    monkeypatch.setattr(
        audit.updates,
        "analyze" if backend == "native" else "original_report",
        lambda _directory: copy.deepcopy(report),
    )
    result = audit.analyze_capture(directory, backend, plan)
    assert result["waveform"] == report["waveform"]
    assert result["physical"] == report["physical"]
    assert (
        result["absolute_high_target_error_distributions"]["servo50_d4915"]["count"]
        == 40
    )
    assert result["absolute_high_target_error_distributions"]["servo50_d4915"][
        "max_us"
    ] == pytest.approx(0, abs=1e-8)
    assert result["actual_worker_overlap"]["accepted"]


def test_prior_outlier_never_pooled_and_actual_order_required(tmp_path, monkeypatch):
    plan = audit.read_plan()
    order = {name: index for index, name in enumerate(plan["capture_order"])}

    def fake_capture(directory, backend, _plan):
        name = Path(directory).name
        report = waveform_fakes.report(
            "frequency",
            backend="native" if backend == "native" else "original",
            name=name,
        )
        if name == plan["prior_evidence"]["retained_known_native_anomaly"]["capture"]:
            report["physical"]["all_high_runs"][0]["target_error_us"] = 330.018
        index = order.get(name, 0)
        return {
            **report,
            "backend": backend,
            "capture_begin_local_ns": index * 100,
            "capture_end_local_ns": index * 100 + 99,
        }

    monkeypatch.setattr(audit, "analyze_capture", fake_capture)
    result = audit.analyze(tmp_path)
    new = result["followup"]["per_backend_absolute_high_target_error_distributions"][
        "native"
    ]["servo50_d4915"]
    prior = result["prior_evidence_separate_not_pooled"][
        "per_backend_absolute_high_target_error_distributions"
    ]["native"]["servo50_d4915"]
    assert new["count"] == 160 and new["max_us"] == pytest.approx(0, abs=1e-8)
    assert prior["count"] == 80 and prior["max_us"] == 330.018
    assert prior["exceedance_counts"]["250"] == 1
    assert not result["overall_backend_parity_established"]
    assert not result["tail_guarantee_or_nonrecurrence_established"]
    assert not result["electrical_command_latency_measured"]
    order[plan["capture_order"][0]] = 9
    with pytest.raises(ValueError, match="sequential order"):
        audit.analyze(tmp_path)


def test_exclusive_output_refuses_existing_or_dangling_symlink(tmp_path):
    output = tmp_path / "report.json"
    output.write_text("preserved")
    with pytest.raises(ValueError, match="Exclusive"):
        audit.main(["--root", str(tmp_path), "--output", str(output)])
    assert output.read_text() == "preserved"
    dangling = tmp_path / "dangling.json"
    dangling.symlink_to(tmp_path / "absent.json")
    with pytest.raises(ValueError, match="Exclusive"):
        audit.main(["--root", str(tmp_path), "--output", str(dangling)])
