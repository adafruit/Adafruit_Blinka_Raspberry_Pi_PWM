"""Offline finite frequency-tail observations; no capture, GPIO or SSH actions.

Reuses unchanged raw/receipt validators and waveform-only regime assignments.
Prior observations are never pooled with follow-up distributions. Every raw
edge, full high, low, adjacent rise interval and boundary remains in the report.
"""

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

import analyze_native_pwm_updates as updates
import capture_pwm_updates_loaded as loaded
from capture_native_pwm_updates import read_json

PLAN_NAME = "oct7-native-frequency-loaded-followup-plan.json"
PLAN_SHA256 = "6798dc13b9214aff0217f715b56f457c895f5cd20202df75c6bc30f127fc6758"
BACKENDS = {"native": updates.BACKEND, "lgpio": "original-blinka-lgpio"}
REGIMES = ("servo50_d4915", "half500_d32768")
CUTOFFS_US = (50, 100, 250)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_plan(path=None):
    path = Path(path) if path is not None else Path(__file__).with_name(PLAN_NAME)
    raw = path.read_bytes()
    require(
        hashlib.sha256(raw).hexdigest() == PLAN_SHA256, "Frozen follow-up plan changed"
    )
    plan = read_json(raw.decode())
    require(
        plan["retained_provisional_frequency_checks"]
        == updates.read_plan()["provisional_checks"]["frequency"],
        "Retained idle-reference checks changed",
    )
    for name, expected in plan["fixed_local_source_sha256"].items():
        source = Path(__file__).parent / name
        require(
            hashlib.sha256(source.read_bytes()).hexdigest() == expected,
            "Frozen local source changed: " + name,
        )
    return plan


def distribution(absolute_errors_us):
    """Type-7 percentiles, with a fixed picosecond-scale cutoff rounding rule."""
    values = sorted(absolute_errors_us)
    require(
        all(math.isfinite(value) and value >= 0 for value in values),
        "Absolute errors must be finite and nonnegative",
    )

    def percentile(probability):
        if not values:
            return None
        rank = (len(values) - 1) * probability
        low = math.floor(rank)
        high = math.ceil(rank)
        return values[low] + (values[high] - values[low]) * (rank - low)

    return {
        "count": len(values),
        "max_us": max(values, default=None),
        "p50_us": percentile(0.50),
        "p95_us": percentile(0.95),
        "p99_us": percentile(0.99),
        "exceedance_counts": {
            str(cutoff): sum(round(value, 6) > cutoff for value in values)
            for cutoff in CUTOFFS_US
        },
        "cutoffs_us": list(CUTOFFS_US),
        "exceedance_counts_are_descriptive_not_acceptance_gates": True,
    }


def high_distributions(reports):
    """All nearest-stable anomalies count; separately classified intermediates remain."""
    return {
        regime: distribution(
            [
                abs(high["target_error_us"])
                for report in reports
                for high in report["physical"]["all_high_runs"]
                if high["diagnostic_regime"] == regime
            ]
        )
        for regime in REGIMES
    }


def validate_coordination(directory, backend, plan):
    directory = Path(directory)
    coordination = read_json(
        directory.with_name(directory.name + ".updates-coordination.json").read_text()
    )
    require(
        type(coordination.get("schema_version")) is int
        and coordination["schema_version"] == 1
        and coordination.get("stem") == directory.name
        and coordination.get("backend") == backend
        and coordination.get("mode") == "frequency",
        "Coordination capture identity mismatch",
    )
    require(
        coordination.get("launch_validated") is True
        and coordination.get("launch_validation_errors") == []
        and coordination.get("coordination_success") is True
        and "capture_error" in coordination
        and coordination["capture_error"] is None
        and "load_recorder_error" in coordination
        and coordination["load_recorder_error"] is None
        and all(
            type(coordination.get(key)) is int and coordination[key] == 0
            for key in (
                "capture_returncode",
                "load_helper_returncode",
                "load_recorder_exit_code",
            )
        )
        and "waveform_accepted" in coordination
        and coordination["waveform_accepted"] is None
        and "parity_pass" in coordination
        and coordination["parity_pass"] is None,
        "Actual collector/load/recorder success required without waveform verdict",
    )
    require(
        coordination.get("source_sha256")
        == {
            name: plan["fixed_local_source_sha256"][name]
            for name in (
                "capture_pwm_updates_loaded.py",
                "record_kernel_pwm_cpu_load.py",
                "capture_kernel_pwm_loaded.py",
            )
        },
        "Coordination frozen source mismatch",
    )
    begin = coordination.get("capture_begin_local_ns")
    end = coordination.get("capture_end_local_ns")
    require(
        type(begin) is int and type(end) is int and 0 <= begin < end,
        "Invalid local collection interval",
    )
    command = coordination.get("capture_command")
    collector = (
        "capture_native_pwm_updates.py"
        if backend == "native"
        else "capture_kernel_pwm_lgpio_baseline.py"
    )
    require(
        isinstance(command, list)
        and len(command) >= 7
        and all(isinstance(item, str) for item in command)
        and Path(command[1]).name == collector
        and command[2] == directory.name
        and command[-2:] == ["--mode", "frequency"],
        "Coordination fixed capture command mismatch",
    )
    load_path = directory.with_name(directory.name + ".load.stdout")
    launch, _completion = loaded.load_audit.parse_lines(
        load_path.read_text(), 2, "load stdout"
    )
    require(
        coordination.get("launch_receipt") == launch,
        "Persisted launch receipt mismatch",
    )
    require(
        directory.with_name(directory.name + ".load.stderr").read_text() == "",
        "Load recorder stderr is not empty",
    )
    overlap = loaded.overlap(load_path, directory)
    require(overlap["accepted"], "Actual workers did not bracket every phase")
    require(
        coordination.get("overlap") == overlap,
        "Stored/recomputed worker overlap mismatch",
    )
    return coordination, overlap


def analyze_capture(directory, backend, plan):
    require(backend in BACKENDS, "Unsupported backend")
    directory = Path(directory)
    report = (
        updates.analyze(directory)
        if backend == "native"
        else updates.original_report(directory)
    )
    require(
        report["capture"] == directory.name
        and report["mode"] == "frequency"
        and report["backend"] == BACKENDS[backend],
        "Expected fixed frequency backend capture",
    )
    if backend == "native":
        require(
            report["source_manifest"] == plan["native_source_manifest"],
            "Native capture source manifest differs from pre-capture plan",
        )
    metadata = read_json((directory / "results.json").read_text())
    acquisition = read_json((directory / "acquisition.json").read_text())
    require(
        all(
            item.get("pre_helper_lead_seconds") == 0.5
            and item.get("post_helper_tail_seconds") == 0.2
            for item in (metadata, acquisition)
        )
        and acquisition.get("local_timing_not_aligned_to_pi_or_saleae") is True,
        "Lead/tail or clock provenance mismatch",
    )
    coordination, overlap = validate_coordination(directory, backend, plan)
    command = coordination["capture_command"]
    require(
        command.count("--remote-root") == 1
        and command[command.index("--remote-root") + 1] == acquisition["remote_root"],
        "Captured remote root differs from coordination command",
    )
    return {
        "capture": report["capture"],
        "backend": backend,
        "mode": "frequency",
        "waveform": report["waveform"],
        "physical": report["physical"],
        "absolute_high_target_error_distributions": high_distributions([report]),
        "idle_reference_flags_not_loaded_verdict": updates.provisional_checks(report),
        "caller_updates": report["caller_updates"],
        "phase_api_update_durations_us": report["phase_api_update_durations_us"],
        "source_sha256": report["source_sha256"],
        "saved_capture_settings": report["saved_capture_settings"],
        "actual_worker_overlap": overlap,
        "capture_begin_local_ns": coordination["capture_begin_local_ns"],
        "capture_end_local_ns": coordination["capture_end_local_ns"],
        "collection_coordination_success": True,
    }


def evidence_group(root, pairs, plan, check_order=False):
    captures = []
    for pair in pairs:
        for backend in pair.get("backend_order", ["lgpio", "native"]):
            captures.append(analyze_capture(Path(root) / pair[backend], backend, plan))
    if check_order:
        require(
            [item["capture"] for item in captures] == plan["capture_order"],
            "Follow-up captures do not follow frozen order",
        )
        require(
            all(
                a["capture_end_local_ns"] <= b["capture_begin_local_ns"]
                for a, b in itertools.pairwise(captures)
            ),
            "Actual local capture intervals contradict predeclared sequential order",
        )
    return {
        "matched_pairs": pairs,
        "captures": captures,
        "per_backend_absolute_high_target_error_distributions": {
            backend: high_distributions(
                [item for item in captures if item["backend"] == backend]
            )
            for backend in BACKENDS
        },
    }


def analyze(root=None, plan_path=None):
    root = Path(__file__).parent if root is None else Path(root)
    plan = read_plan(plan_path)
    return {
        "schema_version": 1,
        "analysis_kind": "finite_loaded_frequency_recurrence_observation",
        "followup_plan_sha256": PLAN_SHA256,
        "distribution_specification": plan["distribution_specification"],
        "followup": evidence_group(root, plan["matched_pairs"], plan, check_order=True),
        "prior_evidence_separate_not_pooled": evidence_group(
            root, plan["prior_evidence"]["matched_pairs"], plan
        ),
        "prior_known_native_anomaly": plan["prior_evidence"][
            "retained_known_native_anomaly"
        ],
        "overall_backend_parity_established": False,
        "tail_guarantee_or_nonrecurrence_established": False,
        "electrical_command_latency_measured": False,
        "pi_saleae_clocks_aligned": False,
        "limitation": plan["interpretation"],
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).parent)
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    plan = read_plan(args.plan)
    output = args.output or args.root / plan["analysis_output"]
    require(
        not output.exists() and not output.is_symlink(),
        "Exclusive output already exists",
    )
    report = analyze(args.root, args.plan)
    with output.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "output": str(output),
                "followup_plan_sha256": PLAN_SHA256,
                "followup_distributions": report["followup"][
                    "per_backend_absolute_high_target_error_distributions"
                ],
                "prior_distributions_separate": report[
                    "prior_evidence_separate_not_pooled"
                ]["per_backend_absolute_high_target_error_distributions"],
                "overall_backend_parity_established": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
