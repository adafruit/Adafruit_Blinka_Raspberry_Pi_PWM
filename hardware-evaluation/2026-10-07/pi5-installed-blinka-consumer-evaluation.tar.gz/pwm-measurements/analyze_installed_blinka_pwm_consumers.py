"""Offline, finite installed-Blinka consumer integration evidence only.

The installed collector validates actual board/pwmio dispatch and its separate
import-only lgpio handle. The frozen native consumer waveform functions are
reused unchanged: every edge, complete high/low/rise interval, anomaly, short
fragment and boundary-inclusive sibling ambiguity remains in the report.
Nothing here establishes parity, actuator safety or general compatibility.
"""

import argparse
import hashlib
import importlib
import json
import shlex
from pathlib import Path

import analyze_native_pwm_consumers as waveform

raw = waveform.raw
require = raw.require
PLAN_NAME = "oct7-installed-blinka-consumers-plan.json"
# The parent freezes the pre-capture plan after this method is reviewed.
# Unset is deliberately not a permissive development mode.
PLAN_SHA256 = "04869dae6b202202fc2c2b6bfdaa1dbaa7bcaf5a2f8a946ee65d81073a1c6161"
REUSED_CONSUMER_ANALYZER_SHA256 = (
    "ec302be4cc56d5cbce8af46e9380121a38017cce4e37aca76e673184fd0bef2b"
)
REUSED_RAW_FACTS_SHA256 = (
    "61f5f31343c09e06ec213d4c19f64d35605d0eda2140057d0b08cb539d17a350"
)
CAPTURE_NAMES = (
    "oct7-pi5-installed-blinka-consumers-r1",
    "oct7-pi5-installed-blinka-consumers-r2",
)
EVIDENCE_NAMES = (
    "plan.json",
    "manifest.json",
    "remote.stdout",
    "remote.stderr",
    "results.json",
    "acquisition.json",
    "waveform.sal",
    "digital_0.bin",
    "digital_1.bin",
)

# These functions only operate on fresh per-capture facts. No reused module
# constant, global, source file or legacy receipt is modified or converted.
retarget_channel = waveform.retarget_channel
functional_facts = waveform.functional_facts
NOMINALS = waveform.NOMINALS


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _collector():
    # Importing the collector does not connect to Saleae or run the helper.
    return importlib.import_module("capture_installed_blinka_pwm_consumers")


def read_plan(path=None):
    path = Path(path) if path is not None else Path(__file__).with_name(PLAN_NAME)
    require(
        isinstance(PLAN_SHA256, str)
        and len(PLAN_SHA256) == 64
        and all(char in "0123456789abcdef" for char in PLAN_SHA256),
        "Installed consumer plan SHA256 is not frozen",
    )
    require(path.is_file() and not path.is_symlink(), "Regular frozen plan required")
    data = path.read_bytes()
    require(
        hashlib.sha256(data).hexdigest() == PLAN_SHA256,
        "Frozen installed consumer plan changed",
    )
    plan = _collector().read_json(data.decode())
    require(isinstance(plan, dict), "Installed consumer plan must be an object")
    rules = plan.get("pre_capture_waveform_identification")
    require(
        isinstance(rules, dict)
        and type(rules.get("ordinary_width_period_relative_band")) in (int, float)
        and rules["ordinary_width_period_relative_band"] == waveform.BAND
        and type(rules.get("minimum_identifiable_train_pulses")) is int
        and rules["minimum_identifiable_train_pulses"] == waveform.MIN_PULSES
        and type(rules.get("sustained_high_threshold_seconds")) in (int, float)
        and rules["sustained_high_threshold_seconds"] * 1e6 == waveform.LONG_HIGH_US
        and type(rules.get("minimum_joint_brake_overlap_seconds")) in (int, float)
        and rules["minimum_joint_brake_overlap_seconds"]
        == waveform.MIN_BRAKE_OVERLAP_SECONDS
        and plan.get("capture_order") == list(CAPTURE_NAMES)
        and plan.get("runtime_flags") == {"short_slice": False, "shared": False},
        "Frozen installed identification/capture contract changed",
    )
    require(
        digest(waveform.__file__) == REUSED_CONSUMER_ANALYZER_SHA256
        and digest(raw.__file__) == REUSED_RAW_FACTS_SHA256,
        "Frozen reused waveform reconstruction changed",
    )
    return plan


def read_channel(path):
    return retarget_channel(raw.read_channel(path))


def complete_extent_descriptive_statistics(channel, functional, gpio_name):
    """All extents, not a central window or an acceptance band summary."""
    highs = channel["all_high_runs"]
    lows = channel["all_low_runs"]
    fragments = functional["all_width_period_train_fragments_including_short"][
        gpio_name
    ]
    return {
        "all_high_widths_including_long_and_anomalous_us": raw.stats(
            [row["width_us"] for row in highs]
        ),
        "all_low_widths_including_initial_and_final_us": raw.stats(
            [row["width_us"] for row in lows]
        ),
        "all_interior_low_widths_us": raw.stats(
            [row["width_us"] for row in lows if row["kind"] == "interior"]
        ),
        "all_adjacent_rise_intervals_including_gaps_us": raw.stats(
            [row["rise_to_rise_us"] for row in channel["all_adjacent_rise_intervals"]]
        ),
        "every_width_period_fragment_including_short": {
            tag: [
                {
                    "pair_indices": block["pair_indices"],
                    "begin_seconds": block["begin_seconds"],
                    "end_seconds": block["end_seconds"],
                    "eligible_train": block["eligible_train"],
                    "high_error_from_u16_c_target_us": raw.stats(
                        [
                            highs[index]["width_us"] - NOMINALS[tag]["high_us"]
                            for index in block["pair_indices"]
                        ]
                    ),
                    "within_fragment_adjacent_rise_error_us": raw.stats(
                        [
                            (highs[right]["rise_seconds"] - highs[left]["rise_seconds"])
                            * 1e6
                            - NOMINALS[tag]["period_us"]
                            for left, right in zip(
                                block["pair_indices"], block["pair_indices"][1:]
                            )
                        ]
                    ),
                }
                for block in blocks
            ]
            for tag, blocks in fragments.items()
        },
        "all_raw_arrays_retained_in_channel_facts": True,
        "identification_band_is_not_acceptance": True,
    }


def analyze(directory, plan_path=None):
    directory = Path(directory)
    require(
        directory.is_dir()
        and not directory.is_symlink()
        and directory.name in CAPTURE_NAMES,
        "Exclusive new installed consumer capture directory required",
    )
    plan = read_plan(plan_path)
    for name in EVIDENCE_NAMES:
        path = directory / name
        require(
            path.is_file() and not path.is_symlink(),
            "Regular evidence required: " + name,
        )
    plan_file = (
        Path(plan_path)
        if plan_path is not None
        else Path(__file__).with_name(PLAN_NAME)
    )
    require(
        (directory / "plan.json").read_bytes() == plan_file.read_bytes(),
        "Retained capture plan differs from frozen pre-capture plan",
    )
    collector = _collector()

    def read(name):
        return collector.read_json((directory / name).read_text())

    manifest, remote, metadata, acquisition = (
        read(name)
        for name in (
            "manifest.json",
            "remote.stdout",
            "results.json",
            "acquisition.json",
        )
    )
    collector.validate_plan(plan, manifest)
    collector.validate_local_manifest(manifest)
    collector.validate_remote(remote, manifest)
    require(
        digest(directory / "manifest.json") == plan["manifest_sha256"],
        "Retained installed manifest bytes changed",
    )
    outputs = [
        {"gpio": gpio, "saleae_channel": index, "backend": collector.BACKEND}
        for gpio, index in ((18, 0), (23, 1))
    ]
    require(
        type(metadata.get("schema_version")) is int
        and metadata["schema_version"] == 1
        and metadata.get("host") == "test-pi5.local"
        and metadata.get("mode") == collector.MODE
        and metadata.get("backend") == collector.BACKEND
        and metadata.get("sequence_marker") == collector.SEQUENCE_MARKER
        and type(metadata.get("sample_rate_hz")) is int
        and metadata["sample_rate_hz"] == 100_000_000
        and metadata.get("remote") == remote
        and metadata.get("source_manifest") == manifest
        and metadata.get("source_plan") == plan
        and metadata.get("outputs") == outputs
        and metadata.get("glitch_filters") == []
        and metadata.get("collection_success") is True
        and metadata.get("installed_blinka_dispatch_exercised") is True
        and metadata.get("production_backend_unchanged") is True
        and metadata.get("analysis_deferred") is True
        and metadata.get("parity_evaluated") is False
        and metadata.get("actual_actuators_attached") is False
        and metadata.get("whole_blinka_compatibility_proven") is False
        and "waveform_accepted" in metadata
        and metadata["waveform_accepted"] is None
        and "parity_pass" in metadata
        and metadata["parity_pass"] is None,
        "Successful finite installed integration collection required without verdict",
    )
    expected_program = plan["remote_root"] + "/installed_blinka_pwm_consumers_eval.py"
    expected_manifest = (
        plan["remote_root"] + "/oct7-installed-blinka-consumers-manifest.json"
    )
    expected_command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        " ".join(
            shlex.quote(part)
            for part in (
                plan["remote_python"],
                "-I",
                expected_program,
                "--manifest",
                expected_manifest,
            )
        ),
    ]
    require(
        acquisition.get("mode") == collector.MODE
        and acquisition.get("backend") == collector.BACKEND
        and acquisition.get("primary_error", "missing") is None
        and acquisition.get("evidence_errors") == []
        and acquisition.get("ssh_exit_unavailable_after_exception") is False
        and acquisition.get("requested_channels") == [0, 1]
        and type(acquisition.get("requested_sample_rate_hz")) is int
        and acquisition["requested_sample_rate_hz"] == 100_000_000
        and acquisition.get("requested_glitch_filters") == []
        and acquisition.get("local_timing_not_aligned_to_pi_or_saleae") is True
        and remote.get("manifest_path") == expected_manifest
        and remote.get("python_executable") == plan["remote_python"]
        and all(
            row.get("remote_root") == plan["remote_root"]
            and row.get("remote_python") == plan["remote_python"]
            and type(row.get("remote_returncode")) is int
            and row["remote_returncode"] == 0
            and row.get("pre_helper_lead_seconds") == 0.5
            and row.get("post_helper_tail_seconds") == 0.2
            and row.get("plan_sha256") == PLAN_SHA256
            and row.get("manifest_sha256") == plan["manifest_sha256"]
            and row.get("preflight_receipt_sha256") == plan["preflight_receipt_sha256"]
            and row.get("remote_program") == expected_program
            and row.get("remote_manifest") == expected_manifest
            for row in (metadata, acquisition)
        )
        and metadata.get("helper_sha256") == plan["helper_sha256"]
        and metadata.get("collector_sha256") == plan["collector_sha256"]
        and "receipt_validation_error" not in metadata
        and acquisition.get("remote_command") == expected_command,
        "Installed acquisition/root/command/typed SSH exit/evidence contract failed",
    )
    settings = raw.validate_sal(directory / "waveform.sal")
    channels = [read_channel(directory / f"digital_{index}.bin") for index in (0, 1)]
    bounds = [
        (row["waveform"]["begin_seconds"], row["waveform"]["end_seconds"])
        for row in channels
    ]
    require(
        bounds[0] == bounds[1], "Both installed channels must share acquisition bounds"
    )
    require(
        bounds[0][1] - bounds[0][0] >= sum(row[1] for row in collector.helper.SEQUENCE),
        "Insufficient full installed consumer capture coverage",
    )
    functional = functional_facts(*channels)
    return {
        "schema_version": 1,
        "capture": directory.name,
        "mode": collector.MODE,
        "backend": collector.BACKEND,
        "plan_sha256": PLAN_SHA256,
        "source_plan": plan,
        "source_manifest": manifest,
        "approved_preflight_receipt_hash_retained_not_revalidated_here": plan[
            "preflight_receipt_sha256"
        ],
        "offline_analyzer_sha256": digest(__file__),
        "reused_consumer_waveform_module_sha256": digest(waveform.__file__),
        "reused_raw_facts_module_sha256": digest(raw.__file__),
        "reused_waveform_globals_overridden": False,
        "old_shim_receipts_converted": False,
        "saved_capture_settings": settings,
        "collection_receipts_validated": True,
        "evidence_sha256": {name: digest(directory / name) for name in EVIDENCE_NAMES},
        "preserved_stderr": {
            "byte_count": (directory / "remote.stderr").stat().st_size,
            "interpretation": "Preserved verbatim evidence; this analyzer does not attribute local/remote diagnostics from the filename.",
        },
        "actual_recorded_exit_statuses": {
            "consumer_ssh_returncode_from_results": metadata["remote_returncode"],
            "consumer_ssh_returncode_from_acquisition": acquisition[
                "remote_returncode"
            ],
            "local_collector_cli_exit_not_inferred": True,
        },
        "validated_installed_dispatch_and_provenance_not_electrical_phase_identity": {
            key: remote[key]
            for key in (
                "installed_dispatch",
                "source_sha256",
                "source_paths",
                "distribution_versions",
                "python_executable",
                "isolated_python",
                "inherited_environment",
                "noninteractive_no_runtime_installs",
            )
        },
        "validated_separate_import_only_lgpio_handle_not_pwm_ownership": remote[
            "blinka_import_chip"
        ],
        "validated_environment_and_preclaim_receipt_not_whole_system_attestation": {
            key: remote[key]
            for key in (
                "identity",
                "helper_pid",
                "begin_ns",
                "end_ns",
                "before",
                "after",
                "preclaim_lines",
                "read_only_chip_closed",
                "runtime_flags",
                "selected_source_hashes_are_not_whole_system_attestation",
            )
        },
        "validated_receipt_consumer_api_and_ownership_not_electrical_phase_identity": {
            key: remote[key]
            for key in ("consumers", "outputs", "shutdowns", "phases", "actions")
        },
        "caller_events_pi_clock": [
            {
                **event,
                "caller_duration_us": (event["end_ns"] - event["begin_ns"]) / 1000,
            }
            for event in remote["events"]
        ],
        "gpio18_channel0": channels[0],
        "gpio23_channel1": channels[1],
        "functional_waveform_facts": functional,
        "complete_extent_descriptive_statistics": {
            name: complete_extent_descriptive_statistics(channel, functional, gpio)
            for name, channel, gpio in (
                ("gpio18_channel0", channels[0], "gpio18"),
                ("gpio23_channel1", channels[1], "gpio23"),
            )
        },
        "actual_consumer_u16_c_rounded_nominals": {
            tag: dict(values) for tag, values in NOMINALS.items()
        },
        "common_requested_servo_high_us_minus_actual_c_rounded_us": {
            tag: requested - NOMINALS[tag]["high_us"]
            for tag, requested in (
                ("servo_angle0", 1000),
                ("servo_angle90", 1500),
                ("servo_angle180", 2000),
            )
        },
        "functional_consumer_integration_only": True,
        "installed_board_pwmio_dispatch_receipt_validated": True,
        "passive_probes_only": True,
        "actual_actuator_operation_established": False,
        "whole_blinka_compatibility_proven": False,
        "general_hardware_or_api_compatibility_proven": False,
        "actuator_safety_established": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "matched_performance_parity": False,
        "pi_saleae_clocks_aligned": False,
        "application_latency_measured": False,
        "physical_channels_share_acquisition_timestamps": True,
        "no_edge_trimming_or_glitch_filtering": True,
        "timebase_gpio_driver_and_threshold_skew_calibrated": False,
        "limitation": "Finite passive integration through selected installed sources from a test-only patched Blinka distribution, actual board/pwmio dispatch and genuine motor3.5.0 classes. Dispatch/import-handle/ownership are receipt facts, not electrical edge labels or whole-wheel/system attestation. The import-stage guard rejects lgpio line mutation; its separately owned handle closure is distinct from the PWM private requests. The approved preflight receipt fingerprint is retained, not its body revalidated here. No Pi/Saleae clock alignment, exact adoption/deinit latency, actuator operation/safety, matched performance parity or general Blinka compatibility is established. The 10% identification band only identifies unique ordered topology; every raw edge, anomalous width, short fragment and full-run sibling boundary ambiguity is retained. Silent states cannot identify exact disable/deinit/release calls.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", type=Path, nargs="+")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output-name", default="installed-consumer-analysis.json")
    args = parser.parse_args(argv)
    require(
        Path(args.output_name).name == args.output_name
        and args.output_name not in ("", ".", ".."),
        "Output must be a filename",
    )
    outputs = [directory / args.output_name for directory in args.directories]
    require(
        len({path.resolve() for path in outputs}) == len(outputs)
        and all(not path.exists() and not path.is_symlink() for path in outputs),
        "Exclusive fresh installed report outputs required",
    )
    reports = [analyze(directory, args.plan) for directory in args.directories]
    for path, report in zip(outputs, reports):
        with path.open("x") as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
