"""Hardware-free installed analyzer tests: synthetic SAL/raw, recording GPIO.

Installed board/pwmio and genuine motor Python objects use the existing
recording-only helper fixture. Strict physical source/ABI validation is tested
by the separate installed collector tests; only those source validators are
substituted here for fixture-only source bytes. No SSH, network, Saleae API,
GPIO, real native extension or actual capture report is used or generated.
"""

import copy
import hashlib
import json
import struct
import zipfile

import analyze_installed_blinka_pwm_consumers as audit
import capture_installed_blinka_pwm_consumers as collector
import installed_blinka_pwm_consumers_eval as helper
import pytest
import test_capture_installed_blinka_pwm_consumers as collector_fakes
import test_installed_blinka_pwm_consumers_eval as installed_fakes

old_environment = installed_fakes.old_environment
dual_environment = installed_fakes.dual_environment
native_environment = installed_fakes.native_environment
environment = installed_fakes.environment
strict_receipt = collector_fakes.receipt


def binary(edges, version=0, begin=0.0, end=5.3, initial=0, rate=100_000_000):
    data = b"<SALEAE>" + struct.pack("<ii", version, 0)
    if version:
        data += struct.pack("<Q", 1)
    data += struct.pack("<I", initial)
    if version:
        data += struct.pack("<d", rate)
    return (
        data
        + struct.pack("<ddQ", begin, end, len(edges))
        + struct.pack(f"<{len(edges)}d", *edges)
    )


def train(start, stop, tag):
    nominal = audit.NOMINALS[tag]
    period, high = nominal["period_us"] / 1e6, nominal["high_us"] / 1e6
    edges, index = [], 0
    while start + index * period + high < stop:
        rise = start + index * period
        edges.extend((rise, rise + high))
        index += 1
    return edges


def visible_protocol():
    return (
        train(0.8, 1.2, "servo_angle0")
        + train(1.22, 1.62, "servo_angle90")
        + train(1.64, 2.04, "servo_angle180")
        + [2.55, 2.7505]
        + train(2.752, 3.10, "motor_half")
        + [3.102, 3.302],
        [2.55002, 2.75001] + train(3.304, 3.652, "motor_half") + [3.654, 3.854],
    )


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def plan_value():
    return {
        "schema_version": 1,
        "mode": collector.MODE,
        "backend": collector.BACKEND,
        "sequence_marker": collector.SEQUENCE_MARKER,
        "capture_order": list(audit.CAPTURE_NAMES),
        "remote_root": installed_fakes.ROOT,
        "remote_python": installed_fakes.ROOT + "/venv/bin/python",
        "helper_sha256": audit.digest(helper.__file__),
        "collector_sha256": audit.digest(collector.__file__),
        "manifest_sha256": "a" * 64,
        "preflight_receipt_sha256": "b" * 64,
        "outputs": [
            {"gpio": 18, "saleae_channel": 0},
            {"gpio": 23, "saleae_channel": 1},
        ],
        "sequence": [
            {
                "name": name,
                "duration_seconds": dwell,
                "operation": operation,
                "value": value,
            }
            for name, dwell, operation, value in helper.SEQUENCE
        ],
        "runtime_flags": {"short_slice": False, "shared": False},
        "pre_capture_waveform_identification": {
            "ordinary_width_period_relative_band": 0.1,
            "minimum_identifiable_train_pulses": 5,
            "sustained_high_threshold_seconds": 0.1,
            "minimum_joint_brake_overlap_seconds": 0.1,
        },
    }


def frozen_plan(tmp_path, monkeypatch, value=None):
    path = tmp_path / audit.PLAN_NAME
    write_json(path, plan_value() if value is None else value)
    monkeypatch.setattr(audit, "PLAN_SHA256", audit.digest(path))
    return path


def test_unset_plan_fails_closed_before_collector_or_evidence(monkeypatch):
    monkeypatch.setattr(audit, "PLAN_SHA256", None)
    monkeypatch.setattr(
        audit, "_collector", lambda: pytest.fail("No permissive fallback")
    )
    with pytest.raises(ValueError, match="not frozen"):
        audit.read_plan()


def test_frozen_plan_unchanged_reused_methods_and_nominals(tmp_path, monkeypatch):
    path = frozen_plan(tmp_path, monkeypatch)
    before = copy.deepcopy(audit.waveform.NOMINALS)
    assert audit.read_plan(path)["capture_order"] == list(audit.CAPTURE_NAMES)
    assert audit.retarget_channel is audit.waveform.retarget_channel
    assert audit.functional_facts is audit.waveform.functional_facts
    assert {tag: row["high_us"] for tag, row in audit.NOMINALS.items()} == {
        "servo_angle0": 999.771,
        "servo_angle90": 1499.657,
        "servo_angle180": 1999.847,
        "motor_half": 499.992,
    }
    assert audit.waveform.NOMINALS == before
    path.write_text(path.read_text() + " ")
    with pytest.raises(ValueError, match="plan changed"):
        audit.read_plan(path)


@pytest.mark.parametrize(
    "key,value",
    [
        ("ordinary_width_period_relative_band", 0.11),
        ("minimum_identifiable_train_pulses", True),
        ("sustained_high_threshold_seconds", 0.2),
        ("minimum_joint_brake_overlap_seconds", 0.2),
    ],
)
def test_identification_rules_are_exact_not_waveform_acceptance(
    tmp_path, monkeypatch, key, value
):
    plan = plan_value()
    plan["pre_capture_waveform_identification"][key] = value
    path = frozen_plan(tmp_path, monkeypatch, plan)
    with pytest.raises(ValueError, match="identification"):
        audit.read_plan(path)


def test_changed_reused_source_refused(tmp_path, monkeypatch):
    path = frozen_plan(tmp_path, monkeypatch)
    monkeypatch.setattr(audit, "REUSED_RAW_FACTS_SHA256", "0" * 64)
    with pytest.raises(ValueError, match="reconstruction changed"):
        audit.read_plan(path)


@pytest.mark.parametrize("version", [0, 1])
@pytest.mark.parametrize("edges", [[], [0.8, 0.800999771, 0.82, 0.820999771]])
def test_raw_arrays_and_all_endpoint_lows_retained(tmp_path, version, edges):
    path = tmp_path / "digital.bin"
    path.write_bytes(binary(edges, version))
    actual = audit.read_channel(path)
    expected = audit.waveform.read_channel(path)
    assert actual == expected
    assert actual["waveform"]["transition_seconds"] == edges
    assert len(actual["all_high_runs"]) == len(edges) // 2
    assert len(actual["all_low_runs"]) == len(edges) // 2 + 1
    assert len(actual["all_adjacent_rise_intervals"]) == max(0, len(edges) // 2 - 1)


def saved_capture(tmp_path, monkeypatch, environment, receipt=None):
    root = installed_fakes.ROOT
    manifest_path = root + "/" + collector.MANIFEST_FILENAME
    if receipt is None:
        _state, _guard, _native, manifest, _sleeps, _detect, _paths, _chip = environment
        remote = helper.experiment(manifest_path)
    else:
        remote, manifest = receipt
    assert remote["success"]
    calls = []
    original_plan = collector.validate_plan
    original_sources = collector.validate_local_manifest
    original_remote = collector.validate_remote

    def validate_plan(plan, given_manifest):
        assert given_manifest == manifest
        assert plan["remote_root"] == root
        if receipt is not None:
            original_plan(plan, given_manifest)
        calls.append("installed_plan")

    def validate_local_manifest(given_manifest):
        assert given_manifest == manifest
        if receipt is not None:
            original_sources(given_manifest)
        calls.append("installed_sources")

    def validate_remote(remote_receipt, given_manifest):
        assert given_manifest == manifest
        audit.require(
            remote_receipt.get("success") is True
            and "integration_shim" not in remote_receipt
            and remote_receipt.get("installed_dispatch") == remote["installed_dispatch"]
            and remote_receipt["installed_dispatch"]["virtual_pwmio_export_used"]
            is False
            and remote_receipt["blinka_import_chip"] == remote["blinka_import_chip"]
            and remote_receipt["blinka_import_chip"]["closed"] is True
            and remote_receipt["source_paths"] == manifest["source_paths"],
            "Fixture installed dispatch/import/source contract failed",
        )
        if receipt is not None:
            original_remote(remote_receipt, given_manifest)
        helper.validate_actions(remote_receipt)
        calls.append("installed_receipt")

    monkeypatch.setattr(collector, "validate_plan", validate_plan)
    monkeypatch.setattr(collector, "validate_local_manifest", validate_local_manifest)
    monkeypatch.setattr(collector, "validate_remote", validate_remote)
    monkeypatch.setattr(
        audit.waveform.collector,
        "validate_remote",
        lambda *_args: pytest.fail("Legacy shim validation must never be called"),
    )
    directory = tmp_path / audit.CAPTURE_NAMES[0]
    directory.mkdir()
    write_json(directory / "manifest.json", manifest)
    plan = plan_value()
    plan["manifest_sha256"] = audit.digest(directory / "manifest.json")
    path = frozen_plan(tmp_path, monkeypatch, plan)
    (directory / "plan.json").write_bytes(path.read_bytes())
    program = root + "/" + helper.NEW_SOURCE
    common = {
        "mode": collector.MODE,
        "backend": collector.BACKEND,
        "remote_root": root,
        "remote_python": plan["remote_python"],
        "remote_program": program,
        "remote_manifest": manifest_path,
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "plan_sha256": audit.PLAN_SHA256,
        "manifest_sha256": plan["manifest_sha256"],
        "preflight_receipt_sha256": plan["preflight_receipt_sha256"],
    }
    metadata = {
        **common,
        "schema_version": 1,
        "host": "test-pi5.local",
        "sequence_marker": collector.SEQUENCE_MARKER,
        "sample_rate_hz": 100_000_000,
        "glitch_filters": [],
        "remote": remote,
        "source_plan": plan,
        "source_manifest": manifest,
        "helper_sha256": plan["helper_sha256"],
        "collector_sha256": plan["collector_sha256"],
        "collection_success": True,
        "production_backend_unchanged": True,
        "installed_blinka_dispatch_exercised": True,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "whole_blinka_compatibility_proven": False,
        "actual_actuators_attached": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "outputs": [
            {"gpio": gpio, "saleae_channel": index, "backend": collector.BACKEND}
            for gpio, index in ((18, 0), (23, 1))
        ],
    }
    acquisition = {
        **common,
        "primary_error": None,
        "evidence_errors": [],
        "ssh_exit_unavailable_after_exception": False,
        "requested_channels": [0, 1],
        "requested_sample_rate_hz": 100_000_000,
        "requested_glitch_filters": [],
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "remote_command": [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            audit.shlex.join(
                [plan["remote_python"], "-I", program, "--manifest", manifest_path]
            ),
        ],
    }
    for name, value in (
        ("remote.stdout", remote),
        ("results.json", metadata),
        ("acquisition.json", acquisition),
    ):
        write_json(directory / name, value)
    (directory / "remote.stderr").write_text("fixture-only preserved diagnostic\n")
    settings = {
        "enabledChannels": [{"type": "Digital", "index": index} for index in (0, 1)],
        "sampleRate": {"digital": 100_000_000},
        "glitchFilter": {"enabled": False, "channels": []},
    }
    with zipfile.ZipFile(directory / "waveform.sal", "w") as archive:
        archive.writestr(
            "meta.json",
            json.dumps(
                {
                    "data": {
                        "legacySettings": settings,
                        "legacyDevice": {
                            "isSimulation": False,
                            "deviceId": "81F8C2631DF5BF30",
                        },
                    }
                }
            ),
        )
    for index, edges in enumerate(visible_protocol()):
        (directory / f"digital_{index}.bin").write_bytes(binary(edges))
    return directory, path, calls


def test_real_new_collector_validation_chain_with_declared_simulated_provenance(
    tmp_path, monkeypatch, strict_receipt
):
    # The recording-only helper truly executes installed Python dispatch and
    # consumer/cleanup logic. Source/version origins are explicitly declared
    # fixture data, not an observed physical Pi or an executed installed wheel.
    directory, plan, calls = saved_capture(tmp_path, monkeypatch, None, strict_receipt)
    report = audit.analyze(directory, plan)
    assert calls == ["installed_plan", "installed_sources", "installed_receipt"]
    assert report["collection_receipts_validated"]
    assert report["source_manifest"] == strict_receipt[1]
    assert not report["old_shim_receipts_converted"]
    assert report["functional_waveform_facts"]["ambiguities"] == []


def test_complete_installed_report_separates_receipt_from_topology(
    tmp_path, monkeypatch, environment
):
    before = copy.deepcopy(audit.waveform.NOMINALS)
    directory, plan, calls = saved_capture(tmp_path, monkeypatch, environment)
    report = audit.analyze(directory, plan)
    assert calls == ["installed_plan", "installed_sources", "installed_receipt"]
    assert report["collection_receipts_validated"]
    assert len(report["evidence_sha256"]) == 9
    assert report["functional_waveform_facts"][
        "complete_frozen_ordered_joint_topology_supported"
    ]
    assert report["functional_waveform_facts"]["ambiguities"] == []
    dispatch = report[
        "validated_installed_dispatch_and_provenance_not_electrical_phase_identity"
    ]
    assert dispatch["installed_dispatch"]["real_board_used"]
    assert dispatch["installed_dispatch"]["real_pwmio_used"]
    assert not dispatch["installed_dispatch"]["virtual_pwmio_export_used"]
    import_chip = report[
        "validated_separate_import_only_lgpio_handle_not_pwm_ownership"
    ]
    assert (
        import_chip["opened"]
        and import_chip["closed"]
        and import_chip["hooks_restored"]
    )
    assert not import_chip["claims_or_writes_permitted"]
    assert report["preserved_stderr"]["byte_count"] > 0
    assert report["actual_recorded_exit_statuses"] == {
        "consumer_ssh_returncode_from_results": 0,
        "consumer_ssh_returncode_from_acquisition": 0,
        "local_collector_cli_exit_not_inferred": True,
    }
    for key in (
        "whole_blinka_compatibility_proven",
        "general_hardware_or_api_compatibility_proven",
        "actual_actuator_operation_established",
        "actuator_safety_established",
        "matched_performance_parity",
        "pi_saleae_clocks_aligned",
        "application_latency_measured",
        "reused_waveform_globals_overridden",
        "old_shim_receipts_converted",
    ):
        assert report[key] is False
    assert report["waveform_accepted"] is None and report["parity_pass"] is None
    assert audit.waveform.NOMINALS == before
    report["actual_consumer_u16_c_rounded_nominals"]["servo_angle0"]["high_us"] = 123
    assert audit.waveform.NOMINALS == before
    assert not (directory / "installed-consumer-analysis.json").exists()
    for name in ("gpio18_channel0", "gpio23_channel1"):
        channel = report[name]
        summary = report["complete_extent_descriptive_statistics"][name]
        assert (
            summary["all_high_widths_including_long_and_anomalous_us"]
            == channel["all_high_width_stats_us"]
        )
        assert (
            summary["all_low_widths_including_initial_and_final_us"]
            == channel["all_low_width_stats_us"]
        )
        assert (
            summary["all_adjacent_rise_intervals_including_gaps_us"]
            == channel["all_adjacent_rise_stats_us"]
        )


@pytest.mark.parametrize(
    "file,key,value",
    [
        ("results.json", "schema_version", True),
        ("results.json", "remote_returncode", True),
        ("results.json", "parity_pass", True),
        ("results.json", "whole_blinka_compatibility_proven", True),
        ("results.json", "installed_blinka_dispatch_exercised", False),
        ("results.json", "source_manifest", {}),
        ("results.json", "source_plan", {}),
        ("results.json", "collector_sha256", "a" * 64),
        ("results.json", "manifest_sha256", "a" * 64),
        ("results.json", "receipt_validation_error", "contradiction"),
        ("acquisition.json", "remote_returncode", None),
        ("acquisition.json", "remote_command", ["not the isolated command"]),
        ("acquisition.json", "requested_channels", [0]),
        ("acquisition.json", "requested_sample_rate_hz", 50_000_000),
        ("acquisition.json", "requested_glitch_filters", [0]),
        ("acquisition.json", "ssh_exit_unavailable_after_exception", True),
        ("acquisition.json", "primary_error", "timeout"),
        ("acquisition.json", "evidence_errors", ["failed export"]),
        ("acquisition.json", "remote_root", "/tmp/another"),
        ("acquisition.json", "local_timing_not_aligned_to_pi_or_saleae", False),
    ],
)
def test_mismatched_failed_or_false_verdict_collection_refused(
    tmp_path, monkeypatch, environment, file, key, value
):
    directory, plan, _calls = saved_capture(tmp_path, monkeypatch, environment)
    target = directory / file
    data = json.loads(target.read_text())
    data[key] = value
    write_json(target, data)
    with pytest.raises(ValueError):
        audit.analyze(directory, plan)


@pytest.mark.parametrize(
    "scope,key,value",
    [
        ("legacyDevice", "isSimulation", True),
        ("legacyDevice", "deviceId", "0000000000000001"),
        ("legacySettings", "enabledChannels", [{"type": "Digital", "index": 0}]),
        ("legacySettings", "sampleRate", {"digital": 50_000_000}),
        ("legacySettings", "glitchFilter", {"enabled": True, "channels": [0]}),
    ],
)
def test_wrong_saved_physical_sal_settings_refused(
    tmp_path, monkeypatch, environment, scope, key, value
):
    directory, plan, _calls = saved_capture(tmp_path, monkeypatch, environment)
    path = directory / "waveform.sal"
    with zipfile.ZipFile(path) as archive:
        data = json.loads(archive.read("meta.json"))
    data["data"][scope][key] = value
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("meta.json", json.dumps(data))
    with pytest.raises(ValueError):
        audit.analyze(directory, plan)


def test_complete_boundaries_sibling_overlap_and_short_fragments_are_not_trimmed(
    tmp_path, monkeypatch, environment
):
    directory, plan, _calls = saved_capture(tmp_path, monkeypatch, environment)
    edges18, edges23 = visible_protocol()
    edges18[5] += 0.005  # Split a train with a retained 5999.771-us anomaly.
    shift = 3.302 - 3.304  # Exact peer boundary touch is still overlap.
    edges23[2:-2] = [edge + shift for edge in edges23[2:-2]]
    for index, edges in enumerate((edges18, edges23)):
        (directory / f"digital_{index}.bin").write_bytes(binary(edges))
    report = audit.analyze(directory, plan)
    facts = report["functional_waveform_facts"]
    assert not facts["complete_frozen_ordered_joint_topology_supported"]
    assert report["gpio18_channel0"]["waveform"]["transition_seconds"] == edges18
    assert report["gpio23_channel1"]["waveform"]["transition_seconds"] == edges23
    fragments = facts["all_width_period_train_fragments_including_short"]["gpio18"][
        "servo_angle0"
    ]
    assert [len(row["pair_indices"]) for row in fragments] == [2, 17]
    summary = report["complete_extent_descriptive_statistics"]["gpio18_channel0"]
    assert [
        row["high_error_from_u16_c_target_us"]["count"]
        for row in summary["every_width_period_fragment_including_short"][
            "servo_angle0"
        ]
    ] == [2, 17]
    assert report["gpio18_channel0"]["all_high_runs"][2]["width_us"] == pytest.approx(
        5999.771
    )
    assert any(
        row["feature"] == "servo_angle0_full_extent" for row in facts["ambiguities"]
    )
    full = next(
        row
        for row in facts["physical_observations"]
        if row["feature"] == "motor_forward_full_physical_long_high"
    )
    assert not full["evidence"]["sibling"]["low_throughout_full_window_observed"]
    assert not full["evidence"]["sibling"]["guarded_core_substitution_used"]


def test_retained_plan_manifest_and_channel_bounds_are_not_substituted(
    tmp_path, monkeypatch, environment
):
    directory, plan, _calls = saved_capture(tmp_path, monkeypatch, environment)
    (directory / "plan.json").write_text("{}")
    with pytest.raises(ValueError, match="Retained capture plan"):
        audit.analyze(directory, plan)
    (directory / "plan.json").write_bytes(plan.read_bytes())
    (directory / "manifest.json").write_text(
        (directory / "manifest.json").read_text() + " "
    )
    with pytest.raises(ValueError, match="manifest bytes"):
        audit.analyze(directory, plan)
    original = (directory / "manifest.json").read_text().rstrip() + "\n"
    (directory / "manifest.json").write_text(original)
    (directory / "digital_1.bin").write_bytes(binary(visible_protocol()[1], end=5.4))
    with pytest.raises(ValueError, match="share acquisition bounds"):
        audit.analyze(directory, plan)


def test_only_new_named_captures_and_regular_evidence(
    tmp_path, monkeypatch, environment
):
    directory, plan, _calls = saved_capture(tmp_path, monkeypatch, environment)
    old = tmp_path / "oct7-pi5-native-consumers-r1"
    old.mkdir()
    with pytest.raises(ValueError, match="new installed"):
        audit.analyze(old, plan)
    data = directory / "digital_0.bin"
    other = tmp_path / "other.bin"
    other.write_bytes(data.read_bytes())
    data.unlink()
    data.symlink_to(other)
    with pytest.raises(ValueError, match="Regular evidence"):
        audit.analyze(directory, plan)


def test_cli_exclusive_default_filename_and_all_validation_before_writes(
    tmp_path, monkeypatch, environment
):
    directory, plan, _calls = saved_capture(tmp_path, monkeypatch, environment)
    assert audit.main([str(directory), "--plan", str(plan)]) == 0
    output = directory / "installed-consumer-analysis.json"
    before = hashlib.sha256(output.read_bytes()).hexdigest()
    with pytest.raises(ValueError, match="Exclusive fresh"):
        audit.main([str(directory), "--plan", str(plan)])
    assert hashlib.sha256(output.read_bytes()).hexdigest() == before
    with pytest.raises(ValueError, match="filename"):
        audit.main([str(directory), "--output-name", "../outside.json"])
    with pytest.raises(ValueError, match="Exclusive fresh"):
        audit.main([str(directory), str(directory), "--output-name", "duplicate.json"])
    second = tmp_path / audit.CAPTURE_NAMES[1]
    second.mkdir()
    with pytest.raises(ValueError, match="Regular evidence"):
        audit.main(
            [
                str(directory),
                str(second),
                "--plan",
                str(plan),
                "--output-name",
                "all-or-none.json",
            ]
        )
    assert not (directory / "all-or-none.json").exists()
    assert not (second / "all-or-none.json").exists()
