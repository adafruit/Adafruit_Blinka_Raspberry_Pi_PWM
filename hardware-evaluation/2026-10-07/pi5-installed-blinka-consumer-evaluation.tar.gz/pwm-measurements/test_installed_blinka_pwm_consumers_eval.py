"""Real Blinka/consumer Python sources with recording-only hardware/detection.

Temporary source-only installation is not a built/installed-wheel compatibility
claim. No GPIO, native extension, network, SSH, subprocess or Saleae is used.
"""

import copy
import hashlib
import importlib
import signal
import sys
from pathlib import Path
from types import SimpleNamespace

import installed_blinka_pwm_consumers_eval as bench
import pytest
import test_native_pwm_consumers_eval as native_fakes

old_environment = native_fakes.old_environment
dual_environment = native_fakes.dual_environment
native_environment = native_fakes.environment
ROOT = "/tmp/blinka-pwm-installed-consumers.abc123"


@pytest.fixture
def environment(native_environment, monkeypatch, tmp_path):
    state, guard, native, _manifest, sleeps = native_environment
    blinka = Path(__file__).parent.parent / "Adafruit_Blinka/src"
    installed = tmp_path / "venv/lib/site-packages"
    for relative in (
        *("adafruit_blinka/" + name for name in bench.BLINKA_FILES),
        "board.py",
        "board_imports.json",
        "pwmio.py",
    ):
        target = installed / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((blinka / relative).read_bytes())
    patch = (
        Path(__file__).parent.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/docs/blinka-integration.patch"
    ).read_text()
    old, new = [], []
    for line in patch.splitlines():
        if line.startswith("-") and not line.startswith("---"):
            old.append(line[1:])
        if line.startswith("+") and not line.startswith("+++"):
            new.append(line[1:])
    pwmio = installed / "pwmio.py"
    source = pwmio.read_text()
    assert source.count("\n".join(old)) == 1
    pwmio.write_text(source.replace("\n".join(old), "\n".join(new)))
    detector = installed / "adafruit_platformdetect"
    (detector / "constants").mkdir(parents=True)
    (detector / "__init__.py").write_text("from _recording_detector import Detector\n")
    (detector / "constants/__init__.py").write_text("")
    (detector / "constants/boards.py").write_text(
        "def __getattr__(name):\n    return name\n"
    )
    for name in list(sys.modules):
        if name in ("board", "pwmio", "lgpio", "_lgpio") or name.startswith(
            ("adafruit_blinka", "adafruit_platformdetect", "adafruit_motor")
        ):
            monkeypatch.delitem(sys.modules, name, raising=False)
    monkeypatch.syspath_prepend(str(installed))
    state.pins = []
    old_engine = native.SoftwarePWM

    class Engine(old_engine):
        def __init__(self, pin, frequency, duty):
            assert type(pin).__module__ == bench.PIN_MODULE
            state.pins.append(pin)
            super().__init__(("/dev/gpiochip4", pin.id), frequency, duty)

    monkeypatch.setattr(native, "SoftwarePWM", Engine)
    detect = SimpleNamespace(
        board=SimpleNamespace(
            id="RASPBERRY_PI_5", any_raspberry_pi_5_board=True, any_raspberry_pi=True
        ),
        chip=SimpleNamespace(id="BCM2XXX"),
    )

    class Board:
        id = "RASPBERRY_PI_5"
        any_raspberry_pi_5_board = True
        any_raspberry_pi = True

        def __getattr__(self, name):
            return False

    detect.board = Board()
    monkeypatch.setitem(
        sys.modules, "_recording_detector", SimpleNamespace(Detector=lambda: detect)
    )
    state.import_log, state.import_hook, state.import_close_error = [], None, False

    def chip_open(index):
        state.import_log.append(("open", index, 723))
        if state.import_hook:
            state.import_hook()
        return 723

    def chip_close(handle):
        state.import_log.append(("close", handle))
        assert handle == 723 and not state.claimed
        if state.import_close_error:
            raise OSError("injected import close")
        return 0

    def forbidden(*args, **kwargs):
        pytest.fail(f"Unexpected unguarded lgpio mutation: {args} {kwargs}")

    lgpio = SimpleNamespace(
        gpiochip_open=chip_open,
        gpiochip_close=chip_close,
        error=OSError,
        exceptions=True,
        **{name: forbidden for name in bench.MUTATIONS if name != "gpiochip_close"},
    )
    monkeypatch.setitem(sys.modules, "_recording_lgpio", lgpio)
    (installed / "lgpio.py").write_text("from _recording_lgpio import *\n")
    # Real Pin source's sysfs discovery is read-only; present a fake compatible
    # file, not an actual /sys or GPIO device. Every other Path operation is real.
    chip = tmp_path / "gpiochip4"
    (chip / "of_node").mkdir(parents=True)
    (chip / "of_node/compatible").write_text("raspberrypi,rp1-gpio\0")
    old_glob = Path.glob
    monkeypatch.setattr(
        Path,
        "glob",
        lambda self, pattern, **kwargs: (
            iter([chip])
            if self == Path("/sys/bus/gpio/devices") and pattern == "gpiochip*"
            else old_glob(self, pattern, **kwargs)
        ),
    )
    original_flags = sys.flags

    class Flags:
        isolated = 1

        def __getattr__(self, name):
            return getattr(original_flags, name)

    monkeypatch.setattr(sys, "flags", Flags())
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setattr(sys, "executable", ROOT + "/venv/bin/python")
    for name in list(bench.os.environ):
        if name.startswith("BLINKA_") or name in ("PYTHONPATH", "PYTHONHOME"):
            monkeypatch.delenv(name, raising=False)
    paths = {
        **{
            key: installed / key
            for key in ("board.py", "pwmio.py", "board_imports.json", "lgpio.py")
        },
        **{
            "adafruit_blinka/" + name: installed / "adafruit_blinka" / name
            for name in bench.BLINKA_FILES
        },
        **{
            "adafruit_platformdetect/" + str(path.relative_to(detector)): path
            for path in detector.rglob("*.py")
        },
        **bench.protocol.consumer_inventory(),
        bench.dual.base.PACKAGE + "/__init__.py": Path(native.__file__),
    }
    # Account for already imported requirement-parsing dependencies; no fake
    # pwmio/board/Pin module is created or inserted.
    package = Path(importlib.util.find_spec("packaging").origin).parent
    paths.update(
        {
            "packaging/" + str(path.relative_to(package)): path
            for path in package.rglob("*.py")
        }
    )
    manifest = {
        "schema_version": 1,
        "source_sha256": {"fixture-only": "a" * 64},
        "source_paths": {key: str(path) for key, path in paths.items()},
    }
    monkeypatch.setattr(bench, "approved_manifest_path", lambda path: Path(path))
    monkeypatch.setattr(bench, "load_manifest", lambda path: manifest)

    def inspect_sources(root, given, receipt):
        assert given is manifest
        # Gate freshness first, then actual patched pwmio imports the genuine
        # public class whose hardware engine is recording-only in this fixture.
        monkeypatch.setitem(sys.modules, bench.dual.base.PACKAGE, native)
        receipt.update(
            source_paths=manifest["source_paths"],
            source_sha256=manifest["source_sha256"],
            distribution_versions={"adafruit-circuitpython-motor": "3.5.0"},
        )
        return paths

    monkeypatch.setattr(bench, "inspect_sources", inspect_sources)
    yield state, guard, native, manifest, sleeps, detect, paths, chip
    # Only test-imported modules are removed; normal helper runs in a fresh
    # finite process and intentionally does not restore an import cache.
    for name in list(sys.modules):
        if (
            name in ("board", "pwmio", "lgpio", "_lgpio")
            or name.startswith(
                ("adafruit_blinka.", "adafruit_platformdetect.", "adafruit_motor.")
            )
            or name in ("adafruit_blinka", "adafruit_platformdetect", "adafruit_motor")
        ):
            monkeypatch.delitem(sys.modules, name, raising=False)


def run():
    return bench.experiment(ROOT + "/manifest.json")


def test_real_source_dispatch_real_pins_consumers_and_private_shutdown(environment):
    state, _guard, native, _manifest, sleeps, _detect, _paths, _chip = environment
    receipt = run()
    assert receipt["success"], receipt["primary_error"]
    assert sys.modules["pwmio"].PWMOut is native.PWMOut
    assert len(state.pins) == 3
    assert state.pins[0] is state.pins[1] is sys.modules["board"].D18
    assert state.pins[2] is sys.modules["board"].D23
    assert (
        bench.SEQUENCE is bench.protocol.SEQUENCE
        and bench.OUTPUTS is bench.protocol.OUTPUTS
    )
    assert len(receipt["phases"]) == 15 and len(receipt["actions"]) == 10
    assert sum(sleeps) == pytest.approx(3.75)
    assert [a["api_state_after"][0]["duty_u16"] for a in receipt["actions"][:4]] == [
        3276,
        4914,
        6553,
        0,
    ]
    assert receipt["actions"][1]["consumer_readback"] == pytest.approx(
        89.97253585596583
    )
    assert [
        tuple(row["duty_u16"] for row in a["api_state_after"])
        for a in receipt["actions"][4:]
    ] == [(65535, 65535), (32767, 0), (65535, 0), (0, 32767), (0, 65535), (0, 0)]
    assert (
        receipt["shutdowns"][1]["sibling_after"]
        == receipt["shutdowns"][1]["sibling_before"]
    )
    assert not state.claimed and state.levels == {18: 0, 23: 0}
    assert state.import_log == [("open", 4, 723), ("close", 723)]
    assert receipt["blinka_import_chip"]["hooks_restored"]
    assert receipt["blinka_import_chip"]["closed"]
    assert receipt["installed_dispatch"]["real_pwmio_used"]
    assert not receipt["installed_dispatch"]["virtual_pwmio_export_used"]
    assert (
        not receipt["whole_blinka_compatibility_proven"]
        and receipt["parity_pass"] is None
    )


@pytest.mark.parametrize("gpio", [18, 23])
def test_foreign_line_rejects_before_board_import(environment, gpio):
    state, *_rest = environment
    state.foreign.add(gpio)
    receipt = run()
    assert not receipt["success"] and "fresh unused" in receipt["primary_error"]
    assert state.import_log == [] and not state.claimed


@pytest.mark.parametrize(
    "flag",
    ["BLINKA_PWM_SHARED", "BLINKA_PWM_SHORT_SLICE", "BLINKA_FORCEBOARD", "PYTHONPATH"],
)
def test_inherited_overrides_fail_before_import_or_claim(
    environment, monkeypatch, flag
):
    state, *_rest = environment
    monkeypatch.setenv(flag, "1")
    receipt = run()
    assert "overrides" in receipt["primary_error"] and not receipt["success"]
    assert not state.import_log and not state.claimed


@pytest.mark.parametrize(
    "name",
    [
        "board",
        "pwmio",
        bench.PIN_MODULE,
        "adafruit_motor.servo",
        "adafruit_platformdetect",
    ],
)
def test_preloaded_module_not_replaced(environment, monkeypatch, name):
    state, *_rest = environment
    foreign = SimpleNamespace()
    monkeypatch.setitem(sys.modules, name, foreign)
    receipt = run()
    assert "preexisting" in receipt["primary_error"] and not receipt["success"]
    assert sys.modules[name] is foreign and not state.import_log


@pytest.mark.parametrize(
    "wrong", ["detection", "overprecise_old_ids", "dispatch", "origin"]
)
def test_wrong_detection_dispatch_or_source_origin(environment, wrong):
    state, _guard, _native, _manifest, _sleeps, detect, paths, chip = environment
    if wrong == "detection":
        detect.chip.id = "WRONG"
    elif wrong == "overprecise_old_ids":
        detect.chip.id = "BCM2712"
        detect.board.id = "RASPBERRY_PI_5B"
    elif wrong == "dispatch":
        paths["pwmio.py"].write_text("class PWMOut: pass\n")
    else:
        paths["board.py"] = paths["pwmio.py"]
    receipt = run()
    assert not receipt["success"] and not state.claimed
    assert state.import_log == [("open", 4, 723), ("close", 723)]
    assert receipt["blinka_import_chip"]["hooks_restored"]


def test_partial_board_import_close_owned_handle_preserve_original_error(environment):
    state, _guard, _native, _manifest, _sleeps, _detect, paths, _chip = environment
    with paths["adafruit_blinka/microcontroller/bcm2712/pin.py"].open("a") as stream:
        stream.write("\nraise RuntimeError('partial Pin import')\n")
    receipt = run()
    assert "partial Pin import" in receipt["primary_error"] and not receipt["success"]
    assert bench.PIN_MODULE in sys.modules and "board" not in sys.modules
    assert state.import_log == [("open", 4, 723), ("close", 723)]
    assert not state.claimed and receipt["blinka_import_chip"]["hooks_restored"]


@pytest.mark.parametrize(
    "operation",
    ["gpio_claim_output", "gpio_write", "gpio_free", "tx_pwm", "gpiochip_close"],
)
def test_import_cannot_claim_free_drive_or_close(environment, operation):
    state, _guard, _native, _manifest, _sleeps, _detect, paths, _chip = environment
    with paths["adafruit_blinka/microcontroller/bcm2712/pin.py"].open("a") as stream:
        stream.write(f"\nimport lgpio\nlgpio.{operation}(123,18,0)\n")
    receipt = run()
    assert "may not claim/free/drive/close" in receipt["primary_error"]
    assert state.import_log == [("open", 4, 723), ("close", 723)] and not state.claimed


def test_signal_during_open_atomic_latch_restores_and_closes(environment):
    state, guard, *_rest = environment
    state.import_hook = lambda: guard.handler(signal.SIGTERM, None)
    receipt = run()
    assert not receipt["success"] and "SafetyAbort" in receipt["primary_error"]
    assert receipt["signals_received"] == [signal.SIGTERM]
    assert state.import_log == [("open", 4, 723), ("close", 723)] and not state.claimed


def test_partial_public_constructor_retained_and_deinitialized(
    environment, monkeypatch
):
    state, _guard, native, *_rest = environment
    original = native.PWMOut.__init__

    def init(self, *args, **kwargs):
        original(self, *args, **kwargs)
        raise RuntimeError("partial public constructor")

    monkeypatch.setattr(native.PWMOut, "__init__", init)
    receipt = run()
    assert (
        "partial public constructor" in receipt["primary_error"]
        and not receipt["success"]
    )
    assert not state.claimed and receipt["outputs"][0]["released"]
    assert any(e["operation"] == "PWMOut.deinit" for e in receipt["events"])
    assert state.import_log[-1] == ("close", 723)


@pytest.mark.parametrize("gpio", [18, 23])
def test_setter_failure_still_releases_outputs_and_import_handle(environment, gpio):
    state, *_rest = environment
    state.fail = ("configure", gpio)
    receipt = run()
    assert "configure" in receipt["primary_error"] and not receipt["success"]
    assert receipt["actions"][-1]["status"] == "error"
    assert not state.claimed and all(row["released"] for row in receipt["outputs"])
    assert state.import_log[-1] == ("close", 723)


def test_second_motor_signal_latches_both_native_private_requests(environment):
    state, guard, *_rest = environment
    state.hook = lambda name, gpio: (
        guard.handler(signal.SIGTERM, None) if name == "claim" and gpio == 23 else None
    )
    receipt = run()
    assert "SafetyAbort" in receipt["primary_error"] and not state.claimed
    assert receipt["signals_received"] == [signal.SIGTERM]
    assert state.import_log[-1] == ("close", 723)


def test_cleanup_failures_are_not_success_and_do_not_replace_primary(environment):
    state, *_rest = environment
    state.fail = ("configure", 18)
    state.import_close_error = True
    receipt = run()
    assert "configure" in receipt["primary_error"] and not receipt["success"]
    assert any("import chip close" in error for error in receipt["cleanup_errors"])
    assert not receipt["blinka_import_chip"]["closed"] and not state.claimed


def test_native_deinit_failure_still_releases_before_import_close(environment):
    state, *_rest = environment
    state.fail = ("stop", 23)
    receipt = run()
    assert not receipt["success"] and receipt["cleanup_errors"]
    assert not state.claimed and state.import_log[-1] == ("close", 723)


def test_pin_mutation_is_detected_but_cleanup_does_not_drive_through_pin(environment):
    state, *_rest = environment

    def hook(name, gpio):
        if name == "configure" and gpio == 18:
            sys.modules["board"].D18.id = 19

    state.hook = hook
    receipt = run()
    assert (
        "Pin identity/id changed" in receipt["primary_error"] and not receipt["success"]
    )
    assert not state.claimed and state.import_log[-1] == ("close", 723)


def test_manifest_unfrozen_placeholder_fails_closed(monkeypatch):
    monkeypatch.setattr(bench, "RUNTIME_PINS", None)
    monkeypatch.setattr(bench, "DISTRIBUTION_VERSIONS", None)
    with pytest.raises(bench.core.BenchError, match="not frozen"):
        bench.validate_manifest({})


def test_exact_manifest_pins_and_duplicate_keys(monkeypatch, tmp_path):
    runtime = {"test-runtime.py": "a" * 64}
    versions = {name: "fixture-version" for name in bench.DISTRIBUTIONS}
    monkeypatch.setattr(bench, "RUNTIME_PINS", runtime)
    monkeypatch.setattr(bench, "DISTRIBUTION_VERSIONS", versions)
    hashes = {**bench.FROZEN_PINS, **runtime, bench.NEW_SOURCE: "b" * 64}
    manifest = {
        "schema_version": 1,
        "distribution_versions": versions,
        "source_sha256": hashes,
        "source_paths": {name: "/fixture/" + name for name in hashes},
    }
    assert bench.validate_manifest(manifest) == hashes
    for key in ("source_sha256", "source_paths", "distribution_versions"):
        bad = copy.deepcopy(manifest)
        bad[key].pop(next(iter(bad[key])))
        with pytest.raises(bench.core.BenchError):
            bench.validate_manifest(bad)
    bad = copy.deepcopy(manifest)
    bad["source_sha256"]["native_pwm_consumers_eval.py"] = "0" * 64
    with pytest.raises(bench.core.BenchError, match="source mismatch"):
        bench.validate_manifest(bad)
    path = tmp_path / "manifest.json"
    path.write_text('{"schema_version":1,"schema_version":1}')
    with pytest.raises(bench.core.BenchError, match="Duplicate"):
        bench.load_manifest(path)


def test_inspect_sources_rejects_changed_bytes_or_origin(monkeypatch, tmp_path):
    path = tmp_path / "source.py"
    path.write_text("source")
    monkeypatch.setattr(bench, "source_inventory", lambda root: {"source": path})
    # This focused bytes/origins gate starts after validated executed helpers.
    helpers = {
        Path(module.__file__).name: Path(module.__file__)
        for module in (
            bench.protocol,
            bench.dual,
            bench.dual.native,
            bench.dual.base,
            bench.dual.base.baseline,
            bench.core,
        )
    }
    monkeypatch.setattr(
        bench, "source_inventory", lambda root: {"source": path, **helpers}
    )
    receipt = {}
    manifest = {
        "source_paths": {"source": str(path)},
        "source_sha256": {"source": "0" * 64},
    }
    with pytest.raises(bench.core.BenchError, match="bytes/origins"):
        bench.inspect_sources(tmp_path, manifest, receipt)
    assert receipt["source_sha256"]["source"] == hashlib.sha256(b"source").hexdigest()
    manifest["source_sha256"] = receipt["source_sha256"]
    manifest["source_paths"]["source"] = "/foreign/source.py"
    with pytest.raises(bench.core.BenchError, match="bytes/origins"):
        bench.inspect_sources(tmp_path, manifest, receipt)


def test_source_paths_reject_foreign_location_and_symlinks(tmp_path):
    root = tmp_path / "root"
    venv = root / "venv"
    venv.mkdir(parents=True)
    file = venv / "board.py"
    file.write_text("source")
    bench.validate_source_paths(root, {"board.py": file})
    with pytest.raises(bench.core.BenchError, match="outside fresh venv"):
        bench.validate_source_paths(tmp_path / "foreign", {"board.py": file})
    link = venv / "alias.py"
    link.symlink_to(file)
    with pytest.raises(bench.core.BenchError, match="non-symlink"):
        bench.validate_source_paths(root, {"board.py": link})
    with pytest.raises(bench.core.BenchError, match="outside fresh isolated root"):
        bench.validate_source_paths(root, {"kernel_pwm_eval.py": file})


@pytest.mark.parametrize("problem", ["python", "platform", "isolated", "tty"])
def test_fresh_process_interpreter_and_noninteractive_gates(
    environment, monkeypatch, problem
):
    state, *_rest = environment
    if problem == "python":
        monkeypatch.setattr(sys, "executable", "/usr/bin/python3")
    elif problem == "platform":
        monkeypatch.setattr(sys, "platform", "darwin")
    elif problem == "isolated":
        monkeypatch.setattr(sys.flags, "isolated", 0)
    else:
        monkeypatch.setattr(sys, "stdin", SimpleNamespace(isatty=lambda: True))
    receipt = run()
    assert not receipt["success"] and receipt["primary_error"]
    assert not state.import_log and not state.claimed


@pytest.mark.parametrize("index", [0, True, "4", 5])
def test_import_open_wrong_chip_does_not_call_original(index):
    calls = []
    library = SimpleNamespace(
        gpiochip_open=lambda chip: calls.append(chip),
        gpiochip_close=lambda handle: pytest.fail("no handle owned"),
    )
    guard = bench.core.SafetySignals()
    receipt = {"cleanup_errors": []}
    owner = bench.ImportChip(library, {"gpiochip_index": 4}, guard, receipt)
    with owner.hooks():
        with pytest.raises(bench.core.BenchError, match="verified RP1"):
            library.gpiochip_open(index)
    owner.close()
    assert not calls and owner.record["hooks_restored"] and not owner.record["opened"]


@pytest.mark.parametrize(
    "path",
    [
        "manifest.json",
        "/tmp/manifest.json",
        ROOT + "/../manifest.json",
        ROOT + "/venv/manifest.json",
    ],
)
def test_manifest_root_path_restrictions(path):
    with pytest.raises(bench.core.BenchError, match="isolated root"):
        bench.approved_manifest_path(path)
