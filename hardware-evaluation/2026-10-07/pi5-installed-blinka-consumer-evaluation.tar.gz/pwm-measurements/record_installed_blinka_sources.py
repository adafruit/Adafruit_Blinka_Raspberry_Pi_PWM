"""Read-only inventory of private installed wheels; never import board or pwmio."""

import datetime
import hashlib
import json
import shlex
import subprocess
import tarfile
import zipfile
from pathlib import Path

import installed_blinka_pwm_consumers_eval as helper
import prepare_installed_blinka_env as preparation

LAB = Path(__file__).resolve().parent
OUTPUT = LAB / "oct7-installed-blinka-source-inventory.json"
CODE = f"""
import hashlib,importlib.metadata,json,pathlib,sys
root=pathlib.Path({preparation.ROOT!r})
sys.path.insert(0,str(root))
import installed_blinka_pwm_consumers_eval as helper
fresh={{}}
helper.fresh_process(root,fresh)
paths=helper.source_inventory(root)
versions={{name:importlib.metadata.version(name) for name in helper.DISTRIBUTIONS}}
source={{key:hashlib.sha256(path.read_bytes()).hexdigest() for key,path in paths.items()}}
for key,expected in helper.FROZEN_PINS.items():
    assert source[key]==expected, key
assert not any(name in sys.modules for name in ('board','pwmio','lgpio','_lgpio'))
print(json.dumps({{'root':str(root),'fresh_process':fresh,'source_sha256':source,
 'source_paths':{{key:str(path) for key,path in paths.items()}},
 'distribution_versions':versions,
 'all_distribution_versions':{{d.metadata['Name']:d.version for d in importlib.metadata.distributions()}},
 'no_board_pwmio_lgpio_import':True}},indent=2))
"""


def digest(data):
    return hashlib.sha256(data).hexdigest()


def archive_sources(path):
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        assert all(member.isfile() or member.isdir() for member in members)
        assert all(
            not Path(member.name).is_absolute() and ".." not in Path(member.name).parts
            for member in members
        )
        files = [member for member in members if member.isfile()]
        assert len(files) == len({member.name for member in files})
        return {
            member.name.removeprefix("./"): digest(archive.extractfile(member).read())
            for member in files
        }


def main():
    stdout, stderr = Path(str(OUTPUT) + ".stdout"), Path(str(OUTPUT) + ".stderr")
    assert not any(
        path.exists() or path.is_symlink() for path in (OUTPUT, stdout, stderr)
    )
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([preparation.PYTHON, "-I", "-c", CODE]),
    ]
    with stdout.open("xb") as out, stderr.open("xb") as err:
        result = subprocess.run(
            command, stdout=out, stderr=err, timeout=45, check=False
        )
    receipt = {
        "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "ssh_returncode": result.returncode,
        "remote_command": command,
        "remote_code": CODE,
        "recorder_sha256": digest(Path(__file__).read_bytes()),
        "stdout_sha256": digest(stdout.read_bytes()),
        "stderr_sha256": digest(stderr.read_bytes()),
        "accepted": False,
    }
    try:
        assert type(result.returncode) is int and result.returncode == 0
        remote = json.loads(stdout.read_text())
        assert remote["root"] == preparation.ROOT
        assert remote["no_board_pwmio_lgpio_import"] is True
        receipt["remote"] = remote
        original = archive_sources(preparation.STAGE / "blinka-source.tar.gz")
        patched = archive_sources(preparation.STAGE / "blinka-patched-source.tar.gz")
        assert set(original) <= set(patched)
        changed = [key for key in original if original[key] != patched[key]]
        extras = sorted(set(patched) - set(original))
        assert changed == ["src/pwmio.py"]
        assert all(Path(key).name.startswith("._") for key in extras)
        receipt["blinka_source_comparison"] = {
            "original_regular_files": len(original),
            "patched_regular_files": len(patched),
            "common_code_changes": changed,
            "extra_appledouble_metadata_files": extras,
            "source_commit": preparation.BLINKA_COMMIT,
        }
        wheels, contents = {}, {}
        for path in sorted((preparation.STAGE / "wheelhouse").glob("*.whl")):
            with zipfile.ZipFile(path) as wheel:
                names = wheel.namelist()
                assert len(names) == len(set(names))
                assert not any(Path(name).name.startswith("._") for name in names)
                for name in names:
                    assert not Path(name).is_absolute() and ".." not in Path(name).parts
                    if not name.endswith("/"):
                        contents.setdefault(name, []).append(
                            (path.name, digest(wheel.read(name)))
                        )
                wheels[path.name] = {
                    "sha256": digest(path.read_bytes()),
                    "size_bytes": path.stat().st_size,
                }
        assert len(wheels) == 23
        checks = {}
        for key, source_path in remote["source_paths"].items():
            if key in helper.FROZEN_PINS and "/" not in key or key == helper.NEW_SOURCE:
                assert digest((LAB / key).read_bytes()) == remote["source_sha256"][key]
                checks[key] = {"kind": "exact_local_helper"}
                continue
            parts = Path(source_path).parts
            assert "site-packages" in parts
            member = "/".join(parts[parts.index("site-packages") + 1 :])
            matches = contents.get(member, [])
            assert len(matches) == 1, (key, member, matches)
            wheel_name, expected = matches[0]
            assert remote["source_sha256"][key] == expected, key
            checks[key] = {
                "kind": "exact_installed_wheel_member",
                "wheel": wheel_name,
                "member": member,
            }
        receipt.update(
            wheel_artifacts=wheels, installed_source_checks=checks, accepted=True
        )
    except Exception as error:
        receipt["error"] = f"{type(error).__name__}: {error}"
    finally:
        with OUTPUT.open("x") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
    print(
        json.dumps(
            {
                "accepted": receipt["accepted"],
                "ssh_returncode": result.returncode,
                "selected_sources": len(receipt.get("installed_source_checks", {})),
                "error": receipt.get("error"),
            }
        )
    )
    return 0 if receipt["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
