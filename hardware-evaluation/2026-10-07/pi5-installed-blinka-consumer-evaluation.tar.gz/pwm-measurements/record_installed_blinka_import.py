"""Guarded real Blinka import only: open/close controller, never claim GPIO."""

import hashlib
import json
import shlex
import subprocess
from pathlib import Path

import prepare_installed_blinka_env as prep

LAB = Path(__file__).resolve().parent
OUTPUT = LAB / "oct7-installed-blinka-import-probe-r2.json"
CODE = f"""
import json,pathlib,sys
root=pathlib.Path({prep.ROOT!r})
sys.path.insert(0,str(root))
import installed_blinka_pwm_consumers_eval as h
receipt={{'scope':'real installed Blinka import only; no GPIO requests or writes',
         'cleanup_errors':[],'primary_error':None,'success':False}}
chip=None
with h.core.SafetySignals() as guard:
    try:
        h.fresh_process(root,receipt)
        manifest=h.load_manifest(root/'oct7-installed-blinka-consumers-manifest.json')
        paths=h.inspect_sources(root,manifest,receipt)
        identity=h.dual.base.baseline.preflight()
        receipt['identity']=identity
        library,native=h.dual.load_backend()
        lgpio=h.importlib.import_module('lgpio')
        chip=h.ImportChip(lgpio,identity,guard,receipt)
        h.installed_api(paths,native,chip,receipt)
        receipt['pio_modules_loaded']=[name for name in sys.modules if name.startswith(
           ('adafruit_blinka_raspberry_pi5_rp1pio','adafruit_blinka_raspberry_pi5_neopixel',
            'rp1pio','neopixel','piomatter'))]
        assert not receipt['pio_modules_loaded']
    except BaseException as error:
        receipt['primary_error']=h.error_text(error)
    finally:
        if chip is not None:
            chip.close()
        receipt['signals_received']=list(guard.received)
receipt['success']=bool(receipt['primary_error'] is None and not receipt['cleanup_errors']
    and not receipt['signals_received'] and chip is not None and chip.record['closed']
    and chip.record['hooks_restored'])
print(json.dumps(receipt,indent=2))
raise SystemExit(0 if receipt['success'] else 1)
"""


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([prep.PYTHON, "-I", "-c", CODE]),
    ]
    stdout, stderr = Path(str(OUTPUT) + ".stdout"), Path(str(OUTPUT) + ".stderr")
    assert not any(p.exists() or p.is_symlink() for p in (OUTPUT, stdout, stderr))
    with stdout.open("xb") as out, stderr.open("xb") as err:
        result = subprocess.run(
            command, stdout=out, stderr=err, timeout=30, check=False
        )
    receipt = {
        "ssh_returncode": result.returncode,
        "remote_command": command,
        "remote_code": CODE,
        "runner_sha256": digest(__file__),
        "stdout_sha256": digest(stdout),
        "stderr_sha256": digest(stderr),
        "manifest_sha256": digest(
            LAB / "oct7-installed-blinka-consumers-manifest.json"
        ),
        "accepted": False,
    }
    try:
        receipt["remote"] = json.loads(stdout.read_text())
        receipt["accepted"] = (
            type(result.returncode) is int
            and result.returncode == 0
            and receipt["remote"]["success"] is True
        )
    except Exception as error:
        receipt["error"] = f"{type(error).__name__}: {error}"
    with OUTPUT.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                "accepted": receipt["accepted"],
                "ssh_returncode": result.returncode,
                "primary_error": receipt.get("remote", {}).get("primary_error"),
                "cleanup_errors": receipt.get("remote", {}).get("cleanup_errors"),
            }
        )
    )
    return 0 if receipt["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
