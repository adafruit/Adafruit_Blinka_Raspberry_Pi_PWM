"""Recording-only collector/receipt tests, never SSH/GPIO/Saleae calls."""

import copy
import hashlib
import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_installed_blinka_pwm_consumers as bench
import pytest
import test_installed_blinka_pwm_consumers_eval as installed_fakes

old_environment = installed_fakes.old_environment
dual_environment = installed_fakes.dual_environment
native_environment = installed_fakes.native_environment
environment = installed_fakes.environment
ROOT = "/tmp/blinka-pwm-installed-consumers.abc123"
PYTHON = ROOT + "/venv/bin/python"


def plan_for(manifest, manifest_bytes):
    return {
        "schema_version": 1,
        "mode": bench.MODE,
        "backend": bench.BACKEND,
        "sequence_marker": bench.SEQUENCE_MARKER,
        "remote_root": ROOT,
        "remote_python": PYTHON,
        "helper_sha256": bench.HELPER_SHA256,
        "collector_sha256": bench.digest(bench.__file__),
        "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "preflight_receipt_sha256": "a" * 64,
        "capture_order": bench.CAPTURES,
        "outputs": [
            {"gpio": 18, "saleae_channel": 0},
            {"gpio": 23, "saleae_channel": 1},
        ],
        "sequence": [
            {
                "name": name,
                "duration_seconds": duration,
                "operation": operation,
                "value": value,
            }
            for name, duration, operation, value in bench.helper.SEQUENCE
        ],
        "runtime_flags": {"short_slice": False, "shared": False},
    }


def declared_manifest():
    # The actual parent-pinned selected runtime bytes remain immutable. A fake
    # receipt below declares simulated remote origins, not an executed wheel.
    manifest = json.loads((Path(__file__).parent / bench.MANIFEST_FILENAME).read_text())
    prior_root = str(Path(manifest["source_paths"][bench.helper.NEW_SOURCE]).parent)
    manifest["source_paths"] = {
        key: path.replace(prior_root, ROOT, 1)
        for key, path in manifest["source_paths"].items()
    }
    return manifest


@pytest.fixture
def receipt(environment):
    actual = bench.helper.experiment(ROOT + "/" + bench.MANIFEST_FILENAME)
    assert actual["success"], actual["primary_error"]
    manifest = declared_manifest()
    actual.update(
        source_sha256=manifest["source_sha256"],
        source_paths=manifest["source_paths"],
        distribution_versions=manifest["distribution_versions"],
    )
    return actual, manifest


def configure(monkeypatch, tmp_path, scenario="success"):
    events = []
    manifest = {
        "schema_version": 1,
        "source_sha256": {bench.helper.NEW_SOURCE: bench.HELPER_SHA256},
    }
    manifest_bytes = json.dumps(manifest, indent=2).encode() + b"\n"
    manifest_path = tmp_path / bench.MANIFEST_FILENAME
    manifest_path.write_bytes(manifest_bytes)
    plan = plan_for(manifest, manifest_bytes)
    plan_path = tmp_path / bench.PLAN_FILENAME
    plan_path.write_text(json.dumps(plan, indent=2) + "\n")
    receipt = {
        "manifest_path": ROOT + "/" + bench.MANIFEST_FILENAME,
        "python_executable": PYTHON,
    }
    local, validate, validate_plan = (
        MagicMock(return_value=manifest["source_sha256"]),
        MagicMock(),
        MagicMock(),
    )
    if scenario == "bad_receipt":
        validate.side_effect = ValueError("bad installed receipt")
    monkeypatch.setattr(bench, "validate_local_manifest", local)
    monkeypatch.setattr(bench, "validate_remote", validate)
    monkeypatch.setattr(bench, "validate_plan", validate_plan)
    capture = MagicMock()
    capture.__enter__.return_value = capture
    capture.stop.side_effect = lambda: events.append("stop")

    def save(path):
        events.append("save")
        if scenario == "save_error":
            raise OSError("save failed")
        Path(path).write_bytes(b"fake SAL")

    def export(path, **kwargs):
        assert kwargs == {"digital_channels": [0, 1]}
        events.append("export")
        (Path(path) / "digital_0.bin").write_bytes(b"all GPIO18 fake raw edges")
        if scenario != "missing_gpio23":
            (Path(path) / "digital_1.bin").write_bytes(b"all GPIO23 fake raw edges")

    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = export
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=MagicMock(return_value=manager)),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            PYTHON,
            "-I",
            ROOT + "/" + bench.helper.NEW_SOURCE,
            "--manifest",
            ROOT + "/" + bench.MANIFEST_FILENAME,
        ]
        assert set(kwargs) == {"stdout", "stderr", "text", "check", "timeout"}
        assert (
            kwargs["timeout"] == 30
            and kwargs["text"] is True
            and kwargs["check"] is False
        )
        if scenario in ("timeout", "interrupt"):
            kwargs["stdout"].write("partial receipt")
            kwargs["stderr"].write("partial actual diagnostic")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            raise KeyboardInterrupt("interrupted")
        kwargs["stdout"].write(json.dumps(receipt))
        kwargs["stderr"].write("retained actual local fork-child diagnostic\n")
        exitcode = (
            True if scenario == "bool_exit" else 1 if scenario == "helper_failed" else 0
        )
        return subprocess.CompletedProcess(command, exitcode)

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(
        bench.time, "sleep", lambda duration: events.append(("sleep", duration))
    )
    return SimpleNamespace(
        events=events,
        manager=manager,
        runner=runner,
        local=local,
        validate=validate,
        plan_validate=validate_plan,
        manifest=manifest,
        plan=plan,
        receipt=receipt,
        manifest_path=manifest_path,
        plan_path=plan_path,
    )


def collect(fake, output, root=ROOT, python=PYTHON):
    return bench.capture_test(output, root, python, fake.manifest_path, fake.plan_path)


def test_physical_config_exact_plan_bytes_actual_exit_and_deferred_verdict(
    monkeypatch, tmp_path
):
    fake = configure(monkeypatch, tmp_path)
    output = tmp_path / bench.CAPTURES[0]
    result = collect(fake, output)
    assert fake.events == [
        ("sleep", 0.5),
        "ssh",
        ("sleep", 0.2),
        "stop",
        "save",
        "export",
    ]
    fake.manager.start_capture.assert_called_once_with(
        device_id="81F8C2631DF5BF30",
        device_configuration={
            "enabled_digital_channels": [0, 1],
            "digital_sample_rate": 100_000_000,
            "glitch_filters": [],
        },
    )
    fake.validate.assert_called_once_with(fake.receipt, fake.manifest)
    assert (
        result["collection_success"] and result["installed_blinka_dispatch_exercised"]
    )
    assert result["remote_returncode"] == 0 and type(result["remote_returncode"]) is int
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert (
        not result["parity_evaluated"]
        and not result["whole_blinka_compatibility_proven"]
    )
    assert (output / "manifest.json").read_bytes() == fake.manifest_path.read_bytes()
    assert (output / "plan.json").read_bytes() == fake.plan_path.read_bytes()
    assert (
        result["source_plan"] == fake.plan
        and result["source_manifest"] == fake.manifest
    )
    assert result["plan_sha256"] == bench.digest(fake.plan_path)
    assert result["manifest_sha256"] == bench.digest(fake.manifest_path)
    assert (
        output / "remote.stderr"
    ).read_text() == "retained actual local fork-child diagnostic\n"
    acquisition = json.loads((output / "acquisition.json").read_text())
    assert acquisition["requested_glitch_filters"] == []
    assert acquisition["remote_manifest"] == ROOT + "/" + bench.MANIFEST_FILENAME
    assert json.loads((output / "results.json").read_text()) == result


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "save_error",
        "missing_gpio23",
        "simulation",
        "helper_failed",
        "bad_receipt",
        "bool_exit",
    ],
)
def test_failures_retain_actual_exits_diagnostics_and_available_raw(
    monkeypatch, tmp_path, scenario
):
    fake = configure(monkeypatch, tmp_path, scenario)
    output = tmp_path / bench.CAPTURES[0]
    with pytest.raises((ValueError, RuntimeError)):
        collect(fake, output)
    result = json.loads((output / "results.json").read_text())
    acquisition = json.loads((output / "acquisition.json").read_text())
    assert result["collection_success"] is False and result["receipt_validation_error"]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    if scenario == "simulation":
        fake.runner.assert_not_called()
        assert acquisition["remote_returncode"] is None
    else:
        assert fake.events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
        assert (output / "digital_0.bin").is_file()
    if scenario in ("timeout", "interrupt"):
        assert acquisition["remote_returncode"] is None
        assert acquisition["ssh_exit_unavailable_after_exception"] is True
        assert (output / "remote.stdout").read_text() == "partial receipt"
        assert (output / "remote.stderr").read_text() == "partial actual diagnostic"
    if scenario == "helper_failed":
        assert acquisition["remote_returncode"] == 1


@pytest.mark.parametrize(
    "root,python",
    [("/tmp", PYTHON), (ROOT, "/usr/bin/python3"), (ROOT, PYTHON + ";unsafe")],
)
def test_invalid_remote_inputs_do_not_create_output_or_call_ssh(
    monkeypatch, tmp_path, root, python
):
    fake = configure(monkeypatch, tmp_path)
    output = tmp_path / bench.CAPTURES[0]
    with pytest.raises(ValueError):
        collect(fake, output, root, python)
    fake.runner.assert_not_called()
    fake.local.assert_not_called()
    assert not output.exists()


@pytest.mark.parametrize(
    "problem", ["existing", "symlink", "name", "manifest_digest", "plan_root"]
)
def test_exclusive_plan_bound_target_safeguards(monkeypatch, tmp_path, problem):
    fake = configure(monkeypatch, tmp_path)
    output = tmp_path / bench.CAPTURES[0]
    if problem == "existing":
        output.mkdir()
        (output / "keep").write_text("prior evidence")
    elif problem == "symlink":
        output.symlink_to(tmp_path, target_is_directory=True)
    elif problem == "name":
        output = tmp_path / "foreign_capture"
    else:
        fake.plan[
            "manifest_sha256" if problem == "manifest_digest" else "remote_root"
        ] = (
            "0" * 64
            if problem == "manifest_digest"
            else "/tmp/blinka-pwm-installed-consumers.def456"
        )
        fake.plan_path.write_text(json.dumps(fake.plan))
    with pytest.raises((ValueError, FileExistsError)):
        collect(fake, output)
    fake.runner.assert_not_called()
    if problem == "existing":
        assert (output / "keep").read_text() == "prior evidence"


def test_genuine_source_recording_receipt_validates_without_shim_conversion(receipt):
    actual, manifest = receipt
    bench.validate_remote(actual, manifest)
    assert bench.validate_local_manifest(manifest) == manifest["source_sha256"]
    assert "integration_shim" not in actual
    assert actual["installed_dispatch"]["real_pwmio_used"] is True
    assert actual["blinka_import_chip"]["events"][-1]["returncode"] == 0


@pytest.mark.parametrize(
    "problem",
    [
        "source",
        "helper_source",
        "source_path",
        "version",
        "shim",
        "dispatch",
        "board_id",
        "pin_class",
        "python",
        "isolated",
        "noninteractive",
        "inherited",
        "flag",
        "handle",
        "wrong_chip",
        "close_returncode",
        "extra_import_mutation",
        "hooks",
        "handle_late_open",
        "handle_early_close",
        "midpoint",
        "brake",
        "dwell",
        "action_index",
        "constructor",
        "extra_caller",
        "caller_scope",
        "private_request",
        "foreign_line",
        "released",
        "low",
        "deinit_event",
        "sibling",
        "thermal",
        "signal",
    ],
)
def test_explicit_installed_and_protocol_schema_rejects_changed_evidence(
    receipt, problem
):
    original, manifest = receipt
    actual = copy.deepcopy(original)
    if problem == "source":
        actual["source_sha256"]["pwmio.py"] = "0" * 64
    elif problem == "helper_source":
        actual["source_sha256"][bench.helper.NEW_SOURCE] = "0" * 64
    elif problem == "source_path":
        manifest = copy.deepcopy(manifest)
        manifest["source_paths"]["pwmio.py"] = "/usr/lib/python3/dist-packages/pwmio.py"
        actual["source_paths"] = manifest["source_paths"]
    elif problem == "version":
        actual["distribution_versions"]["Adafruit-Blinka"] = "foreign-version"
    elif problem == "shim":
        actual["integration_shim"] = {"kind": "in-memory-pwmio-export"}
    elif problem == "dispatch":
        actual["installed_dispatch"]["virtual_pwmio_export_used"] = True
    elif problem == "board_id":
        actual["installed_dispatch"]["board_id"] = "RASPBERRY_PI_5B"
    elif problem == "pin_class":
        actual["outputs"][0]["real_board_pin"]["class_module"] = "fake.Pin"
    elif problem == "python":
        actual["python_executable"] = "/usr/bin/python3"
    elif problem in ("isolated", "noninteractive"):
        actual[
            "isolated_python"
            if problem == "isolated"
            else "noninteractive_no_runtime_installs"
        ] = False
    elif problem == "inherited":
        actual["inherited_environment"]["BLINKA_FORCEBOARD"] = "RASPBERRY_PI_5"
    elif problem == "flag":
        actual["runtime_flags"]["shared"] = True
    elif problem == "handle":
        actual["blinka_import_chip"]["closed"] = False
    elif problem == "wrong_chip":
        actual["blinka_import_chip"]["events"][0]["chip_index"] += 1
    elif problem == "close_returncode":
        actual["blinka_import_chip"]["events"][1]["returncode"] = False
    elif problem == "extra_import_mutation":
        actual["blinka_import_chip"]["events"].append(
            {"operation": "gpio_write", "status": "rejected"}
        )
    elif problem == "hooks":
        actual["blinka_import_chip"]["hooks_restored"] = False
    elif problem == "handle_late_open":
        actual["blinka_import_chip"]["events"][0]["end_ns"] = (
            actual["phases"][0]["begin_ns"] + 1
        )
    elif problem == "handle_early_close":
        actual["blinka_import_chip"]["events"][1]["begin_ns"] = (
            actual["phases"][-1]["readback_end_ns"] - 1
        )
    elif problem == "midpoint":
        actual["actions"][1]["consumer_readback"] = 90
    elif problem == "brake":
        actual["phases"][7]["api_state"][0]["duty_u16"] = 0
    elif problem == "dwell":
        actual["phases"][1]["end_ns"] = actual["phases"][1]["stable_begin_ns"] + 1
    elif problem == "action_index":
        actual["actions"][0]["phase_index"] = 2
    elif problem == "constructor":
        next(e for e in actual["events"] if e["operation"] == "PWMOut.__init__")[
            "arguments"
        ]["variable_frequency"] = False
    elif problem == "extra_caller":
        extra = copy.deepcopy(actual["events"][-1])
        extra.update(ordinal=len(actual["events"]), operation="unexpected")
        actual["events"].append(extra)
    elif problem == "caller_scope":
        actual["events"][0]["scope"] = actual["phases"][1]["scope"]
    elif problem == "private_request":
        actual["outputs"][2]["owned_request"]["fd"] = actual["outputs"][1][
            "owned_request"
        ]["fd"]
    elif problem == "foreign_line":
        actual["preclaim_lines"][0]["line_info"]["used"] = True
    elif problem == "released":
        actual["outputs"][0]["released"] = False
    elif problem == "low":
        actual["outputs"][0]["cleanup_final_readback"]["gpio_level"] = 1
    elif problem == "deinit_event":
        next(e for e in actual["events"] if e["operation"] == "PWMOut.deinit")[
            "operation"
        ] = "foreign.close"
    elif problem == "sibling":
        actual["shutdowns"][1]["sibling_after"]["owned_request"]["fd"] += 1
    elif problem == "thermal":
        actual["after"]["throttled"] = "throttled=0x1"
    else:
        actual["signals_received"] = [15]
    with pytest.raises((ValueError, bench.helper.core.BenchError)):
        bench.validate_remote(actual, manifest)


def test_plan_semantics_and_loaded_method_source_hashes(receipt):
    _actual, manifest = receipt
    raw = json.dumps(manifest).encode()
    plan = plan_for(manifest, raw)
    bench.validate_plan(plan, manifest)
    for key, value in (
        ("collector_sha256", "0" * 64),
        ("preflight_receipt_sha256", "bad"),
        ("remote_python", "/usr/bin/python3"),
        ("runtime_flags", {"shared": True, "short_slice": False}),
        ("capture_order", list(reversed(bench.CAPTURES))),
    ):
        bad = copy.deepcopy(plan)
        bad[key] = value
        with pytest.raises(ValueError):
            bench.validate_plan(bad, manifest)
    sources = bench.source_hashes()
    assert sources[Path(bench.__file__).name] == bench.digest(bench.__file__)
    assert sources[bench.helper.NEW_SOURCE] == bench.HELPER_SHA256
    assert set(sources) == {
        "capture_installed_blinka_pwm_consumers.py",
        "capture_native_pwm_dual.py",
        "capture_native_pwm_half50.py",
        "capture_kernel_pwm_lgpio_baseline.py",
        "capture_pwm.py",
        "installed_blinka_pwm_consumers_eval.py",
        "native_pwm_consumers_eval.py",
        "native_pwm_dual_eval.py",
        "native_pwm_updates_eval.py",
        "native_pwm_half50_eval.py",
        "kernel_pwm_lgpio_baseline_eval.py",
        "kernel_pwm_eval.py",
    }
