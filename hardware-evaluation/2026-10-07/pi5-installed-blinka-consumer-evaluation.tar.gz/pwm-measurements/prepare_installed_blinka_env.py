"""Fixed private Pi5 build/install preparation; never import board or drive GPIO.

Each explicit stage preserves actual SSH stdout/stderr and exit status in fresh
files. No sudo, user-site/system installation, existing venv mutation or capture.
"""

import argparse
import datetime
import hashlib
import json
import shlex
import subprocess
from pathlib import Path

LAB = Path(__file__).resolve().parent
ROOT = "/tmp/blinka-pwm-installed-consumers.QmHr57"
PYTHON = ROOT + "/venv/bin/python"
STAGE = Path("/private/tmp/blinka-installed-prep.1XpM16")
BLINKA_COMMIT = "beb49bf8ea9305dacbd14b08525f234eda563c02"
PWM_COMMIT = "0e1c7cdafb141583948b795bc44a59cf57671d08"
BLINKA_VERSION = "9.0.5.dev74+pwmeval.beb49bf"
ARCHIVES = {
    "blinka-patched-source.tar.gz": "e3e4260736ae98ecec586b5694ecbde559864bfc8a1295f297feff3fd3f1c4af",
    "pwm-source.tar.gz": "94f5764edb8ab331ff6bcc128031b4b2a1af135e5d455d738881cd519597cf00",
}
STEPS = ("bootstrap", "build-tools", "local-wheels", "runtime-wheels", "install")
COMMON = f"""
import email,hashlib,json,pathlib,subprocess,sys,tarfile,zipfile
root=pathlib.Path({ROOT!r})
assert root.is_dir() and not root.is_symlink() and root.resolve()==root
python={PYTHON!r}
version={BLINKA_VERSION!r}
def run(args, **kwargs):
    subprocess.run(args, check=True, stdin=subprocess.DEVNULL, **kwargs)
def wheel_info(path):
    assert path.is_file() and not path.is_symlink() and path.resolve()==path
    with zipfile.ZipFile(path) as wheel:
        entries=wheel.namelist()
        assert len(entries)==len(set(entries))
        for entry in entries:
            p=pathlib.PurePosixPath(entry)
            assert not p.is_absolute() and '..' not in p.parts
            assert (wheel.getinfo(entry).external_attr >> 16) & 0o170000 != 0o120000
        names=[n for n in entries if n.endswith('.dist-info/METADATA')]
        assert len(names)==1
        meta=email.message_from_bytes(wheel.read(names[0]))
        tag=wheel.read(names[0].rsplit('/',1)[0]+'/WHEEL').decode()
        return {{'name':meta['Name'],'version':meta['Version'],
                'requires_dist':meta.get_all('Requires-Dist',[]),'wheel_metadata':tag,
                'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                'size_bytes':path.stat().st_size,'entries':entries,
                'path':str(path)}}
def local_wheels():
    wheels={{}}
    for path in sorted((root/'wheelhouse').glob('*.whl')):
        info=wheel_info(path)
        key=info['name'].lower().replace('_','-').replace('.','-')
        assert key not in wheels
        wheels[key]=info
    b=wheels['adafruit-blinka']; p=wheels['adafruit-blinka-raspberry-pi-pwm']
    assert b['version']==version and p['version']=='0.0.1.dev0'
    assert 'board.py' in b['entries'] and 'pwmio.py' in b['entries']
    assert all(n in b['entries'] for n in ('board_imports.json','microcontroller_imports.json'))
    assert 'Root-Is-Purelib: false' in p['wheel_metadata']
    assert 'cp313-cp313-linux_aarch64' in p['wheel_metadata']
    assert len([n for n in p['entries'] if n.startswith('adafruit_blinka_raspberry_pi_pwm/_native') and n.endswith('.so')])==1
    return wheels
def runtime_inputs(wheels):
    return [wheels['adafruit-blinka']['path'],wheels['adafruit-blinka-raspberry-pi-pwm']['path'],
            'adafruit-circuitpython-motor==3.5.0','gpiod==2.5.0',
            'adafruit-lgpio==0.2.2.0','Adafruit-Blinka-Raspberry-Pi5-Neopixel',
            'pytest==9.1.1']
"""
CODE = {
    "bootstrap": f"""
assert {{p.name for p in root.iterdir()}}=={set(ARCHIVES)!r}
for name,expected in {ARCHIVES!r}.items():
    path=root/name
    assert path.is_file() and not path.is_symlink()
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
    target=root/('blinka-source' if name.startswith('blinka') else 'pwm-source')
    target.mkdir()
    with tarfile.open(path,'r:gz') as archive:
        for member in archive.getmembers():
            p=pathlib.PurePosixPath(member.name)
            assert not p.is_absolute() and '..' not in p.parts
            assert member.isfile() or member.isdir()
        archive.extractall(target,filter='data')
assert hashlib.sha256((root/'blinka-source/src/pwmio.py').read_bytes()).hexdigest()=='e1527231dab797eef28b6f2acc2c08a1e404a3cb377cf387e23a71347b39e87d'
run(['/usr/bin/python3','-m','venv',str(root/'venv')])
(root/'wheelhouse').mkdir()
print(json.dumps({{'stage':'bootstrap','root':str(root),'no_gpio_import':True}}))
""",
    "build-tools": """
run([python,'-I','-m','pip','install','--no-input','--no-cache-dir',
     '--report',str(root/'build-tools-report.json'),'--log',str(root/'build-tools.log'),
     'setuptools==84.0.0','wheel==0.48.0','setuptools-scm==8.2.0'])
run([python,'-I','-m','pip','list','--format=json'])
""",
    "local-wheels": """
assert not list((root/'wheelhouse').iterdir())
run([python,'-I','-m','pip','wheel','--no-input','--no-cache-dir',
     '--no-deps','--no-build-isolation','--wheel-dir',str(root/'wheelhouse'),
     '--log',str(root/'native-wheel.log'),str(root/'pwm-source')])
import os
build_env=dict(os.environ)
build_env['SETUPTOOLS_SCM_PRETEND_VERSION_FOR_ADAFRUIT_BLINKA']=version
run([python,'-I','-m','pip','wheel','--no-input','--no-cache-dir',
     '--no-deps','--no-build-isolation','--wheel-dir',str(root/'wheelhouse'),
     '--log',str(root/'blinka-wheel.log'),str(root/'blinka-source')],env=build_env)
print(json.dumps(local_wheels(),indent=2))
""",
    "runtime-wheels": """
wheels=local_wheels()
assert len(wheels)==2
run([python,'-I','-m','pip','wheel','--no-input','--no-cache-dir',
     '--wheel-dir',str(root/'wheelhouse'),'--log',str(root/'runtime-wheels.log'),
     *runtime_inputs(wheels)])
print(json.dumps(local_wheels(),indent=2))
""",
    "install": """
wheels=local_wheels()
run([python,'-I','-m','pip','install','--no-input','--no-cache-dir','--no-index',
     '--find-links',str(root/'wheelhouse'),'--report',str(root/'runtime-install-report.json'),
     '--log',str(root/'runtime-install.log'),*runtime_inputs(wheels)])
run([python,'-I','-m','pip','check'])
run([python,'-I','-m','pip','list','--format=json'])
""",
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare(step):
    for name, expected in ARCHIVES.items():
        path = STAGE / name
        if not path.is_file() or path.is_symlink() or digest(path) != expected:
            raise ValueError("Exact local source archive required: " + name)
    for prior in STEPS[: STEPS.index(step)]:
        receipt = json.loads(
            (LAB / f"oct7-installed-blinka-env-{prior}.json").read_text()
        )
        if (
            receipt.get("accepted") is not True
            or type(receipt.get("ssh_returncode")) is not int
            or receipt["ssh_returncode"] != 0
            or receipt.get("preparer_sha256") != digest(__file__)
            or receipt.get("root") != ROOT
        ):
            raise ValueError("Unchanged successful prior preparation required")
    output = LAB / f"oct7-installed-blinka-env-{step}.json"
    stdout, stderr = Path(str(output) + ".stdout"), Path(str(output) + ".stderr")
    if any(p.exists() or p.is_symlink() for p in (output, stdout, stderr)):
        raise ValueError("Exclusive fresh preparation evidence required")
    code = COMMON + CODE[step]
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(["/usr/bin/python3", "-c", code]),
    ]
    result, error = None, None
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            result = subprocess.run(
                command, stdout=out, stderr=err, timeout=300, check=False
            )
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt) as failure:
            error = f"{type(failure).__name__}: {failure}"
    actual = (
        result.returncode
        if result is not None and type(result.returncode) is int
        else None
    )
    accepted = error is None and actual == 0
    receipt = {
        "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "step": step,
        "root": ROOT,
        "remote_python": PYTHON,
        "ssh_returncode": actual,
        "accepted": accepted,
        "error": error,
        "preparer_sha256": digest(__file__),
        "source_archives": ARCHIVES,
        "blinka_source_commit": BLINKA_COMMIT,
        "pwm_source_commit": PWM_COMMIT,
        "test_only_blinka_version": BLINKA_VERSION,
        "remote_command": command,
        "remote_code": code,
        "stdout_sha256": digest(stdout),
        "stderr_sha256": digest(stderr),
        "scope": "Private source build/install only; no board/pwmio import or GPIO requests",
    }
    with output.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                "step": step,
                "accepted": accepted,
                "ssh_returncode": actual,
                "error": error,
            }
        )
    )
    return 0 if accepted else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("step", choices=STEPS)
    raise SystemExit(prepare(parser.parse_args().step))
