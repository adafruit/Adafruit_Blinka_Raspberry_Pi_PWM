"""Pure checkpoint gates with temporary fake bytes; no real checkpoint/replay."""

import ast
import io
import json
from pathlib import Path
from types import SimpleNamespace

import checkpoint_installed_blinka_consumers as checkpoint
import pytest


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(
        value if isinstance(value, bytes) else (json.dumps(value) + "\n").encode()
    )
    return checkpoint.digest(path)


@pytest.fixture
def inputs(tmp_path, monkeypatch):
    lab, prep = tmp_path / "pwm-measurements", tmp_path / "prep"
    lab.mkdir()
    prep.mkdir()
    sources = {}
    for name in checkpoint.METHODS:
        sources["pwm-measurements/" + name] = save(
            lab / name, ("# fake method " + name).encode()
        )
    for name in checkpoint.DATA_NAMES:
        save(lab / name, b"fake preserved evidence\n")
    native = (
        tmp_path
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src/adafruit_blinka_raspberry_pi_pwm"
    )
    manifest = {"schema_version": 1, "source_sha256": {}}
    for name in checkpoint.NATIVE_FILES:
        value = save(native / name, ("# fake selected native " + name).encode())
        sources[checkpoint.NATIVE_PREFIX + name] = value
        manifest["source_sha256"]["adafruit_blinka_raspberry_pi_pwm/" + name] = value
    sources[checkpoint.INTEGRATION_PATCH] = save(
        tmp_path / checkpoint.INTEGRATION_PATCH, b"fake integration patch\n"
    )
    consumer = tmp_path / "site-packages"
    for name in checkpoint.CONSUMER_FILES:
        value = save(consumer / name, ("# fake selected consumer " + name).encode())
        sources["consumer-library-source/" + name] = value
        manifest["source_sha256"][name] = value
    monkeypatch.setattr(
        checkpoint.importlib.metadata,
        "distribution",
        lambda name: SimpleNamespace(
            version="3.5.0", locate_file=lambda key: consumer / key
        ),
    )
    manifest_sha = save(lab / checkpoint.MANIFEST_NAME, manifest)
    plan = {
        "capture_order": list(checkpoint.CAPTURES),
        "manifest_sha256": manifest_sha,
        "preflight_receipt_sha256": checkpoint.digest(
            lab / "oct7-installed-blinka-consumers-preflight.json"
        ),
        "helper_sha256": sources[
            "pwm-measurements/installed_blinka_pwm_consumers_eval.py"
        ],
        "collector_sha256": sources[
            "pwm-measurements/capture_installed_blinka_pwm_consumers.py"
        ],
    }
    plan_sha = save(lab / checkpoint.PLAN_NAME, plan)
    for capture in checkpoint.CAPTURES:
        for name in checkpoint.CAPTURE_FILES:
            save(lab / capture / name, ("fake capture bytes " + name).encode())
    for name in checkpoint.PREP_ARCHIVES:
        save(prep / name, ("fake opaque source archive " + name).encode())
    for name in checkpoint.PREP_LOGS:
        save(
            prep / "remote-install-receipts" / name,
            ("fake saved build log " + name).encode(),
        )
    for index in range(23):
        save(
            prep / "wheelhouse" / f"fake-wheel-{index}.whl",
            ("fake opaque wheel " + str(index)).encode(),
        )
    plan["wheel_artifacts"] = {
        path.name: {
            "sha256": checkpoint.digest(path),
            "size_bytes": path.stat().st_size,
        }
        for path in (prep / "wheelhouse").iterdir()
    }
    plan_sha = save(lab / checkpoint.PLAN_NAME, plan)
    save(
        lab / "oct7-installed-blinka-env-bootstrap.json",
        {
            "accepted": True,
            "ssh_returncode": 0,
            "source_archives": {
                name: checkpoint.digest(prep / name)
                for name in ("blinka-patched-source.tar.gz", "pwm-source.tar.gz")
            },
        },
    )
    extras = {}
    for name in checkpoint.AUDIT_ARTIFACTS:
        extras[name] = save(lab / name, b"fake immutable independent artifact\n")
    audit_source = tmp_path / "independent-method.py"
    audit_sha = save(audit_source, b"# fake immutable independent method\n")
    pins = {
        "schema_version": 1,
        "plan_sha256": plan_sha,
        "source_sha256": sources,
        "extra_lab_sha256": extras,
        "audit_sources": {
            "audit-source/method.py": {"path": str(audit_source), "sha256": audit_sha}
        },
    }
    path = tmp_path / "input-pins.json"
    save(path, pins)
    return SimpleNamespace(
        lab=lab,
        prep=prep,
        path=path,
        pins=pins,
        plan=plan,
        manifest=manifest,
        audit_source=audit_source,
    )


def test_enumerated_complete_inventory_all_methods_wheels_reports_and_receipts(inputs):
    files, pins = checkpoint.build_inventory(inputs.lab, inputs.prep, inputs.path)
    assert pins == inputs.pins
    assert len(files) == len(set(files))
    assert all(
        "pwm-measurements/" + name in files
        for name in checkpoint.METHODS + checkpoint.DATA_NAMES
    )
    assert "checkpoint-input-pins.json" in files
    assert "audit-source/method.py" in files
    assert checkpoint.INTEGRATION_PATCH in files
    assert (
        sum(name.startswith("installation-preparation/wheelhouse/") for name in files)
        == 23
    )
    assert all(
        "installation-preparation/" + name in files for name in checkpoint.PREP_ARCHIVES
    )
    assert all(
        "installation-preparation/remote-install-receipts/" + name in files
        for name in checkpoint.PREP_LOGS
    )
    for capture in checkpoint.CAPTURES:
        assert all(
            "pwm-measurements/" + capture + "/" + name in files
            for name in checkpoint.CAPTURE_FILES
        )
    for stem in (
        "oct7-installed-blinka-import-probe",
        "oct7-installed-blinka-import-probe-r2",
        "oct7-lgpio-consumers-loaded-paired-postflight",
    ):
        assert all(
            "pwm-measurements/" + stem + ".json" + suffix in files
            for suffix in ("", ".stdout", ".stderr")
        )


@pytest.mark.parametrize(
    "problem",
    [
        "plan_pin",
        "method",
        "native",
        "consumer",
        "patch",
        "audit",
        "missing_wheel",
        "extra_wheel",
        "wheel_hash",
        "wheel_size",
        "bootstrap_rejected",
        "source_archive",
        "missing_log",
        "extra_log",
        "missing_report",
        "extra_artifact",
        "missing_source_pin",
    ],
)
def test_changed_missing_or_additional_frozen_inputs_rejected(inputs, problem):
    if problem == "plan_pin":
        inputs.pins["plan_sha256"] = "0" * 64
    elif problem == "method":
        save(inputs.lab / checkpoint.METHODS[0], b"changed method")
    elif problem in ("native", "consumer"):
        key = (
            checkpoint.NATIVE_PREFIX + "__init__.py"
            if problem == "native"
            else "consumer-library-source/adafruit_motor/servo.py"
        )
        inputs.pins["source_sha256"][key] = "0" * 64
    elif problem == "audit":
        save(inputs.audit_source, b"changed independent method")
    elif problem == "patch":
        save(inputs.lab.parent / checkpoint.INTEGRATION_PATCH, b"changed patch")
    elif problem == "missing_wheel":
        (inputs.prep / "wheelhouse/fake-wheel-0.whl").unlink()
    elif problem == "extra_wheel":
        save(inputs.prep / "wheelhouse/extra.whl", b"extra wheel")
    elif problem == "wheel_hash":
        target = inputs.prep / "wheelhouse/fake-wheel-0.whl"
        save(target, b"x" * target.stat().st_size)
    elif problem == "wheel_size":
        save(inputs.prep / "wheelhouse/fake-wheel-0.whl", b"changed-size")
    elif problem == "bootstrap_rejected":
        target = inputs.lab / "oct7-installed-blinka-env-bootstrap.json"
        receipt = json.loads(target.read_text())
        receipt["accepted"] = False
        save(target, receipt)
    elif problem == "source_archive":
        save(inputs.prep / "pwm-source.tar.gz", b"changed source archive")
    elif problem == "missing_log":
        (inputs.prep / "remote-install-receipts" / checkpoint.PREP_LOGS[0]).unlink()
    elif problem == "extra_log":
        save(inputs.prep / "remote-install-receipts/extra.log", b"extra log")
    elif problem == "missing_report":
        (inputs.lab / checkpoint.CAPTURES[0] / checkpoint.REPORT_NAME).unlink()
    elif problem == "extra_artifact":
        inputs.pins["extra_lab_sha256"]["../../old-evidence"] = "a" * 64
    elif problem == "missing_source_pin":
        del inputs.pins["source_sha256"]["pwm-measurements/" + checkpoint.METHODS[0]]
    save(inputs.path, inputs.pins)
    with pytest.raises(ValueError):
        checkpoint.build_inventory(inputs.lab, inputs.prep, inputs.path)


@pytest.mark.parametrize(
    "which", ["source_sha256", "extra_lab_sha256", "audit_sources"]
)
def test_pending_pins_gate_requires_complete_freeze(inputs, which):
    inputs.pins[which] = {}
    with pytest.raises(ValueError):
        checkpoint.validate_pins(inputs.pins)


def test_duplicate_json_keys_are_not_silently_collapsed():
    with pytest.raises(ValueError, match="Duplicate JSON"):
        checkpoint.read_json_bytes(b'{"schema_version":1,"schema_version":1}')


@pytest.mark.parametrize(
    "name",
    [
        "",
        "/absolute",
        "../outside",
        "a/../b",
        "a/./b",
        "a//b",
        "a\\b",
        "C:/windows",
        "a\x00b",
    ],
)
def test_unsafe_member_names_refused(name):
    with pytest.raises(ValueError, match="Unsafe member"):
        checkpoint.safe_name(name)


def test_regular_sources_and_directory_parents_refuse_links(tmp_path):
    real = tmp_path / "real"
    real.mkdir()
    source = real / "file"
    source.write_bytes(b"fake")
    link = tmp_path / "link"
    link.symlink_to(source)
    with pytest.raises(ValueError, match="linked"):
        checkpoint.file_bytes(link)
    parent_link = tmp_path / "parent-link"
    parent_link.symlink_to(real, target_is_directory=True)
    with pytest.raises(ValueError, match="linked"):
        checkpoint.file_bytes(parent_link / "file")
    with pytest.raises(ValueError, match="linked"):
        checkpoint.directory(parent_link)


def test_normal_venv_interpreter_link_preserves_venv_path(tmp_path):
    actual = tmp_path / "python-real"
    actual.write_bytes(b"fake executable, never run\n")
    actual.chmod(0o755)
    linked = tmp_path / "python"
    linked.symlink_to(actual)
    assert checkpoint.interpreter(linked) == linked


def test_fake_archive_exact_bytes_and_exclusive_output_only(tmp_path):
    source, other = tmp_path / "source", tmp_path / "other"
    source.write_bytes(b"fake waveform bytes")
    other.write_bytes(b"")
    files = {
        "pwm-measurements/fake/digital_0.bin": (source, checkpoint.digest(source)),
        "pwm-measurements/fake/remote.stderr": (other, checkpoint.digest(other)),
    }
    archive = tmp_path / "fake.tar.gz"
    checkpoint.write_archive(archive, files)
    before = checkpoint.digest(archive)
    recovered = tmp_path / "recovered"
    recovered.mkdir()
    assert checkpoint.safe_extract(archive, recovered) == {
        name: expected for name, (_path, expected) in files.items()
    }
    with pytest.raises(ValueError, match="fresh archive"):
        checkpoint.write_archive(archive, files)
    assert checkpoint.digest(archive) == before
    with pytest.raises(ValueError, match="Fresh empty"):
        checkpoint.safe_extract(archive, recovered)


@pytest.mark.parametrize(
    "problem",
    [
        "absolute",
        "traversal",
        "duplicate",
        "symlink",
        "hardlink",
        "directory",
        "fifo",
        "prefix_collision",
    ],
)
def test_archive_full_member_validation_precedes_any_extraction(tmp_path, problem):
    path = tmp_path / "unsafe.tar.gz"
    with checkpoint.tarfile.open(path, "w:gz") as archive:
        good = checkpoint.tarfile.TarInfo("good")
        good.size = 4
        archive.addfile(good, io.BytesIO(b"fake"))
        bad = checkpoint.tarfile.TarInfo(
            {
                "absolute": "/bad",
                "traversal": "../bad",
                "duplicate": "good",
                "prefix_collision": "good/child",
            }.get(problem, "bad")
        )
        if problem == "symlink":
            bad.type, bad.linkname = checkpoint.tarfile.SYMTYPE, "good"
        elif problem == "hardlink":
            bad.type, bad.linkname = checkpoint.tarfile.LNKTYPE, "good"
        elif problem == "directory":
            bad.type = checkpoint.tarfile.DIRTYPE
        elif problem == "fifo":
            bad.type = checkpoint.tarfile.FIFOTYPE
        archive.addfile(bad)
    output = tmp_path / "empty"
    output.mkdir()
    with pytest.raises(ValueError):
        checkpoint.safe_extract(path, output)
    assert list(output.iterdir()) == []


def test_source_changed_during_archive_stops_and_preserves_partial_output(tmp_path):
    source = tmp_path / "source"
    source.write_bytes(b"initial fake source")
    files = {"method.py": (source, checkpoint.digest(source))}
    source.write_bytes(b"changed fake source")
    archive = tmp_path / "partial.tar.gz"
    with pytest.raises(ValueError, match="changed during archive"):
        checkpoint.write_archive(archive, files)
    assert archive.exists()
    assert source.read_bytes() == b"changed fake source"


def test_isolated_replay_source_is_exact_comparison_without_fact_adjustments():
    tree = ast.parse(checkpoint.REPLAY)
    assert not any(isinstance(node, ast.Delete) for node in ast.walk(tree))
    assert "analysis.analyze(lab/name,plan)" in checkpoint.REPLAY
    assert "assert reproduced==saved,name" in checkpoint.REPLAY
    assert "installed-consumer-analysis.json" in checkpoint.REPLAY
    assert all(
        word not in checkpoint.REPLAY
        for word in (
            "Manager.connect",
            "capture_test(",
            "request_lines(",
            "gpio_write(",
            "pip install",
            "monkeypatch",
        )
    )


def test_no_execution_gate_does_not_read_input_or_create_anything(
    tmp_path, monkeypatch
):
    monkeypatch.setattr(
        checkpoint,
        "build_inventory",
        lambda *_args: pytest.fail("Not authorized to read future reports"),
    )
    args = [
        "--input-pins",
        str(tmp_path / "future-pins.json"),
        "--archive",
        str(tmp_path / checkpoint.ARCHIVE_NAME),
        "--verification",
        str(tmp_path / checkpoint.VERIFICATION_NAME),
    ]
    before = list(tmp_path.iterdir())
    with pytest.raises(ValueError, match="authorization required"):
        checkpoint.main(args)
    assert list(tmp_path.iterdir()) == before


def test_replay_call_is_isolated_and_mocked_not_executed(tmp_path, monkeypatch):
    source = tmp_path / "source"
    source.write_bytes(b"fake evidence")
    files = {"evidence": (source, checkpoint.digest(source))}
    archive = tmp_path / "fake.tar.gz"
    checkpoint.write_archive(archive, files)
    calls = []

    def run(command, **kwargs):
        calls.append((command, kwargs))
        assert command[1:4] == ["-I", "-c", checkpoint.REPLAY]
        assert kwargs["check"] is True and kwargs["timeout"] == 60
        return SimpleNamespace(
            stdout=json.dumps(
                {
                    "installed_reports_reproduced": 2,
                    "all_report_json_facts_exact": True,
                    "fact_or_path_adjustments_used": False,
                }
            ),
            stderr="fake preserved offline diagnostic",
        )

    monkeypatch.setattr(checkpoint.subprocess, "run", run)
    # Keep even the mocked replay's fresh extraction inside the test fixture.
    monkeypatch.setattr(
        checkpoint.tempfile, "mkdtemp", lambda **_kwargs: str(tmp_path / "extracted")
    )
    (tmp_path / "extracted").mkdir()
    extracted, result, stderr = checkpoint.verify_archive(
        archive, files, Path("/fake/not-executed/python")
    )
    assert len(calls) == 1
    assert extracted == tmp_path / "extracted"
    assert result["installed_reports_reproduced"] == 2
    assert stderr == "fake preserved offline diagnostic"
