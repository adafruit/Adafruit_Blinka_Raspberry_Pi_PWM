"""Fully offline installed-state fakes; no GPIO, SSH or Saleae is invoked."""

import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
import record_installed_blinka_state as state


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value) + "\n")
    return state.digest(path)


@pytest.fixture
def environment(tmp_path, monkeypatch):
    monkeypatch.setattr(state, "LAB", tmp_path)
    hashes = {
        **state.helper.FROZEN_PINS,
        **state.helper.RUNTIME_PINS,
        state.helper.NEW_SOURCE: state.digest(state.helper.__file__),
    }
    manifest = {
        "schema_version": 1,
        "source_sha256": hashes,
        "source_paths": {
            key: state.ROOT
            + (
                "/"
                if key.endswith("_eval.py")
                else "/venv/lib/python3.13/site-packages/"
            )
            + key
            for key in hashes
        },
        "distribution_versions": state.helper.DISTRIBUTION_VERSIONS,
    }
    manifest_path = tmp_path / "oct7-installed-blinka-consumers-manifest.json"
    manifest_sha = save(manifest_path, manifest)
    pids = list(range(1001, 1121))
    prior = {"accepted": True, "ssh_returncode": 0, "inspected_pids": pids}
    monkeypatch.setattr(state, "PRIOR_SHA256", save(tmp_path / state.PRIOR_NAME, prior))
    collector = SimpleNamespace(
        __file__=state.helper.__file__,
        validate_local_manifest=MagicMock(),
        validate_remote=MagicMock(),
    )
    monkeypatch.setattr(
        state, "importlib", SimpleNamespace(import_module=lambda name: collector)
    )
    plan = {
        "remote_root": state.ROOT,
        "remote_python": state.PYTHON,
        "capture_order": list(state.CAPTURES),
        "manifest_sha256": manifest_sha,
        "prior_postflight_sha256": state.PRIOR_SHA256,
        "state_recorder_sha256": state.digest(state.__file__),
        "collector_sha256": state.digest(collector.__file__),
    }
    plan_path = tmp_path / "state-plan.json"
    save(plan_path, plan)
    reply = {
        "read_only": True,
        "no_gpio_request_or_write": True,
        "board_or_pwmio_imported": False,
        "hostname": "test-pi5",
        "kernel": state.helper.dual.base.baseline.KERNEL,
        "boot_id": state.frozen.BOOT_ID,
        "boot_config_sha256": state.frozen.BOOT_SHA,
        "manifest": manifest,
        "manifest_sha256": manifest_sha,
        "source_sha256": manifest["source_sha256"],
        "source_paths": manifest["source_paths"],
        "distribution_versions": manifest["distribution_versions"],
        "program_path": state.ROOT + "/" + state.helper.NEW_SOURCE,
        "runtime": {
            "python_executable": state.PYTHON,
            "isolated": True,
            "python_version": "fake3.13.5",
        },
        "identity": {
            "gpiochip": "/dev/gpiochip0",
            "gpiochip_index": 0,
            "gpiochip_device_number": "254:0",
            "of_node": state.OF_NODE,
            "compatible": ["raspberrypi,rp1-gpio"],
            "label": "pinctrl-rp1",
            "boot_id": state.frozen.BOOT_ID,
            "kernel_release": state.helper.dual.base.baseline.KERNEL,
        },
        "pid_exists": {str(pid): False for pid in pids},
        "gpiochip": {"name": "gpiochip0", "label": "pinctrl-rp1", "num_lines": 54},
        "lines": [
            {"offset": gpio, "used": False, "consumer": None, "direction": "OUTPUT"}
            for gpio in (18, 23)
        ],
        "pinctrl": [
            {
                "arguments": ["pinctrl", "get", str(gpio)],
                "returncode": 0,
                "stdout": f"{gpio}: op -- | lo\n",
            }
            for gpio in (18, 23)
        ],
        "temperature_millic": "48000",
        "throttled": {"returncode": 0, "stdout": "throttled=0x0\n"},
        "pwm": {
            "returncode": 0,
            "stdout": "0: platform/1f0009c000.pwm, 4 PWM devices\n pwm-3 (cooling_fan): requested enabled period: 41566 ns duty: 12225 ns polarity: inverse usage_power\n",
        },
    }
    calls = []

    def run(command, *, stdout, stderr, timeout, check):
        calls.append(command)
        executable, isolated, option, code = shlex.split(command[-1])
        assert (executable, isolated, option) == (state.PYTHON, "-I", "-c")
        compile(code, "read-only-installed-fake", "exec")
        assert timeout == 20 and check is False
        assert "PIDS" not in code and "request_lines(" not in code
        assert "import board" not in code and "import pwmio" not in code
        assert "tx_pwm(" not in code and "gpio_write(" not in code
        assert "root / " + repr(state.MANIFEST_NAME) in code
        stdout.write(json.dumps(reply).encode())
        stderr.write(b"retained read-only diagnostic\n")
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(
        state,
        "subprocess",
        SimpleNamespace(run=run, TimeoutExpired=subprocess.TimeoutExpired),
    )
    return SimpleNamespace(
        path=tmp_path,
        manifest=manifest,
        manifest_path=manifest_path,
        manifest_sha=manifest_sha,
        plan=plan,
        plan_path=plan_path,
        pids=pids,
        reply=reply,
        collector=collector,
        calls=calls,
        run=run,
    )


def output(environment, stage="preflight"):
    return environment.path / f"oct7-installed-blinka-consumers-{stage}.json"


def captures(environment):
    for index, name in enumerate(state.CAPTURES):
        pid = 2001 + index
        remote = {"helper_pid": pid, "manifest_path": state.REMOTE_MANIFEST}
        result = {
            "collection_success": True,
            "remote": remote,
            "remote_returncode": 0,
            "source_manifest": environment.manifest,
            "collector_sha256": state.digest(environment.collector.__file__),
            "manifest_sha256": environment.manifest_sha,
        }
        acquisition = {
            "remote_root": state.ROOT,
            "remote_python": state.PYTHON,
            "remote_returncode": 0,
            "primary_error": None,
            "evidence_errors": [],
            "manifest_sha256": environment.manifest_sha,
            "remote_command": [
                "ssh",
                "-o",
                "BatchMode=yes",
                "-o",
                "ConnectTimeout=8",
                "pi@test-pi5.local",
                shlex.join(
                    [
                        state.PYTHON,
                        "-I",
                        state.ROOT + "/" + state.helper.NEW_SOURCE,
                        "--manifest",
                        state.REMOTE_MANIFEST,
                    ]
                ),
            ],
        }
        for filename, value in (
            ("remote.stdout", remote),
            ("results.json", result),
            ("acquisition.json", acquisition),
        ):
            save(environment.path / name / filename, value)
        environment.reply["pid_exists"][str(pid)] = False


def test_preflight_exact_120_pids_inventory_and_actual_exit(environment):
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 0
    )
    receipt = json.loads(output(environment).read_text())
    assert receipt["accepted"] is True and type(receipt["ssh_returncode"]) is int
    assert (
        receipt["ssh_returncode"] == 0 and receipt["inspected_pids"] == environment.pids
    )
    assert not receipt["capture_receipts"] and len(environment.calls) == 1
    assert receipt["manifest"] == environment.manifest
    assert (
        Path(str(output(environment)) + ".stderr")
        .read_bytes()
        .endswith(b"diagnostic\n")
    )


def test_postflight_adds_two_actual_validated_capture_pids(environment):
    captures(environment)
    assert (
        state.record("postflight", environment.plan_path, environment.manifest_path)
        == 0
    )
    receipt = json.loads(output(environment, "postflight").read_text())
    assert receipt["inspected_pids"] == environment.pids + [2001, 2002]
    assert list(receipt["capture_receipts"]) == list(state.CAPTURES)
    assert environment.collector.validate_remote.call_count == 2


@pytest.mark.parametrize(
    "field,value",
    [
        ("read_only", False),
        ("no_gpio_request_or_write", False),
        ("board_or_pwmio_imported", True),
        ("hostname", "test2-pi4"),
        ("kernel", "other"),
        ("boot_id", "different"),
        ("boot_config_sha256", "b" * 64),
        ("manifest", {}),
        ("manifest_sha256", "b" * 64),
        ("source_sha256", {}),
        ("source_paths", {}),
        ("distribution_versions", {}),
        ("program_path", "/tmp/other.py"),
        ("pid_exists", {}),
    ],
)
def test_reject_changed_identity_inventory_or_process_proof(environment, field, value):
    environment.reply[field] = value
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 1
    )
    assert json.loads(output(environment).read_text())["accepted"] is False


@pytest.mark.parametrize(
    "section,field,value",
    [
        ("runtime", "python_executable", "/usr/bin/python3"),
        ("runtime", "isolated", False),
        ("identity", "gpiochip_index", False),
        ("identity", "gpiochip", "/dev/gpiochip4"),
        ("identity", "gpiochip_device_number", "254:4"),
        ("identity", "of_node", "/sys/other"),
        ("identity", "compatible", ["other"]),
        ("identity", "label", "other"),
        ("gpiochip", "num_lines", 55),
        ("throttled", "returncode", False),
        ("throttled", "stdout", "throttled=0x50000"),
        ("pwm", "returncode", False),
        ("pwm", "stdout", "0: platform/1f00098000.pwm, 4 PWM devices\n"),
    ],
)
def test_reject_changed_nested_gate(environment, section, field, value):
    environment.reply[section][field] = value
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 1
    )


@pytest.mark.parametrize(
    "field,value",
    [("offset", 19), ("used", True), ("consumer", "other"), ("direction", "INPUT")],
)
def test_pins_must_be_exact_free_outputs(environment, field, value):
    environment.reply["lines"][0][field] = value
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 1
    )


@pytest.mark.parametrize(
    "value", ["18: op -- | hi\n", "18: ip -- | lo\n", "23: op -- | lo\n"]
)
def test_pinctrl_output_and_pin_identity_low_required(environment, value):
    environment.reply["pinctrl"][0]["stdout"] = value
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 1
    )


@pytest.mark.parametrize(
    "stage,temp,accepted",
    [
        ("preflight", "64999", True),
        ("preflight", "65000", False),
        ("postflight", "69999", True),
        ("postflight", "70000", False),
        ("preflight", "nan", False),
        ("preflight", 48000, False),
    ],
)
def test_distinct_pre_and_post_thermal_limits(environment, stage, temp, accepted):
    if stage == "postflight":
        captures(environment)
    environment.reply["temperature_millic"] = temp
    assert state.record(stage, environment.plan_path, environment.manifest_path) == (
        0 if accepted else 1
    )


def test_automatic_fan_duty_change_is_allowed(environment):
    environment.reply["pwm"]["stdout"] = (
        environment.reply["pwm"]["stdout"]
        .replace("12225", "0")
        .replace("requested enabled", "requested")
    )
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 0
    )


@pytest.mark.parametrize(
    "suffix", ["\n1: pwm-gpio, 1 PWM device\n", "\n pwm-0 (other): requested enabled\n"]
)
def test_additional_pwm_provider_or_requested_consumer_rejected(environment, suffix):
    environment.reply["pwm"]["stdout"] += suffix
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 1
    )


@pytest.mark.parametrize("value", [False, None, 1])
def test_actual_ssh_exit_must_be_typed_integer_zero(environment, monkeypatch, value):
    def run(*args, **kwargs):
        environment.run(*args, **kwargs)
        return SimpleNamespace(returncode=value)

    monkeypatch.setattr(state.subprocess, "run", run)
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 1
    )
    receipt = json.loads(output(environment).read_text())
    assert receipt["ssh_returncode"] == (value if type(value) is int else None)
    assert receipt["accepted"] is False


def test_timeout_preserves_outputs_and_records_no_actual_exit(environment, monkeypatch):
    def run(*args, **kwargs):
        kwargs["stdout"].write(b"partial read-only query\n")
        raise subprocess.TimeoutExpired("fake-ssh", 20)

    monkeypatch.setattr(state.subprocess, "run", run)
    assert (
        state.record("preflight", environment.plan_path, environment.manifest_path) == 1
    )
    receipt = json.loads(output(environment).read_text())
    assert (
        receipt["ssh_returncode"] is None
        and "TimeoutExpired" in receipt["validation_error"]
    )
    assert (
        Path(str(output(environment)) + ".stdout").read_bytes()
        == b"partial read-only query\n"
    )


@pytest.mark.parametrize(
    "field,value",
    [
        ("remote_root", "/tmp/other"),
        ("remote_python", "/usr/bin/python3"),
        ("capture_order", []),
        ("manifest_sha256", "b" * 64),
        ("prior_postflight_sha256", "b" * 64),
        ("state_recorder_sha256", "b" * 64),
    ],
)
def test_changed_plan_blocks_before_ssh(environment, field, value):
    environment.plan[field] = value
    save(environment.plan_path, environment.plan)
    with pytest.raises(ValueError):
        state.record("preflight", environment.plan_path, environment.manifest_path)
    assert not environment.calls


def test_prior_receipt_bytes_cannot_change(environment):
    path = environment.path / state.PRIOR_NAME
    prior = json.loads(path.read_text())
    prior["accepted"] = False
    save(path, prior)
    with pytest.raises(ValueError):
        state.record("preflight", environment.plan_path, environment.manifest_path)
    assert not environment.calls


@pytest.mark.parametrize(
    "which,field,value",
    [
        ("results.json", "remote_returncode", False),
        ("acquisition.json", "remote_returncode", None),
        ("acquisition.json", "remote_python", "/usr/bin/python3"),
        ("acquisition.json", "evidence_errors", ["failure"]),
        ("results.json", "collection_success", False),
        ("acquisition.json", "remote_command", []),
        ("acquisition.json", "manifest_sha256", "b" * 64),
        ("results.json", "manifest_sha256", "b" * 64),
        ("results.json", "source_manifest", {}),
        ("results.json", "collector_sha256", "b" * 64),
    ],
)
def test_invalid_capture_linkage_blocks_postflight(environment, which, field, value):
    captures(environment)
    path = environment.path / state.CAPTURES[0] / which
    receipt = json.loads(path.read_text())
    receipt[field] = value
    save(path, receipt)
    with pytest.raises(ValueError):
        state.record("postflight", environment.plan_path, environment.manifest_path)
    assert not environment.calls


def test_collector_source_plan_mismatch_blocks_postflight(environment):
    captures(environment)
    environment.plan["collector_sha256"] = "b" * 64
    save(environment.plan_path, environment.plan)
    with pytest.raises(ValueError):
        state.record("postflight", environment.plan_path, environment.manifest_path)
    assert not environment.calls


def test_generic_manifest_filename_rejected_before_postflight_ssh(environment):
    captures(environment)
    directory = environment.path / state.CAPTURES[0]
    remote = json.loads((directory / "remote.stdout").read_text())
    remote["manifest_path"] = state.ROOT + "/manifest.json"
    save(directory / "remote.stdout", remote)
    result = json.loads((directory / "results.json").read_text())
    result["remote"] = remote
    save(directory / "results.json", result)
    with pytest.raises(ValueError):
        state.record("postflight", environment.plan_path, environment.manifest_path)
    assert not environment.calls


def test_existing_or_symlink_target_never_overwritten(environment):
    destination = output(environment)
    destination.write_text("keep existing")
    with pytest.raises(ValueError):
        state.record("preflight", environment.plan_path, environment.manifest_path)
    assert destination.read_text() == "keep existing" and not environment.calls


def test_unknown_runtime_pins_fail_closed_before_ssh(environment, monkeypatch):
    monkeypatch.setattr(state.helper, "RUNTIME_PINS", None)
    with pytest.raises(state.helper.core.BenchError):
        state.record("preflight", environment.plan_path, environment.manifest_path)
    assert not environment.calls
