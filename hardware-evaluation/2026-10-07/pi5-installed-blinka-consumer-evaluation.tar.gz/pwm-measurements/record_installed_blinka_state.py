"""Fixed read-only installed-Blinka pre/postflight; never imports board/pwmio.

Only GPIO chip/line metadata is read. The installed package inventory and every
known completed helper/load PID are checked independently of waveform results.
"""

import argparse
import hashlib
import importlib
import json
import re
import shlex
import subprocess
from pathlib import Path

import installed_blinka_pwm_consumers_eval as helper
import record_native_updates_postflight as frozen

LAB = Path(__file__).resolve().parent
ROOT = "/tmp/blinka-pwm-installed-consumers.QmHr57"
PYTHON = ROOT + "/venv/bin/python"
MANIFEST_NAME = "oct7-installed-blinka-consumers-manifest.json"
REMOTE_MANIFEST = ROOT + "/" + MANIFEST_NAME
PRIOR_NAME = "oct7-lgpio-consumers-loaded-paired-postflight.json"
PRIOR_SHA256 = "e9ec4230b7fc36585fa9e9d2d664df88d2b29042fa647b068821975ff31ce0f2"
FROZEN_QUERY_SHA256 = "850e4d5e3bf7b5e84675ad410cb8ec862a067ee6c44f9582d9b95981575d015a"
CAPTURES = (
    "oct7-pi5-installed-blinka-consumers-r1",
    "oct7-pi5-installed-blinka-consumers-r2",
)
OF_NODE = "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/gpio@d0000"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    path = Path(path)
    require(
        path.is_file() and not path.is_symlink(), "Regular nonsymlink evidence required"
    )
    return json.loads(path.read_text())


def inputs(stage, plan_path, manifest_path):
    require(stage in ("preflight", "postflight"), "Fixed installed stage required")
    require(
        digest(frozen.__file__) == FROZEN_QUERY_SHA256,
        "Frozen read-only query source changed",
    )
    plan, manifest = read(plan_path), read(manifest_path)
    helper.validate_manifest(manifest)
    require(
        manifest["source_sha256"][helper.NEW_SOURCE] == digest(helper.__file__),
        "Local and selected installed helper source differ",
    )
    expected = {
        "remote_root": ROOT,
        "remote_python": PYTHON,
        "capture_order": list(CAPTURES),
        "manifest_sha256": digest(manifest_path),
        "prior_postflight_sha256": PRIOR_SHA256,
        "state_recorder_sha256": digest(__file__),
    }
    require(
        all(plan.get(key) == value for key, value in expected.items()),
        "Frozen installed plan/runtime/source contract changed",
    )
    prior_path = LAB / PRIOR_NAME
    require(
        digest(prior_path) == PRIOR_SHA256, "Accepted prior postflight bytes changed"
    )
    prior = read(prior_path)
    pids = prior.get("inspected_pids", [])
    require(
        prior.get("accepted") is True
        and type(prior.get("ssh_returncode")) is int
        and prior["ssh_returncode"] == 0
        and len(pids) == len(set(pids)) == 120
        and all(type(pid) is int and pid > 1 for pid in pids),
        "Accepted actual-exit0 exact 120-PID prior required",
    )
    pids, captures = set(pids), {}
    if stage == "postflight":
        collector = importlib.import_module("capture_installed_blinka_pwm_consumers")
        collector.validate_local_manifest(manifest)
        require(
            plan.get("collector_sha256") == digest(collector.__file__),
            "Frozen installed collector sources changed",
        )
        expected_command = [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            shlex.join(
                [
                    PYTHON,
                    "-I",
                    ROOT + "/" + helper.NEW_SOURCE,
                    "--manifest",
                    REMOTE_MANIFEST,
                ]
            ),
        ]
        for name in CAPTURES:
            remote, result, acquisition = (
                read(LAB / name / filename)
                for filename in ("remote.stdout", "results.json", "acquisition.json")
            )
            collector.validate_remote(remote, manifest)
            require(
                result.get("collection_success") is True
                and result.get("remote") == remote
                and acquisition.get("remote_root") == ROOT
                and acquisition.get("remote_python") == PYTHON
                and acquisition.get("remote_command") == expected_command
                and result.get("source_manifest") == manifest
                and result.get("collector_sha256") == digest(collector.__file__)
                and all(
                    row.get("manifest_sha256") == digest(manifest_path)
                    for row in (result, acquisition)
                )
                and all(
                    type(row.get("remote_returncode")) is int
                    and row["remote_returncode"] == 0
                    for row in (result, acquisition)
                )
                and acquisition.get("primary_error") is None
                and acquisition.get("evidence_errors") == []
                and remote.get("manifest_path") == REMOTE_MANIFEST,
                "Successful actual-exit0 installed capture linkage required",
            )
            pid = remote.get("helper_pid")
            require(
                type(pid) is int and pid > 1 and pid not in pids,
                "Distinct actual installed helper PID required",
            )
            pids.add(pid)
            captures[name] = {
                "helper_pid": pid,
                "consumer_stdout_sha256": digest(LAB / name / "remote.stdout"),
                "results_sha256": digest(LAB / name / "results.json"),
                "acquisition_sha256": digest(LAB / name / "acquisition.json"),
            }
        require(len(pids) == 122, "Exact 122-PID installed postflight required")
    return manifest, sorted(pids), captures


def remote_code(pids):
    code = frozen.REMOTE.replace("PIDS", repr(json.dumps(pids)))
    final = "print(json.dumps(receipt, indent=2))"
    require(code.count(final) == 1, "Frozen read-only query structure changed")
    extra = f"""
import os, sys
root = pathlib.Path({ROOT!r})
assert root.is_dir() and not root.is_symlink()
assert sys.executable == {PYTHON!r} and sys.flags.isolated
assert not sys.stdin.isatty() and not sys.stdout.isatty()
assert not any(key.startswith('BLINKA_') or key in ('PYTHONPATH', 'PYTHONHOME') for key in os.environ)
sys.path.insert(0, str(root))
import installed_blinka_pwm_consumers_eval as installed
assert pathlib.Path(installed.__file__) == root / installed.NEW_SOURCE
manifest_path = root / {MANIFEST_NAME!r}
assert manifest_path.is_file() and not manifest_path.is_symlink()
manifest = json.loads(manifest_path.read_text())
installed.validate_manifest(manifest)
installed.inspect_sources(root, manifest, receipt)
receipt['identity'] = installed.dual.base.baseline.preflight()
receipt['manifest'] = manifest
receipt['manifest_sha256'] = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
receipt['program_path'] = str(pathlib.Path(installed.__file__))
receipt['runtime'] = {{'python_executable': sys.executable, 'isolated': bool(sys.flags.isolated), 'python_version': sys.version}}
receipt['board_or_pwmio_imported'] = any(name in sys.modules for name in ('board', 'pwmio', installed.PIN_MODULE))
assert not receipt['board_or_pwmio_imported']
{final}
"""
    return code.replace(final, extra)


def validate_state(remote, manifest, pids, stage, manifest_sha256):
    require(
        remote.get("read_only") is True
        and remote.get("no_gpio_request_or_write") is True
        and remote.get("board_or_pwmio_imported") is False
        and remote.get("hostname") == "test-pi5"
        and remote.get("kernel") == helper.dual.base.baseline.KERNEL
        and remote.get("boot_id") == frozen.BOOT_ID
        and remote.get("boot_config_sha256") == frozen.BOOT_SHA,
        "Pi identity/boot/read-only gate changed",
    )
    require(
        remote.get("manifest") == manifest
        and remote.get("manifest_sha256") == manifest_sha256
        and remote.get("source_sha256") == manifest["source_sha256"]
        and remote.get("source_paths") == manifest["source_paths"]
        and remote.get("distribution_versions") == manifest["distribution_versions"]
        and remote.get("program_path") == ROOT + "/" + helper.NEW_SOURCE,
        "Exact installed selected-source bytes/origins/versions required",
    )
    identity = remote.get("identity", {})
    require(
        identity.get("gpiochip") == "/dev/gpiochip0"
        and type(identity.get("gpiochip_index")) is int
        and identity["gpiochip_index"] == 0
        and identity.get("gpiochip_device_number") == "254:0"
        and identity.get("of_node") == OF_NODE
        and identity.get("compatible") == ["raspberrypi,rp1-gpio"]
        and identity.get("label") == "pinctrl-rp1"
        and identity.get("boot_id") == frozen.BOOT_ID
        and identity.get("kernel_release") == helper.dual.base.baseline.KERNEL,
        "Exact registered RP1 character-device and OF identity required",
    )
    runtime = remote.get("runtime", {})
    require(
        runtime.get("python_executable") == PYTHON
        and runtime.get("isolated") is True
        and isinstance(runtime.get("python_version"), str),
        "Private isolated installed interpreter required",
    )
    require(
        remote.get("pid_exists") == {str(pid): False for pid in pids},
        "Every exact inspected PID must be absent",
    )
    chip, lines = remote.get("gpiochip", {}), remote.get("lines", [])
    require(
        chip == {"name": "gpiochip0", "label": "pinctrl-rp1", "num_lines": 54}
        and len(lines) == 2
        and [row.get("offset") for row in lines] == [18, 23]
        and all(
            row.get("used") is False
            and row.get("consumer") in (None, "")
            and row.get("direction") == "OUTPUT"
            for row in lines
        ),
        "Both exact private header pins must be unclaimed OUTPUT",
    )
    pins = remote.get("pinctrl", [])
    require(
        len(pins) == 2
        and all(
            row.get("arguments") == ["pinctrl", "get", str(gpio)]
            and type(row.get("returncode")) is int
            and row["returncode"] == 0
            and re.search(
                r"^\s*" + str(gpio) + r": op\b.*\| lo\b", row.get("stdout", "")
            )
            for row, gpio in zip(pins, (18, 23), strict=True)
        ),
        "Both pins must independently read physically OUTPUT LOW",
    )
    throttled, pwm = remote.get("throttled", {}), remote.get("pwm", {})
    require(
        type(throttled.get("returncode")) is int
        and throttled["returncode"] == 0
        and throttled.get("stdout", "").strip() == "throttled=0x0"
        and isinstance(remote.get("temperature_millic"), str)
        and re.fullmatch(r"[0-9]+", remote["temperature_millic"])
        and 0
        <= int(remote["temperature_millic"])
        < (65000 if stage == "preflight" else 70000),
        "Temperature/throttling gate failed",
    )
    text = pwm.get("stdout", "")
    require(
        type(pwm.get("returncode")) is int
        and pwm["returncode"] == 0
        and re.findall(r"^\d+: ([^,]+),", text, re.M) == ["platform/1f0009c000.pwm"]
        and "cooling_fan" in text
        and all(
            "cooling_fan" in line for line in text.splitlines() if "requested" in line
        )
        and "1f00098000" not in text
        and "pwm-gpio" not in text,
        "Only unchanged separate fan provider permitted; automatic fan duty may change",
    )


def record(stage, plan_path, manifest_path):
    manifest, pids, captures = inputs(stage, plan_path, manifest_path)
    output = LAB / f"oct7-installed-blinka-consumers-{stage}.json"
    stdout, stderr = Path(str(output) + ".stdout"), Path(str(output) + ".stderr")
    require(
        not any(
            path.exists() or path.is_symlink() for path in (output, stdout, stderr)
        ),
        "Exclusive fresh installed state targets required",
    )
    code = remote_code(pids)
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([PYTHON, "-I", "-c", code]),
    ]
    result, remote, error = None, None, None
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            result = subprocess.run(
                command, stdout=out, stderr=err, timeout=20, check=False
            )
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt) as failure:
            error = f"{type(failure).__name__}: {failure}"
    actual_exit = (
        result.returncode
        if result is not None and type(result.returncode) is int
        else None
    )
    try:
        require(
            error is None and actual_exit == 0,
            "Actual typed read-only SSH exit0 required",
        )
        remote = read(stdout)
        validate_state(remote, manifest, pids, stage, digest(manifest_path))
    except (
        ValueError,
        KeyError,
        TypeError,
        AttributeError,
        OSError,
        KeyboardInterrupt,
    ) as failure:
        error = error or f"{type(failure).__name__}: {failure}"
    receipt = {
        "schema_version": 1,
        "stage": stage,
        "remote_root": ROOT,
        "remote_python": PYTHON,
        "manifest": manifest,
        "manifest_sha256": digest(manifest_path),
        "plan_sha256": digest(plan_path),
        "prior_postflight_sha256": PRIOR_SHA256,
        "capture_receipts": captures,
        "inspected_pids": pids,
        "ssh_returncode": actual_exit,
        "accepted": error is None,
        "validation_error": error,
        "remote": remote,
        "remote_read_only_code": code,
        "remote_command": command,
        "source_sha256": digest(__file__),
        "stdout_sha256": digest(stdout),
        "stderr_sha256": digest(stderr),
        "scope": "Read-only exact installed-source/state/PID absence; not waveform acceptance, parity, whole-Blinka compatibility or actuator safety",
    }
    with output.open("x") as stream:
        json.dump(receipt, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "accepted": receipt["accepted"],
                "inspected_pids": len(pids),
                "validation_error": error,
            }
        )
    )
    return 0 if receipt["accepted"] else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("preflight", "postflight"))
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    args = parser.parse_args(argv)
    return record(args.stage, args.plan, args.manifest)


if __name__ == "__main__":
    raise SystemExit(main())
