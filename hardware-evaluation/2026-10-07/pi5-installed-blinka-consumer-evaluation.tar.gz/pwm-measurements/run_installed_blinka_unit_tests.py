"""Three installed-wheel hardware-free test modules, no GPIO requests."""

import hashlib
import json
import shlex
import subprocess
from pathlib import Path

import prepare_installed_blinka_env as prep

LAB = Path(__file__).resolve().parent
REPO = LAB.parent / "Adafruit_Blinka_Raspberry_Pi_PWM"
OUTPUT = LAB / "oct7-installed-blinka-unit-tests.json"
TESTS = ("test_pwmout.py", "test_software.py", "test_native_module.py")


def main():
    pins = {
        name: hashlib.sha256((REPO / "tests" / name).read_bytes()).hexdigest()
        for name in TESTS
    }
    code = f"""
import hashlib,json,pathlib,subprocess
root=pathlib.Path({prep.ROOT!r})
pins={pins!r}
for name,expected in pins.items():
    file=root/'pwm-source/tests'/name
    assert file.is_file() and not file.is_symlink()
    assert hashlib.sha256(file.read_bytes()).hexdigest()==expected
command=[{prep.PYTHON!r},'-I','-m','pytest','-q',
         *[str(root/'pwm-source/tests'/name) for name in pins]]
result=subprocess.run(command,cwd=root,stdin=subprocess.DEVNULL,check=False)
print(json.dumps({{'pytest_returncode':result.returncode,'command':command,
                  'test_source_sha256':pins,'no_gpio_test_scope':True}}))
raise SystemExit(result.returncode)
"""
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(["/usr/bin/python3", "-c", code]),
    ]
    stdout, stderr = Path(str(OUTPUT) + ".stdout"), Path(str(OUTPUT) + ".stderr")
    assert not any(p.exists() or p.is_symlink() for p in (OUTPUT, stdout, stderr))
    with stdout.open("xb") as out, stderr.open("xb") as err:
        result = subprocess.run(
            command, stdout=out, stderr=err, timeout=45, check=False
        )
    receipt = {
        "ssh_returncode": result.returncode,
        "accepted": type(result.returncode) is int and result.returncode == 0,
        "remote_code": code,
        "remote_command": command,
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "stdout_sha256": hashlib.sha256(stdout.read_bytes()).hexdigest(),
        "stderr_sha256": hashlib.sha256(stderr.read_bytes()).hexdigest(),
    }
    with OUTPUT.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(stdout.read_text())
    print(
        json.dumps(
            {"accepted": receipt["accepted"], "ssh_returncode": result.returncode}
        )
    )
    return 0 if receipt["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
