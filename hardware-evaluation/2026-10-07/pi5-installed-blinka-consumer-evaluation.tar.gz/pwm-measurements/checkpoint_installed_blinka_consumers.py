"""Exclusive installed-consumer recovery and exact isolated offline replay.

No import-time evidence reads, GPIO, SSH, installation or Saleae calls. Execute
only after both captures/reports and independent audits are frozen. Supply a
separate input-pins JSON after method freeze; its exact bytes are archived too.
Source tarballs and wheels are retained as opaque bytes, never installed or
unpacked by this checkpointer. Failed verification leaves evidence in place.
"""

import argparse
import hashlib
import importlib.metadata
import io
import json
import os
import stat
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

LAB = Path(__file__).resolve().parent
PREP = Path("/private/tmp/blinka-installed-prep.1XpM16")
PLAN_NAME = "oct7-installed-blinka-consumers-plan.json"
MANIFEST_NAME = "oct7-installed-blinka-consumers-manifest.json"
CAPTURES = (
    "oct7-pi5-installed-blinka-consumers-r1",
    "oct7-pi5-installed-blinka-consumers-r2",
)
REPORT_NAME = "installed-consumer-analysis.json"
ARCHIVE_NAME = "pi5-installed-blinka-consumer-evaluation.tar.gz"
VERIFICATION_NAME = "oct7-installed-blinka-consumers-checkpoint-verification.json"
METHODS = (
    "installed_blinka_pwm_consumers_eval.py",
    "capture_installed_blinka_pwm_consumers.py",
    "analyze_installed_blinka_pwm_consumers.py",
    "test_installed_blinka_pwm_consumers_eval.py",
    "test_capture_installed_blinka_pwm_consumers.py",
    "test_analyze_installed_blinka_pwm_consumers.py",
    "prepare_installed_blinka_env.py",
    "record_installed_blinka_sources.py",
    "run_installed_blinka_unit_tests.py",
    "record_installed_blinka_import.py",
    "record_installed_blinka_state.py",
    "test_record_installed_blinka_state.py",
    "checkpoint_installed_blinka_consumers.py",
    "test_checkpoint_installed_blinka_consumers.py",
    "audit_installed_blinka_raw.py",
    "test_audit_installed_blinka_raw.py",
    "compare_installed_blinka_reports.py",
    "test_compare_installed_blinka_reports.py",
    "verify_installed_blinka_saved_sal.py",
    # Frozen import/receipt/reconstruction and recording-only fixture closure.
    "native_pwm_consumers_eval.py",
    "capture_native_pwm_consumers.py",
    "analyze_native_pwm_consumers.py",
    "test_native_pwm_consumers_eval.py",
    "test_capture_native_pwm_consumers.py",
    "test_analyze_native_pwm_consumers.py",
    "native_pwm_dual_eval.py",
    "capture_native_pwm_dual.py",
    "analyze_native_pwm_dual_initial.py",
    "test_native_pwm_dual_eval.py",
    "native_pwm_updates_eval.py",
    "native_pwm_half50_eval.py",
    "test_native_pwm_half50_eval.py",
    "kernel_pwm_lgpio_baseline_eval.py",
    "test_kernel_pwm_lgpio_baseline_eval.py",
    "kernel_pwm_eval.py",
    "capture_native_pwm_half50.py",
    "capture_kernel_pwm_lgpio_baseline.py",
    "capture_pwm.py",
    "analyze_kernel_pwm_inverse.py",
    "analyze_gpio_pwm_marker.py",
    "capture_gpio_pwm_marker.py",
    "gpio_pwm_marker_eval.py",
    "baseline_pwmout.py",
    "lgpio_pin.py",
    "record_native_updates_postflight.py",
    "record_lgpio_consumers_loaded_paired_state.py",
    "test_record_lgpio_consumers_loaded_paired_state.py",
)
RECEIPT_STEMS = tuple(
    "oct7-installed-blinka-env-" + stage
    for stage in (
        "bootstrap",
        "build-tools",
        "local-wheels",
        "runtime-wheels",
        "install",
    )
) + (
    "oct7-installed-blinka-source-inventory",
    "oct7-installed-blinka-unit-tests",
    "oct7-installed-blinka-import-probe",  # Failed initial detector-ID probe.
    "oct7-installed-blinka-import-probe-r2",  # Corrected actual-ID probe.
    "oct7-installed-blinka-consumers-preflight",
    "oct7-installed-blinka-consumers-postflight",
    "oct7-lgpio-consumers-loaded-paired-postflight",  # Prior actual 120-PID chain.
)
DATA_NAMES = (
    PLAN_NAME,
    MANIFEST_NAME,
    "oct7-installed-blinka-state-preflight-plan.json",
    "oct7-installed-blinka-state-postflight-plan.json",
    "oct7-installed-blinka-local-cli-results.json",
    "oct7-installed-blinka-saved-sal-verification.json",
    "oct7-installed-blinka-late-rise-diagnosis.json",
    "oct7-lgpio-consumers-loaded-plan.json",
    "oct7-native-consumers-plan.json",
) + tuple(
    stem + ".json" + suffix
    for stem in RECEIPT_STEMS
    for suffix in ("", ".stdout", ".stderr")
)
CAPTURE_FILES = (
    "plan.json",
    "manifest.json",
    "remote.stdout",
    "remote.stderr",
    "results.json",
    "acquisition.json",
    "waveform.sal",
    "digital_0.bin",
    "digital_1.bin",
    REPORT_NAME,
)
PREP_ARCHIVES = (
    "blinka-source.tar.gz",
    "blinka-patched-source.tar.gz",
    "pwm-source.tar.gz",
    "inventory-only-helper.tar.gz",
    "pre-detection-correction.tar.gz",
)
PREP_LOGS = (
    "runtime-wheels.log",
    "blinka-wheel.log",
    "native-wheel.log",
    "runtime-install.log",
    "runtime-install-report.json",
    "build-tools-report.json",
    "build-tools.log",
)
NATIVE_PREFIX = "Adafruit_Blinka_Raspberry_Pi_PWM/src/adafruit_blinka_raspberry_pi_pwm/"
NATIVE_FILES = ("__init__.py", "_software.py")
INTEGRATION_PATCH = "Adafruit_Blinka_Raspberry_Pi_PWM/docs/blinka-integration.patch"
CONSUMER_FILES = (
    "adafruit_motor/__init__.py",
    "adafruit_motor/servo.py",
    "adafruit_motor/motor.py",
)
AUDIT_ARTIFACTS = (
    "oct7-installed-blinka-independent-audit.json",
    "oct7-installed-blinka-independent-audit.notes.txt",
    "oct7-installed-blinka-final-report-audit.json",
)
REPLAY = r"""
import importlib.metadata,json,pathlib,sys
root=pathlib.Path(sys.argv[1])
lab=root/'pwm-measurements'
sys.path.insert(0,str(lab))
import analyze_installed_blinka_pwm_consumers as analysis
plan=lab/'oct7-installed-blinka-consumers-plan.json'
names=json.loads(plan.read_text())['capture_order']
assert names==list(analysis.CAPTURE_NAMES)
for name in names:
    saved=json.loads((lab/name/'installed-consumer-analysis.json').read_text())
    reproduced=analysis.analyze(lab/name,plan)
    assert reproduced==saved,name
print(json.dumps({'installed_reports_reproduced':len(names),
                  'all_report_json_facts_exact':True,
                  'fact_or_path_adjustments_used':False,
                  'runtime_motor_version':importlib.metadata.version('adafruit-circuitpython-motor'),
                  'runtime_saleae_sdk_version':importlib.metadata.version('logic2-automation')}))
"""


def require(condition, message):
    if not condition:
        raise ValueError(message)


def safe_name(name):
    require(
        isinstance(name, str) and name and "\\" not in name and "\x00" not in name,
        "Unsafe member name",
    )
    path = PurePosixPath(name)
    require(
        not path.is_absolute()
        and str(path) == name
        and all(
            part not in ("", ".", "..") and ":" not in part for part in name.split("/")
        ),
        "Unsafe member name: " + name,
    )
    return path


def regular(path):
    path = Path(path).absolute()
    require(
        path.is_file() and not path.is_symlink() and path.resolve(strict=True) == path,
        "Missing or linked regular source: " + str(path),
    )
    return path


def directory(path):
    path = Path(path).absolute()
    require(
        path.is_dir() and not path.is_symlink() and path.resolve(strict=True) == path,
        "Missing or linked directory: " + str(path),
    )
    return path


def interpreter(path):
    # A normal venv interpreter may itself be a link; keep that venv pathname
    # so Python retains its existing site-packages. It is not an archive input.
    path = Path(path).absolute()
    directory(path.parent)
    require(
        path.is_file() and os.access(path, os.X_OK),
        "Existing executable replay Python required",
    )
    return path


def file_bytes(path):
    path = regular(path)
    # Refuse replacing the already-checked final component with a link.
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        require(
            stat.S_ISREG(os.fstat(stream.fileno()).st_mode),
            "Regular file changed before read",
        )
        return stream.read()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha256(file_bytes(path))


def read_json_bytes(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result

    return json.loads(data.decode(), object_pairs_hook=pairs)


def valid_hash(value):
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(char in "0123456789abcdef" for char in value)
    )


def source_names():
    return (
        {"pwm-measurements/" + name for name in METHODS}
        | {NATIVE_PREFIX + name for name in NATIVE_FILES}
        | {"consumer-library-source/" + name for name in CONSUMER_FILES}
        | {INTEGRATION_PATCH}
    )


def validate_pins(pins):
    require(
        isinstance(pins, dict)
        and type(pins.get("schema_version")) is int
        and pins["schema_version"] == 1,
        "Input pins schema1 required",
    )
    require(valid_hash(pins.get("plan_sha256")), "Frozen plan SHA256 pending")
    sources = pins.get("source_sha256")
    require(
        isinstance(sources, dict)
        and set(sources) == source_names()
        and all(valid_hash(value) for value in sources.values()),
        "Exact frozen method/native/consumer source pins required",
    )
    extras = pins.get("extra_lab_sha256")
    require(
        isinstance(extras, dict)
        and extras
        and all(valid_hash(value) for value in extras.values()),
        "Frozen independent audit artifacts pending",
    )
    for name in extras:
        require(
            str(safe_name(name)) == name
            and "/" not in name
            and name.startswith("oct7-installed-blinka-"),
            "Only explicit new installed lab artifacts allowed",
        )
    require(
        set(AUDIT_ARTIFACTS) <= set(extras),
        "Frozen initial audit/notes and final report audit required",
    )
    audit = pins.get("audit_sources")
    require(
        isinstance(audit, dict) and audit,
        "Independent method/check receipt mapping pending",
    )
    for name, row in audit.items():
        safe_name(name)
        require(
            name.startswith("audit-source/")
            and isinstance(row, dict)
            and set(row) == {"path", "sha256"}
            and valid_hash(row["sha256"])
            and isinstance(row["path"], str)
            and Path(row["path"]).is_absolute(),
            "Exact audit-source path/hash required",
        )


def build_inventory(lab, prep, pins_path):
    """Resolve only enumerated files; never recurse into a checkout or source tree."""
    lab, prep = directory(lab), directory(prep)
    pins_path = regular(pins_path)
    pins_bytes = file_bytes(pins_path)
    pins = read_json_bytes(pins_bytes)
    validate_pins(pins)
    sources = {}

    def add(name, path, expected=None):
        safe_name(name)
        require(name not in sources, "Duplicate archive member: " + name)
        path = regular(path)
        actual = digest(path)
        require(
            expected is None or actual == expected,
            "Frozen input bytes changed: " + name,
        )
        sources[name] = (path, actual)

    for name in METHODS + DATA_NAMES:
        key = "pwm-measurements/" + name
        add(
            key,
            lab / name,
            pins["source_sha256"].get(key, pins["extra_lab_sha256"].get(name)),
        )
    for name, expected in pins["extra_lab_sha256"].items():
        if name not in METHODS + DATA_NAMES:
            add("pwm-measurements/" + name, lab / name, expected)
    for capture in CAPTURES:
        for name in CAPTURE_FILES:
            add("pwm-measurements/" + capture + "/" + name, lab / capture / name)
    plan = read_json_bytes(file_bytes(lab / PLAN_NAME))
    manifest = read_json_bytes(file_bytes(lab / MANIFEST_NAME))
    require(
        digest(lab / PLAN_NAME) == pins["plan_sha256"]
        and plan.get("capture_order") == list(CAPTURES),
        "Frozen exact two-capture plan changed",
    )
    require(
        plan.get("manifest_sha256") == digest(lab / MANIFEST_NAME),
        "Plan manifest bytes changed",
    )
    require(
        plan.get("preflight_receipt_sha256")
        == digest(lab / "oct7-installed-blinka-consumers-preflight.json"),
        "Plan preflight receipt changed",
    )
    for filename, key in (
        ("installed_blinka_pwm_consumers_eval.py", "helper_sha256"),
        ("capture_installed_blinka_pwm_consumers.py", "collector_sha256"),
    ):
        require(
            plan.get(key) == sources["pwm-measurements/" + filename][1],
            "Plan source pin changed: " + filename,
        )
    native = (
        lab.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src/adafruit_blinka_raspberry_pi_pwm"
    )
    for name in NATIVE_FILES:
        key = NATIVE_PREFIX + name
        add(key, native / name, pins["source_sha256"][key])
        require(
            sources[key][1]
            == manifest["source_sha256"]["adafruit_blinka_raspberry_pi_pwm/" + name],
            "Native selected Python source changed",
        )
    add(
        INTEGRATION_PATCH,
        lab.parent / INTEGRATION_PATCH,
        pins["source_sha256"][INTEGRATION_PATCH],
    )
    distribution = importlib.metadata.distribution("adafruit-circuitpython-motor")
    require(
        distribution.version == "3.5.0",
        "Genuine installed motor3.5.0 required for recovery",
    )
    for name in CONSUMER_FILES:
        key = "consumer-library-source/" + name
        add(key, distribution.locate_file(name), pins["source_sha256"][key])
        require(
            sources[key][1] == manifest["source_sha256"][name],
            "Selected genuine consumer Python source changed",
        )
    bootstrap = read_json_bytes(
        file_bytes(lab / "oct7-installed-blinka-env-bootstrap.json")
    )
    require(
        bootstrap.get("accepted") is True
        and type(bootstrap.get("ssh_returncode")) is int
        and bootstrap["ssh_returncode"] == 0,
        "Successful actual-exit0 bootstrap receipt required",
    )
    archive_pins = bootstrap.get("source_archives")
    require(
        isinstance(archive_pins, dict)
        and set(archive_pins) == {"blinka-patched-source.tar.gz", "pwm-source.tar.gz"}
        and all(valid_hash(value) for value in archive_pins.values()),
        "Exact successful bootstrap source archive pins required",
    )
    for name in PREP_ARCHIVES:
        add("installation-preparation/" + name, prep / name, archive_pins.get(name))
    logs = prep / "remote-install-receipts"
    require(
        {path.name for path in logs.iterdir()} == set(PREP_LOGS),
        "Exact seven preserved build/install log files required",
    )
    for name in PREP_LOGS:
        add("installation-preparation/remote-install-receipts/" + name, logs / name)
    wheels = sorted((prep / "wheelhouse").iterdir())
    wheel_pins = plan.get("wheel_artifacts")
    require(
        isinstance(wheel_pins, dict)
        and len(wheel_pins) == 23
        and {path.name for path in wheels} == set(wheel_pins)
        and all(path.suffix == ".whl" for path in wheels),
        "Exact 23 predeclared actual wheel files required",
    )
    for path in wheels:
        row = wheel_pins[path.name]
        require(
            isinstance(row, dict)
            and set(row) == {"sha256", "size_bytes"}
            and valid_hash(row["sha256"])
            and type(row["size_bytes"]) is int
            and row["size_bytes"] > 0,
            "Exact frozen wheel hash/size required: " + path.name,
        )
        require(
            regular(path).stat().st_size == row["size_bytes"],
            "Frozen wheel size changed: " + path.name,
        )
        add("installation-preparation/wheelhouse/" + path.name, path, row["sha256"])
    for name, row in pins["audit_sources"].items():
        add(name, row["path"], row["sha256"])
    add("checkpoint-input-pins.json", pins_path, sha256(pins_bytes))
    return sources, pins


def write_archive(destination, sources):
    """Snapshot each validated source byte stream; links and trees are never added."""
    require(
        not destination.exists() and not destination.is_symlink(),
        "Exclusive fresh archive required",
    )
    with (
        destination.open("xb") as stream,
        tarfile.open(fileobj=stream, mode="w:gz") as archive,
    ):
        for name, (source, expected) in sorted(sources.items()):
            safe_name(name)
            data = file_bytes(source)
            require(sha256(data) == expected, "Source changed during archive: " + name)
            member = tarfile.TarInfo(name)
            member.size, member.mode = len(data), 0o644
            archive.addfile(member, io.BytesIO(data))


def safe_extract(archive_path, destination):
    """Validate the full member set before extracting into a new empty directory."""
    directory(destination)
    require(
        not list(destination.iterdir()), "Fresh empty extraction directory required"
    )
    with tarfile.open(regular(archive_path), "r:gz") as archive:
        members, names = archive.getmembers(), set()
        for member in members:
            key = str(safe_name(member.name))
            require(
                key not in names and member.isfile(),
                "Duplicate or nonregular archive member: " + key,
            )
            names.add(key)
        require(
            all(
                not any(
                    str(parent) in names
                    for parent in PurePosixPath(name).parents
                    if str(parent) != "."
                )
                for name in names
            ),
            "Archive file/directory prefix collision",
        )
        archive.extractall(destination, filter="data")
    return {
        str(path.relative_to(destination)): digest(path)
        for path in destination.rglob("*")
        if path.is_file()
    }


def verify_archive(archive_path, sources, replay_python):
    extracted = Path(
        tempfile.mkdtemp(
            prefix="blinka-installed-consumers-checkpoint-", dir="/private/tmp"
        )
    )
    recovered = safe_extract(archive_path, extracted)
    require(
        recovered == {name: expected for name, (_path, expected) in sources.items()},
        "Archive file set/bytes differ",
    )
    result = subprocess.run(
        [str(replay_python), "-I", "-c", REPLAY, str(extracted)],
        cwd=extracted,
        capture_output=True,
        text=True,
        check=True,
        timeout=60,
    )
    replay = read_json_bytes(result.stdout.encode())
    require(
        replay.get("installed_reports_reproduced") == 2
        and replay.get("all_report_json_facts_exact") is True
        and replay.get("fact_or_path_adjustments_used") is False,
        "Exact two-report isolated replay required",
    )
    return extracted, replay, result.stderr


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--input-pins", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--verification", type=Path, required=True)
    parser.add_argument("--replay-python", type=Path, default=Path(sys.executable))
    args = parser.parse_args(argv)
    require(args.execute, "Explicit execution authorization required; preparation only")
    archive, verification = args.archive.absolute(), args.verification.absolute()
    require(
        archive.name == ARCHIVE_NAME and verification.name == VERIFICATION_NAME,
        "Exact installed checkpoint output filenames required",
    )
    require(
        archive.parent.resolve(strict=True) == archive.parent
        and verification.parent.resolve(strict=True) == verification.parent,
        "Outputs cannot traverse links",
    )
    require(
        all(
            not path.exists() and not path.is_symlink()
            for path in (archive, verification)
        ),
        "Archive and verification outputs must be fresh",
    )
    require(archive != verification, "Distinct exclusive outputs required")
    replay_python = interpreter(args.replay_python)
    sources, pins = build_inventory(LAB, PREP, args.input_pins)
    require(
        all(
            path not in (archive, verification) for path, _expected in sources.values()
        ),
        "Output overlaps input evidence",
    )
    write_archive(archive, sources)
    extracted, replay, stderr = verify_archive(archive, sources, replay_python)
    report = {
        "archive": str(archive),
        "size_bytes": archive.stat().st_size,
        "sha256": digest(archive),
        "regular_files": len(sources),
        "all_file_bytes_match": True,
        "safe_extraction": str(extracted),
        "frozen_plan_sha256": pins["plan_sha256"],
        "file_sha256": {
            name: expected for name, (_path, expected) in sorted(sources.items())
        },
        "replay": replay,
        "replay_stderr": stderr,
        "source_archives_retained_as_bytes_not_extracted": list(PREP_ARCHIVES),
        "actual_wheel_files_retained": 23,
        "all_wheel_bytes_and_sizes_match_pre_capture_plan": True,
        "patched_blinka_and_pwm_archives_match_successful_bootstrap": True,
        "recording_only_fixture_recovery_note": "To rerun source-only helper fixtures, restore original Adafruit_Blinka sources from the opaque blinka-source.tar.gz; the integration patch is retained separately at Adafruit_Blinka_Raspberry_Pi_PWM/docs/blinka-integration.patch, not in pwm-source.tar.gz. The isolated report replay itself needs neither source-tree extraction nor board/pwmio imports.",
        "scope": "Exact recovery and unchanged offline replay of two finite installed board/pwmio consumer reports; no new hardware evidence, safety, quantitative parity or general compatibility verdict. Failed initial import probe and corrected probe are both preserved. Fan state is retained verbatim, never labelled unchanged here. Replay requires existing genuine motor3.5.0 and Saleae automation; no runtime installation or hardware API is called.",
    }
    with verification.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                key: report[key]
                for key in (
                    "archive",
                    "size_bytes",
                    "sha256",
                    "regular_files",
                    "all_file_bytes_match",
                    "frozen_plan_sha256",
                    "replay",
                )
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
