"""Real installed patched-Blinka passive consumer acquisition, not parity.

Copy the frozen consumer protocol validator's bounded phase/action/cleanup
checks with genuine board-Pin constructor arguments. Reuse its small immutable
validation primitives; never convert receipts into an in-memory-shim receipt.
Physical unfiltered Logic8 channels0/1, 100 MSa/s, with full SAL/raw evidence.
"""

import argparse
import hashlib
import json
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path

import capture_native_pwm_dual as frozen
import installed_blinka_pwm_consumers_eval as helper
from saleae import automation

protocol = helper.protocol
DEVICE_ID, require, read_json, _write = (
    frozen.DEVICE_ID,
    frozen.require,
    frozen.read_json,
    frozen._write,
)
MODE, BACKEND, SEQUENCE_MARKER = helper.MODE, helper.BACKEND, helper.SEQUENCE_MARKER
HELPER_SHA256 = "4635b27d6290364c55027974761cf1956e17ba36904edb6e1a170721e804333b"
MANIFEST_FILENAME = "oct7-installed-blinka-consumers-manifest.json"
PLAN_FILENAME = "oct7-installed-blinka-consumers-plan.json"
CAPTURES = [
    "oct7-pi5-installed-blinka-consumers-r1",
    "oct7-pi5-installed-blinka-consumers-r2",
]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_hashes():
    """Exact loaded lab method files, not a whole SDK/system attestation."""
    paths = {
        Path(__file__),
        Path(frozen.__file__),
        Path(read_json.__code__.co_filename),
    }
    paths.update(
        Path(sys.modules[name].__file__)
        for name in ("capture_native_pwm_half50", "capture_pwm")
    )
    paths.update(
        Path(module.__file__)
        for module in (
            helper,
            protocol,
            helper.dual,
            helper.dual.native,
            helper.dual.base,
            helper.dual.base.baseline,
            helper.core,
        )
    )
    return {path.name: digest(path) for path in sorted(paths)}


def validate_local_manifest(manifest):
    hashes = helper.validate_manifest(manifest)
    directory = Path(__file__).resolve().parent
    native = (
        directory.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src"
        / helper.dual.base.PACKAGE
    )
    paths = {key: directory / key for key in helper.FROZEN_PINS if "/" not in key}
    paths.update(protocol.consumer_inventory())
    paths.update(
        {
            helper.dual.base.PACKAGE + "/" + name: native / name
            for name in ("__init__.py", "_software.py")
        }
    )
    paths[helper.NEW_SOURCE] = Path(helper.__file__)
    require(
        hashes[helper.NEW_SOURCE] == HELPER_SHA256
        and all(
            path.is_file() and digest(path) == hashes[key]
            for key, path in paths.items()
        ),
        "Frozen local helper/core/native/consumer Python bytes must match manifest",
    )
    return hashes


def validate_plan(plan, manifest):
    hashes = helper.validate_manifest(manifest)
    require(isinstance(plan, dict), "Installed consumer plan must be an object")
    root = plan.get("remote_root")
    require(
        isinstance(root, str) and re.fullmatch(helper.ROOT_PATTERN, root),
        "Plan requires the fresh installed-consumers root",
    )
    require(
        frozen._fields(
            plan,
            {
                "schema_version": 1,
                "mode": MODE,
                "backend": BACKEND,
                "sequence_marker": SEQUENCE_MARKER,
                "remote_python": root + "/venv/bin/python",
                "helper_sha256": HELPER_SHA256,
                "collector_sha256": digest(__file__),
                "capture_order": CAPTURES,
                "outputs": [
                    {"gpio": 18, "saleae_channel": 0},
                    {"gpio": 23, "saleae_channel": 1},
                ],
                "sequence": [
                    {
                        "name": name,
                        "duration_seconds": dwell,
                        "operation": operation,
                        "value": value,
                    }
                    for name, dwell, operation, value in helper.SEQUENCE
                ],
                "runtime_flags": {"short_slice": False, "shared": False},
            },
        )
        and hashes[helper.NEW_SOURCE] == HELPER_SHA256,
        "Exact frozen installed consumer plan/source/protocol mismatch",
    )
    for key in ("manifest_sha256", "preflight_receipt_sha256"):
        require(
            isinstance(plan.get(key), str) and re.fullmatch(r"[0-9a-f]{64}", plan[key]),
            "Plan requires SHA256: " + key,
        )


def validate_remote(remote, manifest):
    hashes = helper.validate_manifest(manifest)
    require(isinstance(remote, dict), "Installed consumer receipt must be an object")
    require(
        frozen._fields(
            remote,
            {
                "schema_version": 1,
                "mode": MODE,
                "backend": BACKEND,
                "sequence_marker": SEQUENCE_MARKER,
                "gpios": [18, 23],
                "primary_error": None,
                "cleanup_errors": [],
                "signals_received": [],
                "parity_pass": None,
                "actual_actuators_attached": False,
                "whole_blinka_compatibility_proven": False,
                "runtime_flags": {"short_slice": False, "shared": False},
                "inherited_environment": {},
                "watchdog_seconds": 14,
                "sequence_dwell_seconds": round(sum(p[1] for p in helper.SEQUENCE), 6),
                "low_settle_seconds": 0.1,
                "normal_fixed_wait_seconds": round(
                    sum(p[1] for p in helper.SEQUENCE) + 0.3, 6
                ),
                "source_sha256": hashes,
                "source_paths": manifest["source_paths"],
                "distribution_versions": manifest["distribution_versions"],
            },
        )
        and "integration_shim" not in remote
        and hashes[helper.NEW_SOURCE] == HELPER_SHA256,
        "Installed source/version/functional-only receipt contract mismatch",
    )
    require(
        all(
            remote.get(key) is True
            for key in (
                "success",
                "completed_normally",
                "read_only_chip_closed",
                "functional_consumer_integration_only",
                "passive_probes_only",
                "production_backend_unchanged",
                "api_readbacks_are_not_electrical",
                "selected_source_hashes_are_not_whole_system_attestation",
                "variable_frequency",
                "watchdog_cannot_bound_native_hang_or_sigkill",
                "isolated_python",
                "noninteractive_no_runtime_installs",
            )
        ),
        "Installed positive safety gates required",
    )
    require(
        type(remote.get("helper_pid")) is int
        and remote["helper_pid"] > 0
        and type(remote.get("begin_ns")) is int
        and type(remote.get("end_ns")) is int
        and 0 <= remote["begin_ns"] < remote["end_ns"]
        and remote["end_ns"] - remote["begin_ns"] < 14_000_000_000,
        "Bounded installed helper identity/run required",
    )
    manifest_path = remote.get("manifest_path")
    require(
        isinstance(manifest_path, str)
        and re.fullmatch(helper.ROOT_PATTERN + "/" + MANIFEST_FILENAME, manifest_path),
        "Installed isolated manifest identity mismatch",
    )
    root = Path(manifest_path).parent
    require(
        remote.get("python_executable") == str(root / "venv/bin/python"),
        "Installed fresh interpreter mismatch",
    )
    for key, value in manifest["source_paths"].items():
        require(isinstance(value, str), "Selected source path must be text")
        path = Path(value)
        is_helper = (
            key == helper.NEW_SOURCE or "/" not in key and key.endswith("_eval.py")
        )
        require(
            path.is_absolute()
            and ".." not in path.parts
            and (
                path == root / key if is_helper else path.is_relative_to(root / "venv")
            ),
            "Selected source outside exact fresh helper/venv root: " + key,
        )
    require(
        frozen._exact(
            remote.get("installed_dispatch"),
            {
                "real_board_used": True,
                "real_pwmio_used": True,
                "virtual_pwmio_export_used": False,
                "unwrapped_public_pwm_objects": True,
                "pwmout_identity_verified": True,
                "board_id": "RASPBERRY_PI_5",
                "chip_id": "BCM2XXX",
                "pin_class_module": helper.PIN_MODULE,
                "pin_ids": [18, 23],
            },
        ),
        "Real installed board/pwmio/Pin dispatch proof required",
    )
    require(
        frozen._exact(
            remote.get("consumers"),
            {
                "version": "3.5.0",
                "servo": {
                    "actuation_range": 180,
                    "min_pulse_us": 1000,
                    "max_pulse_us": 2000,
                },
                "motor": {"decay_mode": 0, "throttle_zero_is_both_high_brake": True},
            },
        ),
        "Genuine motor3.5.0 consumer configuration required",
    )
    identity = remote.get("identity")
    require(
        frozen._fields(
            identity,
            {
                "gpio": 18,
                "label": "pinctrl-rp1",
                "kernel_release": helper.dual.base.baseline.KERNEL,
                "compatible": ["raspberrypi,rp1-gpio"],
            },
        )
        and type(identity.get("gpiochip_index")) is int
        and identity["gpiochip_index"] >= 0
        and identity.get("gpiochip") == f"/dev/gpiochip{identity['gpiochip_index']}"
        and isinstance(identity.get("gpiochip_device_number"), str)
        and re.fullmatch(r"[0-9]+:[0-9]+", identity["gpiochip_device_number"])
        and isinstance(identity.get("model"), str)
        and identity["model"].startswith("Raspberry Pi 5 Model B Rev ")
        and isinstance(identity.get("boot_id"), str)
        and re.fullmatch(
            r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", identity["boot_id"]
        ),
        "Approved Pi5 RP1 kernel/controller identity required",
    )
    preclaim = remote.get("preclaim_lines")
    require(
        isinstance(preclaim, list) and len(preclaim) == 2,
        "Both fresh preclaim lines required",
    )
    for row, gpio in zip(preclaim, (18, 23)):
        require(frozen._fields(row, {"gpio": gpio}), "Preclaim pin mismatch")
        frozen._chip(row.get("chip_info"), identity)
        frozen._line(row.get("line_info"), gpio)
    outputs = remote.get("outputs")
    require(
        isinstance(outputs, list) and len(outputs) == 3,
        "Three private generations required",
    )
    records = {}
    for row, (output_id, gpio, generation, frequency) in zip(outputs, helper.OUTPUTS):
        require(
            frozen._fields(
                row,
                {
                    "output_id": output_id,
                    "gpio": gpio,
                    "generation": generation,
                    "initial_frequency": frequency,
                    "variable_frequency": True,
                    "fresh_claim_accepted": True,
                    "initial_low_confirmed": True,
                    "low_confirmed": True,
                    "released": True,
                    "read_only_chip_closed": True,
                },
            )
            and frozen._exact(
                row.get("real_board_pin"),
                {
                    "attribute": "D" + str(gpio),
                    "id": gpio,
                    "class_module": helper.PIN_MODULE,
                },
            )
            and frozen._exact(
                row.get("initial_readback"), {"gpio_level": 0, "inactive": True}
            )
            and frozen._exact(
                row.get("cleanup_final_readback"), {"gpio_level": 0, "inactive": True}
            ),
            "Real Pin/private initial-low/cleanup-low/release proof required",
        )
        request = row.get("owned_request")
        require(
            frozen._fields(
                request,
                {"chip_name": Path(identity["gpiochip"]).name, "offsets": [gpio]},
            )
            and set(request) == {"chip_name", "offsets", "fd"}
            and type(request.get("fd")) is int
            and request["fd"] >= 0,
            "Private native per-line request identity required",
        )
        frozen._chip(row.get("chip_info"), identity)
        for key in ("preclaim_line_info", "released_line_info"):
            frozen._line(row.get(key), gpio)
        records[output_id] = row
    _validate_protocol(remote, records)
    _validate_event_order(remote)
    _validate_import_chip(remote, identity)
    for key, limit in (("before", 65000), ("after", 70000)):
        require(
            isinstance(remote.get(key), dict)
            and not helper.core.thermal_issues(remote[key], limit),
            "Thermal safety gate failed: " + key,
        )


def _validate_event_order(remote):
    """Flat native caller events only; import-lgpio events are separate."""
    expected = []
    constructor = [
        "gpiod_line_info_preclaim",
        "PWMOut.__init__",
        "initial_request.get_value",
    ]
    cleanup = [
        "track_owned_request",
        "PWMOut.duty_cycle_zero",
        "low_settle",
        "owned_request.get_value",
        "PWMOut.deinit",
        "gpiod_line_info_released",
    ]
    for index, (name, _duration, operation, _value) in enumerate(helper.SEQUENCE):
        scope = f"{index:02d}_{name}"
        if operation.endswith("initialize"):
            ids = (
                ["servo18-g1"]
                if operation == "servo_initialize"
                else ["motor18-g2", "motor23-g1"]
            )
            expected.extend(
                (output_id, call, scope) for output_id in ids for call in constructor
            )
            expected.append(
                (
                    ids[0],
                    "Servo.__init__" if len(ids) == 1 else "DCMotor.__init__",
                    scope,
                )
            )
        elif operation in ("Servo.angle", "DCMotor.throttle"):
            expected.append(
                (
                    "servo18-g1" if operation == "Servo.angle" else "motor18-g2",
                    operation,
                    scope,
                )
            )
        else:
            output_id = (
                "servo18-g1"
                if operation == "servo_release"
                else "motor18-g2"
                if operation == "motor_release_positive"
                else "motor23-g1"
            )
            if operation == "motor_release_positive":
                expected.append(
                    ("motor23-g1", "sibling_before_request.get_value", scope)
                )
            expected.extend((output_id, call, scope) for call in cleanup)
            if operation == "motor_release_positive":
                expected.append(
                    ("motor23-g1", "sibling_after_request.get_value", scope)
                )
    require(
        [(e["output_id"], e["operation"], e["scope"]) for e in remote["events"]]
        == expected,
        "Exact finite installed caller order/scope required",
    )
    scopes = {phase["scope"]: phase for phase in remote["phases"]}
    for event in remote["events"]:
        phase = scopes[event["scope"]]
        require(
            phase["begin_ns"]
            <= event["begin_ns"]
            <= event["end_ns"]
            <= phase["stable_begin_ns"],
            "Caller event must remain inside its phase update boundary",
        )


def _validate_import_chip(remote, identity):
    record = remote.get("blinka_import_chip")
    require(
        frozen._fields(
            record,
            {
                "verified_chip_index": identity["gpiochip_index"],
                "opened": True,
                "closed": True,
                "hooks_restored": True,
                "claims_or_writes_permitted": False,
                "errors": [],
            },
        )
        and type(record.get("handle")) is int
        and record["handle"] >= 0,
        "Separately owned import-only lgpio chip must be restored and closed",
    )
    events = record.get("events")
    require(
        isinstance(events, list) and len(events) == 2,
        "Only one import-open and owned-close allowed; no line mutations",
    )
    opened, closed = events
    require(
        frozen._fields(
            opened,
            {
                "operation": "gpiochip_open",
                "chip_index": identity["gpiochip_index"],
                "handle": record["handle"],
                "status": "ok",
            },
        )
        and frozen._fields(
            closed,
            {
                "operation": "gpiochip_close",
                "handle": record["handle"],
                "status": "ok",
                "returncode": 0,
            },
        ),
        "Import-only lgpio handle event identity/actual-close mismatch",
    )
    for event in events:
        require(
            type(event.get("begin_ns")) is int
            and type(event.get("end_ns")) is int
            and remote["begin_ns"]
            <= event["begin_ns"]
            <= event["end_ns"]
            <= remote["end_ns"],
            "Import chip event interval mismatch",
        )
    require(
        opened["end_ns"] <= remote["phases"][0]["begin_ns"]
        and closed["begin_ns"] >= remote["phases"][-1]["readback_end_ns"]
        and closed["begin_ns"]
        >= max(
            e["end_ns"] for e in remote["events"] if e["operation"] == "PWMOut.deinit"
        ),
        "Import handle must open before consumers and close after all private outputs",
    )


def _validate_protocol(remote, records):
    phases, actions, events, shutdowns = (
        remote.get(key) for key in ("phases", "actions", "events", "shutdowns")
    )
    require(
        isinstance(phases, list) and len(phases) == len(helper.SEQUENCE),
        "Exact consumer phases required",
    )
    require(
        isinstance(actions, list) and len(actions) == 10,
        "All ten consumer actions required",
    )
    require(
        isinstance(events, list) and all(isinstance(e, dict) for e in events),
        "Consumer caller events required",
    )
    previous = remote["begin_ns"]
    for ordinal, event in enumerate(events):
        require(
            frozen._fields(event, {"ordinal": ordinal, "status": "ok"})
            and event.get("output_id") in records
            and frozen._fields(
                event,
                {
                    "gpio": records[event["output_id"]]["gpio"],
                    "generation": records[event["output_id"]]["generation"],
                },
            )
            and isinstance(event.get("scope"), str)
            and isinstance(event.get("operation"), str)
            and type(event.get("begin_ns")) is int
            and type(event.get("end_ns")) is int
            and previous <= event["begin_ns"] <= event["end_ns"] <= remote["end_ns"],
            "Chronological successful per-generation caller events required",
        )
        previous = event["end_ns"]
    constructors = [
        event for event in events if event["operation"] == "PWMOut.__init__"
    ]
    require(
        len(constructors) == 3, "All three public consumer PWM constructors required"
    )
    for event, (output_id, gpio, _generation, frequency) in zip(
        constructors, helper.OUTPUTS
    ):
        require(
            event["output_id"] == output_id
            and frozen._exact(
                event.get("arguments"),
                {
                    "attribute": "D" + str(gpio),
                    "id": gpio,
                    "class_module": helper.PIN_MODULE,
                    "frequency": frequency,
                    "duty_u16": 0,
                    "variable_frequency": True,
                },
            ),
            "Consumer constructor pin/frequency/default permission mismatch",
        )
    states, action_index, previous = {}, 0, remote["begin_ns"]

    def snapshots():
        result = [
            frozen._snapshot(output_id, state, records)
            for output_id, state in states.items()
        ]
        require(
            len({r["owned_request"]["fd"] for r in result}) == len(result),
            "Live consumer requests must have distinct FDs",
        )
        return result

    for index, (phase, spec) in enumerate(zip(phases, helper.SEQUENCE)):
        name, duration, operation, value = spec
        scope = f"{index:02d}_{name}"
        require(
            frozen._fields(
                phase,
                {
                    "index": index,
                    "name": name,
                    "scope": scope,
                    "duration_seconds": duration,
                    "operation": operation,
                    "value": value,
                },
            ),
            "Exact consumer phase/action/dwell mismatch",
        )
        clocks = [
            phase.get(key)
            for key in ("begin_ns", "stable_begin_ns", "end_ns", "readback_end_ns")
        ]
        require(
            all(type(v) is int for v in clocks)
            and previous
            <= clocks[0]
            <= clocks[1]
            < clocks[2]
            <= clocks[3]
            <= remote["end_ns"]
            and clocks[2] - clocks[1] >= round(duration * 1e9),
            "Consumer phase dwell/interval mismatch",
        )
        previous, before = clocks[-1], snapshots()
        if operation == "servo_initialize":
            states["servo18-g1"] = (50, 0)
        elif operation == "motor_initialize":
            states.update({"motor18-g2": (1000, 0), "motor23-g1": (1000, 0)})
        elif operation == "Servo.angle":
            states["servo18-g1"] = (50, protocol.servo_duty(value))
        elif operation == "DCMotor.throttle":
            positive, negative = protocol.motor_duties(value)
            states.update(
                {"motor18-g2": (1000, positive), "motor23-g1": (1000, negative)}
            )
        else:
            del states[
                "servo18-g1"
                if operation == "servo_release"
                else "motor18-g2"
                if operation == "motor_release_positive"
                else "motor23-g1"
            ]
        after = snapshots()
        require(
            frozen._exact(phase.get("api_state"), after)
            and frozen._exact(phase.get("api_state_end"), after),
            "Consumer native API state/request mismatch",
        )
        consumer = (
            {
                "kind": "Servo",
                "angle": protocol.servo_readback(
                    value if operation == "Servo.angle" else None
                ),
            }
            if index < 5
            else {
                "kind": "DCMotor",
                "throttle": value if operation == "DCMotor.throttle" else None,
                "decay_mode": 0,
            }
            if 6 <= index <= 12
            else None
        )
        for key in ("consumer_state", "consumer_state_end"):
            actual = phase.get(key)
            if consumer is None:
                require(
                    key in phase and actual is None,
                    "Released consumer must not read deinitialized PWM",
                )
            else:
                property_name = "angle" if consumer["kind"] == "Servo" else "throttle"
                require(
                    isinstance(actual, dict)
                    and set(actual) == set(consumer)
                    and actual.get("kind") == consumer["kind"]
                    and protocol.readback_matches(
                        actual.get(property_name), consumer[property_name]
                    )
                    and (
                        consumer["kind"] != "DCMotor"
                        or type(actual.get("decay_mode")) is int
                        and actual["decay_mode"] == 0
                    ),
                    "Genuine consumer quantized readback/default decay mismatch",
                )
        if operation in ("Servo.angle", "DCMotor.throttle"):
            action = actions[action_index]
            action_index += 1
            expected_readback = (
                protocol.servo_readback(value) if operation == "Servo.angle" else value
            )
            require(
                frozen._fields(
                    action,
                    {
                        "phase_index": index,
                        "operation": operation,
                        "value": value,
                        "status": "ok",
                    },
                )
                and frozen._exact(action.get("api_state_before"), before)
                and frozen._exact(action.get("api_state_after"), after)
                and protocol.readback_matches(
                    action.get("consumer_readback"), expected_readback
                )
                and type(action.get("begin_ns")) is int
                and type(action.get("end_ns")) is int
                and clocks[0] <= action["begin_ns"] <= action["end_ns"] <= clocks[1],
                "Consumer action/readback/native state receipt mismatch",
            )
            calls = [
                e for e in events if e["scope"] == scope and e["operation"] == operation
            ]
            expected_ids = (
                ["servo18-g1"]
                if operation == "Servo.angle"
                else ["motor18-g2", "motor23-g1"]
            )
            require(
                len(calls) == 1
                and frozen._exact(
                    calls[0].get("arguments"),
                    {"value": value, "output_ids": expected_ids},
                )
                and action["begin_ns"]
                <= calls[0]["begin_ns"]
                <= calls[0]["end_ns"]
                <= action["end_ns"],
                "Consumer caller operation must be bounded by its action",
            )
    require(
        isinstance(shutdowns, list) and len(shutdowns) == 3,
        "All private consumer shutdown receipts required",
    )
    for row, (output_id, index, sibling_id) in zip(
        shutdowns,
        (
            ("servo18-g1", 5, None),
            ("motor18-g2", 13, "motor23-g1"),
            ("motor23-g1", 14, None),
        ),
    ):
        phase = phases[index]
        require(
            frozen._fields(
                row,
                {
                    "output_id": output_id,
                    "scope": phase["scope"],
                    "reason": "sequence",
                    "sibling_id": sibling_id,
                    "errors": [],
                    "success": True,
                },
            )
            and type(row.get("begin_ns")) is int
            and type(row.get("end_ns")) is int
            and phase["begin_ns"]
            <= row["begin_ns"]
            <= row["end_ns"]
            <= phase["stable_begin_ns"],
            "Private consumer shutdown interval/error mismatch",
        )
        calls = [
            e
            for e in events
            if e["scope"] == phase["scope"] and e["output_id"] == output_id
        ]
        require(
            [e["operation"] for e in calls]
            == [
                "track_owned_request",
                "PWMOut.duty_cycle_zero",
                "low_settle",
                "owned_request.get_value",
                "PWMOut.deinit",
                "gpiod_line_info_released",
            ]
            and row["begin_ns"]
            <= calls[0]["begin_ns"]
            <= calls[-1]["end_ns"]
            <= row["end_ns"]
            and calls[2]["end_ns"] - calls[2]["begin_ns"] >= 100_000_000,
            "Full private low/read/deinit/release events required",
        )
        for key in ("sibling_before", "sibling_after"):
            actual = row.get(key)
            require(
                (key in row and actual is None)
                if sibling_id is None
                else isinstance(actual, dict)
                and type(actual.get("gpio_level")) is int
                and actual["gpio_level"] == 0
                and frozen._exact(
                    {k: v for k, v in actual.items() if k != "gpio_level"},
                    frozen._snapshot(sibling_id, (1000, 0), records),
                ),
                "Independent continuing motor sibling ownership/readback required",
            )


def capture_test(directory, remote_root, remote_python, manifest_path, plan_path):
    require(
        isinstance(remote_root, str) and re.fullmatch(helper.ROOT_PATTERN, remote_root),
        "Requires the isolated installed-consumers root",
    )
    require(
        remote_python == remote_root + "/venv/bin/python",
        "Requires exact fresh root/venv/bin/python",
    )
    manifest_path, plan_path = Path(manifest_path), Path(plan_path)
    require(
        manifest_path.name == MANIFEST_FILENAME
        and plan_path.name == PLAN_FILENAME
        and not manifest_path.is_symlink()
        and not plan_path.is_symlink(),
        "Requires new regular installed manifest and plan paths",
    )
    manifest_bytes, plan_bytes = manifest_path.read_bytes(), plan_path.read_bytes()
    manifest, plan = (
        read_json(manifest_bytes.decode("utf-8")),
        read_json(plan_bytes.decode("utf-8")),
    )
    hashes = validate_local_manifest(manifest)
    validate_plan(plan, manifest)
    local_sources = source_hashes()
    directory = Path(directory).absolute()
    require(
        directory == directory.resolve() and not directory.is_symlink(),
        "Capture output cannot traverse symlinks",
    )
    output = directory
    manifest_sha = hashlib.sha256(manifest_bytes).hexdigest()
    plan_sha = hashlib.sha256(plan_bytes).hexdigest()
    require(
        output.name in CAPTURES
        and plan["remote_root"] == remote_root
        and plan["remote_python"] == remote_python
        and plan["manifest_sha256"] == manifest_sha,
        "Capture name/root/interpreter/manifest must match frozen plan",
    )
    output.mkdir(parents=True, exist_ok=False)
    for name, data in (("manifest.json", manifest_bytes), ("plan.json", plan_bytes)):
        with (output / name).open("xb") as stream:
            stream.write(data)
    program, remote_manifest = (
        remote_root + "/" + helper.NEW_SOURCE,
        remote_root + "/" + MANIFEST_FILENAME,
    )
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([remote_python, "-I", program, "--manifest", remote_manifest]),
    ]
    remote, primary, logic_version = None, None, None
    evidence_errors, timing = [], {}
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            require(
                any(
                    device.device_id == DEVICE_ID and not device.is_simulation
                    for device in manager.get_devices()
                ),
                "Confirmed physical Logic8 analyzer unavailable",
            )
            logic_version = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[0, 1],
                digital_sample_rate=100_000_000,
                glitch_filters=[],
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as capture:
                try:
                    timing["lead_begin_ns"] = time.monotonic_ns()
                    time.sleep(0.5)
                    timing["lead_end_ns"] = time.monotonic_ns()
                    with (
                        (output / "remote.stdout").open("x") as stdout_file,
                        (output / "remote.stderr").open("x") as stderr_file,
                    ):
                        remote = subprocess.run(
                            command,
                            stdout=stdout_file,
                            stderr=stderr_file,
                            text=True,
                            check=False,
                            timeout=30,
                        )
                except BaseException as error:
                    # No fabricated process exit for a timeout or interruption.
                    primary = error
                finally:
                    for name, action in (
                        ("tail", lambda: time.sleep(0.2)),
                        ("stop", capture.stop),
                        (
                            "save_capture",
                            lambda: capture.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_binary",
                            lambda: capture.export_raw_data_binary(
                                str(output), digital_channels=[0, 1]
                            ),
                        ),
                    ):
                        try:
                            if name == "tail":
                                timing["tail_begin_ns"] = time.monotonic_ns()
                            action()
                            if name == "tail":
                                timing["tail_end_ns"] = time.monotonic_ns()
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:
        if primary is None:
            primary = error
        else:
            evidence_errors.append(f"acquisition: {type(error).__name__}: {error}")
    for name in ("remote.stdout", "remote.stderr"):
        try:
            if not (output / name).exists():
                _write(output, name, "")
        except BaseException as error:
            evidence_errors.append(f"{name}: {type(error).__name__}: {error}")
    actual_exit = None if remote is None else remote.returncode
    acquisition = {
        "mode": MODE,
        "backend": BACKEND,
        "remote_root": remote_root,
        "remote_python": remote_python,
        "remote_program": program,
        "remote_manifest": remote_manifest,
        "remote_command": command,
        "remote_returncode": actual_exit,
        "ssh_exit_unavailable_after_exception": remote is None,
        "plan_sha256": plan_sha,
        "manifest_sha256": manifest_sha,
        "preflight_receipt_sha256": plan["preflight_receipt_sha256"],
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "requested_channels": [0, 1],
        "requested_sample_rate_hz": 100_000_000,
        "requested_glitch_filters": [],
        "local_timing_ns": timing,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None
        if primary is None
        else f"{type(primary).__name__}: {primary}",
        "evidence_errors": evidence_errors,
    }
    _write(output, "acquisition.json", json.dumps(acquisition, indent=2) + "\n")
    result = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": MODE,
        "backend": BACKEND,
        "sequence_marker": SEQUENCE_MARKER,
        "helper_sha256": hashes[helper.NEW_SOURCE],
        "collector_sha256": digest(__file__),
        "source_manifest": manifest,
        "source_plan": plan,
        "collector_source_sha256": local_sources,
        "plan_sha256": plan_sha,
        "manifest_sha256": manifest_sha,
        "preflight_receipt_sha256": plan["preflight_receipt_sha256"],
        "remote_root": remote_root,
        "remote_python": remote_python,
        "remote_program": program,
        "remote_manifest": remote_manifest,
        "sample_rate_hz": 100_000_000,
        "glitch_filters": [],
        "logic_version": logic_version,
        "production_backend_unchanged": True,
        "outputs": [
            {"gpio": gpio, "saleae_channel": channel, "backend": BACKEND}
            for gpio, channel in ((18, 0), (23, 1))
        ],
        "remote": None,
        "remote_returncode": actual_exit,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "installed_blinka_dispatch_exercised": False,
        "whole_blinka_compatibility_proven": False,
        "actual_actuators_attached": False,
        "success_scope": "acquisition and installed board/pwmio genuine consumer API/private cleanup only; not waveform, actuators, parity or whole-Blinka compatibility",
    }
    try:
        if primary is not None or evidence_errors:
            raise RuntimeError(
                "Capture failure evidence retained: "
                + (acquisition["primary_error"] or "; ".join(evidence_errors))
            ) from primary
        require(
            type(actual_exit) is int and actual_exit == 0,
            "Installed consumer SSH did not actually exit0; raw evidence retained",
        )
        require(
            all(
                (output / name).is_file()
                and not (output / name).is_symlink()
                and (output / name).stat().st_size > 0
                for name in ("waveform.sal", "digital_0.bin", "digital_1.bin")
            ),
            "Missing regular SAL/raw PWM channel evidence",
        )
        result["remote"] = read_json((output / "remote.stdout").read_text())
        validate_remote(result["remote"], manifest)
        require(
            result["remote"].get("manifest_path") == remote_manifest
            and result["remote"].get("python_executable") == remote_python,
            "Remote manifest/interpreter differs from acquisition",
        )
        result["installed_blinka_dispatch_exercised"] = True
        result["collection_success"] = True
    except BaseException as error:
        result["receipt_validation_error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        _write(output, "results.json", json.dumps(result, indent=2) + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--remote-python", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    args = parser.parse_args(argv)
    result = capture_test(
        args.directory, args.remote_root, args.remote_python, args.manifest, args.plan
    )
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "mode": MODE,
                "collection_success": result["collection_success"],
                "waveform_accepted": None,
                "parity_pass": None,
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
