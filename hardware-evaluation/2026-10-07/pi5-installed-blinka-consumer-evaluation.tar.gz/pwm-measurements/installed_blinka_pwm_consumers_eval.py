"""Lab-only real installed Blinka dispatch with passive logic probes, no actuators.

The private test wheel dispatches real pwmio.PWMOut to the unchanged draft.
Only the import-time lgpio chip-open/line-mutation boundary is instrumented;
public PWMOut, genuine board Pins and consumer classes are not wrapped/patched.
This finite functional experiment is not a whole-Blinka or waveform/parity verdict.
Unknown freshly built runtime pins below deliberately prevent physical execution.
"""

import argparse
import hashlib
import importlib
import importlib.machinery
import importlib.metadata
import importlib.util
import json
import os
import re
import signal
import sys
import time
from contextlib import contextmanager
from pathlib import Path

ROOT_PATTERN = r"/tmp/blinka-pwm-installed-consumers\.[A-Za-z0-9]{6}"
if __name__ == "__main__":
    # -I intentionally omits the script directory. Add only this validated
    # isolated helper root, never a package/distro/PYTHONPATH fallback.
    helper_path = Path(__file__)
    if (
        re.fullmatch(ROOT_PATTERN, str(helper_path.parent)) is None
        or helper_path.resolve(strict=True) != helper_path
    ):
        raise SystemExit(
            "Only the fresh isolated installed-consumers root is authorized"
        )
    sys.path.insert(0, str(helper_path.parent))

import native_pwm_consumers_eval as protocol  # noqa: E402 - validated -I helper root

dual, core = protocol.dual, protocol.core
SEQUENCE, OUTPUTS = protocol.SEQUENCE, protocol.OUTPUTS
MODE = "installed-blinka-consumer-passive-probes"
SEQUENCE_MARKER = "installed-blinka-servo-dcmotor-v1"
BACKEND = protocol.BACKEND
NEW_SOURCE = "installed_blinka_pwm_consumers_eval.py"
MAX_RUN_SECONDS = protocol.MAX_RUN_SECONDS
PIN_MODULE = "adafruit_blinka.microcontroller.generic_linux.lgpio_pin"
BLINKA_FILES = (
    "__init__.py",
    "agnostic/__init__.py",
    "importing.py",
    "platform_dependencies.py",
    "board/__init__.py",
    "board/raspberrypi/__init__.py",
    "board/raspberrypi/raspi_5.py",
    "microcontroller/__init__.py",
    "microcontroller/bcm2712/__init__.py",
    "microcontroller/bcm2712/pin.py",
    "microcontroller/generic_linux/__init__.py",
    "microcontroller/generic_linux/lgpio_pin.py",
)
FROZEN_PINS = {
    **protocol.SOURCE_PINS,
    "native_pwm_consumers_eval.py": "db6d32ec066a7683fd85613f638f60a7e13e7a736cea362e9fe4b751641b54dc",
    dual.base.PACKAGE
    + "/__init__.py": "b601ad1630ea2889a46b34f8a95fecb5a3462a1a084ad306c39011c0d2d430a9",
    dual.base.PACKAGE
    + "/_software.py": "f0f35841de24661ede3cffd9397ebbf9734be7c58ef8930e1f114c1dc8dadd2e",
}
# Parent fills these only after independently checking the fresh wheel/venv.
# RUNTIME_PINS must contain every inventoried non-frozen source except this file.
RUNTIME_PINS = {
    "adafruit_blinka_raspberry_pi_pwm/_native.so": "86e3c5f580c0c2599f29e12c0846189543726a73544cbe93a84a7b45cbb8b214",
    "gpiod/version.py": "d943c6733baac8a7af8d29a58cb3377106c8b5e8f915b3be014bfd9b232439ff",
    "gpiod/line_settings.py": "6c313e34d32d2c1ec1206f2ede6b581c904230f896e5eae1bbc3054dee61ba87",
    "gpiod/line_request.py": "52f1e83cdf5e0ce26b68b3bee89bf1de20b7439fe1a3460c4a8bc043ec632d2d",
    "gpiod/line_info.py": "09bb5f23f45eb914d4088687ba5b9c3ef644c5109ac9b33848c5bbef12893720",
    "gpiod/line.py": "187e0e31a771a53b8e94a54b65e9136e053d0c367a441734d9c8e38637e1399f",
    "gpiod/info_event.py": "9e079a0211227fe7950ecdd476193dbf66ee9083eb972c11b7e7e552f3e5f663",
    "gpiod/exception.py": "9068b11cb2684ef0b2d684622c94dd91854fd22a1793ceebc47809a1b1ec4f0a",
    "gpiod/edge_event.py": "db176ef77ba6e03c8aad06c1f4290b10065d8225411f2c6791538b886842f551",
    "gpiod/chip_info.py": "6cff3d7569faa46361484fbb4b311c8da6b9cc9e5e19d1e6ac46e443417960cd",
    "gpiod/chip.py": "058af8ea720a9e34bfbccaaccc1ec34c29b985e54be5277e224f64e211d472d0",
    "gpiod/_internal.py": "0eb45b2a251db2419e6d7086b886bec3f3f5ebbcacba5c84f5748e25cc37e4ac",
    "gpiod/__init__.py": "44c7c0a058e3866b6b295aadd3c98e10695eaf4c2dd6d001e9fb626aec5d7290",
    "gpiod/_ext.so": "8741505369ed38c36891ecb7fddf888b4858ee78d377996f8134764283be8dfa",
    "adafruit_blinka/__init__.py": "75b671f636199bf2bd8c173150e1edadf6865781e70b33e5ff1d208fa4d817d8",
    "adafruit_blinka/agnostic/__init__.py": "d9906c66cb59d23f4dda30b7875e919487a060cea92e70791b7089a10661e0e1",
    "adafruit_blinka/importing.py": "8c51f1e602257132463901d2cd906e2861e0d84dda4a1f22b654943fc1b60a88",
    "adafruit_blinka/platform_dependencies.py": "7bbaa8ad2ddf4ef6edc4b1b2147b306b3480d1e3d3aba8d59c3068591f1ee088",
    "adafruit_blinka/board/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "adafruit_blinka/board/raspberrypi/__init__.py": "6a96746f4bb221c6fc4050a7e5697c2066110312e713e0f165e94987f418fe70",
    "adafruit_blinka/board/raspberrypi/raspi_5.py": "3aa78ba8144252b7d5f81d0111a859a9480de89b9d153040ae373ef5db285ec7",
    "adafruit_blinka/microcontroller/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "adafruit_blinka/microcontroller/bcm2712/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "adafruit_blinka/microcontroller/bcm2712/pin.py": "f218ea35a3ef220570c3effe905bdccd6da0a1aa00d0f273c93eac85691107ed",
    "adafruit_blinka/microcontroller/generic_linux/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "adafruit_blinka/microcontroller/generic_linux/lgpio_pin.py": "f836d4e5342639b0fa4348b8600fbc6b6401d79ce138ccbda2886bc028cdb413",
    "board.py": "4214c3188ddb41930219b12872fa0fdf8764a66192717a291ba4fe093e2f1bec",
    "pwmio.py": "e1527231dab797eef28b6f2acc2c08a1e404a3cb377cf387e23a71347b39e87d",
    "lgpio.py": "a2e6e04314818d757789d9e49060de5041158125f76bc1b40f39bca1c6938588",
    "_lgpio.so": "2ff8f2483440015b0d2f90b791e055bfccce8968771c521f55db31939a827abf",
    "board_imports.json": "a1a9af690b5d665f9286645c0128b010740d5893e951a6472b1d3308f6089af4",
    "adafruit_platformdetect/revcodes.py": "4a7935d79424417accfef0ac3a5a28535c4c5fd6d641042f7a0c5d94f978ae2b",
    "adafruit_platformdetect/chip.py": "d2ccc64550f8a046534e1519b960ab67ba73cd375313cbcfa975d21fc3f1645e",
    "adafruit_platformdetect/board.py": "60101f5592510678c396beb13c1dc209c6b13b96146067cd99bd0b955d485f3d",
    "adafruit_platformdetect/__init__.py": "d77f15eaeae255ac3ccc09fb6748ac275c2af7f50f9aa38a4fc2395c22748d23",
    "adafruit_platformdetect/constants/chips.py": "500ab531e26d5ba476c058cc61c7192556a8c65a8e436724e9d6c52c741f4be9",
    "adafruit_platformdetect/constants/boards.py": "034a3a166097786c003964a78c9e268e01284e6fb820bc2be989ec1b4a84502f",
    "adafruit_platformdetect/constants/__init__.py": "ef722d1b0c85ed9fc0a1a49a48c405f68a0bb84c905ce57566ff72a8053c1b89",
    "packaging/version.py": "558b2fb50fd198c660a4c082f96b8919c565911b6b4b6e07f34b6b60c074be97",
    "packaging/utils.py": "a13742cd9994eeca5adfb0249d126408c478026eb1f48cb97afbf2fe9f28ecc6",
    "packaging/tags.py": "0e717a082a79620d79cf0321b420df15593c4916fcda03c27cb9d82e07ef5d6e",
    "packaging/specifiers.py": "661ad31ddf45ffb861d2626734f4e3d66966029b8fdb79586bb105825d8d9d59",
    "packaging/requirements.py": "459476eb2107fe30e6b1310051a5bdb44c7d3b7f78e0e87bada268282cba62f5",
    "packaging/ranges.py": "b4781ce913e5dff9e07906f20585c54c3028e1f7ff56341828e79d522ddbfab6",
    "packaging/pylock.py": "1bce0a9fe63e42b87e8ced05da272baf16a68aa704b3718405e2735a6112467c",
    "packaging/metadata.py": "934149f420a5449e6f376aa61d6f26a0823eb82cc7c6a1c8cde5aa7be43d0f63",
    "packaging/markers.py": "6cbe860d35d98d2b599e7f0ec73feab124e015711b30be9045e678c92940d9cc",
    "packaging/errors.py": "ea17c461701ff2ffc817ae7e94569d24e30889e04fdb120ab721178c6d67188b",
    "packaging/direct_url.py": "843baa95d04cbb49288de9d9fd77ee946e862cb603123e7e46a69e171fa7d06b",
    "packaging/dependency_groups.py": "5309cc564ca3022dfb594816e9d593bb09cdf34208c1fb8c5ec9afb6c670278c",
    "packaging/_tokenizer.py": "cc25e57c0d564c89e15073471d6e1c264299ca946fb17c0e1e4af54ef7713ee6",
    "packaging/_structures.py": "eb48d16c5efca7ccf930a9cd77a700a6b80e69d0891d5d03966526441a8565cb",
    "packaging/_ranges.py": "b7b595f2e692aeb3697c545b85c24cbbcb4552f2adc6d9059aa82d0877e816b7",
    "packaging/_parser.py": "88a348115209327497e453b635e5db099fd592f9335d710c7313b29cdb30c50c",
    "packaging/_musllinux.py": "0328fb827b1170c77df4c107d49be8df8d37262103490a61e8acad8a2f9cadff",
    "packaging/_manylinux.py": "5b6e84324c42538ab4cdb148e2430fdba36f04427b0efda55bea083a35fa6136",
    "packaging/_elffile.py": "1f025f54c573f1a85740c4fbd908cc1d1fb0c177c14377ebf5f09d6cd5368780",
    "packaging/__init__.py": "6e758cdd0028b2cad74c739b9adc9c9f06f054932306280b878bfe59d39219b5",
    "packaging/licenses/_spdx.py": "596ec35e2ca0ebcba9fd8343ff0a51625af548786257815f24b41f7e08613314",
    "packaging/licenses/__init__.py": "590d12eee73ddbec53b4e9ee5bfc64d9cb3aacb4940e8ebcba260757ce56740b",
}
DISTRIBUTION_VERSIONS = {
    "Adafruit-Blinka": "9.0.5.dev74+pwmeval.beb49bf",
    "Adafruit-PlatformDetect": "3.89.1",
    "Adafruit-Blinka-Raspberry-Pi-PWM": "0.0.1.dev0",
    "adafruit-circuitpython-motor": "3.5.0",
    "adafruit-lgpio": "0.2.2.0",
    "gpiod": "2.5.0",
    "packaging": "26.3",
}
DISTRIBUTIONS = (
    "Adafruit-Blinka",
    "Adafruit-PlatformDetect",
    "Adafruit-Blinka-Raspberry-Pi-PWM",
    "adafruit-circuitpython-motor",
    "adafruit-lgpio",
    "gpiod",
    "packaging",
)
MUTATIONS = (
    "gpiochip_close",
    "gpio_free",
    "gpio_claim_input",
    "gpio_claim_output",
    "gpio_claim_alert",
    "gpio_write",
    "group_claim_input",
    "group_claim_output",
    "group_free",
    "group_write",
    "tx_pwm",
    "tx_pulse",
    "tx_servo",
    "tx_wave",
)


def error_text(error):
    return f"{type(error).__name__}: {error}"


def validate_manifest(manifest):
    if RUNTIME_PINS is None or DISTRIBUTION_VERSIONS is None:
        raise core.BenchError("Fresh installed wheel/runtime source pins not frozen")
    if (
        not isinstance(RUNTIME_PINS, dict)
        or not RUNTIME_PINS
        or set(RUNTIME_PINS) & (set(FROZEN_PINS) | {NEW_SOURCE})
        or not isinstance(DISTRIBUTION_VERSIONS, dict)
        or any(not isinstance(v, str) or not v for v in DISTRIBUTION_VERSIONS.values())
    ):
        raise core.BenchError("Invalid frozen runtime source/version pins")
    keys = set(FROZEN_PINS) | set(RUNTIME_PINS) | {NEW_SOURCE}
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
        or manifest.get("distribution_versions") != DISTRIBUTION_VERSIONS
        or not isinstance(manifest.get("source_sha256"), dict)
        or not isinstance(manifest.get("source_paths"), dict)
        or set(manifest["source_sha256"]) != keys
        or set(manifest["source_paths"]) != keys
        or set(DISTRIBUTION_VERSIONS) != set(DISTRIBUTIONS)
    ):
        raise core.BenchError(
            "Exact installed selected-source/version manifest required"
        )
    hashes = manifest["source_sha256"]
    if any(
        not isinstance(v, str) or not re.fullmatch(r"[0-9a-f]{64}", v)
        for v in hashes.values()
    ):
        raise core.BenchError("Malformed selected-source SHA256")
    if any(hashes[k] != v for k, v in {**FROZEN_PINS, **RUNTIME_PINS}.items()):
        raise core.BenchError("Frozen installed/native/consumer/helper source mismatch")
    return hashes


def load_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise core.BenchError("Duplicate manifest key: " + key)
            result[key] = value
        return result

    manifest = json.loads(Path(path).read_text(), object_pairs_hook=pairs)
    validate_manifest(manifest)
    return manifest


def approved_manifest_path(path):
    path = Path(path)
    if (
        not path.is_absolute()
        or re.fullmatch(ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", str(path)) is None
        or path.resolve(strict=True) != path
        or path.parent != Path(__file__).resolve().parent
    ):
        raise core.BenchError(
            "Manifest/helper must share a fresh isolated root without symlinks"
        )
    return path


def fresh_process(root, receipt):
    forbidden = [
        name
        for name in sys.modules
        if name in ("board", "pwmio", "lgpio", "_lgpio")
        or name.startswith(
            ("adafruit_blinka", "adafruit_platformdetect", "adafruit_motor")
        )
    ]
    receipt["inherited_environment"] = {
        name: value
        for name, value in os.environ.items()
        if name.startswith("BLINKA_") or name in ("PYTHONPATH", "PYTHONHOME")
    }
    if forbidden:
        raise core.BenchError(
            "Refusing preexisting board/pwmio/Pin/detection/consumer/lgpio modules: "
            + ",".join(forbidden)
        )
    if receipt["inherited_environment"]:
        raise core.BenchError("Refusing inherited platform/Python/scheduler overrides")
    if (
        sys.implementation.name != "cpython"
        or sys.platform != "linux"
        or sys.executable != str(root / "venv/bin/python")
        or not sys.flags.isolated
    ):
        raise core.BenchError(
            "Require isolated CPython in the exact fresh root/venv/bin/python"
        )
    if any(
        stream is not None and stream.isatty() for stream in (sys.stdin, sys.stdout)
    ):
        raise core.BenchError(
            "Require non-TTY input/output: Blinka must not offer runtime pip installation"
        )
    receipt["python_executable"] = sys.executable
    receipt["isolated_python"] = True
    receipt["noninteractive_no_runtime_installs"] = True


def origin(name):
    spec = importlib.util.find_spec(name)
    if spec is None or spec.origin is None:
        raise core.BenchError("Missing installed source: " + name)
    return Path(spec.origin)


def extension(package, stem):
    paths = list(
        dict.fromkeys(
            package / (stem + suffix)
            for suffix in importlib.machinery.EXTENSION_SUFFIXES
            if (package / (stem + suffix)).is_file()
        )
    )
    if len(paths) != 1:
        raise core.BenchError("Require one ABI-compatible extension: " + stem)
    return paths[0]


def source_inventory(root):
    paths = {key: root / key for key in FROZEN_PINS if "/" not in key}
    paths[NEW_SOURCE] = Path(__file__)
    native = origin(dual.base.PACKAGE).parent
    gpiod = origin("gpiod").parent
    paths.update(
        {
            dual.base.PACKAGE + "/" + name: native / name
            for name in ("__init__.py", "_software.py")
        }
    )
    paths[dual.base.PACKAGE + "/_native.so"] = extension(native, "_native")
    paths.update(
        {"gpiod/" + str(path.relative_to(gpiod)): path for path in gpiod.rglob("*.py")}
    )
    paths["gpiod/_ext.so"] = extension(gpiod, "_ext")
    paths.update(protocol.consumer_inventory())
    blinka = origin("adafruit_blinka").parent
    paths.update({"adafruit_blinka/" + name: blinka / name for name in BLINKA_FILES})
    for name in ("board", "pwmio", "lgpio", "_lgpio"):
        paths[name + (".so" if name == "_lgpio" else ".py")] = origin(name)
    paths["board_imports.json"] = paths["board.py"].with_name("board_imports.json")
    # Pin every Python source in these small detection/requirements packages,
    # including package initializers and dynamically selected detection helpers.
    for name in ("adafruit_platformdetect", "packaging"):
        package = origin(name).parent
        paths.update(
            {
                name + "/" + str(path.relative_to(package)): path
                for path in package.rglob("*.py")
            }
        )
    validate_source_paths(root, paths)
    return paths


def validate_source_paths(root, paths):
    for key, path in paths.items():
        if (
            not path.is_absolute()
            or path.resolve(strict=True) != path
            or not path.is_file()
        ):
            raise core.BenchError(
                "Selected source must be a regular non-symlink file: " + key
            )
        expected = (
            root if "/" not in key and key.endswith("_eval.py") else root / "venv"
        )
        if key == NEW_SOURCE:
            expected = root
        if expected == root and path != root / key:
            raise core.BenchError("Selected helper outside fresh isolated root: " + key)
        try:
            path.relative_to(expected)
        except ValueError as error:
            raise core.BenchError(
                "Selected installed source outside fresh venv: " + key
            ) from error


def inspect_sources(root, manifest, receipt):
    paths = source_inventory(root)
    for module in (protocol, dual, dual.native, dual.base, dual.base.baseline, core):
        if Path(module.__file__) != paths[Path(module.__file__).name]:
            raise core.BenchError("Executed frozen helper origin mismatch")
    actual = {
        key: hashlib.sha256(path.read_bytes()).hexdigest()
        for key, path in paths.items()
    }
    receipt["source_paths"] = {key: str(path) for key, path in paths.items()}
    receipt["source_sha256"] = actual
    if (
        actual != manifest["source_sha256"]
        or receipt["source_paths"] != manifest["source_paths"]
    ):
        raise core.BenchError("Installed selected-source bytes/origins mismatch")
    versions = {}
    for name in DISTRIBUTIONS:
        distribution = importlib.metadata.distribution(name)
        try:
            Path(distribution.locate_file("")).resolve(strict=True).relative_to(
                root / "venv"
            )
        except ValueError as error:
            raise core.BenchError(
                "Distribution metadata outside fresh venv: " + name
            ) from error
        versions[name] = distribution.version
    receipt["distribution_versions"] = versions
    if versions != DISTRIBUTION_VERSIONS:
        raise core.BenchError("Installed distribution versions mismatch")
    return paths


class ImportChip:
    """Only the handle returned to this fresh board import belongs to this scope."""

    def __init__(self, library, identity, guard, receipt):
        self.library, self.identity, self.guard, self.receipt = (
            library,
            identity,
            guard,
            receipt,
        )
        self.originals, self.handle = {}, None
        self.close_function = library.gpiochip_close
        self.record = {
            "verified_chip_index": identity["gpiochip_index"],
            "handle": None,
            "opened": False,
            "closed": False,
            "hooks_restored": False,
            "claims_or_writes_permitted": False,
            "events": [],
            "errors": [],
        }
        receipt["blinka_import_chip"] = self.record

    def open(self, chip):
        event = {
            "operation": "gpiochip_open",
            "chip_index": chip,
            "begin_ns": time.monotonic_ns(),
        }
        try:
            if (
                type(chip) is not int
                or chip != self.identity["gpiochip_index"]
                or self.handle is not None
            ):
                raise core.BenchError(
                    "Blinka import must open the verified RP1 index exactly once"
                )
            with self.guard.atomic():
                handle = self.originals["gpiochip_open"](chip)
                if type(handle) is not int or handle < 0:
                    raise core.BenchError("Invalid private lgpio import handle")
                self.handle = handle
                self.record.update(handle=handle, opened=True)
                event.update(status="ok", handle=handle)
                return handle
        except BaseException as error:
            event.update(status="error", error=error_text(error))
            raise
        finally:
            event["end_ns"] = time.monotonic_ns()
            self.record["events"].append(event)

    def deny(self, name):
        def blocked(*_args, **_kwargs):
            self.record["events"].append(
                {
                    "operation": name,
                    "status": "rejected",
                    "begin_ns": time.monotonic_ns(),
                    "end_ns": time.monotonic_ns(),
                }
            )
            raise core.BenchError(
                "Blinka board import may not claim/free/drive/close GPIO: " + name
            )

        return blocked

    @contextmanager
    def hooks(self):
        # Save first; restore even a partially installed hook set.
        names = ("gpiochip_open", *MUTATIONS)
        self.originals = {
            name: getattr(self.library, name)
            for name in names
            if hasattr(self.library, name)
        }
        try:
            with self.guard.atomic():
                for name in self.originals:
                    setattr(
                        self.library,
                        name,
                        self.open if name == "gpiochip_open" else self.deny(name),
                    )
            yield
        finally:
            with self.guard.cleanup():
                for name, function in self.originals.items():
                    setattr(self.library, name, function)
                self.record["hooks_restored"] = all(
                    getattr(self.library, name) is function
                    for name, function in self.originals.items()
                )

    def close(self):
        if self.handle is None or self.record["closed"]:
            return
        event = {
            "operation": "gpiochip_close",
            "handle": self.handle,
            "begin_ns": time.monotonic_ns(),
        }
        with self.guard.cleanup():
            try:
                result = self.close_function(self.handle)
                event["returncode"] = result
                if type(result) is not int or result != 0:
                    raise core.BenchError(
                        "Private import chip close did not return zero"
                    )
                self.record["closed"] = True
                event["status"] = "ok"
            except BaseException as error:
                event.update(status="error", error=error_text(error))
                text = "Blinka import chip close: " + error_text(error)
                self.record["errors"].append(text)
                self.receipt["cleanup_errors"].append(text)
            finally:
                event["end_ns"] = time.monotonic_ns()
                self.record["events"].append(event)


def verify_origins(paths):
    for name, module in list(sys.modules.items()):
        key = None
        if name in ("board", "pwmio", "lgpio", "_lgpio"):
            key = name + (".so" if name == "_lgpio" else ".py")
        elif name == dual.base.PACKAGE:
            key = name + "/__init__.py"
        elif name.startswith(
            (
                "adafruit_blinka.",
                "adafruit_platformdetect.",
                "packaging.",
                "adafruit_motor.",
                "gpiod.",
                dual.base.PACKAGE + ".",
            )
        ) or name in (
            "adafruit_blinka",
            "adafruit_platformdetect",
            "packaging",
            "adafruit_motor",
            "gpiod",
        ):
            filename = getattr(module, "__file__", None)
            candidates = [key for key, path in paths.items() if str(path) == filename]
            if len(candidates) != 1:
                raise core.BenchError(
                    "Loaded unpinned installed source/origin: " + name
                )
            key = candidates[0]
        if key is not None and (
            key not in paths or getattr(module, "__file__", None) != str(paths[key])
        ):
            raise core.BenchError("Loaded module origin mismatch: " + name)


def installed_api(paths, native_module, import_chip, receipt):
    with import_chip.hooks():
        board = importlib.import_module("board")
        pwmio = importlib.import_module("pwmio")
        pin_module = importlib.import_module(PIN_MODULE)
        bcm_pins = importlib.import_module(
            "adafruit_blinka.microcontroller.bcm2712.pin"
        )
        raspi_pins = importlib.import_module(
            "adafruit_blinka.board.raspberrypi.raspi_5"
        )
        agnostic = importlib.import_module("adafruit_blinka.agnostic")
        servo = importlib.import_module("adafruit_motor.servo")
        motor = importlib.import_module("adafruit_motor.motor")
        verify_origins(paths)
        if (
            not agnostic.detector.board.any_raspberry_pi_5_board
            or not agnostic.detector.board.any_raspberry_pi
            or agnostic.chip_id != "BCM2XXX"
            or agnostic.board_id != "RASPBERRY_PI_5"
        ):
            raise core.BenchError(
                "Installed Blinka must detect genuine Pi5/BCM2712 without overrides"
            )
        if (
            pwmio.PWMOut is not native_module.PWMOut
            or servo.PWMOut is not pwmio.PWMOut
            or motor.PWMOut is not pwmio.PWMOut
        ):
            raise core.BenchError(
                "Real installed pwmio/consumer PWMOut dispatch identity mismatch"
            )
        if pin_module.CHIP != import_chip.handle or not import_chip.record["opened"]:
            raise core.BenchError("Real Pin module does not hold the owned import chip")
        if any(
            type(getattr(board, "D" + str(gpio))) is not pin_module.Pin
            or type(getattr(board, "D" + str(gpio)).id) is not int
            or getattr(board, "D" + str(gpio)).id != gpio
            or getattr(board, "D" + str(gpio)) is not getattr(bcm_pins, "D" + str(gpio))
            or getattr(board, "D" + str(gpio))
            is not getattr(raspi_pins, "D" + str(gpio))
            for gpio in (18, 23)
        ):
            raise core.BenchError(
                "Real board.D18/D23 must be unchanged genuine Pin objects"
            )
        if any(
            getattr(module, "__version__", None) != protocol.MOTOR_VERSION
            for module in (servo, motor)
        ):
            raise core.BenchError("Genuine consumer version mismatch")
        receipt["installed_dispatch"] = {
            "real_board_used": True,
            "real_pwmio_used": True,
            "virtual_pwmio_export_used": False,
            "unwrapped_public_pwm_objects": True,
            "pwmout_identity_verified": True,
            "board_id": agnostic.board_id,
            "chip_id": agnostic.chip_id,
            "pin_class_module": pin_module.Pin.__module__,
            "pin_ids": [18, 23],
        }
        receipt["consumers"] = {
            "version": protocol.MOTOR_VERSION,
            "servo": {
                "actuation_range": 180,
                "min_pulse_us": 1000,
                "max_pulse_us": 2000,
            },
            "motor": {
                "decay_mode": motor.FAST_DECAY,
                "throttle_zero_is_both_high_brake": True,
            },
        }
        return board, pwmio, servo, motor


class Owner(protocol.Owner):
    def __init__(self, library, identity, guard, receipt, output_id, board):
        super().__init__(library, identity, guard, receipt, output_id)
        self.board = board
        self.pin = getattr(board, "D" + str(self.gpio))
        self.pin_class = type(self.pin)
        self.pin_state = dict(vars(self.pin))
        self.record["real_board_pin"] = {
            "attribute": "D" + str(self.gpio),
            "id": self.gpio,
            "class_module": self.pin_class.__module__,
        }

    def verify_pin(self):
        if (
            getattr(self.board, "D" + str(self.gpio)) is not self.pin
            or type(self.pin) is not self.pin_class
            or type(self.pin.id) is not int
            or self.pin.id != self.gpio
            or vars(self.pin) != self.pin_state
        ):
            raise core.BenchError("Genuine board Pin identity/id changed")

    def construct(self, pwm_class):
        self.verify_pin()
        chip, line = self.call(
            "gpiod_line_info_preclaim",
            lambda: dual.inspect_line(self.library, self.identity, self.gpio),
        )
        self.record.update(
            chip_info=chip, preclaim_line_info=line, read_only_chip_closed=True
        )
        if line["used"] or line["consumer"] not in (None, ""):
            raise core.BenchError(
                "Fresh unused GPIO required; never borrow another request"
            )
        self.pwm = pwm_class.__new__(pwm_class)
        with self.guard.atomic():
            self.call(
                "PWMOut.__init__",
                lambda: self.pwm.__init__(
                    self.pin,
                    frequency=self.initial_frequency,
                    duty_cycle=0,
                    variable_frequency=True,
                ),
                {
                    **self.record["real_board_pin"],
                    "frequency": self.initial_frequency,
                    "duty_u16": 0,
                    "variable_frequency": True,
                },
            )
            self.verify_pin()
            if not self.track_request():
                raise core.BenchError("Native PWM returned without a private request")
            level = self.call(
                "initial_request.get_value", lambda: self.request().get_value(self.gpio)
            )
            self.record["initial_low_confirmed"] = (
                level == self.library.line.Value.INACTIVE
            )
            self.record["initial_readback"] = {
                "gpio_level": getattr(level, "value", None),
                "inactive": self.record["initial_low_confirmed"],
            }
            if not self.record["initial_low_confirmed"]:
                raise core.BenchError("New private PWM request did not read inactive")

    def snapshot(self, read_level=False, boundary="sibling"):
        self.verify_pin()
        return super().snapshot(read_level, boundary)


def run_protocol(
    library, pwmio, board, servo_module, motor_module, identity, guard, receipt, owners
):
    servo = motor = None

    def consumer_state():
        return (
            {"kind": "Servo", "angle": servo.angle}
            if servo
            else {
                "kind": "DCMotor",
                "throttle": motor.throttle,
                "decay_mode": motor.decay_mode,
            }
            if motor
            else None
        )

    for index, (name, duration, operation, value) in enumerate(SEQUENCE):
        scope = f"{index:02d}_{name}"
        phase = {
            "index": index,
            "name": name,
            "scope": scope,
            "duration_seconds": duration,
            "operation": operation,
            "value": value,
            "begin_ns": time.monotonic_ns(),
        }
        for owner in owners.values():
            owner.scope = scope
        if operation.endswith("initialize"):
            ids = (
                ("servo18-g1",)
                if operation == "servo_initialize"
                else ("motor18-g2", "motor23-g1")
            )
            for output_id in ids:
                owner = Owner(library, identity, guard, receipt, output_id, board)
                owners[output_id] = owner
                owner.scope = scope
                owner.construct(pwmio.PWMOut)
                dual.active_snapshots(owners)
            if operation == "servo_initialize":
                servo = owner.call(
                    "Servo.__init__",
                    lambda: servo_module.Servo(
                        owner.pwm, actuation_range=180, min_pulse=1000, max_pulse=2000
                    ),
                    {
                        "actuation_range": 180,
                        "min_pulse_us": 1000,
                        "max_pulse_us": 2000,
                    },
                )
            else:
                motor = owners["motor18-g2"].call(
                    "DCMotor.__init__",
                    lambda: motor_module.DCMotor(
                        owners["motor18-g2"].pwm, owners["motor23-g1"].pwm
                    ),
                    {"output_ids": list(ids), "default_decay_mode": 0},
                )
                if motor.decay_mode != motor_module.FAST_DECAY:
                    raise core.BenchError("Unexpected genuine motor default decay mode")
        elif operation in ("Servo.angle", "DCMotor.throttle"):
            protocol.run_action(
                owners["servo18-g1" if servo else "motor18-g2"],
                servo if servo else motor,
                operation,
                value,
                index,
                owners,
                receipt,
            )
        else:
            output_id = (
                "servo18-g1"
                if operation == "servo_release"
                else "motor18-g2"
                if operation == "motor_release_positive"
                else "motor23-g1"
            )
            with guard.atomic():
                owners[output_id].cleanup(
                    owners.get("motor23-g1")
                    if operation == "motor_release_positive"
                    else None,
                    "sequence",
                )
                if not receipt["shutdowns"][-1]["success"]:
                    raise core.BenchError("Consumer independent shutdown failed")
            servo = None if operation == "servo_release" else servo
            motor = None if operation.startswith("motor_release") else motor
        phase.update(
            stable_begin_ns=time.monotonic_ns(),
            api_state=dual.active_snapshots(owners),
            consumer_state=consumer_state(),
        )
        time.sleep(duration)
        phase.update(
            end_ns=time.monotonic_ns(),
            api_state_end=dual.active_snapshots(owners),
            consumer_state_end=consumer_state(),
            readback_end_ns=time.monotonic_ns(),
        )
        receipt["phases"].append(phase)


def validate_actions(receipt):
    expected = [
        (i, op, value)
        for i, (_name, _duration, op, value) in enumerate(SEQUENCE)
        if op in ("Servo.angle", "DCMotor.throttle")
    ]
    if len(receipt["actions"]) != len(expected):
        raise core.BenchError("Exact ten genuine consumer actions required")
    for action, (index, operation, value) in zip(receipt["actions"], expected):
        duties = (
            [protocol.servo_duty(value)]
            if operation == "Servo.angle"
            else list(protocol.motor_duties(value))
        )
        readback = (
            protocol.servo_readback(value) if operation == "Servo.angle" else value
        )
        states = action.get("api_state_after", [])
        if (
            action.get("phase_index") != index
            or action.get("operation") != operation
            or action.get("value") != value
            or action.get("status") != "ok"
            or not protocol.readback_matches(action.get("consumer_readback"), readback)
            or [row["duty_u16"] for row in states] != duties
            or [row["frequency"] for row in states]
            != ([50] if operation == "Servo.angle" else [1000, 1000])
        ):
            raise core.BenchError("Genuine consumer action/API readback mismatch")


def experiment(manifest_path):
    receipt = {
        "schema_version": 1,
        "mode": MODE,
        "backend": BACKEND,
        "sequence_marker": SEQUENCE_MARKER,
        "gpios": [18, 23],
        "helper_pid": os.getpid(),
        "passive_probes_only": True,
        "actual_actuators_attached": False,
        "functional_consumer_integration_only": True,
        "whole_blinka_compatibility_proven": False,
        "production_backend_unchanged": True,
        "parity_pass": None,
        "api_readbacks_are_not_electrical": True,
        "selected_source_hashes_are_not_whole_system_attestation": True,
        "variable_frequency": True,
        "runtime_flags": {"short_slice": False, "shared": False},
        "watchdog_seconds": MAX_RUN_SECONDS,
        "watchdog_cannot_bound_native_hang_or_sigkill": True,
        "sequence_dwell_seconds": round(sum(row[1] for row in SEQUENCE), 6),
        "normal_fixed_wait_seconds": round(sum(row[1] for row in SEQUENCE) + 0.3, 6),
        "low_settle_seconds": 0.1,
        "begin_ns": time.monotonic_ns(),
        "phases": [],
        "actions": [],
        "events": [],
        "outputs": [],
        "shutdowns": [],
        "source_sha256": {},
        "before": None,
        "after": None,
        "primary_error": None,
        "cleanup_errors": [],
        "signals_received": [],
        "completed_normally": False,
        "read_only_chip_closed": False,
        "success": False,
    }
    owners, import_chip, board = {}, None, None
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            path = approved_manifest_path(manifest_path)
            receipt["manifest_path"] = str(path)
            fresh_process(path.parent, receipt)
            manifest = load_manifest(path)
            paths = inspect_sources(path.parent, manifest, receipt)
            receipt["identity"] = dual.base.baseline.preflight()
            receipt["before"] = core.system_snapshot()
            issues = core.thermal_issues(receipt["before"], 65000)
            if issues:
                raise core.BenchError("Thermal preflight: " + "; ".join(issues))
            library, native_module = dual.load_backend()
            lgpio = importlib.import_module("lgpio")
            verify_origins(paths)
            receipt["preclaim_lines"] = []
            for gpio in (18, 23):
                chip, line = dual.inspect_line(library, receipt["identity"], gpio)
                receipt["preclaim_lines"].append(
                    {"gpio": gpio, "chip_info": chip, "line_info": line}
                )
                receipt["read_only_chip_closed"] = True
                if line["used"] or line["consumer"] not in (None, ""):
                    raise core.BenchError(
                        "Both consumer pins must be fresh unused lines"
                    )
            import_chip = ImportChip(lgpio, receipt["identity"], guard, receipt)
            board, pwmio, servo, motor = installed_api(
                paths, native_module, import_chip, receipt
            )
            run_protocol(
                library,
                pwmio,
                board,
                servo,
                motor,
                receipt["identity"],
                guard,
                receipt,
                owners,
            )
            verify_origins(paths)
            validate_actions(receipt)
            receipt["completed_normally"] = True
        except BaseException as error:
            receipt["primary_error"] = error_text(error)
        finally:
            with guard.cleanup():
                signal.alarm(0)
                for owner in owners.values():
                    owner.scope = "safety_cleanup_" + owner.output_id
                    try:
                        owner.cleanup()
                        owner.verify_pin()
                    except BaseException as error:
                        receipt["cleanup_errors"].append(
                            owner.output_id + ": " + error_text(error)
                        )
                if import_chip is not None:
                    import_chip.close()
                try:
                    receipt["after"] = core.system_snapshot()
                    receipt["cleanup_errors"].extend(
                        core.thermal_issues(receipt["after"], 70000)
                    )
                except BaseException as error:
                    receipt["cleanup_errors"].append(
                        "Thermal postflight: " + error_text(error)
                    )
                receipt["signals_received"] = list(guard.received)
    receipt["end_ns"] = time.monotonic_ns()
    receipt["success"] = bool(
        receipt["completed_normally"]
        and receipt["primary_error"] is None
        and not receipt["cleanup_errors"]
        and not receipt["signals_received"]
        and receipt["read_only_chip_closed"]
        and import_chip is not None
        and import_chip.record["opened"]
        and import_chip.record["closed"]
        and import_chip.record["hooks_restored"]
        and len(receipt["outputs"]) == 3
        and all(
            all(
                row[key]
                for key in (
                    "fresh_claim_accepted",
                    "initial_low_confirmed",
                    "low_confirmed",
                    "released",
                    "read_only_chip_closed",
                )
            )
            for row in receipt["outputs"]
        )
        and len(receipt["shutdowns"]) == 3
        and all(row["success"] for row in receipt["shutdowns"])
        and len(receipt["phases"]) == 15
        and len(receipt["actions"]) == 10
        and receipt["end_ns"] - receipt["begin_ns"] < MAX_RUN_SECONDS * 1_000_000_000
    )
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    receipt = experiment(parser.parse_args(argv).manifest)
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
