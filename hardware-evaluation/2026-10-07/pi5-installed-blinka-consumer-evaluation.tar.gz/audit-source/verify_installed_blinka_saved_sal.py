"""Re-export two saved captures only; never start acquisition or drive GPIO."""

import hashlib
import json
import tempfile
from pathlib import Path

from saleae import automation

LAB = Path(__file__).resolve().parent
OUTPUT = LAB / "oct7-installed-blinka-saved-sal-verification.json"
CAPTURES = (
    "oct7-pi5-installed-blinka-consumers-r1",
    "oct7-pi5-installed-blinka-consumers-r2",
)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    assert not OUTPUT.exists() and not OUTPUT.is_symlink()
    destination = Path(
        tempfile.mkdtemp(prefix="installed-blinka-sal-", dir="/private/tmp")
    )
    checks = []
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        for name in CAPTURES:
            saved = LAB / name / "waveform.sal"
            assert saved.is_file() and not saved.is_symlink()
            export = destination / name
            export.mkdir()
            with manager.load_capture(str(saved)) as capture:
                capture.export_raw_data_binary(str(export), digital_channels=[0, 1])
            for channel in (0, 1):
                original = LAB / name / f"digital_{channel}.bin"
                regenerated = export / original.name
                assert original.read_bytes() == regenerated.read_bytes()
                checks.append(
                    {
                        "capture": name,
                        "channel": channel,
                        "original_sha256": digest(original),
                        "regenerated_sha256": digest(regenerated),
                        "byte_identical": True,
                        "sal_sha256": digest(saved),
                    }
                )
    receipt = {
        "accepted": True,
        "checks": checks,
        "export_directory": str(destination),
        "source_sha256": digest(__file__),
        "saved_capture_objects_closed": True,
        "manager_released": True,
        "no_new_capture_or_gpio_activity": True,
    }
    with OUTPUT.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"accepted": True, "byte_identical_channels": len(checks)}))


if __name__ == "__main__":
    main()
