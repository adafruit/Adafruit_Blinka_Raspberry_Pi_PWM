"""Independent offline receipt audit and direct struct-based Saleae decoder.

No collector/analyzer code, producer waveform reports, SSH, GPIO or Saleae API
is imported. Every edge/run/adjacent-rise interval and short fragment is kept.
The nominal band identifies waveform features, not acceptance or performance.
"""

import argparse
import datetime
import hashlib
import itertools
import json
import math
import shlex
import statistics
import struct
import zipfile
from pathlib import Path

LAB = Path(__file__).resolve().parent
ROOT = "/tmp/blinka-pwm-installed-consumers.QmHr57"
PYTHON = ROOT + "/venv/bin/python"
CAPTURES = (
    "oct7-pi5-installed-blinka-consumers-r1",
    "oct7-pi5-installed-blinka-consumers-r2",
)
MANIFEST_NAME = "oct7-installed-blinka-consumers-manifest.json"
HELPER_NAME = "installed_blinka_pwm_consumers_eval.py"
MODE = "installed-blinka-consumer-passive-probes"
MARKER = "installed-blinka-servo-dcmotor-v1"
PIN_MODULE = "adafruit_blinka.microcontroller.generic_linux.lgpio_pin"
BAND, MIN_PULSES, LONG_SECONDS, BRAKE_SECONDS = 0.10, 5, 0.10, 0.10
TARGETS = {
    "servo_angle0": (50, 3276),
    "servo_angle90": (50, 4914),
    "servo_angle180": (50, 6553),
    "motor_half": (1000, 32767),
}
SEQUENCE = (
    ("servo_initial_low", 0.1, "servo_initialize", None),
    ("servo_angle0", 0.4, "Servo.angle", 0),
    ("servo_angle90", 0.4, "Servo.angle", 90),
    ("servo_angle180", 0.4, "Servo.angle", 180),
    ("servo_disable", 0.15, "Servo.angle", None),
    ("servo_release", 0.15, "servo_release", None),
    ("motor_initial_low", 0.1, "motor_initialize", None),
    ("motor_brake", 0.2, "DCMotor.throttle", 0),
    ("motor_forward_half", 0.35, "DCMotor.throttle", 0.5),
    ("motor_forward_full", 0.2, "DCMotor.throttle", 1),
    ("motor_reverse_half", 0.35, "DCMotor.throttle", -0.5),
    ("motor_reverse_full", 0.2, "DCMotor.throttle", -1),
    ("motor_disable", 0.15, "DCMotor.throttle", None),
    ("motor_release_positive", 0.15, "motor_release_positive", None),
    ("motor_release_negative", 0.15, "motor_release_negative", None),
)


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    path = Path(path)
    require(
        path.is_file() and not path.is_symlink(),
        "Regular nonsymlink input required: " + str(path),
    )
    return json.loads(path.read_text())


def statistics_all(values):
    if not values:
        return {
            "count": 0,
            "minimum": None,
            "maximum": None,
            "mean": None,
            "median": None,
            "population_stddev": None,
        }
    return {
        "count": len(values),
        "minimum": min(values),
        "maximum": max(values),
        "mean": statistics.mean(values),
        "median": statistics.median(values),
        "population_stddev": statistics.pstdev(values),
    }


def nominal(frequency, duty):
    period_ns = (1_000_000_000 + frequency // 2) // frequency
    high_ns = (period_ns * duty + 32767) // 65535
    return {
        "frequency_hz": frequency,
        "duty_u16": duty,
        "period_us": period_ns / 1000,
        "high_us": high_ns / 1000,
    }


NOMINALS = {name: nominal(*values) for name, values in TARGETS.items()}


def decode(path):
    """Read binary versions0/1 directly; never bridge gaps between chunks."""
    payload = Path(path).read_bytes()
    cursor = 0

    def take(format_string):
        nonlocal cursor
        size = struct.calcsize(format_string)
        require(cursor + size <= len(payload), "Truncated digital export")
        values = struct.unpack_from(format_string, payload, cursor)
        cursor += size
        return values

    require(payload[:8] == b"<SALEAE>", "Wrong digital magic")
    cursor = 8
    version, kind = take("<ii")
    require(version in (0, 1) and kind == 0, "Unsupported digital binary version/type")
    count = take("<Q")[0] if version else 1
    require(1 <= count <= len(payload) // 28, "Invalid digital chunk count")
    chunks = []
    for chunk_index in range(count):
        initial = take("<I")[0]
        rate = take("<d")[0] if version else None
        begin, end, transition_count = take("<ddQ")
        require(
            initial in (0, 1)
            and math.isfinite(begin)
            and math.isfinite(end)
            and begin < end,
            "Invalid digital chunk bounds/state",
        )
        require(
            rate is None or math.isfinite(rate) and rate > 0,
            "Invalid digital header sample rate",
        )
        require(
            transition_count <= (len(payload) - cursor) // 8,
            "Invalid digital transition count",
        )
        transitions = list(take("<" + str(transition_count) + "d"))
        require(
            all(math.isfinite(t) and begin <= t <= end for t in transitions)
            and all(a < b for a, b in itertools.pairwise(transitions)),
            "Nonfinite, out-of-bounds or unordered transition",
        )
        require(
            not chunks or chunks[-1]["end_seconds"] <= begin,
            "Overlapping digital chunks",
        )
        edges = [
            {"seconds": point, "level_after": initial ^ ((index + 1) & 1)}
            for index, point in enumerate(transitions)
        ]
        boundaries = [begin, *transitions, end]
        runs = [
            {
                "run_index": index,
                "level": initial ^ (index & 1),
                "begin_seconds": a,
                "end_seconds": b,
                "width_us": (b - a) * 1e6,
                "left_capture_boundary": index == 0,
                "right_capture_boundary": index == len(boundaries) - 2,
            }
            for index, (a, b) in enumerate(itertools.pairwise(boundaries))
        ]
        highs = [
            dict(row, pair_index=index)
            for index, row in enumerate(row for row in runs if row["level"] == 1)
        ]
        lows = [row for row in runs if row["level"] == 0]
        rises = [edge["seconds"] for edge in edges if edge["level_after"] == 1]
        periods = [(b - a) * 1e6 for a, b in itertools.pairwise(rises)]
        for high in highs:
            high["target_candidates"] = [
                name
                for name, target in NOMINALS.items()
                if math.isclose(high["width_us"], target["high_us"], rel_tol=BAND)
            ]
            high["descriptive_sustained_high"] = high["width_us"] > LONG_SECONDS * 1e6
        chunks.append(
            {
                "chunk_index": chunk_index,
                "initial_level": initial,
                "final_level": initial ^ (transition_count & 1),
                "begin_seconds": begin,
                "end_seconds": end,
                "header_sample_rate_hz": rate,
                "transition_count": transition_count,
                "edges": edges,
                "all_high_runs": highs,
                "all_low_runs": lows,
                "all_rise_seconds": rises,
                "all_adjacent_rise_intervals_us": periods,
                "all_adjacent_edge_intervals_us": [
                    (b - a) * 1e6 for a, b in itertools.pairwise(transitions)
                ],
                "full_high_width_stats_us": statistics_all(
                    [row["width_us"] for row in highs]
                ),
                "full_low_width_stats_us": statistics_all(
                    [row["width_us"] for row in lows]
                ),
                "full_adjacent_rise_stats_us": statistics_all(periods),
            }
        )
    require(cursor == len(payload), "Trailing digital binary bytes")
    return {
        "format_version": version,
        "type": kind,
        "file_sha256": hashlib.sha256(payload).hexdigest(),
        "file_bytes": len(payload),
        "chunks": chunks,
        "no_edges_or_outliers_removed": True,
        "no_inter_chunk_gap_bridging": True,
    }


def fragments(chunk, tag):
    groups, current = [], []
    for high in chunk["all_high_runs"]:
        compatible = tag in high["target_candidates"]
        joined = current and math.isclose(
            (high["begin_seconds"] - current[-1]["begin_seconds"]) * 1e6,
            NOMINALS[tag]["period_us"],
            rel_tol=BAND,
        )
        if current and (not compatible or not joined):
            groups.append(current)
            current = []
        if compatible:
            current.append(high)
    if current:
        groups.append(current)
    result = []
    for group in groups:
        highs = [row["width_us"] for row in group]
        periods = [
            (b["begin_seconds"] - a["begin_seconds"]) * 1e6
            for a, b in itertools.pairwise(group)
        ]
        errors = [value - NOMINALS[tag]["high_us"] for value in highs]
        result.append(
            {
                "tag": tag,
                "pair_indices": [row["pair_index"] for row in group],
                "begin_seconds": group[0]["begin_seconds"],
                "end_seconds": group[-1]["end_seconds"],
                "eligible_train": len(group) >= MIN_PULSES
                and not any(
                    row["left_capture_boundary"] or row["right_capture_boundary"]
                    for row in group
                ),
                "all_high_widths_us": highs,
                "all_periods_us": periods,
                "all_high_target_errors_us": errors,
                "high_stats_us": statistics_all(highs),
                "period_stats_us": statistics_all(periods),
                "maximum_absolute_high_target_error_us": max(map(abs, errors)),
            }
        )
    return result


def joint_facts(channel18, channel23):
    require(
        len(channel18["chunks"]) == len(channel23["chunks"]) == 1,
        "Functional topology requires the complete single chunk; gap facts remain separately preserved",
    )
    a, b = channel18["chunks"][0], channel23["chunks"][0]
    require(
        (a["begin_seconds"], a["end_seconds"])
        == (b["begin_seconds"], b["end_seconds"]),
        "Both physical channels must share acquisition bounds",
    )
    groups = {
        "gpio18": {tag: fragments(a, tag) for tag in TARGETS},
        "gpio23": {tag: fragments(b, tag) for tag in TARGETS},
    }
    contacts = []
    for high18, high23 in itertools.product(a["all_high_runs"], b["all_high_runs"]):
        begin, end = (
            max(high18["begin_seconds"], high23["begin_seconds"]),
            min(high18["end_seconds"], high23["end_seconds"]),
        )
        if begin <= end:
            contacts.append(
                {
                    "gpio18_pair_index": high18["pair_index"],
                    "gpio23_pair_index": high23["pair_index"],
                    "begin_seconds": begin,
                    "end_seconds": end,
                    "duration_us": (end - begin) * 1e6,
                    "sample_tied_boundary_touch": begin == end,
                    "both_sustained_high": high18["descriptive_sustained_high"]
                    and high23["descriptive_sustained_high"],
                    "eligible_brake_overlap": high18["descriptive_sustained_high"]
                    and high23["descriptive_sustained_high"]
                    and end - begin >= BRAKE_SECONDS,
                }
            )
    ambiguity = []

    def unique(name, candidates):
        if len(candidates) != 1:
            ambiguity.append(
                {
                    "feature": name,
                    "candidate_count": len(candidates),
                    "candidates": candidates,
                }
            )
            return None
        return candidates[0]

    brake = unique(
        "joint_brake", [row for row in contacts if row["eligible_brake_overlap"]]
    )
    selected = {}
    for tag in ("servo_angle0", "servo_angle90", "servo_angle180"):
        possibilities = [
            row
            for row in groups["gpio18"][tag]
            if brake and row["end_seconds"] < brake["begin_seconds"]
        ]
        selected[tag] = unique(
            tag, [row for row in possibilities if row["eligible_train"]]
        )
        if selected[tag] and len(possibilities) != 1:
            ambiguity.append(
                {
                    "feature": tag + "_full_extent",
                    "reason": "Extra short or eligible fragments retained",
                    "all_fragments": possibilities,
                }
            )
    long18 = [row for row in a["all_high_runs"] if row["descriptive_sustained_high"]]
    long23 = [row for row in b["all_high_runs"] if row["descriptive_sustained_high"]]
    brake18 = next(
        (
            row
            for row in long18
            if brake and row["pair_index"] == brake["gpio18_pair_index"]
        ),
        None,
    )
    brake23 = next(
        (
            row
            for row in long23
            if brake and row["pair_index"] == brake["gpio23_pair_index"]
        ),
        None,
    )
    positive = unique(
        "full_positive",
        [
            row
            for row in long18
            if brake18 and row["begin_seconds"] > brake18["end_seconds"]
        ],
    )
    negative = unique(
        "full_negative",
        [
            row
            for row in long23
            if brake23 and row["begin_seconds"] > brake23["end_seconds"]
        ],
    )
    ordered_servo = bool(
        brake
        and all(selected.values())
        and selected["servo_angle0"]["end_seconds"]
        < selected["servo_angle90"]["begin_seconds"]
        and selected["servo_angle90"]["end_seconds"]
        < selected["servo_angle180"]["begin_seconds"]
        and selected["servo_angle180"]["end_seconds"] < brake["begin_seconds"]
    )
    ordered_long = bool(
        brake
        and positive
        and negative
        and brake["end_seconds"]
        < positive["begin_seconds"]
        < positive["end_seconds"]
        < negative["begin_seconds"]
    )
    selected["motor_forward_half"] = unique(
        "motor_forward_half",
        [
            row
            for row in groups["gpio18"]["motor_half"]
            if row["eligible_train"]
            and ordered_long
            and brake18["end_seconds"] < row["begin_seconds"]
            and row["end_seconds"] < positive["begin_seconds"]
        ],
    )
    selected["motor_reverse_half"] = unique(
        "motor_reverse_half",
        [
            row
            for row in groups["gpio23"]["motor_half"]
            if row["eligible_train"]
            and ordered_long
            and positive["end_seconds"] < row["begin_seconds"]
            and row["end_seconds"] < negative["begin_seconds"]
        ],
    )
    selected["motor_forward_full"], selected["motor_reverse_full"] = positive, negative
    if not ordered_servo:
        ambiguity.append(
            {
                "feature": "servo_order",
                "reason": "Unique ordered servo0/90/180 before joint brake not established",
            }
        )
    if not ordered_long:
        ambiguity.append(
            {
                "feature": "long_high_order",
                "reason": "Unique brake then GPIO18full then GPIO23full order not established",
            }
        )
    sibling = {}
    for name, chosen in selected.items():
        if chosen is None:
            continue
        other = a if name.startswith("motor_reverse") else b
        overlap = [
            row
            for row in other["all_high_runs"]
            if row["begin_seconds"] <= chosen["end_seconds"]
            and row["end_seconds"] >= chosen["begin_seconds"]
        ]
        sibling[name] = {
            "entire_extent_sibling_low": not overlap,
            "all_overlap_or_boundary_touch_high_runs": overlap,
            "guarded_core_substitution_used": False,
        }
        if overlap:
            ambiguity.append(
                {
                    "feature": name + "_sibling_low",
                    "reason": "Whole feature extent intersects sibling high or sample-tied boundary",
                    "overlapping_high_runs": overlap,
                }
            )
    reverse = selected["motor_reverse_half"]
    gap = (
        (reverse["begin_seconds"] - positive["end_seconds"]) * 1e6
        if reverse and positive
        else None
    )
    last_high = max(
        (row["end_seconds"] for row in [*a["all_high_runs"], *b["all_high_runs"]]),
        default=a["begin_seconds"],
    )
    return {
        "all_width_period_fragments_including_short": groups,
        "all_cross_channel_high_overlap_or_boundary_contacts": contacts,
        "selected_unique_features": selected,
        "whole_extent_sibling_facts": sibling,
        "all_ambiguities": ambiguity,
        "unique_servo_order_before_brake": ordered_servo,
        "unique_brake_forward_reverse_sustained_order": ordered_long,
        "complete_ordered_joint_topology_supported": bool(
            ordered_servo and ordered_long and all(selected.values()) and not ambiguity
        ),
        "forward_full_fall_to_reverse_first_rise_signed_gap_us": gap,
        "both_initial_levels": [a["initial_level"], b["initial_level"]],
        "both_final_levels": [a["final_level"], b["final_level"]],
        "final_both_low_tail_seconds": a["end_seconds"] - last_high
        if a["final_level"] == b["final_level"] == 0
        else None,
        "no_pi_saleae_clock_alignment": True,
        "silent_levels_do_not_identify_disable_vs_deinit_or_generation": True,
        "rules": {
            "symmetric_math_isclose_relative_band": BAND,
            "minimum_train_pulses": MIN_PULSES,
            "sustained_high_seconds": LONG_SECONDS,
            "minimum_brake_overlap_seconds": BRAKE_SECONDS,
            "identification_only_not_acceptance": True,
        },
    }


def sal_settings(path):
    with zipfile.ZipFile(path) as archive:
        data = json.loads(archive.read("meta.json"))["data"]
    settings, device = data["legacySettings"], data["legacyDevice"]
    require(
        settings["enabledChannels"]
        == [{"type": "Digital", "index": 0}, {"type": "Digital", "index": 1}]
        and type(settings["sampleRate"]["digital"]) is int
        and settings["sampleRate"]["digital"] == 100_000_000
        and settings["glitchFilter"] == {"enabled": False, "channels": []}
        and device["isSimulation"] is False,
        "Saved SAL must be physical channels0/1,100MSa/s,unfiltered",
    )
    identifier = str(device["deviceId"])
    require(
        int(identifier, 10 if identifier.isdigit() else 16)
        == int("81F8C2631DF5BF30", 16),
        "Saved physical analyzer device differs",
    )
    return {
        "physical_logic8": True,
        "device_id": "81F8C2631DF5BF30",
        "channels": [0, 1],
        "sample_rate_hz": 100_000_000,
        "glitch_filter": False,
    }


def verify_receipts(directory, manifest, plan, manifest_sha, plan_sha):
    """Duplicate the essential contract independently, not the new validator."""
    remote, result, acquisition = (
        read(directory / name)
        for name in ("remote.stdout", "results.json", "acquisition.json")
    )
    checks = []

    def check(name, value):
        checks.append({"check": name, "passed": bool(value)})

    check(
        "typed_actual_ssh_exit0",
        all(
            type(row.get("remote_returncode")) is int and row["remote_returncode"] == 0
            for row in (result, acquisition)
        ),
    )
    check(
        "collection_success_and_actual_receipt",
        result.get("collection_success") is True and result.get("remote") == remote,
    )
    check(
        "no_primary_or_cleanup_or_signal_error",
        remote.get("primary_error") is None
        and remote.get("cleanup_errors") == []
        and remote.get("signals_received") == []
        and remote.get("success") is True
        and remote.get("completed_normally") is True
        and acquisition.get("primary_error") is None
        and acquisition.get("evidence_errors") == [],
    )
    check(
        "exact_mode_backend_sequence",
        all(
            row.get("mode") == MODE and row.get("backend") == "native-blinka-pwm"
            for row in (remote, result, acquisition)
        )
        and remote.get("sequence_marker") == MARKER
        and remote.get("gpios") == [18, 23],
    )
    check(
        "exact_selected_source_inventory",
        remote.get("source_sha256") == manifest.get("source_sha256")
        and remote.get("source_paths") == manifest.get("source_paths")
        and remote.get("distribution_versions") == manifest.get("distribution_versions")
        and result.get("source_manifest") == manifest
        and read(directory / "manifest.json") == manifest,
    )
    check(
        "source_plan_and_hash_linkage",
        result.get("source_plan") == plan
        and read(directory / "plan.json") == plan
        and all(
            row.get("manifest_sha256") == manifest_sha
            and row.get("plan_sha256") == plan_sha
            for row in (result, acquisition)
        )
        and result.get("collector_sha256") == plan.get("collector_sha256")
        and result.get("helper_sha256") == manifest["source_sha256"][HELPER_NAME],
    )
    expected_command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(
            [
                PYTHON,
                "-I",
                ROOT + "/" + HELPER_NAME,
                "--manifest",
                ROOT + "/" + MANIFEST_NAME,
            ]
        ),
    ]
    check(
        "actual_isolated_helper_invocation",
        acquisition.get("remote_command") == expected_command
        and acquisition.get("remote_root") == ROOT
        and acquisition.get("remote_python") == PYTHON
        and remote.get("manifest_path") == ROOT + "/" + MANIFEST_NAME,
    )
    check(
        "fresh_isolated_noninteractive_runtime",
        remote.get("python_executable") == PYTHON
        and remote.get("isolated_python") is True
        and remote.get("noninteractive_no_runtime_installs") is True
        and remote.get("inherited_environment") == {},
    )
    check(
        "preflight_receipt_hash_linkage",
        all(
            row.get("preflight_receipt_sha256") == plan.get("preflight_receipt_sha256")
            for row in (result, acquisition)
        ),
    )
    dispatch = remote.get("installed_dispatch", {})
    check(
        "real_installed_board_pwmio_unwrapped_dispatch",
        all(
            dispatch.get(key) is True
            for key in (
                "real_board_used",
                "real_pwmio_used",
                "unwrapped_public_pwm_objects",
                "pwmout_identity_verified",
            )
        )
        and dispatch.get("virtual_pwmio_export_used") is False
        and dispatch.get("board_id") == "RASPBERRY_PI_5"
        and dispatch.get("chip_id") == "BCM2XXX"
        and dispatch.get("pin_class_module") == PIN_MODULE
        and dispatch.get("pin_ids") == [18, 23],
    )
    chip = remote.get("blinka_import_chip", {})
    check(
        "private_import_chip_owned_closed_hooks_restored",
        all(chip.get(key) is True for key in ("opened", "closed", "hooks_restored"))
        and chip.get("claims_or_writes_permitted") is False
        and chip.get("verified_chip_index") == 0
        and type(chip.get("handle")) is int
        and chip["handle"] >= 0
        and chip.get("errors") == [],
    )
    import_events = chip.get("events", [])
    check(
        "exact_import_open_close0_no_gpio_mutations",
        len(import_events) == 2
        and [row.get("operation") for row in import_events]
        == ["gpiochip_open", "gpiochip_close"]
        and all(row.get("status") == "ok" for row in import_events)
        and type(import_events[-1].get("returncode")) is int
        and import_events[-1]["returncode"] == 0,
    )
    outputs = remote.get("outputs", [])
    expected_outputs = (
        ("servo18-g1", 18, 1, 50),
        ("motor18-g2", 18, 2, 1000),
        ("motor23-g1", 23, 1, 1000),
    )
    check("exact_three_private_output_generations", len(outputs) == 3)
    for row, (name, gpio, generation, frequency) in zip(outputs, expected_outputs):
        check(
            name + "_identity_real_pin",
            all(
                row.get(key) == value
                for key, value in {
                    "output_id": name,
                    "gpio": gpio,
                    "generation": generation,
                    "initial_frequency": frequency,
                    "real_board_pin": {
                        "attribute": "D" + str(gpio),
                        "id": gpio,
                        "class_module": PIN_MODULE,
                    },
                }.items()
            ),
        )
        check(
            name + "_low_release_confirmation",
            all(
                row.get(key) is True
                for key in (
                    "fresh_claim_accepted",
                    "initial_low_confirmed",
                    "low_confirmed",
                    "released",
                    "read_only_chip_closed",
                )
            )
            and row.get("initial_readback") == {"gpio_level": 0, "inactive": True}
            and row.get("cleanup_final_readback")
            == {"gpio_level": 0, "inactive": True},
        )
        request = row.get("owned_request", {})
        check(
            name + "_private_descriptor",
            request.get("chip_name") == "gpiochip0"
            and request.get("offsets") == [gpio]
            and type(request.get("fd")) is int
            and request["fd"] >= 0,
        )
        for boundary in ("preclaim_line_info", "released_line_info"):
            line = row.get(boundary, {})
            check(
                name + "_" + boundary,
                line.get("offset") == gpio
                and line.get("used") is False
                and line.get("consumer") in (None, ""),
            )
    phases, actions, shutdowns = (
        remote.get("phases", []),
        remote.get("actions", []),
        remote.get("shutdowns", []),
    )
    check(
        "exact_15_phases_10_actions_3_shutdowns",
        len(phases) == 15 and len(actions) == 10 and len(shutdowns) == 3,
    )
    for index, (row, (name, duration, operation, value)) in enumerate(
        zip(phases, SEQUENCE)
    ):
        check(
            name + "_phase_contract",
            row.get("index") == index
            and row.get("name") == name
            and row.get("duration_seconds") == duration
            and row.get("operation") == operation
            and row.get("value") == value,
        )
        times = [
            row.get(key)
            for key in ("begin_ns", "stable_begin_ns", "end_ns", "readback_end_ns")
        ]
        check(
            name + "_ordered_receipt_timing",
            all(type(t) is int and t > 0 for t in times)
            and all(a <= b for a, b in itertools.pairwise(times)),
        )
    expected_actions = [
        (index, op, value)
        for index, (_name, _duration, op, value) in enumerate(SEQUENCE)
        if op in ("Servo.angle", "DCMotor.throttle")
    ]
    for index, (action, (phase_index, operation, value)) in enumerate(
        zip(actions, expected_actions)
    ):
        if operation == "Servo.angle":
            duties = [{0: 3276, 90: 4914, 180: 6553, None: 0}[value]]
        elif value is None:
            duties = [0, 0]
        elif value == 0:
            duties = [65535, 65535]
        else:
            duty = int(abs(value) * 65535)
            duties = [duty, 0] if value > 0 else [0, duty]
        state = action.get("api_state_after", [])
        check(
            "action" + str(index) + "_genuine_api_contract",
            action.get("phase_index") == phase_index
            and action.get("operation") == operation
            and action.get("value") == value
            and action.get("status") == "ok"
            and [row.get("duty_u16") for row in state] == duties
            and [row.get("frequency") for row in state]
            == ([50] if operation == "Servo.angle" else [1000, 1000]),
        )
    check(
        "three_ordered_successful_shutdowns",
        [row.get("output_id") for row in shutdowns]
        == [row[0] for row in expected_outputs]
        and all(
            row.get("success") is True and row.get("errors") == [] for row in shutdowns
        ),
    )
    if len(shutdowns) == 3:
        middle = shutdowns[1]
        check(
            "independent_motor18_release_preserves_motor23",
            middle.get("sibling_id") == "motor23-g1"
            and isinstance(middle.get("sibling_before"), dict)
            and middle.get("sibling_before") == middle.get("sibling_after")
            and middle["sibling_before"].get("gpio_level") == 0
            and middle["sibling_before"].get("duty_u16") == 0,
        )
    check(
        "all_receipted_ownership_events_succeeded",
        all(row.get("status") == "ok" for row in remote.get("events", [])),
    )
    check(
        "ordinary_individual_worker_flags",
        remote.get("runtime_flags") == {"short_slice": False, "shared": False},
    )
    return {
        "checks": checks,
        "all_checks_passed": all(row["passed"] for row in checks),
        "helper_pid": remote.get("helper_pid"),
        "import_chip": chip,
        "installed_dispatch": dispatch,
        "private_outputs": outputs,
        "shutdowns": shutdowns,
        "phase_count": len(phases),
        "action_count": len(actions),
        "ownership_event_count": len(remote.get("events", [])),
        "receipt_clocks_not_used_for_waveform_phase_alignment": True,
    }


def audit(manifest_path, plan_path):
    manifest, plan = read(manifest_path), read(plan_path)
    require(
        plan.get("remote_root") == ROOT
        and plan.get("remote_python") == PYTHON
        and plan.get("capture_order") == list(CAPTURES),
        "Fixed installed capture plan required",
    )
    rules = plan.get("pre_capture_waveform_identification", {})
    require(
        rules.get("ordinary_width_period_relative_band") == BAND
        and rules.get("minimum_identifiable_train_pulses") == MIN_PULSES
        and rules.get("sustained_high_threshold_seconds") == LONG_SECONDS
        and rules.get("minimum_joint_brake_overlap_seconds") == BRAKE_SECONDS,
        "Pre-capture identification rules differ",
    )
    require(
        plan.get("helper_sha256")
        == digest(LAB / HELPER_NAME)
        == manifest["source_sha256"][HELPER_NAME]
        and plan.get("collector_sha256")
        == digest(LAB / "capture_installed_blinka_pwm_consumers.py"),
        "Selected helper/collector sources changed",
    )
    manifest_sha, plan_sha = digest(manifest_path), digest(plan_path)
    require(
        plan.get("manifest_sha256") == manifest_sha,
        "Manifest plan source hash linkage differs",
    )
    captures = {}
    for name in CAPTURES:
        directory = LAB / name
        require(
            directory.is_dir()
            and not directory.is_symlink()
            and directory.resolve() == directory,
            "Canonical capture directory required",
        )
        evidence = (
            "manifest.json",
            "plan.json",
            "remote.stdout",
            "remote.stderr",
            "results.json",
            "acquisition.json",
            "waveform.sal",
            "digital_0.bin",
            "digital_1.bin",
        )
        for filename in evidence:
            path = directory / filename
            require(
                path.is_file() and not path.is_symlink(),
                "Required canonical evidence missing: " + filename,
            )
        channels = [
            decode(directory / ("digital_" + str(index) + ".bin")) for index in (0, 1)
        ]
        captures[name] = {
            "evidence_sha256": {
                filename: digest(directory / filename) for filename in evidence
            },
            "saved_sal_settings": sal_settings(directory / "waveform.sal"),
            "receipt_audit": verify_receipts(
                directory, manifest, plan, manifest_sha, plan_sha
            ),
            "gpio18_channel0": channels[0],
            "gpio23_channel1": channels[1],
            "independent_joint_waveform_facts": joint_facts(*channels),
        }
    return {
        "schema_version": 1,
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "method": "Independent standard-library struct/zip/json reconstruction; no new analyzer, collector validators or producer waveform reports used",
        "audit_source_sha256": digest(__file__),
        "manifest_sha256": manifest_sha,
        "plan_sha256": plan_sha,
        "source_manifest": manifest,
        "nominals_from_integer_u16_c_rounding": NOMINALS,
        "capture_order": list(CAPTURES),
        "captures": captures,
        "all_collection_receipt_checks_passed": all(
            row["receipt_audit"]["all_checks_passed"] for row in captures.values()
        ),
        "pi_saleae_clocks_aligned": False,
        "application_latency_measured": False,
        "no_glitch_filtering_or_edge_trimming": True,
        "actuator_operation_proven": False,
        "whole_blinka_compatibility_proven": False,
        "matched_performance_parity": False,
        "waveform_accepted": None,
        "limitation": "Finite passive digital evidence only. Width/period bands identify candidate features and retain all fragments; they are not acceptance limits. Exact calls/generations are receipt-only, silent states cannot identify calls, and shared sample timestamps do not calibrate GPIO thresholds or channel skew.",
    }


def notes(report):
    lines = [
        "Independent installed-Blinka passive-probe audit",
        report["method"],
        "",
        "No waveform/performance/actuator or whole-Blinka acceptance is claimed.",
    ]
    for name, capture in report["captures"].items():
        receipt, joint = (
            capture["receipt_audit"],
            capture["independent_joint_waveform_facts"],
        )
        lines.extend(
            [
                "",
                name,
                "Receipt checks: "
                + str(sum(row["passed"] for row in receipt["checks"]))
                + "/"
                + str(len(receipt["checks"]))
                + "; outputs/phases/actions="
                + str(len(receipt["private_outputs"]))
                + "/"
                + str(receipt["phase_count"])
                + "/"
                + str(receipt["action_count"]),
                "Edges GPIO18/23: "
                + "/".join(
                    str(capture[key]["chunks"][0]["transition_count"])
                    for key in ("gpio18_channel0", "gpio23_channel1")
                ),
                "Initial/final levels: "
                + str(joint["both_initial_levels"])
                + "/"
                + str(joint["both_final_levels"]),
                "Complete ordered joint topology: "
                + str(joint["complete_ordered_joint_topology_supported"])
                + "; ambiguity count="
                + str(len(joint["all_ambiguities"])),
                "Forward-full fall to reverse-first rise signed gap us: "
                + str(joint["forward_full_fall_to_reverse_first_rise_signed_gap_us"]),
            ]
        )
        for tag, feature in joint["selected_unique_features"].items():
            if feature and "high_stats_us" in feature:
                lines.append(
                    tag
                    + ": pulse count="
                    + str(feature["high_stats_us"]["count"])
                    + "; full width min/max us="
                    + str(feature["high_stats_us"]["minimum"])
                    + "/"
                    + str(feature["high_stats_us"]["maximum"])
                    + "; max absolute nominal error us="
                    + str(feature["maximum_absolute_high_target_error_us"])
                )
    return "\n".join(lines) + "\n"


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    args = parser.parse_args(argv)
    output, note = (
        LAB / "oct7-installed-blinka-independent-audit.json",
        LAB / "oct7-installed-blinka-independent-audit.notes.txt",
    )
    require(
        not any(path.exists() or path.is_symlink() for path in (output, note)),
        "Exclusive fresh independent audit targets required",
    )
    report = audit(args.manifest, args.plan)
    with output.open("x") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")
    with note.open("x") as stream:
        stream.write(notes(report))
    print(
        json.dumps(
            {
                "all_collection_receipt_checks_passed": report[
                    "all_collection_receipt_checks_passed"
                ],
                "audit_sha256": digest(output),
                "notes_sha256": digest(note),
            }
        )
    )
    return 0 if report["all_collection_receipt_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
