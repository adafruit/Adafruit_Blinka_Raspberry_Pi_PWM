"""Offline comparison regressions using preserved artifacts, not hardware."""

import copy

import compare_installed_blinka_reports as compare
import pytest


def test_exact_numeric_types_are_not_fabricated():
    assert not compare.equal(False, 0)
    assert not compare.equal(None, 0)
    assert compare.equal([1.0, 2.0], [1.0, 2.0])


def test_statistics_tolerance_is_small_absolute_and_never_clock_tolerance():
    assert compare.equal({"mean": 500.0}, {"mean": 500.0 + 1e-8}, True)
    assert not compare.equal({"mean": 500.0}, {"mean": 500.001}, True)
    assert not compare.equal(
        {"begin_seconds": 1.0}, {"begin_seconds": 1.0 + 1e-8}, True
    )
    assert not compare.equal({"count": False}, {"count": 0}, True)


@pytest.fixture
def evidence():
    original = compare.read(compare.LAB / compare.INITIAL_NAME)
    assert compare.digest(compare.LAB / compare.INITIAL_NAME) == compare.INITIAL_SHA256
    name = compare.CAPTURES[1]
    report = compare.read(compare.LAB / name / compare.REPORT_NAME)
    return (
        name,
        {**original["captures"][name], "source_manifest": original["source_manifest"]},
        report,
        original["nominals_from_integer_u16_c_rounding"],
    )


def test_preserved_r2_report_matches_all_independent_raw_facts(evidence):
    result = compare.compare_capture(*evidence)
    assert result["all_checks_passed"] and result["mismatch_count"] == 0
    diagnostic = result["full_reverse_region_diagnostics_not_acceptance"]
    assert diagnostic["gpio23_all_nonlong_highs_including_unmatched_count"] == 351
    assert diagnostic["ordinary_fragment_pulse_counts"] == [258, 92]
    assert diagnostic["gpio23_all_nonlong_high_extrema_us"]["min"] == pytest.approx(
        308.86
    )
    assert len(diagnostic["gpio23_unmatched_nonlong_highs"]) == 1


@pytest.mark.parametrize(
    "section",
    [
        "edges",
        "high",
        "low",
        "period",
        "fragment",
        "ambiguity",
        "topology",
        "unmatched",
    ],
)
def test_erasing_or_altering_raw_outlier_and_fragment_facts_is_detected(
    evidence, section
):
    name, initial, original, nominals = evidence
    report = copy.deepcopy(original)
    channel = report["gpio23_channel1"]
    if section == "edges":
        channel["waveform"]["transition_seconds"][518] += 1e-8
    elif section == "high":
        channel["all_high_runs"][259]["width_us"] = 499.992
    elif section == "low":
        channel["all_low_runs"][259]["width_us"] = 500.0
    elif section == "period":
        channel["all_adjacent_rise_intervals"][258]["rise_to_rise_us"] = 1000.0
    elif section == "fragment":
        report["functional_waveform_facts"][
            "all_width_period_train_fragments_including_short"
        ]["gpio23"]["motor_half"].pop()
    elif section == "ambiguity":
        report["functional_waveform_facts"]["ambiguities"] = []
    elif section == "topology":
        report["functional_waveform_facts"][
            "complete_frozen_ordered_joint_topology_supported"
        ] = True
    elif section == "unmatched":
        channel["unmatched_width_pair_indices"] = []
    result = compare.compare_capture(name, initial, report, nominals)
    assert not result["all_checks_passed"] and result["mismatch_count"] >= 1


def test_silent_endpoint_must_match_initial_raw_evidence(evidence):
    name, initial, original, nominals = evidence
    report = copy.deepcopy(original)
    report["gpio23_channel1"]["waveform"]["final_state"] = 1
    assert (
        compare.compare_capture(name, initial, report, nominals)["mismatch_count"] >= 1
    )
