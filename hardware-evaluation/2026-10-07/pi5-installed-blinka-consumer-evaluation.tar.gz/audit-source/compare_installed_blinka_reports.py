"""Compare new producer reports against the immutable pre-report raw audit.

Only standard-library JSON/statistics are used. Raw arrays compare exactly;
derived descriptive statistics allow an absolute1e-7us numerical tolerance.
No initial evidence or producer report is edited, and no hardware is accessed.
"""

import datetime
import hashlib
import itertools
import json
import math
import statistics
from pathlib import Path

LAB = Path(__file__).resolve().parent
INITIAL_NAME = "oct7-installed-blinka-independent-audit.json"
INITIAL_SHA256 = "5ad34991122e2b54d82be662fe0fbdb9c7f2f48a7f3e2ab75bb98efa3c25bdbc"
SOURCE_SHA256 = "8a823c774adc1663c258ad621010902fa82d003768e5e5ccf6cfb547b76c3e11"
REPORT_NAME = "installed-consumer-analysis.json"
CAPTURES = (
    "oct7-pi5-installed-blinka-consumers-r1",
    "oct7-pi5-installed-blinka-consumers-r2",
)
TOLERANCE_US = 1e-7


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise ValueError("Regular nonsymlink comparison input required")
    return json.loads(path.read_text())


def stats(values):
    if not values:
        return {"count": 0}
    return {
        "count": len(values),
        "min": min(values),
        "median": statistics.median(values),
        "max": max(values),
        "mean": statistics.mean(values),
    }


def equal(actual, expected, tolerant=False):
    if isinstance(actual, dict) and isinstance(expected, dict):
        return set(actual) == set(expected) and all(
            equal(actual[key], expected[key], tolerant and not key.endswith("_seconds"))
            for key in actual
        )
    if isinstance(actual, list) and isinstance(expected, list):
        return len(actual) == len(expected) and all(
            equal(a, b, tolerant) for a, b in zip(actual, expected, strict=True)
        )
    if tolerant and type(actual) in (int, float) and type(expected) in (int, float):
        return (
            math.isfinite(actual)
            and math.isfinite(expected)
            and math.isclose(actual, expected, rel_tol=0, abs_tol=TOLERANCE_US)
        )
    return type(actual) is type(expected) and actual == expected


def high(row, nominals):
    width = row["width_us"]
    nearest = min(nominals, key=lambda tag: abs(width - nominals[tag]["high_us"]))
    return {
        "pair_index": row["pair_index"],
        "rise_seconds": row["begin_seconds"],
        "fall_seconds": row["end_seconds"],
        "width_us": width,
        "width_target_candidates": row["target_candidates"],
        "nearest_width_target": nearest,
        "nearest_width_target_error_us": width - nominals[nearest]["high_us"],
        "descriptive_long_high": row["descriptive_sustained_high"],
    }


def low_rows(chunk):
    lows, highs = chunk["all_low_runs"], chunk["all_high_runs"]
    return [
        {
            "kind": "initial"
            if row["left_capture_boundary"]
            else "final"
            if row["right_capture_boundary"]
            else "interior",
            "preceding_pair_index": index - 1 if index else None,
            "following_pair_index": index if index < len(highs) else None,
            "begin_seconds": row["begin_seconds"],
            "end_seconds": row["end_seconds"],
            "width_us": row["width_us"],
        }
        for index, row in enumerate(lows)
    ]


def period_rows(chunk):
    return [
        {
            "preceding_pair_index": index,
            "following_pair_index": index + 1,
            "begin_seconds": a,
            "end_seconds": b,
            "rise_to_rise_us": (b - a) * 1e6,
        }
        for index, (a, b) in enumerate(itertools.pairwise(chunk["all_rise_seconds"]))
    ]


def group_summary(group):
    return {
        "tag": group["tag"],
        "pair_indices": group["pair_indices"],
        "begin_seconds": group["begin_seconds"],
        "end_seconds": group["end_seconds"],
        "eligible_train": group["eligible_train"],
        "high_width_stats_us": stats(group["all_high_widths_us"]),
        "period_stats_us": stats(group["all_periods_us"]),
    }


def compare_capture(name, initial, report, nominals):
    checks = []

    def compare(label, actual, expected, tolerant=False):
        passed = equal(actual, expected, tolerant)
        row = {
            "check": label,
            "passed": passed,
            "comparison": "absolute1e-7us scalar statistics tolerance"
            if tolerant
            else "exact typed JSON equality",
        }
        if not passed:
            row.update(actual=actual, expected=expected)
        checks.append(row)

    compare("capture_name", report.get("capture"), name)
    compare(
        "same_selected_source_manifest",
        report.get("source_manifest"),
        initial["source_manifest"],
    )
    compare(
        "same_nominals", report.get("actual_consumer_u16_c_rounded_nominals"), nominals
    )
    for filename, wanted in initial["evidence_sha256"].items():
        compare(
            "live_evidence_bytes:" + filename, digest(LAB / name / filename), wanted
        )
        compare(
            "producer_evidence_hash:" + filename,
            report.get("evidence_sha256", {}).get(filename),
            wanted,
        )
    joint = initial["independent_joint_waveform_facts"]
    producer_joint = report["functional_waveform_facts"]
    for channel_name, gpio_name in (
        ("gpio18_channel0", "gpio18"),
        ("gpio23_channel1", "gpio23"),
    ):
        channel, actual = initial[channel_name], report[channel_name]
        chunk = channel["chunks"][0]
        wanted_waveform = {
            "binary_format_version": channel["format_version"],
            "header_sample_rate_hz": chunk["header_sample_rate_hz"],
            "chunks": len(channel["chunks"]),
            "begin_seconds": chunk["begin_seconds"],
            "end_seconds": chunk["end_seconds"],
            "initial_state": chunk["initial_level"],
            "final_state": chunk["final_level"],
            "edge_count": chunk["transition_count"],
            "transition_seconds": [row["seconds"] for row in chunk["edges"]],
        }
        compare(
            channel_name + ":entire_raw_edge_array_bounds_levels",
            actual.get("waveform"),
            wanted_waveform,
        )
        highs = [high(row, nominals) for row in chunk["all_high_runs"]]
        lows, periods = low_rows(chunk), period_rows(chunk)
        compare(
            channel_name + ":all_high_runs_classifications_and_outliers",
            actual.get("all_high_runs"),
            highs,
        )
        compare(
            channel_name + ":all_low_runs_including_leading_final",
            actual.get("all_low_runs"),
            lows,
        )
        compare(
            channel_name + ":all_adjacent_rise_intervals_including_gaps",
            actual.get("all_adjacent_rise_intervals"),
            periods,
        )
        raw_stats = {
            "all_high_width_stats_us": [row["width_us"] for row in highs],
            "all_low_width_stats_us": [row["width_us"] for row in lows],
            "all_adjacent_rise_stats_us": [row["rise_to_rise_us"] for row in periods],
        }
        for key, values in raw_stats.items():
            compare(
                channel_name + ":full_raw_stats:" + key,
                actual.get(key),
                stats(values),
                True,
            )
        compare(
            channel_name + ":every_unmatched_short_width_index",
            actual.get("unmatched_width_pair_indices"),
            [
                row["pair_index"]
                for row in highs
                if not row["width_target_candidates"]
                and not row["descriptive_long_high"]
            ],
        )
        compare(
            channel_name + ":every_sustained_high",
            actual.get("descriptive_long_high_runs"),
            [row for row in highs if row["descriptive_long_high"]],
        )
        for tag in nominals:
            errors = [
                row["nearest_width_target_error_us"]
                for row in highs
                if row["nearest_width_target"] == tag
                and not row["descriptive_long_high"]
            ]
            compare(
                channel_name + ":nearest_target_error_stats_including_unmatched:" + tag,
                actual.get(
                    "nearest_target_error_stats_us_including_all_nonlong_anomalies", {}
                ).get(tag),
                stats(errors),
                True,
            )
            expected_groups = joint["all_width_period_fragments_including_short"][
                gpio_name
            ][tag]
            groups = producer_joint["all_width_period_train_fragments_including_short"][
                gpio_name
            ][tag]
            compare(
                channel_name + ":fragment_count:" + tag,
                len(groups),
                len(expected_groups),
            )
            for index, (got, expected) in enumerate(zip(groups, expected_groups)):
                compare(
                    channel_name + ":full_fragment:" + tag + ":" + str(index),
                    got,
                    group_summary(expected),
                    True,
                )
        extent = report["complete_extent_descriptive_statistics"][channel_name]
        wanted_extent = {
            "all_high_widths_including_long_and_anomalous_us": stats(
                [row["width_us"] for row in highs]
            ),
            "all_low_widths_including_initial_and_final_us": stats(
                [row["width_us"] for row in lows]
            ),
            "all_interior_low_widths_us": stats(
                [row["width_us"] for row in lows if row["kind"] == "interior"]
            ),
            "all_adjacent_rise_intervals_including_gaps_us": stats(
                [row["rise_to_rise_us"] for row in periods]
            ),
        }
        for key, expected in wanted_extent.items():
            compare(
                channel_name + ":complete_extent_stats:" + key,
                extent.get(key),
                expected,
                True,
            )
        for tag, expected_groups in joint["all_width_period_fragments_including_short"][
            gpio_name
        ].items():
            got_groups = extent["every_width_period_fragment_including_short"][tag]
            expected = [
                {
                    "pair_indices": group["pair_indices"],
                    "begin_seconds": group["begin_seconds"],
                    "end_seconds": group["end_seconds"],
                    "eligible_train": group["eligible_train"],
                    "high_error_from_u16_c_target_us": stats(
                        group["all_high_target_errors_us"]
                    ),
                    "within_fragment_adjacent_rise_error_us": stats(
                        [
                            period - nominals[tag]["period_us"]
                            for period in group["all_periods_us"]
                        ]
                    ),
                }
                for group in expected_groups
            ]
            compare(
                channel_name
                + ":complete_extent_all_fragments_and_error_extrema:"
                + tag,
                got_groups,
                expected,
                True,
            )
        compare(
            channel_name + ":complete_extent_keeps_raw_arrays",
            extent.get("all_raw_arrays_retained_in_channel_facts"),
            True,
        )
        compare(
            channel_name + ":bands_not_acceptance",
            extent.get("identification_band_is_not_acceptance"),
            True,
        )
    for actual_name, expected_name in (
        ("unique_servo_order_before_joint_brake", "unique_servo_order_before_brake"),
        (
            "unique_brake_positive_negative_long_high_order",
            "unique_brake_forward_reverse_sustained_order",
        ),
        (
            "complete_frozen_ordered_joint_topology_supported",
            "complete_ordered_joint_topology_supported",
        ),
    ):
        compare(
            "joint_topology:" + actual_name,
            producer_joint.get(actual_name),
            joint[expected_name],
        )
    ambiguity_map = {"motor_reverse_half": "gpio23_reverse_half_train"}
    expected_ambiguities = [
        {
            "feature": ambiguity_map.get(row["feature"], row["feature"]),
            "candidate_count": row.get("candidate_count"),
            "candidates": [group_summary(group) for group in row.get("candidates", [])],
        }
        for row in joint["all_ambiguities"]
    ]
    compare(
        "all_ambiguities_and_all_candidate_fragments",
        producer_joint.get("ambiguities"),
        expected_ambiguities,
        True,
    )
    expected_brake = [
        row
        for row in joint["all_cross_channel_high_overlap_or_boundary_contacts"]
        if row["both_sustained_high"]
    ]
    actual_brake = producer_joint["all_joint_long_high_overlap_candidates"]
    compare("all_joint_sustained_contact_count", len(actual_brake), len(expected_brake))
    for index, (actual, expected) in enumerate(zip(actual_brake, expected_brake)):
        normalized = {
            "begin_seconds": actual["begin_seconds"],
            "end_seconds": actual["end_seconds"],
            "duration_us": actual["duration_seconds"] * 1e6,
            "gpio18_pair_index": actual["gpio18_high"]["pair_index"],
            "gpio23_pair_index": actual["gpio23_high"]["pair_index"],
            "eligible_brake": actual["eligible_joint_brake"],
        }
        wanted = {
            "begin_seconds": expected["begin_seconds"],
            "end_seconds": expected["end_seconds"],
            "duration_us": expected["duration_us"],
            "gpio18_pair_index": expected["gpio18_pair_index"],
            "gpio23_pair_index": expected["gpio23_pair_index"],
            "eligible_brake": expected["eligible_brake_overlap"],
        }
        compare("joint_brake_contact:" + str(index), normalized, wanted, True)
    observations = {
        row["feature"]: row for row in producer_joint["physical_observations"]
    }
    for tag, chosen in joint["selected_unique_features"].items():
        suffix = "_physical_long_high" if tag.endswith("_full") else "_guarded_train"
        feature = tag + suffix
        compare(
            "selected_feature_presence:" + tag,
            feature in observations,
            chosen is not None,
        )
        if chosen is None or feature not in observations:
            continue
        evidence = observations[feature]["evidence"]
        if suffix == "_guarded_train":
            compare(
                "selected_full_train:" + tag,
                evidence.get("train"),
                group_summary(chosen),
                True,
            )
        else:
            compare(
                "selected_full_sustained_high:" + tag,
                evidence.get("complete_high_run"),
                high(chosen, nominals),
            )
        quiet = evidence.get("sibling", {})
        expected_quiet = joint["whole_extent_sibling_facts"][tag]
        compare(
            "whole_extent_sibling_low:" + tag,
            quiet.get("low_throughout_full_window_observed"),
            expected_quiet["entire_extent_sibling_low"],
        )
        compare(
            "no_guarded_core_substitution:" + tag,
            quiet.get("guarded_core_substitution_used"),
            False,
        )
    for index, observation in enumerate(observations.values()):
        for key in (
            "command_phase_clocks_aligned",
            "complete_command_phase_extent_identified",
            "exact_application_or_deinit_instant_identified",
        ):
            compare(
                "physical_observation_limit:" + str(index) + ":" + key,
                observation.get(key),
                False,
            )
    for key, value in {
        "waveform_accepted": None,
        "parity_pass": None,
        "matched_performance_parity": False,
        "whole_blinka_compatibility_proven": False,
        "application_latency_measured": False,
        "pi_saleae_clocks_aligned": False,
        "no_edge_trimming_or_glitch_filtering": True,
        "actuator_safety_established": False,
    }.items():
        compare("report_limit:" + key, report.get(key), value)
    a, b = (
        initial["gpio18_channel0"]["chunks"][0],
        initial["gpio23_channel1"]["chunks"][0],
    )
    nonlong = [
        row for row in b["all_high_runs"] if not row["descriptive_sustained_high"]
    ]
    diagnostic = {
        "gpio23_all_nonlong_highs_including_unmatched_count": len(nonlong),
        "gpio23_all_nonlong_high_extrema_us": stats(
            [row["width_us"] for row in nonlong]
        ),
        "gpio23_unmatched_nonlong_highs": [
            row for row in nonlong if not row["target_candidates"]
        ],
        "direction_signed_raw_forward_fall_to_first_reverse_rise_gap_us": (
            nonlong[0]["begin_seconds"] - a["all_high_runs"][-1]["end_seconds"]
        )
        * 1e6,
        "ordinary_fragment_pulse_counts": [
            len(row["pair_indices"])
            for row in joint["all_width_period_fragments_including_short"]["gpio23"][
                "motor_half"
            ]
        ],
    }
    return {
        "checks": checks,
        "check_count": len(checks),
        "mismatch_count": sum(not row["passed"] for row in checks),
        "all_checks_passed": all(row["passed"] for row in checks),
        "full_reverse_region_diagnostics_not_acceptance": diagnostic,
    }


def main():
    output = LAB / "oct7-installed-blinka-final-report-audit.json"
    if output.exists() or output.is_symlink():
        raise ValueError("Exclusive fresh final-audit output required")
    initial_path = LAB / INITIAL_NAME
    if (
        digest(initial_path) != INITIAL_SHA256
        or digest(LAB / "audit_installed_blinka_raw.py") != SOURCE_SHA256
    ):
        raise ValueError("Initial independent audit/source bytes changed")
    initial = read(initial_path)
    captures = {}
    for name in CAPTURES:
        producer = LAB / name / REPORT_NAME
        report = read(producer)
        facts = compare_capture(
            name,
            {
                **initial["captures"][name],
                "source_manifest": initial["source_manifest"],
            },
            report,
            initial["nominals_from_integer_u16_c_rounding"],
        )
        facts["producer_report_sha256"] = digest(producer)
        captures[name] = facts
    if digest(initial_path) != INITIAL_SHA256:
        raise ValueError("Initial audit changed during comparison")
    result = {
        "schema_version": 1,
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "method": __doc__,
        "comparison_source_sha256": digest(__file__),
        "initial_audit_sha256": INITIAL_SHA256,
        "initial_audit_source_sha256": SOURCE_SHA256,
        "initial_audit_bytes_unchanged": True,
        "plan_sha256": initial["plan_sha256"],
        "captures": captures,
        "check_count": sum(row["check_count"] for row in captures.values()),
        "mismatch_count": sum(row["mismatch_count"] for row in captures.values()),
        "all_checks_passed": all(row["all_checks_passed"] for row in captures.values()),
        "scope": "Comparison to pre-producer independent raw reconstruction only; no waveform acceptance, parity, latency, safety or whole-Blinka compatibility claim",
    }
    with output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "check_count": result["check_count"],
                "mismatch_count": result["mismatch_count"],
                "all_checks_passed": result["all_checks_passed"],
                "report_sha256": digest(output),
            }
        )
    )
    return 0 if result["all_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
