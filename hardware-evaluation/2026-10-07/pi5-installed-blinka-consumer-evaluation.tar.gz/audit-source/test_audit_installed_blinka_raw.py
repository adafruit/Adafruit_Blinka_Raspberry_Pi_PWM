"""Synthetic binary/receipt regressions for the independent offline decoder."""

import copy
import json
import shlex
import struct

import audit_installed_blinka_raw as audit
import pytest


def digital(path, chunks, version=0):
    value = b"<SALEAE>" + struct.pack("<ii", version, 0)
    if version:
        value += struct.pack("<Q", len(chunks))
    for initial, begin, end, edges in chunks:
        value += struct.pack("<I", initial)
        if version:
            value += struct.pack("<d", 100_000_000)
        value += struct.pack("<ddQ", begin, end, len(edges))
        value += struct.pack("<" + str(len(edges)) + "d", *edges)
    path.write_bytes(value)
    return path


def test_all_edges_runs_and_adjacent_rises_preserved(tmp_path):
    path = digital(
        tmp_path / "digital_0.bin", [(0, 0, 1, [0.1, 0.101, 0.12, 0.121, 0.14, 0.167])]
    )
    result = audit.decode(path)
    chunk = result["chunks"][0]
    assert [row["seconds"] for row in chunk["edges"]] == [
        0.1,
        0.101,
        0.12,
        0.121,
        0.14,
        0.167,
    ]
    assert (
        chunk["transition_count"] == 6
        and chunk["initial_level"] == chunk["final_level"] == 0
    )
    assert len(chunk["all_high_runs"]) == 3 and len(chunk["all_low_runs"]) == 4
    assert chunk["all_high_runs"][-1]["width_us"] == pytest.approx(27000)
    assert chunk["full_high_width_stats_us"]["maximum"] == pytest.approx(27000)
    assert chunk["all_adjacent_rise_intervals_us"] == pytest.approx([20000, 20000])
    assert chunk["all_low_runs"][0]["left_capture_boundary"]
    assert chunk["all_low_runs"][-1]["right_capture_boundary"]


def test_high_boundary_runs_not_invented_as_edges(tmp_path):
    result = audit.decode(digital(tmp_path / "digital_0.bin", [(1, 0, 1, [0.1, 0.2])]))
    chunk = result["chunks"][0]
    assert [row["level_after"] for row in chunk["edges"]] == [0, 1]
    assert chunk["initial_level"] == chunk["final_level"] == 1
    assert chunk["all_high_runs"][0]["left_capture_boundary"]
    assert chunk["all_high_runs"][-1]["right_capture_boundary"]
    assert chunk["all_rise_seconds"] == [0.2]
    assert not chunk["all_adjacent_rise_intervals_us"]


def test_version1_gaps_never_bridge_adjacent_rises(tmp_path):
    result = audit.decode(
        digital(
            tmp_path / "digital_0.bin",
            [(0, 0, 1, [0.1, 0.101]), (0, 2, 3, [2.1, 2.101])],
            version=1,
        )
    )
    assert len(result["chunks"]) == 2
    assert all(row["header_sample_rate_hz"] == 100_000_000 for row in result["chunks"])
    assert all(row["all_adjacent_rise_intervals_us"] == [] for row in result["chunks"])
    with pytest.raises(ValueError, match="single chunk"):
        audit.joint_facts(result, result)


@pytest.mark.parametrize("edges", [[0.2, 0.1], [0.1, 0.1], [float("nan")], [1.2]])
def test_bad_transition_order_or_finiteness_rejected(tmp_path, edges):
    with pytest.raises(ValueError):
        audit.decode(digital(tmp_path / "bad.bin", [(0, 0, 1, edges)]))


def test_truncation_and_trailing_data_fail(tmp_path):
    path = digital(tmp_path / "bad.bin", [(0, 0, 1, [0.1, 0.2])])
    original = path.read_bytes()
    for changed in (original[:-1], original + b"extra"):
        path.write_bytes(changed)
        with pytest.raises(ValueError):
            audit.decode(path)


def test_short_fragments_and_period_anomaly_not_erased(tmp_path):
    rises = [0.1, 0.12, 0.14, 0.16, 0.18, 0.4, 0.42]
    edges = [point for rise in rises for point in (rise, rise + 0.000999771)]
    chunk = audit.decode(digital(tmp_path / "trains.bin", [(0, 0, 1, edges)]))[
        "chunks"
    ][0]
    blocks = audit.fragments(chunk, "servo_angle0")
    assert [len(block["pair_indices"]) for block in blocks] == [5, 2]
    assert [block["eligible_train"] for block in blocks] == [True, False]
    assert sum(len(block["all_high_widths_us"]) for block in blocks) == 7
    assert chunk["full_adjacent_rise_stats_us"]["maximum"] == pytest.approx(220000)


def test_symmetric_band_is_identification_not_target_centered(tmp_path):
    width = audit.NOMINALS["motor_half"]["high_us"] * 1.105 / 1e6
    chunk = audit.decode(
        digital(tmp_path / "band.bin", [(0, 0, 1, [0.1, 0.1 + width])])
    )["chunks"][0]
    assert "motor_half" in chunk["all_high_runs"][0]["target_candidates"]


def test_cross_channel_boundary_touch_and_overlap_preserved(tmp_path):
    a = audit.decode(digital(tmp_path / "a.bin", [(0, 0, 1, [0.1, 0.2, 0.3, 0.4])]))
    b = audit.decode(digital(tmp_path / "b.bin", [(0, 0, 1, [0.15, 0.25, 0.4, 0.5])]))
    facts = audit.joint_facts(a, b)
    contacts = facts["all_cross_channel_high_overlap_or_boundary_contacts"]
    assert len(contacts) == 2
    assert contacts[0]["duration_us"] == pytest.approx(50000)
    assert contacts[1]["sample_tied_boundary_touch"] and contacts[1]["duration_us"] == 0
    assert facts["complete_ordered_joint_topology_supported"] is False


@pytest.fixture
def receipts(tmp_path):
    manifest = {
        "source_sha256": {audit.HELPER_NAME: "a" * 64},
        "source_paths": {"x": "/tmp/fake"},
        "distribution_versions": {"motor": "3.5.0"},
    }
    plan = {"collector_sha256": "b" * 64, "preflight_receipt_sha256": "c" * 64}
    remote = {
        "mode": audit.MODE,
        "backend": "native-blinka-pwm",
        "sequence_marker": audit.MARKER,
        "gpios": [18, 23],
        "primary_error": None,
        "cleanup_errors": [],
        "signals_received": [],
        "success": True,
        "completed_normally": True,
        "source_sha256": manifest["source_sha256"],
        "source_paths": manifest["source_paths"],
        "distribution_versions": manifest["distribution_versions"],
        "manifest_path": audit.ROOT + "/" + audit.MANIFEST_NAME,
        "python_executable": audit.PYTHON,
        "isolated_python": True,
        "noninteractive_no_runtime_installs": True,
        "inherited_environment": {},
        "installed_dispatch": {
            "real_board_used": True,
            "real_pwmio_used": True,
            "unwrapped_public_pwm_objects": True,
            "pwmout_identity_verified": True,
            "virtual_pwmio_export_used": False,
            "board_id": "RASPBERRY_PI_5",
            "chip_id": "BCM2XXX",
            "pin_class_module": audit.PIN_MODULE,
            "pin_ids": [18, 23],
        },
        "blinka_import_chip": {
            "opened": True,
            "closed": True,
            "hooks_restored": True,
            "claims_or_writes_permitted": False,
            "verified_chip_index": 0,
            "handle": 0,
            "errors": [],
            "events": [
                {"operation": "gpiochip_open", "status": "ok"},
                {"operation": "gpiochip_close", "status": "ok", "returncode": 0},
            ],
        },
        "outputs": [],
        "phases": [],
        "actions": [],
        "shutdowns": [],
        "events": [{"status": "ok"}],
        "runtime_flags": {"short_slice": False, "shared": False},
    }
    for name, gpio, generation, frequency in (
        ("servo18-g1", 18, 1, 50),
        ("motor18-g2", 18, 2, 1000),
        ("motor23-g1", 23, 1, 1000),
    ):
        output = {
            "output_id": name,
            "gpio": gpio,
            "generation": generation,
            "initial_frequency": frequency,
            "real_board_pin": {
                "attribute": "D" + str(gpio),
                "id": gpio,
                "class_module": audit.PIN_MODULE,
            },
            "owned_request": {"chip_name": "gpiochip0", "offsets": [gpio], "fd": gpio},
            "initial_readback": {"gpio_level": 0, "inactive": True},
            "cleanup_final_readback": {"gpio_level": 0, "inactive": True},
        }
        output.update(
            {
                key: True
                for key in (
                    "fresh_claim_accepted",
                    "initial_low_confirmed",
                    "low_confirmed",
                    "released",
                    "read_only_chip_closed",
                )
            }
        )
        for key in ("preclaim_line_info", "released_line_info"):
            output[key] = {"offset": gpio, "used": False, "consumer": None}
        remote["outputs"].append(output)
        remote["shutdowns"].append({"output_id": name, "success": True, "errors": []})
    sibling = {"gpio_level": 0, "duty_u16": 0}
    remote["shutdowns"][1].update(
        sibling_id="motor23-g1",
        sibling_before=sibling,
        sibling_after=copy.deepcopy(sibling),
    )
    for index, (name, duration, operation, value) in enumerate(audit.SEQUENCE):
        remote["phases"].append(
            {
                "index": index,
                "name": name,
                "duration_seconds": duration,
                "operation": operation,
                "value": value,
                "begin_ns": 100 + index * 10,
                "stable_begin_ns": 101 + index * 10,
                "end_ns": 102 + index * 10,
                "readback_end_ns": 103 + index * 10,
            }
        )
        if operation not in ("Servo.angle", "DCMotor.throttle"):
            continue
        if operation == "Servo.angle":
            duties = [{0: 3276, 90: 4914, 180: 6553, None: 0}[value]]
            frequencies = [50]
        else:
            duties = (
                [0, 0]
                if value is None
                else [65535, 65535]
                if value == 0
                else [int(abs(value) * 65535), 0]
                if value > 0
                else [0, int(abs(value) * 65535)]
            )
            frequencies = [1000, 1000]
        remote["actions"].append(
            {
                "phase_index": index,
                "operation": operation,
                "value": value,
                "status": "ok",
                "api_state_after": [
                    {"duty_u16": duty, "frequency": frequency}
                    for duty, frequency in zip(duties, frequencies, strict=True)
                ],
            }
        )
    result = {
        "mode": audit.MODE,
        "backend": "native-blinka-pwm",
        "remote_returncode": 0,
        "collection_success": True,
        "remote": remote,
        "source_manifest": manifest,
        "source_plan": plan,
        "manifest_sha256": "d" * 64,
        "plan_sha256": "e" * 64,
        "collector_sha256": "b" * 64,
        "helper_sha256": "a" * 64,
        "preflight_receipt_sha256": "c" * 64,
    }
    acquisition = {
        "mode": audit.MODE,
        "backend": "native-blinka-pwm",
        "remote_returncode": 0,
        "primary_error": None,
        "evidence_errors": [],
        "manifest_sha256": "d" * 64,
        "plan_sha256": "e" * 64,
        "remote_root": audit.ROOT,
        "remote_python": audit.PYTHON,
        "preflight_receipt_sha256": "c" * 64,
        "remote_command": [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            shlex.join(
                [
                    audit.PYTHON,
                    "-I",
                    audit.ROOT + "/" + audit.HELPER_NAME,
                    "--manifest",
                    audit.ROOT + "/" + audit.MANIFEST_NAME,
                ]
            ),
        ],
    }
    data = {
        "manifest.json": manifest,
        "plan.json": plan,
        "remote.stdout": remote,
        "results.json": result,
        "acquisition.json": acquisition,
    }
    return tmp_path, manifest, plan, data


def evaluate(receipts):
    directory, manifest, plan, data = receipts
    for name, value in data.items():
        (directory / name).write_text(json.dumps(value))
    return audit.verify_receipts(directory, manifest, plan, "d" * 64, "e" * 64)


def test_independent_manual_receipt_checks_accept_complete_contract(receipts):
    report = evaluate(receipts)
    assert report["all_checks_passed"]
    assert report["phase_count"] == 15 and report["action_count"] == 10
    assert len(report["private_outputs"]) == 3


@pytest.mark.parametrize(
    "filename,field,value",
    [
        ("results.json", "remote_returncode", False),
        ("acquisition.json", "remote_returncode", None),
        ("remote.stdout", "source_sha256", {}),
        ("remote.stdout", "primary_error", "failure"),
        ("remote.stdout", "cleanup_errors", ["failure"]),
        ("remote.stdout", "isolated_python", False),
        ("acquisition.json", "remote_command", []),
        ("results.json", "manifest_sha256", "f" * 64),
    ],
)
def test_manual_receipt_failures_visible_not_fabricated_success(
    receipts, filename, field, value
):
    receipts[3][filename][field] = value
    assert not evaluate(receipts)["all_checks_passed"]


@pytest.mark.parametrize("value", [False, None, 1])
def test_import_handle_close_requires_actual_typed_zero(receipts, value):
    receipts[3]["remote.stdout"]["blinka_import_chip"]["events"][-1]["returncode"] = (
        value
    )
    assert not evaluate(receipts)["all_checks_passed"]


def test_import_chip_gpio_mutator_event_not_tolerated(receipts):
    receipts[3]["remote.stdout"]["blinka_import_chip"]["events"].append(
        {"operation": "gpio_write", "status": "ok"}
    )
    assert not evaluate(receipts)["all_checks_passed"]


def test_misordered_or_missing_generation_and_action_reported(receipts):
    receipts[3]["remote.stdout"]["outputs"].reverse()
    receipts[3]["remote.stdout"]["actions"].pop()
    assert not evaluate(receipts)["all_checks_passed"]
