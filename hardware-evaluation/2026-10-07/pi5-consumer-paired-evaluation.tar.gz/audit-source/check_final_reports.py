"""Offline receipt/report comparison, intentionally excludes all waveform arrays."""
import hashlib
import json
from pathlib import Path

ROOT=Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
DEST=Path('/private/tmp/paired-receipts-audit.WL4JrM/final_receipt_comparison.json')
NAMES=['oct7-pi5-lgpio-consumers-r1','oct7-pi5-native-consumers-paired-r1','oct7-pi5-native-consumers-paired-r2','oct7-pi5-lgpio-consumers-r2']
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
CHECKS=[]; SUMMARY=[]
def check(name,value): CHECKS.append({'name':name,'passed':bool(value)})
ip=ROOT/'oct7-lgpio-consumers-paired-independent-audit.json'; initial=read(ip)
rp=Path('/private/tmp/paired-receipts-audit.WL4JrM/receipt_checks.json'); receipt=read(rp)
check('initial embeds exact independently completed receipt check',initial['additional_independent_receipt_checks']==receipt and initial['additional_receipt_check_file_sha256']==sha(rp))
plan=read(ROOT/'oct7-lgpio-consumers-plan.json')
for name in NAMES:
    original='lgpio-consumers' in name
    p=ROOT/name; filename='analysis.json' if original else 'consumer-analysis.json'; report=read(p/filename)
    res=read(p/'results.json'); acq=read(p/'acquisition.json'); remote=res['remote']; manifest=read(p/'manifest.json')
    ir=initial['runs'][name]; raw=ir['offline_receipt_source_ownership_checks']
    check(name+' correct report name/backend',report['capture']==name and report['backend']==res['backend'])
    for filename_raw in ['results.json','acquisition.json','remote.stdout','remote.stderr','manifest.json']:
        check(name+' report raw evidence hash '+filename_raw,report['evidence_sha256'][filename_raw]==sha(p/filename_raw))
    check(name+' initial manifest unchanged',raw['selected_frozen_manifest']==manifest)
    check(name+' initial recorded SSH exits unchanged',raw['actual_consumer_ssh_exit_statuses']=={'acquisition_remote_returncode':acq['remote_returncode'],'results_remote_returncode':res['remote_returncode']})
    for key,value in raw['receipt_fields'].items(): check(name+' initial receipt field '+key,value==remote[key])
    for ik,rk in [('outputs_ownership_and_cleanup','outputs'),('shutdowns','shutdowns'),('recorded_phase_data_unmapped_to_saleae','phases'),('recorded_actions_unmapped_to_saleae','actions'),('recorded_events_on_pi_clock_not_latency','events'),('recorded_preclaim_lines','preclaim_lines')]:
        check(name+' initial raw block '+ik,raw[ik]==remote[rk])
    for key,value in raw['backend_specific_cleanup_fields'].items(): check(name+' initial backend field '+key,value==remote[key])
    check(name+' preserved stderr unchanged',raw['remote_stderr_preserved']['sha256']==sha(p/'remote.stderr') and raw['remote_stderr_preserved']['complete_text']==(p/'remote.stderr').read_text())
    if original:
        fr=report['functional_receipts']
        check(name+' exact21 report source hashes',fr['selected_source_sha256']==manifest['source_sha256']==remote['source_sha256'])
        check(name+' report actual SSH exit',fr['actual_ssh_returncode']==acq['remote_returncode']==res['remote_returncode']==0)
        for key in ['remote_root','remote_python','remote_program']: check(name+' report '+key,fr[key]==res[key]==acq[key])
        check(name+' original nominal table exact',report['original_percent_nominals']==res['original_percent_nominals']==plan['original_percent_nominals'])
        check(name+' original nominal high widths equal initial',{k:v['submitted_nominal_high_us'] for k,v in report['original_percent_nominals'].items()}==ir['nominal_targets_us'])
        check(name+' frozen plan hash',report['frozen_plan']['sha256']==initial['frozen_plan_sha256']==sha(ROOT/'oct7-lgpio-consumers-plan.json'))
        check(name+' original receipt scope not electrical','not electrical facts' in fr['scope'])
        check(name+' original limitations deny overclaims',all(any(s in line for line in report['limitations']) for s in ['not waveform acceptance','clocks are unaligned','not deadtime','deinit alone does not cancel/free GPIO','not installed Blinka or actual actuator proof']))
        coverage={'embedded_receipt_blocks':[],'actual_ssh_exit_field':'functional_receipts.actual_ssh_returncode','unexposed_raw_facts':['outputs/generations/private handle','phases/actions/nested caller events','shim/library-hook restoration','runtime flags/inherited environment','helper begin/end','chip_closed','stderr diagnostic text/classification'],'validation_delegation':fr['receipt_validation']}
    else:
        vr=report['validated_receipt_consumer_api_and_ownership_not_electrical_phase_identity']
        check(name+' exact18 full report manifest',report['source_manifest']==manifest)
        for key,value in vr.items(): check(name+' native embedded receipt block '+key,value==remote[key])
        events=report['caller_events_pi_clock']
        check(name+' native raw caller event copy', [{k:v for k,v in e.items() if k!='caller_duration_us'} for e in events]==remote['events'])
        for e in events: check(name+' native caller duration '+str(e['ordinal']),e['caller_duration_us']==(e['end_ns']-e['begin_ns'])/1000)
        check(name+' native nominal high widths equal initial',{k:v['high_us'] for k,v in report['actual_consumer_u16_c_rounded_nominals'].items()}==ir['nominal_targets_us'])
        targets={'servo_angle0':(50,3276),'servo_angle90':(50,4914),'servo_angle180':(50,6553),'motor_half':(1000,32767)}
        for key,(hz,duty) in targets.items():
            period_ns=round(1e9/hz); high_ns=round(period_ns*duty/65535)
            check(name+' independently C-rounded nominal '+key,report['actual_consumer_u16_c_rounded_nominals'][key]=={'frequency_hz':hz,'duty_u16':duty,'period_us':period_ns/1000,'high_us':high_ns/1000})
        requested={'servo_angle0':1000,'servo_angle90':1500,'servo_angle180':2000}
        check(name+' native ideal-minus-actual nominal delta',report['common_requested_servo_high_us_minus_actual_c_rounded_us']=={k:width-report['actual_consumer_u16_c_rounded_nominals'][k]['high_us'] for k,width in requested.items()})
        check(name+' native frozen protocol plan hash',report['plan_sha256']==plan['native_reference']['unchanged_protocol_plan_sha256']==sha(ROOT/'oct7-native-consumers-plan.json'))
        expected_scope={'collection_receipts_validated':True,'functional_consumer_integration_only':True,'passive_probes_only':True,'actual_actuator_operation_established':False,'installed_blinka_compatibility_proven':False,'waveform_accepted':None,'parity_pass':None,'matched_performance_parity':False,'pi_saleae_clocks_aligned':False,'application_latency_measured':False,'timebase_gpio_driver_and_threshold_skew_calibrated':False}
        for key,value in expected_scope.items(): check(name+' native limited scope '+key,report[key]==value)
        coverage={'embedded_receipt_blocks':list(vr),'caller_event_count':len(events),'actual_ssh_exit_field':None,'unexposed_raw_facts':['actual SSH exit (raw results/acquisition independently0)','runtime flags/inherited environment','helper begin/end','global read_only_chip_closed','primary_error/cleanup_errors/signals_received/success','stderr diagnostic text/classification'],'validation_boolean_not_ssh_status':'collection_receipts_validated'}
    SUMMARY.append({'name':name,'report_filename':filename,'report_sha256':sha(p/filename),'coverage':coverage})
out={'schema_version':1,'purpose':'Offline final-report source/receipt/ownership/nominal/scope comparison only; waveform values/topology/fragment classifications checked separately by parent','passed':all(x['passed'] for x in CHECKS),'check_count':len(CHECKS),'mismatches':[x for x in CHECKS if not x['passed']],'checks':CHECKS,'reports':SUMMARY,'initial_audit_sha256':sha(ip),'receipt_check_sha256':sha(rp),'retained_method_difference':'Parent identified original r1 GPIO23 index25 width551.170us retained identically: final symmetric-looking relative tolerance tags motor_half while frozen target-relative500us +/-10% rejects it. No raw-width discrepancy; receipt comparisons do not evaluate identity tagging or confer topology credit.','limitations':['Original report delegates original API/private-handle-generation/cleanup validation; exact nested events and cleanup proof are in saved raw receipts and immutable initial audit, not serialized in report.','Native report embeds exact receipt blocks/caller events but omits actual SSH exit, runtime flags/environment and helper/global error/chip fields; collection_receipts_validated is not a substitute for an exit field.','Original private request wording is generic: actual ownership is lgpio private chip handle, GPIO and generation, not a native gpiod request.','Source inventories attest selected saved sources only; do not establish whole-system or installed Blinka/actuator compatibility.','No hardware/network calls, analyzer-source reads, edits of reports/raw artifacts/immutable initial audit, or waveform acceptance/parity inference.']}
DEST.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'output':str(DEST),'sha256':sha(DEST),'passed':out['passed'],'check_count':len(CHECKS),'mismatches':out['mismatches'],'reports':SUMMARY},indent=2))
