"""Offline post-reconstruction report comparison. No project imports."""
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT=Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
INITIAL=ROOT/'oct7-lgpio-consumers-paired-independent-audit.json'
NOTES=ROOT/'oct7-lgpio-consumers-paired-independent-notes.txt'
FINAL=ROOT/'oct7-lgpio-consumers-paired-final-report-audit.json'
INITIAL_HASH='4036c3ca1c5d0066c03b8aa478462b99d235472b8a0d862af7a408cec0fb8ab7'
NOTES_HASH='acd48faa2d3b09219febad2357cae85d2dd362a3cd3dd0f1f86afa5574129293'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(v):
    v=list(v)
    return {'count':0}if not v else{'count':len(v),'min':min(v),'median':statistics.median(v),'max':max(v),'mean':statistics.mean(v)}
def same_stats(a,b):
    return {k:a[k]==b[k]if k=='count'else math.isclose(a[k],b[k],abs_tol=1e-7,rel_tol=0)for k in b}
def touching(highs,a,b):return [x['high_index']for x in highs if x['start_s']<=b and x['end_s']>=a]
def false_paths(v,prefix=''):
    found=[]
    if isinstance(v,dict):
        for k,x in v.items():found.extend(false_paths(x,prefix+'.'+k if prefix else k))
    elif v is not True:found.append(prefix)
    return found

assert sha(INITIAL)==INITIAL_HASH and sha(NOTES)==NOTES_HASH
base=json.loads(INITIAL.read_text())
result={'schema_version':1,'audit_kind':'final-report-comparison-after-immutable-independent-paired-audit',
        'immutable_initial_artifacts':{'audit':{'path':INITIAL.name,'sha256':INITIAL_HASH},'notes':{'path':NOTES.name,'sha256':NOTES_HASH}},
        'initial_bytes_unchanged':True,'hardware_network_or_saleae_used':False,
        'analyzer_sources_read':False,'reports_modified':False,
        'report_filename_selection':{'original':'analysis.json','native':'consumer-analysis.json','difference_is_cli_filename_default_not_waveform_data':True},
        'statistics_tolerance_us':1e-7,
        'method_differences':[
            'Independent reconstruction imports no project helper/analyzer and uses direct struct decoding. Reports expose reused raw facts and conditional candidate identity. Comparison checks common numerical facts against the already immutable arrays.',
            'Independent full nearest-nominal blocks retain every nearest-target high, including out-of-band values. Final diagnostic distributions and blocks use matching target candidates and may exclude unmatched highs from a labeled distribution while retaining them in complete raw arrays.',
            'Initial strict diagnostic band is target-normalized: abs(width-target)<=0.1*target. Final candidate tags are reproduced by symmetric math.isclose(width,target,rel_tol=0.1), which uses the larger magnitude. This behavior is inferred from report outputs, not analyzer source inspection. In original r1, 551.170us is outside500us+/-50us yet inside the symmetric relative convention, so the two methods produce different labeled fragments.',
            'Original r1 independent reverse fragments are20/1-anomaly/3/1-anomaly/325 pulses. Final reported motor-half blocks are20 and329 pulses, with425.110us index21 unmatched and551.170us index25 retained within the second block. The latter is only a conditional selected candidate: the final report explicitly retains unassigned indices1..21 and withholds complete topology.',
            'Independent entire original reverse350-pulse group has a peer-high boundary overlap. Final r1 selected later329-pulse candidate is isolated but does not substitute for the whole extent; r2 has no isolated reverse candidate and retains all350 unassigned highs. Both final full-extent topology results remain withheld, agreeing with the conservative independent conclusion.',
            'Independent same-block low summaries exclude cross-label/end-point lows, but those are retained separately and globally. Final feature-window low lists include overlapping endpoint/boundary runs. The all-low comparison uses the same inclusive basis and checks every interval exactly.',
            'Independent statistics add nearest-rank quantiles/population standard deviations and full target errors. Shared report count/min/median/max/mean statistics are recomputed on each exact reported raw subset, not compared across unlike fragment/distribution bases.',
            'Original final ownership/source validation is delegated and summarized rather than re-emitting all private cleanup receipts. Native final reports expose complete API/ownership phases/actions. Saved raw receipt hashes and the prior1580-check offline audit remain the detailed ownership/exits evidence.',
            'Original withheld-topology state is represented as null compatible_unique_ordered_topology; independent audit uses false. These both mean no complete isolated ordered topology established, not a quantitative parity or safety verdict.'],
        'runs':{}}

for stem,own in base['runs'].items():
    original=own['backend']=='original-blinka-lgpio';name='analysis.json'if original else'consumer-analysis.json';path=ROOT/stem/name
    report=json.loads(path.read_text());check={};raw_summary=[];fragment_checks=[];normalized=[]
    channels=report['raw_channels']if original else{'gpio18_ch0':report['gpio18_channel0'],'gpio23_ch1':report['gpio23_channel1']}
    for ch,key in[('0','gpio18_ch0'),('1','gpio23_ch1')]:
        a=own['channels'][ch];b=channels[key];header=a['header'];wave=b['waveform']
        check[key+'_header']={k:wave[k]==header[v]for k,v in{'binary_format_version':'version','begin_seconds':'begin_s','end_seconds':'end_s','initial_state':'initial_state','edge_count':'transition_count'}.items()}
        check[key+'_header']['final_state']=wave['final_state']==a['final_state']
        check[key+'_all_transition_times_exact']=wave['transition_seconds']==a['all_transition_times_s']
        hi=[(x['start_s'],x['end_s'],x['duration_us'])for x in a['all_high_intervals']]
        lo=[(x['start_s'],x['end_s'],x['duration_us'])for x in a['all_low_intervals_including_endpoints']]
        ri=[(x['earlier_rise_s'],x['later_rise_s'],x['duration_us'])for x in a['all_adjacent_rise_intervals_including_discontinuities']]
        check[key+'_all_high_intervals_exact']=hi==[(x['rise_seconds'],x['fall_seconds'],x['width_us'])for x in b['all_high_runs']]
        check[key+'_all_low_intervals_including_endpoints_exact']=lo==[(x['begin_seconds'],x['end_seconds'],x['width_us'])for x in b['all_low_runs']]
        check[key+'_all_adjacent_rises_and_discontinuities_exact']=ri==[(x['begin_seconds'],x['end_seconds'],x['rise_to_rise_us'])for x in b['all_adjacent_rise_intervals']]
        for tag,key_stats,v in[('high','all_high_width_stats_us',hi),('low','all_low_width_stats_us',lo),('rise','all_adjacent_rise_stats_us',ri)]:check[key+'_global_'+tag+'_stats']=same_stats(stats(x[2]for x in v),b[key_stats])
        check[key+'_sub_microsecond_highs']=len(b['sub_microsecond_highs'])==len(a['sub_microsecond_high_indices'])==0
        check[key+'_sub_microsecond_interior_lows']=len(b['sub_microsecond_interior_lows'])==len(a['sub_microsecond_interior_low_indices'])==0
        targets=own['nominal_targets_us'];candidate_checks=[];unmatched=[]
        for x,y in zip(a['all_high_intervals'],b['all_high_runs']):
            if x['duration_us']>=100000:candidates=[]
            else:candidates=[tag for tag,target in targets.items()if math.isclose(x['duration_us'],target,rel_tol=.1,abs_tol=0)]
            nearest=min(targets,key=lambda tag:abs(x['duration_us']-targets[tag]))
            candidate_checks.append(candidates==y['width_target_candidates'] and nearest==y['nearest_width_target'] and math.isclose(x['duration_us']-targets[nearest],y['nearest_width_target_error_us'],rel_tol=0,abs_tol=1e-7))
            if not candidates and x['duration_us']<100000:unmatched.append(x['high_index'])
        check[key+'_diagnostic_candidate_mapping_reproduced_by_symmetric_relative_tolerance']=all(candidate_checks)
        check[key+'_unmatched_pairs_under_report_candidate_convention']=unmatched==b['unmatched_width_pair_indices']
        raw_summary.append({'channel':int(ch),'transitions':len(a['all_transition_times_s']),'complete_high_count':len(hi),'all_low_count_including_endpoints':len(lo),'all_adjacent_rise_count':len(ri),
                            'complete_raw_high_stats_us':a['all_high_width_stats_us'],'report_unmatched_candidate_high_indices':unmatched})
        if original:
            for tag,dist in b['target_normalized_width_distributions'].items():
                ids=dist['pair_indices'];vals=[a['all_high_intervals'][i]['duration_us']for i in ids];target=targets[tag]
                expected_ids=[x['high_index']for x in a['all_high_intervals']if x['duration_us']<100000 and math.isclose(x['duration_us'],target,rel_tol=.1)]
                item={'channel':ch,'target_tag':tag,'pair_indices_match_report_candidate_convention':ids==expected_ids,
                      'raw_width_stats':same_stats(stats(vals),dist['width_us']),
                      'ratio_stats':same_stats(stats(v/target for v in vals),dist['width_divided_by_target']),
                      'difference_stats':same_stats(stats(v-target for v in vals),dist['width_minus_target_us'])}
                normalized.append(item);check[key+'_normalized_'+tag]={k:v for k,v in item.items()if k not in('channel','target_tag')}
            blocks=b['all_width_period_blocks']
        else:blocks=report['functional_waveform_facts']['all_width_period_train_fragments_including_short']['gpio18'if ch=='0'else'gpio23']
        for tag,arr in blocks.items():
            for index,t in enumerate(arr):
                ids=t['pair_indices'];hs=[a['all_high_intervals'][i]for i in ids]
                periods=[(n['start_s']-p['start_s'])*1e6 for p,n in zip(hs,hs[1:])]
                item={'channel':ch,'tag':tag,'first_high_index':ids[0],'last_high_index':ids[-1],'pulse_count':len(ids),
                      'checks':{'contiguous_raw_indices':ids==list(range(ids[0],ids[-1]+1)),
                                'begin_end_exact':(t['begin_seconds'],t['end_seconds'])==(hs[0]['start_s'],hs[-1]['end_s']),
                                'complete_fragment_high_stats':same_stats(stats(x['duration_us']for x in hs),t['high_width_stats_us']),
                                'complete_fragment_adjacent_rise_stats':same_stats(stats(periods),t['period_stats_us'])}}
                fragment_checks.append(item);check[key+'_fragment_'+tag+'_'+str(index)]=item['checks']
    hashes=own['raw_file_sha256_and_sizes']
    check['all_evidence_hashes_match_immutable_initial_raw_audit']=all(hashes[stem+'/'+filename]['sha256']==digest for filename,digest in report['evidence_sha256'].items())
    check['all_raw_files_still_match_immutable_initial_hashes']=all(sha(ROOT/file)==v['sha256']for file,v in hashes.items())
    saved=report['saved_sal']if original else report['saved_capture_settings']
    check['saved_sal_metadata_flags_agree']=saved=={'channels':[0,1],'sample_rate_hz':100000000,'physical_device':True,'glitch_filter':False}
    initial_receipts=own['offline_receipt_source_ownership_checks'];remote=json.loads((ROOT/stem/'results.json').read_text())['remote'];acq=json.loads((ROOT/stem/'acquisition.json').read_text())
    check['recorded_actual_ssh_exit_evidence_zero_and_unchanged']=initial_receipts['actual_consumer_ssh_exit_statuses']=={'acquisition_remote_returncode':0,'results_remote_returncode':0}and acq['remote_returncode']==0
    check['prior_detailed_independent_receipt_checks_passed']=base['additional_independent_receipt_checks']['passed']is True and base['additional_independent_receipt_checks']['failures']==[]
    if original:
        check['frozen_plan_reference_hash_agrees']=report['frozen_plan']['sha256']==base['frozen_plan_sha256']
        check['frozen_helper_collector_analyzer_hash_declarations_agree']={k:report['frozen_plan']['source_sha256'][name]==base['frozen_plan'][k]for k,name in[('helper_sha256','lgpio_pwm_consumers_eval.py'),('collector_sha256','capture_lgpio_pwm_consumers.py'),('analyzer_sha256','analyze_lgpio_pwm_consumers.py')]}
        check['selected_original21_source_hashes_exact']=report['functional_receipts']['selected_source_sha256']==remote['source_sha256']==initial_receipts['selected_frozen_manifest']['source_sha256']
        check['report_actual_ssh_returncode_exact']=report['functional_receipts']['actual_ssh_returncode']==0
        check['original_nominal_percent_targets_exact']=report['original_percent_nominals']==base['frozen_plan']['original_percent_nominals']
        check['original90_4914_submits7percent_1400us']=report['original_percent_nominals']['servo_angle90']=={'frequency_hz':50,'duty_u16':4914,'submitted_duty_percent':7,'submitted_nominal_high_us':1400.0}
        top=report['ordered_raw_topology'];selection=top['selected_candidates']
        check['original_complete_isolated_topology_withheld']=top['compatible_unique_ordered_topology']is None and own['complete_frozen_isolated_ordered_topology_supported']is False
        observations=top['candidate_whole_run_observations']
        for obs in observations:
            gpio=obs['gpio'];ch='0'if gpio==18 else'1';peer=own['channels']['1'if ch=='0'else'0']['all_high_intervals'];candidate=obs['candidate']
            if 'pair_indices'in candidate:
                ids=candidate['pair_indices'];hs=[own['channels'][ch]['all_high_intervals'][i]for i in ids];begin,end=hs[0]['start_s'],hs[-1]['end_s']
                check['selected_'+obs['feature']+'_raw_width_stats']=same_stats(stats(x['duration_us']for x in hs),candidate['high_width_stats_us'])
            else:begin,end=candidate['rise_seconds'],candidate['fall_seconds']
            sibling=obs['sibling_raw_window'];touch=touching(peer,begin,end)
            check['selected_'+obs['feature']+'_whole_boundary_sibling']={'touching_indices_exact':sibling['overlapping_high_pair_indices']==touch,
                 'full_window_exact':sibling['window_seconds']==[begin,end],'low_throughout_full_window_flag':sibling['whole_run_boundary_inclusive_low']==(not touch),
                 'boundary_runs_preserved':sibling['boundary_runs_not_discarded']is True}
        check['original_full_positive_peer_overlap_explicitly_withheld']=any(x['feature']=='motor_forward_full'and x['reason']=='sibling_high_overlaps_or_touches_whole_run_boundary'and x['sibling_high_pair_indices']==[1]for x in top['ambiguities'])
        if stem.endswith('r1'):
            check['r1_reverse_full_extent_unassigned_prefix_explicit']=any(x['feature']=='reverse_half_full_extent'and x['pair_indices']==list(range(1,22))for x in top['ambiguities'])
            check['r1_selected_reverse_later_candidate_only329_pulses']=selection['motor_reverse_half']['pair_indices']==list(range(22,351))
        else:
            check['r2_no_isolated_reverse_candidate']=('motor_reverse_half'not in selection and any(x['feature']=='motor_reverse_half'and x['candidate_count']==0 for x in top['ambiguities']))
            check['r2_reverse_all350_unassigned_explicit']=any(x['feature']=='reverse_half_full_extent'and x['pair_indices']==list(range(1,351))for x in top['ambiguities'])
        brake=selection['joint_brake'];joint=own['all_both_high_positive_duration_intersections'][0]
        check['joint_brake_complete_overlap_endpoints_exact']=(brake['begin_seconds'],brake['end_seconds'])==(joint['start_s'],joint['end_s'])
        scope={'report_scope':report['functional_receipts']['scope'],'ownership_validation_is_summary_delegation_not_reemitted_raw':report['functional_receipts']['receipt_validation'],
               'public_deinit_vs_lab_cleanup_limitation_preserved':any('Public original deinit alone does not cancel/free GPIO'in x for x in report['limitations']),
               'quantitative_parity_or_command_clock_alignment_not_claimed':report['limitations']}
        check['original_public_deinit_separate_from_lab_cleanup_caveat']=scope['public_deinit_vs_lab_cleanup_limitation_preserved']
        verdict={'compatible_unique_ordered_topology':top['compatible_unique_ordered_topology'],'ambiguities':top['ambiguities'],
                 'selected_reverse_candidate_range':([selection['motor_reverse_half']['pair_indices'][0],selection['motor_reverse_half']['pair_indices'][-1]]if'motor_reverse_half'in selection else None)}
    else:
        check['selected_native18_source_manifest_exact']=report['source_manifest']==initial_receipts['selected_frozen_manifest']
        check['native_rounded_targets_exact']={tag:report['actual_consumer_u16_c_rounded_nominals'][tag]['high_us']==target for tag,target in own['nominal_targets_us'].items()}
        api=report['validated_receipt_consumer_api_and_ownership_not_electrical_phase_identity'];check['native_full_api_ownership_receipts_exact']={k:v==remote[k]for k,v in api.items()}
        check['native_event_count_and_caller_durations_exact']=len(report['caller_events_pi_clock'])==41 and all({k:v for k,v in event.items()if k!='caller_duration_us'}==raw and math.isclose(event['caller_duration_us'],(raw['end_ns']-raw['begin_ns'])/1000,abs_tol=1e-7,rel_tol=0)for event,raw in zip(report['caller_events_pi_clock'],remote['events']))
        facts=report['functional_waveform_facts'];check['native_complete_isolated_topology_supported_agrees']=facts['complete_frozen_ordered_joint_topology_supported']is True and own['complete_frozen_isolated_ordered_topology_supported']is True and facts['ambiguities']==[]
        for obs in facts['physical_observations']:
            if'sibling'not in obs['evidence']:continue
            if'train'in obs['evidence']:
                candidate=obs['evidence']['train'];ch='1'if obs['feature']=='motor_reverse_half_guarded_train'else'0';begin,end=candidate['begin_seconds'],candidate['end_seconds']
            else:
                candidate=obs['evidence']['complete_high_run'];ch='1'if obs['feature']=='motor_reverse_full_physical_long_high'else'0';begin,end=candidate['rise_seconds'],candidate['fall_seconds']
            peer=own['channels']['1'if ch=='0'else'0']['all_high_intervals'];sibling=obs['evidence']['sibling']
            check[obs['feature']+'_full_boundary_inclusive_sibling']={'no_peer_highs':not touching(peer,begin,end),'full_window_low_flag':sibling['low_throughout_full_window_observed']is True,
                 'no_guarded_core_substitution':sibling['guarded_core_substitution_used']is False}
        flag_values={'functional_consumer_integration_only':True,'passive_probes_only':True,'actual_actuator_operation_established':False,'installed_blinka_compatibility_proven':False,'waveform_accepted':None,'parity_pass':None,'matched_performance_parity':False,'pi_saleae_clocks_aligned':False,'application_latency_measured':False,'no_edge_trimming_or_glitch_filtering':True,'timebase_gpio_driver_and_threshold_skew_calibrated':False}
        check['native_scope_flags_exact']={k:report[k]==v for k,v in flag_values.items()}
        verdict={'complete_frozen_ordered_joint_topology_supported':facts['complete_frozen_ordered_joint_topology_supported'],'ambiguities':facts['ambiguities']}
        scope={'limitation':report['limitation'],'actual_ssh_exit_not_exposed_as_separate_report_field':'Validated saved acquisition/results hashes refer to the same SSH0 receipts; collection_receipts_validated=true does not itself identify local CLI exits.'}
    failures=false_paths(check)
    result['runs'][stem]={'report_path':str(path),'report_sha256':sha(path),'report_size_bytes':path.stat().st_size,
         'checked_facts':check,'checked_fact_mismatch_paths':failures,'all_compared_raw_receipt_numeric_facts_agree':not failures,
         'raw_counts_and_stats':raw_summary,'all_reported_fragment_stats_recomputed_from_immutable_raw':fragment_checks,
         'original_target_normalized_distributions_recomputed_on_reported_raw_basis':normalized,
         'direction_handoff_from_immutable_independent_audit':own['direction_handoff_observation'],
         'all_raw_both_high_intersections_from_independent_audit':own['all_both_high_positive_duration_intersections'],
         'report_full_extent_association_verdict':verdict,'source_ownership_scope_notes':scope}
    print(stem,'checked fact mismatches',failures)
result['checked_fact_mismatch_count']=sum(len(x['checked_fact_mismatch_paths'])for x in result['runs'].values())
result['all_checked_numeric_raw_receipt_and_scope_facts_agree']=result['checked_fact_mismatch_count']==0
result['diagnostic_classification_differences']=[{'capture':'oct7-pi5-lgpio-consumers-r1','channel':1,'high_index':25,'raw_high_width_us':base['runs']['oct7-pi5-lgpio-consumers-r1']['channels']['1']['all_high_intervals'][25]['duration_us'],
    'target_us':500.0,'independent_target_normalized_relative_error':.10234000000097876,'report_symmetric_relative_error':51.17000000048938/551.1700000004894,
    'independent_target_relative_band_membership':False,'report_candidate_motor_half_membership':True,
    'inference_not_analyzer_source_inspection':'Observed report mapping is reproduced across all raw highs by math.isclose relative0.1; this explains the551.170us diagnostic tag difference. The exact raw width remains unchanged and complete topology remains withheld.'}]
result['overall_conclusion']='Zero mismatches in checked complete raw arrays, common numeric statistics, source/exit/ownership references and full-extent association verdicts. One explicitly preserved diagnostic tolerance/fragment method difference for original r1 high25 changes labeled blocks/distribution basis, not raw data or the withheld original topology conclusion. No hardware/network used; no reports/initial artifacts/analyzer sources modified.'
assert sha(INITIAL)==INITIAL_HASH and sha(NOTES)==NOTES_HASH
assert not FINAL.exists(),'Final audit output must be exclusive'
with FINAL.open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
print(FINAL,'SHA256',sha(FINAL))
