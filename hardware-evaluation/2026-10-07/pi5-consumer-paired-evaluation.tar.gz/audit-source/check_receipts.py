"""Independent offline check. Never imports collector, evaluator or analyzer."""
import hashlib
import json
import math
import re
from pathlib import Path

ROOT = Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
DEST = Path('/private/tmp/paired-receipts-audit.WL4JrM/receipt_checks.json')
NAMES = ['oct7-pi5-lgpio-consumers-r1', 'oct7-pi5-native-consumers-paired-r1', 'oct7-pi5-native-consumers-paired-r2', 'oct7-pi5-lgpio-consumers-r2']
SEQUENCE = [
    ('servo_initial_low', .1, 'servo_initialize', None),
    ('servo_angle0', .4, 'Servo.angle', 0),
    ('servo_angle90', .4, 'Servo.angle', 90),
    ('servo_angle180', .4, 'Servo.angle', 180),
    ('servo_disable', .15, 'Servo.angle', None),
    ('servo_release', .15, 'servo_release', None),
    ('motor_initial_low', .1, 'motor_initialize', None),
    ('motor_brake', .2, 'DCMotor.throttle', 0),
    ('motor_forward_half', .35, 'DCMotor.throttle', .5),
    ('motor_forward_full', .2, 'DCMotor.throttle', 1),
    ('motor_reverse_half', .35, 'DCMotor.throttle', -.5),
    ('motor_reverse_full', .2, 'DCMotor.throttle', -1),
    ('motor_disable', .15, 'DCMotor.throttle', None),
    ('motor_release_positive', .15, 'motor_release_positive', None),
    ('motor_release_negative', .15, 'motor_release_negative', None),
]
OWNERS = [('servo18-g1', 18, 1, 50), ('motor18-g2', 18, 2, 1000), ('motor23-g1', 23, 1, 1000)]
DUTIES = [[0], [3276], [4914], [6553], [0], [], [0,0], [65535,65535], [32767,0], [65535,0], [0,32767], [0,65535], [0,0], [0], []]
ACTION_INDICES = [1,2,3,4,7,8,9,10,11,12]
CHECKS = []
RUNS = []
def read(path):
    return json.loads(path.read_text())
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def check(name, condition, detail=None):
    CHECKS.append({'name':name, 'passed':bool(condition), **({'detail':detail} if detail is not None else {})})
def same(a,b):
    return a == b
def close(a,b):
    return a is None if b is None else type(a) in (int,float) and math.isclose(a,b,abs_tol=1e-9,rel_tol=0)
def between(row, lo, hi):
    return lo <= row['begin_ns'] <= row['end_ns'] <= hi
def model_state(i):
    specs = OWNERS[:1] if i <=4 else OWNERS[1:] if 6<=i<=12 else OWNERS[2:] if i==13 else []
    return [(a,b,c,d,duty) for (a,b,c,d), duty in zip(specs,DUTIES[i])]
def servo_readback(i):
    return {1:0, 2:180*(4914-3276)/(6553-3276), 3:180, 4:None}.get(i)
def consumer_state(i):
    if i <=4: return {'kind':'Servo','angle':servo_readback(i)}
    if 6<=i<=12: return {'kind':'DCMotor','throttle':SEQUENCE[i][3] if i!=6 else None,'decay_mode':0}
    return None
def state_matches(actual, expected):
    if expected is None: return actual is None
    if actual.keys()!=expected.keys(): return False
    return all(close(actual[k],v) if v is None or type(v) in (int,float) else actual[k]==v for k,v in expected.items())
def validate_state(prefix, rows, i, remote, original):
    expected = model_state(i)
    check(prefix+' exact API tuple', [(r['output_id'],r['gpio'],r['generation'],r['frequency'],r['duty_u16']) for r in rows] == expected)
    owner_records = {r['output_id']:r for r in remote['outputs']}
    for row in rows:
        spec = owner_records[row['output_id']]
        key = 'ownership' if original else 'owned_request'
        check(prefix+' identity '+row['output_id'], row[key] == spec[key])
        if original:
            pc = round(row['duty_u16'] / 65535 * 100)
            check(prefix+' submitted original '+row['output_id'], row['enabled'] is True and row['submitted_duty_percent']==pc and row['submitted_nominal_high_us']==1e6/row['frequency']*pc/100)
    if not original:
        check(prefix+' active unique request fds',len({r['owned_request']['fd'] for r in rows})==len(rows))

original_plan = read(ROOT/'oct7-lgpio-consumers-plan.json')
native_plan = read(ROOT/'oct7-native-consumers-plan.json')
orig_manifest = read(ROOT/'oct7-lgpio-consumers-manifest.json')
native_manifest = read(ROOT/'oct7-native-consumers-manifest.json')
check('frozen paired plan SHA256', digest(ROOT/'oct7-lgpio-consumers-plan.json')=='a4bf9e03fd8fd7d95f2dff9118108f046999272e63d95f7cc78d87caa3f80c7c')
check('unchanged native plan SHA256',digest(ROOT/'oct7-native-consumers-plan.json')==original_plan['native_reference']['unchanged_protocol_plan_sha256'])
check('frozen alternating capture order',original_plan['capture_order']==NAMES)
for label,p in [('original',original_plan),('native',native_plan)]:
    check(label+' full sequence matches independent declaration',[(r['name'],r['duration_seconds'],r['operation'],r['value']) for r in p['sequence']]==SEQUENCE)
    check(label+' three local fixed waits declared',p['sequence_dwell_seconds']==3.45 and p['normal_fixed_wait_seconds']==3.75)
for label,m,count in [('original',orig_manifest,21),('native',native_manifest,18)]:
    check(label+' source hash inventory',len(m['source_sha256'])==count and all(re.fullmatch('[0-9a-f]{64}',v) for v in m['source_sha256'].values()) and m['motor_version']=='3.5.0' and m['selected_sources_not_whole_system_attestation'] is True)
    for key,value in m['source_sha256'].items():
        path = ROOT/key
        if path.is_file(): check(label+' local frozen hash '+key,digest(path)==value)
for key in ['adafruit_motor/__init__.py','adafruit_motor/servo.py','adafruit_motor/motor.py']:
    check('identical genuine motor3.5.0 pin '+key,orig_manifest['source_sha256'][key]==native_manifest['source_sha256'][key])

for name in NAMES:
    p=ROOT/name
    results=read(p/'results.json'); a=read(p/'acquisition.json'); r=results['remote']; m=read(p/'manifest.json')
    original='lgpio-consumers' in name
    expected_m=orig_manifest if original else native_manifest
    check(name+' source manifest chain',m==expected_m and r['source_sha256']==m['source_sha256'] and (not original or results['source_manifest']==m))
    check(name+' stdout receipt exact',read(p/'remote.stdout')==r)
    check(name+' actual recorded SSH exit',results['remote_returncode']==a['remote_returncode']==0 and a['primary_error'] is None and not a['evidence_errors'] and a.get('ssh_exit_unavailable_after_exception',False) is False)
    check(name+' acquisition config',results['sample_rate_hz']==100000000 and [(v['gpio'],v['saleae_channel']) for v in results['outputs']]==[(18,0),(23,1)] and a['local_timing_not_aligned_to_pi_or_saleae'] is True and (not original or (a['requested_channels']==[0,1] and a['requested_sample_rate_hz']==100000000 and a['requested_glitch_filters']==[])))
    check(name+' acquisition results not waveform acceptance',results['collection_success'] is True and results['waveform_accepted'] is None and results['parity_pass'] is None and results['parity_evaluated'] is False and results['analysis_deferred'] is True)
    check(name+' helper success/error separation',r['success'] is True and r['completed_normally'] is True and r['primary_error'] is None and r['cleanup_errors']==[] and r['signals_received']==[])
    check(name+' runtime flags and environment',r['runtime_flags']=={'short_slice':False,'shared':False} and r['inherited_environment']=={'BLINKA_PWM_SHORT_SLICE':None,'BLINKA_PWM_SHARED':None} and r['variable_frequency'] is (not original))
    check(name+' scoped limitations',r['actual_actuators_attached'] is False and r['installed_blinka_compatibility_proven'] is False and r['production_backend_unchanged'] is True and r['api_readbacks_are_not_electrical'] is True and r['parity_pass'] is None)
    check(name+' shim restored and unwrapped',r['integration_shim']=={'kind':'in-memory-pwmio-export','unwrapped_public_pwm_objects':True,'installed_blinka_compatibility_proven':False,'installed_pwmio_module_used':False,'restored':True})
    check(name+' identity RP1',r['identity']['boot_id']=='71305dc8-e9a8-49b1-a623-678032cbd3f5' and r['identity']['gpiochip']=='/dev/gpiochip0' and r['identity']['label']=='pinctrl-rp1')
    check(name+' all initial lines free',len(r['preclaim_lines'])==2 and all(row['line_info']['used'] is False and row['line_info']['consumer'] is None for row in r['preclaim_lines']))
    check(name+' consumers',r['motor_version']=='3.5.0' and r['consumers']['version']=='3.5.0' and r['consumers']['distribution']=='adafruit-circuitpython-motor' and r['consumers']['motor']=={'decay_mode':0,'throttle_zero_is_both_high_brake':True} and r['consumers']['servo']=={'actuation_range':180,'min_pulse_us':1000,'max_pulse_us':2000})
    check(name+' thermal flags',r['before']['throttled']==r['after']['throttled']=='throttled=0x0' and int(r['before']['temperature_millic'])<65000 and int(r['after']['temperature_millic'])<70000)
    check(name+' helper fixed waits and watchdog',r['sequence_dwell_seconds']==3.45 and r['normal_fixed_wait_seconds']==3.75 and r['low_settle_seconds']==.1 and r['end_ns']-r['begin_ns']<14e9)
    check(name+' exact phase count',len(r['phases'])==15)
    phase_timings=[]
    for i,(phase,spec) in enumerate(zip(r['phases'],SEQUENCE)):
        check(name+f' phase{i} declaration',(phase['index'],phase['name'],phase['duration_seconds'],phase['operation'],phase['value'],phase['scope'])==(i,*spec,f'{i:02d}_{spec[0]}'))
        check(name+f' phase{i} own-clock chronology',r['begin_ns']<=phase['begin_ns']<=phase['stable_begin_ns']<=phase['end_ns']<=phase['readback_end_ns']<=r['end_ns'] and (i==0 or r['phases'][i-1]['readback_end_ns']<=phase['begin_ns']))
        check(name+f' phase{i} full dwell',phase['end_ns']-phase['stable_begin_ns']>=round(spec[1]*1e9))
        validate_state(name+f' phase{i} begin',phase['api_state'],i,r,original)
        validate_state(name+f' phase{i} end',phase['api_state_end'],i,r,original)
        check(name+f' phase{i} consumer state',state_matches(phase['consumer_state'],consumer_state(i)) and state_matches(phase['consumer_state_end'],consumer_state(i)))
        phase_timings.append({'index':i,'name':spec[0],'begin_offset_ns':phase['begin_ns']-r['begin_ns'],'operation_and_initial_snapshot_ns':phase['stable_begin_ns']-phase['begin_ns'],'stable_to_dwell_end_ns':phase['end_ns']-phase['stable_begin_ns'],'post_dwell_readback_ns':phase['readback_end_ns']-phase['end_ns'],'next_phase_gap_ns':None if i==14 else r['phases'][i+1]['begin_ns']-phase['readback_end_ns']})
    check(name+' exact action indices',[v['phase_index'] for v in r['actions']]==ACTION_INDICES)
    for action in r['actions']:
        i=action['phase_index']; phase=r['phases'][i]
        check(name+f' action{i} scope/chronology',action['status']=='ok' and (action['operation'],action['value'])==SEQUENCE[i][2:] and between(action,phase['begin_ns'],phase['stable_begin_ns']))
        validate_state(name+f' action{i} before',action['api_state_before'],i-1,r,original)
        validate_state(name+f' action{i} after',action['api_state_after'],i,r,original)
        check(name+f' action{i} consumer readback',close(action['consumer_readback'],servo_readback(i) if i<5 else SEQUENCE[i][3]))
    check(name+' exact owner generations',[(o['output_id'],o['gpio'],o['generation'],o['initial_frequency']) for o in r['outputs']]==OWNERS)
    for output in r['outputs']:
        check(name+' clean owner '+output['output_id'],all(output[k] is True for k in ['fresh_claim_accepted','initial_low_confirmed','low_confirmed','released']) and output['initial_readback']['gpio_level']==0 and output['cleanup_final_readback']['gpio_level']==0 and output['released_line_info']['used'] is False and output['released_line_info']['consumer'] is None)
        if original:
            check(name+' original generation '+output['output_id'],output['ownership']=={'private_chip_handle':r['private_chip_handle'],'gpio':output['gpio'],'generation':output['generation']} and output['freed'] is True and output['cleanup_final_readback']['tx_busy']==0 and output['preclaim_mode']==output['released_mode']==2)
        else:
            check(name+' native owner '+output['output_id'],output['owned_request']['chip_name']=='gpiochip0' and output['owned_request']['offsets']==[output['gpio']] and output['owned_request']['fd']>=0 and output['read_only_chip_closed'] is True and output['cleanup_final_readback']['inactive'] is True)
    check(name+' three independent shutdowns',len(r['shutdowns'])==3 and all(s['success'] is True and s['errors']==[] and s['reason']=='sequence' for s in r['shutdowns']))
    for shutdown,i in zip(r['shutdowns'],[5,13,14]):
        check(name+f' shutdown{i} own-clock scope',shutdown['scope']==r['phases'][i]['scope'] and between(shutdown,r['phases'][i]['begin_ns'],r['phases'][i]['stable_begin_ns']))
    sib=r['shutdowns'][1]
    check(name+' continuing negative sibling unchanged low',sib['sibling_id']=='motor23-g1' and sib['sibling_before']==sib['sibling_after'] and sib['sibling_before']['gpio_level']==0 and sib['sibling_before']['frequency']==1000 and sib['sibling_before']['duty_u16']==0)
    check(name+' servo release precedes GPIO18 g2 construct',r['shutdowns'][0]['end_ns']<=r['phases'][6]['begin_ns'])
    events=r['events']; nested=0
    check(name+' event count/status',len(events)==(78 if original else 41) and all(e['status']=='ok' and between(e,r['begin_ns'],r['end_ns']) for e in events))
    for event in events:
        if event['scope'] in {p['scope'] for p in r['phases']}:
            phase=next(p for p in r['phases'] if p['scope']==event['scope'])
            check(name+' event phase bound '+str(event.get('event_id',event.get('ordinal'))),between(event,phase['begin_ns'],phase['stable_begin_ns']))
    if original:
        by_id={e['event_id']:e for e in events}
        check(name+' nested event IDs and completion order',set(by_id)==set(range(78)) and [e['end_ns'] for e in events]==sorted(e['end_ns'] for e in events) and [e['event_id'] for e in sorted(events,key=lambda v:v['begin_ns'])]==list(range(78)))
        for event in events:
            parent=event['parent_event_id']
            if parent is not None:
                nested+=1
                check(name+' nested parent containment '+str(event['event_id']),parent<event['event_id'] and between(event,by_id[parent]['begin_ns'],by_id[parent]['end_ns']) and event['scope']==by_id[parent]['scope'])
        top=[e for e in events if e['parent_event_id'] is None]
        check(name+' top-level events serial',all(x['end_ns']<=y['begin_ns'] for x,y in zip(top,top[1:])))
        check(name+' original specific cleanup/capabilities',r['chip_closed'] is True and r['library_hooks_restored'] is True and r['native_backend_executed'] is False and r['public_deinit_cancels_or_frees_gpio'] is False and r['additional_lab_cleanup_required'] is True and r['library_hooks_are_ownership_enforcement_only'] is True)
        for output,phase_i in zip(r['outputs'],[5,13,14]):
            oe=[e for e in events if e['output_id']==output['output_id'] and e['scope']==r['phases'][phase_i]['scope']]
            check(name+' original lab cleanup sequence '+output['output_id'],[e['operation'] for e in oe]==['lab.cancel_tx_pwm','lab.drive_low','lab.low_settle','lab.gpio_read_low','lab.tx_busy','original_PWMOut.deinit','lab.gpio_free','gpio_get_mode_released','read_only_line_released'])
            check(name+' original cleanup reads/results '+output['output_id'],all(e['result']==0 for e in oe if e['operation'] in ['lab.cancel_tx_pwm','lab.drive_low','lab.gpio_read_low','lab.tx_busy','lab.gpio_free']) and next(e for e in oe if e['operation']=='lab.low_settle')['end_ns']-next(e for e in oe if e['operation']=='lab.low_settle')['begin_ns']>=1e8)
        tx=[{'scope':e['scope'],'output_id':e['output_id'],'frequency':e['arguments']['args'][0],'percent':e['arguments']['args'][1]} for e in events if e['operation']=='tx_pwm']
        expected_tx=[]
        for i in [0,1,2,3,4,6,7,8,9,10,11,12]:
            for oid,gpio,generation,hz,duty in model_state(i):
                expected_tx.append({'scope':r['phases'][i]['scope'],'output_id':oid,'frequency':hz,'percent':round(duty/65535*100)})
        check(name+' exact original constructor/setter tx submissions',tx==expected_tx)
        for e in events:
            if e['operation'] in ['tx_pwm','gpio_claim_output']:
                check(name+' private hooked call '+str(e['event_id']),e['arguments']['private_handle']==r['private_chip_handle'] and e['arguments']['gpio']==next(v['gpio'] for v in r['outputs'] if v['output_id']==e['output_id']))
    else:
        check(name+' native serial ordinal chronology',[e['ordinal'] for e in events]==list(range(41)) and all(x['end_ns']<=y['begin_ns'] for x,y in zip(events,events[1:])))
        check(name+' native read-only chip closed',r['read_only_chip_closed'] is True)
        for output,phase_i in zip(r['outputs'],[5,13,14]):
            oe=[e for e in events if e['output_id']==output['output_id'] and e['scope']==r['phases'][phase_i]['scope']]
            check(name+' native owner cleanup sequence '+output['output_id'],[e['operation'] for e in oe]==['track_owned_request','PWMOut.duty_cycle_zero','low_settle','owned_request.get_value','PWMOut.deinit','gpiod_line_info_released'])
        tx=None
    stderr=(p/'remote.stderr').read_text(); lines=stderr.splitlines()
    check(name+' preserved Mac gRPC stderr only',len(lines)>0 and all(re.fullmatch(r'I1007 \d\d:\d\d:\d\d\.\d+\s+\d+ ev_poll_posix\.cc:587\] FD from fork parent still in poll list: fd\(9, generation: 1\)',line) for line in lines))
    RUNS.append({'name':name,'helper_pid':r['helper_pid'],'backend':r['backend'],'remote_returncode':results['remote_returncode'],'begin_ns':r['begin_ns'],'end_ns':r['end_ns'],'helper_duration_ns':r['end_ns']-r['begin_ns'],'event_count':len(events),'nested_child_count':nested,'top_level_event_count':len(events)-nested,'phase_timings':phase_timings,'action_durations_ns':[v['end_ns']-v['begin_ns'] for v in r['actions']],'source_count':len(m['source_sha256']),'stderr_bytes':(p/'remote.stderr').stat().st_size,'stderr_lines':len(lines),'raw_file_sha256':{k:digest(p/k) for k in ['results.json','acquisition.json','remote.stdout','remote.stderr','manifest.json']},'original_tx_submissions':tx,'thermal_before':r['before'],'thermal_after':r['after']})

check('recorded capture order on shared Pi boot',all(x['end_ns']<=y['begin_ns'] for x,y in zip(RUNS,RUNS[1:])))
stages=[]
for stage in ['preflight','postflight']:
    f=ROOT/f'oct7-lgpio-consumers-paired-{stage}.json'; z=read(f); rr=z['remote']
    check(stage+' accepted actual SSH exit',z['accepted'] is True and z['ssh_returncode']==0 and z['validation_error'] is None)
    check(stage+' offline source chain',rr['remote_manifests']['original']==orig_manifest and rr['remote_manifests']['native']==native_manifest and rr['selected_source_sha256']['original']==orig_manifest['source_sha256'] and rr['selected_source_sha256']['native']==native_manifest['source_sha256'])
    check(stage+' free pins and absent inspected processes',all(v is False for v in rr['pid_exists'].values()) and [(l['offset'],l['used'],l['consumer']) for l in rr['lines']]==[(18,False,None),(23,False,None)])
    check(stage+' read-only scope',rr['read_only'] is True and rr['no_gpio_request_or_write'] is True and z['plan_sha256']==digest(ROOT/'oct7-lgpio-consumers-plan.json'))
    if stage=='postflight':
        for run in RUNS:
            check(stage+' raw receipt hash '+run['name'],z['capture_receipts'][run['name']]=={'helper_pid':run['helper_pid'],'backend':run['backend'],'stdout_sha256':run['raw_file_sha256']['remote.stdout']} and rr['pid_exists'][str(run['helper_pid'])] is False)
    stages.append({'stage':stage,'sha256':digest(f),'boot_id':rr['boot_id'],'boot_config_sha256':rr['boot_config_sha256'],'pid_count':len(rr['pid_exists']),'existing_pids':[k for k,v in rr['pid_exists'].items() if v],'runtime':rr['runtime'],'utc':rr['utc']})
check('same boot and boot config pre/post',stages[0]['boot_id']==stages[1]['boot_id'] and stages[0]['boot_config_sha256']==stages[1]['boot_config_sha256'])

report={'schema_version':1,'purpose':'Independent offline paired consumer RECEIPTS/SOURCE/OWNERSHIP audit; no waveform report or analyzer used','passed':all(c['passed'] for c in CHECKS),'check_count':len(CHECKS),'failures':[c for c in CHECKS if not c['passed']],'checks':CHECKS,'runs':RUNS,'state_model':{'sequence':SEQUENCE,'api_duties_by_phase':DUTIES,'owners':OWNERS,'servo90_readback':servo_readback(2),'original_servo_percent':{'0':5,'90':7,'180':10},'original_servo_nominal_us':{'0':1000,'90':1400,'180':2000}},'pre_post':stages,'limitations':['Only saved receipts and pinned selected-source records checked; no live Pi state or whole-system attestation.','Pi receipt chronology is never mapped to Saleae or Mac acquisition clocks.','SSH exits are recorded remote subprocess exits, not independently observed local collector/coordinator CLI exits.','Original public deinit only changes flags; lab cancel/drive-low/read/free is not production cleanup.','Readback API/low state does not establish electrical transition timing, deadtime, actuator safety, saturation or quantitative parity.','Nonempty remote.stderr files retain Mac gRPC fork/poll diagnostics, not Pi helper errors.']}
DEST.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'output':str(DEST),'sha256':digest(DEST),'check_count':len(CHECKS),'passed':report['passed'],'failures':report['failures'],'runs':[{k:v for k,v in run.items() if k not in ['phase_timings','raw_file_sha256','original_tx_submissions','thermal_before','thermal_after']} for run in RUNS],'pre_post':stages},indent=2))
