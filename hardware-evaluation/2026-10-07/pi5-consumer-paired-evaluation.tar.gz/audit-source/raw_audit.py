"""Independent exhaustive offline binary audit; imports no project source."""
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import struct
import sys
import zipfile

ROOT=Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
TEMP=Path('/private/tmp/paired-consumer-independent.f2YuIZ')
EXPORT=Path('/private/tmp/paired-consumer-salcheck.GejBJm')
PLAN=ROOT/'oct7-lgpio-consumers-plan.json'
FINAL=ROOT/'oct7-lgpio-consumers-paired-independent-audit.json'
NOTES=ROOT/'oct7-lgpio-consumers-paired-independent-notes.txt'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def stats(values,target=None):
    values=list(values)
    if not values:return {'count':0}
    ordered=sorted(values)
    result={'count':len(values),'min':min(values),'median':statistics.median(values),'max':max(values),
            'mean':statistics.mean(values),'population_stddev':statistics.pstdev(values),
            'p01_nearest_rank':ordered[max(0,math.ceil(.01*len(values))-1)],
            'p99_nearest_rank':ordered[math.ceil(.99*len(values))-1]}
    if target is not None:result.update(target=target,min_error=min(values)-target,median_error=statistics.median(values)-target,
                                      max_error=max(values)-target,max_absolute_error=max(abs(x-target) for x in values))
    return result

def decode(p):
    data=p.read_bytes();assert data[:8]==b'<SALEAE>'
    version,kind=struct.unpack_from('<ii',data,8);assert(version,kind)==(0,0)
    initial,begin,end,count=struct.unpack_from('<IddQ',data,16)
    assert initial in (0,1) and len(data)==44+8*count
    edges=list(struct.unpack_from('<'+str(count)+'d',data,44))
    assert all(math.isfinite(t) and begin<=t<=end for t in edges)
    assert all(a<b for a,b in zip(edges,edges[1:]))
    bounds=[begin,*edges,end]
    spans=[{'start_s':a,'end_s':b,'duration_us':(b-a)*1e6,'state':initial^(i%2),
            'endpoint_fragment':i in(0,len(bounds)-2)} for i,(a,b) in enumerate(zip(bounds,bounds[1:]))]
    highs=[dict(x,high_index=i) for i,x in enumerate(s for s in spans if s['state']==1)]
    lows=[dict(x,low_index=i) for i,x in enumerate(s for s in spans if s['state']==0)]
    rising=[x['start_s'] for x in highs if not(x['endpoint_fragment'] and x['start_s']==begin)]
    periods=[{'earlier_rise_s':a,'later_rise_s':b,'duration_us':(b-a)*1e6} for a,b in zip(rising,rising[1:])]
    return {'file':str(p.relative_to(ROOT)),'sha256':sha(p),'size_bytes':len(data),
            'header':{'signature':'<SALEAE>','version':version,'type':kind,'initial_state':initial,'begin_s':begin,'end_s':end,'transition_count':count,'header_bytes':44,'sample_rate_absent_from_v0_header':True},
            'valid_finite_strictly_ordered_edges_and_exact_payload':True,'final_state':spans[-1]['state'],
            'all_transition_times_s':edges,'all_high_intervals':highs,'all_low_intervals_including_endpoints':lows,
            'all_adjacent_rise_intervals_including_discontinuities':periods,
            'all_high_width_stats_us':stats(x['duration_us'] for x in highs),
            'all_low_width_stats_us_including_endpoints':stats(x['duration_us'] for x in lows),
            'interior_low_stats_us':stats(x['duration_us'] for x in lows if not x['endpoint_fragment']),
            'all_adjacent_rise_stats_us':stats(x['duration_us'] for x in periods),
            'sub_microsecond_high_indices':[x['high_index']for x in highs if x['duration_us']<1],
            'sub_microsecond_interior_low_indices':[x['low_index']for x in lows if not x['endpoint_fragment'] and x['duration_us']<1],
            'all_edges_on_100MSa_grid_within_1e_minus_6_tick':all(abs(t*1e8-round(t*1e8))<=1e-6 for t in edges)}

def high_context(peer,begin,end):
    touching=[x for x in peer if x['start_s']<=end and x['end_s']>=begin]
    overlaps=[dict(x,overlap_start_s=max(begin,x['start_s']),overlap_end_s=min(end,x['end_s']),
                   overlap_duration_us=(min(end,x['end_s'])-max(begin,x['start_s']))*1e6)
              for x in touching if max(begin,x['start_s'])<min(end,x['end_s'])]
    return {'window_s':[begin,end],'boundary_inclusive_touching_or_overlapping_highs':touching,
            'positive_duration_overlaps':overlaps,'high_overlap_duration_us':sum(x['overlap_duration_us']for x in overlaps),
            'low_throughout_entire_boundary_inclusive_window':not touching,
            'central_window_substitution':False}

def joint_intersections(a,b):
    return [{'start_s':max(x['start_s'],y['start_s']),'end_s':min(x['end_s'],y['end_s']),
             'duration_us':(min(x['end_s'],y['end_s'])-max(x['start_s'],y['start_s']))*1e6,
             'gpio18_high_index':x['high_index'],'gpio23_high_index':y['high_index']}
            for x in a for y in b if max(x['start_s'],y['start_s'])<min(x['end_s'],y['end_s'])]

def width_blocks(channel,targets,peer):
    groups=[]
    for high in channel['all_high_intervals']:
        # Nearest-width labels are descriptive only. Out-of-band values remain
        # in the complete enclosing physical group; they are never trimmed.
        tag='long_high' if high['duration_us']>=100000 else min(targets,key=lambda k:abs(high['duration_us']-targets[k]))
        if not groups or groups[-1]['descriptive_label']!=tag:groups.append({'descriptive_label':tag,'highs':[]})
        groups[-1]['highs'].append(high)
    rows=[]
    for index,group in enumerate(groups):
        highs=group['highs'];tag=group['descriptive_label'];target=targets.get(tag)
        low=[(b['start_s']-a['end_s'])*1e6 for a,b in zip(highs,highs[1:])]
        period=[(b['start_s']-a['start_s'])*1e6 for a,b in zip(highs,highs[1:])]
        ptarget=1000 if tag=='motor_half' else 20000
        row={'descriptive_label':tag,'first_high_index':highs[0]['high_index'],'last_high_index':highs[-1]['high_index'],
             'start_s':highs[0]['start_s'],'end_s':highs[-1]['end_s'],
             'high_width_stats_us':stats((x['duration_us']for x in highs),target),
             'within_same_block_interior_low_stats_us':stats(low),
             'within_same_block_adjacent_rise_stats_us':stats(period,None if tag=='long_high' else ptarget),
             'all_high_widths_in_order_us':[x['duration_us']for x in highs],
             'all_within_block_lows_in_order_us':low,'all_within_block_rise_intervals_in_order_us':period,
             'entire_block_sibling_high_context':high_context(peer,highs[0]['start_s'],highs[-1]['end_s'])}
        if target is not None:
            row['width_outside_frozen_relative_10percent_band']=[x for x in highs if abs(x['duration_us']-target)>.1*target]
            row['within_block_period_outside_frozen_relative_10percent_band']=[{'earlier_high_index':a['high_index'],'later_high_index':b['high_index'],'duration_us':(b['start_s']-a['start_s'])*1e6} for a,b in zip(highs,highs[1:]) if abs((b['start_s']-a['start_s'])*1e6-ptarget)>.1*ptarget]
            fragments=[]
            for high in highs:
                inband=abs(high['duration_us']-target)<=.1*target
                adjoining=bool(fragments) and abs((high['start_s']-fragments[-1]['highs'][-1]['start_s'])*1e6-ptarget)<=.1*ptarget
                if not fragments or not inband or not fragments[-1]['widths_all_in_band'] or not adjoining:
                    fragments.append({'widths_all_in_band':inband,'highs':[]})
                fragments[-1]['highs'].append(high)
            row['all_frozen_band_fragments_including_single_anomalies']=[{
                'first_high_index':f['highs'][0]['high_index'],'last_high_index':f['highs'][-1]['high_index'],
                'pulse_count':len(f['highs']),'widths_all_in_band':f['widths_all_in_band'],
                'width_period_identifiable_at_least_5_pulses':f['widths_all_in_band'] and len(f['highs'])>=5,
                'start_s':f['highs'][0]['start_s'],'end_s':f['highs'][-1]['end_s'],
                'complete_fragment_high_width_stats_us':stats(x['duration_us']for x in f['highs']),
                'fragment_sibling_context':high_context(peer,f['highs'][0]['start_s'],f['highs'][-1]['end_s']),
                'not_substituted_for_full_enclosing_group':True} for f in fragments]
        if index+1<len(groups):
            next_high=groups[index+1]['highs'][0]
            row['complete_boundary_to_next_width_block']={'last_fall_s':highs[-1]['end_s'],'next_rise_s':next_high['start_s'],
                  'low_us':(next_high['start_s']-highs[-1]['end_s'])*1e6,'adjacent_rise_us':(next_high['start_s']-highs[-1]['start_s'])*1e6}
        rows.append(row)
    return rows

def receipt_basic(directory,original):
    results=json.loads((directory/'results.json').read_text());remote=results['remote'];acq=json.loads((directory/'acquisition.json').read_text())
    selected=json.loads((ROOT/('oct7-lgpio-consumers-manifest.json'if original else'oct7-native-consumers-manifest.json')).read_text())
    saved_manifest=json.loads((directory/'manifest.json').read_text())
    fields=('runtime_flags','inherited_environment','variable_frequency','motor_version','begin_ns','end_ns','success','completed_normally','primary_error','cleanup_errors','signals_received','integration_shim','consumers','before','after')
    checks={'raw_remote_stdout_equals_results_remote':json.loads((directory/'remote.stdout').read_text())==remote,
            'saved_manifest_equals_frozen_manifest':saved_manifest==selected,
            'selected_source_hashes_equal_frozen_manifest':remote['source_sha256']==selected['source_sha256'],
            'manifest_selected_source_count_matches':len(remote['source_sha256'])==(21 if original else 18),
            'actual_recorded_consumer_ssh_exit_zero_acquisition':type(acq['remote_returncode'])is int and acq['remote_returncode']==0,
            'actual_recorded_consumer_ssh_exit_zero_results':type(results['remote_returncode'])is int and results['remote_returncode']==0,
            'collection_success':results['collection_success']is True,'remote_success_and_clean_cleanup':remote['success']is True and remote['primary_error']is None and remote['cleanup_errors']==[] and remote['signals_received']==[],
            'phase_action_output_shutdown_counts':(len(remote['phases']),len(remote['actions']),len(remote['outputs']),len(remote['shutdowns']))==(15,10,3,3),
            'runtime_flags_false':remote['runtime_flags']=={'short_slice':False,'shared':False},
            'original_false_native_true_variable_frequency':remote['variable_frequency']is(not original),
            'shim_restored':remote['integration_shim']['restored']is True,
            'no_actuators_or_installed_blinka_or_parity_verdict':results['actual_actuators_attached']is False and results['installed_blinka_compatibility_proven']is False and results['parity_pass']is None,
            'new_analysis_report_absent_before_audit_saved':not(directory/'analysis.json').exists()}
    stderr=(directory/'remote.stderr').read_text();diag_pids=sorted(set(int(x)for x in re.findall(r'^I\d+\s+\S+\s+(\d+)\s+ev_poll_posix',stderr,re.M)))
    return {'checks':checks,'helper_pid':remote['helper_pid'],
            'actual_consumer_ssh_exit_statuses':{'acquisition_remote_returncode':acq['remote_returncode'],'results_remote_returncode':results['remote_returncode']},
            'local_cli_process_exit_not_inferred_from_ssh_exit':True,
            'selected_frozen_manifest':selected,'receipt_fields':{k:remote[k]for k in fields},
            'recorded_phase_data_unmapped_to_saleae':remote['phases'],'recorded_actions_unmapped_to_saleae':remote['actions'],
            'outputs_ownership_and_cleanup':remote['outputs'],'shutdowns':remote['shutdowns'],
            'recorded_events_on_pi_clock_not_latency':remote['events'],
            'event_count':len(remote['events']),'recorded_preclaim_lines':remote['preclaim_lines'],
            'backend_specific_cleanup_fields':{k:remote[k]for k in ('public_deinit_cancels_or_frees_gpio','additional_lab_cleanup_required','native_backend_executed','chip_closed','library_hooks_restored','private_chip_handle','event_ordering','read_only_chip_closed')if k in remote},
            'remote_stderr_preserved':{'size_bytes':(directory/'remote.stderr').stat().st_size,'sha256':sha(directory/'remote.stderr'),
                'complete_text':stderr,'diagnostic_pids':diag_pids,'distinct_from_pi_helper_pid':remote['helper_pid']not in diag_pids,
                'interpretation':'Informational local Mac gRPC fork-child FD diagnostics can be captured before SSH exec under this filename. Preserve bytes; not evidence of Pi helper failure. Actual SSH exits and receipt cleanup are independently checked.'}}

plan=json.loads(PLAN.read_text());assert sha(PLAN)=='a4bf9e03fd8fd7d95f2dff9118108f046999272e63d95f7cc78d87caa3f80c7c'
audit={'schema_version':1,'audit_kind':'independent-raw-paired-original-native-consumer-audit',
       'independent_decoder_script_sha256':sha(Path(__file__)),
       'independence':{'consumer_analyzer_sources_read':False,'new_analysis_reports_read':False,'all_edges_and_endpoint_fragments_retained':True,'central_window_substitution':False,'project_helper_or_analyzer_imports':False,'ssh_gpio_load_or_live_acquisition_performed':False},
       'frozen_plan':plan,'frozen_plan_sha256':sha(PLAN),
       'saved_sal_reexport':{'fresh_isolated_output_root':str(EXPORT),'all_own_capture_objects_closed':True,'manager_disconnected':True,'offline_saved_capture_only':True},
       'method':'Struct little-endian decoder of all actual v0 digital exports, alternating-state full intervals, all consecutive rises, nearest-nominal descriptive blocks with every anomalous high retained and strict frozen-band fragments separately recorded. Boundary-inclusive sibling checks cover complete physical groups/full high plateaus. All statistics use full extents and explicitly named bases.',
       'scope_limits':['Finite idle passive digital observations on Pi5; no actuator/motion qualification or installed Blinka compatibility.',
                       'The original percent-rounded targets differ from native u16/C-rounded targets; width difference is not silently normalized.',
                       'No calibrated timebase/GPIO-driver/threshold-skew correction, exact application timing, deinit timing, cross-clock alignment, quantitative parity verdict, or scheduling guarantee.',
                       'Original public deinit changes flags only; lab cancel/drive-low/read/free/chip-close is separately credited and not a production capability.',
                       'Receipt/helper event times stay on their own Pi monotonic clock; SAL metadata start times are not used for alignment.',
                       'Source checks cover selected saved source receipts, not whole-system independent attestation.',
                       'Electrically identical low phases cannot locate exact disable/release/reinit or generation boundaries.',
                       'A later good isolated fragment is not substituted for an enclosing complete train with a boundary overlap or out-of-band widths.'],
       'runs':{}}
notes=['Independent paired original-lgpio/native consumer audit, saved before any new analyzer report is read/generated. All edges, endpoint/interior lows, adjacent rises, outliers and short fragments retained. No central trimming.','']
for stem in plan['capture_order']:
    directory=ROOT/stem;original='lgpio'in stem
    targets={'servo_angle0':1000. if original else 999.771,'servo_angle90':1400. if original else 1499.657,
             'servo_angle180':2000. if original else 1999.847,'motor_half':500. if original else 499.992}
    channels={str(ch):decode(directory/f'digital_{ch}.bin')for ch in(0,1)}
    groups={ch:width_blocks(channels[ch],targets,channels['1'if ch=='0'else'0']['all_high_intervals'])for ch in('0','1')}
    ordered=([x['descriptive_label']for x in groups['0']]==['servo_angle0','servo_angle90','servo_angle180','long_high','motor_half','long_high'] and[x['descriptive_label']for x in groups['1']]==['long_high','motor_half','long_high'])
    assert ordered
    all_joint=joint_intersections(channels['0']['all_high_intervals'],channels['1']['all_high_intervals'])
    zero,one=groups['0'],groups['1'];end=channels['0']['header']['end_s'];assert end==channels['1']['header']['end_s']
    isolated=[zero[0],zero[1],zero[2],zero[4],zero[5],one[1],one[2]]
    all_isolated=all(x['entire_block_sibling_high_context']['low_throughout_entire_boundary_inclusive_window']for x in isolated)
    handoff={'gpio18_full_fall_s':zero[5]['end_s'],'gpio23_reverse_first_rise_s':one[1]['start_s'],
             'signed_fall_to_rise_us':(one[1]['start_s']-zero[5]['end_s'])*1e6,
             'positive_is_both_low_negative_is_both_high':True,
             'calibrated_deadtime_or_exact_command_transition_inferred':False}
    strict_fragments=[]
    for ch in('0','1'):
        for row in groups[ch]:
            if row['descriptive_label']!='long_high':
                strict_fragments.extend({'channel':ch,'enclosing_label':row['descriptive_label'],**x}for x in row['all_frozen_band_fragments_including_single_anomalies'])
    ambiguous=[]
    if not all_isolated:ambiguous.append('Original complete positive full-high plateau and complete reverse half train have a peer-high boundary overlap. Whole-run isolated ordered topology cannot be credited; later low-peer fragments do not replace the complete train.')
    if any(x.get('width_outside_frozen_relative_10percent_band')for rows in groups.values()for x in rows):ambiguous.append('Out-of-band high widths split the frozen-band identification train; preserve the enclosing complete train and every anomalous/short fragment without best-window substitution.')
    with zipfile.ZipFile(directory/'waveform.sal')as z:
        meta=json.loads(z.read('meta.json'));settings=meta['data']['legacySettings'];device=meta['data']['legacyDevice']
        physical={'device_decimal_id':device['deviceId'],'device_hex_id':format(int(device['deviceId']),'016X'),
                  'device_type':device['deviceType'],'isSimulation':device['isSimulation'],'isPhysicalDevice':device['capabilities']['isPhysicalDevice'],
                  'enabled_channels':settings['enabledChannels'],'sample_rate':settings['sampleRate'],'glitch_filter':settings['glitchFilter'],
                  'capture_mode':meta['data']['captureSettings']['captureMode'],'trim_settings':meta['data']['captureSettings']['commonCaptureSettings'],
                  'capture_start_opaque_not_alignment':meta['data']['captureStartTime'],'zip_member_sha256':{k:hashlib.sha256(z.read(k)).hexdigest()for k in z.namelist()}}
        assert physical['device_hex_id']=='81F8C2631DF5BF30' and device['isSimulation']is False and device['capabilities']['isPhysicalDevice']is True
        assert settings['enabledChannels']==[{'type':'Digital','index':0},{'type':'Digital','index':1}]and settings['sampleRate']=={'digital':100000000}and settings['glitchFilter']=={'enabled':False,'channels':[]}
        assert physical['trim_settings']['trimAfterCapture']is False
    exports={}
    for ch in(0,1):
        exported=EXPORT/stem/f'digital_{ch}.bin';original_file=directory/f'digital_{ch}.bin'
        assert exported.read_bytes()==original_file.read_bytes()
        exports[str(ch)]={'byte_identical':True,'export_path':str(exported),'sha256':sha(exported),'size_bytes':exported.stat().st_size}
    files=[directory/x for x in('waveform.sal','digital_0.bin','digital_1.bin','remote.stdout','remote.stderr','results.json','acquisition.json','manifest.json')]
    receipts=receipt_basic(directory,original)
    run={'backend':'original-blinka-lgpio'if original else'native-blinka-pwm','nominal_targets_us':targets,
         'raw_file_sha256_and_sizes':{str(p.relative_to(ROOT)):{'sha256':sha(p),'size_bytes':p.stat().st_size}for p in files},
         'saved_sal_metadata':physical,'offline_byte_identical_reexports':exports,'channels':channels,
         'nearest_nominal_descriptive_full_width_blocks_not_command_labels':groups,
         'all_frozen_band_fragments_including_short_and_anomalous':strict_fragments,
         'ordered_full_raw_shape_present':ordered,'all_required_complete_groups_have_boundary_inclusive_sibling_low':all_isolated,
         'complete_frozen_isolated_ordered_topology_supported':ordered and all_isolated and not ambiguous,
         'all_both_high_positive_duration_intersections':all_joint,'direction_handoff_observation':handoff,
         'servo_gpio23_full_available_context':high_context(channels['1']['all_high_intervals'],0,zero[2]['end_s']),
         'gpio18_between_servo_and_brake_low_duration_us':(zero[3]['start_s']-zero[2]['end_s'])*1e6,
         'both_low_tail_start_s':one[-1]['end_s'],'both_low_tail_duration_us':(end-one[-1]['end_s'])*1e6,
         'ambiguities_and_withheld_associations':ambiguous,
         'physical_extent_caveats':['Brake GPIO18 high plateau can merge a first half-duty high; no electrical edge establishes exact setter adoption.',
                                   'Half-to-full high plateaus may merge prior PWM highs; nominal percent/u16 targets are not continuous plateau durations.',
                                   'Initial/final low fragments and long low generation gap retained; they do not electrically identify ownership or exact release calls.'],
         'offline_receipt_source_ownership_checks':receipts}
    audit['runs'][stem]=run
    notes.append(f'{stem}: capture {end:.8f}s; GPIO18 {len(channels["0"]["all_transition_times_s"])} edges/{len(channels["0"]["all_high_intervals"])} highs; GPIO23 {len(channels["1"]["all_transition_times_s"])} edges/{len(channels["1"]["all_high_intervals"])} highs. Servo highs {zero[0]["high_width_stats_us"]["count"]}/{zero[1]["high_width_stats_us"]["count"]}/{zero[2]["high_width_stats_us"]["count"]}; motor half complete highs {zero[4]["high_width_stats_us"]["count"]}/{one[1]["high_width_stats_us"]["count"]}.')
    for ch,index,feature in[('0',0,'servo0'),('0',1,'servo90'),('0',2,'servo180'),('0',4,'motor+half'),('1',1,'motor-half')]:
        row=groups[ch][index];w=row['high_width_stats_us'];l=row['within_same_block_interior_low_stats_us'];p=row['within_same_block_adjacent_rise_stats_us']
        notes.append(f'  {feature} target {w["target"]:.3f}us; high min/median/max {w["min"]:.3f}/{w["median"]:.3f}/{w["max"]:.3f}us; complete within-block low min/max {l["min"]:.3f}/{l["max"]:.3f}us({l["count"]}); adjacent-rise min/max {p["min"]:.3f}/{p["max"]:.3f}us({p["count"]}).')
    notes.append(f'  Direction signed GPIO18-fall to GPIO23-rise {handoff["signed_fall_to_rise_us"]:.3f}us (negative=both-high, positive=both-low). Strict full-extent isolated topology supported: {run["complete_frozen_isolated_ordered_topology_supported"]}.')
    for item in ambiguous:notes.append('  WITHHELD: '+item)
    for rows in groups.values():
        for row in rows:
            for high in row.get('width_outside_frozen_relative_10percent_band',[]):notes.append(f'  Retained out-of-band high index {high["high_index"]}: {high["duration_us"]:.3f}us at {high["start_s"]:.8f}s; no trimming.')
    if original and stem.endswith('r1'):
        fragments=one[1]['all_frozen_band_fragments_including_single_anomalies']
        notes.append('  Complete reverse frozen-band fragments retained: '+', '.join(str(f['pulse_count'])+(' pulses in band' if f['widths_all_in_band'] else ' anomalous pulse')for f in fragments)+'. First20-pulse fragment overlaps peer high; later325-pulse good fragment is not substituted for the full train.')
    notes.append(f'  Actual consumer SSH exit0 in acquisition/results; {receipts["event_count"]} events, 15 phases, 10 actions,3 outputs,3 clean shutdowns. Nonempty preserved stderr diagnostic PIDs {receipts["remote_stderr_preserved"]["diagnostic_pids"]} are distinct from Pi helper {receipts["helper_pid"]}.')
    notes.append('')
audit['overall_conclusion']='All four captures preserve the expected descriptive raw order and clean consumer/API/source/ownership receipts. Native complete isolated ordered topology is supported. Original full-extent isolated topology is withheld because both runs contain a small positive-duration peer-high handoff overlap; original r1 additionally has two out-of-band reverse highs. No quantitative parity verdict or calibrated timing/actuator/installed-Blinka inference.'
notes.extend(['All eight saved-SAL binary re-exports byte-identical; owned Capture objects closed and Manager disconnected. SAL metadata: physical Logic8 81F8C2631DF5BF30, only digital ch0/ch1 at100MSa/s, no filters/no capture trimming.',
              'Original50Hz angle90 duty4914 submits7%=1400us; native C-rounded1499.657us. Native targets999.771/1499.657/1999.847us and motor499.992us; original1000/1400/2000us and motor500us.',
              'Original public deinit changes flags only; safety proof belongs to separate privately owned lab.cancel_tx_pwm/lab.drive_low/lab.low_settle/lab.gpio_read_low/lab.tx_busy/lab.gpio_free/private chip close. Do not credit it to public deinit.',
              'Pi/helper, local host and Saleae timebases are not aligned. Sub-microsecond handoff observations are uncalibrated digital timestamps, not application latency/deadtime/performance acceptance. No installed Blinka/actual actuator/parity verdict.'])
# A receipt specialist's independent checks are attached only when explicitly
# supplied. It also imports no project helper/analyzer and operates offline.
if len(sys.argv)>1:
    receipt_path=Path(sys.argv[1]);receipt_audit=json.loads(receipt_path.read_text())
    assert receipt_audit['passed'] is True and receipt_audit['failures']==[] and len(receipt_audit['checks'])==receipt_audit['check_count'] and all(x['passed']for x in receipt_audit['checks'])
    audit['additional_independent_receipt_checks']=receipt_audit;audit['additional_receipt_check_file_sha256']=sha(receipt_path)
    notes.append(f'Independent receipt/source/ownership specialist: {receipt_audit["check_count"]} checks passed,0 receipt failures. Original78 nested completion-order/native41 serial events validated; original21/native18 source inventories, distinct genuine consumer classes and original/native ownership cleanup semantics verified. Receipt success does not override waveform ambiguities.')
if '--save' in sys.argv:
    assert not FINAL.exists()and not NOTES.exists(),'Exclusive outputs must not overwrite'
    with FINAL.open('x')as out:out.write(json.dumps(audit,indent=2)+'\n')
    with NOTES.open('x')as out:out.write('\n'.join(notes)+'\n')
    print(FINAL,'SHA256',sha(FINAL));print(NOTES,'SHA256',sha(NOTES))
else:
    preview=TEMP/'raw-audit-preview.json'
    preview.write_text(json.dumps(audit,indent=2)+'\n')
    print('Preview only:',preview)
print('\n'.join(notes))
