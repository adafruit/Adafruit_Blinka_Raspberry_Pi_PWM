"""Offline native dual-output functional facts, never performance parity.

Both physical PWM channels share acquisition timestamps. Pi receipt clocks are
not aligned to those timestamps. Only unique, ordered, long/guarded waveform
features are associated with the protocol; ambiguous features stay explicit.
Every raw transition, complete high, low and adjacent-rise interval is retained.
"""

import argparse
import hashlib
import itertools
import json
import math
import statistics
import struct
from pathlib import Path

import capture_native_pwm_dual as collector
from analyze_gpio_pwm_marker import validate_sal
from analyze_kernel_pwm_inverse import require

HELPER_SHA256 = "4d051ad2f4378a7aaaa4f45b89098f6766f4197362ba7a353970c94630c8b93b"
PLAN_NAME = "oct7-native-dual-plan.json"
PLAN_SHA256 = "462b3e808076e13c01b7553ff919b2f3f3333256b557b898091086ac0b068b68"
IDENTIFICATION_RELATIVE_ALLOWANCE = 0.10
MIN_TRAIN_PULSES = 5
LONG_HIGH_US = 100_000
LONG_INTERIOR_LOW_US = 150_000
TARGETS = {
    "servo50": (50, 4915),
    "half500": (500, 32768),
    "half50": (50, 32768),
    "short500_intermediate": (500, 4915),
}


def nominal(frequency, duty):
    period_ns = (1_000_000_000 + frequency // 2) // frequency
    high_ns = (period_ns * duty + 32767) // 65535
    return {"period_us": period_ns / 1000, "high_us": high_ns / 1000}


NOMINALS = {name: nominal(*arguments) for name, arguments in TARGETS.items()}


def read_plan(path=None):
    path = Path(path) if path is not None else Path(__file__).with_name(PLAN_NAME)
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == PLAN_SHA256, "Frozen dual plan changed")
    plan = collector.read_json(data.decode())
    require(
        plan["mode"] == collector.MODE
        and plan["sequence_marker"] == collector.SEQUENCE_MARKER
        and plan["sequence"]
        == [
            {"name": name, "duration_seconds": duration, "actions": list(actions)}
            for name, duration, actions in collector.helper.SEQUENCE
        ]
        and plan["helper_sha256"] == HELPER_SHA256
        and plan["pre_capture_waveform_identification"][
            "ordinary_width_period_relative_band"
        ]
        == IDENTIFICATION_RELATIVE_ALLOWANCE
        and plan["pre_capture_waveform_identification"][
            "minimum_identifiable_train_pulses"
        ]
        == MIN_TRAIN_PULSES
        and plan["pre_capture_waveform_identification"][
            "sustained_high_threshold_seconds"
        ]
        * 1e6
        == LONG_HIGH_US
        and plan["pre_capture_waveform_identification"][
            "interior_low_gap_threshold_seconds"
        ]
        * 1e6
        == LONG_INTERIOR_LOW_US,
        "Frozen dual sequence/identification contract changed",
    )
    for name, digest in (
        ("native_pwm_dual_eval.py", plan["helper_sha256"]),
        ("capture_native_pwm_dual.py", plan["collector_sha256"]),
    ):
        require(
            hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
            == digest,
            "Frozen dual source changed: " + name,
        )
    return plan


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def stats(values):
    if not values:
        return {"count": 0}
    ordered = sorted(values)
    return {
        "count": len(values),
        "min": ordered[0],
        "median": statistics.median(values),
        "max": ordered[-1],
        "mean": statistics.mean(values),
    }


def read_channel(path):
    """Strict format0/1 continuous export reader, including valid all-low data."""
    data = Path(path).read_bytes()
    require(len(data) >= 16 and data[:8] == b"<SALEAE>", "Invalid digital magic/header")
    version, kind = struct.unpack_from("<ii", data, 8)
    require(version in (0, 1) and kind == 0, "Unsupported digital export format")
    offset = 16
    if version:
        require(len(data) >= 24, "Truncated digital chunk count")
        count = struct.unpack_from("<Q", data, offset)[0]
        require(count == 1, "One continuous digital capture chunk required")
        offset += 8
    header_bytes = 36 if version else 28
    require(len(data) >= offset + header_bytes, "Truncated digital chunk header")
    initial = struct.unpack_from("<I", data, offset)[0]
    offset += 4
    sample_rate = None
    if version:
        sample_rate = struct.unpack_from("<d", data, offset)[0]
        require(sample_rate == 100_000_000, "Digital sample rate must be 100MSa/s")
        offset += 8
    begin, end, count = struct.unpack_from("<ddQ", data, offset)
    offset += 24
    require(len(data) == offset + 8 * count, "Truncated/trailing digital edge data")
    edges = list(struct.unpack_from(f"<{count}d", data, offset))
    require(initial == 0, "Digital channel must start low")
    require(
        finite(begin)
        and finite(end)
        and begin < end
        and all(finite(edge) and begin <= edge <= end for edge in edges)
        and all(a < b for a, b in itertools.pairwise(edges)),
        "Digital edges/bounds must be finite, strictly ordered and covered",
    )
    require(len(edges) % 2 == 0, "Digital channel must finish low")
    require(
        not edges or (edges[0] - begin >= 0.15 and end - edges[-1] >= 0.15),
        "At least 150ms initial/final low digital coverage required",
    )
    return channel_facts(
        {
            "binary_format_version": version,
            "header_sample_rate_hz": sample_rate,
            "chunks": 1,
            "begin_seconds": begin,
            "end_seconds": end,
            "initial_state": initial,
            "final_state": 0,
            "edge_count": len(edges),
        },
        edges,
    )


def channel_facts(waveform, edges):
    begin, end = waveform["begin_seconds"], waveform["end_seconds"]
    require(
        finite(begin)
        and finite(end)
        and begin < end
        and waveform["initial_state"] == waveform["final_state"] == 0
        and waveform["edge_count"] == len(edges)
        and len(edges) % 2 == 0
        and all(finite(edge) and begin <= edge <= end for edge in edges)
        and all(a < b for a, b in itertools.pairwise(edges)),
        "Complete finite ordered low-start/end channel required",
    )
    highs = []
    for index, (rise, fall) in enumerate(zip(edges[::2], edges[1::2])):
        width = (fall - rise) * 1e6
        nearest = min(NOMINALS, key=lambda tag: abs(width - NOMINALS[tag]["high_us"]))
        candidates = [
            tag
            for tag in NOMINALS
            if math.isclose(
                width,
                NOMINALS[tag]["high_us"],
                rel_tol=IDENTIFICATION_RELATIVE_ALLOWANCE,
            )
        ]
        highs.append(
            {
                "pair_index": index,
                "rise_seconds": rise,
                "fall_seconds": fall,
                "width_us": width,
                "width_target_candidates": candidates,
                "nearest_width_target": nearest,
                "nearest_width_target_error_us": width - NOMINALS[nearest]["high_us"],
                "descriptive_long_high": width > LONG_HIGH_US,
            }
        )
    lows = []
    last = begin
    for index, high in enumerate(highs):
        lows.append(
            {
                "kind": "initial" if index == 0 else "interior",
                "preceding_pair_index": index - 1 if index else None,
                "following_pair_index": index,
                "begin_seconds": last,
                "end_seconds": high["rise_seconds"],
                "width_us": (high["rise_seconds"] - last) * 1e6,
            }
        )
        last = high["fall_seconds"]
    lows.append(
        {
            "kind": "final" if highs else "entire_all_low_capture",
            "preceding_pair_index": len(highs) - 1 if highs else None,
            "following_pair_index": None,
            "begin_seconds": last,
            "end_seconds": end,
            "width_us": (end - last) * 1e6,
        }
    )
    periods = [
        {
            "preceding_pair_index": a["pair_index"],
            "following_pair_index": b["pair_index"],
            "begin_seconds": a["rise_seconds"],
            "end_seconds": b["rise_seconds"],
            "rise_to_rise_us": (b["rise_seconds"] - a["rise_seconds"]) * 1e6,
        }
        for a, b in itertools.pairwise(highs)
    ]
    return {
        "waveform": {**waveform, "transition_seconds": list(edges)},
        "all_high_runs": highs,
        "all_low_runs": lows,
        "all_adjacent_rise_intervals": periods,
        "all_high_width_stats_us": stats([row["width_us"] for row in highs]),
        "all_low_width_stats_us": stats([row["width_us"] for row in lows]),
        "all_adjacent_rise_stats_us": stats(
            [row["rise_to_rise_us"] for row in periods]
        ),
        "sub_microsecond_highs": [row for row in highs if row["width_us"] < 1],
        "sub_microsecond_interior_lows": [
            row for row in lows if row["kind"] == "interior" and row["width_us"] < 1
        ],
        "unmatched_width_pair_indices": [
            row["pair_index"]
            for row in highs
            if not row["width_target_candidates"] and not row["descriptive_long_high"]
        ],
        "descriptive_long_high_runs": [
            row for row in highs if row["descriptive_long_high"]
        ],
        "width_bins_are_diagnostic_not_command_or_parity_assignments": True,
    }


def train_candidates(channel, tag):
    """No merging across anomalous pulses/periods; candidates are not acceptance."""
    highs = channel["all_high_runs"]
    blocks, block = [], []
    for high in highs:
        compatible = tag in high["width_target_candidates"]
        connects = block and math.isclose(
            (high["rise_seconds"] - block[-1]["rise_seconds"]) * 1e6,
            NOMINALS[tag]["period_us"],
            rel_tol=IDENTIFICATION_RELATIVE_ALLOWANCE,
        )
        if not compatible or not connects:
            if len(block) >= MIN_TRAIN_PULSES:
                blocks.append(block)
            block = []
        if compatible:
            block.append(high)
    if len(block) >= MIN_TRAIN_PULSES:
        blocks.append(block)
    return [
        {
            "tag": tag,
            "pair_indices": [row["pair_index"] for row in block],
            "begin_seconds": block[0]["rise_seconds"],
            "end_seconds": block[-1]["fall_seconds"],
            "high_width_stats_us": stats([row["width_us"] for row in block]),
            "period_stats_us": stats(
                [
                    (b["rise_seconds"] - a["rise_seconds"]) * 1e6
                    for a, b in itertools.pairwise(block)
                ]
            ),
        }
        for block in blocks
    ]


def window_facts(channel, begin, end):
    """Selection is explicit; touching/straddling runs remain visible as context."""
    require(begin < end, "Positive physical window required")
    edges = channel["waveform"]["transition_seconds"]
    highs = channel["all_high_runs"]
    periods = channel["all_adjacent_rise_intervals"]
    selected = [
        row
        for row in highs
        if begin <= row["rise_seconds"] and row["fall_seconds"] <= end
    ]
    adjacent = [
        row
        for row in periods
        if begin <= row["begin_seconds"] and row["end_seconds"] <= end
    ]
    return {
        "window_seconds": [begin, end],
        "duration_seconds": end - begin,
        "edge_indices_including_boundaries": [
            index for index, edge in enumerate(edges) if begin <= edge <= end
        ],
        "overlapping_high_pair_indices": [
            row["pair_index"]
            for row in highs
            if row["fall_seconds"] >= begin and row["rise_seconds"] <= end
        ],
        "wholly_contained_high_pair_indices": [row["pair_index"] for row in selected],
        "wholly_contained_adjacent_rise_intervals": adjacent,
        "contained_high_width_stats_us": stats([row["width_us"] for row in selected]),
        "contained_adjacent_rise_stats_us": stats(
            [row["rise_to_rise_us"] for row in adjacent]
        ),
        "overlapping_low_runs": [
            row
            for row in channel["all_low_runs"]
            if row["end_seconds"] >= begin and row["begin_seconds"] <= end
        ],
        "boundary_runs_not_discarded": True,
    }


def functional_facts(gpio18, gpio23):
    observations, ambiguities = [], []

    def unique(name, candidates):
        if len(candidates) != 1:
            ambiguities.append(
                {
                    "feature": name,
                    "candidate_count": len(candidates),
                    "candidates": candidates,
                }
            )
            return None
        return candidates[0]

    def observation(name, begin, end, evidence):
        observations.append(
            {
                "feature": name,
                "evidence": evidence,
                "gpio18": window_facts(gpio18, begin, end),
                "gpio23": window_facts(gpio23, begin, end),
                "phase_association": "Named protocol association is conditional on the reported unique anchor order, never an aligned command interval",
                "exact_application_or_deinit_instant_identified": False,
            }
        )

    high18 = unique("gpio18_high", gpio18["descriptive_long_high_runs"])
    high23 = unique("gpio23_high", gpio23["descriptive_long_high_runs"])
    if high18:
        observation(
            "gpio18_long_high_with_gpio23_sibling",
            high18["rise_seconds"],
            high18["fall_seconds"],
            high18,
        )
    if high23:
        observation(
            "gpio23_long_high_with_gpio18_sibling",
            high23["rise_seconds"],
            high23["fall_seconds"],
            high23,
        )
    swap_candidates, swap_overlaps = [], []
    trains18 = {
        tag: train_candidates(gpio18, tag) for tag in ("servo50", "half500", "half50")
    }
    trains23 = {tag: train_candidates(gpio23, tag) for tag in ("servo50", "half500")}
    for fast, slow in itertools.product(trains18["half500"], trains23["servo50"]):
        begin, end = (
            max(fast["begin_seconds"], slow["begin_seconds"]),
            min(fast["end_seconds"], slow["end_seconds"]),
        )
        if end > begin:
            overlap = {
                "begin_seconds": begin,
                "end_seconds": end,
                "gpio18_train": fast,
                "gpio23_train": slow,
            }
            swap_overlaps.append(overlap)
            if (
                end - begin
                >= (MIN_TRAIN_PULSES - 1) * NOMINALS["servo50"]["period_us"] / 1e6
            ):
                swap_candidates.append(overlap)
    swap = unique("reciprocal_frequency_swap", swap_candidates)
    if swap and len(swap_overlaps) != 1:
        ambiguities.append(
            {
                "feature": "reciprocal_swap_full_extent",
                "reason": "Additional reciprocal train fragments remain visible; the qualifying guarded window does not identify the full command-phase extent",
                "all_reciprocal_train_overlap_candidates": swap_overlaps,
                "unmatched_gpio18_high_pair_indices": gpio18[
                    "unmatched_width_pair_indices"
                ],
                "unmatched_gpio23_high_pair_indices": gpio23[
                    "unmatched_width_pair_indices"
                ],
            }
        )
    ordered = bool(
        high18
        and high23
        and swap
        and high18["fall_seconds"] < high23["rise_seconds"]
        and high23["fall_seconds"] < swap["begin_seconds"]
    )
    if not ordered:
        ambiguities.append(
            {
                "feature": "protocol_anchor_order",
                "reason": "Unique GPIO18 high, GPIO23 high and later reciprocal swap order not established",
            }
        )
    if swap and ordered:
        observation(
            "reciprocal_frequency_swap",
            swap["begin_seconds"],
            swap["end_seconds"],
            swap,
        )
    gap = unique(
        "gpio18_shutdown_restart_low_gap",
        [
            row
            for row in gpio18["all_low_runs"]
            if row["kind"] == "interior"
            and row["width_us"] > LONG_INTERIOR_LOW_US
            and ordered
            and row["begin_seconds"] > swap["end_seconds"]
        ],
    )
    if gap:
        observation(
            "gpio18_low_gap_with_gpio23_continuing",
            gap["begin_seconds"],
            gap["end_seconds"],
            gap,
        )
    half = unique(
        "late_gpio18_half50",
        [
            row
            for row in trains18["half50"]
            if gap and row["begin_seconds"] > gap["end_seconds"]
        ],
    )
    if gap and half:
        preceding = gpio18["all_high_runs"][gap["preceding_pair_index"]]
        resumed = gpio18["all_high_runs"][gap["following_pair_index"]]
        restart_servo = "servo50" in resumed["width_target_candidates"]
        if not restart_servo:
            ambiguities.append(
                {"feature": "gpio18_restart_shape", "first_resumed_high": resumed}
            )
        observation(
            "gpio18_resumed_after_unique_gap",
            resumed["rise_seconds"],
            half["begin_seconds"],
            {
                "previous_high": preceding,
                "first_resumed_high": resumed,
                "first_resumed_high_servo50_compatible": restart_servo,
                "generation_ownership_from_receipt_only": True,
            },
        )
        final23 = gpio23["all_low_runs"][-1]
        if (
            final23["kind"] == "final"
            and gap["end_seconds"]
            < final23["begin_seconds"]
            < half["begin_seconds"] - 0.15
        ):
            observation(
                "gpio23_final_low_with_gpio18_servo_continuing",
                final23["begin_seconds"],
                half["begin_seconds"],
                final23,
            )
            observation(
                "gpio18_late_half50_while_gpio23_low",
                half["begin_seconds"],
                half["end_seconds"],
                half,
            )
        else:
            ambiguities.append(
                {
                    "feature": "gpio23_shutdown_sibling_window",
                    "reason": "No uniquely ordered final GPIO23 low span with >=150ms before late GPIO18 half50",
                    "final_gpio23_low": final23,
                }
            )
    if high18 and high23 and ordered:
        quiet23 = unique(
            "gpio23_low_before_high",
            [
                row
                for row in gpio23["all_low_runs"]
                if row["kind"] == "interior"
                and row["width_us"] > 100_000
                and high18["rise_seconds"]
                < row["begin_seconds"]
                < row["end_seconds"]
                <= high23["rise_seconds"]
            ],
        )
        if quiet23:
            observation(
                "gpio23_long_low_with_gpio18_sibling",
                quiet23["begin_seconds"],
                quiet23["end_seconds"],
                quiet23,
            )
    return {
        "physical_observations": observations,
        "ambiguities": ambiguities,
        "regular_train_candidates": {"gpio18": trains18, "gpio23": trains23},
        "all_reciprocal_train_overlap_candidates": swap_overlaps,
        "protocol_anchor_order_uniquely_visible": ordered,
        "identification_rules": {
            "width_period_relative_allowance": IDENTIFICATION_RELATIVE_ALLOWANCE,
            "minimum_train_pulses": MIN_TRAIN_PULSES,
            "long_high_us": LONG_HIGH_US,
            "long_shutdown_restart_interior_low_us": LONG_INTERIOR_LOW_US,
            "rules_are_identification_not_acceptance_gates": True,
        },
        "repeated_nominal_phases_not_assigned_from_pi_clock": True,
        "waveform_has_no_output_generation_identity": True,
    }


def analyze(directory, plan_path=None):
    directory = Path(directory)
    plan = read_plan(plan_path)
    read = lambda name: collector.read_json((directory / name).read_text())
    manifest, remote, metadata, acquisition = (
        read(name)
        for name in (
            "manifest.json",
            "remote.stdout",
            "results.json",
            "acquisition.json",
        )
    )
    collector.validate_remote(remote, manifest)
    require(
        manifest["source_sha256"]["native_pwm_dual_eval.py"] == HELPER_SHA256,
        "Frozen dual helper source mismatch",
    )
    require(
        type(metadata.get("schema_version")) is int
        and metadata["schema_version"] == 1
        and metadata.get("host") == "test-pi5.local"
        and metadata.get("mode") == collector.MODE
        and metadata.get("backend") == collector.BACKEND
        and metadata.get("sequence_marker") == collector.SEQUENCE_MARKER
        and type(metadata.get("sample_rate_hz")) is int
        and metadata["sample_rate_hz"] == 100_000_000
        and metadata.get("remote") == remote
        and metadata.get("collection_success") is True
        and metadata.get("production_backend_unchanged") is True
        and metadata.get("parity_evaluated") is False
        and metadata.get("analysis_deferred") is True
        and "waveform_accepted" in metadata
        and metadata["waveform_accepted"] is None
        and "parity_pass" in metadata
        and metadata["parity_pass"] is None
        and metadata.get("outputs")
        == [
            {"gpio": gpio, "saleae_channel": channel, "backend": collector.BACKEND}
            for gpio, channel in ((18, 0), (23, 1))
        ],
        "Successful unchanged dual physical collection required without waveform/parity verdict",
    )
    require(
        acquisition.get("mode") == collector.MODE
        and acquisition.get("backend") == collector.BACKEND
        and acquisition.get("remote_root") == plan["remote_root"]
        and acquisition.get("remote_python") == plan["remote_python"]
        and remote["manifest_path"]
        == acquisition.get("remote_root", "") + "/manifest.json"
        and "primary_error" in acquisition
        and acquisition["primary_error"] is None
        and acquisition.get("evidence_errors") == []
        and acquisition.get("local_timing_not_aligned_to_pi_or_saleae") is True
        and all(
            type(row.get("remote_returncode")) is int
            and row["remote_returncode"] == 0
            and row.get("pre_helper_lead_seconds") == 0.5
            and row.get("post_helper_tail_seconds") == 0.2
            for row in (metadata, acquisition)
        ),
        "Dual acquisition/root/lead/tail/evidence validation failed",
    )
    settings = validate_sal(directory / "waveform.sal")
    channels = [read_channel(directory / f"digital_{index}.bin") for index in (0, 1)]
    bounds = [
        (row["waveform"]["begin_seconds"], row["waveform"]["end_seconds"])
        for row in channels
    ]
    require(bounds[0] == bounds[1], "Both PWM channels must share acquisition bounds")
    require(
        bounds[0][1] - bounds[0][0] >= sum(row[1] for row in collector.helper.SEQUENCE),
        "Insufficient full dual protocol capture coverage",
    )
    names = (
        "manifest.json",
        "remote.stdout",
        "remote.stderr",
        "results.json",
        "acquisition.json",
        "waveform.sal",
        "digital_0.bin",
        "digital_1.bin",
    )
    return {
        "schema_version": 1,
        "capture": directory.name,
        "mode": collector.MODE,
        "backend": collector.BACKEND,
        "plan_sha256": PLAN_SHA256,
        "offline_analyzer_sha256": hashlib.sha256(
            Path(__file__).read_bytes()
        ).hexdigest(),
        "source_manifest": manifest,
        "saved_capture_settings": settings,
        "evidence_sha256": {
            name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
            for name in names
        },
        "collection_receipts_validated": True,
        "gpio18_channel0": channels[0],
        "gpio23_channel1": channels[1],
        "functional_waveform_facts": functional_facts(*channels),
        "receipt_ownership_not_electrical_phase_identity": {
            "outputs": remote["outputs"],
            "shutdowns": remote["shutdowns"],
            "phases": remote["phases"],
        },
        "caller_events_pi_clock": [
            {
                **event,
                "caller_duration_us": (event["end_ns"] - event["begin_ns"]) / 1000,
            }
            for event in remote["events"]
        ],
        "actual_c_rounded_nominal_targets": NOMINALS,
        "functional_coexistence_only": True,
        "matched_performance_parity": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "pi_saleae_clocks_aligned": False,
        "application_latency_measured": False,
        "physical_channels_share_acquisition_timestamps": True,
        "no_edge_trimming_or_glitch_filtering": True,
        "timebase_gpio_driver_and_threshold_skew_calibrated": False,
        "limitation": "Finite native-only functional observations. Receipts establish private ownership, generation, release and unchanged sibling API identity; electrical waveforms have no generation labels. Unique ordered guarded waveform windows are compatible observations, not synchronized command phases or exact adoption/deinit times. All ambiguous, boundary and anomalous edges remain retained. No performance parity, scheduling bound, analog or subsample-glitch exclusion is established.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", type=Path, nargs="+")
    parser.add_argument("--output-name", default="dual-analysis.json")
    parser.add_argument("--plan", type=Path)
    args = parser.parse_args(argv)
    require(
        Path(args.output_name).name == args.output_name
        and args.output_name not in ("", ".", ".."),
        "Output must be a filename",
    )
    outputs = [directory / args.output_name for directory in args.directories]
    require(
        len(set(outputs)) == len(outputs)
        and all(not path.exists() and not path.is_symlink() for path in outputs),
        "Exclusive fresh report outputs required",
    )
    reports = [analyze(directory, args.plan) for directory in args.directories]
    for path, report in zip(outputs, reports):
        with path.open("x") as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
