"""Dual analyzer fakes only: no GPIO, native extension, SSH or Saleae calls."""

import copy
import json
import math
import struct
import zipfile

import analyze_native_pwm_dual as audit
import pytest
import test_native_pwm_dual_eval as helper_fakes

old_environment = helper_fakes.old_environment
environment = helper_fakes.environment


def channel(edges, end=5.2):
    return audit.channel_facts(
        {
            "begin_seconds": 0.0,
            "end_seconds": end,
            "initial_state": 0,
            "final_state": 0,
            "edge_count": len(edges),
        },
        edges,
    )


def train(start, stop, tag):
    nominal = audit.NOMINALS[tag]
    period, high = nominal["period_us"] / 1e6, nominal["high_us"] / 1e6
    result, index = [], 0
    while start + index * period + high < stop:
        rise = start + index * period
        result.extend((rise, rise + high))
        index += 1
    return result


def visible_protocol():
    edges18 = (
        train(0.8, 1.2, "servo50")
        + [1.21, 1.41]
        + train(1.42, 2.1, "servo50")
        + train(2.12, 2.36, "half500")
        + train(2.38, 2.68, "servo50")
        + train(3.15, 3.94, "servo50")
        + train(3.96, 4.16, "half50")
    )
    edges23 = (
        train(0.8, 1.41, "half500")
        + [1.57, 1.77]
        + train(1.78, 2.1, "half500")
        + train(2.12, 2.36, "servo50")
        + train(2.38, 3.5, "half500")
    )
    return edges18, edges23


def binary(edges, version=0, begin=0.0, end=5.2, initial=0, rate=100_000_000):
    data = b"<SALEAE>" + struct.pack("<ii", version, 0)
    if version:
        data += struct.pack("<Q", 1)
    data += struct.pack("<I", initial)
    if version:
        data += struct.pack("<d", rate)
    return (
        data
        + struct.pack("<ddQ", begin, end, len(edges))
        + struct.pack(f"<{len(edges)}d", *edges)
    )


def test_frozen_plan_and_exact_c_rounded_targets():
    assert len(audit.read_plan()["sequence"]) == 13
    assert audit.NOMINALS == {
        "servo50": {"period_us": 20_000, "high_us": 1499.962},
        "half500": {"period_us": 2000, "high_us": 1000.015},
        "half50": {"period_us": 20_000, "high_us": 10000.153},
        "short500_intermediate": {"period_us": 2000, "high_us": 149.996},
    }


def test_changed_plan_refused(tmp_path):
    path = tmp_path / "plan.json"
    path.write_text(json.dumps(audit.read_plan()))
    with pytest.raises(ValueError, match="Frozen dual plan changed"):
        audit.read_plan(path)


@pytest.mark.parametrize("version", [0, 1])
@pytest.mark.parametrize("edges", [[], [0.8, 0.8015, 0.82, 0.8215]])
def test_raw_reader_retains_complete_channels_and_valid_all_low(
    tmp_path, version, edges
):
    path = tmp_path / "digital.bin"
    path.write_bytes(binary(edges, version))
    facts = audit.read_channel(path)
    assert facts["waveform"]["transition_seconds"] == edges
    assert len(facts["all_high_runs"]) == len(edges) // 2
    assert len(facts["all_low_runs"]) == len(edges) // 2 + 1
    if not edges:
        assert facts["all_low_runs"][0]["kind"] == "entire_all_low_capture"


@pytest.mark.parametrize(
    "data",
    [
        b"bad",
        binary([0.8, 0.8015]) + b"x",
        binary([0.8, 0.8015])[:-1],
        binary([0.8]),
        binary([0.8015, 0.8]),
        binary([0.8, 0.8]),
        binary([0.8, math.nan]),
        binary([0.8, math.inf]),
        binary([0.8, 0.8015], initial=1),
        binary([0.8, 0.8015], end=0.8),
        binary([0.8, 0.8015], version=1, rate=50_000_000),
        binary([0.1, 0.1015]),
        binary([5.1, 5.1015]),
    ],
)
def test_malformed_incomplete_or_uncovered_raw_refused(tmp_path, data):
    path = tmp_path / "digital.bin"
    path.write_bytes(data)
    with pytest.raises(ValueError):
        audit.read_channel(path)


def test_all_boundary_anomalies_and_subus_runs_retained():
    edges = [0.8, 0.80000001, 0.80000002, 0.8021, 0.82, 0.97]
    facts = channel(edges)
    assert facts["waveform"]["transition_seconds"] == edges
    assert len(facts["all_high_runs"]) == 3
    assert len(facts["all_low_runs"]) == 4
    assert len(facts["all_adjacent_rise_intervals"]) == 2
    assert len(facts["sub_microsecond_highs"]) == 1
    assert len(facts["sub_microsecond_interior_lows"]) == 1
    assert facts["unmatched_width_pair_indices"] == [0, 1]
    selected = audit.window_facts(facts, 0.800000005, 0.82)
    assert selected["overlapping_high_pair_indices"] == [0, 1, 2]
    assert selected["wholly_contained_high_pair_indices"] == [1]
    assert selected["edge_indices_including_boundaries"] == [1, 2, 3, 4]


def test_unique_visible_features_and_sibling_facts_without_alignment():
    channels = [channel(edges) for edges in visible_protocol()]
    facts = audit.functional_facts(*channels)
    assert facts["protocol_anchor_order_uniquely_visible"]
    assert facts["ambiguities"] == []
    features = {row["feature"]: row for row in facts["physical_observations"]}
    assert len(features) == 8
    sibling = features["gpio18_low_gap_with_gpio23_continuing"]["gpio23"]
    assert sibling["contained_high_width_stats_us"]["count"] > 100
    assert sibling["contained_adjacent_rise_stats_us"]["min"] == pytest.approx(2000)
    assert features["gpio23_final_low_with_gpio18_servo_continuing"]["gpio23"][
        "contained_high_width_stats_us"
    ] == {"count": 0}
    assert all(
        not row["exact_application_or_deinit_instant_identified"]
        for row in features.values()
    )
    assert facts["waveform_has_no_output_generation_identity"]


def test_missing_all_low_channel_is_ambiguous_not_malformed_or_accepted():
    facts = audit.functional_facts(channel([]), channel([]))
    assert not facts["protocol_anchor_order_uniquely_visible"]
    assert facts["physical_observations"] == []
    assert facts["ambiguities"]


def test_extra_long_high_never_arbitrarily_assigned():
    edges18, edges23 = visible_protocol()
    edges18 += [4.3, 4.5]
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    duplicate = next(
        row for row in facts["ambiguities"] if row["feature"] == "gpio18_high"
    )
    assert duplicate["candidate_count"] == 2
    assert not facts["protocol_anchor_order_uniquely_visible"]
    assert not any(
        row["feature"] == "gpio18_long_high_with_gpio23_sibling"
        for row in facts["physical_observations"]
    )


def test_train_anomaly_breaks_blocks_without_erasure_or_merging():
    edges = train(0.8, 1.04, "servo50")
    edges[11] += 0.005
    facts = channel(edges)
    candidates = audit.train_candidates(facts, "servo50")
    assert len(candidates) == 2
    assert 5 not in [index for row in candidates for index in row["pair_indices"]]
    assert facts["all_high_runs"][5]["width_us"] == pytest.approx(6499.962)
    assert facts["waveform"]["transition_seconds"] == edges


def test_partial_swap_fragment_makes_full_extent_explicitly_ambiguous():
    edges18, edges23 = visible_protocol()
    index = min(
        range(0, len(edges18), 2), key=lambda index: abs(edges18[index] - 2.306)
    )
    assert edges18[index] == pytest.approx(2.306)
    edges18[index + 1] = edges18[index] + 0.00112697
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    assert facts["protocol_anchor_order_uniquely_visible"]
    ambiguity = next(
        row
        for row in facts["ambiguities"]
        if row["feature"] == "reciprocal_swap_full_extent"
    )
    assert len(ambiguity["all_reciprocal_train_overlap_candidates"]) == 2
    assert ambiguity["unmatched_gpio18_high_pair_indices"] == [index // 2]
    assert any(
        row["feature"] == "gpio18_low_gap_with_gpio23_continuing"
        for row in facts["physical_observations"]
    )


def test_sibling_window_keeps_out_of_nominal_pulse_in_stats():
    edges18, edges23 = visible_protocol()
    index = min(range(0, len(edges23), 2), key=lambda index: abs(edges23[index] - 2.98))
    edges23[index + 1] += 0.0005
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    window = next(
        row
        for row in facts["physical_observations"]
        if row["feature"] == "gpio18_low_gap_with_gpio23_continuing"
    )
    assert index // 2 in window["gpio23"]["wholly_contained_high_pair_indices"]
    assert window["gpio23"]["contained_high_width_stats_us"]["max"] == pytest.approx(
        1500.015
    )


def saved_capture(tmp_path, monkeypatch, environment):
    _state, _guard, _module, manifest, _sleeps = environment
    remote = audit.collector.helper.experiment(helper_fakes.ROOT + "/manifest.json")
    audit.collector.validate_remote(remote, manifest)
    plan = copy.deepcopy(audit.read_plan())
    plan["remote_root"] = helper_fakes.ROOT
    monkeypatch.setattr(audit, "read_plan", lambda _path=None: plan)
    directory = tmp_path / "fake-dual"
    directory.mkdir()
    metadata = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": audit.collector.MODE,
        "backend": audit.collector.BACKEND,
        "sequence_marker": audit.collector.SEQUENCE_MARKER,
        "sample_rate_hz": 100_000_000,
        "remote": remote,
        "collection_success": True,
        "production_backend_unchanged": True,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "waveform_accepted": None,
        "parity_pass": None,
        "outputs": [
            {
                "gpio": gpio,
                "saleae_channel": channel,
                "backend": audit.collector.BACKEND,
            }
            for gpio, channel in ((18, 0), (23, 1))
        ],
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
    }
    acquisition = {
        "mode": audit.collector.MODE,
        "backend": audit.collector.BACKEND,
        "remote_root": helper_fakes.ROOT,
        "remote_python": plan["remote_python"],
        "primary_error": None,
        "evidence_errors": [],
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
    }
    for name, value in (
        ("manifest.json", manifest),
        ("remote.stdout", remote),
        ("results.json", metadata),
        ("acquisition.json", acquisition),
    ):
        (directory / name).write_text(json.dumps(value))
    (directory / "remote.stderr").write_text("")
    settings = {
        "enabledChannels": [{"type": "Digital", "index": index} for index in (0, 1)],
        "sampleRate": {"digital": 100_000_000},
        "glitchFilter": {"enabled": False, "channels": []},
    }
    sal = {
        "data": {
            "legacySettings": settings,
            "legacyDevice": {"isSimulation": False, "deviceId": "81F8C2631DF5BF30"},
        }
    }
    with zipfile.ZipFile(directory / "waveform.sal", "w") as archive:
        archive.writestr("meta.json", json.dumps(sal))
    for index, edges in enumerate(visible_protocol()):
        (directory / f"digital_{index}.bin").write_bytes(binary(edges))
    return directory


def test_full_receipts_and_raw_sal_analysis_fakes(tmp_path, monkeypatch, environment):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    report = audit.analyze(directory)
    assert report["collection_receipts_validated"]
    assert report["functional_waveform_facts"]["ambiguities"] == []
    assert len(report["evidence_sha256"]) == 8
    assert report["waveform_accepted"] is None and report["parity_pass"] is None
    assert (
        not report["pi_saleae_clocks_aligned"]
        and not report["application_latency_measured"]
    )
    assert (
        report["receipt_ownership_not_electrical_phase_identity"]["outputs"][2][
            "generation"
        ]
        == 2
    )


@pytest.mark.parametrize(
    "file,key,value",
    [
        ("results.json", "schema_version", True),
        ("results.json", "collection_success", False),
        ("results.json", "parity_pass", True),
        ("results.json", "remote_returncode", True),
        ("acquisition.json", "evidence_errors", ["failed export"]),
        ("acquisition.json", "primary_error", "timeout"),
        ("acquisition.json", "remote_root", "/tmp/other"),
        ("acquisition.json", "local_timing_not_aligned_to_pi_or_saleae", False),
    ],
)
def test_failed_or_mismatched_collection_receipts_refused(
    tmp_path, monkeypatch, environment, file, key, value
):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    path = directory / file
    data = json.loads(path.read_text())
    data[key] = value
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError):
        audit.analyze(directory)


def test_mismatched_channel_bounds_refused(tmp_path, monkeypatch, environment):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    (directory / "digital_1.bin").write_bytes(binary(visible_protocol()[1], end=5.3))
    with pytest.raises(ValueError, match="share acquisition bounds"):
        audit.analyze(directory)


@pytest.mark.parametrize(
    "scope,key,value",
    [
        ("legacyDevice", "isSimulation", True),
        ("legacyDevice", "deviceId", "0000000000000001"),
        ("legacySettings", "enabledChannels", [{"type": "Digital", "index": 0}]),
        ("legacySettings", "sampleRate", {"digital": 50_000_000}),
        ("legacySettings", "glitchFilter", {"enabled": True, "channels": [0]}),
    ],
)
def test_nonphysical_filtered_or_wrong_channel_sal_refused(
    tmp_path, monkeypatch, environment, scope, key, value
):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    path = directory / "waveform.sal"
    with zipfile.ZipFile(path) as archive:
        data = json.loads(archive.read("meta.json"))
    data["data"][scope][key] = value
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("meta.json", json.dumps(data))
    with pytest.raises(ValueError):
        audit.analyze(directory)


def test_report_write_is_exclusive_and_preserves_existing_evidence(
    tmp_path, monkeypatch, environment
):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    audit.main([str(directory), "--output-name", "analysis.json"])
    original = (directory / "analysis.json").read_bytes()
    with pytest.raises(ValueError, match="Exclusive"):
        audit.main([str(directory), "--output-name", "analysis.json"])
    assert (directory / "analysis.json").read_bytes() == original
