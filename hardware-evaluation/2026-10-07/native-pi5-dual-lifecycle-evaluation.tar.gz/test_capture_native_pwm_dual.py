"""Fake-only independent native PWM collector tests; no hardware or SSH."""

import hashlib
import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_native_pwm_dual as bench
import pytest
import test_native_pwm_dual_eval as dual_fakes

ROOT = "/tmp/blinka-pwm-native-dual.abc123"
PYTHON = "/tmp/blinka-pwm-oct6.F3SDcm/venv/bin/python"
old_environment = dual_fakes.old_environment
environment = dual_fakes.environment


def configure(monkeypatch, scenario="success"):
    events = []
    manifest = {"schema_version": 1, "source_sha256": {"fake": "a" * 64}}
    receipt = {"backend": bench.BACKEND, "manifest_path": ROOT + "/manifest.json"}
    monkeypatch.setattr(bench.helper, "load_manifest", lambda _path: manifest)
    local = MagicMock(return_value=manifest["source_sha256"])
    validate = MagicMock()
    if scenario == "bad_receipt":
        validate.side_effect = ValueError("bad dual lifecycle receipt")
    monkeypatch.setattr(bench, "validate_local_manifest", local)
    monkeypatch.setattr(bench, "validate_remote", validate)
    capture = MagicMock()
    capture.__enter__.return_value = capture
    capture.stop.side_effect = lambda: events.append("stop")

    def save(path):
        events.append("save")
        if scenario == "save_error":
            raise OSError("save failed")
        Path(path).write_bytes(b"fake SAL")

    def export(path, **kwargs):
        assert kwargs == {"digital_channels": [0, 1]}
        events.append("export")
        (Path(path) / "digital_0.bin").write_bytes(b"fake GPIO18 PWM edges")
        if scenario != "missing_gpio23":
            (Path(path) / "digital_1.bin").write_bytes(b"fake GPIO23 PWM edges")

    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = export
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=MagicMock(return_value=manager)),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            PYTHON,
            ROOT + "/native_pwm_dual_eval.py",
            "--manifest",
            ROOT + "/manifest.json",
        ]
        assert set(kwargs) == {"stdout", "stderr", "text", "check", "timeout"}
        assert (
            kwargs["text"] is True
            and kwargs["check"] is False
            and kwargs["timeout"] == 30
        )
        if scenario in ("timeout", "interrupt"):
            kwargs["stdout"].write("partial receipt")
            kwargs["stderr"].write("partial diagnostic")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            raise KeyboardInterrupt("interrupted")
        kwargs["stdout"].write(json.dumps(receipt))
        return subprocess.CompletedProcess(
            command, 1 if scenario == "helper_failed" else 0
        )

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(
        bench.time, "sleep", lambda duration: events.append(("sleep", duration))
    )
    return events, manager, runner, local, validate, manifest, receipt


def test_capture_both_unfiltered_pwm_channels_and_defer_verdict(monkeypatch, tmp_path):
    events, manager, runner, _local, validate, manifest, receipt = configure(
        monkeypatch
    )
    output = tmp_path / "capture"
    result = bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    assert events == [("sleep", 0.5), "ssh", ("sleep", 0.2), "stop", "save", "export"]
    manager.start_capture.assert_called_once_with(
        device_id="81F8C2631DF5BF30",
        device_configuration={
            "enabled_digital_channels": [0, 1],
            "digital_sample_rate": 100_000_000,
        },
    )
    runner.assert_called_once()
    validate.assert_called_once_with(receipt, manifest)
    assert result["collection_success"] is True
    assert result["outputs"] == [
        {"gpio": 18, "saleae_channel": 0, "backend": bench.BACKEND},
        {"gpio": 23, "saleae_channel": 1, "backend": bench.BACKEND},
    ]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert result["parity_evaluated"] is False and result["analysis_deferred"] is True
    assert json.loads((output / "manifest.json").read_text()) == manifest
    assert json.loads((output / "results.json").read_text()) == result
    assert (output / "waveform.sal").read_bytes() == b"fake SAL"
    assert (output / "digital_0.bin").read_bytes() == b"fake GPIO18 PWM edges"
    assert (output / "digital_1.bin").read_bytes() == b"fake GPIO23 PWM edges"


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "save_error",
        "missing_gpio23",
        "simulation",
        "helper_failed",
        "bad_receipt",
    ],
)
def test_failures_keep_metadata_and_available_raw_evidence(
    monkeypatch, tmp_path, scenario
):
    events, _manager, runner, _local, _validate, _manifest, _receipt = configure(
        monkeypatch, scenario
    )
    output = tmp_path / "capture"
    with pytest.raises((ValueError, RuntimeError, KeyboardInterrupt)):
        bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    acquisition = json.loads((output / "acquisition.json").read_text())
    result = json.loads((output / "results.json").read_text())
    assert result["collection_success"] is False and result["receipt_validation_error"]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    if scenario == "simulation":
        runner.assert_not_called()
        assert not events
    else:
        assert events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
        assert (output / "digital_0.bin").is_file()
        if scenario != "missing_gpio23":
            assert (output / "digital_1.bin").is_file()
    if scenario in ("timeout", "interrupt"):
        assert (output / "remote.stdout").read_text() == "partial receipt"
        assert (output / "remote.stderr").read_text() == "partial diagnostic"
        assert acquisition["remote_returncode"] == (
            124 if scenario == "timeout" else None
        )
    if scenario == "save_error":
        assert acquisition["evidence_errors"] == ["save_capture: OSError: save failed"]


@pytest.mark.parametrize(
    "root,python",
    [("/tmp", PYTHON), (ROOT, PYTHON + ";unsafe"), (ROOT, "/usr/bin/python3")],
)
def test_invalid_remote_inputs_refuse_before_output_and_ssh(
    monkeypatch, tmp_path, root, python
):
    _events, _manager, runner, local, _validate, _manifest, _receipt = configure(
        monkeypatch
    )
    with pytest.raises(ValueError):
        bench.capture_test(
            tmp_path / "capture", root, python, tmp_path / "manifest.json"
        )
    runner.assert_not_called()
    local.assert_not_called()
    assert not (tmp_path / "capture").exists()


def test_exclusive_output_preserves_existing_evidence(monkeypatch, tmp_path):
    _events, _manager, runner, _local, _validate, _manifest, _receipt = configure(
        monkeypatch
    )
    output = tmp_path / "capture"
    output.mkdir()
    sentinel = output / "previous.txt"
    sentinel.write_text("keep")
    with pytest.raises(FileExistsError):
        bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    assert sentinel.read_text() == "keep"
    runner.assert_not_called()


def test_local_manifest_checks_python_but_not_pi_binaries(monkeypatch):
    directory = Path(bench.__file__).parent
    package = (
        directory.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src/adafruit_blinka_raspberry_pi_pwm"
    )
    paths = [
        directory / name
        for name in (
            "native_pwm_dual_eval.py",
            "native_pwm_updates_eval.py",
            "native_pwm_half50_eval.py",
            "kernel_pwm_lgpio_baseline_eval.py",
            "kernel_pwm_eval.py",
        )
    ]
    hashes = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths
    }
    hashes.update(
        {
            "adafruit_blinka_raspberry_pi_pwm/" + name: hashlib.sha256(
                (package / name).read_bytes()
            ).hexdigest()
            for name in ("__init__.py", "_software.py")
        }
    )
    hashes["adafruit_blinka_raspberry_pi_pwm/_native.so"] = "f" * 64
    monkeypatch.setattr(bench.helper, "validate_manifest", lambda _manifest: hashes)
    assert bench.validate_local_manifest({}) == hashes
    hashes["adafruit_blinka_raspberry_pi_pwm/_software.py"] = "0" * 64
    with pytest.raises(ValueError, match="local production"):
        bench.validate_local_manifest({})


def test_cli_native_only_and_reports_no_waveform_verdict(monkeypatch, tmp_path, capsys):
    capture = MagicMock(return_value={"collection_success": True})
    monkeypatch.setattr(bench, "capture_test", capture)
    args = [
        str(tmp_path / "capture"),
        "--remote-root",
        ROOT,
        "--remote-python",
        PYTHON,
        "--manifest",
        str(tmp_path / "manifest.json"),
    ]
    with pytest.raises(SystemExit) as error:
        bench.main(args + ["--backend", "lgpio"])
    assert error.value.code == 2
    capture.assert_not_called()
    assert bench.main(args) == 0
    capture.assert_called_once_with(
        tmp_path / "capture", ROOT, PYTHON, tmp_path / "manifest.json"
    )
    summary = json.loads(capsys.readouterr().out)
    assert summary["backend"] == bench.BACKEND
    assert summary["waveform_accepted"] is None and summary["parity_evaluated"] is False


def test_real_public_api_fake_receipt_and_reused_fd_validate(environment):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = bench.helper.experiment(ROOT + "/manifest.json")
    assert receipt["success"]
    assert [row["owned_request"]["fd"] for row in receipt["outputs"]] == [100, 101, 100]
    bench.validate_remote(receipt, manifest)
    assert bench.validate_local_manifest(manifest) == manifest["source_sha256"]


@pytest.mark.parametrize(
    "problem", ["shared_fd", "sibling", "action", "event_order", "cleanup"]
)
def test_receipt_rejects_invalid_lifecycle_or_private_ownership(environment, problem):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = bench.helper.experiment(ROOT + "/manifest.json")
    assert receipt["success"]
    if problem == "shared_fd":
        receipt["outputs"][1]["owned_request"]["fd"] = receipt["outputs"][0][
            "owned_request"
        ]["fd"]
    elif problem == "sibling":
        receipt["shutdowns"][0]["sibling_after"]["frequency"] = 50
    elif problem == "action":
        receipt["phases"][1]["actions"][0] = {
            "operation": "set",
            "output_id": "gpio18-g1",
            "frequency": 50,
            "duty_u16": 32768,
        }
    elif problem == "event_order":
        events = receipt["events"]
        index = next(
            i
            for i, event in enumerate(events)
            if event["operation"] == "PWMOut.frequency"
        )
        events[index], events[index + 1] = events[index + 1], events[index]
    else:
        receipt["outputs"][0]["cleanup_final_readback"]["gpio_level"] = False
    with pytest.raises(ValueError):
        bench.validate_remote(receipt, manifest)
