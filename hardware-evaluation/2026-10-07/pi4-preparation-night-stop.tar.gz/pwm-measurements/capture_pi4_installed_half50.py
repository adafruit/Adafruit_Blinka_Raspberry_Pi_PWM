"""Narrow Pi4 real-Pin acquisition and untrimmed offline reconstruction.

Passive probes only: GPIO18/channel2, untouched GPIO23/channel3. Four fresh
idle captures alternate original/native order. No imports call hardware APIs.
Collection completion and descriptive waveform facts are separate from parity.
"""

import argparse
import hashlib
import json
import math
import re
import shlex
import statistics
import subprocess
import time
from pathlib import Path

from capture_pwm import read_digital
from saleae import automation

DEVICE_ID = "81F8C2631DF5BF30"
HELPER = "pi4_installed_pwm_half50_eval.py"
RUNS = (
    ("oct7-pi4-installed-half50-original-r1", "original"),
    ("oct7-pi4-installed-half50-native-r1", "native"),
    ("oct7-pi4-installed-half50-native-r2", "native"),
    ("oct7-pi4-installed-half50-original-r2", "original"),
)
ROOT_PATTERN = r"/tmp/blinka-pwm-pi4-real-pin\.[a-z0-9_]{8}"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    path = Path(path).absolute()
    require(
        path.is_file() and not path.is_symlink() and path.resolve() == path,
        "Regular canonical file required: " + str(path),
    )
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result

    return json.loads(Path(path).read_text(), object_pairs_hook=pairs)


def method_hashes():
    return {
        Path(__file__).name: digest(__file__),
        HELPER: digest(Path(__file__).parent / HELPER),
        "capture_pwm.py": digest(read_digital.__code__.co_filename),
    }


def validate_inputs(directory, plan_path, manifest_path):
    directory = Path(directory).absolute()
    require(directory.resolve() == directory, "Output cannot traverse links")
    require(not directory.exists(), "Exclusive new capture directory required")
    plan_path, manifest_path = Path(plan_path), Path(manifest_path)
    plan_hash, manifest_hash = digest(plan_path), digest(manifest_path)
    plan, manifest = read_json(plan_path), read_json(manifest_path)
    root = plan.get("remote_root")
    require(
        isinstance(root, str) and re.fullmatch(ROOT_PATTERN, root),
        "Fresh Pi4 root required",
    )
    require(
        plan.get("schema_version") == 1
        and type(plan["schema_version"]) is int
        and plan.get("capture_order") == [name for name, _backend in RUNS]
        and plan.get("capture_backends") == dict(RUNS)
        and plan.get("remote_python") == root + "/venv/bin/python"
        and plan.get("host") == "test2-pi4.local"
        and type(manifest.get("schema_version")) is int
        and manifest["schema_version"] == 1
        and manifest.get("remote_root") == root
        and plan.get("manifest_sha256") == manifest_hash
        and plan.get("method_sha256") == method_hashes()
        and plan.get("outputs")
        == [{"gpio": 18, "saleae_channel": 2}, {"gpio": 23, "saleae_channel": 3}]
        and plan.get("frequency") == 50
        and type(plan["frequency"]) is int
        and plan.get("duty_cycle") == 32768
        and type(plan["duty_cycle"]) is int
        and plan.get("hold_seconds") == 3.0
        and type(plan["hold_seconds"]) is float
        and plan.get("runtime_flags") == {"short_slice": False, "shared": False},
        "Frozen Pi4 source/runtime/protocol/wiring plan mismatch",
    )
    require(
        all(type(value) is bool for value in plan["runtime_flags"].values()),
        "Exact boolean scheduler flags required",
    )
    require(directory.name in dict(RUNS), "Only predeclared capture labels allowed")
    preflight = Path(plan.get("preflight_receipt_path", ""))
    require(
        digest(preflight) == plan.get("preflight_receipt_sha256"),
        "Unchanged successful preflight required",
    )
    receipt = read_json(preflight)
    require(
        receipt.get("accepted") is True
        and type(receipt.get("ssh_returncode")) is int
        and receipt["ssh_returncode"] == 0,
        "Actual successful preflight required",
    )
    return directory, plan, manifest, plan_hash, manifest_hash


def collect(directory, plan_path, manifest_path):
    output, plan, manifest, plan_hash, manifest_hash = validate_inputs(
        directory, plan_path, manifest_path
    )
    output.mkdir(parents=True, exist_ok=False)
    for name, path in (("plan.json", plan_path), ("manifest.json", manifest_path)):
        with (output / name).open("xb") as stream:
            stream.write(Path(path).read_bytes())
    backend, root = dict(RUNS)[output.name], plan["remote_root"]
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test2-pi4.local",
        shlex.join(
            [
                plan["remote_python"],
                "-I",
                root + "/" + HELPER,
                "--manifest",
                root + "/manifest.json",
                "--backend",
                backend,
            ]
        ),
    ]
    remote, primary, version = None, None, None
    evidence_errors = []
    with (
        (output / "remote.stdout").open("x") as stdout,
        (output / "remote.stderr").open("x") as stderr,
    ):
        try:
            with automation.Manager.connect(
                port=10430, connect_timeout_seconds=5
            ) as manager:
                require(
                    any(
                        d.device_id == DEVICE_ID and not d.is_simulation
                        for d in manager.get_devices()
                    ),
                    "Physical Logic8 required",
                )
                version = manager.get_app_info().app_version
                config = automation.LogicDeviceConfiguration(
                    enabled_digital_channels=[2, 3],
                    digital_sample_rate=100_000_000,
                    glitch_filters=[],
                )
                with manager.start_capture(
                    device_id=DEVICE_ID, device_configuration=config
                ) as capture:
                    try:
                        time.sleep(0.5)
                        remote = subprocess.run(
                            command,
                            stdin=subprocess.DEVNULL,
                            stdout=stdout,
                            stderr=stderr,
                            timeout=25,
                            check=False,
                        )
                    except BaseException as error:
                        primary = type(error).__name__ + ": " + str(error)
                    finally:
                        for name, operation in (
                            ("tail", lambda: time.sleep(0.2)),
                            ("stop", capture.stop),
                            (
                                "save",
                                lambda: capture.save_capture(
                                    str(output / "waveform.sal")
                                ),
                            ),
                            (
                                "export",
                                lambda: capture.export_raw_data_binary(
                                    str(output), digital_channels=[2, 3]
                                ),
                            ),
                        ):
                            try:
                                operation()
                            except BaseException as error:
                                evidence_errors.append(
                                    {
                                        "operation": name,
                                        "error": type(error).__name__
                                        + ": "
                                        + str(error),
                                    }
                                )
        except BaseException as error:
            if primary is None:
                primary = type(error).__name__ + ": " + str(error)
    actual = (
        remote.returncode
        if remote is not None and type(remote.returncode) is int
        else None
    )
    parsed = None
    try:
        parsed = json.loads((output / "remote.stdout").read_text())
    except (ValueError, OSError) as error:
        evidence_errors.append(
            {
                "operation": "parse_helper",
                "error": type(error).__name__ + ": " + str(error),
            }
        )
    success = (
        primary is None
        and not evidence_errors
        and actual == 0
        and isinstance(parsed, dict)
        and parsed.get("success") is True
    )
    acquisition = {
        "physical_device_id": DEVICE_ID,
        "logic_version": version,
        "requested_sample_rate_hz": 100_000_000,
        "enabled_digital_channels": [2, 3],
        "glitch_filters": [],
        "actual_ssh_returncode": actual,
        "command": command,
        "primary_error": primary,
        "evidence_errors": evidence_errors,
    }
    write_new(output / "acquisition.json", acquisition)
    result = {
        "schema_version": 1,
        "capture": output.name,
        "backend": backend,
        "plan_sha256": plan_hash,
        "manifest_sha256": manifest_hash,
        "method_sha256": method_hashes(),
        "acquisition": acquisition,
        "remote": parsed,
        "collection_success": success,
        "parity_pass": None,
        "passive_probes_only": True,
    }
    write_new(output / "results.json", result)
    require(
        success, "Collection failed; all available evidence preserved: " + output.name
    )
    print(
        json.dumps(
            {
                "capture": output.name,
                "collection_success": True,
                "actual_ssh_returncode": actual,
            }
        )
    )
    return 0


def describe(values):
    if not values:
        return {"count": 0}
    ordered = sorted(values)
    return {
        "count": len(values),
        "min": ordered[0],
        "median": statistics.median(values),
        "mean": statistics.mean(values),
        "p95": ordered[math.ceil(len(values) * 0.95) - 1],
        "p99": ordered[math.ceil(len(values) * 0.99) - 1],
        "max": ordered[-1],
    }


def reconstruct(path, target_high_us):
    version, chunks = read_digital(Path(path))
    rows = []
    for initial, begin, end, sample_rate, times in chunks:
        rises = list(times[0 if initial == 0 else 1 :: 2])
        falls = list(times[1 if initial == 0 else 0 :: 2])
        highs = [
            [rise, fall] for rise, fall in zip(rises, falls[1:] if initial else falls)
        ]
        lows = [
            [fall, rise]
            for fall, rise in zip(falls, rises[1:] if not initial else rises)
        ]
        widths = [(fall - rise) * 1e6 for rise, fall in highs]
        final = initial ^ (len(times) % 2)
        periods = [(b - a) * 1e6 for a, b in zip(rises, rises[1:])]
        rows.append(
            {
                "initial_level": initial,
                "final_level": final,
                "begin_s": begin,
                "end_s": end,
                "sample_rate_in_export": sample_rate,
                "edges_s": list(times),
                "complete_high_intervals_s": highs,
                "complete_low_intervals_s": lows,
                "highs_us": widths,
                "lows_us": [(b - a) * 1e6 for a, b in lows],
                "rise_periods_us": periods,
                "high_summary_us": describe(widths),
                "period_summary_us": describe(periods),
                "absolute_high_error_summary_us": describe(
                    [abs(h - target_high_us) for h in widths]
                ),
                "initial_boundary": {
                    "level": initial,
                    "begin_s": begin,
                    "end_s": times[0] if times else end,
                },
                "final_boundary": {
                    "level": final,
                    "begin_s": times[-1] if times else begin,
                    "end_s": end,
                },
                "quiet_low_tail_seconds": end - (times[-1] if times else begin)
                if final == 0
                else None,
            }
        )
    return {
        "binary_format_version": version,
        "raw_sha256": digest(path),
        "chunks": rows,
        "no_interval_trimming_or_filtering": True,
    }


def analyze(directory):
    directory = Path(directory)
    result = json.loads((directory / "results.json").read_text())
    backend = dict(RUNS).get(directory.name)
    require(
        backend == result.get("backend") and result.get("collection_success") is True,
        "Accepted predeclared capture required",
    )
    target = 10000.0 if backend == "original" else 10000.153
    channels = {
        str(channel): reconstruct(directory / f"digital_{channel}.bin", target)
        for channel in (2, 3)
    }
    main, peer = channels["2"]["chunks"], channels["3"]["chunks"]
    supported = (
        len(main) == len(peer) == 1
        and main[0]["initial_level"] == main[0]["final_level"] == 0
        and bool(main[0]["highs_us"])
        and main[0]["quiet_low_tail_seconds"] > 0.1
        and peer[0]["initial_level"] == peer[0]["final_level"] == 0
        and not peer[0]["edges_s"]
    )
    return {
        "schema_version": 1,
        "capture": directory.name,
        "backend": backend,
        "results_sha256": digest(directory / "results.json"),
        "target_high_us": target,
        "nominal_period_us": 20000.0,
        "channels": channels,
        "single_train_with_untouched_low_peer_supported": supported,
        "parity_pass": None,
        "electrical_and_pi_clocks_aligned": False,
        "scope": "Every complete interval and both boundaries retained. Finite idle real-Pin fixed50Hz descriptive evidence; no actuator, calibrated latency, whole-Blinka or quantitative parity verdict.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="operation", required=True)
    live = sub.add_parser("capture")
    live.add_argument("directory", type=Path)
    live.add_argument("--plan", type=Path, required=True)
    live.add_argument("--manifest", type=Path, required=True)
    offline = sub.add_parser("analyze")
    offline.add_argument("directory", type=Path)
    offline.add_argument("--output-name", default="half50-analysis.json")
    args = parser.parse_args(argv)
    if args.operation == "capture":
        return collect(args.directory, args.plan, args.manifest)
    require(
        Path(args.output_name).name == args.output_name
        and args.output_name not in ("", ".", ".."),
        "Exclusive plain output filename required",
    )
    write_new(args.directory / args.output_name, analyze(args.directory))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
