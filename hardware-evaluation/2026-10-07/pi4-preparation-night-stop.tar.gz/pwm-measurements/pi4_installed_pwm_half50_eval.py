"""Finite Pi4 real-board-Pin half50 experiment; lab only, no actuators.

The original class is the unchanged installed rpi_gpio_pwmout, not an old
pwmio dispatcher. Native is actual installed pwmio.PWMOut. Both public objects
and the genuine board.D18 are unwrapped. RPi.GPIO mutation entry points and the
native request factory are guarded/recorded, returning original objects.
RPi.GPIO mmap ownership is not proved by character-device line information.
An alarm cannot bound a stuck native call, SIGKILL, or an electrical fault.
The lab-owned LOW/read immediately before deinit is a sampled observation,
not continuous-low proof if cancellation interrupts an active half-duty worker.
"""

import argparse
import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import os
import platform
import re
import signal
import stat
import subprocess
import sys
import time
from contextlib import contextmanager, nullcontext
from pathlib import Path

HELPER = "pi4_installed_pwm_half50_eval.py"
ROOT_PATTERN = r"/tmp/blinka-pwm-pi4-real-pin\.[a-z0-9_]{8}"
PACKAGE = "adafruit_blinka_raspberry_pi_pwm"
PIN_MODULE = "adafruit_blinka.microcontroller.generic_linux.rpi_gpio_pin"
ORIGINAL_MODULE = "adafruit_blinka.microcontroller.generic_linux.rpi_gpio_pwmout"
MODE = "pi4-installed-real-pin-half50"
SEQUENCE_MARKER = "pi4-real-pin-fixed50-half-v1"
SEQUENCE = (
    ("initial_low", 0, 0.2),
    ("half50", 32768, 3.0),
    ("commanded_low", 0, 0.2),
    ("quiet_release", None, 0.2),
)
MAX_RUN_SECONDS = 12
KNOWN_VERSIONS = {
    "Adafruit-Blinka": "9.0.5.dev74+pwmeval.beb49bf",
    "Adafruit-Blinka-Raspberry-Pi-PWM": "0.0.1.dev0",
    "Adafruit-PlatformDetect": "3.89.1",
    "gpiod": "2.5.0",
    "packaging": "26.3",
    "RPi.GPIO": "0.7.1a4",
}
REQUIRED_SOURCES = {
    HELPER,
    "board.py",
    "board_imports.json",
    "pwmio.py",
    "RPi/GPIO/__init__.py",
    "RPi/_GPIO.so",
    PACKAGE + "/__init__.py",
    PACKAGE + "/_software.py",
    PACKAGE + "/_native.so",
    "gpiod/__init__.py",
    "gpiod/_ext.so",
    "adafruit_blinka/__init__.py",
    "adafruit_blinka/agnostic/__init__.py",
    "adafruit_blinka/importing.py",
    "adafruit_blinka/platform_dependencies.py",
    "adafruit_blinka/microcontroller/bcm2711/pin.py",
    "adafruit_blinka/board/raspberrypi/raspi_4b.py",
    PIN_MODULE.replace(".", "/") + ".py",
    ORIGINAL_MODULE.replace(".", "/") + ".py",
    "adafruit_platformdetect/__init__.py",
    "packaging/__init__.py",
}
MODULE_PREFIXES = (
    "RPi",
    "adafruit_blinka",
    "adafruit_platformdetect",
    "gpiod",
    "packaging",
    PACKAGE,
)


class BenchError(RuntimeError):
    """An explicit experiment gate or cleanup failure."""


def error_text(error):
    return f"{type(error).__name__}: {error}"


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise BenchError("Duplicate JSON key: " + key)
            result[key] = value
        return result

    return json.loads(Path(path).read_text(), object_pairs_hook=pairs)


def validate_manifest(manifest):
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
    ):
        raise BenchError("Require manifest schema1")
    root = manifest.get("remote_root")
    if not isinstance(root, str) or re.fullmatch(ROOT_PATTERN, root) is None:
        raise BenchError("Require fresh Pi4 real-pin root")
    if (
        manifest.get("model") != "Raspberry Pi 4 Model B Rev 1.4"
        or manifest.get("python_version") != "3.13.5"
        or manifest.get("kernel") != "6.18.50+rpt-rpi-v8"
        or not isinstance(manifest.get("boot_id"), str)
        or re.fullmatch(
            r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", manifest["boot_id"]
        )
        is None
    ):
        raise BenchError("Require declared observed Pi4 model/kernel/Python/boot")
    hashes, paths = manifest.get("source_sha256"), manifest.get("source_paths")
    if (
        not isinstance(hashes, dict)
        or not isinstance(paths, dict)
        or set(hashes) != set(paths)
        or not REQUIRED_SOURCES <= set(paths)
        or any(
            not isinstance(v, str) or re.fullmatch(r"[0-9a-f]{64}", v) is None
            for v in hashes.values()
        )
        or any(not isinstance(v, str) for v in paths.values())
        or len(set(paths.values())) != len(paths)
    ):
        raise BenchError("Require unique complete selected-source paths/SHA256")
    if manifest.get("distribution_versions") != KNOWN_VERSIONS:
        raise BenchError("Require declared private versions and exact distro RPi.GPIO")
    configs = manifest.get("boot_config_sha256")
    if (
        not isinstance(configs, dict)
        or set(configs) != {"/boot/firmware/config.txt", "/boot/config.txt"}
        or any(
            not isinstance(v, str) or re.fullmatch(r"[0-9a-f]{64}", v) is None
            for v in configs.values()
        )
    ):
        raise BenchError("Require both observed boot-config hashes")
    controller = manifest.get("controller")
    if controller != {
        "path": "/dev/gpiochip0",
        "name": "gpiochip0",
        "label": "pinctrl-bcm2711",
        "num_lines": 58,
        "device_number": "254:0",
        "of_node": "/sys/firmware/devicetree/base/soc/gpio@7e200000",
    }:
        raise BenchError("Require observed BCM2711 controller identity")
    if (
        manifest.get("sibling_pinctrl_stdout")
        != "23: ip    pd | lo // GPIO23 = input\n"
    ):
        raise BenchError("Require exact read-only inactive GPIO23 context")
    return Path(root)


def fresh_process(root, receipt):
    inherited = {
        k: v
        for k, v in os.environ.items()
        if k.startswith("BLINKA_") or k in ("PYTHONPATH", "PYTHONHOME")
    }
    receipt["inherited_environment"] = inherited
    loaded = [
        k
        for k in sys.modules
        if k in ("board", "pwmio")
        or any(k == p or k.startswith(p + ".") for p in MODULE_PREFIXES)
    ]
    if inherited or loaded:
        raise BenchError("Refuse inherited override or preimported selected module")
    if (
        sys.platform != "linux"
        or sys.implementation.name != "cpython"
        or not sys.flags.isolated
        or sys.executable != str(root / "venv/bin/python")
    ):
        raise BenchError("Require -I exact private Pi4 venv interpreter")
    if any(s is not None and s.isatty() for s in (sys.stdin, sys.stdout)):
        raise BenchError("Require non-TTY stdin/stdout; never offer runtime pip")
    receipt.update(
        python_executable=sys.executable,
        isolated_python=True,
        noninteractive_no_runtime_installs=True,
        runtime_flags={"short_slice": False, "shared": False},
    )


def inspect_sources(root, manifest, receipt):
    paths = {k: Path(v) for k, v in manifest["source_paths"].items()}
    for key, path in paths.items():
        if (
            not path.is_absolute()
            or path.resolve(strict=True) != path
            or not path.is_file()
        ):
            raise BenchError("Require regular non-symlink selected source: " + key)
        if key == HELPER:
            if path != root / HELPER or path != Path(__file__):
                raise BenchError("Executed helper origin mismatch")
        elif key.startswith("RPi/"):
            if path != Path("/usr/lib/python3/dist-packages") / key and not (
                key == "RPi/_GPIO.so"
                and path.parent == Path("/usr/lib/python3/dist-packages/RPi")
                and path.name.startswith("_GPIO.")
                and path.name.endswith(".so")
            ):
                raise BenchError("RPi.GPIO must be explicit exact distro reference")
        elif not path.is_relative_to(root / "venv"):
            raise BenchError("Selected private source outside fresh venv: " + key)
    actual = {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in paths.items()}
    receipt.update(
        source_paths={k: str(v) for k, v in paths.items()}, source_sha256=actual
    )
    if actual != manifest["source_sha256"]:
        raise BenchError("Selected-source bytes mismatch")
    for name, key in (
        ("board", "board.py"),
        ("pwmio", "pwmio.py"),
        (PACKAGE, PACKAGE + "/__init__.py"),
        ("gpiod", "gpiod/__init__.py"),
    ):
        spec = importlib.util.find_spec(name)
        if spec is None or spec.origin != str(paths[key]):
            raise BenchError("Actual selected top-level origin mismatch: " + name)
    versions, metadata_paths = {}, {}
    for name in KNOWN_VERSIONS:
        distribution = importlib.metadata.distribution(name)
        metadata_root = Path(distribution.locate_file("")).resolve(strict=True)
        permitted = (
            Path("/usr/lib/python3/dist-packages")
            if name == "RPi.GPIO"
            else root / "venv"
        )
        if not metadata_root.is_relative_to(permitted):
            raise BenchError("Wrong selected distribution origin: " + name)
        versions[name], metadata_paths[name] = distribution.version, str(metadata_root)
    receipt.update(
        distribution_versions=versions, distribution_metadata_roots=metadata_paths
    )
    if versions != manifest["distribution_versions"]:
        raise BenchError("Selected distribution version mismatch")
    return paths


def verify_origins(paths):
    allowed = {str(p) for p in paths.values()}
    for name, module in list(sys.modules.items()):
        if name in ("board", "pwmio") or any(
            name == p or name.startswith(p + ".") for p in MODULE_PREFIXES
        ):
            filename = getattr(module, "__file__", None)
            # RPi may be an actual namespace package; its child origins remain pinned.
            if name == "RPi" and filename is None:
                if list(module.__path__) != ["/usr/lib/python3/dist-packages/RPi"]:
                    raise BenchError("Wrong RPi namespace origin")
            elif filename not in allowed:
                raise BenchError("Loaded unpinned selected module: " + name)


def query(arguments):
    result = subprocess.run(
        arguments,
        capture_output=True,
        text=True,
        timeout=3,
        check=False,
        stdin=subprocess.DEVNULL,
    )
    return {
        "arguments": arguments,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


def text(path):
    return Path(path).read_bytes().rstrip(b"\0").decode().strip()


def inspect_platform(manifest, receipt):
    actual = {
        "model": text("/sys/firmware/devicetree/base/model"),
        "kernel": platform.release(),
        "python_version": platform.python_version(),
        "boot_id": text("/proc/sys/kernel/random/boot_id"),
    }
    if any(actual[k] != manifest[k] for k in actual):
        raise BenchError("Actual Pi4 model/kernel/Python/boot changed")
    configs = {
        k: hashlib.sha256(Path(k).read_bytes()).hexdigest()
        for k in manifest["boot_config_sha256"]
    }
    if configs != manifest["boot_config_sha256"]:
        raise BenchError("Boot configuration changed")
    temp = int(text("/sys/class/thermal/thermal_zone0/temp"))
    flags = query(["vcgencmd", "get_throttled"])
    if (
        not 0 < temp < 55000
        or flags["returncode"] != 0
        or flags["stdout"].strip() != "throttled=0x0"
    ):
        raise BenchError("Temperature/throttle preflight failed")
    if list(Path("/sys/class/pwm").glob("pwmchip*")):
        raise BenchError("Registered PWM provider forbidden")
    nodes = []
    for path in Path("/sys/firmware/devicetree/base").rglob("compatible"):
        compatible = path.read_bytes().rstrip(b"\0").decode().split("\0")
        if any("pwm" in item for item in compatible):
            status = (
                text(path.parent / "status")
                if (path.parent / "status").exists()
                else "okay"
            )
            nodes.append(
                {
                    "of_node": str(path.parent),
                    "compatible": compatible,
                    "status": status,
                }
            )
            if status != "disabled":
                raise BenchError("Live header/audio/PWM-gpio provider forbidden")
    if {row["of_node"] for row in nodes} != {
        "/sys/firmware/devicetree/base/soc/pwm@7e20c800",
        "/sys/firmware/devicetree/base/soc/pwm@7e20c000",
    }:
        raise BenchError("Unexpected live PWM device-tree topology")
    controller = manifest["controller"]
    device = Path(controller["path"]).stat()
    if (
        not stat.S_ISCHR(device.st_mode)
        or f"{os.major(device.st_rdev)}:{os.minor(device.st_rdev)}"
        != controller["device_number"]
        or str(
            (Path("/sys/bus/gpio/devices") / controller["name"] / "of_node").resolve(
                strict=True
            )
        )
        != controller["of_node"]
    ):
        raise BenchError("BCM2711 character-device/OF identity changed")
    actual.update(
        boot_config_sha256=configs,
        temperature_millic=temp,
        throttled=flags,
        live_pwm_nodes=nodes,
        registered_pwm_providers=[],
    )
    receipt["platform_preflight"] = actual
    inspect_pins(manifest, receipt, "platform_preflight")


def inspect_pins(manifest, receipt, boundary):
    rows = [query(["pinctrl", "get", str(gpio)]) for gpio in (18, 23)]
    receipt.setdefault("pin_boundaries", []).append(
        {"boundary": boundary, "queries": rows}
    )
    if (
        any(r["returncode"] != 0 for r in rows)
        or re.fullmatch(
            r"18: (?:ip|op)\s+\S+ \| lo // GPIO18 = (?:input|output)\n",
            rows[0]["stdout"],
        )
        is None
        or rows[1]["stdout"] != manifest["sibling_pinctrl_stdout"]
    ):
        raise BenchError(
            "GPIO18 must be GPIO/input-or-output LOW; GPIO23 unchanged INPUT/down/LOW"
        )
    receipt.setdefault("boundary_low_confirmations", {})[boundary] = True


def inspect_lines(library, manifest):
    expected = manifest["controller"]
    with library.Chip(expected["path"]) as chip:
        info = chip.get_info()
        actual = {"name": info.name, "label": info.label, "num_lines": info.num_lines}
        if actual != {k: expected[k] for k in actual}:
            raise BenchError("Opened controller metadata mismatch")
        lines = []
        for gpio in (18, 23):
            line = chip.get_line_info(gpio)
            row = {
                "offset": line.offset,
                "name": line.name,
                "used": line.used,
                "consumer": line.consumer,
                "direction": line.direction.name,
            }
            if (
                line.offset != gpio
                or line.name != "GPIO" + str(gpio)
                or type(line.used) is not bool
                or line.used
                or line.consumer not in (None, "")
            ):
                raise BenchError(
                    "Require fresh unclaimed GPIO18/23; never borrow a request"
                )
            lines.append(row)
    return {
        "chip": actual,
        "lines": lines,
        "read_only_chip_closed": True,
        "rpi_gpio_mmap_exclusivity_not_proved": True,
    }


class SignalGuard:
    def __init__(self):
        self.signals = (signal.SIGALRM, signal.SIGTERM, signal.SIGINT)
        self.previous, self.previous_timer = {}, None

    def __enter__(self):
        self.previous_timer = signal.getitimer(signal.ITIMER_REAL)
        if self.previous_timer != (0.0, 0.0):
            raise BenchError("Refuse inherited alarm")
        for sig in self.signals:
            self.previous[sig] = signal.signal(sig, self.interrupt)
        signal.setitimer(signal.ITIMER_REAL, MAX_RUN_SECONDS)
        return self

    def interrupt(self, sig, _frame):
        raise BenchError("Bounded run interrupted by signal " + str(sig))

    @contextmanager
    def atomic(self):
        old = signal.pthread_sigmask(signal.SIG_BLOCK, self.signals)
        try:
            yield
        finally:
            signal.pthread_sigmask(signal.SIG_SETMASK, old)

    @contextmanager
    def cleanup(self):
        # Cancellation is disabled while performing only already-owned cleanup.
        signal.setitimer(signal.ITIMER_REAL, 0)
        with self.atomic():
            yield

    def __exit__(self, *_args):
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, previous in self.previous.items():
            signal.signal(sig, previous)


def record(receipt, name, operation, scope, arguments=None):
    event = {
        "operation": name,
        "scope": scope,
        "arguments": arguments,
        "begin_ns": time.monotonic_ns(),
    }
    try:
        value = operation()
        event["status"] = "ok"
        return value
    except BaseException as error:
        event.update(status="error", error=error_text(error))
        raise
    finally:
        event["end_ns"] = time.monotonic_ns()
        receipt["events"].append(event)


class GPIOHooks:
    """Only setup/output/cleanup/PWM for target18 during explicit original scope."""

    def __init__(self, library, receipt, guard=None):
        self.library, self.receipt = library, receipt
        self.guard = guard
        self.scope = "imports"
        self.setup_attempted = self.setup_succeeded = self.cleanup_succeeded = False
        self.originals = {}

    def wrap(self, name):
        def call(*args, **kwargs):
            row = {
                "operation": "GPIO." + name,
                "scope": self.scope,
                "arguments": {"args": list(args), "kwargs": kwargs},
                "begin_ns": time.monotonic_ns(),
                "attempted": True,
                "success": False,
                "permitted": False,
            }
            try:
                permitted = False
                if name == "setmode":
                    permitted = args == (self.library.BCM,) and not kwargs
                elif name == "setwarnings":
                    permitted = args == (False,) and not kwargs
                elif self.scope != "imports" and self.scope.startswith("original:"):
                    permitted = bool(args) and type(args[0]) is int and args[0] == 18
                    if name == "setup":
                        permitted = (
                            permitted and args == (18, self.library.OUT) and not kwargs
                        )
                    elif name == "output":
                        permitted = (
                            permitted and args == (18, self.library.LOW) and not kwargs
                        )
                    elif name == "cleanup":
                        permitted = (
                            permitted
                            and args == (18,)
                            and not kwargs
                            and self.setup_attempted
                        )
                    elif name == "PWM":
                        permitted = permitted and args == (18, 50) and not kwargs
                    else:
                        permitted = False
                row["permitted"] = permitted
                if not permitted:
                    raise BenchError("Forbidden scoped GPIO mutation: " + name)
                if name == "setup":
                    self.setup_attempted = True
                result = self.originals[name](*args, **kwargs)
                row["success"] = True
                if name == "setup":
                    self.setup_succeeded = True
                if name == "cleanup":
                    self.cleanup_succeeded = True
                return result
            except BaseException as error:
                row["error"] = error_text(error)
                raise
            finally:
                row["end_ns"] = time.monotonic_ns()
                self.receipt["gpio_calls"].append(row)

        return call

    @contextmanager
    def installed(self):
        names = (
            "setup",
            "output",
            "cleanup",
            "PWM",
            "setmode",
            "setwarnings",
            "add_event_detect",
            "remove_event_detect",
            "add_event_callback",
        )
        self.originals = {
            name: getattr(self.library, name)
            for name in names
            if hasattr(self.library, name)
        }
        try:
            for name in self.originals:
                setattr(self.library, name, self.wrap(name))
            yield self
        finally:
            with self.guard.cleanup() if self.guard is not None else nullcontext():
                for name, value in self.originals.items():
                    setattr(self.library, name, value)
                self.receipt["gpio_hooks_restored"] = all(
                    getattr(self.library, k) is v for k, v in self.originals.items()
                )


def installed_api(paths, receipt):
    board = importlib.import_module("board")
    pwmio = importlib.import_module("pwmio")
    native = importlib.import_module(PACKAGE)
    original = importlib.import_module(ORIGINAL_MODULE)
    pin = importlib.import_module(PIN_MODULE)
    bcm = importlib.import_module("adafruit_blinka.microcontroller.bcm2711.pin")
    raspi = importlib.import_module("adafruit_blinka.board.raspberrypi.raspi_4b")
    agnostic = importlib.import_module("adafruit_blinka.agnostic")
    dependencies = importlib.import_module("adafruit_blinka.platform_dependencies")
    verify_origins(paths)
    if (
        agnostic.board_id != "RASPBERRY_PI_4B"
        or agnostic.chip_id != "BCM2XXX"
        or not agnostic.detector.board.any_raspberry_pi
        or agnostic.detector.board.any_raspberry_pi_5_board
        or pwmio.PWMOut is not native.PWMOut
        or original.PWMOut is native.PWMOut
    ):
        raise BenchError("Actual installed Pi4 dispatch/class identity mismatch")
    for gpio in (18, 23):
        obj = getattr(board, "D" + str(gpio))
        if (
            type(obj) is not pin.Pin
            or type(obj.id) is not int
            or obj.id != gpio
            or obj is not getattr(bcm, "D" + str(gpio))
            or obj is not getattr(raspi, "D" + str(gpio))
        ):
            raise BenchError("Actual unchanged real board Pin/alias identity mismatch")
    missing = dependencies.get_missing_platform_dependencies(agnostic.detector)
    if missing not in ([], ["rpi_ws281x>=4.0.0"]):
        raise BenchError("Unexpected missing Pi4 platform dependency: " + repr(missing))
    receipt["installed_dispatch"] = {
        "real_board_used": True,
        "real_pwmio_used": True,
        "virtual_pwmio_export_used": False,
        "native_pwmio_identity_verified": True,
        "original_reference": ORIGINAL_MODULE + ".PWMOut",
        "unwrapped_public_pwm_objects": True,
        "board_id": agnostic.board_id,
        "chip_id": agnostic.chip_id,
        "pin_class_module": pin.Pin.__module__,
        "target_pin_attribute": "D18",
        "target_pin_id": 18,
        "inactive_context_pin_id": 23,
        "missing_platform_dependencies": missing,
        "missing_neopixel_dependency_not_imported_or_installed": missing
        == ["rpi_ws281x>=4.0.0"],
    }
    return board, pwmio.PWMOut, original.PWMOut


class NativeRequestHooks:
    def __init__(self, library, manifest, receipt, backend, guard=None):
        self.library, self.manifest, self.receipt, self.backend = (
            library,
            manifest,
            receipt,
            backend,
        )
        self.request, self.original = None, library.request_lines
        self.guard = guard
        self.scope = "imports"

    @contextmanager
    def installed(self):
        def request(path, *, consumer, config, **kwargs):
            def call():
                if (
                    self.backend != "native"
                    or self.scope != "native:constructor"
                    or self.request is not None
                    or path != self.manifest["controller"]["path"]
                    or consumer != "adafruit-blinka-pwm"
                    or list(config) != [18]
                    or kwargs
                    or config[18].direction != self.library.line.Direction.OUTPUT
                    or config[18].output_value != self.library.line.Value.INACTIVE
                ):
                    raise BenchError(
                        "Require fresh native private initial-low GPIO18-only request"
                    )
                result = self.original(path, consumer=consumer, config=config)
                self.request = result
                if (
                    list(result.offsets) != [18]
                    or result.chip_name != self.manifest["controller"]["name"]
                ):
                    raise BenchError("Actual native request identity mismatch")
                return result

            return record(
                self.receipt,
                "gpiod.request_lines",
                call,
                self.scope,
                {"path": path, "consumer": consumer, "offsets": list(config)},
            )

        self.library.request_lines = request
        try:
            yield self
        finally:
            with self.guard.cleanup() if self.guard is not None else nullcontext():
                self.library.request_lines = self.original
                self.receipt["native_request_hook_restored"] = (
                    self.library.request_lines is self.original
                )


def cleanup_output(pwm, backend, library, hooks, requests, guard, receipt):
    def attempt(name, operation, scope):
        try:
            return record(receipt, name, operation, scope)
        except BaseException as error:  # noqa: BLE001 - retain cleanup/cancellation evidence
            receipt["cleanup_errors"].append(name + ": " + error_text(error))
            return None

    with guard.cleanup():
        hooks.scope = backend + ":public_deinit"
        request = requests.request
        if backend == "native" and request is not None:
            engine = getattr(pwm, "_engine", None)
            if engine is not None and getattr(engine, "_request", None) is request:
                attempt(
                    "owned_request.set_value(low)",
                    lambda: request.set_value(18, library.line.Value.INACTIVE),
                    "native:lab_owned_low",
                )
                level = attempt(
                    "owned_request.get_value",
                    lambda: request.get_value(18),
                    "native:lab_owned_read",
                )
                receipt["native_private_low_confirmed"] = (
                    level == library.line.Value.INACTIVE
                )
        if pwm is not None:
            attempt("PWMOut.deinit", pwm.deinit, backend + ":public_deinit")
        if (
            backend == "original"
            and hooks.setup_attempted
            and not hooks.cleanup_succeeded
        ):
            hooks.scope = "original:lab_failed_init_cleanup"
            attempt(
                "GPIO.output(low)",
                lambda: hooks.library.output(18, hooks.library.LOW),
                hooks.scope,
            )
            attempt("GPIO.cleanup(18)", lambda: hooks.library.cleanup(18), hooks.scope)
            receipt["original_lab_cleanup_basis"] = (
                "target18 setup attempted; failed/partial initialization or public cleanup"
            )
        if backend == "native" and request is not None:
            # A partially failed SoftwarePWM constructor already releases its own
            # request. Only release here if this exact returned request remains live.
            try:
                live = request.fd is not None
            except (OSError, RuntimeError, ValueError):
                live = False
            if live:
                attempt(
                    "owned_request.set_value(low)",
                    lambda: request.set_value(18, library.line.Value.INACTIVE),
                    "native:lab_failed_init_cleanup",
                )
                attempt(
                    "owned_request.release",
                    request.release,
                    "native:lab_failed_init_cleanup",
                )
            try:
                _ = request.fd
                receipt["native_request_released"] = False
            except (OSError, RuntimeError, ValueError):
                receipt["native_request_released"] = True


def run_protocol(
    board,
    pwm_class,
    backend,
    library,
    manifest,
    hooks,
    requests,
    guard,
    receipt,
    paths=None,
):
    pwm = None
    pin, pin_state = board.D18, dict(vars(board.D18))
    try:
        hooks.scope = backend + ":constructor"
        requests.scope = hooks.scope
        with guard.atomic():
            pwm = pwm_class.__new__(pwm_class)
            record(
                receipt,
                "PWMOut.__init__",
                lambda: pwm.__init__(
                    pin, frequency=50, duty_cycle=0, variable_frequency=False
                ),
                hooks.scope,
                {
                    "pin_attribute": "board.D18",
                    "pin_id": 18,
                    "frequency": 50,
                    "duty_u16": 0,
                    "variable_frequency": False,
                },
            )
        if paths is not None:
            verify_origins(paths)
        if backend == "native":
            request = requests.request
            if (
                request is None
                or getattr(getattr(pwm, "_engine", None), "_request", None)
                is not request
            ):
                raise BenchError(
                    "Public native output must retain exactly the private request"
                )
            receipt["native_initial_low_confirmed"] = (
                record(
                    receipt,
                    "owned_request.get_value",
                    lambda: request.get_value(18),
                    "native:initial_low",
                )
                == library.line.Value.INACTIVE
            )
            if not receipt["native_initial_low_confirmed"]:
                raise BenchError("Initial native request not LOW")
        for name, duty, duration in SEQUENCE[:3]:
            phase = {
                "name": name,
                "duty_u16": duty,
                "duration_seconds": duration,
                "begin_ns": time.monotonic_ns(),
            }
            receipt["phases"].append(phase)
            hooks.scope = backend + ":" + name
            if name != "initial_low":
                record(
                    receipt,
                    "PWMOut.duty_cycle",
                    lambda duty=duty: setattr(pwm, "duty_cycle", duty),
                    hooks.scope,
                    {"duty_u16": duty},
                )
            if (
                board.D18 is not pin
                or vars(pin) != pin_state
                or pwm.frequency != 50
                or pwm.duty_cycle != duty
            ):
                raise BenchError("Real Pin/fixed-frequency/duty readback changed")
            phase["api_readback"] = {
                "frequency": pwm.frequency,
                "duty_u16": pwm.duty_cycle,
                "pin_id": pin.id,
            }
            phase["api_readback_ns"] = time.monotonic_ns()
            phase["wait_begin_ns"] = time.monotonic_ns()
            time.sleep(duration)
            phase["wait_end_ns"] = time.monotonic_ns()
            if duty == 0:
                inspect_pins(manifest, receipt, name)
                phase["settled_low_confirmation_ns"] = time.monotonic_ns()
            phase["end_ns"] = time.monotonic_ns()
    finally:
        cleanup_output(pwm, backend, library, hooks, requests, guard, receipt)
    receipt["free_lines_after_public_and_lab_cleanup"] = inspect_lines(
        library, manifest
    )
    inspect_pins(manifest, receipt, "release")
    quiet = {
        "name": "quiet_release",
        "duty_u16": None,
        "duration_seconds": 0.2,
        "begin_ns": time.monotonic_ns(),
    }
    receipt["phases"].append(quiet)
    time.sleep(0.2)
    quiet["end_ns"] = time.monotonic_ns()
    inspect_pins(manifest, receipt, "quiet_release_end")


def experiment(manifest_path, backend, inspect_only=False):
    receipt = {
        "schema_version": 1,
        "mode": MODE,
        "sequence_marker": SEQUENCE_MARKER,
        "backend": backend,
        "pid": os.getpid(),
        "begin_ns": time.monotonic_ns(),
        "events": [],
        "gpio_calls": [],
        "phases": [],
        "cleanup_errors": [],
        "primary_error": None,
        "success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "inspect_only": inspect_only,
        "scope": "Installed real Pi4 Pin/fixed half50 only; no scheduler-causality, parity, safety, NeoPixel or general compatibility verdict",
    }
    try:
        if backend not in ("original", "native"):
            raise BenchError("Only original/native are authorized")
        path = Path(manifest_path)
        manifest = read_json(path)
        root = validate_manifest(manifest)
        if (
            path.parent != root
            or path.resolve(strict=True) != path
            or Path(__file__) != root / HELPER
        ):
            raise BenchError("Manifest/helper must share fresh regular isolated root")
        receipt["manifest_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        fresh_process(root, receipt)
        paths = inspect_sources(root, manifest, receipt)
        with SignalGuard() as guard:
            inspect_platform(manifest, receipt)
            library = importlib.import_module("gpiod")
            receipt["free_lines_preimport"] = inspect_lines(library, manifest)
            gpio = importlib.import_module("RPi.GPIO")
            verify_origins(paths)
            hooks, requests = (
                GPIOHooks(gpio, receipt, guard),
                NativeRequestHooks(library, manifest, receipt, backend, guard),
            )
            with hooks.installed(), requests.installed():
                board, native_class, original_class = installed_api(paths, receipt)
                receipt["free_lines_postimport"] = inspect_lines(library, manifest)
                inspect_pins(manifest, receipt, "postimport")
                if not inspect_only:
                    run_protocol(
                        board,
                        native_class if backend == "native" else original_class,
                        backend,
                        library,
                        manifest,
                        hooks,
                        requests,
                        guard,
                        receipt,
                        paths=paths,
                    )
                verify_origins(paths)
            receipt["guarded_import_only_no_gpio_construction"] = (
                inspect_only and requests.request is None and not hooks.setup_attempted
            )
            receipt["bounded_python_run_confirmed"] = (
                time.monotonic_ns() - receipt["begin_ns"]
            ) < MAX_RUN_SECONDS * 1_000_000_000
            complete = len(receipt["phases"]) == 4 and all(
                type(p.get("begin_ns")) is int
                and type(p.get("end_ns")) is int
                and p["end_ns"] >= p["begin_ns"]
                for p in receipt["phases"]
            )
            native_low = backend != "native" or (
                receipt.get("native_initial_low_confirmed") is True
                and receipt.get("native_private_low_confirmed") is True
                and receipt.get("native_request_released") is True
            )
            boundary_low = all(
                receipt.get("boundary_low_confirmations", {}).get(name) is True
                for name in (
                    "initial_low",
                    "commanded_low",
                    "release",
                    "quiet_release_end",
                )
            )
            receipt["success"] = (
                receipt["primary_error"] is None
                and not receipt["cleanup_errors"]
                and receipt.get("gpio_hooks_restored") is True
                and receipt.get("native_request_hook_restored") is True
                and receipt["bounded_python_run_confirmed"]
                and (
                    receipt["guarded_import_only_no_gpio_construction"]
                    if inspect_only
                    else complete and native_low and boundary_low
                )
            )
    except BaseException as error:  # noqa: BLE001 - finite receipt includes signal/interrupt failures
        receipt["primary_error"] = error_text(error)
    receipt["end_ns"] = time.monotonic_ns()
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--backend", choices=("original", "native"), required=True)
    parser.add_argument(
        "--inspect",
        action="store_true",
        help="Same guarded sources/platform/import gates; no PWM construction or GPIO setup/write/cleanup",
    )
    args = parser.parse_args()
    receipt = experiment(args.manifest, args.backend, inspect_only=args.inspect)
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
