"""Hardware-free real Blinka Pin/PWM Python sources with recording-only engines.

No actual GPIO, C extension, SSH, subprocess, Saleae or network is used. These
are source-level protocol/guard tests, not installed ARM64 wheel evidence.
"""

import importlib
import shutil
import signal
import sys
from contextlib import contextmanager
from enum import Enum
from pathlib import Path
from types import SimpleNamespace

import pytest

import pi4_installed_pwm_half50_eval as bench


class Guard:
    def __enter__(self):
        return self

    def __exit__(self, *_args):
        pass

    @contextmanager
    def atomic(self):
        yield

    cleanup = atomic


def receipt():
    return {"events": [], "gpio_calls": [], "phases": [], "cleanup_errors": []}


def declared_manifest():
    return {
        "schema_version": 1,
        "remote_root": "/tmp/blinka-pwm-pi4-real-pin.abc12345",
        "model": "Raspberry Pi 4 Model B Rev 1.4",
        "kernel": "6.18.50+rpt-rpi-v8",
        "python_version": "3.13.5",
        "boot_id": "5d3cf2af-f7f0-4199-a1d1-25958db13921",
        "controller": {
            "path": "/dev/gpiochip0",
            "name": "gpiochip0",
            "label": "pinctrl-bcm2711",
            "num_lines": 58,
            "device_number": "254:0",
            "of_node": "/sys/firmware/devicetree/base/soc/gpio@7e200000",
        },
        "distribution_versions": dict(bench.KNOWN_VERSIONS),
        "boot_config_sha256": {
            "/boot/firmware/config.txt": "a" * 64,
            "/boot/config.txt": "b" * 64,
        },
        "sibling_pinctrl_stdout": "23: ip    pd | lo // GPIO23 = input\n",
        "source_paths": {key: "/selected/" + key for key in bench.REQUIRED_SOURCES},
        "source_sha256": {key: "c" * 64 for key in bench.REQUIRED_SOURCES},
    }


@pytest.fixture
def environment(monkeypatch, tmp_path):
    source = Path(__file__).parent.parent / "Adafruit_Blinka/src"
    installed = tmp_path / "installed"
    installed.mkdir()
    shutil.copytree(source / "adafruit_blinka", installed / "adafruit_blinka")
    for name in ("board.py", "board_imports.json", "pwmio.py"):
        shutil.copyfile(source / name, installed / name)
    patch = (
        Path(__file__).parent.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/docs/blinka-integration.patch"
    ).read_text()
    old = "\n".join(
        line[1:]
        for line in patch.splitlines()
        if line.startswith("-") and not line.startswith("---")
    )
    new = "\n".join(
        line[1:]
        for line in patch.splitlines()
        if line.startswith("+") and not line.startswith("+++")
    )
    text = (installed / "pwmio.py").read_text()
    assert text.count(old) == 1
    (installed / "pwmio.py").write_text(text.replace(old, new))
    native_source = (
        Path(__file__).parent.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src"
        / bench.PACKAGE
    )
    shutil.copytree(native_source, installed / bench.PACKAGE)
    detector_path = installed / "adafruit_platformdetect"
    (detector_path / "constants").mkdir(parents=True)
    (detector_path / "__init__.py").write_text(
        "from _pi4_recording import detector\ndef Detector(): return detector\n"
    )
    (detector_path / "constants/__init__.py").write_text("")
    (detector_path / "constants/boards.py").write_text(
        "def __getattr__(name): return name\n"
    )

    class Board:
        id, any_raspberry_pi, any_raspberry_pi_5_board = "RASPBERRY_PI_4B", True, False
        any_raspberry_pi_4_board = True

        def __getattr__(self, _name):
            return False

    state = SimpleNamespace(
        detector=SimpleNamespace(board=Board(), chip=SimpleNamespace(id="BCM2XXX")),
        calls=[],
        levels={18: 0, 23: 0},
        claimed=False,
        requests=[],
        sleeps=[],
        fail=None,
        queued_low=False,
        pending_low=False,
    )

    def change_level(duty):
        if duty == 0 and state.queued_low and state.levels[18] == 1:
            state.pending_low = True
        else:
            state.levels[18] = 0 if duty == 0 else 1

    class PWM:
        def __init__(self, gpio, frequency):
            assert gpio == 18 and frequency == 50
            state.calls.append(("PWM", gpio, frequency))

        def ChangeFrequency(self, value):
            state.calls.append(("ChangeFrequency", value))

        def ChangeDutyCycle(self, value):
            state.calls.append(("ChangeDutyCycle", value))
            if state.fail == "duty" and value == 50:
                raise OSError("injected duty")
            change_level(value)

        def start(self, value):
            state.calls.append(("start", value))

        def stop(self):
            state.calls.append(("stop",))
            state.levels[18] = 0

    def setup(gpio, direction):
        state.calls.append(("setup", gpio, direction))
        if state.fail == "setup":
            raise OSError("injected partial setup")

    def cleanup(gpio):
        assert gpio == 18
        state.calls.append(("cleanup", gpio))
        state.levels[18] = 0

    def factory(gpio, frequency):
        if state.fail == "factory":
            raise OSError("injected PWM factory")
        return PWM(gpio, frequency)

    gpio = SimpleNamespace(
        BCM=11,
        OUT=0,
        IN=1,
        LOW=0,
        HIGH=1,
        PUD_OFF=0,
        PUD_UP=1,
        PUD_DOWN=2,
        setup=setup,
        output=lambda pin, value: state.calls.append(("output", pin, value)),
        cleanup=cleanup,
        PWM=factory,
        input=lambda pin: state.levels[pin],
        setmode=lambda value: state.calls.append(("setmode", value)),
        setwarnings=lambda value: state.calls.append(("setwarnings", value)),
        add_event_detect=lambda *args: pytest.fail("unguarded event mutation"),
    )

    class Value(Enum):
        INACTIVE = 0
        ACTIVE = 1

    class Direction(Enum):
        INPUT = 1
        OUTPUT = 2

    class Request:
        chip_name, offsets = "gpiochip0", [18]

        def __init__(self):
            self.released = False
            state.claimed = True

        @property
        def fd(self):
            if self.released:
                raise RuntimeError("released")
            return 321

        def set_value(self, gpio, value):
            assert not self.released and gpio == 18
            state.calls.append(("set_value", gpio, value.value))
            state.levels[18] = value.value

        def get_value(self, gpio):
            assert not self.released and gpio == 18
            return Value(state.levels[18])

        def release(self):
            assert not self.released
            self.released, state.claimed = True, False
            state.calls.append(("release",))

    def request_lines(path, **kwargs):
        assert path == "/dev/gpiochip0" and list(kwargs["config"]) == [18]
        result = Request()
        state.requests.append(result)
        return result

    library = SimpleNamespace(
        request_lines=request_lines,
        line=SimpleNamespace(Direction=Direction, Value=Value),
    )
    for name in list(sys.modules):
        if name in ("board", "pwmio") or any(
            name == p or name.startswith(p + ".")
            for p in bench.MODULE_PREFIXES
            if p != "packaging"
        ):
            monkeypatch.delitem(sys.modules, name, raising=False)
    monkeypatch.setitem(sys.modules, "_pi4_recording", state)
    monkeypatch.setitem(sys.modules, "RPi", SimpleNamespace(GPIO=gpio))
    monkeypatch.setitem(sys.modules, "RPi.GPIO", gpio)
    monkeypatch.syspath_prepend(str(installed))
    native = importlib.import_module(bench.PACKAGE)

    class Engine:
        def __init__(self, pin, frequency, duty):
            assert (
                type(pin).__module__ == bench.PIN_MODULE
                and pin.id == 18
                and frequency == 50
                and duty == 0
            )
            self._request = library.request_lines(
                "/dev/gpiochip0",
                consumer="adafruit-blinka-pwm",
                config={
                    18: SimpleNamespace(
                        direction=Direction.OUTPUT, output_value=Value.INACTIVE
                    )
                },
            )
            if state.fail == "native-start":
                self._request.release()
                self._request = None
                raise OSError("injected native start")

        def check(self):
            assert self._request is not None

        def configure(self, frequency, duty):
            state.calls.append(("configure", frequency, duty))
            change_level(duty)

        def close(self):
            state.calls.append(("native_stop",))
            self._request.set_value(18, Value.INACTIVE)
            self._request.release()
            self._request = None

    monkeypatch.setattr(native, "SoftwarePWM", Engine)
    monkeypatch.setattr(bench, "verify_origins", lambda _paths: None)
    monkeypatch.setattr(
        bench, "inspect_lines", lambda *_args: {"claimed": state.claimed}
    )
    monkeypatch.setattr(bench, "inspect_pins", lambda *_args: None)

    def sleep(duration):
        state.sleeps.append(duration)
        if state.pending_low:
            state.levels[18], state.pending_low = 0, False

    monkeypatch.setattr(bench.time, "sleep", sleep)
    dependencies = importlib.import_module("adafruit_blinka.platform_dependencies")
    state.actual_install_function = dependencies.install_missing_platform_dependencies
    monkeypatch.setattr(
        dependencies,
        "get_missing_platform_dependencies",
        lambda _detector, *_args: ["rpi_ws281x>=4.0.0"],
    )
    monkeypatch.setattr(
        dependencies, "install_missing_platform_dependencies", lambda _detector: False
    )
    yield state, gpio, library, native
    for name in list(sys.modules):
        if name in ("board", "pwmio") or any(
            name == p or name.startswith(p + ".")
            for p in bench.MODULE_PREFIXES
            if p != "packaging"
        ):
            monkeypatch.delitem(sys.modules, name, raising=False)


def run(environment, backend):
    _state, gpio, library, _native = environment
    result = receipt()
    hooks = bench.GPIOHooks(gpio, result)
    requests = bench.NativeRequestHooks(library, declared_manifest(), result, backend)
    with hooks.installed(), requests.installed():
        board, native, original = bench.installed_api({}, result)
        bench.run_protocol(
            board,
            native if backend == "native" else original,
            backend,
            library,
            declared_manifest(),
            hooks,
            requests,
            Guard(),
            result,
        )
    return result


@pytest.mark.parametrize("backend", ["original", "native"])
def test_actual_source_real_board_pin_public_classes_and_complete_protocol(
    environment, backend
):
    state, _gpio, _library, native = environment
    result = run(environment, backend)
    assert sys.modules["pwmio"].PWMOut is native.PWMOut
    assert type(sys.modules["board"].D18).__module__ == bench.PIN_MODULE
    assert [p["name"] for p in result["phases"]] == [p[0] for p in bench.SEQUENCE]
    assert state.sleeps == [0.2, 3.0, 0.2, 0.2]
    assert not result["cleanup_errors"] and not state.claimed
    assert result["gpio_hooks_restored"] and result["native_request_hook_restored"]
    assert result["installed_dispatch"]["missing_platform_dependencies"] == [
        "rpi_ws281x>=4.0.0"
    ]
    assert not any(
        call[0] in ("setup", "output", "cleanup", "PWM") and call[1] != 18
        for call in state.calls
    )
    if backend == "original":
        assert ("ChangeDutyCycle", 50) in state.calls
        assert ("stop",) in state.calls and ("cleanup", 18) in state.calls
        assert not state.requests
        assert "original_lab_cleanup_basis" not in result
        assert [
            r["scope"] for r in result["gpio_calls"] if r["operation"] == "GPIO.cleanup"
        ] == ["original:public_deinit"]
    else:
        assert (
            result["native_initial_low_confirmed"]
            and result["native_private_low_confirmed"]
            and result["native_request_released"]
        )
        assert ("configure", 50, 32768) in state.calls
        assert not any(
            row["operation"]
            in ("GPIO.setup", "GPIO.output", "GPIO.cleanup", "GPIO.PWM")
            for row in result["gpio_calls"]
        )


@pytest.mark.parametrize("backend", ["original", "native"])
def test_queued_zero_finishes_outgoing_pulse_before_settled_low_check(
    environment, monkeypatch, backend
):
    state, _gpio, _library, _native = environment
    state.queued_low = True
    checked = []

    def low_check(_manifest, result, name):
        assert state.levels[18] == 0, (
            "Physical low must be checked only after queued update settles"
        )
        if name == "commanded_low":
            assert state.sleeps == [0.2, 3.0, 0.2]
        checked.append(name)
        result.setdefault("boundary_low_confirmations", {})[name] = True

    monkeypatch.setattr(bench, "inspect_pins", low_check)
    result = run(environment, backend)
    phase = result["phases"][2]
    assert (
        phase["api_readback_ns"]
        <= phase["wait_begin_ns"]
        <= phase["wait_end_ns"]
        <= phase["settled_low_confirmation_ns"]
        <= phase["end_ns"]
    )
    assert checked == ["initial_low", "commanded_low", "release", "quiet_release_end"]


@pytest.mark.parametrize("failure", ["setup", "factory", "duty"])
def test_original_failed_start_or_duty_cleanup_only_target18(environment, failure):
    state, _gpio, _library, _native = environment
    state.fail = failure
    with pytest.raises(OSError, match="injected"):
        run(environment, "original")
    assert ("cleanup", 18) in state.calls
    assert not any(
        call[0] == "cleanup" and call != ("cleanup", 18) for call in state.calls
    )


def test_native_failed_start_already_released_not_borrowed_or_released_twice(
    environment,
):
    state, _gpio, _library, _native = environment
    state.fail = "native-start"
    with pytest.raises(OSError, match="native start"):
        run(environment, "native")
    assert not state.claimed and sum(call == ("release",) for call in state.calls) == 1


@pytest.mark.parametrize(
    "operation,args",
    [("setup", (18, 0)), ("output", (18, 0)), ("cleanup", (18,)), ("PWM", (18, 50))],
)
def test_import_phase_mutations_rejected_and_restored(environment, operation, args):
    state, gpio, _library, _native = environment
    original = getattr(gpio, operation)
    result = receipt()
    with (
        bench.GPIOHooks(gpio, result).installed(),
        pytest.raises(bench.BenchError, match="Forbidden"),
    ):
        getattr(gpio, operation)(*args)
    assert getattr(gpio, operation) is original
    assert (
        result["gpio_calls"][-1]["attempted"]
        and not result["gpio_calls"][-1]["success"]
    )
    assert not any(call[0] == operation for call in state.calls)


@pytest.mark.parametrize(
    "operation,args",
    [
        ("setup", (23, 0)),
        ("output", (23, 0)),
        ("cleanup", ()),
        ("cleanup", ([18],)),
        ("cleanup", (23,)),
        ("PWM", (23, 50)),
        ("setup", (18, 1)),
        ("output", (18, 1)),
        ("add_event_detect", (18,)),
    ],
)
def test_foreign_global_high_or_other_mutation_rejected(environment, operation, args):
    _state, gpio, _library, _native = environment
    result = receipt()
    with bench.GPIOHooks(gpio, result).installed() as hooks:
        hooks.scope, hooks.setup_attempted = "original:constructor", True
        with pytest.raises(bench.BenchError, match="Forbidden"):
            getattr(gpio, operation)(*args)
    assert not result["gpio_calls"][-1]["permitted"]


@pytest.mark.parametrize(
    "field,value",
    [
        ("schema_version", True),
        ("remote_root", "/tmp/wrong.abc12345"),
        ("boot_id", ""),
        ("model", "Raspberry Pi 5 Model B Rev 1.0"),
        ("kernel", "other"),
        ("python_version", "3.14.0"),
        ("sibling_pinctrl_stdout", "23 output high"),
        ("distribution_versions", {}),
    ],
)
def test_manifest_gate_rejects(field, value):
    manifest = declared_manifest()
    manifest[field] = value
    with pytest.raises(bench.BenchError):
        bench.validate_manifest(manifest)


def test_manifest_valid_and_selected_source_completeness():
    manifest = declared_manifest()
    assert str(bench.validate_manifest(manifest)) == manifest["remote_root"]
    del manifest["source_paths"]["pwmio.py"]
    with pytest.raises(bench.BenchError, match="selected-source"):
        bench.validate_manifest(manifest)


def test_duplicate_json_keys_fail(tmp_path):
    path = tmp_path / "manifest.json"
    path.write_text('{"schema_version":1,"schema_version":1}')
    with pytest.raises(bench.BenchError, match="Duplicate"):
        bench.read_json(path)


def test_controller_and_configs_fail_closed():
    for field in ("controller", "boot_config_sha256"):
        manifest = declared_manifest()
        manifest[field] = {}
        with pytest.raises(bench.BenchError):
            bench.validate_manifest(manifest)


def test_noninteractive_and_isolated_fresh_process(monkeypatch):
    for name in list(sys.modules):
        if name in ("board", "pwmio") or any(
            name == p or name.startswith(p + ".") for p in bench.MODULE_PREFIXES
        ):
            monkeypatch.delitem(sys.modules, name, raising=False)
    for name in list(bench.os.environ):
        if name.startswith("BLINKA_") or name in ("PYTHONPATH", "PYTHONHOME"):
            monkeypatch.delenv(name, raising=False)
    root = bench.validate_manifest(declared_manifest())
    monkeypatch.setattr(sys, "executable", str(root / "venv/bin/python"))
    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setattr(sys, "flags", SimpleNamespace(isolated=1))
    monkeypatch.setattr(sys, "stdin", SimpleNamespace(isatty=lambda: False))
    monkeypatch.setattr(sys, "stdout", SimpleNamespace(isatty=lambda: False))
    result = receipt()
    bench.fresh_process(root, result)
    assert result["runtime_flags"] == {"short_slice": False, "shared": False}
    monkeypatch.setattr(sys, "stdin", SimpleNamespace(isatty=lambda: True))
    with pytest.raises(bench.BenchError, match="non-TTY"):
        bench.fresh_process(root, result)


@pytest.mark.parametrize(
    "value",
    ["18: ip    pd | hi // GPIO18 = input\n", "18: a2    pd | lo // GPIO18 = PWM0\n"],
)
def test_pin_boundary_rejects_high_or_alt(monkeypatch, value):
    manifest = declared_manifest()
    monkeypatch.setattr(
        bench,
        "query",
        lambda args: {
            "returncode": 0,
            "stdout": value if args[-1] == "18" else manifest["sibling_pinctrl_stdout"],
        },
    )
    with pytest.raises(bench.BenchError, match="GPIO18"):
        bench.inspect_pins(manifest, receipt(), "test")


def test_signal_handlers_timer_and_masks_restore(monkeypatch):
    previous = {
        sig: object() for sig in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT)
    }
    handlers, timers, masks = dict(previous), [], []
    monkeypatch.setattr(bench.signal, "getitimer", lambda _kind: (0.0, 0.0))
    monkeypatch.setattr(
        bench.signal,
        "signal",
        lambda sig, handler: (
            handlers.setdefault(sig, handler)
            if False
            else replace(handlers, sig, handler)
        ),
    )
    monkeypatch.setattr(bench.signal, "setitimer", lambda *args: timers.append(args))
    monkeypatch.setattr(
        bench.signal, "pthread_sigmask", lambda *args: masks.append(args) or set()
    )
    with bench.SignalGuard() as guard:
        with guard.atomic():
            pass
        with pytest.raises(bench.BenchError, match="interrupted"):
            guard.interrupt(signal.SIGTERM, None)
        with guard.cleanup():
            pass
    assert handlers == previous and timers[0][-1] == 12 and timers[-1][-1] == 0
    assert len(masks) == 4


def replace(mapping, key, value):
    previous = mapping[key]
    mapping[key] = value
    return previous


def test_selected_sources_regular_path_and_hash_gate(monkeypatch, tmp_path):
    root = tmp_path / "root"
    root.mkdir()
    helper = root / bench.HELPER
    helper.write_text("fixture")
    monkeypatch.setattr(bench, "__file__", str(helper))
    manifest = {
        "source_paths": {bench.HELPER: str(helper)},
        "source_sha256": {bench.HELPER: "0" * 64},
    }
    with pytest.raises(bench.BenchError, match="bytes mismatch"):
        bench.inspect_sources(root, manifest, receipt())
    linked = root / "linked.py"
    linked.symlink_to(helper)
    manifest["source_paths"][bench.HELPER] = str(linked)
    with pytest.raises(bench.BenchError, match="non-symlink"):
        bench.inspect_sources(root, manifest, receipt())


def test_no_old_harnesses_or_production_changes_used():
    assert bench.SEQUENCE == (
        ("initial_low", 0, 0.2),
        ("half50", 32768, 3.0),
        ("commanded_low", 0, 0.2),
        ("quiet_release", None, 0.2),
    )
    assert all(
        not key.endswith("_eval.py") or key == bench.HELPER
        for key in bench.REQUIRED_SOURCES
    )


@pytest.mark.parametrize("backend", ["original", "native"])
def test_guarded_import_only_experiment_no_gpio_construction(
    environment, monkeypatch, tmp_path, backend
):
    state, gpio, library, _native = environment
    root = tmp_path
    path = root / "manifest.json"
    path.write_text("{}")
    manifest = declared_manifest()
    monkeypatch.setattr(bench, "read_json", lambda _path: manifest)
    monkeypatch.setattr(bench, "validate_manifest", lambda _manifest: root)
    monkeypatch.setattr(bench, "__file__", str(root / bench.HELPER))
    monkeypatch.setattr(bench, "fresh_process", lambda *_args: None)
    monkeypatch.setattr(bench, "inspect_sources", lambda *_args: {})
    monkeypatch.setattr(bench, "inspect_platform", lambda *_args: None)
    monkeypatch.setattr(bench, "SignalGuard", Guard)
    monkeypatch.setitem(sys.modules, "gpiod", library)
    monkeypatch.setitem(sys.modules, "RPi.GPIO", gpio)
    result = bench.experiment(path, backend, inspect_only=True)
    assert result["success"], result["primary_error"]
    assert result["guarded_import_only_no_gpio_construction"] and not result["phases"]
    assert not state.requests and not state.sleeps
    assert not any(
        call[0] in ("setup", "output", "cleanup", "PWM") for call in state.calls
    )
    assert result["gpio_hooks_restored"] and result["native_request_hook_restored"]


def prepare_experiment(environment, monkeypatch, tmp_path):
    state, gpio, library, _native = environment
    root = tmp_path
    path = root / "manifest.json"
    path.write_text("{}")
    manifest = declared_manifest()
    monkeypatch.setattr(bench, "read_json", lambda _path: manifest)
    monkeypatch.setattr(bench, "validate_manifest", lambda _manifest: root)
    monkeypatch.setattr(bench, "__file__", str(root / bench.HELPER))
    monkeypatch.setattr(bench, "fresh_process", lambda *_args: None)
    monkeypatch.setattr(bench, "inspect_sources", lambda *_args: {})
    monkeypatch.setattr(bench, "inspect_platform", lambda *_args: None)
    monkeypatch.setattr(bench, "SignalGuard", Guard)
    monkeypatch.setitem(sys.modules, "gpiod", library)
    monkeypatch.setitem(sys.modules, "RPi.GPIO", gpio)

    def check_low(_manifest, result, name):
        assert state.levels[18] == 0
        result.setdefault("boundary_low_confirmations", {})[name] = True

    monkeypatch.setattr(bench, "inspect_pins", check_low)
    return path


@pytest.mark.parametrize("backend", ["original", "native"])
def test_complete_experiment_success_requires_all_positive_facts(
    environment, monkeypatch, tmp_path, backend
):
    path = prepare_experiment(environment, monkeypatch, tmp_path)
    result = bench.experiment(path, backend)
    assert result["success"] and result["primary_error"] is None
    assert result["bounded_python_run_confirmed"] and len(result["phases"]) == 4
    assert result["gpio_hooks_restored"] and result["native_request_hook_restored"]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None


@pytest.mark.parametrize("failure", ["setup", "factory", "duty", "native-start"])
def test_experiment_errors_are_actual_failed_receipts_not_passes(
    environment, monkeypatch, tmp_path, failure
):
    state, _gpio, _library, _native = environment
    path = prepare_experiment(environment, monkeypatch, tmp_path)
    state.fail = failure
    result = bench.experiment(
        path, "native" if failure == "native-start" else "original"
    )
    assert not result["success"] and "injected" in result["primary_error"]
    assert result["gpio_hooks_restored"] and result["native_request_hook_restored"]
    assert not state.claimed


def test_actual_blinka_non_tty_installer_returns_false_without_pip(
    environment, monkeypatch
):
    state, _gpio, _library, _native = environment
    module = sys.modules["adafruit_blinka.platform_dependencies"]
    monkeypatch.setattr(sys, "stdin", SimpleNamespace(isatty=lambda: False))
    monkeypatch.setattr(sys, "stdout", SimpleNamespace(isatty=lambda: False))
    monkeypatch.setattr(
        module.subprocess,
        "run",
        lambda *_args, **_kwargs: pytest.fail("Runtime pip must never run"),
    )
    assert (
        state.actual_install_function(
            state.detector, input_func=lambda *_args: pytest.fail("No prompt")
        )
        is False
    )


def test_late_native_extension_origin_is_rejected_before_phases_and_cleanup_runs(
    environment, monkeypatch, tmp_path
):
    state, _gpio, _library, _native = environment
    path = prepare_experiment(environment, monkeypatch, tmp_path)
    calls = []

    def verify(_paths):
        calls.append(len(state.requests))
        if state.requests:
            raise bench.BenchError("injected late origin mismatch")

    monkeypatch.setattr(bench, "verify_origins", verify)
    result = bench.experiment(path, "native")
    assert not result["success"] and "late origin" in result["primary_error"]
    assert not result["phases"] and not state.claimed
    assert result["native_request_released"]
    assert calls == [0, 0, 1]


def test_native_import_phase_request_is_denied_before_factory(environment):
    state, _gpio, library, _native = environment
    result = receipt()
    with (
        bench.NativeRequestHooks(
            library, declared_manifest(), result, "native"
        ).installed(),
        pytest.raises(bench.BenchError, match="private initial-low"),
    ):
        library.request_lines(
            "/dev/gpiochip0",
            consumer="adafruit-blinka-pwm",
            config={
                18: SimpleNamespace(
                    direction=library.line.Direction.OUTPUT,
                    output_value=library.line.Value.INACTIVE,
                )
            },
        )
    assert not state.requests and result["native_request_hook_restored"]
    assert (
        result["events"][-1]["scope"] == "imports"
        and result["events"][-1]["status"] == "error"
    )
