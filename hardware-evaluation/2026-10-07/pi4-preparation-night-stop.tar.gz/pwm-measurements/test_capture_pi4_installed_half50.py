"""Recording-only Pi4 acquisition and synthetic raw-export tests.

No SSH, GPIO, real Saleae connection, sleeps or backend imports are performed.
The minimal transport receipt is explicitly fake; root owns the forthcoming
strict real-helper receipt binding.
"""

import hashlib
import json
import shlex
import struct
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_pi4_installed_half50 as bench
import pytest

ROOT = "/tmp/blinka-pwm-pi4-real-pin.abcd1234"


def put_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


@pytest.fixture(autouse=True)
def refuse_live_calls(monkeypatch):
    def forbidden(*_args, **_kwargs):
        raise AssertionError("A real acquisition/process/sleep is forbidden")

    monkeypatch.setattr(bench.subprocess, "run", forbidden)
    monkeypatch.setattr(bench.automation.Manager, "connect", forbidden)
    monkeypatch.setattr(bench.time, "sleep", forbidden)


@pytest.fixture
def inputs(tmp_path):
    manifest = {"schema_version": 1, "remote_root": ROOT}
    manifest_path = tmp_path / "manifest.json"
    preflight_path = tmp_path / "preflight.json"
    receipt = {"accepted": True, "ssh_returncode": 0}
    put_json(manifest_path, manifest)
    put_json(preflight_path, receipt)
    plan = {
        "schema_version": 1,
        "capture_order": [name for name, _backend in bench.RUNS],
        "capture_backends": dict(bench.RUNS),
        "remote_root": ROOT,
        "remote_python": ROOT + "/venv/bin/python",
        "host": "test2-pi4.local",
        "manifest_sha256": bench.digest(manifest_path),
        "method_sha256": bench.method_hashes(),
        "outputs": [
            {"gpio": 18, "saleae_channel": 2},
            {"gpio": 23, "saleae_channel": 3},
        ],
        "frequency": 50,
        "duty_cycle": 32768,
        "hold_seconds": 3.0,
        "runtime_flags": {"short_slice": False, "shared": False},
        "preflight_receipt_path": str(preflight_path),
        "preflight_receipt_sha256": bench.digest(preflight_path),
    }
    plan_path = tmp_path / "plan.json"
    put_json(plan_path, plan)
    return SimpleNamespace(
        plan=plan,
        manifest=manifest,
        preflight=receipt,
        plan_path=plan_path,
        manifest_path=manifest_path,
        preflight_path=preflight_path,
        output=tmp_path / bench.RUNS[0][0],
    )


def validate(fake, output=None):
    return bench.validate_inputs(
        fake.output if output is None else output,
        fake.plan_path,
        fake.manifest_path,
    )


def test_exact_predeclared_plan_source_and_fresh_output(inputs):
    output, plan, manifest, plan_hash, manifest_hash = validate(inputs)
    assert output == inputs.output
    assert plan == inputs.plan and manifest == inputs.manifest
    assert plan_hash == bench.digest(inputs.plan_path)
    assert manifest_hash == bench.digest(inputs.manifest_path)
    assert set(plan["method_sha256"]) == {
        "capture_pi4_installed_half50.py",
        "pi4_installed_pwm_half50_eval.py",
        "capture_pwm.py",
    }
    assert not output.exists()
    for name, backend in bench.RUNS:
        assert (
            validate(inputs, output.parent / name)[1]["capture_backends"][name]
            == backend
        )


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("schema_version", True),
        ("schema_version", "1"),
        ("schema_version", 2),
        ("capture_order", [name for name, _ in reversed(bench.RUNS)]),
        ("capture_backends", {name: "native" for name, _ in bench.RUNS}),
        ("remote_python", "/usr/bin/python3"),
        ("host", "test-pi5.local"),
        ("manifest_sha256", "0" * 64),
        ("method_sha256", {}),
        (
            "outputs",
            [{"gpio": 18, "saleae_channel": 0}, {"gpio": 23, "saleae_channel": 1}],
        ),
        (
            "outputs",
            [{"gpio": 23, "saleae_channel": 2}, {"gpio": 18, "saleae_channel": 3}],
        ),
        ("frequency", 500),
        ("frequency", 50.0),
        ("duty_cycle", 32767),
        ("duty_cycle", 32768.0),
        ("hold_seconds", 3),
        ("hold_seconds", 4.0),
        ("runtime_flags", {"short_slice": True, "shared": False}),
        ("runtime_flags", {"short_slice": False, "shared": True}),
        ("runtime_flags", {"short_slice": 0, "shared": False}),
        ("runtime_flags", {"short_slice": False, "shared": 0}),
    ],
)
def test_plan_contract_rejects_mutations_before_output(inputs, key, value):
    inputs.plan[key] = value
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        validate(inputs)
    assert not inputs.output.exists()


@pytest.mark.parametrize(
    "root",
    [
        "/tmp/blinka-pwm-pi4-real-pin.a",
        "/tmp/blinka-pwm-pi4-real-pin.ABCD1234",
        "/tmp/blinka-pwm-pi4-real-pin.abcd-123",
        "/tmp/blinka-pwm-pi4-real-pin.abcd12345",
        "/tmp/blinka-pwm-pi4-real-pin.abcd1234/child",
        "/tmp/blinka-pwm-native-dual.abcd1234",
        "tmp/blinka-pwm-pi4-real-pin.abcd1234",
        None,
    ],
)
def test_root_matches_exact_helper_scope(inputs, root):
    inputs.plan["remote_root"] = root
    inputs.plan["remote_python"] = str(root) + "/venv/bin/python"
    inputs.manifest["remote_root"] = root
    put_json(inputs.manifest_path, inputs.manifest)
    inputs.plan["manifest_sha256"] = bench.digest(inputs.manifest_path)
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError, match="Fresh Pi4 root"):
        validate(inputs)


@pytest.mark.parametrize("schema", [True, "1", 2, None])
def test_manifest_schema_is_exact_typed_one(inputs, schema):
    inputs.manifest["schema_version"] = schema
    put_json(inputs.manifest_path, inputs.manifest)
    inputs.plan["manifest_sha256"] = bench.digest(inputs.manifest_path)
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        validate(inputs)


def test_manifest_root_and_source_hashes_not_substitutable(inputs):
    inputs.manifest["remote_root"] = ROOT.replace("abcd1234", "fresh567")
    put_json(inputs.manifest_path, inputs.manifest)
    inputs.plan["manifest_sha256"] = bench.digest(inputs.manifest_path)
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        validate(inputs)
    inputs.manifest["remote_root"] = ROOT
    put_json(inputs.manifest_path, inputs.manifest)
    inputs.plan["manifest_sha256"] = bench.digest(inputs.manifest_path)
    inputs.plan["method_sha256"][bench.HELPER] = "0" * 64
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        validate(inputs)


@pytest.mark.parametrize(
    ("accepted", "actual"),
    [
        (False, 0),
        (1, 0),
        (None, 0),
        (True, False),
        (True, 0.0),
        (True, "0"),
        (True, None),
        (True, 1),
    ],
)
def test_preflight_requires_true_and_actual_typed_exit_zero(inputs, accepted, actual):
    put_json(inputs.preflight_path, {"accepted": accepted, "ssh_returncode": actual})
    inputs.plan["preflight_receipt_sha256"] = bench.digest(inputs.preflight_path)
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError, match="Actual successful preflight"):
        validate(inputs)
    assert not inputs.output.exists()


def test_changed_or_missing_preflight_is_refused(inputs):
    inputs.preflight_path.write_text(inputs.preflight_path.read_text() + "\n")
    with pytest.raises(ValueError, match="Unchanged successful preflight"):
        validate(inputs)
    inputs.plan["preflight_receipt_path"] = str(
        inputs.preflight_path.parent / "absent.json"
    )
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError, match="Regular canonical file"):
        validate(inputs)


@pytest.mark.parametrize("which", ["plan", "manifest", "preflight"])
def test_duplicate_json_keys_are_refused(inputs, which):
    path = getattr(inputs, which + "_path")
    key = "ssh_returncode" if which == "preflight" else "schema_version"
    original = path.read_text()
    path.write_text(original.replace("{", '{"' + key + '":0,', 1))
    if which == "manifest":
        inputs.plan["manifest_sha256"] = bench.digest(path)
        put_json(inputs.plan_path, inputs.plan)
    elif which == "preflight":
        inputs.plan["preflight_receipt_sha256"] = bench.digest(path)
        put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError, match="Duplicate JSON key"):
        validate(inputs)


@pytest.mark.parametrize("existing_kind", ["directory", "file", "symlink"])
def test_existing_output_is_untouched(inputs, existing_kind):
    if existing_kind == "directory":
        inputs.output.mkdir()
        (inputs.output / "foreign.txt").write_bytes(b"foreign evidence")
    elif existing_kind == "file":
        inputs.output.write_bytes(b"foreign evidence")
    else:
        target = inputs.output.parent / "foreign"
        target.mkdir()
        (target / "foreign.txt").write_bytes(b"foreign evidence")
        inputs.output.symlink_to(target, target_is_directory=True)
    with pytest.raises(ValueError):
        validate(inputs)
    evidence = (
        inputs.output if existing_kind == "file" else inputs.output / "foreign.txt"
    )
    assert evidence.read_bytes() == b"foreign evidence"


def test_symlink_parent_and_unapproved_capture_label_refused(inputs):
    target = inputs.output.parent / "target"
    target.mkdir()
    link = inputs.output.parent / "linked"
    link.symlink_to(target, target_is_directory=True)
    with pytest.raises(ValueError, match="traverse links"):
        validate(inputs, link / inputs.output.name)
    with pytest.raises(ValueError, match="predeclared"):
        validate(inputs, inputs.output.parent / "unapproved-capture")


def test_digest_and_write_new_keep_exclusive_regular_file_scope(tmp_path):
    path = tmp_path / "data.json"
    bench.write_new(path, {"preserved": True})
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        bench.write_new(path, {"overwritten": True})
    assert path.read_bytes() == before
    assert bench.digest(path) == hashlib.sha256(before).hexdigest()
    link = tmp_path / "alias.json"
    link.symlink_to(path)
    with pytest.raises(ValueError, match="Regular canonical file"):
        bench.digest(link)


def binary(path, chunks, version=0):
    content = struct.pack("<8sii", b"<SALEAE>", version, 0)
    if version:
        content += struct.pack("<Q", len(chunks))
    else:
        assert len(chunks) == 1
    for initial, begin, end, times in chunks:
        content += struct.pack("<I", initial)
        if version:
            content += struct.pack("<d", 100_000_000.0)
        content += struct.pack("<ddQ", begin, end, len(times))
        content += struct.pack("<" + "d" * len(times), *times)
    path.write_bytes(content)


def test_reconstruct_retains_every_uneven_interval_and_outlier(tmp_path):
    path = tmp_path / "digital_2.bin"
    times = [0.1, 0.11, 0.12, 0.131, 0.14, 0.170886, 0.18, 0.180001]
    binary(path, [(0, 0.0, 0.5, times)])
    report = bench.reconstruct(path, 10000.0)
    row = report["chunks"][0]
    assert report["no_interval_trimming_or_filtering"]
    assert report["raw_sha256"] == bench.digest(path)
    assert row["edges_s"] == times
    assert row["complete_high_intervals_s"] == [
        [times[i], times[i + 1]] for i in (0, 2, 4, 6)
    ]
    assert row["complete_low_intervals_s"] == [
        [times[i], times[i + 1]] for i in (1, 3, 5)
    ]
    assert row["highs_us"] == pytest.approx([10000, 11000, 30886, 1])
    assert row["lows_us"] == pytest.approx([10000, 9000, 9114])
    assert row["rise_periods_us"] == pytest.approx([20000, 20000, 40000])
    assert row["high_summary_us"]["count"] == 4
    assert row["high_summary_us"]["min"] == pytest.approx(1)
    assert row["high_summary_us"]["max"] == pytest.approx(30886)
    assert row["absolute_high_error_summary_us"]["max"] == pytest.approx(20886)
    assert row["quiet_low_tail_seconds"] == pytest.approx(0.319999)


@pytest.mark.parametrize(
    ("initial", "times", "highs", "lows", "final"),
    [
        (1, [0.1, 0.2, 0.35, 0.55], [[0.2, 0.35]], [[0.1, 0.2], [0.35, 0.55]], 1),
        (0, [0.1, 0.3, 0.4], [[0.1, 0.3]], [[0.3, 0.4]], 1),
        (1, [0.1], [], [], 0),
        (0, [], [], [], 0),
        (1, [], [], [], 1),
    ],
)
def test_boundary_fragments_are_not_invented_complete_pulses(
    tmp_path, initial, times, highs, lows, final
):
    path = tmp_path / "edges.bin"
    binary(path, [(initial, 0.0, 1.0, times)])
    row = bench.reconstruct(path, 10000.0)["chunks"][0]
    assert row["initial_level"] == initial and row["final_level"] == final
    assert row["edges_s"] == times
    assert row["complete_high_intervals_s"] == highs
    assert row["complete_low_intervals_s"] == lows
    assert row["initial_boundary"] == {
        "level": initial,
        "begin_s": 0.0,
        "end_s": times[0] if times else 1.0,
    }
    assert row["final_boundary"] == {
        "level": final,
        "begin_s": times[-1] if times else 0.0,
        "end_s": 1.0,
    }
    assert row["quiet_low_tail_seconds"] == (
        1.0 - (times[-1] if times else 0.0) if final == 0 else None
    )


def analysis_fixture(tmp_path, name, chunks, peer=None, version=0):
    directory = tmp_path / name
    directory.mkdir()
    put_json(
        directory / "results.json",
        {"backend": dict(bench.RUNS)[name], "collection_success": True},
    )
    binary(directory / "digital_2.bin", chunks, version)
    binary(
        directory / "digital_3.bin",
        [(0, 0.0, 1.0, [])] if peer is None else peer,
        version,
    )
    return directory


@pytest.mark.parametrize("name", [bench.RUNS[0][0], bench.RUNS[1][0]])
def test_descriptive_analysis_low_peer_and_backend_specific_target(tmp_path, name):
    directory = analysis_fixture(
        tmp_path, name, [(0, 0.0, 1.0, [0.1, 0.11, 0.12, 0.131])]
    )
    report = bench.analyze(directory)
    assert report["single_train_with_untouched_low_peer_supported"]
    assert report["channels"]["3"]["chunks"][0]["edges_s"] == []
    assert report["channels"]["3"]["chunks"][0]["high_summary_us"] == {"count": 0}
    assert report["parity_pass"] is None
    assert report["electrical_and_pi_clocks_aligned"] is False
    assert report["target_high_us"] == (
        10000.0 if dict(bench.RUNS)[name] == "original" else 10000.153
    )


@pytest.mark.parametrize("peer", [[(1, 0.0, 1.0, [])], [(0, 0.0, 1.0, [0.2, 0.21])]])
def test_active_or_initially_high_peer_withholds_single_train_scope(tmp_path, peer):
    directory = analysis_fixture(
        tmp_path, bench.RUNS[0][0], [(0, 0.0, 1.0, [0.1, 0.11])], peer
    )
    report = bench.analyze(directory)
    assert not report["single_train_with_untouched_low_peer_supported"]
    assert report["channels"]["3"]["chunks"][0]["edges_s"] == peer[0][3]


@pytest.mark.parametrize(
    "chunks",
    [
        [(0, 0.0, 1.0, [])],
        [(1, 0.0, 1.0, [0.1, 0.2, 0.21])],
        [(0, 0.0, 1.0, [0.1, 0.11, 0.12])],
        [(0, 0.0, 0.2, [0.1, 0.11])],
    ],
)
def test_main_boundaries_no_pulses_or_short_tail_withhold_scope(tmp_path, chunks):
    directory = analysis_fixture(tmp_path, bench.RUNS[0][0], chunks)
    assert not bench.analyze(directory)[
        "single_train_with_untouched_low_peer_supported"
    ]


def test_multiple_gapped_chunks_keep_all_edges_without_cross_gap_intervals(tmp_path):
    chunks = [
        (0, 0.0, 0.5, [0.1, 0.11, 0.12, 0.131]),
        (1, 2.0, 3.0, [2.1, 2.2, 2.21, 2.3, 2.300001]),
    ]
    peer = [(0, 0.0, 0.5, []), (0, 2.0, 3.0, [])]
    directory = analysis_fixture(tmp_path, bench.RUNS[0][0], chunks, peer, version=1)
    report = bench.analyze(directory)
    assert not report["single_train_with_untouched_low_peer_supported"]
    raw = report["channels"]["2"]
    assert raw["binary_format_version"] == 1
    assert [row["edges_s"] for row in raw["chunks"]] == [chunks[0][3], chunks[1][3]]
    assert raw["chunks"][0]["rise_periods_us"] == pytest.approx([20000])
    assert raw["chunks"][1]["rise_periods_us"] == pytest.approx([100000])
    assert raw["chunks"][1]["highs_us"] == pytest.approx([10000, 1])
    assert all(row["sample_rate_in_export"] == 100_000_000.0 for row in raw["chunks"])
    assert report["parity_pass"] is None


def recording(monkeypatch, inputs, scenario="success", failures=()):
    events = []
    receipt = {"success": True, "recording_only_transport_fixture": True}
    capture = MagicMock()
    capture.__enter__.return_value = capture

    def operation(name, body):
        def called(*args, **kwargs):
            events.append(name)
            if name in failures:
                raise OSError(name + " failed")
            return body(*args, **kwargs)

        return called

    capture.stop.side_effect = operation("stop", lambda: None)
    capture.save_capture.side_effect = operation(
        "save", lambda path: Path(path).write_bytes(b"recording-only SAL")
    )

    def export(path, **kwargs):
        assert kwargs == {"digital_channels": [2, 3]}
        for channel in (2, 3):
            (Path(path) / f"digital_{channel}.bin").write_bytes(b"recording-only raw")

    capture.export_raw_data_binary.side_effect = operation("export", export)
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake Logic2")
    manager.start_capture.return_value = capture
    if scenario == "connection":
        connect = MagicMock(side_effect=OSError("connection failed"))
    else:
        connect = MagicMock(return_value=manager)
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connect),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test2-pi4.local",
        ]
        assert shlex.split(command[-1]) == [
            ROOT + "/venv/bin/python",
            "-I",
            ROOT + "/" + bench.HELPER,
            "--manifest",
            ROOT + "/manifest.json",
            "--backend",
            dict(bench.RUNS)[inputs.output.name],
        ]
        assert set(kwargs) == {"stdin", "stdout", "stderr", "timeout", "check"}
        assert (
            kwargs["stdin"] == subprocess.DEVNULL
            and kwargs["timeout"] == 25
            and kwargs["check"] is False
        )
        kwargs["stderr"].write("retained stderr bytes\n")
        if scenario in ("timeout", "interrupt", "process_error"):
            kwargs["stdout"].write("partial stdout\n")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 25)
            if scenario == "interrupt":
                raise KeyboardInterrupt("recording interrupted")
            raise OSError("runner failed")
        kwargs["stdout"].write(
            "not JSON\n"
            if scenario == "malformed"
            else json.dumps({**receipt, "success": scenario != "helper_failure"})
        )
        actual = {"bool_exit": False, "string_exit": "0", "nonzero_exit": 7}.get(
            scenario, 0
        )
        return subprocess.CompletedProcess(command, actual)

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)

    def sleep(duration):
        events.append(("sleep", duration))
        if "tail" in failures and duration == 0.2:
            raise OSError("tail failed")

    monkeypatch.setattr(bench.time, "sleep", sleep)
    return SimpleNamespace(
        events=events, manager=manager, capture=capture, runner=runner, connect=connect
    )


def collected(inputs):
    return bench.collect(inputs.output, inputs.plan_path, inputs.manifest_path)


def test_recording_capture_exact_config_command_cleanup_and_retained_bytes(
    monkeypatch, inputs
):
    fake = recording(monkeypatch, inputs)
    assert collected(inputs) == 0
    assert fake.events == [
        ("sleep", 0.5),
        "ssh",
        ("sleep", 0.2),
        "stop",
        "save",
        "export",
    ]
    fake.connect.assert_called_once_with(port=10430, connect_timeout_seconds=5)
    fake.manager.start_capture.assert_called_once_with(
        device_id=bench.DEVICE_ID,
        device_configuration={
            "enabled_digital_channels": [2, 3],
            "digital_sample_rate": 100_000_000,
            "glitch_filters": [],
        },
    )
    result = json.loads((inputs.output / "results.json").read_text())
    acquisition = json.loads((inputs.output / "acquisition.json").read_text())
    assert result["collection_success"] and result["parity_pass"] is None
    assert result["acquisition"] == acquisition
    assert (
        acquisition["actual_ssh_returncode"] == 0
        and type(acquisition["actual_ssh_returncode"]) is int
    )
    assert acquisition["primary_error"] is None and acquisition["evidence_errors"] == []
    assert (inputs.output / "remote.stderr").read_bytes() == b"retained stderr bytes\n"
    assert (inputs.output / "plan.json").read_bytes() == inputs.plan_path.read_bytes()
    assert (
        inputs.output / "manifest.json"
    ).read_bytes() == inputs.manifest_path.read_bytes()
    assert (inputs.output / "waveform.sal").read_bytes() == b"recording-only SAL"
    assert [(inputs.output / f"digital_{c}.bin").read_bytes() for c in (2, 3)] == [
        b"recording-only raw"
    ] * 2
    fake.capture.__exit__.assert_called_once()
    fake.manager.__exit__.assert_called_once()


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "process_error",
        "bool_exit",
        "string_exit",
        "nonzero_exit",
        "malformed",
        "helper_failure",
    ],
)
def test_recording_failures_preserve_actual_exit_or_none_and_drain(
    monkeypatch, inputs, scenario
):
    fake = recording(monkeypatch, inputs, scenario)
    with pytest.raises(ValueError, match="all available evidence preserved"):
        collected(inputs)
    assert fake.events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
    result = json.loads((inputs.output / "results.json").read_text())
    acquisition = result["acquisition"]
    expected = (
        7
        if scenario == "nonzero_exit"
        else None
        if scenario
        in ("timeout", "interrupt", "process_error", "bool_exit", "string_exit")
        else 0
    )
    assert acquisition["actual_ssh_returncode"] == expected
    assert not result["collection_success"] and result["parity_pass"] is None
    assert (inputs.output / "remote.stderr").read_bytes() == b"retained stderr bytes\n"
    if scenario in ("timeout", "interrupt", "process_error"):
        assert (inputs.output / "remote.stdout").read_bytes() == b"partial stdout\n"
        assert acquisition["primary_error"] is not None
    assert (inputs.output / "waveform.sal").exists()
    assert all((inputs.output / f"digital_{c}.bin").exists() for c in (2, 3))
    fake.capture.__exit__.assert_called_once()
    fake.manager.__exit__.assert_called_once()


@pytest.mark.parametrize(
    "failures",
    [("tail",), ("stop",), ("save",), ("export",), ("tail", "stop", "save", "export")],
)
def test_each_cleanup_attempt_runs_in_order_after_prior_failure(
    monkeypatch, inputs, failures
):
    fake = recording(monkeypatch, inputs, failures=failures)
    with pytest.raises(ValueError):
        collected(inputs)
    assert fake.events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
    result = json.loads((inputs.output / "results.json").read_text())
    assert result["acquisition"]["actual_ssh_returncode"] == 0
    assert [e["operation"] for e in result["acquisition"]["evidence_errors"]] == list(
        failures
    )
    assert not result["collection_success"]


def test_primary_timeout_is_not_replaced_by_save_export_failures(monkeypatch, inputs):
    fake = recording(monkeypatch, inputs, "timeout", failures=("save", "export"))
    with pytest.raises(ValueError):
        collected(inputs)
    result = json.loads((inputs.output / "results.json").read_text())
    assert result["acquisition"]["actual_ssh_returncode"] is None
    assert result["acquisition"]["primary_error"].startswith("TimeoutExpired:")
    assert [e["operation"] for e in result["acquisition"]["evidence_errors"]] == [
        "save",
        "export",
        "parse_helper",
    ]
    assert fake.events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
    assert (inputs.output / "remote.stdout").read_bytes() == b"partial stdout\n"
    assert (inputs.output / "remote.stderr").read_bytes() == b"retained stderr bytes\n"


@pytest.mark.parametrize("scenario", ["simulation", "connection"])
def test_physical_device_and_connection_failure_never_launch_ssh(
    monkeypatch, inputs, scenario
):
    fake = recording(monkeypatch, inputs, scenario)
    with pytest.raises(ValueError):
        collected(inputs)
    fake.runner.assert_not_called()
    fake.manager.start_capture.assert_not_called()
    result = json.loads((inputs.output / "results.json").read_text())
    assert result["acquisition"]["actual_ssh_returncode"] is None
    assert result["acquisition"]["primary_error"] is not None
    assert (inputs.output / "remote.stdout").read_bytes() == b""
    assert (inputs.output / "remote.stderr").read_bytes() == b""


def test_collection_bad_gate_never_connects_or_creates_outputs(monkeypatch, inputs):
    fake = recording(monkeypatch, inputs)
    inputs.plan["host"] = "foreign.local"
    put_json(inputs.plan_path, inputs.plan)
    with pytest.raises(ValueError):
        collected(inputs)
    fake.connect.assert_not_called()
    fake.runner.assert_not_called()
    assert not inputs.output.exists()


def test_analysis_new_output_is_exclusive_and_plain_filename(monkeypatch, tmp_path):
    directory = analysis_fixture(
        tmp_path, bench.RUNS[0][0], [(0, 0.0, 1.0, [0.1, 0.11])]
    )
    assert bench.main(["analyze", str(directory)]) == 0
    path = directory / "half50-analysis.json"
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        bench.main(["analyze", str(directory)])
    assert path.read_bytes() == before
    for name in ("../foreign.json", "/tmp/foreign.json", ".", ".."):
        with pytest.raises(ValueError, match="plain output filename"):
            bench.main(["analyze", str(directory), "--output-name", name])
