"""Offline, unfiltered native half50 facts and predeclared finite comparisons.

No hardware calls are made. Width bins are diagnostic, never an acceptance
filter. Caller return times and electrical durations remain separate because
Pi and Saleae clocks are not aligned. There is no overall backend parity flag.
"""

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

from analyze_kernel_pwm_inverse import read_continuous, require, validate_saved_capture
from analyze_kernel_pwm_lgpio_baseline import analyze as analyze_baseline
from analyze_kernel_pwm_lgpio_baseline import waveform_facts
from capture_pwm import describe

MODE = "half50-direct"
BACKEND = "native-blinka-pwm"
NATIVE_HIGH_TARGET_US = 20_000 * 32768 / 65535
PLAN_NAME = "oct7-native-half50-plan.json"
BASELINE_NAMES = (
    "oct6-pi5-lgpio-baseline-half50-direct",
    "oct6-pi5-lgpio-baseline-half50-direct-r2",
)
SCOPES = (
    "pwm50_d32768_initial",
    "high50",
    "pwm50_d32768_recovery",
    "low50_final",
)
PREDECLARED_CHECKS = {
    "start_and_end_low": True,
    "continuous_high_runs": 1,
    "unmatched_high_runs": 0,
    "sub_microsecond_interior_low_runs": 0,
    "initial_pwm_high_count": 20,
    "recovery_pwm_high_count_inclusive": [19, 20],
    "complete_edge_count_inclusive": [80, 82],
    "max_absolute_high_deviation_from_common_10000us_reference_us": 49.16,
    "max_absolute_period_deviation_from_20000us_reference_us": 59.72,
    "max_absolute_interior_low_deviation_from_10000us_reference_us": 25.97,
    "max_absolute_constant_high_duration_deviation_from_300ms_ms": 10.343,
    "max_physical_boundary_low_gap_ms": 10.02488,
    "caller_setter_per_scope_max_us": {
        "pwm50_d32768_initial": 15.501,
        "high50": 12.340,
        "pwm50_d32768_recovery": 22.699,
        "low50_final": 17.112,
    },
}


def read_plan(path):
    from capture_native_pwm_half50 import read_json

    path = Path(path)
    plan = read_json(path.read_text())
    require(
        plan.get("schema_version") == 1
        and plan.get("baseline_captures") == list(BASELINE_NAMES)
        and plan.get("provisional_checks") == PREDECLARED_CHECKS
        and plan.get("sequence")
        == [[0, 0.2], [32768, 0.4], [65535, 0.3], [32768, 0.4], [0, 0.2]]
        and plan.get("short_slice") is False
        and plan.get("shared") is False
        and plan.get("load_workers") == 0,
        "Expected exact predeclared idle/default half50 comparison plan",
    )
    return plan, hashlib.sha256(path.read_bytes()).hexdigest()


def summary(values):
    return describe(values) if values else None


def maximum_deviation(values, target):
    return max((abs(value - target) for value in values), default=None)


def comparison_metrics(report):
    """Include anomalous short highs/periods; never summarize only matched bins."""
    physical = report["physical"]
    highs = physical["all_high_runs"]
    short_highs = [item["width_us"] for item in highs if item["width_us"] < 100_000]
    periods = [
        (second["rise_seconds"] - first["rise_seconds"]) * 1e6
        for first, second in itertools.pairwise(highs)
        if first["width_us"] < 100_000 and second["width_us"] < 100_000
    ]
    lows = [item["width_ns"] / 1000 for item in physical["all_interior_low_runs"]]
    holds = [item["width_us"] / 1000 for item in physical["constant_high_holds"]]
    groups = physical["groups"]
    expected_groups = ["half50_rounded50pct", "constant_high", "half50_rounded50pct"]
    topology = [item["width_bin"] for item in groups] == expected_groups
    boundary_lows = [item["low_gap_seconds"] * 1000 for item in physical["boundaries"]]
    return {
        "group_topology_matches_half50_hold_half50": topology,
        "initial_pwm_high_count": groups[0]["high_count"] if topology else None,
        "recovery_pwm_high_count": groups[2]["high_count"] if topology else None,
        "edge_count": report["waveform"]["edge_count"],
        "high_run_count": len(highs),
        "continuous_high_runs": len(holds),
        "unmatched_high_runs": len(physical["unmatched_high_runs"]),
        "sub_microsecond_interior_low_runs": len(physical["sub_microsecond_low_runs"]),
        "all_short_high_us": summary(short_highs),
        "all_short_high_region_rise_to_rise_us": summary(periods),
        "all_interior_low_us": summary(lows),
        "continuous_high_ms": holds,
        "max_absolute_high_deviation_from_common_10000us_reference_us": maximum_deviation(
            short_highs, 10_000
        ),
        "max_absolute_high_deviation_from_native_target_us": maximum_deviation(
            short_highs, NATIVE_HIGH_TARGET_US
        ),
        "max_absolute_period_deviation_from_20000us_reference_us": maximum_deviation(
            periods, 20_000
        ),
        "max_absolute_interior_low_deviation_from_10000us_reference_us": maximum_deviation(
            lows, 10_000
        ),
        "max_absolute_constant_high_duration_deviation_from_300ms_ms": maximum_deviation(
            holds, 300
        ),
        "max_physical_boundary_low_gap_ms": max(boundary_lows, default=None),
        "caller_setter_per_scope_max_us": {
            scope: max(
                (
                    item["caller_duration_us"]
                    for item in report["caller_updates"]
                    if item["scope"] == scope
                ),
                default=None,
            )
            for scope in SCOPES
        },
        "phase_api_update_durations_us": report["phase_api_update_durations_us"],
    }


def provisional_checks(report):
    metrics = comparison_metrics(report)
    checks = []

    def check(name, observed, expected, passed, domain="physical"):
        checks.append(
            {
                "name": name,
                "domain": domain,
                "observed": observed,
                "provisional_limit": expected,
                "within_predeclared_limit": bool(passed),
            }
        )

    waveform = report["waveform"]
    check(
        "start_and_end_low",
        [waveform["initial_state"], waveform["final_state"]],
        [0, 0],
        waveform["initial_state"] == waveform["final_state"] == 0,
    )
    check(
        "all_edges_accounted_for",
        metrics["edge_count"],
        2 * metrics["high_run_count"],
        metrics["edge_count"] == 2 * metrics["high_run_count"],
    )
    check(
        "group_topology_matches_half50_hold_half50",
        metrics["group_topology_matches_half50_hold_half50"],
        True,
        metrics["group_topology_matches_half50_hold_half50"],
    )
    for key in (
        "continuous_high_runs",
        "unmatched_high_runs",
        "sub_microsecond_interior_low_runs",
        "initial_pwm_high_count",
    ):
        check(
            key,
            metrics[key],
            PREDECLARED_CHECKS[key],
            metrics[key] == PREDECLARED_CHECKS[key],
        )
    for metric, plan_key in (
        ("recovery_pwm_high_count", "recovery_pwm_high_count_inclusive"),
        ("edge_count", "complete_edge_count_inclusive"),
    ):
        value, bounds = metrics[metric], PREDECLARED_CHECKS[plan_key]
        check(
            metric, value, bounds, value is not None and bounds[0] <= value <= bounds[1]
        )
    for key, limit in PREDECLARED_CHECKS.items():
        if not key.startswith("max_"):
            continue
        value = metrics[key]
        check(
            key,
            value,
            limit,
            value is not None and math.isfinite(value) and value <= limit + 1e-7,
        )
    for scope, limit in PREDECLARED_CHECKS["caller_setter_per_scope_max_us"].items():
        value = metrics["caller_setter_per_scope_max_us"][scope]
        check(
            "caller_setter_duration." + scope,
            value,
            limit,
            value is not None and math.isfinite(value) and value <= limit,
            domain="caller_return_not_electrical_latency",
        )
    return {
        "metrics": metrics,
        "checks": checks,
        "flags_to_investigate": [
            item["name"] for item in checks if not item["within_predeclared_limit"]
        ],
    }


def compare_paired(native_reports, baseline_reports, plan=None):
    """Two versus two, not a statistically established backend-parity verdict."""
    require(
        len(native_reports) == len(baseline_reports) == 2,
        "Matched comparison requires two native and two baseline captures",
    )
    require(
        [item["capture"] for item in baseline_reports] == list(BASELINE_NAMES),
        "Expected exact retained half50 baseline pair in original/repeat order",
    )
    require(
        all(
            item.get("backend") == "original-blinka-lgpio" and item.get("mode") == MODE
            for item in baseline_reports
        ),
        "Wrong baseline backend/mode",
    )
    require(
        all(
            item.get("backend") == BACKEND and item.get("mode") == MODE
            for item in native_reports
        ),
        "Wrong native backend/mode",
    )
    require(
        len({item["capture"] for item in native_reports}) == 2,
        "Native repeats must be distinct captures",
    )
    if plan is not None:
        require(
            plan.get("provisional_checks") == PREDECLARED_CHECKS,
            "Predeclared limits must not be adjusted after capture",
        )
    return {
        "comparison_kind": "predeclared_narrow_finite_observation",
        "baseline_metrics": [
            {"capture": item["capture"], "metrics": comparison_metrics(item)}
            for item in baseline_reports
        ],
        "native_comparisons": [
            {"capture": item["capture"], **provisional_checks(item)}
            for item in native_reports
        ],
        "predeclared_checks": PREDECLARED_CHECKS,
        "overall_backend_parity_established": False,
        "electrical_command_latency_measured": False,
        "limitation": "Two idle captures per backend, uncalibrated digital threshold evidence and recording overhead. A flag is an investigation prompt, not automatically a material regression. No load/coexistence, other frequencies, pins or boards are covered.",
    }


def analyze(directory, plan_path=None):
    from capture_native_pwm_half50 import read_json, validate_remote

    directory = Path(directory)
    plan_path = (
        Path(plan_path)
        if plan_path is not None
        else Path(__file__).with_name(PLAN_NAME)
    )
    plan, plan_sha256 = read_plan(plan_path)
    metadata = read_json((directory / "results.json").read_text())
    remote = read_json((directory / "remote.stdout").read_text())
    manifest = read_json((directory / "manifest.json").read_text())
    validate_remote(remote, manifest)
    require(metadata.get("remote") == remote, "Native remote receipt/metadata disagree")
    require(
        type(metadata.get("schema_version")) is int
        and metadata["schema_version"] == 1
        and metadata.get("mode") == MODE
        and metadata.get("backend") == BACKEND
        and metadata.get("sequence_marker") == "native-half50-direct-v1"
        and metadata.get("production_backend_unchanged") is True
        and metadata.get("collection_success") is True
        and type(metadata.get("remote_returncode")) is int
        and metadata["remote_returncode"] == 0
        and metadata.get("parity_evaluated") is False
        and "parity_pass" in metadata
        and metadata["parity_pass"] is None
        and "waveform_accepted" in metadata
        and metadata["waveform_accepted"] is None,
        "Expected successful native collection without a waveform/parity verdict",
    )
    acquisition = read_json((directory / "acquisition.json").read_text())
    require(
        acquisition.get("mode") == MODE
        and acquisition.get("backend") == BACKEND
        and type(acquisition.get("remote_returncode")) is int
        and acquisition["remote_returncode"] == 0
        and "primary_error" in acquisition
        and acquisition["primary_error"] is None
        and acquisition.get("evidence_errors") == [],
        "Native acquisition failed or reported incomplete evidence",
    )
    require(
        remote.get("manifest_path")
        == str(acquisition.get("remote_root")) + "/manifest.json"
        and acquisition.get("local_timing_not_aligned_to_pi_or_saleae") is True
        and all(
            item.get("pre_helper_lead_seconds") == 0.5
            and item.get("post_helper_tail_seconds") == 0.2
            for item in (metadata, acquisition)
        ),
        "Native acquisition root/lead/tail/clock provenance mismatch",
    )
    require(
        metadata.get("host") == "test-pi5.local"
        and metadata.get("sample_rate_hz") == 100_000_000,
        "Wrong native host/sample rate",
    )
    require(
        metadata.get("outputs")
        == [{"gpio": 18, "saleae_channel": 0, "backend": BACKEND}],
        "Wrong native output mapping",
    )
    settings = validate_saved_capture(directory / "waveform.sal")
    waveform, edges = read_continuous(directory / "digital_0.bin")
    physical = waveform_facts(waveform, edges)
    setters = [
        {
            "operation": event["operation"],
            "scope": event["scope"],
            "arguments": event["arguments"],
            "begin_ns": event["begin_ns"],
            "end_ns": event["end_ns"],
            "caller_duration_us": (event["end_ns"] - event["begin_ns"]) / 1000,
        }
        for event in remote["events"]
        if event["operation"] in ("PWMOut.frequency", "PWMOut.duty_cycle")
    ]
    require(
        [item["scope"] for item in setters] == list(SCOPES)
        and all(item["operation"] == "PWMOut.duty_cycle" for item in setters),
        "Expected exactly four native duty setters, with no frequency setters",
    )
    report = {
        "capture": directory.name,
        "mode": MODE,
        "backend": BACKEND,
        "collection_success": True,
        "characterization_only": True,
        "saved_capture_settings": settings,
        "waveform": waveform,
        "physical": physical,
        "caller_updates": setters,
        "phase_api_update_durations_us": [
            {
                "name": phase["name"],
                "duration_us": (phase["stable_begin_ns"] - phase["begin_ns"]) / 1000,
            }
            for phase in remote["phases"]
        ],
        "source_sha256": remote["source_sha256"],
        "source_manifest": manifest,
        "comparison_plan_sha256": plan_sha256,
        "comparison_plan_declared_before_capture_utc": plan[
            "declared_before_capture_utc"
        ],
        "quantization": {
            "native_high_target_us": NATIVE_HIGH_TARGET_US,
            "common_original_high_reference_us": 10_000,
            "nominal_sample_interval_ns": 10,
            "timebase_calibrated": False,
            "width_bins_are_diagnostic_not_parity": True,
        },
        "clock_alignment": "Pi API/phase clocks are not aligned to Saleae; no command-to-edge latency claim.",
        "caller_timing_includes_instrumentation": True,
        "limitation": "Finite unfiltered 100 MSa/s digital threshold evidence, not analog proof or exclusion of sub-sample glitches. Every edge, boundary pulse/gap and anomalous run is retained. No overall backend parity is established.",
    }
    report["provisional_comparison"] = provisional_checks(report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "directories",
        type=Path,
        nargs="+",
        help="One capture report, or two for paired comparison",
    )
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output-name", default="analysis.json")
    parser.add_argument("--comparison-output", type=Path)
    args = parser.parse_args(argv)
    require(len(args.directories) in (1, 2), "Expected one or two native captures")
    require(
        bool(args.output_name)
        and Path(args.output_name).name == args.output_name
        and args.output_name not in (".", ".."),
        "Output must be a filename within the capture directory",
    )
    require(
        args.comparison_output is None or len(args.directories) == 2,
        "Paired output requires two native captures",
    )
    reports = [analyze(directory, args.plan) for directory in args.directories]
    comparison = None
    if len(reports) == 2:
        root = Path(__file__).parent
        baselines = [analyze_baseline(root / name) for name in BASELINE_NAMES]
        comparison = compare_paired(reports, baselines)
    for directory, report in zip(args.directories, reports):
        with (directory / args.output_name).open("x") as stream:
            json.dump(report, stream, indent=2)
            stream.write("\n")
    if args.comparison_output is not None:
        with args.comparison_output.open("x") as stream:
            json.dump(comparison, stream, indent=2)
            stream.write("\n")
    print(
        json.dumps(
            {
                "native_captures": [
                    {
                        "capture": report["capture"],
                        "edges": report["waveform"]["edge_count"],
                        "flags_to_investigate": report["provisional_comparison"][
                            "flags_to_investigate"
                        ],
                    }
                    for report in reports
                ],
                "paired_comparison_evaluated": comparison is not None,
                "overall_backend_parity_established": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
