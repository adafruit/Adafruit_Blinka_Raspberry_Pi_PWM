"""Fake capture/receipt tests: no analyzer, SSH, GPIO or waveform verdict."""

import copy
import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_native_pwm_half50 as bench
import native_pwm_half50_eval as helper
import pytest
import test_native_pwm_half50_eval as helper_fakes

ROOT = helper_fakes.ROOT
environment = helper_fakes.environment
PYTHON = "/tmp/blinka-pwm-oct6.F3SDcm/venv/bin/python"


def configure(monkeypatch, receipt, scenario="success"):
    events = []
    capture = MagicMock()
    capture.__enter__.return_value = capture
    capture.stop.side_effect = lambda: events.append("stop")

    def save(path):
        events.append("save")
        if scenario == "save_error":
            raise OSError("save failed")
        Path(path).write_bytes(b"fake SAL evidence")

    def export(path, **kwargs):
        events.append(("export", kwargs["digital_channels"]))
        if scenario != "missing_raw":
            (Path(path) / "digital_0.bin").write_bytes(b"fake unfiltered edges")

    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = export
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=MagicMock(return_value=manager)),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            PYTHON,
            ROOT + "/native_pwm_half50_eval.py",
            "--manifest",
            ROOT + "/manifest.json",
        ]
        assert set(kwargs) == {"stdout", "stderr", "text", "check", "timeout"}
        assert (
            kwargs["text"] is True
            and kwargs["check"] is False
            and kwargs["timeout"] == 30
        )
        if scenario in ("timeout", "interrupt"):
            kwargs["stdout"].write("partial receipt")
            kwargs["stderr"].write("partial diagnostic")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            raise KeyboardInterrupt("interrupted")
        data = copy.deepcopy(receipt)
        if scenario == "wrong_hash":
            data["source_sha256"][helper.PACKAGE + "/_native.so"] = "0" * 64
        elif scenario == "cleanup_failed":
            data["cleanup_errors"] = ["failed"]
        elif scenario == "wrong_schema":
            data["schema_version"] = True
        kwargs["stdout"].write(json.dumps(data))
        return subprocess.CompletedProcess(
            command, 1 if scenario == "helper_failed" else 0
        )

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)

    def sleep(duration):
        events.append(("sleep", duration))
        if scenario == "lead_interrupt" and duration == 0.5:
            raise KeyboardInterrupt("lead interrupted")

    monkeypatch.setattr(bench.time, "sleep", sleep)
    return events, manager, runner


def test_helper_receipt_validates_and_capture_preserves_unfiltered_evidence(
    environment, monkeypatch, tmp_path
):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = helper.experiment(ROOT + "/manifest.json")
    bench.validate_remote(receipt, manifest)
    events, manager, runner = configure(monkeypatch, receipt)
    output = tmp_path / "capture"
    result = bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    assert events == [
        ("sleep", 0.5),
        "ssh",
        ("sleep", 0.2),
        "stop",
        "save",
        ("export", [0]),
    ]
    manager.start_capture.assert_called_once_with(
        device_id=bench.DEVICE_ID,
        device_configuration={
            "enabled_digital_channels": [0],
            "digital_sample_rate": 100_000_000,
        },
    )
    runner.assert_called_once()
    assert result["collection_success"] is True
    assert (
        result["waveform_accepted"] is None
        and result["parity_pass"] is None
        and result["parity_evaluated"] is False
    )
    assert result["analysis_deferred"] is True and "accepted" not in result
    assert json.loads((output / "manifest.json").read_text()) == manifest
    assert json.loads((output / "results.json").read_text()) == result
    assert (output / "waveform.sal").read_bytes() == b"fake SAL evidence"
    assert (output / "digital_0.bin").read_bytes() == b"fake unfiltered edges"
    assert not (output / "analysis.json").exists()


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "lead_interrupt",
        "save_error",
        "helper_failed",
        "wrong_hash",
        "wrong_schema",
        "cleanup_failed",
        "simulation",
        "missing_raw",
    ],
)
def test_failures_keep_metadata_and_raw_evidence_without_acceptance(
    environment, monkeypatch, tmp_path, scenario
):
    receipt = helper.experiment(ROOT + "/manifest.json")
    events, _manager, runner = configure(monkeypatch, receipt, scenario)
    output = tmp_path / "capture"
    with pytest.raises((RuntimeError, ValueError, KeyboardInterrupt)):
        bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    acquisition = json.loads((output / "acquisition.json").read_text())
    result = json.loads((output / "results.json").read_text())
    assert result["collection_success"] is False and result["receipt_validation_error"]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    if scenario == "simulation":
        runner.assert_not_called()
        assert events == []
    else:
        assert "stop" in events and "save" in events and ("export", [0]) in events
        assert ("sleep", 0.2) in events
    if scenario in ("timeout", "interrupt"):
        assert (output / "remote.stdout").read_text() == "partial receipt"
        assert (output / "remote.stderr").read_text() == "partial diagnostic"
        assert acquisition["remote_returncode"] == (
            124 if scenario == "timeout" else None
        )
        assert acquisition["primary_error"]
    if scenario == "save_error":
        assert acquisition["evidence_errors"] == ["save_capture: OSError: save failed"]
    assert not (output / "analysis.json").exists()


@pytest.mark.parametrize(
    "root,python",
    [
        ("/tmp", PYTHON),
        (ROOT + "/../other", PYTHON),
        (ROOT, "/usr/bin/python3"),
        (ROOT, PYTHON + ";echo unsafe"),
        (ROOT, "/tmp/blinka-pwm-oct6.other/venv/bin/python"),
    ],
)
def test_invalid_remote_paths_refuse_before_output_or_ssh(
    environment, monkeypatch, tmp_path, root, python
):
    receipt = helper.experiment(ROOT + "/manifest.json")
    _events, _manager, runner = configure(monkeypatch, receipt)
    with pytest.raises(ValueError):
        bench.capture_test(
            tmp_path / "capture", root, python, tmp_path / "manifest.json"
        )
    assert not (tmp_path / "capture").exists()
    runner.assert_not_called()


def test_local_source_manifest_mismatch_refuses_before_capture(
    environment, monkeypatch, tmp_path
):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = helper.experiment(ROOT + "/manifest.json")
    _events, _manager, runner = configure(monkeypatch, receipt)
    manifest["source_sha256"][helper.PACKAGE + "/__init__.py"] = "0" * 64
    with pytest.raises(ValueError, match="local production"):
        bench.capture_test(
            tmp_path / "capture", ROOT, PYTHON, tmp_path / "manifest.json"
        )
    assert not (tmp_path / "capture").exists()
    runner.assert_not_called()


@pytest.mark.parametrize(
    "field",
    [
        "flag",
        "inherited",
        "enabled",
        "cleanup",
        "request",
        "source",
        "short_dwell",
        "signal",
        "event",
    ],
)
def test_validator_rejects_malformed_safety_provenance(environment, field):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = helper.experiment(ROOT + "/manifest.json")
    if field == "flag":
        receipt["runtime_flags"]["shared"] = 0
    elif field == "inherited":
        receipt["inherited_environment"]["BLINKA_PWM_SHARED"] = "1"
    elif field == "enabled":
        receipt["phases"][0]["api_state"]["enabled"] = True
    elif field == "cleanup":
        receipt["cleanup_final_readback"]["gpio_level"] = False
    elif field == "request":
        receipt["owned_request"]["offsets"] = [23]
    elif field == "source":
        receipt["source_sha256"][helper.PACKAGE + "/_native.so"] = "0" * 64
    elif field == "short_dwell":
        receipt["phases"][0]["end_ns"] = receipt["phases"][0]["stable_begin_ns"] + 1
    elif field == "signal":
        receipt["signals_received"] = [15]
    else:
        receipt["events"].pop()
    with pytest.raises(ValueError):
        bench.validate_remote(receipt, manifest)


def test_output_directory_is_exclusive(environment, monkeypatch, tmp_path):
    receipt = helper.experiment(ROOT + "/manifest.json")
    _events, _manager, runner = configure(monkeypatch, receipt)
    output = tmp_path / "capture"
    output.mkdir()
    sentinel = output / "previous"
    sentinel.write_text("keep")
    with pytest.raises(FileExistsError):
        bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    assert sentinel.read_text() == "keep"
    runner.assert_not_called()


def test_json_parser_rejects_duplicates_and_nonfinite():
    with pytest.raises(ValueError):
        bench.read_json('{"success":true,"success":false}')
    with pytest.raises(ValueError):
        bench.read_json('{"value":NaN}')
