"""Offline raw-edge and predeclared comparison tests: no SSH or hardware."""

import copy
import json
import struct
import zipfile
from pathlib import Path

import analyze_native_pwm_half50 as analysis
import native_pwm_half50_eval as helper
import pytest
import test_native_pwm_half50_eval as helper_fakes

environment = helper_fakes.environment
ROOT = helper_fakes.ROOT
LAB = Path(__file__).parent


def half50_edges(recovery_count=19):
    edges = []
    for index in range(20):
        rise = 0.7 + index * 0.02
        edges.extend((rise, rise + analysis.NATIVE_HIGH_TARGET_US / 1e6))
    edges.extend((1.1, 1.41))
    for index in range(recovery_count):
        rise = 1.42 + index * 0.02
        edges.extend((rise, rise + analysis.NATIVE_HIGH_TARGET_US / 1e6))
    return edges


def facts(edges, capture="native-first"):
    waveform = {"initial_state": 0, "final_state": 0, "edge_count": len(edges)}
    return {
        "capture": capture,
        "mode": analysis.MODE,
        "backend": analysis.BACKEND,
        "waveform": waveform,
        "physical": analysis.waveform_facts(waveform, edges),
        "caller_updates": [
            {"scope": scope, "caller_duration_us": 1.0} for scope in analysis.SCOPES
        ],
        "phase_api_update_durations_us": [],
    }


@pytest.fixture
def capture(environment, tmp_path):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = helper.experiment(ROOT + "/manifest.json")
    metadata = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": analysis.MODE,
        "backend": analysis.BACKEND,
        "sequence_marker": helper.SEQUENCE_MARKER,
        "sample_rate_hz": 100_000_000,
        "production_backend_unchanged": True,
        "outputs": [{"gpio": 18, "saleae_channel": 0, "backend": analysis.BACKEND}],
        "remote": receipt,
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": True,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
    }
    acquisition = {
        "mode": analysis.MODE,
        "backend": analysis.BACKEND,
        "remote_root": ROOT,
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None,
        "evidence_errors": [],
    }
    for name, value in (
        ("manifest.json", manifest),
        ("results.json", metadata),
        ("remote.stdout", receipt),
        ("acquisition.json", acquisition),
    ):
        (tmp_path / name).write_text(json.dumps(value))
    sal = {
        "data": {
            "legacySettings": {
                "enabledChannels": [{"type": "Digital", "index": 0}],
                "sampleRate": {"digital": 100_000_000},
                "glitchFilter": {"enabled": False, "channels": []},
            },
            "legacyDevice": {"isSimulation": False, "deviceId": "81F8C2631DF5BF30"},
        }
    }
    with zipfile.ZipFile(tmp_path / "waveform.sal", "w") as archive:
        archive.writestr("meta.json", json.dumps(sal))
    edges = half50_edges()
    (tmp_path / "digital_0.bin").write_bytes(
        b"<SALEAE>"
        + struct.pack("<iiIddQ", 0, 0, 0, 0.0, 2.6, len(edges))
        + struct.pack(f"<{len(edges)}d", *edges)
    )
    return tmp_path, edges


@pytest.mark.parametrize("recovery_count", [19, 20])
def test_exact_small_protocol_keeps_all_edges_and_accepts_extra_recovery_pulse(
    recovery_count,
):
    edges = half50_edges(recovery_count)
    report = facts(edges)
    result = analysis.provisional_checks(report)
    assert result["flags_to_investigate"] == []
    assert report["waveform"]["transition_seconds"] == edges
    assert len(report["physical"]["all_high_runs"]) == 21 + recovery_count
    assert len(report["physical"]["all_interior_low_runs"]) == 20 + recovery_count
    assert result["metrics"][
        "max_absolute_high_deviation_from_native_target_us"
    ] == pytest.approx(0, abs=1e-8)
    assert result["metrics"][
        "max_absolute_high_deviation_from_common_10000us_reference_us"
    ] == pytest.approx(0.152590218967, abs=1e-8)
    assert "parity_pass" not in result and "accepted" not in result


def test_10ns_hold_dip_is_retained_and_flagged_not_merged():
    edges = half50_edges()
    edges[41:41] = [1.25, 1.25000001]
    report = facts(edges)
    result = analysis.provisional_checks(report)
    assert report["waveform"]["transition_seconds"] == edges
    assert len(report["physical"]["constant_high_holds"]) == 2
    assert report["physical"]["sub_microsecond_low_runs"][0][
        "width_ns"
    ] == pytest.approx(10)
    assert "continuous_high_runs" in result["flags_to_investigate"]
    assert "sub_microsecond_interior_low_runs" in result["flags_to_investigate"]
    assert (
        "max_absolute_interior_low_deviation_from_10000us_reference_us"
        in result["flags_to_investigate"]
    )


def test_unmatched_boundary_pulse_is_included_in_deviation_and_period_statistics():
    edges = half50_edges()
    edges[39] = edges[38] + 40e-6
    report = facts(edges)
    result = analysis.provisional_checks(report)
    assert report["physical"]["unmatched_high_runs"][0]["pair_index"] == 19
    assert result["metrics"]["all_short_high_us"]["count"] == 39
    assert result["metrics"]["all_short_high_region_rise_to_rise_us"]["count"] == 37
    assert result["metrics"][
        "max_absolute_high_deviation_from_common_10000us_reference_us"
    ] == pytest.approx(9960)
    assert "unmatched_high_runs" in result["flags_to_investigate"]
    assert "group_topology_matches_half50_hold_half50" in result["flags_to_investigate"]
    assert (
        "max_absolute_high_deviation_from_common_10000us_reference_us"
        in result["flags_to_investigate"]
    )


def test_setter_return_flag_is_separate_from_electrical_observation():
    report = facts(half50_edges())
    report["caller_updates"][1]["caller_duration_us"] = 12.341
    result = analysis.provisional_checks(report)
    assert result["flags_to_investigate"] == ["caller_setter_duration.high50"]
    flagged = [
        item for item in result["checks"] if not item["within_predeclared_limit"]
    ]
    assert flagged[0]["domain"] == "caller_return_not_electrical_latency"


def test_extra_complete_initial_cycle_is_retained_and_predeclared_counts_stay_frozen():
    edges = half50_edges(20)
    edges[:0] = [0.68, 0.68 + analysis.NATIVE_HIGH_TARGET_US / 1e6]
    report = facts(edges)
    result = analysis.provisional_checks(report)
    assert report["waveform"]["transition_seconds"] == edges
    assert result["metrics"]["initial_pwm_high_count"] == 21
    assert result["metrics"]["edge_count"] == 84
    assert result["flags_to_investigate"] == ["initial_pwm_high_count", "edge_count"]


def test_raw_native_capture_validates_receipts_and_keeps_target_and_timing_separate(
    capture,
):
    directory, edges = capture
    report = analysis.analyze(directory)
    assert report["waveform"]["transition_seconds"] == edges
    assert report["saved_capture_settings"]["glitch_filter_enabled"] is False
    assert (
        report["quantization"]["native_high_target_us"]
        == analysis.NATIVE_HIGH_TARGET_US
    )
    assert len(report["caller_updates"]) == 4
    assert len(report["phase_api_update_durations_us"]) == 5
    assert report["provisional_comparison"]["flags_to_investigate"] == []
    assert "no command-to-edge latency claim" in report["clock_alignment"]
    assert report["caller_timing_includes_instrumentation"] is True
    assert "parity_pass" not in report and "accepted" not in report
    assert not (directory / "analysis.json").exists()


@pytest.mark.parametrize(
    "file,key,value,match",
    [
        ("results.json", "collection_success", False, "successful native collection"),
        ("results.json", "schema_version", True, "successful native collection"),
        ("results.json", "remote_returncode", True, "successful native collection"),
        ("results.json", "parity_pass", True, "successful native collection"),
        ("results.json", "sample_rate_hz", 1_000_000, "host/sample rate"),
        ("acquisition.json", "primary_error", "failed", "acquisition failed"),
        ("acquisition.json", "evidence_errors", ["missing raw"], "acquisition failed"),
        ("acquisition.json", "remote_root", "/tmp/wrong", "root/lead/tail"),
    ],
)
def test_native_capture_evidence_failures_are_not_waveform_success(
    capture, file, key, value, match
):
    directory, _edges = capture
    data = json.loads((directory / file).read_text())
    data[key] = value
    (directory / file).write_text(json.dumps(data))
    with pytest.raises(ValueError, match=match):
        analysis.analyze(directory)


def test_native_manifest_remote_mismatch_is_rejected_before_waveform(capture):
    directory, _edges = capture
    data = json.loads((directory / "manifest.json").read_text())
    data["source_sha256"][helper.PACKAGE + "/_native.so"] = "b" * 64
    (directory / "manifest.json").write_text(json.dumps(data))
    with pytest.raises(ValueError, match="Exact manifest"):
        analysis.analyze(directory)


def test_predeclared_plan_cannot_be_relaxed_after_capture(capture):
    directory, _edges = capture
    plan = json.loads((LAB / analysis.PLAN_NAME).read_text())
    plan["provisional_checks"][
        "max_absolute_high_deviation_from_common_10000us_reference_us"
    ] = 1_000
    path = directory / "relaxed-plan.json"
    path.write_text(json.dumps(plan))
    with pytest.raises(ValueError, match="exact predeclared"):
        analysis.analyze(directory, path)


def test_two_baseline_reports_reproduce_exactly_and_pair_remains_narrow():
    baselines = [
        analysis.analyze_baseline(LAB / name) for name in analysis.BASELINE_NAMES
    ]
    for report in baselines:
        assert report == json.loads(
            (LAB / report["capture"] / "analysis.json").read_text()
        )
    first = facts(half50_edges())
    second = copy.deepcopy(first)
    second["capture"] = "native-repeat"
    paired = analysis.compare_paired([first, second], baselines)
    assert all(
        not item["flags_to_investigate"] for item in paired["native_comparisons"]
    )
    assert [item["metrics"]["edge_count"] for item in paired["baseline_metrics"]] == [
        80,
        80,
    ]
    assert paired["overall_backend_parity_established"] is False
    assert paired["electrical_command_latency_measured"] is False
    assert "parity_pass" not in paired


def test_pair_requires_two_distinct_native_captures_and_exact_baseline_pair():
    baselines = [
        analysis.analyze_baseline(LAB / name) for name in analysis.BASELINE_NAMES
    ]
    native = facts(half50_edges())
    with pytest.raises(ValueError, match="distinct captures"):
        analysis.compare_paired([native, native], baselines)
    with pytest.raises(ValueError, match="original/repeat order"):
        analysis.compare_paired([native, native], list(reversed(baselines)))
