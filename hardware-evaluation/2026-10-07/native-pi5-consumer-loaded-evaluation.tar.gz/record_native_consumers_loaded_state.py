"""Read-only pre/postflight for the fixed two-run loaded consumer batch."""

import argparse
import hashlib
import json
import shlex
import subprocess
from pathlib import Path

import analyze_kernel_pwm_cpu_load as load_audit
import capture_native_pwm_consumers as collector
from record_native_updates_postflight import BOOT_ID, BOOT_SHA, REMOTE, REMOTE_PYTHON

LAB = Path(__file__).resolve().parent
ROOT = "/tmp/blinka-pwm-native-consumers.oPHx3J"
BENCH = "/tmp/blinka-pwm-oct6.F3SDcm"
CAPTURES = [f"oct7-pi5-native-consumers-loaded-r{repeat}" for repeat in (1, 2)]


def record(stage):
    if stage not in ("preflight", "postflight"):
        raise ValueError("Only fixed batch pre/postflight is supported")
    prior = collector.read_json(
        (LAB / "oct7-native-consumers-postflight.json").read_text()
    )
    manifest = collector.read_json(
        (LAB / "oct7-native-consumers-manifest.json").read_text()
    )
    collector.validate_local_manifest(manifest)
    if prior["accepted"] is not True:
        raise ValueError("Previous consumer postflight was not accepted")
    pids = set(prior["inspected_pids"])
    captures = CAPTURES if stage == "postflight" else []
    for name in captures:
        remote = collector.read_json((LAB / name / "remote.stdout").read_text())
        collector.validate_remote(remote, manifest)
        coordination = collector.read_json(
            (LAB / (name + ".consumers-coordination.json")).read_text()
        )
        if coordination["coordination_success"] is not True:
            raise ValueError("Loaded capture coordination was not successful")
        launch, completion = load_audit.parse_lines(
            (LAB / (name + ".load.stdout")).read_text(), 2, "load stdout"
        )
        workers = load_audit.validate_load(launch, completion)
        pids.add(remote["helper_pid"])
        pids.add(launch["launcher_pid"])
        pids.update(worker["pid"] for worker in workers)
    if not pids or not all(type(pid) is int and pid > 1 for pid in pids):
        raise ValueError("Invalid inspected PID set")
    output = LAB / f"oct7-native-consumers-loaded-{stage}.json"
    targets = [output, Path(str(output) + ".stdout"), Path(str(output) + ".stderr")]
    if any(path.exists() or path.is_symlink() for path in targets):
        raise ValueError("State targets must be fresh")
    extra = f"""
import sys
sys.path.insert(0, {ROOT!r})
import native_pwm_consumers_eval as consumer
sys.path.insert(0, {BENCH + "/cpu-load-eval"!r})
import kernel_pwm_cpu_load_eval as load
receipt['selected_source_sha256'] = consumer.source_hashes()
receipt['load_source_sha256'] = hashlib.sha256(pathlib.Path(load.__file__).read_bytes()).hexdigest()
receipt['worker_source_sha256'] = hashlib.sha256(load._worker_source().encode()).hexdigest()
print(json.dumps(receipt, indent=2))
"""
    code = REMOTE.replace("PIDS", repr(json.dumps(sorted(pids)))).replace(
        "print(json.dumps(receipt, indent=2))", extra
    )
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([REMOTE_PYTHON, "-c", code]),
    ]
    with targets[1].open("xb") as stdout, targets[2].open("xb") as stderr:
        result = subprocess.run(
            command, stdout=stdout, stderr=stderr, timeout=20, check=False
        )
    remote = (
        collector.read_json(targets[1].read_text()) if result.returncode == 0 else None
    )
    accepted = bool(
        remote
        and result.returncode == 0
        and remote["boot_id"] == BOOT_ID
        and remote["boot_config_sha256"] == BOOT_SHA
        and remote["selected_source_sha256"] == manifest["source_sha256"]
        and remote["load_source_sha256"] == load_audit.LOAD_SOURCE_SHA256
        and remote["worker_source_sha256"] == load_audit.WORKER_SOURCE_SHA256
        and remote["gpiochip"]["label"] == "pinctrl-rp1"
        and not any(remote["pid_exists"].values())
        and all(
            line["used"] is False and not line["consumer"] for line in remote["lines"]
        )
        and all(
            query["returncode"] == 0 and "| lo" in query["stdout"]
            for query in remote["pinctrl"]
        )
        and remote["throttled"]["returncode"] == 0
        and remote["throttled"]["stdout"].strip() == "throttled=0x0"
        and int(remote["temperature_millic"]) < 65000
        and remote["pwm"]["returncode"] == 0
        and "platform/1f0009c000.pwm" in remote["pwm"]["stdout"]
        and "cooling_fan" in remote["pwm"]["stdout"]
        and "1f00098000" not in remote["pwm"]["stdout"]
        and "pwm-gpio" not in remote["pwm"]["stdout"]
    )
    receipt = {
        "stage": stage,
        "capture_names": captures,
        "inspected_pids": sorted(pids),
        "ssh_returncode": result.returncode,
        "accepted": accepted,
        "remote": remote,
        "remote_read_only_code": code,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Read-only state/source check; not waveform acceptance, saturation or analog failsafe",
    }
    with output.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {
                "accepted": accepted,
                "pids_inspected": len(pids),
                "utc": remote["utc"] if remote else None,
                "temperature_millic": remote["temperature_millic"] if remote else None,
                "throttled": remote["throttled"] if remote else None,
            },
            indent=2,
        )
    )
    return 0 if accepted else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("preflight", "postflight"))
    raise SystemExit(record(parser.parse_args().stage))
