"""Exclusive loaded-consumer archive; byte-check and replay frozen evidence."""

import hashlib
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

import checkpoint_native_consumers as idle

LAB = Path(__file__).resolve().parent
ARCHIVE = (
    LAB.parent
    / "Adafruit_Blinka_Raspberry_Pi_PWM/hardware-evaluation/2026-10-07/native-pi5-consumer-loaded-evaluation.tar.gz"
)
PLAN = json.loads((LAB / "oct7-native-consumers-loaded-plan.json").read_text())
CAPTURES = PLAN["capture_order"]
EXCLUDE = set(idle.CAPTURES) | {
    "oct7-native-consumers-independent-audit.json",
    "oct7-native-consumers-final-report-audit.json",
    "oct7-native-consumers-notes.txt",
}
TARGETS = [name for name in idle.TARGETS if name not in EXCLUDE] + CAPTURES
TARGETS += [
    name + suffix
    for name in CAPTURES
    for suffix in (".load.stdout", ".load.stderr", ".consumers-coordination.json")
]
TARGETS += [
    "capture_native_pwm_consumers_loaded.py",
    "test_capture_native_pwm_consumers_loaded.py",
    "record_native_consumers_loaded_state.py",
    "record_kernel_pwm_cpu_load.py",
    "capture_kernel_pwm_loaded.py",
    "analyze_kernel_pwm_cpu_load.py",
    "kernel_pwm_cpu_load_eval.py",
    "test_analyze_kernel_pwm_cpu_load.py",
    "oct7-native-consumers-loaded-plan.json",
    "oct7-native-consumers-loaded-preflight.json",
    "oct7-native-consumers-loaded-preflight.json.stdout",
    "oct7-native-consumers-loaded-preflight.json.stderr",
    "oct7-native-consumers-loaded-postflight.json",
    "oct7-native-consumers-loaded-postflight.json.stdout",
    "oct7-native-consumers-loaded-postflight.json.stderr",
    "oct7-native-consumers-loaded-independent-audit.json",
    "oct7-native-consumers-loaded-final-report-audit.json",
    "oct7-native-consumers-loaded-independent-notes.txt",
    "checkpoint_native_consumers_loaded.py",
]
REPLAY = r"""
import json,pathlib,sys
sys.path.insert(0,sys.argv[1])
import analyze_native_pwm_consumers as analysis
import capture_native_pwm_consumers_loaded as loaded
root=pathlib.Path(sys.argv[1])
plan=json.loads((root/'oct7-native-consumers-loaded-plan.json').read_text())
manifest=json.loads((root/plan['manifest']).read_text())
loaded.source_hashes()
for name in plan['capture_order']:
    assert analysis.analyze(root/name)==json.loads((root/name/'analysis.json').read_text()),name
    receipt=json.loads((root/(name+'.consumers-coordination.json')).read_text())
    assert loaded.audit(name,plan['consumer_root'],plan['remote_python'],manifest)==receipt['overlap'],name
print(json.dumps({'consumer_reports_reproduced':2,'load_overlap_reports_reproduced':2}))
"""


def main():
    if (
        hashlib.sha256(
            (LAB / "oct7-native-consumers-loaded-plan.json").read_bytes()
        ).hexdigest()
        != "0a216d5da16a496315fbc0ea446bcb797e32c23b49ac37bc038683c89e93cf20"
    ):
        raise ValueError("Frozen loaded pre-capture plan changed")
    if len(TARGETS) != len(set(TARGETS)):
        raise ValueError("Duplicate recovery targets")
    files = {}
    for name in TARGETS:
        path = LAB / name
        if not path.exists() or path.is_symlink():
            raise ValueError("Missing or linked target: " + name)
        for member in [path] if path.is_file() else sorted(path.rglob("*")):
            if member.is_symlink() or not (member.is_file() or member.is_dir()):
                raise ValueError("Unsupported member: " + str(member))
            if member.is_file():
                key = str(member.relative_to(LAB))
                if key in files:
                    raise ValueError("Duplicate member: " + key)
                files[key] = hashlib.sha256(member.read_bytes()).hexdigest()
    pins = {
        "capture_native_pwm_consumers_loaded.py": PLAN["coordinator_sha256"],
        "test_capture_native_pwm_consumers_loaded.py": PLAN["coordinator_test_sha256"],
        "record_native_consumers_loaded_state.py": PLAN["state_recorder_sha256"],
        "oct7-native-consumers-loaded-preflight.json": PLAN["preflight_sha256"],
        PLAN["manifest"]: PLAN["manifest_sha256"],
        PLAN["unchanged_consumer_protocol_plan"]: PLAN[
            "unchanged_consumer_protocol_plan_sha256"
        ],
        "analyze_native_pwm_consumers.py": PLAN["unchanged_analyzer_sha256"],
    }
    if any(files[name] != digest for name, digest in pins.items()):
        raise ValueError("Pre-capture frozen source/evidence bytes changed")
    consumers = idle.helper.consumer_inventory()
    for key, path in consumers.items():
        if path.is_symlink() or not path.is_file():
            raise ValueError("Unsupported consumer source: " + key)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != idle.helper.CONSUMER_PINS[key]:
            raise ValueError("Consumer source changed: " + key)
        files["consumer-library-source/" + key] = digest
    with (
        ARCHIVE.open("xb") as stream,
        tarfile.open(fileobj=stream, mode="w:gz") as archive,
    ):
        for name in TARGETS:
            archive.add(LAB / name, arcname=name)
        for key, path in consumers.items():
            archive.add(path, arcname="consumer-library-source/" + key)
    extracted = Path(
        tempfile.mkdtemp(
            prefix="blinka-consumers-loaded-checkpoint-", dir="/private/tmp"
        )
    )
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if (
                path.is_absolute()
                or ".." in path.parts
                or not (member.isfile() or member.isdir())
            ):
                raise ValueError("Unsafe archive member: " + member.name)
        archive.extractall(extracted, filter="data")
    recovered = {
        str(path.relative_to(extracted)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in extracted.rglob("*")
        if path.is_file()
    }
    if recovered != files:
        raise ValueError("Archive file set/bytes differ")
    result = subprocess.run(
        [sys.executable, "-c", REPLAY, str(extracted)],
        cwd=extracted,
        capture_output=True,
        text=True,
        check=True,
    )
    report = {
        "archive": str(ARCHIVE),
        "size_bytes": ARCHIVE.stat().st_size,
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "top_level_targets": len(TARGETS) + 1,
        "regular_files": len(files),
        "safe_extraction": str(extracted),
        "all_file_bytes_match": True,
        "replay": json.loads(result.stdout),
        "replay_stderr": result.stderr,
        "scope": "Recovery of native-only functional-under-load evidence, not matched performance parity",
    }
    with (LAB / "oct7-native-consumers-loaded-checkpoint-verification.json").open(
        "x"
    ) as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
