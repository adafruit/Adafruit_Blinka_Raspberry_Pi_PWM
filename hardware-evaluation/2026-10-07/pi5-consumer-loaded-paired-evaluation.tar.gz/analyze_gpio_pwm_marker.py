"""Offline same-acquisition GPIO18/GPIO23 facts, not exact adoption latency.

Every edge is retained. GPIO23 pulses are paired only by validated setter
ordinal, including the separately labeled native safety-cleanup pulse. Long
high widths are descriptive; no generic width bin silently assigns commands.
"""

import argparse
import bisect
import hashlib
import itertools
import json
import zipfile
from pathlib import Path

import capture_gpio_pwm_marker as collector
from analyze_kernel_pwm_inverse import read_continuous, require

PLAN_NAME = "oct7-gpio-pwm-marker-plan.json"
PLAN_SHA256 = "bf5f530a0e6c8d8c4956d307ccfb86ba386453eee166dddef5d6205178f4f63f"
LONG_HIGH_US = 30_000


def read_plan(path=None):
    path = Path(path) if path is not None else Path(__file__).with_name(PLAN_NAME)
    raw = path.read_bytes()
    require(
        hashlib.sha256(raw).hexdigest() == PLAN_SHA256, "Frozen marker plan changed"
    )
    plan = collector.read_json(raw.decode())
    require(
        [list(row) for row in collector.helper.SEQUENCE] == plan["sequence"],
        "Frozen marker sequence changed",
    )
    for name, expected in plan["helpers"].items():
        source = Path(__file__).with_name(name + ".py")
        require(
            hashlib.sha256(source.read_bytes()).hexdigest() == expected,
            "Marker source changed: " + name,
        )
    return plan


def validate_sal(path):
    with zipfile.ZipFile(path) as archive:
        data = collector.read_json(archive.read("meta.json").decode())["data"]
    settings, device = data["legacySettings"], data["legacyDevice"]
    require(
        settings["enabledChannels"]
        == [{"type": "Digital", "index": 0}, {"type": "Digital", "index": 1}]
        and settings["sampleRate"]["digital"] == 100_000_000
        and settings["glitchFilter"] == {"enabled": False, "channels": []}
        and device["isSimulation"] is False,
        "Require physical channels0/1, 100MSa/s and no glitch filtering in saved SAL",
    )
    identifier = str(device["deviceId"])
    require(
        int(identifier, 10 if identifier.isdigit() else 16)
        == int("81F8C2631DF5BF30", 16),
        "Wrong saved physical device",
    )
    return {
        "channels": [0, 1],
        "sample_rate_hz": 100_000_000,
        "physical_device": True,
        "glitch_filter": False,
    }


def channel_facts(waveform, edges):
    require(
        len(edges) % 2 == 0
        and waveform["initial_state"] == waveform["final_state"] == 0,
        "Complete low-start/end channel required",
    )
    highs = [
        {
            "pair_index": index,
            "rise_seconds": rise,
            "fall_seconds": fall,
            "width_us": (fall - rise) * 1e6,
        }
        for index, (rise, fall) in enumerate(zip(edges[::2], edges[1::2]))
    ]
    lows = [
        {
            "preceding_pair_index": a["pair_index"],
            "following_pair_index": b["pair_index"],
            "fall_seconds": a["fall_seconds"],
            "rise_seconds": b["rise_seconds"],
            "width_us": (b["rise_seconds"] - a["fall_seconds"]) * 1e6,
        }
        for a, b in itertools.pairwise(highs)
    ]
    intervals = [
        {
            "preceding_pair_index": a["pair_index"],
            "following_pair_index": b["pair_index"],
            "rise_to_rise_us": (b["rise_seconds"] - a["rise_seconds"]) * 1e6,
        }
        for a, b in itertools.pairwise(highs)
    ]
    return {
        "waveform": {**waveform, "transition_seconds": list(edges)},
        "all_high_runs": highs,
        "all_interior_low_runs": lows,
        "all_adjacent_rise_intervals": intervals,
        "descriptive_high_runs_over_30ms": [
            high for high in highs if high["width_us"] > LONG_HIGH_US
        ],
        "sub_microsecond_low_runs": [low for low in lows if low["width_us"] < 1],
        "long_high_width_does_not_prove_command_or_application": True,
    }


def level_at(edges, seconds):
    """At tied samples preserve both possible sides rather than choose ordering."""
    before, after = (
        bisect.bisect_left(edges, seconds),
        bisect.bisect_right(edges, seconds),
    )
    return {
        "immediately_before": before % 2,
        "immediately_after": after % 2,
        "pwm_edge_at_same_timestamp": before != after,
    }


def relative_interval(edge, rise, fall):
    return {
        "pwm_edge_seconds": edge,
        "edge_minus_marker_fall_us": (edge - fall) * 1e6,
        "edge_minus_marker_rise_us": (edge - rise) * 1e6,
        "signed_observed_interval_us": [(edge - fall) * 1e6, (edge - rise) * 1e6],
        "scope": "Physical PWM edge relative to physical marker bracket; not calibrated application latency",
    }


def marker_facts(pwm, marker, setter_events):
    pulses = marker["all_high_runs"]
    require(
        len(pulses) == len(setter_events),
        "Marker pulse/setter count mismatch; ordinal pairing refused",
    )
    require(
        all(type(event.get("ordinal")) is int for event in setter_events)
        and [event.get("ordinal") for event in setter_events]
        == list(range(len(pulses))),
        "Exact setter ordinals required",
    )
    edges = pwm["waveform"]["transition_seconds"]
    observations, frequency, duty = [], 50, 0
    for index, (pulse, event) in enumerate(zip(pulses, setter_events)):
        rise, fall = pulse["rise_seconds"], pulse["fall_seconds"]
        left = (
            pulses[index - 1]["fall_seconds"]
            if index
            else pwm["waveform"]["begin_seconds"]
        )
        right = (
            pulses[index + 1]["rise_seconds"]
            if index + 1 < len(pulses)
            else pwm["waveform"]["end_seconds"]
        )
        before = {"frequency": frequency, "duty_u16": duty}
        operation, arguments = event["operation"], event["arguments"]
        frequency, duty = arguments["frequency"], arguments["duty_u16"]
        start, end = level_at(edges, rise), level_at(edges, fall)
        lower = max(0, bisect.bisect_left(edges, left) - 1)
        upper = min(len(edges), bisect.bisect_right(edges, right) + 1)
        nearby_highs = [
            high
            for high in pwm["all_high_runs"]
            if high["fall_seconds"] >= left and high["rise_seconds"] <= right
        ]
        next_falls = [
            high["fall_seconds"]
            for high in pwm["all_high_runs"]
            if rise <= high["fall_seconds"] < right
        ]
        item = {
            "ordinal": index,
            "category": event["category"],
            "scope": event["scope"],
            "phase_index": event["phase_index"],
            "operation": operation,
            "arguments": arguments,
            "logical_state_before": before,
            "logical_state_after": {"frequency": frequency, "duty_u16": duty},
            "marker_high_run": pulse,
            "pwm_level_at_marker_start": start,
            "pwm_level_at_marker_end": end,
            "nearby_window_seconds": [left, right],
            "nearby_pwm_edges": [
                {
                    "edge_index": edge_index,
                    "seconds": edges[edge_index],
                    "direction": "rise" if edge_index % 2 == 0 else "fall",
                    "offset_from_marker_rise_us": (edges[edge_index] - rise) * 1e6,
                    "offset_from_marker_fall_us": (edges[edge_index] - fall) * 1e6,
                }
                for edge_index in range(lower, upper)
            ],
            "nearby_complete_pwm_high_runs": nearby_highs,
            "nearby_pwm_adjacent_rise_intervals": [
                interval
                for interval in pwm["all_adjacent_rise_intervals"]
                if interval["preceding_pair_index"]
                in {high["pair_index"] for high in nearby_highs}
                and interval["following_pair_index"]
                in {high["pair_index"] for high in nearby_highs}
            ],
            "caller_duration_pi_us": (event["caller_end_ns"] - event["caller_begin_ns"])
            / 1000,
            "instrumented_setter_event_duration_pi_us": (
                event["end_ns"] - event["begin_ns"]
            )
            / 1000,
            "sustained_high_rise_observation": None,
            "application_instant_identified": False,
        }
        if event["category"] != "sequence":
            item["interpretation"] = (
                "Separately paired safety cleanup marker, not a sequence application observation"
            )
        elif (
            operation == "PWMOut.duty_cycle"
            and 0 < before["duty_u16"] < 65535
            and duty == 65535
        ):
            candidates = [
                high
                for high in nearby_highs
                if rise <= high["rise_seconds"] < right
                and high["fall_seconds"] >= fall
                and high["width_us"] > LONG_HIGH_US
            ]
            item["sustained_high_candidate_pair_indices"] = [
                high["pair_index"] for high in candidates
            ]
            if (
                start["immediately_before"] != 0
                or start["immediately_after"] != 0
                or start["pwm_edge_at_same_timestamp"]
            ):
                item["interpretation"] = (
                    "Ambiguous ordinary-to-high: PWM already high or sample-tied at marker rise"
                )
            elif len(candidates) != 1:
                item["interpretation"] = (
                    "No unique subsequent sustained-high run identifiable before the next marker"
                )
            else:
                high = candidates[0]
                item["sustained_high_rise_observation"] = {
                    "pwm_pair_index": high["pair_index"],
                    "complete_high_width_us": high["width_us"],
                    **relative_interval(high["rise_seconds"], rise, fall),
                }
                item["interpretation"] = (
                    "Unambiguous low-at-marker-start with one subsequent >30ms sustained-high run; its start is an observed physical edge, not proof of adoption instant"
                )
        elif operation == "PWMOut.duty_cycle" and duty == 0:
            item["interpretation"] = (
                "Already-low-to-zero can leave no edge; a later fall may be ordinary pulse completion, not exact adoption"
            )
            item["first_subsequent_fall_observation"] = (
                relative_interval(next_falls[0], rise, fall) if next_falls else None
            )
        elif (
            operation == "PWMOut.duty_cycle"
            and before["duty_u16"] == 65535
            and 0 < duty < 65535
        ):
            item["interpretation"] = (
                "High-to-ordinary first fall includes resumed pulse-high duration; not exact adoption/start delay"
            )
            item["first_subsequent_fall_observation"] = (
                relative_interval(next_falls[0], rise, fall) if next_falls else None
            )
        else:
            item["interpretation"] = (
                "Nearby waveform facts only; first arbitrary edge is not labeled electrical application"
            )
        observations.append(item)
    return observations


def analyze(directory, plan_path=None):
    directory = Path(directory)
    plan = read_plan(plan_path)
    metadata = collector.read_json((directory / "results.json").read_text())
    acquisition = collector.read_json((directory / "acquisition.json").read_text())
    remote = collector.read_json((directory / "remote.stdout").read_text())
    manifest = collector.read_json((directory / "manifest.json").read_text())
    backend = metadata.get("backend_selector")
    require(
        manifest == plan["manifest"],
        "Capture eighteen-source manifest differs from frozen plan",
    )
    collector.validate_remote(remote, backend, manifest)
    require(
        metadata.get("remote") == remote, "Collector remote receipt/metadata mismatch"
    )
    require(
        type(metadata.get("schema_version")) is int
        and metadata["schema_version"] == 1
        and metadata.get("host") == "test-pi5.local"
        and metadata.get("mode") == collector.MODE
        and metadata.get("sequence_marker") == collector.SEQUENCE_MARKER
        and metadata.get("backend") == collector.BACKEND_NAMES[backend]
        and metadata.get("sample_rate_hz") == 100_000_000
        and metadata.get("production_backend_unchanged") is True
        and metadata.get("collection_success") is True
        and type(metadata.get("remote_returncode")) is int
        and metadata["remote_returncode"] == 0
        and metadata.get("parity_evaluated") is False
        and metadata.get("analysis_deferred") is True
        and "parity_pass" in metadata
        and metadata["parity_pass"] is None
        and "waveform_accepted" in metadata
        and metadata["waveform_accepted"] is None
        and metadata.get("outputs")
        == [
            {
                "gpio": 18,
                "saleae_channel": 0,
                "backend": collector.BACKEND_NAMES[backend],
            },
            {"gpio": 23, "saleae_channel": 1, "backend": "gpiod-marker"},
        ],
        "Successful unchanged two-channel marker collection required without waveform verdict",
    )
    require(
        acquisition.get("mode") == collector.MODE
        and acquisition.get("backend") == collector.BACKEND_NAMES[backend]
        and acquisition.get("backend_selector") == backend
        and acquisition.get("remote_root") == plan["remote_root"]
        and remote["manifest_path"] == acquisition["remote_root"] + "/manifest.json"
        and type(acquisition.get("remote_returncode")) is int
        and acquisition["remote_returncode"] == 0
        and "primary_error" in acquisition
        and acquisition["primary_error"] is None
        and acquisition.get("evidence_errors") == []
        and acquisition.get("local_timing_not_aligned_to_pi_or_saleae") is True
        and all(
            item.get("pre_helper_lead_seconds") == 0.5
            and item.get("post_helper_tail_seconds") == 0.2
            for item in (metadata, acquisition)
        ),
        "Marker acquisition/root/lead/tail/evidence validation failed",
    )
    settings = validate_sal(directory / "waveform.sal")
    pwm_waveform, pwm_edges = read_continuous(directory / "digital_0.bin")
    marker_waveform, marker_edges = read_continuous(directory / "digital_1.bin")
    require(
        pwm_waveform["begin_seconds"] == marker_waveform["begin_seconds"]
        and pwm_waveform["end_seconds"] == marker_waveform["end_seconds"],
        "Both channels must share identical acquisition bounds",
    )
    pwm, marker = (
        channel_facts(pwm_waveform, pwm_edges),
        channel_facts(marker_waveform, marker_edges),
    )
    observations = marker_facts(pwm, marker, remote["setter_events"])
    return {
        "schema_version": 1,
        "capture": directory.name,
        "backend": backend,
        "mode": collector.MODE,
        "plan_sha256": PLAN_SHA256,
        "source_manifest": manifest,
        "saved_capture_settings": settings,
        "collection_receipts_validated": True,
        "strict_marker_ordinal_pairing_validated": True,
        "pwm_channel": pwm,
        "marker_channel": marker,
        "marker_observations": observations,
        "setter_events": remote["setter_events"],
        "phases": remote["phases"],
        "observed_sustained_high_rise_count": sum(
            item["sustained_high_rise_observation"] is not None for item in observations
        ),
        "sequence_marker_count": sum(
            item["category"] == "sequence" for item in observations
        ),
        "cleanup_marker_count": sum(
            item["category"] != "sequence" for item in observations
        ),
        "waveform_accepted": None,
        "parity_pass": None,
        "overall_backend_parity_established": False,
        "no_transition_trimming_or_glitch_filtering": True,
        "pi_saleae_clocks_aligned": False,
        "physical_channels_share_acquisition_timestamps": True,
        "gpio_driver_and_threshold_skew_calibrated": False,
        "timebase_calibrated": False,
        "nominal_sampling_interval_ns": 10,
        "nominal_two_edge_sampling_allowance_us": 0.02,
        "analog_or_subsample_glitches_excluded": False,
        "application_latency_measured": False,
        "limitation": "Finite uncalibrated digital-threshold edge observations. Marker GPIO writes bracket the caller but are not exact invocation timestamps. Same-acquisition channel timestamps support physical marker-relative intervals, not Pi/Saleae clock alignment or calibrated application latency. Already-high/low and pulse-recovery cases can be ambiguous. Marking changes caller overhead. Long-high widths are descriptive, not command proof; all edges and complete high runs remain visible.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", type=Path, nargs="+")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output-name", default="marker-analysis.json")
    args = parser.parse_args(argv)
    require(
        Path(args.output_name).name == args.output_name
        and args.output_name not in ("", ".", ".."),
        "Output must be a filename",
    )
    outputs = [directory / args.output_name for directory in args.directories]
    require(
        len(set(outputs)) == len(outputs)
        and all(not output.exists() and not output.is_symlink() for output in outputs),
        "Exclusive outputs must be fresh",
    )
    reports = [analyze(directory, args.plan) for directory in args.directories]
    for output, report in zip(outputs, reports):
        with output.open("x") as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write("\n")
    print(
        json.dumps(
            [
                {
                    "capture": report["capture"],
                    "pwm_edges": report["pwm_channel"]["waveform"]["edge_count"],
                    "marker_count": len(report["marker_observations"]),
                    "observed_sustained_high_rise_count": report[
                        "observed_sustained_high_rise_count"
                    ],
                }
                for report in reports
            ]
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
