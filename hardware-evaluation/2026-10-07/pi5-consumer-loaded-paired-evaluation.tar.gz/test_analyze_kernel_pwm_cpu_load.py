"""Offline fakes only: never start workers or access GPIO/sysfs."""

import copy
import json

import pytest

import analyze_kernel_pwm_cpu_load as audit


def documents():
    base = {
        "schema_version": 1,
        "mode": "cpu-only-fixed-two-workers",
        "launcher_pid": 101,
        "worker_count": 2,
        "worker_duration_seconds": 10,
        "source_sha256": audit.LOAD_SOURCE_SHA256,
        "worker_source_sha256": audit.WORKER_SOURCE_SHA256,
        "gpio_writes": False,
        "pwm_sysfs_access": False,
        "kernel_configuration_changes": False,
        "begin_ns": 1_000_000_000,
    }
    records = []
    for index in range(2):
        records.append(
            {
                "index": index,
                "pid": 102 + index,
                "popen_begin_ns": 1_010_000_000 + index * 10_000_000,
                "popen_end_ns": 1_019_000_000 + index * 10_000_000,
                "returncode": None,
                "completed_ns": None,
                "reaped": False,
                "worker_receipts": [],
            }
        )
    launch = {
        **base,
        "event": "load_launched",
        "receipt_ns": 1_040_000_000,
        "started_worker_count": 2,
        "launch_complete": True,
        "owned_workers": copy.deepcopy(records),
    }
    for index, record in enumerate(records):
        begin = 1_100_000_000 + index * 10_000_000
        reports = [
            {
                "event": "worker_started",
                "pid": record["pid"],
                "begin_ns": begin,
                "duration_seconds": 10,
            },
            {
                "event": "worker_completed",
                "pid": record["pid"],
                "begin_ns": begin,
                "end_ns": begin + 10_001_000_000,
                "iterations": 41000 + index,
                "duration_seconds": 10,
            },
        ]
        record.update(
            returncode=0,
            completed_ns=11_200_000_000 + index,
            reaped=True,
            stderr="",
            worker_receipts=reports,
            stdout="".join(json.dumps(item) + "\n" for item in reports),
        )
    completion = {
        **base,
        "event": "load_completed",
        "end_ns": 11_210_000_000,
        "receipt_boundary": "after worker cleanup; signals arriving during receipt emission can still fail exit status",
        "success": True,
        "signals_received": [],
        "cleanup_errors": [],
        "primary_error": None,
        "owned_workers": records,
    }
    remote = {
        "schema_version": 1,
        "mode": "direct",
        "helper_pid": 201,
        "begin_ns": 2_000_000_000,
        "end_ns": 6_000_000_000,
        "sysfs_released": True,
        "low_confirmed": True,
        "cleanup_errors": [],
        "burner_pids": [],
        "phases": [
            {
                "name": "initial",
                "generation": 1,
                "begin_ns": 2_100_000_000,
                "transition_begin_ns": 2_100_000_000,
                "stable_begin_ns": 2_140_000_000,
                "end_ns": 2_440_000_000,
                "readback_end_ns": 2_441_000_000,
            },
            {
                "name": "high",
                "generation": 1,
                "begin_ns": 2_442_000_000,
                "transition_begin_ns": 2_442_000_000,
                "stable_begin_ns": 2_482_000_000,
                "end_ns": 2_782_000_000,
                "readback_end_ns": 2_783_000_000,
            },
        ],
    }
    return launch, completion, remote


def inputs(tmp_path, launch=None, completion=None, remote=None):
    defaults = documents()
    launch = defaults[0] if launch is None else launch
    completion = defaults[1] if completion is None else completion
    remote = defaults[2] if remote is None else remote
    load = tmp_path / "case.load.stdout"
    load.write_text(json.dumps(launch) + "\n" + json.dumps(completion) + "\n")
    capture = tmp_path / "case"
    capture.mkdir()
    (capture / "remote.stdout").write_text(json.dumps(remote) + "\n")
    (capture / "results.json").write_text('{"original":true}\n')
    (capture / "digital_0.bin").write_bytes(b"original waveform")
    return load, capture


def sync_stdout(record):
    record["stdout"] = "".join(
        json.dumps(item) + "\n" for item in record["worker_receipts"]
    )


def test_valid_independent_overlap_and_explicit_limitations(tmp_path):
    load, capture = inputs(tmp_path)
    report = audit.analyze(load, capture)
    assert report["accepted"]
    assert report["all_phases_bracketed_by_each_worker"]
    assert report["entire_helper_bracketed_by_each_worker"]
    assert report["worker_count"] == 2
    assert report["workers"][0]["iterations"] == 41000
    assert report["workers"][0]["phase_overlaps"][0]["overlap_ns"] == 341_000_000
    assert report["pwm_helper_burner_pids"] == []
    assert report["recorder_exit_zero_required"]
    assert not report["recorder_exit_status_verified"]
    assert not report["pwm_helper_exit_status_verified"]
    assert not report["original_results_or_waveform_predicates_modified"]
    assert any("not CPU saturation" in value for value in report["limitations"])


@pytest.mark.parametrize("mode", audit.MODES)
def test_supported_modes(tmp_path, mode):
    launch, completion, remote = documents()
    remote["mode"] = mode
    load, capture = inputs(tmp_path, launch, completion, remote)
    assert audit.analyze(load, capture)["mode"] == mode


def test_missing_load_receipts_do_not_create_output(tmp_path):
    load, capture = inputs(tmp_path)
    load.unlink()
    with pytest.raises(FileNotFoundError):
        audit.write_analysis(load, capture)
    assert not (capture / audit.OUTPUT_NAME).exists()


@pytest.mark.parametrize("text", ["", "{}\n", "{}\n{}\n{}\n", "{}\n{}", "{}\n{\n"])
def test_missing_partial_extra_load_receipts(tmp_path, text):
    load, capture = inputs(tmp_path)
    load.write_text(text)
    with pytest.raises(ValueError):
        audit.write_analysis(load, capture)
    assert not (capture / audit.OUTPUT_NAME).exists()


@pytest.mark.parametrize(
    "key,value",
    [
        ("source_sha256", "0" * 64),
        ("worker_source_sha256", "f" * 64),
        ("mode", "custom-load"),
        ("schema_version", True),
        ("worker_count", 3),
        ("worker_count", 2.0),
        ("worker_duration_seconds", 6),
        ("gpio_writes", True),
        ("pwm_sysfs_access", True),
        ("kernel_configuration_changes", True),
    ],
)
@pytest.mark.parametrize("receipt_index", [0, 1])
def test_frozen_provenance_both_receipts(tmp_path, key, value, receipt_index):
    launch, completion, remote = documents()
    (launch, completion)[receipt_index][key] = value
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError, match="provenance mismatch"):
        audit.analyze(load, capture)


@pytest.mark.parametrize(
    "key,value",
    [
        ("success", False),
        ("success", 1),
        ("cleanup_errors", ["reap failed"]),
        ("cleanup_errors", None),
        ("signals_received", [15]),
        ("signals_received", None),
        ("primary_error", "timeout"),
        ("receipt_boundary", "before cleanup"),
        ("begin_ns", 1_000_000_001),
        ("launcher_pid", 999),
        ("end_ns", 1_000_000_000),
    ],
)
def test_failed_or_mismatched_completion(tmp_path, key, value):
    launch, completion, remote = documents()
    completion[key] = value
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError):
        audit.analyze(load, capture)


@pytest.mark.parametrize("mutation", ["count", "partial", "records", "false-reaped"])
def test_partial_launch_and_ownership(tmp_path, mutation):
    launch, completion, remote = documents()
    if mutation == "count":
        launch["started_worker_count"] = 1
    elif mutation == "partial":
        launch["launch_complete"] = False
    elif mutation == "records":
        launch["owned_workers"].pop()
    else:
        launch["owned_workers"][0]["reaped"] = True
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError):
        audit.analyze(load, capture)


@pytest.mark.parametrize(
    "key,value",
    [
        ("pid", 999),
        ("index", 1),
        ("returncode", -15),
        ("returncode", False),
        ("reaped", False),
        ("stderr", "failure"),
        ("stderr", None),
        ("completed_ns", 1),
        ("receipt_error", "bad JSON"),
        ("terminate_requested_ns", 11_000_000_000),
        ("kill_requested_ns", 11_000_000_000),
    ],
)
def test_worker_ownership_reap_and_cleanup_failures(tmp_path, key, value):
    launch, completion, remote = documents()
    completion["owned_workers"][0][key] = value
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError):
        audit.analyze(load, capture)


@pytest.mark.parametrize(
    "key,value",
    [
        ("pid", 999),
        ("pid", True),
        ("event", "other"),
        ("begin_ns", 1_000_000_000),
        ("end_ns", 11_099_999_999),
        ("duration_seconds", 6),
        ("iterations", 0),
        ("iterations", True),
    ],
)
def test_actual_worker_receipt_provenance_and_short_duration(tmp_path, key, value):
    launch, completion, remote = documents()
    record = completion["owned_workers"][0]
    record["worker_receipts"][1][key] = value
    sync_stdout(record)
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError):
        audit.analyze(load, capture)


def test_parsed_receipts_cannot_replace_actual_stdout_or_equal_bool(tmp_path):
    launch, completion, remote = documents()
    completion["owned_workers"][0]["worker_receipts"][1]["iterations"] = True
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError, match="raw/parsed receipt mismatch"):
        audit.analyze(load, capture)


def test_duplicate_worker_pids_and_pwm_identity_collision(tmp_path):
    launch, completion, remote = documents()
    remote["helper_pid"] = completion["owned_workers"][0]["pid"]
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError, match="identities collide"):
        audit.analyze(load, capture)
    launch["owned_workers"][1]["pid"] = launch["owned_workers"][0]["pid"]
    completion["owned_workers"][1]["pid"] = launch["owned_workers"][0]["pid"]
    with pytest.raises(ValueError, match="Duplicate"):
        audit.validate_load(launch, completion)


@pytest.mark.parametrize("target", ["load", "worker", "remote"])
def test_duplicate_json_keys_rejected(tmp_path, target):
    load, capture = inputs(tmp_path)
    if target == "load":
        load.write_text(
            load.read_text().replace(
                '"schema_version": 1', '"schema_version": 1, "schema_version": 1', 1
            )
        )
    elif target == "worker":
        launch, completion, remote = documents()
        record = completion["owned_workers"][0]
        record["stdout"] = record["stdout"].replace(
            '"pid": 102', '"pid": 102, "pid": 102', 1
        )
        load.write_text(json.dumps(launch) + "\n" + json.dumps(completion) + "\n")
    else:
        path = capture / "remote.stdout"
        path.write_text(
            path.read_text().replace(
                '"schema_version": 1', '"schema_version": 1, "schema_version": 1', 1
            )
        )
    with pytest.raises(ValueError, match="Duplicate JSON"):
        audit.analyze(load, capture)


def test_nonfinite_json_rejected(tmp_path):
    load, capture = inputs(tmp_path)
    load.write_text(
        load.read_text().replace('"begin_ns": 1000000000', '"begin_ns": NaN', 1)
    )
    with pytest.raises(ValueError, match="Non-finite JSON"):
        audit.analyze(load, capture)


def test_short_overlap_is_rejected_but_actual_intervals_retained(tmp_path):
    launch, completion, remote = documents()
    remote["begin_ns"] = 1_000_000_000
    remote["phases"][0]["begin_ns"] = 1_105_000_000
    remote["phases"][0]["transition_begin_ns"] = 1_105_000_000
    remote["phases"][0]["stable_begin_ns"] = 1_115_000_000
    load, capture = inputs(tmp_path, launch, completion, remote)
    report = audit.write_analysis(load, capture)
    assert not report["accepted"]
    assert report["rejection_reasons"] == ["Worker 1 did not bracket phase initial"]
    overlap = report["workers"][1]["phase_overlaps"][0]
    assert not overlap["bracketed"]
    assert overlap["start_margin_ns"] == -5_000_000
    assert overlap["overlap_ns"] == overlap["duration_ns"] - 5_000_000


def test_phase_coverage_not_confused_with_whole_helper(tmp_path):
    launch, completion, remote = documents()
    remote["begin_ns"] = 1_000_000_000
    remote["end_ns"] = 12_000_000_000
    load, capture = inputs(tmp_path, launch, completion, remote)
    report = audit.analyze(load, capture)
    assert report["accepted"]
    assert not report["entire_helper_bracketed_by_each_worker"]
    assert all(not w["entire_helper_overlap"]["bracketed"] for w in report["workers"])


@pytest.mark.parametrize(
    "key,value",
    [
        ("mode", "legacy"),
        ("sysfs_released", False),
        ("low_confirmed", False),
        ("cleanup_errors", ["restore failed"]),
        ("burner_pids", [200]),
        ("phases", []),
        ("helper_pid", True),
    ],
)
def test_invalid_pwm_helper_cleanup_and_schema(tmp_path, key, value):
    launch, completion, remote = documents()
    remote[key] = value
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError):
        audit.analyze(load, capture)


@pytest.mark.parametrize(
    "key,value",
    [
        ("begin_ns", True),
        ("transition_begin_ns", 2_100_000_001),
        ("readback_end_ns", 6_000_000_001),
        ("stable_begin_ns", 2_000_000_000),
        ("name", "high"),
        ("generation", 0),
    ],
)
def test_invalid_pwm_phase_intervals(tmp_path, key, value):
    launch, completion, remote = documents()
    remote["phases"][0][key] = value
    load, capture = inputs(tmp_path, launch, completion, remote)
    with pytest.raises(ValueError):
        audit.analyze(load, capture)


def test_exclusive_writer_preserves_every_original_artifact(tmp_path):
    load, capture = inputs(tmp_path)
    original = {path: path.read_bytes() for path in [load, *capture.iterdir()]}
    report = audit.write_analysis(load, capture)
    output = capture / audit.OUTPUT_NAME
    saved = output.read_bytes()
    assert json.loads(saved) == report
    assert all(path.read_bytes() == content for path, content in original.items())
    with pytest.raises(FileExistsError):
        audit.write_analysis(load, capture)
    assert output.read_bytes() == saved
    assert all(path.read_bytes() == content for path, content in original.items())


def test_cli_success_creates_only_fixed_output(tmp_path, capsys):
    load, capture = inputs(tmp_path)
    assert audit.main([str(load), str(capture)]) == 0
    assert json.loads(capsys.readouterr().out)["accepted"]
    assert {path.name for path in capture.iterdir()} == {
        "remote.stdout",
        "results.json",
        "digital_0.bin",
        "load-overlap.json",
    }


def test_cli_invalid_receipt_fails_without_output(tmp_path):
    load, capture = inputs(tmp_path)
    load.write_text("{}\n")
    with pytest.raises(SystemExit) as error:
        audit.main([str(load), str(capture)])
    assert error.value.code == 2
    assert not (capture / audit.OUTPUT_NAME).exists()
