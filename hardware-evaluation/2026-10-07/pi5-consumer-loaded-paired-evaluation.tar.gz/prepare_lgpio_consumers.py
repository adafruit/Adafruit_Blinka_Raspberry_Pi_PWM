"""Freeze/deploy the original consumer reference; read-only bench checks."""

import argparse
import datetime
import hashlib
import json
import re
import shlex
import subprocess
from pathlib import Path

import capture_lgpio_pwm_consumers as collector
import capture_native_pwm_consumers as native_collector
import lgpio_pwm_consumers_eval as helper
from capture_native_pwm_half50 import read_json, require
from prepare_native_dual import write_new
from record_native_updates_postflight import BOOT_ID, BOOT_SHA, REMOTE_PYTHON

LAB = Path(__file__).resolve().parent
FILES = [
    "lgpio_pwm_consumers_eval.py",
    "gpio_pwm_marker_eval.py",
    "baseline_pwmout.py",
    "lgpio_pin.py",
    "native_pwm_consumers_eval.py",
    "native_pwm_dual_eval.py",
    "native_pwm_updates_eval.py",
    "native_pwm_half50_eval.py",
    "kernel_pwm_lgpio_baseline_eval.py",
    "kernel_pwm_eval.py",
]


def ssh(code, capture=False):
    return subprocess.run(
        [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            shlex.join([REMOTE_PYTHON, "-c", code]),
        ],
        capture_output=capture,
        text=True,
        check=not capture,
        timeout=20,
    )


def main(root):
    require(re.fullmatch(helper.ROOT_PATTERN, root), "Unexpected isolated root")
    paths = [
        LAB / ("oct7-lgpio-consumers-" + name + ".json")
        for name in ("plan", "manifest", "preflight")
    ]
    require(
        not any(p.exists() or p.is_symlink() for p in paths),
        "Preparation outputs must be fresh",
    )
    previous = read_json((LAB / "oct7-gpio-pwm-marker-manifest.json").read_text())
    hashes = {
        **{
            key: digest
            for key, digest in previous["source_sha256"].items()
            if key not in helper.NATIVE_PACKAGE_KEYS
        },
        **helper.protocol.CONSUMER_PINS,
        **{
            name: hashlib.sha256((LAB / name).read_bytes()).hexdigest()
            for name in ("native_pwm_consumers_eval.py", "native_pwm_dual_eval.py")
        },
        helper.NEW_SOURCE: hashlib.sha256(
            (LAB / helper.NEW_SOURCE).read_bytes()
        ).hexdigest(),
    }
    commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=LAB.parent / "Adafruit_Blinka_Raspberry_Pi_PWM",
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    require(re.fullmatch(r"[0-9a-f]{40}", commit), "Unexpected production commit")
    manifest = {
        "schema_version": 1,
        "evaluation_repo_commit": commit,
        "baseline_blinka_commit": helper.baseline.BLINKA_COMMIT,
        "motor_version": helper.protocol.MOTOR_VERSION,
        "selected_sources_not_whole_system_attestation": True,
        "source_sha256": hashes,
    }
    collector.validate_local_manifest(manifest)
    native_manifest = read_json(
        (LAB / "oct7-native-consumers-manifest.json").read_text()
    )
    native_collector.validate_local_manifest(native_manifest)
    plan = {
        "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "mode": helper.MODE,
        "sequence_marker": helper.SEQUENCE_MARKER,
        "backend": helper.BACKEND,
        "capture_order": [
            "oct7-pi5-lgpio-consumers-r1",
            "oct7-pi5-native-consumers-paired-r1",
            "oct7-pi5-native-consumers-paired-r2",
            "oct7-pi5-lgpio-consumers-r2",
        ],
        "pairing_scope": "Fresh idle references, alternating original/native then native/original. No quantitative parity verdict inferred.",
        "remote_root": root,
        "remote_python": REMOTE_PYTHON,
        "motor_version": helper.protocol.MOTOR_VERSION,
        "helper_sha256": hashes[helper.NEW_SOURCE],
        "collector_sha256": hashlib.sha256(
            (LAB / "capture_lgpio_pwm_consumers.py").read_bytes()
        ).hexdigest(),
        "analyzer_sha256": hashlib.sha256(
            (LAB / "analyze_lgpio_pwm_consumers.py").read_bytes()
        ).hexdigest(),
        "original_percent_nominals": collector.PERCENT_NOMINALS,
        "native_reference": {
            "remote_root": "/tmp/blinka-pwm-native-consumers.oPHx3J",
            "manifest": "oct7-native-consumers-manifest.json",
            "helper_sha256": "db6d32ec066a7683fd85613f638f60a7e13e7a736cea362e9fe4b751641b54dc",
            "collector_sha256": "710c3367b9696e2953bfaa7f89eff21933b637b44375ad79e1cead2d30effbe1",
            "analyzer_sha256": "ec302be4cc56d5cbce8af46e9380121a38017cce4e37aca76e673184fd0bef2b",
            "unchanged_protocol_plan_sha256": "97bb31a21eee3d2ed33241a5a8ebd92f5b10f56a5081cfad4f7fdb6227eaf0d2",
        },
        "variable_frequency": False,
        "outputs": [
            {"gpio": 18, "saleae_channel": 0},
            {"gpio": 23, "saleae_channel": 1},
        ],
        "sequence": [
            {
                "name": name,
                "duration_seconds": dwell,
                "operation": operation,
                "value": value,
            }
            for name, dwell, operation, value in helper.SEQUENCE
        ],
        "sequence_dwell_seconds": round(sum(p[1] for p in helper.SEQUENCE), 6),
        "normal_fixed_wait_seconds": round(sum(p[1] for p in helper.SEQUENCE) + 0.3, 6),
        "runtime_flags": {"short_slice": False, "shared": False},
        "integration": "Genuine motor3.5.0 classes receive original unwrapped PWMOut/Pin with original percent rounding. Private-handle/line hooks enforce ownership only. In-memory pwmio export; not installed Blinka or actuator proof. Lab low/cancel/free cleanup is separate from original flags-only deinit.",
        "pre_capture_waveform_identification": {
            "ordinary_width_period_relative_band": 0.1,
            "minimum_identifiable_train_pulses": 5,
            "sustained_high_threshold_seconds": 0.1,
            "minimum_joint_brake_overlap_seconds": 0.1,
            "sibling_low_rule": "whole-run-boundary-inclusive",
            "order": "Unique three GPIO18 servo trains before unique joint long-high brake, then unique GPIO18-only full high preceded by GPIO18 motorhalf while23 low, then unique GPIO23-only full high preceded by GPIO23 motorhalf while18 low. Unique ordered joint topology only, never Pi clock mapping or arbitrary nth edge.",
            "purpose": "Identification, not timing acceptance. Retain every edge, fragment, anomaly and full-extent ambiguity. No matched performance parity or exact setter/deinit latency.",
        },
        "safety": "Passive logic probes only. Fresh private claims, independent owned-low/read/release, ordinary watchdog cannot bound native hangs, SIGKILL or faults. No providers, fan, priority, affinity or global configuration changes.",
    }
    for name, digest in (
        ("native_pwm_consumers_eval.py", plan["native_reference"]["helper_sha256"]),
        (
            "capture_native_pwm_consumers.py",
            plan["native_reference"]["collector_sha256"],
        ),
        (
            "analyze_native_pwm_consumers.py",
            plan["native_reference"]["analyzer_sha256"],
        ),
        (
            "oct7-native-consumers-plan.json",
            plan["native_reference"]["unchanged_protocol_plan_sha256"],
        ),
    ):
        require(
            hashlib.sha256((LAB / name).read_bytes()).hexdigest() == digest,
            "Frozen native reference changed: " + name,
        )
    write_new(paths[0], plan)
    # Validate the frozen analyzer's declared contract before any deployment.
    import analyze_lgpio_pwm_consumers as analysis

    analysis.read_plan(paths[0])
    write_new(paths[1], manifest)
    ssh(
        f"import pathlib; p=pathlib.Path({root!r}); assert p.is_dir() and not p.is_symlink() and not list(p.iterdir())"
    )
    common = ["scp", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8"]
    subprocess.run(
        common
        + [str(LAB / name) for name in FILES]
        + ["pi@test-pi5.local:" + root + "/"],
        check=True,
        timeout=20,
    )
    subprocess.run(
        common + [str(paths[1]), "pi@test-pi5.local:" + root + "/manifest.json"],
        check=True,
        timeout=20,
    )
    code = f"""import sys,json,pathlib,hashlib,subprocess
sys.path.insert(0,{root!r})
import lgpio_pwm_consumers_eval as m
d={{"source_sha256":m.source_hashes(),"identity":m.baseline.preflight(),"before":m.core.system_snapshot()}}
lib,pkg=m.marker.load_libraries()
d["lgpio_version"]=pkg.get_module_version()
d["line_info"]={{str(g):m.marker.inspect(lib,d["identity"],g) for g in (18,23)}}
d["gpiod_version"]=lib.__version__
d["consumer_source_paths"]={{key:str(path) for key,path in m.protocol.consumer_inventory().items()}}
d["boot_config_sha256"]=hashlib.sha256(pathlib.Path('/boot/firmware/config.txt').read_bytes()).hexdigest()
r=subprocess.run(['sudo','-n','cat','/sys/kernel/debug/pwm'],capture_output=True,text=True,check=False)
d["pwm"]={{"returncode":r.returncode,"stdout":r.stdout,"stderr":r.stderr}}
d["read_only"]=True
d["no_gpio_request_or_write"]=True
print(json.dumps(d,indent=2))
"""
    result = ssh(code, capture=True)
    remote = read_json(result.stdout) if result.returncode == 0 else None
    accepted = bool(
        remote
        and remote["source_sha256"] == hashes
        and remote["identity"]["boot_id"] == BOOT_ID
        and remote["gpiod_version"] == "2.5.0"
        and remote["lgpio_version"] == "lgpio.py_0.2.2.0"
        and remote["boot_config_sha256"] == BOOT_SHA
        and not helper.core.thermal_issues(remote["before"], 65000)
        and all(
            row[1]["used"] is False and not row[1]["consumer"]
            for row in remote["line_info"].values()
        )
        and remote["pwm"]["returncode"] == 0
        and "cooling_fan" in remote["pwm"]["stdout"]
        and "1f00098000" not in remote["pwm"]["stdout"]
        and "pwm-gpio" not in remote["pwm"]["stdout"]
    )
    write_new(
        paths[2],
        {
            "ssh_returncode": result.returncode,
            "ssh_stdout": result.stdout,
            "ssh_stderr": result.stderr,
            "remote_python_code": code,
            "remote_root": root,
            "accepted": accepted,
            "remote": remote,
        },
    )
    require(accepted, "Read-only consumer preflight failed; do not drive GPIOs")
    print(
        json.dumps(
            {
                "accepted": accepted,
                "source_files": len(hashes),
                "remote_root": root,
                "before": remote["before"],
                "plan_sha256": hashlib.sha256(paths[0].read_bytes()).hexdigest(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("remote_root")
    main(parser.parse_args().remote_root)
