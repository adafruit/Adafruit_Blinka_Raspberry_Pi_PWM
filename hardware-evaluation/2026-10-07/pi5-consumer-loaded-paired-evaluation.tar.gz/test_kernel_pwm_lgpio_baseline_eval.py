"""Small fake-lgpio baseline tests; no physical GPIO, SSH or subprocesses."""

import os
import signal
import stat
import sys
from pathlib import Path
from types import SimpleNamespace

import kernel_pwm_lgpio_baseline_eval as bench
import pytest


class FakeLgpio:
    SET_PULL_NONE = 128
    TX_PWM = 0
    exceptions = False

    def __init__(self):
        self.log = []
        self.claimed = False
        self.foreign = False
        self.claim_result = 0
        self.level = 0
        self.busy = False
        self.fail = None
        self.hook = None
        self.chip_info = [0, 54, "gpiochip4", "pinctrl-rp1"]

    def note(self, name, *args):
        self.log.append((name, *args))
        if self.hook is not None:
            self.hook(name, args)
        if self.fail == name:
            raise OSError("injected " + name)

    def get_module_version(self):
        return "fake-lgpio"

    def gpiochip_open(self, chip):
        self.note("open", chip)
        return 7

    def gpiochip_close(self, handle):
        self.note("close", handle)
        self.claimed = False
        return 0

    def gpio_get_mode(self, handle, gpio):
        self.note("mode", handle, gpio)
        return 1 if self.claimed or self.foreign else 0

    def gpio_get_chip_info(self, handle):
        self.note("chip_info", handle)
        return list(self.chip_info)

    def gpio_get_line_info(self, handle, gpio):
        self.note("line_info", handle, gpio)
        return [
            0,
            gpio,
            1 if self.foreign else 0,
            "GPIO18",
            "foreign" if self.foreign else "",
        ]

    def gpio_claim_output(self, handle, gpio, *, lFlags):
        self.note("claim", handle, gpio, lFlags)
        if self.claim_result >= 0:
            self.claimed = True
        return self.claim_result

    def tx_pwm(self, handle, gpio, frequency, duty):
        self.note("tx", handle, gpio, frequency, duty)
        self.busy = bool(frequency)
        self.level = int(bool(duty))
        return 0

    def gpio_write(self, handle, gpio, level):
        self.note("write", handle, gpio, level)
        self.level = level
        return 0

    def gpio_read(self, handle, gpio):
        self.note("read", handle, gpio)
        return self.level

    def tx_busy(self, handle, gpio, kind):
        self.note("busy", handle, gpio, kind)
        return int(self.busy)

    def gpio_free(self, handle, gpio):
        self.note("free", handle, gpio)
        self.claimed = False
        return 0

    @staticmethod
    def error_text(value):
        return "fake error " + str(value)


@pytest.fixture
def environment(tmp_path, monkeypatch):
    dt = tmp_path / "dt"
    node = dt / "soc/rp1/gpio@d0000"
    node.mkdir(parents=True)
    (dt / "model").write_bytes(b"Raspberry Pi 5 Model B Rev 1.0\0")
    (node / "compatible").write_bytes(b"raspberrypi,rp1-gpio\0")
    chips = tmp_path / "gpio"
    chip = chips / "gpiochip4"
    chip.mkdir(parents=True)
    (chip / "of_node").symlink_to(node, target_is_directory=True)
    (chip / "dev").write_text("254:4\n")
    pwm = tmp_path / "pwm"
    pwm.mkdir()
    boot = tmp_path / "boot_id"
    boot.write_text("12345678-1234-1234-1234-123456789abc\n")
    monkeypatch.setattr(bench, "GPIO_DEVICES", chips)
    monkeypatch.setattr(bench, "DEVICE_TREE", dt)
    monkeypatch.setattr(bench, "SYSFS_PWM", pwm)
    monkeypatch.setattr(bench, "BOOT_ID", boot)
    monkeypatch.setattr(bench.platform, "release", lambda: bench.KERNEL)
    original_stat = os.stat

    def fake_stat(path, *args, **kwargs):
        if str(path) == "/dev/gpiochip4":
            return SimpleNamespace(st_mode=stat.S_IFCHR, st_rdev=os.makedev(254, 4))
        return original_stat(path, *args, **kwargs)

    monkeypatch.setattr(os, "stat", fake_stat)
    # Keep the byte-identical original pin's actual chip-discovery implementation.
    original_glob = Path.glob

    def glob(path, pattern, **kwargs):
        if str(path) == "/sys/bus/gpio/devices":
            return chips.glob(pattern)
        return original_glob(path, pattern, **kwargs)

    monkeypatch.setattr(Path, "glob", glob)
    fake = FakeLgpio()
    monkeypatch.setitem(sys.modules, "lgpio", fake)
    monkeypatch.setattr(bench, "load_lgpio", lambda: fake)
    snapshots = [{"temperature_millic": "42000", "throttled": "throttled=0x0"}] * 2
    readings = iter(snapshots)
    monkeypatch.setattr(bench.core, "system_snapshot", lambda: next(readings))
    monkeypatch.setattr(bench.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(
        bench.signal, "signal", lambda _signum, _handler: signal.SIG_DFL
    )
    sleeps = []
    monkeypatch.setattr(bench.time, "sleep", sleeps.append)
    return fake, dt, pwm, sleeps


@pytest.mark.parametrize("mode", bench.SEQUENCES)
def test_real_unmodified_source_imports_fixed_shapes_rounding_and_extra_cleanup(
    environment, mode
):
    fake, _dt, _pwm, sleeps = environment
    previous_path = sys.path[:]
    sentinel = object()
    previous_pin = sys.modules.get(bench.PIN_KEY, sentinel)
    result = bench.experiment(mode)
    assert result["success"] and result["characterization_only"]
    assert result["parity_pass"] is None and result["api_readbacks_are_not_electrical"]
    assert result["baseline_commit"] == bench.BLINKA_COMMIT
    assert result["source_sha256"] == bench.source_hashes()
    assert result["identity"]["gpiochip_index"] == 4
    assert [
        (p["name"], p["duration_seconds"], p["frequency"], p["duty_u16"])
        for p in result["phases"]
    ] == list(bench.SEQUENCES[mode])
    assert sleeps == [p[1] for p in bench.SEQUENCES[mode]] + [0.1]
    assert {p["duty_u16"]: p["baseline_duty_percent"] for p in result["phases"]}[
        65535
    ] == 100
    expected = [(50, 0)]
    frequency, duty = 50, 0
    for _name, _duration, next_frequency, next_duty in bench.SEQUENCES[mode]:
        if next_frequency != frequency:
            frequency = next_frequency
            expected.append((frequency, round(duty / 65535 * 100)))
        if next_duty != duty:
            duty = next_duty
            expected.append((frequency, round(duty / 65535 * 100)))
    expected.append((0, 0))  # Extra safety cancel, never inserted into the phases.
    assert [row[3:] for row in fake.log if row[0] == "tx"] == expected
    assert all(
        row[2] == 18
        for row in fake.log
        if row[0] in ("mode", "claim", "tx", "write", "read", "busy", "free")
    )
    assert [row[0] for row in fake.log[-7:]] == [
        "tx",
        "write",
        "read",
        "busy",
        "free",
        "mode",
        "close",
    ]
    assert result["cleanup_final_readback"] == {"gpio_level": 0, "tx_busy": 0}
    assert result["gpio18_released"] and result["chip_closed"] and not fake.claimed
    assert result["cleanup_errors"] == [] and result["signals_received"] == []
    assert (
        sys.path == previous_path
        and sys.modules.get(bench.PIN_KEY, sentinel) is previous_pin
    )
    assert fake.exceptions is False


@pytest.mark.parametrize("provider", ["header", "software", "registered"])
def test_forbidden_live_providers_refuse_before_any_lgpio_open(environment, provider):
    fake, dt, pwm, _sleeps = environment
    node = dt / ("soc/rp1/pwm@98000" if provider != "software" else "pwm-gpio")
    node.mkdir(parents=True)
    (node / "compatible").write_bytes(
        b"pwm-gpio\0" if provider == "software" else b"raspberrypi,rp1-pwm\0"
    )
    if provider == "registered":
        (node / "status").write_bytes(b"disabled\0")
        link = pwm / "pwmchip2/device"
        link.mkdir(parents=True)
        (link / "of_node").symlink_to(node, target_is_directory=True)
    result = bench.experiment("direct")
    assert not result["success"] and "Refusing" in result["primary_error"]
    assert fake.log == []


@pytest.mark.parametrize("field", ["kernel", "model", "char_device", "hash"])
def test_platform_source_and_chip_identity_fail_before_open(
    environment, monkeypatch, field
):
    fake, dt, _pwm, _sleeps = environment
    if field == "kernel":
        monkeypatch.setattr(bench.platform, "release", lambda: "wrong")
    elif field == "model":
        (dt / "model").write_bytes(b"Raspberry Pi 4 Model B\0")
    elif field == "char_device":
        (bench.GPIO_DEVICES / "gpiochip4/dev").write_text("254:0\n")
    else:
        hashes = bench.source_hashes()
        hashes["baseline_pwmout.py"] = "0" * 64
        monkeypatch.setattr(bench, "source_hashes", lambda: hashes)
    result = bench.experiment("direct")
    assert not result["success"] and fake.log == []
    if field == "hash":
        assert result["source_sha256"]["baseline_pwmout.py"] == "0" * 64


@pytest.mark.parametrize("field,value", [(1, 18), (3, "wrong-controller")])
def test_actual_chip_info_gate_prevents_claim_and_closes_only_opened_chip(
    environment, field, value
):
    fake, _dt, _pwm, _sleeps = environment
    fake.chip_info[field] = value
    result = bench.experiment("direct")
    assert not result["success"] and "verified RP1" in result["primary_error"]
    assert not any(row[0] in ("claim", "tx", "write", "free") for row in fake.log)
    assert result["chip_closed"] and fake.log[-1] == ("close", 7)


@pytest.mark.filterwarnings("ignore::pytest.PytestUnraisableExceptionWarning")
@pytest.mark.parametrize("foreign", [True, False])
def test_failed_constructor_claim_never_drives_or_frees_foreign_line(
    environment, foreign
):
    fake, _dt, _pwm, _sleeps = environment
    fake.foreign = foreign
    fake.claim_result = -5
    result = bench.experiment("half50-direct")
    assert not result["success"] and not result["fresh_claim_accepted"]
    assert not any(row[0] in ("tx", "write", "free") for row in fake.log)
    assert fake.log[-1] == ("close", 7) and result["chip_closed"]


@pytest.mark.filterwarnings("ignore::pytest.PytestUnraisableExceptionWarning")
@pytest.mark.parametrize("at", ["claim", "tx"])
def test_signal_during_ownership_or_constructor_recovers_only_actual_owner(
    environment, monkeypatch, at
):
    fake, _dt, _pwm, _sleeps = environment
    guard = bench.core.SafetySignals()
    monkeypatch.setattr(bench.core, "SafetySignals", lambda: guard)
    fired = False

    def hook(name, _args):
        nonlocal fired
        if name == at and not fired:
            fired = True
            guard.handler(signal.SIGTERM, None)

    fake.hook = hook
    result = bench.experiment("direct")
    assert not result["success"] and "SafetyAbort" in result["primary_error"]
    assert result["signals_received"] == [signal.SIGTERM]
    assert result["fresh_claim_accepted"] and result["low_confirmed"]
    assert result["gpio18_released"] and result["chip_closed"]
    assert fake.log[-1] == ("close", 7)


def test_cleanup_write_failure_is_retained_but_owned_free_and_close_continue(
    environment,
):
    fake, _dt, _pwm, _sleeps = environment
    fake.fail = "write"
    result = bench.experiment("half50-direct")
    assert not result["success"] and result["completed_normally"]
    assert any("drive_low" in error for error in result["cleanup_errors"])
    assert result["gpio18_released"] and result["chip_closed"]


def test_independent_hot_postflight_rejects_after_complete_release(
    environment, monkeypatch
):
    safe = {"temperature_millic": "42000", "throttled": "throttled=0x0"}
    hot = {"temperature_millic": "71000", "throttled": "throttled=0x0"}
    snapshots = iter([safe, hot])
    monkeypatch.setattr(bench.core, "system_snapshot", lambda: next(snapshots))
    result = bench.experiment("direct")
    assert not result["success"] and result["gpio18_released"] and result["chip_closed"]
    assert result["after"] == hot and result["cleanup_errors"]


def test_thermal_preflight_stops_before_any_open(environment, monkeypatch):
    fake, _dt, _pwm, _sleeps = environment
    snapshot = {"temperature_millic": "66000", "throttled": "throttled=0x0"}
    monkeypatch.setattr(bench.core, "system_snapshot", lambda: snapshot)
    result = bench.experiment("direct")
    assert not result["success"] and "Thermal preflight" in result["primary_error"]
    assert fake.log == []


def test_postflight_signal_is_recorded_and_cannot_report_success(
    environment, monkeypatch
):
    guard = bench.core.SafetySignals()
    monkeypatch.setattr(bench.core, "SafetySignals", lambda: guard)
    count = 0

    def snapshot():
        nonlocal count
        count += 1
        if count == 2:
            guard.handler(signal.SIGTERM, None)
        return {"temperature_millic": "42000", "throttled": "throttled=0x0"}

    monkeypatch.setattr(bench.core, "system_snapshot", snapshot)
    result = bench.experiment("direct")
    assert result["completed_normally"] and not result["success"]
    assert result["signals_received"] == [signal.SIGTERM]
    assert (
        result["low_confirmed"] and result["gpio18_released"] and result["chip_closed"]
    )
    assert result["cleanup_errors"] == []


def test_high_phase_abort_and_second_cleanup_signal_do_not_interrupt_release(
    environment, monkeypatch
):
    fake, _dt, _pwm, _sleeps = environment
    guard = bench.core.SafetySignals()
    monkeypatch.setattr(bench.core, "SafetySignals", lambda: guard)
    stopped = False

    def sleep(seconds):
        nonlocal stopped
        if seconds == 0.3 and not stopped:
            stopped = True
            guard.handler(signal.SIGTERM, None)

    def hook(name, _args):
        if name == "write":
            guard.handler(signal.SIGINT, None)

    monkeypatch.setattr(bench.time, "sleep", sleep)
    fake.hook = hook
    result = bench.experiment("direct")
    assert not result["success"] and not result["completed_normally"]
    assert result["signals_received"] == [signal.SIGTERM, signal.SIGINT]
    assert (
        result["low_confirmed"] and result["gpio18_released"] and result["chip_closed"]
    )
    assert result["cleanup_errors"] == []


def test_no_arbitrary_mode_and_stdout_is_one_json(environment, capsys):
    with pytest.raises(bench.core.BenchError):
        bench.experiment("lifecycle")
    assert bench.main(["--mode", "half50-direct"]) == 0
    captured = capsys.readouterr()
    assert len(captured.out.splitlines()) == 1 and captured.err == ""
