"""Freeze/deploy the inspected live-consumer helper; read-only bench checks."""

import argparse
import datetime
import hashlib
import json
import re
import shlex
import subprocess
from pathlib import Path

import capture_native_pwm_consumers as collector
import native_pwm_consumers_eval as helper
from capture_native_pwm_half50 import read_json, require
from prepare_native_dual import write_new
from record_native_updates_postflight import BOOT_ID, BOOT_SHA, REMOTE_PYTHON

LAB = Path(__file__).resolve().parent
FILES = [
    "native_pwm_consumers_eval.py",
    "native_pwm_dual_eval.py",
    "native_pwm_updates_eval.py",
    "native_pwm_half50_eval.py",
    "kernel_pwm_lgpio_baseline_eval.py",
    "kernel_pwm_eval.py",
]


def ssh(code, capture=False):
    return subprocess.run(
        [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            shlex.join([REMOTE_PYTHON, "-c", code]),
        ],
        capture_output=capture,
        text=True,
        check=not capture,
        timeout=20,
    )


def main(root):
    require(re.fullmatch(helper.ROOT_PATTERN, root), "Unexpected isolated root")
    paths = [
        LAB / ("oct7-native-consumers-" + name + ".json")
        for name in ("plan", "manifest", "preflight")
    ]
    require(
        not any(p.exists() or p.is_symlink() for p in paths),
        "Preparation outputs must be fresh",
    )
    previous = read_json((LAB / "oct7-native-dual-manifest.json").read_text())
    hashes = {
        **previous["source_sha256"],
        **helper.CONSUMER_PINS,
        helper.NEW_SOURCE: hashlib.sha256(
            (LAB / helper.NEW_SOURCE).read_bytes()
        ).hexdigest(),
    }
    commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=LAB.parent / "Adafruit_Blinka_Raspberry_Pi_PWM",
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    require(re.fullmatch(r"[0-9a-f]{40}", commit), "Unexpected production commit")
    manifest = {
        "schema_version": 1,
        "production_commit": commit,
        "motor_version": helper.MOTOR_VERSION,
        "selected_sources_not_whole_system_attestation": True,
        "source_sha256": hashes,
    }
    collector.validate_local_manifest(manifest)
    plan = {
        "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "mode": helper.MODE,
        "sequence_marker": helper.SEQUENCE_MARKER,
        "capture_order": [f"oct7-pi5-native-consumers-r{n}" for n in (1, 2)],
        "remote_root": root,
        "remote_python": REMOTE_PYTHON,
        "motor_version": helper.MOTOR_VERSION,
        "helper_sha256": hashes[helper.NEW_SOURCE],
        "collector_sha256": hashlib.sha256(
            (LAB / "capture_native_pwm_consumers.py").read_bytes()
        ).hexdigest(),
        "outputs": [
            {"gpio": 18, "saleae_channel": 0},
            {"gpio": 23, "saleae_channel": 1},
        ],
        "sequence": [
            {
                "name": name,
                "duration_seconds": dwell,
                "operation": operation,
                "value": value,
            }
            for name, dwell, operation, value in helper.SEQUENCE
        ],
        "sequence_dwell_seconds": round(sum(p[1] for p in helper.SEQUENCE), 6),
        "normal_fixed_wait_seconds": round(sum(p[1] for p in helper.SEQUENCE) + 0.3, 6),
        "runtime_flags": {"short_slice": False, "shared": False},
        "integration": "Genuine motor3.5.0 classes receive unwrapped native public PWMOut. In-memory pwmio export only; no installed Blinka or real actuator compatibility proof.",
        "pre_capture_waveform_identification": {
            "ordinary_width_period_relative_band": 0.1,
            "minimum_identifiable_train_pulses": 5,
            "sustained_high_threshold_seconds": 0.1,
            "minimum_joint_brake_overlap_seconds": 0.1,
            "order": "Unique three GPIO18 servo trains before unique joint long-high brake, then unique GPIO18-only full high preceded by GPIO18 motorhalf while23 low, then unique GPIO23-only full high preceded by GPIO23 motorhalf while18 low. Unique ordered joint topology only, never Pi clock mapping or arbitrary nth edge.",
            "purpose": "Identification, not timing acceptance. Retain every edge, fragment, anomaly and full-extent ambiguity. No matched performance parity or exact setter/deinit latency.",
        },
        "safety": "Passive logic probes only. Fresh private claims, independent owned-low/read/release, ordinary watchdog cannot bound native hangs, SIGKILL or faults. No providers, fan, priority, affinity or global configuration changes.",
    }
    write_new(paths[0], plan)
    write_new(paths[1], manifest)
    ssh(
        f"import pathlib; p=pathlib.Path({root!r}); assert p.is_dir() and not p.is_symlink() and not list(p.iterdir())"
    )
    common = ["scp", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8"]
    subprocess.run(
        common
        + [str(LAB / name) for name in FILES]
        + ["pi@test-pi5.local:" + root + "/"],
        check=True,
        timeout=20,
    )
    subprocess.run(
        common + [str(paths[1]), "pi@test-pi5.local:" + root + "/manifest.json"],
        check=True,
        timeout=20,
    )
    code = f"""import sys,json,pathlib,hashlib,subprocess
sys.path.insert(0,{root!r})
import native_pwm_consumers_eval as m
d={{"source_sha256":m.source_hashes(),"identity":m.dual.base.baseline.preflight(),"before":m.core.system_snapshot()}}
lib,pkg=m.dual.load_backend()
d["line_info"]={{str(g):m.dual.inspect_line(lib,d["identity"],g) for g in (18,23)}}
d["gpiod_version"]=lib.__version__
d["consumer_source_paths"]={{key:str(path) for key,path in m.consumer_inventory().items()}}
d["boot_config_sha256"]=hashlib.sha256(pathlib.Path('/boot/firmware/config.txt').read_bytes()).hexdigest()
r=subprocess.run(['sudo','-n','cat','/sys/kernel/debug/pwm'],capture_output=True,text=True,check=False)
d["pwm"]={{"returncode":r.returncode,"stdout":r.stdout,"stderr":r.stderr}}
d["read_only"]=True
d["no_gpio_request_or_write"]=True
print(json.dumps(d,indent=2))
"""
    result = ssh(code, capture=True)
    remote = read_json(result.stdout) if result.returncode == 0 else None
    accepted = bool(
        remote
        and remote["source_sha256"] == hashes
        and remote["identity"]["boot_id"] == BOOT_ID
        and remote["boot_config_sha256"] == BOOT_SHA
        and not helper.core.thermal_issues(remote["before"], 65000)
        and all(
            row[1]["used"] is False and not row[1]["consumer"]
            for row in remote["line_info"].values()
        )
        and remote["pwm"]["returncode"] == 0
        and "cooling_fan" in remote["pwm"]["stdout"]
        and "1f00098000" not in remote["pwm"]["stdout"]
        and "pwm-gpio" not in remote["pwm"]["stdout"]
    )
    write_new(
        paths[2],
        {
            "ssh_returncode": result.returncode,
            "ssh_stdout": result.stdout,
            "ssh_stderr": result.stderr,
            "remote_python_code": code,
            "remote_root": root,
            "accepted": accepted,
            "remote": remote,
        },
    )
    require(accepted, "Read-only consumer preflight failed; do not drive GPIOs")
    print(
        json.dumps(
            {
                "accepted": accepted,
                "source_files": len(hashes),
                "remote_root": root,
                "before": remote["before"],
                "plan_sha256": hashlib.sha256(paths[0].read_bytes()).hexdigest(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("remote_root")
    main(parser.parse_args().remote_root)
