"""Freeze/deploy the inspected dual helper, then record a read-only preflight."""

import argparse
import datetime
import hashlib
import json
import re
import shlex
import subprocess
from pathlib import Path

import capture_native_pwm_dual as collector
import native_pwm_dual_eval as helper
from capture_native_pwm_half50 import read_json, require
from record_native_updates_postflight import BOOT_ID, BOOT_SHA, REMOTE_PYTHON

LAB = Path(__file__).resolve().parent
FILES = (
    "native_pwm_dual_eval.py",
    "native_pwm_updates_eval.py",
    "native_pwm_half50_eval.py",
    "kernel_pwm_lgpio_baseline_eval.py",
    "kernel_pwm_eval.py",
)


def write_new(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def main(root):
    require(re.fullmatch(helper.ROOT_PATTERN, root), "Unexpected remote root")
    targets = [
        LAB / ("oct7-native-dual-" + name + ".json")
        for name in ("plan", "manifest", "preflight")
    ]
    require(
        not any(path.exists() or path.is_symlink() for path in targets),
        "Preparation targets must be fresh",
    )
    previous = read_json((LAB / "oct7-gpio-pwm-marker-manifest.json").read_text())
    hashes = {
        key: (
            hashlib.sha256((LAB / key).read_bytes()).hexdigest()
            if key == helper.NEW_SOURCE
            else previous["source_sha256"][key]
        )
        for key in sorted(helper.SOURCE_KEYS)
    }
    commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=LAB.parent / "Adafruit_Blinka_Raspberry_Pi_PWM",
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    require(re.fullmatch(r"[0-9a-f]{40}", commit), "Unexpected production commit")
    manifest = {
        "schema_version": 1,
        "production_commit": commit,
        "selected_sources_not_whole_system_attestation": True,
        "source_sha256": hashes,
    }
    collector.validate_local_manifest(manifest)
    plan = {
        "declared_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "mode": helper.MODE,
        "sequence_marker": helper.SEQUENCE_MARKER,
        "capture_order": [
            f"oct7-pi5-native-dual-lifecycle-r{repeat}" for repeat in (1, 2)
        ],
        "remote_root": root,
        "remote_python": REMOTE_PYTHON,
        "helper_sha256": hashes[helper.NEW_SOURCE],
        "collector_sha256": hashlib.sha256(
            (LAB / "capture_native_pwm_dual.py").read_bytes()
        ).hexdigest(),
        "outputs": [
            {"gpio": 18, "saleae_channel": 0},
            {"gpio": 23, "saleae_channel": 1},
        ],
        "sequence": [
            {"name": name, "duration_seconds": dwell, "actions": list(actions)}
            for name, dwell, actions in helper.SEQUENCE
        ],
        "sequence_dwell_seconds": round(sum(row[1] for row in helper.SEQUENCE), 6),
        "normal_fixed_wait_seconds": round(
            sum(row[1] for row in helper.SEQUENCE) + 0.3, 6
        ),
        "runtime_flags": {"short_slice": False, "shared": False},
        "functional_coexistence_only": True,
        "matched_performance_parity": False,
        "waveform_reporting": "Retain both complete raw channels and every edge/high/period. No Pi/Saleae clock alignment. Physically identifiable lifecycle features and ambiguity reported, not exact setter latency or a parity verdict.",
        "safety": "Fresh private claims, owned-low readbacks and separate releases; ordinary watchdog cannot bound native hangs, SIGKILL or hardware faults. No provider, fan, priority, affinity or global configuration changes.",
    }
    write_new(targets[0], plan)
    write_new(targets[1], manifest)
    empty_code = f"import pathlib; p=pathlib.Path({root!r}); assert p.is_dir() and not p.is_symlink() and not list(p.iterdir())"
    subprocess.run(
        [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            shlex.join([REMOTE_PYTHON, "-c", empty_code]),
        ],
        check=True,
        timeout=20,
    )
    subprocess.run(
        [
            "scp",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            *[str(LAB / name) for name in FILES],
            str(targets[1]),
            "pi@test-pi5.local:" + root + "/",
        ],
        check=True,
        timeout=20,
    )
    # SCP preserved the local manifest basename; rename exactly this fresh file.
    rename_code = f"import pathlib; p=pathlib.Path({root!r}); s=p/'oct7-native-dual-manifest.json'; d=p/'manifest.json'; assert s.is_file() and not s.is_symlink() and not d.exists(); s.rename(d)"
    subprocess.run(
        [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            shlex.join([REMOTE_PYTHON, "-c", rename_code]),
        ],
        check=True,
        timeout=20,
    )
    code = f"""import sys,json,pathlib,hashlib,subprocess
sys.path.insert(0,{root!r})
import native_pwm_dual_eval as m
d={{"source_sha256":m.source_hashes(),"identity":m.base.baseline.preflight(),"before":m.core.system_snapshot()}}
lib,pkg=m.load_backend()
d["line_info"]={{str(g):m.inspect_line(lib,d["identity"],g) for g in (18,23)}}
d["gpiod_version"]=lib.__version__
d["boot_config_sha256"]=hashlib.sha256(pathlib.Path('/boot/firmware/config.txt').read_bytes()).hexdigest()
r=subprocess.run(['sudo','-n','cat','/sys/kernel/debug/pwm'],capture_output=True,text=True,check=False)
d["pwm"]={{"returncode":r.returncode,"stdout":r.stdout,"stderr":r.stderr}}
d["read_only"]=True
d["no_gpio_request_or_write"]=True
print(json.dumps(d,indent=2))
"""
    result = subprocess.run(
        [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            shlex.join([REMOTE_PYTHON, "-c", code]),
        ],
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    remote = read_json(result.stdout) if result.returncode == 0 else None
    accepted = bool(
        remote
        and remote["source_sha256"] == hashes
        and remote["identity"]["boot_id"] == BOOT_ID
        and remote["boot_config_sha256"] == BOOT_SHA
        and not helper.core.thermal_issues(remote["before"], 65000)
        and all(
            row[1]["used"] is False and not row[1]["consumer"]
            for row in remote["line_info"].values()
        )
        and remote["pwm"]["returncode"] == 0
        and "cooling_fan" in remote["pwm"]["stdout"]
        and "1f00098000" not in remote["pwm"]["stdout"]
        and "pwm-gpio" not in remote["pwm"]["stdout"]
    )
    write_new(
        targets[2],
        {
            "ssh_returncode": result.returncode,
            "ssh_stdout": result.stdout,
            "ssh_stderr": result.stderr,
            "remote_python_code": code,
            "remote_root": root,
            "accepted": accepted,
            "remote": remote,
        },
    )
    require(accepted, "Read-only dual preflight failed; do not drive GPIOs")
    print(
        json.dumps(
            {
                "accepted": accepted,
                "remote_root": root,
                "before": remote["before"],
                "source_files": len(hashes),
                "plan_sha256": hashlib.sha256(targets[0].read_bytes()).hexdigest(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("remote_root")
    main(parser.parse_args().remote_root)
