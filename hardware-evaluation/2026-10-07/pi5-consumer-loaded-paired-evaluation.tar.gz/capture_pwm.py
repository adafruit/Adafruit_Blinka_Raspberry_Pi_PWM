"""Record GPIO18 or GPIO23 with Saleae and summarize complete PWM cycles.

The Fan SHIM was removed; cooling now uses a heatsink and a 5V/GND-only fan.
Only use after confirming channel 0/GPIO18 or channel 1/GPIO23 and common ground.
The remote output always has a bounded duration and explicit low/deinit cleanup.
"""

import argparse
import inspect
import json
import math
import shlex
import statistics
import struct
import subprocess
from pathlib import Path

from saleae import automation

DEVICE_ID = "81F8C2631DF5BF30"
REMOTE_ROOT = "/tmp/blinka-pwm-cooled.7d40hB"
BENCH_ROOTS = {"test2-pi4.local": REMOTE_ROOT,
               "test-pi5.local": "/tmp/blinka-pwm-pi5-cooled.y4ysND"}


def thermal_issues(snapshot, maximum_millic):
    """Conservative bench gate: reject missing readings or any firmware flags.

    History bits deliberately require a reboot after a limiting event. With a
    clean initial history, the final check also catches transient limiting.
    This is a measurement acceptance rule, not a hardware safety threshold.
    """
    issues = []
    try:
        temperature = int(snapshot["temperature_millic"])
        if not 0 <= temperature <= maximum_millic:
            issues.append(f"Temperature {temperature / 1000:.1f} C exceeds bench limit")
    except (KeyError, TypeError, ValueError):
        issues.append("Temperature reading unavailable")
    try:
        flags = snapshot["throttled"]
        if not flags.startswith("throttled=0x"):
            raise ValueError("Malformed firmware flags")
        if int(flags.split("=", 1)[1], 16) != 0:
            issues.append(f"Firmware limiting flags are not clear: {flags}")
    except (KeyError, AttributeError, TypeError, ValueError):
        issues.append("Firmware limiting flags unavailable")
    return issues


def remote_code(frequency, duty, backend, timer_slack_ns=None, duration=3, load_workers=0,
                probe_root=None, probe_output=None, pwm_cpu=None, load_cpus=None,
                worker_slice_ns=None, short_slice=False, gpio=23,
                output_specs=None, retire_first=False, host="test2-pi4.local", shared=False):
    if host not in BENCH_ROOTS:
        raise ValueError("Only the two authorized bench hosts are supported")
    if shared and backend != "draft":
        raise ValueError("The shared scheduler opt-in is draft-only")
    if (backend == "rpi_gpio" and host != "test2-pi4.local") or (backend == "lgpio" and host != "test-pi5.local"):
        raise ValueError("Use RPi.GPIO on Pi 4 and lgpio on Pi 5")
    bench_root = BENCH_ROOTS[host]
    if gpio not in (18, 23) or (backend == "probe" and gpio != 18):
        raise ValueError("Only GPIO18/23 are wired; the old probe is GPIO18-only")
    specs = output_specs or [{"gpio": gpio, "frequency": frequency, "duty": duty}]
    if output_specs is not None:
        if backend == "probe" or worker_slice_ns is not None or pwm_cpu is not None:
            raise ValueError("Multi-output measurements do not use diagnostic overrides")
        if len(specs) != 2 or [spec["gpio"] for spec in specs] != [18, 23]:
            raise ValueError("Multi-output bench is GPIO18 and GPIO23 only")
        for spec in specs:
            if not 1 <= spec["frequency"] <= 10000 or not 0 < spec["duty"] < 65535:
                raise ValueError("Invalid multi-output frequency or duty")
    if retire_first and output_specs is None:
        raise ValueError("Independent deinit test requires two outputs")
    if backend == "rpi_gpio":
        imports = f"""
import importlib.util, sys
from types import SimpleNamespace
# Use the same Debian RPi.GPIO baseline as the earlier captures, even if a test
# dependency also installed another copy in the virtual environment.
sys.path.insert(0, "/usr/lib/python3/dist-packages")
spec = importlib.util.spec_from_file_location("baseline_pwmout", "{bench_root}/baseline_pwmout.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
PWMOut = module.PWMOut
pin = SimpleNamespace(id={gpio})
backend_version = module.GPIO.VERSION
"""
    elif backend == "lgpio":
        imports = f"""
import importlib.util, sys
from types import SimpleNamespace
sys.path.insert(0, "/usr/lib/python3/dist-packages")
import lgpio
# Load both unmodified Blinka source files, retaining their chip-discovery logic.
pin_name = "adafruit_blinka.microcontroller.generic_linux.lgpio_pin"
pin_spec = importlib.util.spec_from_file_location(pin_name, "{bench_root}/lgpio_pin.py")
pin_module = importlib.util.module_from_spec(pin_spec)
sys.modules[pin_name] = pin_module
pin_spec.loader.exec_module(pin_module)
spec = importlib.util.spec_from_file_location("baseline_pwmout", "{bench_root}/baseline_pwmout.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
PWMOut = module.PWMOut
pin = SimpleNamespace(id={gpio})
backend_version = lgpio.get_module_version()
"""
    elif backend == "probe":
        imports = f"""
sys.path.insert(0, {probe_root!r})
os.environ["PWM_PROBE_OUTPUT"] = {probe_output!r}
from probe_backend import PWMOut
pin = 18
backend_version = "instrumented-production-engine"
"""
    else:
        imports = f"""
from adafruit_blinka_raspberry_pi_pwm import PWMOut, __version__
pin = {gpio}
backend_version = __version__
"""
    return f"""
import ctypes, json, os, resource, subprocess, sys, time
from contextlib import ExitStack
from pathlib import Path
{imports}
{inspect.getsource(thermal_issues)}

if {short_slice!r}:
    os.environ["BLINKA_PWM_SHORT_SLICE"] = "1"
else:
    os.environ.pop("BLINKA_PWM_SHORT_SLICE", None)
if {shared!r}:
    os.environ["BLINKA_PWM_SHARED"] = "1"
else:
    os.environ.pop("BLINKA_PWM_SHARED", None)
original_timer_slack_ns = int(Path("/proc/self/timerslack_ns").read_text())
requested_timer_slack_ns = {timer_slack_ns!r}
if requested_timer_slack_ns is not None:
    libc = ctypes.CDLL(None, use_errno=True)
    # PR_SET_TIMERSLACK affects only this thread; the PWM worker inherits it.
    if libc.prctl(29, ctypes.c_ulong(requested_timer_slack_ns), 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "PR_SET_TIMERSLACK failed")
effective_timer_slack_ns = int(Path("/proc/self/timerslack_ns").read_text())
def run_output():
    global thread_settings, active_stats, lifecycle_events
    specs = {specs!r}
    with ExitStack() as stack:
        outputs = []
        for spec in specs:
            target = SimpleNamespace(id=spec["gpio"]) if {backend!r} in ("rpi_gpio", "lgpio") else spec["gpio"]
            outputs.append(stack.enter_context(PWMOut(target, frequency=spec["frequency"], duty_cycle=0)))
        time.sleep(0.2)
        if {worker_slice_ns!r} is not None:
            tids = [int(task.name) for task in Path("/proc/self/task").iterdir()
                    if int(task.name) != os.getpid()]
            if len(tids) != 1:
                raise RuntimeError("Cannot uniquely identify PWM worker")
            # Normal SCHED_OTHER policy, same nice value, this test worker only.
            subprocess.run(["chrt", "-o", "-T", str({worker_slice_ns!r}),
                            "-p", "0", str(tids[0])], check=True)
        thread_settings = []
        for task in Path("/proc/self/task").iterdir():
            tid = int(task.name)
            try:
                thread_settings.append({{"tid": tid,
                    "scheduler": os.sched_getscheduler(tid),
                    "nice": os.getpriority(os.PRIO_PROCESS, tid),
                    "affinity": sorted(os.sched_getaffinity(tid)),
                    "slice_ns": next((int(line.split(":")[1]) for line in
                        (task / "sched").read_text().splitlines()
                        if line.startswith("se.slice")), None)}})
            except ProcessLookupError:
                pass
        if any(process.poll() is not None for process in load):
            raise RuntimeError("CPU load worker exited early")
        active_before = resource.getrusage(resource.RUSAGE_SELF)
        active_start = time.monotonic()
        for output, spec in zip(outputs, specs):
            output.duty_cycle = spec["duty"]
        if {retire_first!r}:
            time.sleep({duration / 2})
            outputs[0].duty_cycle = 0
            outputs[0].deinit()
            lifecycle_events["first_deinit_at_active_seconds"] = time.monotonic() - active_start
            time.sleep({duration / 2})
        else:
            time.sleep({duration})
        for index, output in enumerate(outputs):
            if index == 0 and {retire_first!r}:
                continue
            output.duty_cycle = 0
        active_end = time.monotonic()
        active_after = resource.getrusage(resource.RUSAGE_SELF)
        active_stats = {{"elapsed_seconds": active_end - active_start,
            "cpu_user_seconds": active_after.ru_utime - active_before.ru_utime,
            "cpu_system_seconds": active_after.ru_stime - active_before.ru_stime}}
        if any(process.poll() is not None for process in load):
            raise RuntimeError("CPU load worker exited early")
        time.sleep(0.2)

before = resource.getrusage(resource.RUSAGE_SELF)
start = time.monotonic()
def system_snapshot():
    result = {{}}
    for name, path in (
        ("temperature_millic", "/sys/class/thermal/thermal_zone0/temp"),
        ("cpu0_frequency_khz", "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"),
        ("governor", "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")):
        try:
            result[name] = Path(path).read_text().strip()
        except OSError:
            result[name] = None
    try:
        result["throttled"] = subprocess.run(["vcgencmd", "get_throttled"],
            capture_output=True, text=True, timeout=2, check=True).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        result["throttled"] = None
    return result
system_before = system_snapshot()
preflight_issues = thermal_issues(system_before, 65000)
if preflight_issues:
    raise RuntimeError("Bench preflight failed before GPIO/load startup: " + "; ".join(preflight_issues))
load = []
thread_settings = []
active_stats = {{}}
lifecycle_events = {{}}
# Independent bounded CPU burners; no disk or GPIO access. Started before PWM.
load_code = "import os, time\\ncpus = {load_cpus!r}\\nif cpus is not None: os.sched_setaffinity(0, cpus)\\nend = time.monotonic() + {duration + 5}\\nwhile time.monotonic() < end: sum(range(10000))"
try:
    for _ in range({load_workers}):
        load.append(subprocess.Popen([sys.executable, "-c", load_code]))
    if {pwm_cpu!r} is not None:
        os.sched_setaffinity(0, [{pwm_cpu!r}])
    run_output()
finally:
    for process in load:
        if process.poll() is None:
            process.terminate()
        process.wait(timeout=5)
after = resource.getrusage(resource.RUSAGE_SELF)
system_after = system_snapshot()
postflight_issues = thermal_issues(system_after, 75000)
print(json.dumps({{
    "backend_version": backend_version,
    "original_timer_slack_ns": original_timer_slack_ns,
    "effective_timer_slack_ns": effective_timer_slack_ns,
    "caller_timer_slack_after_ns": int(Path("/proc/self/timerslack_ns").read_text()),
    "load_workers": {load_workers},
    "load_cpus": {load_cpus!r},
    "requested_worker_slice_ns": {worker_slice_ns!r},
    "optin_short_slice": {short_slice!r},
    "optin_shared": {shared!r},
    "thread_settings": thread_settings,
    "output_specs": {specs!r},
    "lifecycle_events": lifecycle_events,
    "active_interval": active_stats,
    "system_before": system_before,
    "system_after": system_after,
    "thermal_acceptance": {{"valid": not postflight_issues,
        "issues": postflight_issues, "start_limit_millic": 65000,
        "end_limit_millic": 75000, "require_clear_firmware_history": True}},
    "elapsed_seconds": time.monotonic() - start,
    "cpu_user_seconds": after.ru_utime - before.ru_utime,
    "cpu_system_seconds": after.ru_stime - before.ru_stime,
}}))
"""


def read_digital(path):
    """Parse Saleae's documented digital binary formats, keeping gaps separate."""
    with path.open("rb") as stream:
        assert stream.read(8) == b"<SALEAE>", "Not a Saleae binary export"
        version, kind = struct.unpack("<ii", stream.read(8))
        assert version in (0, 1) and kind == 0, "Unsupported binary format"
        count = struct.unpack("<Q", stream.read(8))[0] if version else 1
        chunks = []
        for _ in range(count):
            initial = struct.unpack("<I", stream.read(4))[0]
            sample_rate = struct.unpack("<d", stream.read(8))[0] if version else None
            begin, end, transitions = struct.unpack("<ddQ", stream.read(24))
            times = struct.unpack(f"<{transitions}d", stream.read(8 * transitions))
            assert initial in (0, 1) and all(begin <= t <= end for t in times)
            assert all(a < b for a, b in zip(times, times[1:]))
            chunks.append((initial, begin, end, sample_rate, times))
        assert stream.read(1) == b"", "Unexpected trailing export data"
    return version, chunks


def describe(samples):
    ordered = sorted(samples)
    return {
        "count": len(samples),
        "mean": statistics.mean(samples),
        "median": statistics.median(samples),
        "min": ordered[0],
        "p99": ordered[math.ceil(len(samples) * 0.99) - 1],
        "p999": ordered[math.ceil(len(samples) * 0.999) - 1],
        "max": ordered[-1],
        "stddev": statistics.pstdev(samples),
    }


def summarize(path, frequency, duty=32768, backend="draft"):
    version, chunks = read_digital(path)
    periods, highs, lows = [], [], []
    for initial, begin, end, sample_rate, times in chunks:
        state, last_rise, last_fall = initial, None, None
        rising_times = times[(0 if initial == 0 else 1)::2]
        if len(rising_times) < 2:
            continue
        lower, upper = rising_times[0] + 0.05, rising_times[-1] - 0.05
        for t in times:
            state = 1 - state
            if state:
                if last_rise is not None and last_fall is not None:
                    if lower <= last_rise and t <= upper:
                        periods.append((t - last_rise) * 1e6)
                        highs.append((last_fall - last_rise) * 1e6)
                        lows.append((t - last_fall) * 1e6)
                last_rise, last_fall = t, None
            else:
                last_fall = t
    assert periods, "No complete steady-state PWM cycles were recorded"
    initial, begin, end, sample_rate, times = chunks[-1]
    final_state = initial ^ (len(times) % 2)
    result = {
        "binary_format_version": version,
        "chunks": len(chunks),
        "period_us": describe(periods),
        "high_us": describe(highs),
        "low_us": describe(lows),
        "mean_frequency_hz": 1e6 / statistics.mean(periods),
        "mean_duty_percent": 100 * sum(highs) / sum(periods),
        "absolute_period_error_us": describe([abs(p - 1e6 / frequency) for p in periods]),
        "final_state": final_state,
        "quiet_tail_seconds": end - times[-1] if times else end - begin,
        "steady_state_trim_seconds_each_end": 0.05,
    }
    target_high = 1e6 / frequency * (round(duty / 65535 * 100) / 100
                                   if backend in ("rpi_gpio", "lgpio") else duty / 65535)
    result["target_high_us"] = target_high
    result["periods_over_150_percent_target"] = sum(p > 1e6 / frequency * 1.5 for p in periods)
    result["long_gaps_over_150_percent_median"] = sum(p > result["period_us"]["median"] * 1.5
                                                     for p in periods)
    # Meaningful only for the draft's fixed-phase scheduler, not RPi.GPIO's drift.
    result["estimated_omitted_cycles"] = (sum(max(0, round(p / (1e6 / frequency)) - 1)
                                               for p in periods)
                                          if backend not in ("rpi_gpio", "lgpio") else None)
    result["highs_outside_20_percent_target"] = sum(not target_high * .8 <= h <= target_high * 1.2
                                                   for h in highs)
    result["highs_outside_50_percent_target"] = sum(not target_high * .5 <= h <= target_high * 1.5
                                                   for h in highs)
    result["absolute_high_error_us"] = describe([abs(h - target_high) for h in highs])
    assert result["final_state"] == 0, "Output did not finish low"
    assert result["quiet_tail_seconds"] > 0.1, "Capture lacks a stable low tail"
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--frequency", type=int, default=500)
    parser.add_argument("--duty-cycle", type=int, default=32768)
    parser.add_argument("--backend", choices=("draft", "rpi_gpio", "lgpio", "probe"), default="draft")
    parser.add_argument("--host", choices=tuple(BENCH_ROOTS), default="test2-pi4.local")
    parser.add_argument("--timer-slack-ns", type=int, default=None,
                        help="Diagnostic override in the remote test process only")
    parser.add_argument("--duration", type=float, default=3)
    parser.add_argument("--load-workers", type=int, default=0)
    parser.add_argument("--brief", action="store_true")
    parser.add_argument("--probe-root")
    parser.add_argument("--pwm-cpu", type=int)
    parser.add_argument("--load-cpus", help="Diagnostic CPU affinity, comma-separated")
    parser.add_argument("--worker-slice-ns", type=int,
                        help="Diagnostic normal-policy time slice for the test worker")
    parser.add_argument("--short-slice", action="store_true",
                        help="Enable the package's BLINKA_PWM_SHORT_SLICE opt-in")
    parser.add_argument("--gpio", type=int, choices=(18, 23), default=23)
    parser.add_argument("--saleae-channel", type=int, choices=(0, 1), default=1)
    args = parser.parse_args()
    assert 1 <= args.frequency <= 10000 and 0 < args.duty_cycle < 65535
    assert args.timer_slack_ns is None or args.timer_slack_ns >= 1
    assert 1 <= args.duration <= 30 and 0 <= args.load_workers <= 4
    assert args.pwm_cpu is None or 0 <= args.pwm_cpu <= 3
    assert args.backend != "probe" or args.probe_root
    assert args.worker_slice_ns is None or 100000 <= args.worker_slice_ns <= 100000000
    assert (args.gpio, args.saleae_channel) in ((18, 0), (23, 1))
    assert args.backend != "probe" or args.gpio == 18
    assert not args.short_slice or args.backend == "draft"
    load_cpus = [int(cpu) for cpu in args.load_cpus.split(",")] if args.load_cpus else None
    assert load_cpus is None or all(0 <= cpu <= 3 for cpu in load_cpus)
    output = args.directory.resolve()
    output.mkdir(parents=True, exist_ok=False)
    probe_output = f"{args.probe_root}/{output.name}.csv" if args.probe_root else None
    command = [
        "ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=8",
        f"pi@{args.host}",
        f"{BENCH_ROOTS[args.host]}/venv/bin/python -c {shlex.quote(remote_code(args.frequency, args.duty_cycle, args.backend, args.timer_slack_ns, args.duration, args.load_workers, args.probe_root, probe_output, args.pwm_cpu, load_cpus, args.worker_slice_ns, args.short_slice, args.gpio, host=args.host))}",
    ]
    with automation.Manager.connect(port=10430, connect_timeout_seconds=5) as manager:
        devices = manager.get_devices()
        assert any(d.device_id == DEVICE_ID and not d.is_simulation for d in devices)
        configuration = automation.LogicDeviceConfiguration(
            enabled_digital_channels=[args.saleae_channel], digital_sample_rate=10_000_000,
        )
        with manager.start_capture(device_id=DEVICE_ID, device_configuration=configuration) as capture:
            try:
                remote = subprocess.run(command, capture_output=True, text=True, timeout=args.duration + 20)
            finally:
                capture.stop()
                capture.save_capture(str(output / "waveform.sal"))
                capture.export_raw_data_binary(str(output), digital_channels=[args.saleae_channel])
            (output / "remote.stdout").write_text(remote.stdout)
            (output / "remote.stderr").write_text(remote.stderr)
            assert remote.returncode == 0, remote.stderr
            if args.backend == "probe":
                subprocess.run(["scp", f"pi@test2-pi4.local:{probe_output}",
                                str(output / "probe.csv")], check=True, timeout=15)
            result = {
                "host": args.host, "gpio": args.gpio, "saleae_channel": args.saleae_channel,
                "sample_rate_hz": 10_000_000, "backend": args.backend,
                "configured_frequency_hz": args.frequency,
                "configured_duty_cycle": args.duty_cycle,
                "output_duration_seconds": args.duration,
                "logic_version": manager.get_app_info().app_version,
                "remote": json.loads(remote.stdout),
                "timing": summarize(output / f"digital_{args.saleae_channel}.bin", args.frequency,
                                    args.duty_cycle, args.backend),
            }
            (output / "results.json").write_text(json.dumps(result, indent=2) + "\n")
            if not result["remote"]["thermal_acceptance"]["valid"]:
                raise RuntimeError("Capture saved but rejected: " + "; ".join(
                    result["remote"]["thermal_acceptance"]["issues"]))
            if args.brief:
                timing = result["timing"]
                active = result["remote"]["active_interval"]
                print(json.dumps({"capture": output.name, "gpio": args.gpio,
                    "backend": args.backend, "short_slice": args.short_slice,
                    "temperature_before_millic": result["remote"]["system_before"]["temperature_millic"],
                    "temperature_after_millic": result["remote"]["system_after"]["temperature_millic"],
                    "throttled_after": result["remote"]["system_after"]["throttled"],
                    "worker_slices_ns": [t["slice_ns"] for t in result["remote"]["thread_settings"]],
                    "mean_frequency_hz": timing["mean_frequency_hz"],
                    "mean_duty_percent": timing["mean_duty_percent"],
                    "cycles": timing["period_us"]["count"],
                    "long_gaps": timing["long_gaps_over_150_percent_median"],
                    "max_period_us": timing["period_us"]["max"],
                    "high_min_us": timing["high_us"]["min"],
                    "high_max_us": timing["high_us"]["max"],
                    "cpu_percent_one_core": 100*(active["cpu_user_seconds"]+active["cpu_system_seconds"])/active["elapsed_seconds"],
                    "final_state": timing["final_state"]}))
            else:
                print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
