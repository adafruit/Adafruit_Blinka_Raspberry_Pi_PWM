"""Fake native harness safety tests: no GPIO, SSH, native extension or hardware."""

import hashlib
import importlib.util
import signal
import sys
from enum import Enum
from pathlib import Path
from types import SimpleNamespace

import native_pwm_half50_eval as bench
import pytest

ROOT = "/tmp/blinka-pwm-native-half50.abc123"
IDENTITY = {
    "gpio": 18,
    "gpiochip_index": 4,
    "gpiochip": "/dev/gpiochip4",
    "gpiochip_device_number": "254:4",
    "label": "pinctrl-rp1",
    "kernel_release": bench.baseline.KERNEL,
    "compatible": ["raspberrypi,rp1-gpio"],
    "model": "Raspberry Pi 5 Model B Rev 1.0",
    "boot_id": "12345678-1234-1234-1234-123456789abc",
    "of_node": "/sys/firmware/devicetree/base/axi/pcie@1000120000/rp1/gpio@d0000",
}


class Value(Enum):
    INACTIVE = 0
    ACTIVE = 1


@pytest.fixture
def environment(monkeypatch):
    state = SimpleNamespace(
        log=[],
        claimed=False,
        foreign=False,
        chip_label="pinctrl-rp1",
        fail=None,
        hook=None,
        level=0,
    )

    def note(name, *args):
        state.log.append((name, *args))
        if state.hook:
            state.hook(name)
        if state.fail == name:
            raise OSError("injected " + name)

    class Chip:
        def __init__(self, path):
            assert path == IDENTITY["gpiochip"]
            note("chip_open", path)

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            note("chip_close")

        def get_info(self):
            return SimpleNamespace(
                name="gpiochip4", label=state.chip_label, num_lines=54
            )

        def get_line_info(self, offset):
            assert offset == 18
            note("line_info", offset)
            return SimpleNamespace(
                offset=18,
                name="GPIO18",
                used=state.claimed or state.foreign,
                consumer="foreign"
                if state.foreign
                else "adafruit-blinka-pwm"
                if state.claimed
                else None,
            )

    class Request:
        offsets = [18]
        chip_name = "gpiochip4"

        def get_value(self, offset):
            assert offset == 18 and state.claimed
            note("get_value", offset)
            return Value.ACTIVE if state.level else Value.INACTIVE

    class Engine:
        def __init__(self, pin, frequency, duty):
            assert pin == (IDENTITY["gpiochip"], 18) and frequency == 50 and duty == 0
            self._request = None
            note("construct", pin, frequency, duty)
            state.claimed = True
            self._request = Request()
            note("claim")

        def configure(self, frequency, duty):
            assert state.claimed and frequency == 50
            note("configure", frequency, duty)
            state.level = int(duty != 0)

        def check(self):
            pass

        def close(self):
            try:
                note("stop")
                state.level = 0
            finally:
                note("release")
                state.claimed = False
                self._request = None

    package_path = (
        Path(__file__).resolve().parent.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src"
        / bench.PACKAGE
        / "__init__.py"
    )
    name = "_half50_fake_public"
    spec = importlib.util.spec_from_file_location(
        name, package_path, submodule_search_locations=[str(package_path.parent)]
    )
    module = importlib.util.module_from_spec(spec)
    monkeypatch.setitem(sys.modules, name, module)
    monkeypatch.setitem(
        sys.modules, name + "._software", SimpleNamespace(SoftwarePWM=Engine)
    )
    spec.loader.exec_module(module)
    library = SimpleNamespace(Chip=Chip, line=SimpleNamespace(Value=Value))
    manifest = {
        "schema_version": 1,
        "source_sha256": {
            **bench.PINNED_SOURCES,
            "native_pwm_half50_eval.py": hashlib.sha256(
                Path(bench.__file__).read_bytes()
            ).hexdigest(),
            bench.PACKAGE + "/__init__.py": hashlib.sha256(
                package_path.read_bytes()
            ).hexdigest(),
            bench.PACKAGE + "/_software.py": hashlib.sha256(
                package_path.with_name("_software.py").read_bytes()
            ).hexdigest(),
            bench.PACKAGE + "/_native.so": "a" * 64,
        },
    }
    monkeypatch.setattr(bench, "approved_manifest_path", lambda path: Path(path))
    monkeypatch.setattr(bench, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(bench, "source_hashes", lambda: dict(manifest["source_sha256"]))
    monkeypatch.setattr(bench.baseline, "preflight", lambda: dict(IDENTITY))
    monkeypatch.setattr(bench, "load_backend", lambda: (library, module))
    monkeypatch.setattr(
        bench.core,
        "system_snapshot",
        lambda: {"temperature_millic": "42000", "throttled": "throttled=0x0"},
    )
    guard = bench.core.SafetySignals()
    monkeypatch.setattr(bench.core, "SafetySignals", lambda: guard)
    monkeypatch.setattr(bench.signal, "alarm", lambda _seconds: 0)
    monkeypatch.setattr(
        bench.signal, "signal", lambda _signum, _handler: signal.SIG_DFL
    )
    clock, sleeps = [1_000_000_000], []

    def now():
        clock[0] += 1_000
        return clock[0]

    def sleep(duration):
        sleeps.append(duration)
        clock[0] += round(duration * 1_000_000_000)

    monkeypatch.setattr(bench.time, "monotonic_ns", now)
    monkeypatch.setattr(bench.time, "sleep", sleep)
    monkeypatch.delenv("BLINKA_PWM_SHORT_SLICE", raising=False)
    monkeypatch.delenv("BLINKA_PWM_SHARED", raising=False)
    return state, guard, module, manifest, sleeps


def test_exact_sequence_real_public_api_and_owned_low_release(environment):
    state, _guard, _module, manifest, sleeps = environment
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert receipt["success"] and receipt["source_sha256"] == manifest["source_sha256"]
    assert [
        (
            phase["name"],
            phase["duration_seconds"],
            phase["frequency"],
            phase["duty_u16"],
        )
        for phase in receipt["phases"]
    ] == list(bench.SEQUENCE)
    assert sleeps == [0.2, 0.4, 0.3, 0.4, 0.2, 0.1]
    assert [row[2] for row in state.log if row[0] == "configure"] == [
        32768,
        65535,
        32768,
        0,
        0,
    ]
    assert (
        receipt["runtime_flags"] == {"short_slice": False, "shared": False}
        and receipt["variable_frequency"] is False
    )
    assert all(
        set(phase["api_state"]) == {"frequency", "duty_cycle"}
        for phase in receipt["phases"]
    )
    assert receipt["cleanup_final_readback"] == {"gpio_level": 0, "inactive": True}
    assert (
        not state.claimed
        and receipt["gpio18_released"]
        and receipt["read_only_chip_closed"]
    )
    assert [row[0] for row in state.log[-6:]] == [
        "get_value",
        "stop",
        "release",
        "chip_open",
        "line_info",
        "chip_close",
    ]
    assert receipt["primary_error"] is None and receipt["cleanup_errors"] == []


@pytest.mark.parametrize("flag", ["BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED"])
def test_inherited_enabled_flags_refuse_without_open_or_claim(
    environment, monkeypatch, flag
):
    state, *_rest = environment
    monkeypatch.setenv(flag, "1")
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "Refusing inherited" in receipt["primary_error"]
    assert state.log == []


@pytest.mark.parametrize("bad", ["foreign", "chip", "hash", "thermal"])
def test_preclaim_gates_never_construct(environment, monkeypatch, bad):
    state, _guard, _module, manifest, _sleeps = environment
    if bad == "foreign":
        state.foreign = True
    elif bad == "chip":
        state.chip_label = "other"
    elif bad == "hash":
        monkeypatch.setattr(
            bench,
            "source_hashes",
            lambda: {
                **manifest["source_sha256"],
                bench.PACKAGE + "/_software.py": "0" * 64,
            },
        )
    else:
        monkeypatch.setattr(
            bench.core,
            "system_snapshot",
            lambda: {"temperature_millic": "66000", "throttled": "throttled=0x0"},
        )
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and not receipt["fresh_claim_accepted"]
    assert not any(
        row[0] in ("construct", "configure", "stop", "release") for row in state.log
    )


def test_signal_during_atomic_constructor_tracks_owner_before_cleanup(environment):
    state, guard, *_rest = environment
    state.hook = lambda name: (
        guard.handler(signal.SIGTERM, None) if name == "claim" else None
    )
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "SafetyAbort" in receipt["primary_error"]
    assert receipt["signals_received"] == [signal.SIGTERM]
    assert (
        receipt["fresh_claim_accepted"]
        and receipt["low_confirmed"]
        and receipt["gpio18_released"]
    )
    assert not state.claimed


def test_partial_public_constructor_is_explicitly_deinitialized(
    environment, monkeypatch
):
    state, _guard, module, *_rest = environment

    class Outputs:
        @staticmethod
        def add(_pwm):
            raise OSError("injected after engine ownership")

        @staticmethod
        def discard(_pwm):
            pass

        def __iter__(self):
            return iter(())

    monkeypatch.setattr(module, "_outputs", Outputs())
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert (
        not receipt["success"] and "after engine ownership" in receipt["primary_error"]
    )
    assert (
        receipt["fresh_claim_accepted"]
        and receipt["gpio18_released"]
        and not state.claimed
    )
    assert ("stop",) in state.log and ("release",) in state.log


def test_failed_constructor_without_request_still_attempts_deinit(environment):
    state, *_rest = environment
    state.fail = "construct"
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert "injected construct" in receipt["primary_error"] and not state.claimed
    assert any(event["operation"] == "PWMOut.deinit" for event in receipt["events"])
    assert not any(row[0] == "configure" for row in state.log)


def test_primary_setter_failure_retained_and_deinit_attempted_despite_cleanup_failure(
    environment,
):
    state, *_rest = environment
    state.fail = "configure"
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "injected configure" in receipt["primary_error"]
    assert any("duty_cycle_zero" in error for error in receipt["cleanup_errors"])
    assert not state.claimed and receipt["gpio18_released"]
    assert ("stop",) in state.log and ("release",) in state.log


def test_deinit_error_retained_release_verified_without_reclaim(environment):
    state, *_rest = environment
    state.fail = "stop"
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and receipt["completed_normally"]
    assert receipt["primary_error"] is None and any(
        "PWMOut.deinit" in error for error in receipt["cleanup_errors"]
    )
    assert receipt["gpio18_released"] and not state.claimed
    assert len([row for row in state.log if row[0] == "claim"]) == 1


def test_pinned_baseline_and_core_files_are_exact():
    for name, digest in bench.PINNED_SOURCES.items():
        assert (
            hashlib.sha256(
                Path(bench.__file__).with_name(name).read_bytes()
            ).hexdigest()
            == digest
        )


@pytest.mark.parametrize(
    "path", ["manifest.json", "/tmp/manifest.json", ROOT + "/../manifest.json"]
)
def test_manifest_path_is_confined_before_loading(path):
    with pytest.raises(bench.core.BenchError, match="absolute"):
        bench.approved_manifest_path(path)
