"""Fixed read-only loaded-paired pre/postflight, composing frozen validators.

No collector, coordinator, load launcher or GPIO writer is called. Only the
read-only state query runs when explicitly invoked; all outputs are exclusive.
"""

import argparse
import hashlib
import json
import shlex
import subprocess
from pathlib import Path
from subprocess import TimeoutExpired

import analyze_kernel_pwm_cpu_load as load_audit
import capture_lgpio_pwm_consumers_loaded as original_loaded
import capture_native_pwm_consumers_loaded as native_loaded
import record_lgpio_consumers_paired_state as paired

LAB = Path(__file__).resolve().parent
ROOT = "/tmp/blinka-pwm-lgpio-consumers.6Hnhjx"
BENCH = "/tmp/blinka-pwm-oct6.F3SDcm"
PRIOR_NAME = "oct7-lgpio-consumers-paired-postflight.json"
PRIOR_SHA256 = "aaa343c537b1d7541d757136961f24a63c84831bdafd852665432ab09b9117d6"
CAPTURES = (
    "oct7-pi5-lgpio-consumers-loaded-r1",
    "oct7-pi5-paired-native-consumers-loaded-r1",
    "oct7-pi5-paired-native-consumers-loaded-r2",
    "oct7-pi5-lgpio-consumers-loaded-r2",
)
COORDINATORS = {"original": original_loaded, "native": native_loaded}
SOURCE_PINS = {
    "record_lgpio_consumers_paired_state.py": "9043be40d3ea5ae0a2d4e188b75e6f6f1ef82244d5c8db8f45b8d5020f1c8c31",
    "analyze_kernel_pwm_cpu_load.py": "d1b45cdfc989d8cdae439534cc6af17a79d46a2bcb8622fad2bc3e0a9fdedb84",
}
require, read_json = paired.require, paired.read_json


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    path = Path(path)
    require(
        path.is_file() and not path.is_symlink(), "Regular nonsymlink evidence required"
    )
    return read_json(path.read_text())


def read_plan(path):
    path = Path(path)
    plan = read(path)
    expected = {
        "remote_root": ROOT,
        "remote_python": paired.REMOTE_PYTHON,
        "bench_root": BENCH,
        "capture_order": list(CAPTURES),
        "prior_postflight_sha256": PRIOR_SHA256,
        "load_source_sha256": load_audit.LOAD_SOURCE_SHA256,
        "worker_source_sha256": load_audit.WORKER_SOURCE_SHA256,
        "state_recorder_sha256": digest(__file__),
        "loaded_coordinators_sha256": {
            key: digest(module.__file__) for key, module in COORDINATORS.items()
        },
    }
    require(
        all(plan.get(key) == value for key, value in expected.items())
        and plan.get("native_reference", {}).get("remote_root") == paired.NATIVE_ROOT,
        "Frozen loaded paired plan/runtime/order/source contract changed",
    )
    for name, value in SOURCE_PINS.items():
        require(
            digest(Path(__file__).with_name(name)) == value,
            "Frozen reused state/load source changed: " + name,
        )
    return plan, {
        "path": str(path.resolve()),
        "sha256": digest(path),
        "loaded_coordinator_source_sha256": {
            key: module.source_hashes() for key, module in COORDINATORS.items()
        },
    }


def capture_pids(name, key, manifest, manifest_path):
    coordinator = COORDINATORS[key]
    root = ROOT if key == "original" else paired.NATIVE_ROOT
    stem = str(LAB / name)
    coordination_path = Path(stem + ".consumers-coordination.json")
    coordination = read(coordination_path)
    remote, acquisition = (
        read(LAB / name / filename)
        for filename in ("remote.stdout", "acquisition.json")
    )
    expected = {
        "schema_version": 1,
        "stem": name,
        "mode": coordinator.consumer.MODE,
        "backend": coordinator.consumer.BACKEND,
        "bench_root": BENCH,
        "consumer_root": root,
        "remote_python": paired.REMOTE_PYTHON,
        "manifest_path": str(manifest_path.resolve()),
        "manifest_sha256": digest(manifest_path),
        "consumer_source_manifest": manifest,
        "source_sha256": coordinator.source_hashes(),
        "coordination_success": True,
        "launch_validated": True,
        "launch_validation_errors": [],
        "collector_returned_normally": True,
        "collector_collection_success": True,
        "load_recorder_returned_normally": True,
        "capture_error": None,
        "capture_evidence_error": None,
        "load_recorder_error": None,
        "audit_error": None,
        "collector_invocation": "in-process frozen "
        + Path(coordinator.consumer.__file__).stem
        + ".capture_test",
    }
    require(
        all(
            type(coordination.get(field)) is type(value)
            and coordination[field] == value
            for field, value in expected.items()
        ),
        "Successful coordinator/source/manifest/runtime linkage required",
    )
    require(
        all(
            type(coordination.get(field)) is int and coordination[field] == 0
            for field in ("consumer_remote_returncode", "load_helper_returncode")
        ),
        "Actual typed consumer/load SSH exit0 required",
    )
    program = root + "/" + coordinator.consumer.helper.NEW_SOURCE
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(
            [paired.REMOTE_PYTHON, program, "--manifest", root + "/manifest.json"]
        ),
    ]
    require(
        acquisition.get("remote_command") == command
        and (
            key != "original" or remote.get("python_executable") == paired.REMOTE_PYTHON
        ),
        "Actual captured consumer interpreter/program invocation changed",
    )
    load_path = Path(stem + ".load.stdout")
    require(
        load_path.is_file() and not load_path.is_symlink(),
        "Regular nonsymlink actual load receipts required",
    )
    launch, completion = load_audit.parse_lines(load_path.read_text(), 2, "load stdout")
    workers = load_audit.validate_load(launch, completion)
    require(
        coordination.get("launch_receipt") == launch
        and coordination.get("persisted_launch_sha256")
        == hashlib.sha256(
            load_path.read_bytes().splitlines(keepends=True)[0]
        ).hexdigest(),
        "Coordinator must link the actual persisted pre-capture launch",
    )
    audited = coordinator.audit(stem, root, paired.REMOTE_PYTHON, manifest)
    require(
        audited.get("accepted") is True and coordination.get("overlap") == audited,
        "Frozen coordinator/actual-worker overlap audit differs or rejected",
    )
    pids = [
        remote.get("helper_pid"),
        launch["launcher_pid"],
        *(worker["pid"] for worker in workers),
    ]
    require(
        all(type(pid) is int and pid > 1 for pid in pids) and len(set(pids)) == 4,
        "Four distinct actual helper/launcher/worker PIDs required per capture",
    )
    return pids, {
        "backend": coordinator.consumer.BACKEND,
        "helper_pid": pids[0],
        "load_launcher_pid": pids[1],
        "worker_pids": pids[2:],
        "coordination_sha256": digest(coordination_path),
        "load_stdout_sha256": digest(load_path),
        "consumer_stdout_sha256": digest(LAB / name / "remote.stdout"),
        "validation": "Frozen coordinator.audit and CPU auditor.validate_load, with actual-exit/source/manifest/runtime linkage",
    }


def inputs(stage, plan_path):
    require(stage in ("preflight", "postflight"), "Fixed loaded paired stage required")
    plan, frozen_plan = read_plan(plan_path)
    manifest_paths = {
        "original": LAB / "oct7-lgpio-consumers-manifest.json",
        "native": LAB / "oct7-native-consumers-manifest.json",
    }
    manifests = {key: read(path) for key, path in manifest_paths.items()}
    for key, count in (("original", 21), ("native", 18)):
        COORDINATORS[key].consumer.validate_local_manifest(manifests[key])
        require(
            len(manifests[key].get("source_sha256", {})) == count,
            "Exact selected inventories required",
        )
    prior_path = LAB / PRIOR_NAME
    require(digest(prior_path) == PRIOR_SHA256, "Accepted paired prior bytes changed")
    prior = read(prior_path)
    prior_pids = prior.get("inspected_pids", [])
    require(
        prior.get("accepted") is True
        and type(prior.get("ssh_returncode")) is int
        and prior["ssh_returncode"] == 0
        and prior.get("remote_root") == ROOT
        and prior.get("native_root") == paired.NATIVE_ROOT
        and len(prior_pids) == len(set(prior_pids)) == 104
        and all(type(pid) is int and pid > 1 for pid in prior_pids),
        "Accepted actual-exit0 exact 104-PID paired prior required",
    )
    pids, captures = set(prior_pids), {}
    if stage == "postflight":
        for name in CAPTURES:
            key = "original" if "-lgpio-" in name else "native"
            added, captures[name] = capture_pids(
                name, key, manifests[key], manifest_paths[key]
            )
            require(
                not pids.intersection(added),
                "New actual loaded PIDs must be distinct from prior/all captures",
            )
            pids.update(added)
        require(len(pids) == 120, "Exact 120-PID loaded paired postflight required")
    return plan, frozen_plan, manifests, sorted(pids), captures


def remote_code(root, pids):
    code = paired.remote_code(root, pids)
    final_print = "print(json.dumps(receipt, indent=2))"
    require(
        code.count(final_print) == 1, "Frozen paired read-only query structure changed"
    )
    extra = f"""
load_path = pathlib.Path({BENCH + "/cpu-load-eval/kernel_pwm_cpu_load_eval.py"!r})
assert load_path.is_file() and not load_path.is_symlink()
load_spec = importlib.util.spec_from_file_location('_loaded_paired_cpu_state', str(load_path))
load = importlib.util.module_from_spec(load_spec)
load_spec.loader.exec_module(load)
receipt['load_program_path'] = str(load_path.resolve())
receipt['load_source_sha256'] = hashlib.sha256(load_path.read_bytes()).hexdigest()
receipt['worker_source_sha256'] = hashlib.sha256(load._worker_source().encode()).hexdigest()
{final_print}
"""
    return code.replace(final_print, extra)


def validate_state(remote, root, manifests, pids):
    paired.validate_state(remote, root, manifests, pids)
    require(
        remote.get("load_program_path")
        == BENCH + "/cpu-load-eval/kernel_pwm_cpu_load_eval.py"
        and remote.get("load_source_sha256") == load_audit.LOAD_SOURCE_SHA256
        and remote.get("worker_source_sha256") == load_audit.WORKER_SOURCE_SHA256,
        "Remote frozen load helper/worker source origins changed",
    )


def record(stage, plan_path):
    _plan, frozen_plan, manifests, pids, captures = inputs(stage, plan_path)
    output = LAB / f"oct7-lgpio-consumers-loaded-paired-{stage}.json"
    stdout, stderr = Path(str(output) + ".stdout"), Path(str(output) + ".stderr")
    require(
        not any(
            path.exists() or path.is_symlink() for path in (output, stdout, stderr)
        ),
        "Exclusive fresh loaded paired state targets required",
    )
    code = remote_code(ROOT, pids)
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([paired.REMOTE_PYTHON, "-c", code]),
    ]
    result, remote, error = None, None, None
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            result = subprocess.run(
                command, stdout=out, stderr=err, timeout=20, check=False
            )
        except (OSError, TimeoutExpired, KeyboardInterrupt) as failure:
            error = f"{type(failure).__name__}: {failure}"
    actual_exit = (
        result.returncode
        if result is not None and type(result.returncode) is int
        else None
    )
    try:
        require(
            error is None and actual_exit == 0,
            "Actual typed read-only SSH exit0 required",
        )
        remote = read(stdout)
        validate_state(remote, ROOT, manifests, pids)
    except (
        ValueError,
        KeyError,
        TypeError,
        AttributeError,
        OSError,
        KeyboardInterrupt,
    ) as failure:
        error = error or f"{type(failure).__name__}: {failure}"
    receipt = {
        "schema_version": 1,
        "stage": stage,
        "remote_root": ROOT,
        "native_root": paired.NATIVE_ROOT,
        "bench_root": BENCH,
        "source_manifests": manifests,
        "frozen_plan": frozen_plan,
        "plan_sha256": frozen_plan["sha256"],
        "prior_postflight_sha256": PRIOR_SHA256,
        "capture_receipts": captures,
        "inspected_pids": pids,
        "ssh_returncode": actual_exit,
        "accepted": error is None,
        "validation_error": error,
        "remote": remote,
        "remote_read_only_code": code,
        "remote_command": command,
        "source_sha256": digest(__file__),
        "stdout_sha256": digest(stdout),
        "stderr_sha256": digest(stderr),
        "scope": "Read-only state/source/exact PID absence; no waveform acceptance, CPU saturation, parity or actuator-safety claim",
    }
    with output.open("x") as stream:
        json.dump(receipt, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "accepted": receipt["accepted"],
                "inspected_pids": len(pids),
                "validation_error": error,
            }
        )
    )
    return 0 if receipt["accepted"] else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("preflight", "postflight"))
    parser.add_argument("--plan", required=True, type=Path)
    args = parser.parse_args(argv)
    return record(args.stage, args.plan)


if __name__ == "__main__":
    raise SystemExit(main())
