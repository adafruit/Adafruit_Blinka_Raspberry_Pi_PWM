"""Collect unfiltered GPIO18 PWM/GPIO23 setter-bound markers in the lab.

Use only after source inspection and physical GPIO18/channel0, GPIO23/channel1
wiring confirmation. Collection success is not waveform acceptance or parity.
All raw edges, SAL, receipts and failure diagnostics are retained for analysis.
"""

import argparse
import hashlib
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

import gpio_pwm_marker_eval as helper
from capture_native_pwm_half50 import DEVICE_ID, _write, read_json, require
from saleae import automation

BACKENDS = ("native", "lgpio")
BACKEND_NAMES = {"native": "native-blinka-pwm", "lgpio": "original-blinka-lgpio"}
MODE = "electrical-marker-updates"
SEQUENCE_MARKER = "gpio23-setter-bounds-v1"


def validate_local_manifest(manifest):
    hashes = helper.validate_manifest(manifest)
    directory = Path(__file__).resolve().parent
    package = (
        directory.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src/adafruit_blinka_raspberry_pi_pwm"
    )
    paths = {
        name: directory / name
        for name in (
            "gpio_pwm_marker_eval.py",
            "native_pwm_updates_eval.py",
            "native_pwm_half50_eval.py",
            "kernel_pwm_lgpio_baseline_eval.py",
            "kernel_pwm_eval.py",
            "baseline_pwmout.py",
            "lgpio_pin.py",
        )
    }
    paths.update(
        {
            "adafruit_blinka_raspberry_pi_pwm/" + name: package / name
            for name in ("__init__.py", "_software.py")
        }
    )
    require(
        all(
            hashlib.sha256(path.read_bytes()).hexdigest() == hashes[name]
            for name, path in paths.items()
        ),
        "Manifest helper/core/original/native Python sources must match local production sources",
    )
    return hashes


def validate_remote(remote, backend, manifest):
    require(backend in BACKENDS, "Unsupported marker backend")
    hashes = helper.validate_manifest(manifest)
    require(isinstance(remote, dict), "Marker receipt must be an object")
    require(
        _matches(
            remote,
            {
                "schema_version": 1,
                "mode": MODE,
                "sequence_marker": SEQUENCE_MARKER,
                "backend": BACKEND_NAMES[backend],
                "backend_selector": backend,
                "gpio": 18,
                "marker_gpio": 23,
            },
        )
        and remote.get("source_sha256") == hashes,
        "Marker schema/backend/GPIO/selected-source provenance mismatch",
    )
    require(
        all(
            remote.get(key) is True
            for key in (
                "success",
                "completed_normally",
                "fresh_claim_accepted",
                "gpio18_released",
                "read_only_chip_closed",
                "low_confirmed",
                "characterization_only",
                "production_backend_unchanged",
                "api_readbacks_are_not_electrical",
                "marker_bounds_not_exact_invocation",
                "marker_edge_does_not_prove_application_edge",
                "gpio_driver_and_threshold_skew_not_calibrated",
                "marker_instrumentation_changes_caller_timing",
                "selected_source_hashes_not_whole_system_attestation",
                "watchdog_cannot_bound_native_hang_or_sigkill",
            )
        )
        and "parity_pass" in remote
        and remote["parity_pass"] is None
        and "primary_error" in remote
        and remote["primary_error"] is None
        and remote.get("cleanup_errors") == []
        and remote.get("signals_received") == []
        and remote.get("variable_frequency") is (backend == "native")
        and remote.get("original_variable_frequency_default") is False,
        "Marker safety/characterization/API-difference receipt failed",
    )
    require(
        remote.get("runtime_flags") == {"short_slice": False, "shared": False}
        and all(value is False for value in remote["runtime_flags"].values())
        and isinstance(remote.get("inherited_environment"), dict)
        and set(remote["inherited_environment"])
        == {"BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED"}
        and all(
            value is None or isinstance(value, str) and value != "1"
            for value in remote["inherited_environment"].values()
        ),
        "Native shared/short-slice flags must remain disabled",
    )
    require(
        type(remote.get("helper_pid")) is int
        and remote["helper_pid"] > 0
        and type(remote.get("begin_ns")) is int
        and type(remote.get("end_ns")) is int
        and 0 <= remote["begin_ns"] < remote["end_ns"]
        and remote["end_ns"] - remote["begin_ns"]
        < helper.MAX_RUN_SECONDS * 1_000_000_000
        and _matches(remote, {"watchdog_seconds": 14, "gpiod_version": "2.5.0"})
        and isinstance(remote.get("lgpio_version"), str)
        and bool(remote["lgpio_version"]),
        "Invalid bounded helper identity/run interval or library version",
    )
    identity = remote.get("identity")
    require(
        isinstance(identity, dict)
        and _matches(
            identity,
            {
                "gpio": 18,
                "label": "pinctrl-rp1",
                "kernel_release": helper.baseline.KERNEL,
            },
        )
        and type(identity.get("gpiochip_index")) is int
        and identity["gpiochip_index"] >= 0
        and identity.get("gpiochip") == f"/dev/gpiochip{identity['gpiochip_index']}"
        and isinstance(identity.get("gpiochip_device_number"), str)
        and re.fullmatch(r"[0-9]+:[0-9]+", identity["gpiochip_device_number"])
        and identity.get("compatible") == ["raspberrypi,rp1-gpio"]
        and isinstance(identity.get("model"), str)
        and identity["model"].startswith("Raspberry Pi 5 Model B Rev ")
        and isinstance(identity.get("boot_id"), str)
        and re.fullmatch(
            r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", identity["boot_id"]
        ),
        "Expected approved Pi5 RP1 GPIO18/GPIO23 identity",
    )
    require(
        isinstance(remote.get("manifest_path"), str)
        and re.fullmatch(
            helper.ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", remote["manifest_path"]
        ),
        "Manifest must be in the isolated marker root",
    )
    marker = remote.get("marker")
    require(
        isinstance(marker, dict)
        and _matches(marker, {"gpio": 23})
        and all(
            marker.get(key) is True
            for key in (
                "fresh_claim_accepted",
                "initial_low_confirmed",
                "final_low_confirmed",
                "gpio23_released",
                "read_only_chip_closed",
            )
        )
        and _low_readback(marker.get("cleanup_final_readback"), native=True),
        "Fresh private GPIO23 inactive/released marker receipt required",
    )
    _chip(marker.get("chip_info"), identity)
    _owned_request(marker.get("owned_request"), identity, 23)
    for key in ("preclaim_line_info", "released_line_info"):
        _line(marker.get(key), 23)
    if backend == "native":
        require(
            remote.get("read_only_chip_closed") is True
            and _low_readback(remote.get("cleanup_final_readback"), native=True),
            "Native PWM settled private GPIO18 low receipt required",
        )
        _chip(remote.get("chip_info"), identity)
        _owned_request(remote.get("owned_request"), identity, 18)
        for key in ("preclaim_line_info", "released_line_info"):
            _line(remote.get(key), 18)
    else:
        chip, line = remote.get("chip_info"), remote.get("preclaim_line_info")
        require(
            isinstance(chip, list)
            and len(chip) == 4
            and type(chip[0]) is int
            and chip[0] == 0
            and type(chip[1]) is int
            and chip[1] > 23
            and chip[3] == "pinctrl-rp1"
            and isinstance(line, list)
            and len(line) == 5
            and all(type(line[i]) is int for i in (0, 1, 2))
            and line[0] == 0
            and line[1] == 18
            and line[2] >= 0
            and line[2] & 1 == 0
            and line[4] == ""
            and type(remote.get("preclaim_mode")) is int
            and remote["preclaim_mode"] >= 0
            and remote["preclaim_mode"] & 1 == 0
            and type(remote.get("released_mode")) is int
            and remote["released_mode"] >= 0
            and remote["released_mode"] & 0xF01 == 0
            and remote.get("chip_closed") is True
            and _low_readback(remote.get("cleanup_final_readback"), native=False),
            "Original-lgpio fresh private GPIO18/chip/low-release receipt required",
        )
    phases = remote.get("phases")
    require(
        isinstance(phases, list) and len(phases) == len(helper.SEQUENCE),
        "Missing fixed marker phases",
    )
    previous_end = remote["begin_ns"]
    for index, (phase, (name, duration, frequency, duty)) in enumerate(
        zip(phases, helper.SEQUENCE)
    ):
        require(
            isinstance(phase, dict)
            and set(phase)
            == {
                "name",
                "scope",
                "phase_index",
                "frequency",
                "duty_u16",
                "duration_seconds",
                "begin_ns",
                "transition_begin_ns",
                "stable_begin_ns",
                "end_ns",
                "readback_end_ns",
                "api_state",
                "api_state_end",
            }
            and _matches(
                phase,
                {
                    "name": name,
                    "scope": f"{index:02d}_{name}",
                    "phase_index": index,
                    "frequency": frequency,
                    "duty_u16": duty,
                },
            )
            and type(phase.get("duration_seconds")) in (int, float)
            and phase["duration_seconds"] == duration,
            "Fixed marker phase mismatch: " + name,
        )
        clocks = [
            phase.get(key)
            for key in (
                "begin_ns",
                "transition_begin_ns",
                "stable_begin_ns",
                "end_ns",
                "readback_end_ns",
            )
        ]
        require(
            all(type(value) is int for value in clocks)
            and previous_end
            <= clocks[0]
            == clocks[1]
            <= clocks[2]
            < clocks[3]
            <= clocks[4]
            <= remote["end_ns"]
            and clocks[3] - clocks[2] >= round(duration * 1_000_000_000),
            "Marker phase dwell/interval mismatch: " + name,
        )
        previous_end = clocks[-1]
        for key in ("api_state", "api_state_end"):
            require(
                _matches(
                    phase.get(key),
                    {"frequency": frequency, "duty_cycle": duty},
                    exact=True,
                ),
                "Software-only API state mismatch: " + name,
            )
    _validate_setters(remote, backend)
    for key, limit in (("before", 65000), ("after", 70000)):
        require(
            isinstance(remote.get(key), dict)
            and not helper.core.thermal_issues(remote[key], limit),
            "Marker thermal/firmware gate failed: " + key,
        )


def _matches(actual, expected, exact=False):
    return (
        isinstance(actual, dict)
        and (not exact or set(actual) == set(expected))
        and all(
            key in actual and type(actual[key]) is type(value) and actual[key] == value
            for key, value in expected.items()
        )
    )


def _low_readback(value, native):
    return _matches(
        value,
        {"gpio_level": 0, "inactive": True}
        if native
        else {"gpio_level": 0, "tx_busy": 0},
        exact=True,
    )


def _chip(chip, identity):
    require(
        _matches(
            chip, {"name": Path(identity["gpiochip"]).name, "label": "pinctrl-rp1"}
        )
        and type(chip.get("num_lines")) is int
        and chip["num_lines"] > 23,
        "Verified read-only gpiod RP1 chip receipt required",
    )


def _owned_request(request, identity, gpio):
    require(
        isinstance(request, dict)
        and request.get("chip_name") == Path(identity["gpiochip"]).name
        and request.get("offsets") == [gpio]
        and type(request["offsets"][0]) is int,
        f"Only the private GPIO{gpio} request is authorized",
    )


def _line(line, gpio):
    require(
        _matches(line, {"offset": gpio, "used": False})
        and line.get("consumer") in (None, ""),
        f"Unclaimed GPIO{gpio} read-only line evidence required",
    )


def _validate_setters(remote, backend):
    expected, previous_frequency, previous_duty = [], 50, 0
    for phase in remote["phases"]:
        common = (
            phase["phase_index"],
            phase["scope"],
            "sequence",
            phase["begin_ns"],
            phase["stable_begin_ns"],
        )
        frequency, duty = phase["frequency"], phase["duty_u16"]
        if frequency != previous_frequency:
            expected.append(
                (
                    "PWMOut.frequency",
                    {"frequency": frequency, "duty_u16": previous_duty},
                    *common,
                )
            )
        if duty != previous_duty:
            expected.append(
                (
                    "PWMOut.duty_cycle",
                    {"frequency": frequency, "duty_u16": duty},
                    *common,
                )
            )
        previous_frequency, previous_duty = frequency, duty
    sequence_count = len(expected)
    if backend == "native":
        expected.append(
            (
                "PWMOut.duty_cycle_zero",
                {"frequency": previous_frequency, "duty_u16": 0},
                None,
                "safety_cleanup",
                "safety_cleanup",
                remote["phases"][-1]["readback_end_ns"],
                remote["end_ns"],
            )
        )
    require(
        type(remote.get("sequence_setter_count")) is int
        and remote["sequence_setter_count"] == sequence_count
        and isinstance(remote.get("setter_events"), list)
        and len(remote["setter_events"]) == len(expected),
        "Exact finite marker sequence/cleanup setter count required",
    )
    events = remote.get("events")
    require(isinstance(events, list) and events, "Missing backend caller evidence")
    scopes = {phase["scope"] for phase in remote["phases"]} | {
        "initialization",
        "safety_cleanup",
        "extra_safety_cleanup",
    }
    for event in events:
        require(
            isinstance(event, dict)
            and isinstance(event.get("operation"), str)
            and event.get("scope") in scopes
            and event.get("status") == "ok"
            and type(event.get("begin_ns")) is int
            and type(event.get("end_ns")) is int
            and remote["begin_ns"]
            <= event["begin_ns"]
            <= event["end_ns"]
            <= remote["end_ns"],
            "Contained successful backend caller evidence required",
        )
    constructors = [
        event for event in events if event["operation"] == "PWMOut.__init__"
    ]
    arguments = {
        "gpio": 18,
        "frequency": 50,
        "duty_u16": 0,
        "variable_frequency": backend == "native",
    }
    if backend == "native":
        arguments["gpiochip"] = remote["identity"]["gpiochip"]
    require(
        len(constructors) == 1
        and constructors[0]["scope"] == "initialization"
        and _matches(constructors[0].get("arguments"), arguments, exact=True)
        and constructors[0]["end_ns"] <= remote["phases"][0]["begin_ns"],
        "Exact fresh constructor arguments required",
    )
    public = [
        event
        for event in events
        if event["operation"].startswith("PWMOut.")
        and event["operation"] != "PWMOut.__init__"
        and event["operation"] != "PWMOut.deinit"
    ]
    require(
        len(public) == len(expected), "Only fixed changed public setters are authorized"
    )
    sequence_operations = [row[0] for row in expected[:sequence_count]]
    cleanup = (
        [
            "track_owned_request",
            "PWMOut.duty_cycle_zero",
            "low_settle",
            "owned_request.get_value",
            "PWMOut.deinit",
            "gpiod_line_info_released",
        ]
        if backend == "native"
        else [
            "cancel_pwm",
            "drive_low",
            "low_settle",
            "read_low",
            "read_pwm_busy",
            "original_PWMOut.deinit",
            "gpio_free",
            "gpio_get_mode_released",
            "gpiochip_close",
        ]
    )
    initialization = (
        ["PWMOut.__init__"]
        if backend == "native"
        else [
            "gpiochip_open",
            "gpio_get_chip_info",
            "gpio_get_mode_preclaim",
            "gpio_get_line_info_preclaim",
            "gpio_claim_output",
            "tx_pwm",
            "PWMOut.__init__",
        ]
    )
    operations = (
        sequence_operations
        if backend == "native"
        else [
            name for operation in sequence_operations for name in ("tx_pwm", operation)
        ]
    )
    require(
        [event["operation"] for event in events]
        == initialization + operations + cleanup,
        "Exact authorized backend constructor/setter/cleanup calls required",
    )
    require(
        all(
            event["scope"] == "initialization"
            and event["end_ns"] <= remote["phases"][0]["begin_ns"]
            for event in events[: len(initialization)]
        ),
        "Initialization events must precede the fixed sequence",
    )
    cleanup_scope = "safety_cleanup" if backend == "native" else "extra_safety_cleanup"
    cleanup_end = remote["phases"][-1]["readback_end_ns"]
    for event in events[-len(cleanup) :]:
        require(
            event["scope"] == cleanup_scope
            and event["begin_ns"] >= cleanup_end
            and (
                event["operation"] == "PWMOut.duty_cycle_zero"
                or event.get("arguments") is None
            ),
            "Backend owned cleanup scope/arguments mismatch",
        )
        cleanup_end = event["end_ns"]
        if event["operation"] == "low_settle":
            require(
                event["end_ns"] - event["begin_ns"] >= 100_000_000,
                "Owned PWM low-settle interval is too short",
            )
    if backend == "lgpio":
        handle = events[0].get("result")
        require(
            type(handle) is int
            and handle >= 0
            and events[0].get("arguments") == [remote["identity"]["gpiochip_index"]],
            "Verified original-lgpio chip handle required",
        )
        claim = next(
            event for event in events if event["operation"] == "gpio_claim_output"
        )
        require(
            _matches(
                claim.get("arguments"),
                {"handle": handle, "gpio": 18, "args": [], "kwargs": {"lFlags": 128}},
                exact=True,
            ),
            "Only verified GPIO18 original-lgpio claim is authorized",
        )
        transmit = [event for event in events if event["operation"] == "tx_pwm"]
        targets = [{"frequency": 50, "duty_u16": 0}] + [
            row[1] for row in expected[:sequence_count]
        ]
        for event, target, caller in zip(transmit, targets, constructors + public):
            require(
                _matches(
                    event.get("arguments"),
                    {
                        "handle": handle,
                        "gpio": 18,
                        "args": [
                            target["frequency"],
                            round(target["duty_u16"] / 65535 * 100),
                        ],
                        "kwargs": {},
                    },
                    exact=True,
                )
                and all(type(value) is int for value in event["arguments"]["args"])
                and type(event.get("result")) is int
                and event["result"] >= 0,
                "Original-lgpio setter transmission GPIO/arguments/result mismatch",
            )
            require(
                event["scope"] == caller["scope"]
                and caller["begin_ns"]
                <= event["begin_ns"]
                <= event["end_ns"]
                <= caller["end_ns"],
                "Original-lgpio transmission must be inside the matching caller",
            )
    previous_end = remote["begin_ns"]
    clock_keys = (
        "begin_ns",
        "marker_high_begin_ns",
        "marker_high_end_ns",
        "caller_begin_ns",
        "caller_end_ns",
        "marker_low_begin_ns",
        "marker_low_end_ns",
        "end_ns",
    )
    for ordinal, (event, caller, specification) in enumerate(
        zip(remote["setter_events"], public, expected)
    ):
        operation, arguments, index, scope, category, lower, upper = specification
        require(
            isinstance(event, dict)
            and _matches(
                event,
                {
                    "ordinal": ordinal,
                    "phase_index": index,
                    "scope": scope,
                    "operation": operation,
                    "category": category,
                    "status": "ok",
                    "primary_error": None,
                    "marker_low_error": None,
                },
            )
            and _matches(event.get("arguments"), arguments, exact=True),
            "Marker changed-setter order/scope/arguments mismatch",
        )
        clocks = [event.get(key) for key in clock_keys]
        require(
            all(type(value) is int for value in clocks)
            and max(previous_end, lower) <= clocks[0]
            and clocks == sorted(clocks)
            and clocks[-1] <= upper,
            "Marker high/caller/low bracketing interval mismatch",
        )
        require(
            caller["operation"] == operation
            and caller["scope"] == scope
            and _matches(caller.get("arguments"), arguments, exact=True)
            and event["caller_begin_ns"]
            <= caller["begin_ns"]
            <= caller["end_ns"]
            <= event["caller_end_ns"],
            "Marker bounds must contain the corresponding backend caller",
        )
        previous_end = clocks[-1]


def capture_test(directory, remote_root, remote_python, backend, manifest_path):
    require(backend in BACKENDS, "Unsupported marker backend")
    require(
        isinstance(remote_root, str) and re.fullmatch(helper.ROOT_PATTERN, remote_root),
        "Requires the isolated Pi5 GPIO marker root",
    )
    require(
        isinstance(remote_python, str)
        and (
            re.fullmatch(
                r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/venv/bin/python", remote_python
            )
            or remote_python == remote_root + "/venv/bin/python"
        ),
        "Requires an explicit approved absolute venv Python",
    )
    manifest = helper.load_manifest(manifest_path)
    validate_local_manifest(manifest)
    output = Path(directory).resolve()
    require(
        re.fullmatch(r"[A-Za-z0-9_-]+", output.name),
        "Use a simple capture directory name",
    )
    output.mkdir(parents=True, exist_ok=False)
    _write(output, "manifest.json", json.dumps(manifest, indent=2) + "\n")
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(
            [
                remote_python,
                remote_root + "/gpio_pwm_marker_eval.py",
                "--backend",
                backend,
                "--manifest",
                remote_root + "/manifest.json",
            ]
        ),
    ]
    remote, primary, logic_version = None, None, None
    evidence_errors, timing = [], {}
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            require(
                any(
                    device.device_id == DEVICE_ID and not device.is_simulation
                    for device in manager.get_devices()
                ),
                "Confirmed physical Logic8 analyzer is unavailable",
            )
            logic_version = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[0, 1], digital_sample_rate=100_000_000
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as capture:
                try:
                    timing["lead_begin_ns"] = time.monotonic_ns()
                    time.sleep(0.5)
                    timing["lead_end_ns"] = time.monotonic_ns()
                    with (
                        (output / "remote.stdout").open("x") as stdout_file,
                        (output / "remote.stderr").open("x") as stderr_file,
                    ):
                        remote = subprocess.run(
                            command,
                            stdout=stdout_file,
                            stderr=stderr_file,
                            text=True,
                            check=False,
                            timeout=30,
                        )
                except subprocess.TimeoutExpired as error:
                    primary, remote = error, subprocess.CompletedProcess(command, 124)
                except BaseException as error:
                    primary, remote = error, subprocess.CompletedProcess(command, None)
                finally:
                    for name in ("remote.stdout", "remote.stderr"):
                        try:
                            if not (output / name).exists():
                                _write(output, name, "")
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
                    for name, action in (
                        ("tail", lambda: time.sleep(0.2)),
                        ("stop", capture.stop),
                        (
                            "save_capture",
                            lambda: capture.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_binary",
                            lambda: capture.export_raw_data_binary(
                                str(output), digital_channels=[0, 1]
                            ),
                        ),
                    ):
                        try:
                            if name == "tail":
                                timing["tail_begin_ns"] = time.monotonic_ns()
                            action()
                            if name == "tail":
                                timing["tail_end_ns"] = time.monotonic_ns()
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:
        if primary is None:
            primary = error
        else:
            evidence_errors.append(f"acquisition: {type(error).__name__}: {error}")
    acquisition = {
        "mode": MODE,
        "backend": BACKEND_NAMES[backend],
        "backend_selector": backend,
        "remote_root": remote_root,
        "remote_python": remote_python,
        "remote_command": command,
        "remote_returncode": None if remote is None else remote.returncode,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "local_timing_ns": timing,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None
        if primary is None
        else f"{type(primary).__name__}: {primary}",
        "evidence_errors": evidence_errors,
    }
    _write(output, "acquisition.json", json.dumps(acquisition, indent=2) + "\n")
    result = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": MODE,
        "backend": BACKEND_NAMES[backend],
        "backend_selector": backend,
        "sequence_marker": SEQUENCE_MARKER,
        "sample_rate_hz": 100_000_000,
        "logic_version": logic_version,
        "production_backend_unchanged": True,
        "outputs": [
            {"gpio": 18, "saleae_channel": 0, "backend": BACKEND_NAMES[backend]},
            {"gpio": 23, "saleae_channel": 1, "backend": "gpiod-marker"},
        ],
        "remote": None,
        "remote_returncode": acquisition["remote_returncode"],
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "success_scope": "acquisition and helper schema/source/cleanup only; not waveform acceptance or parity",
    }
    try:
        if primary is not None or evidence_errors:
            raise RuntimeError(
                "Capture failure evidence retained: "
                + (acquisition["primary_error"] or "; ".join(evidence_errors))
            ) from primary
        require(
            remote is not None
            and type(remote.returncode) is int
            and remote.returncode == 0,
            "Marker helper did not exit0; raw evidence retained",
        )
        require(
            all(
                (output / name).is_file() and (output / name).stat().st_size > 0
                for name in ("waveform.sal", "digital_0.bin", "digital_1.bin")
            ),
            "Missing SAL/raw PWM or marker channel evidence",
        )
        result["remote"] = read_json((output / "remote.stdout").read_text())
        validate_remote(result["remote"], backend, manifest)
        require(
            result["remote"]["manifest_path"] == remote_root + "/manifest.json",
            "Remote manifest root does not match acquisition",
        )
        result["collection_success"] = True
    except BaseException as error:
        result["receipt_validation_error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        _write(output, "results.json", json.dumps(result, indent=2) + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--backend", choices=BACKENDS, required=True)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--remote-python", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    result = capture_test(
        args.directory,
        args.remote_root,
        args.remote_python,
        args.backend,
        args.manifest,
    )
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "mode": MODE,
                "backend": BACKEND_NAMES[args.backend],
                "collection_success": result["collection_success"],
                "waveform_accepted": None,
                "parity_evaluated": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
