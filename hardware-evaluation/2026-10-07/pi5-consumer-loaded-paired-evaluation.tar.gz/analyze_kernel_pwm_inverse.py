"""Offline Pi 5 GPIO18 inverse-zero endpoint check; no hardware connections.

The physical pattern is recognized from short, regular 50 Hz PWM pulses and
two long high holds. Pi monotonic timestamps are not mapped onto Saleae time.
No captured transition is filtered or merged, including 10 ns low dips.
"""

import argparse
import itertools
import json
import math
import re
import statistics
import struct
import zipfile
from pathlib import Path

from capture_pwm import describe, read_digital, thermal_issues

MODE = "inverse-endpoints"
SAMPLE_RATE_HZ = 100_000_000
PERIOD_NS = 20_000_000
ACTIVE_DUTY_NS = PERIOD_NS * 4915 // 65535
OUTPUT = {
    "gpio": 18,
    "saleae_channel": 0,
    "frequency": 50,
    "duty": 4915,
    "backend": "kernel-hardware-rp1",
}
PHASES = (
    ("normal_low_initial", 0.2, "normal", 0, "low"),
    ("normal_active_control", 0.4, "normal", ACTIVE_DUTY_NS, "interior_pwm"),
    ("normal_low_before_inverse", 0.2, "normal", 0, "low"),
    ("inverse_zero_high_1", 0.3, "inversed", 0, "constant_high"),
    ("normal_low_between_inverse", 0.2, "normal", 0, "low"),
    ("inverse_zero_high_2", 0.3, "inversed", 0, "constant_high"),
    ("normal_low_after_inverse", 0.2, "normal", 0, "low"),
    ("normal_active_recovery", 0.4, "normal", ACTIVE_DUTY_NS, "interior_pwm"),
    ("normal_low_final", 0.2, "normal", 0, "low"),
)
HIGH_HOLD_BOUNDS_SECONDS = (0.25, 0.4)
LOW_GAP_BOUNDS_SECONDS = (0.15, 0.27)
PWM_HIGH_BOUNDS_SECONDS = (0.0014, 0.0016)
PWM_PERIOD_BOUNDS_SECONDS = (0.019, 0.021)


def require(condition, message):
    """Validation must remain active under python -O."""
    if not condition:
        raise ValueError(message)


def finite_number(value):
    return type(value) in (int, float) and math.isfinite(value)


def expected_readback(polarity, duty, enable=1):
    return {
        "period": PERIOD_NS,
        "duty_cycle": duty,
        "polarity": polarity,
        "enable": enable,
    }


def validate_metadata(metadata, remote):
    require(
        isinstance(metadata, dict) and isinstance(remote, dict),
        "Capture and remote metadata must be objects",
    )
    require(
        metadata.get("remote") == remote,
        "remote.stdout disagrees with results.json remote metadata",
    )
    require(metadata.get("host") == "test-pi5.local", "Expected the Pi 5 bench host")
    require(
        metadata.get("mode") == MODE and remote.get("mode") == MODE,
        "Expected inverse-endpoints mode in capture and remote metadata",
    )
    require(
        type(metadata.get("sample_rate_hz")) is int
        and metadata["sample_rate_hz"] == SAMPLE_RATE_HZ,
        "Inverse endpoint capture requires 100 MSa/s",
    )
    require(
        metadata.get("production_backend_unchanged") is True,
        "Capture must report production backend unchanged",
    )
    require(
        metadata.get("providers_left_loaded_until_reboot") is True,
        "Capture must report temporary providers left loaded until reboot",
    )
    outputs = metadata.get("outputs")
    require(
        isinstance(outputs, list)
        and len(outputs) == 1
        and isinstance(outputs[0], dict)
        and all(outputs[0].get(key) == value for key, value in OUTPUT.items()),
        "Expected GPIO18/channel0 50 Hz duty4915 RP1 output mapping only",
    )
    require(
        remote.get("schema_version") == 1
        and isinstance(remote.get("model"), str)
        and remote["model"].startswith("Raspberry Pi 5 Model B"),
        "Expected helper schema 1 on Raspberry Pi 5 Model B",
    )
    require(
        remote.get("burner_pids") == [],
        "Inverse endpoint test must have no load workers",
    )
    require(
        remote.get("cleanup_errors") == []
        and remote.get("sysfs_released") is True
        and remote.get("low_confirmed") is True,
        "Remote cleanup errors or unconfirmed sysfs release",
    )
    outputs = remote.get("outputs")
    require(
        isinstance(outputs, list)
        and len(outputs) == 1
        and isinstance(outputs[0], dict),
        "Expected one remote output only",
    )
    output = outputs[0]
    require(
        output.get("gpio") == 18
        and output.get("channel") == 2
        and output.get("backend") == "rp1-pwm"
        and output.get("compatible") == ["raspberrypi,rp1-pwm"]
        and output.get("gpio_of_node") is None
        and isinstance(output.get("of_node"), str)
        and output["of_node"].endswith("/rp1/pwm@98000")
        and isinstance(output.get("chip"), str)
        and re.fullmatch(r"/sys/class/pwm/pwmchip[0-9]+", output["chip"]),
        "Provider must be header RP1 PWM0 channel2, not fan/PIO/software PWM",
    )
    require(
        all(
            output.get(key) == value
            for key, value in {
                "frequency": 50,
                "duty_u16": 4915,
                "period_ns": PERIOD_NS,
                "active_duty_ns": ACTIVE_DUTY_NS,
            }.items()
        ),
        "Remote requested period/interior duty does not match the bench",
    )
    require(
        output.get("released") is True
        and output.get("cleanup_low_confirmed") is True
        and output.get("cleanup_final_readback") == expected_readback("normal", 0, 0),
        "Cleanup must confirm normal polarity, zero duty, disabled and released",
    )
    start, end = remote.get("begin_ns"), remote.get("end_ns")
    require(
        type(start) is int and type(end) is int and 0 <= start < end,
        "Invalid remote run monotonic timestamps",
    )
    require(
        end - start < 15_000_000_000 and remote.get("hard_max_run_seconds") == 14,
        "Remote run must retain the 14 s watchdog and sub-15 s bound",
    )
    phases = remote.get("phases")
    require(
        isinstance(phases, list) and len(phases) == len(PHASES),
        "Metadata must describe all nine phases",
    )
    previous_end = start
    for index, (phase, expected) in enumerate(zip(phases, PHASES)):
        name, duration, polarity, duty, intent = expected
        require(isinstance(phase, dict), f"Phase {index} must be an object")
        require(
            phase.get("name") == name
            and phase.get("polarity") == polarity
            and phase.get("duty_ns") == duty
            and phase.get("duty_u16") == (4915 if duty else 0)
            and phase.get("intent") == intent,
            f"Phase {index} has unexpected name/polarity/duty/intent",
        )
        requested = phase.get("duration_seconds")
        require(
            finite_number(requested)
            and math.isclose(requested, duration, rel_tol=0, abs_tol=1e-9),
            f"Phase {index} requested duration does not match protocol",
        )
        ticks = [
            phase.get(key)
            for key in ("transition_begin_ns", "begin_ns", "stable_begin_ns", "end_ns")
        ]
        require(
            all(type(tick) is int for tick in ticks)
            and previous_end <= ticks[0] == ticks[1] <= ticks[2] < ticks[3] <= end,
            f"Phase {index} has invalid or unordered monotonic timestamps",
        )
        require(
            duration - 1e-6 <= (ticks[3] - ticks[2]) / 1e9 <= duration + 1,
            f"Phase {index} stable hold duration is inconsistent with request",
        )
        previous_end = ticks[3]
        readback_end = phase.get("readback_end_ns")
        require(
            type(readback_end) is int and ticks[3] <= readback_end <= end,
            f"Phase {index} has invalid end-readback timestamp",
        )
        previous_end = readback_end
        for key in ("sysfs_readbacks", "end_readbacks"):
            require(
                phase.get(key) == {"18": expected_readback(polarity, duty)},
                f"Phase {index} {key} must confirm the exact enabled state",
            )
    validate_events(output, phases, start, end)
    for when, limit in (("before", 65000), ("after", 75000)):
        thermal = remote.get("thermal")
        snapshot = thermal.get(when) if isinstance(thermal, dict) else None
        require(
            isinstance(snapshot, dict) and not thermal_issues(snapshot, limit),
            f"Remote {when} thermal/firmware gate does not pass",
        )
    provenance = remote.get("metadata")
    hashes = provenance.get("source_sha256") if isinstance(provenance, dict) else None
    require(
        isinstance(hashes, dict)
        and set(hashes) == {"kernel_pwm_eval.py", "kernel_pwm_inverse_eval.py"}
        and all(
            isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value)
            for value in hashes.values()
        ),
        "Missing helper/base source SHA256 provenance",
    )
    return output


def validate_events(output, phases, start, end):
    events = output.get("sysfs_events")
    require(isinstance(events, list) and events, "Missing remote sysfs event audit")
    previous_end = start
    allowed = {
        "period": (PERIOD_NS,),
        "duty_cycle": (0, ACTIVE_DUTY_NS),
        "polarity": ("normal", "inversed"),
        "enable": (0, 1),
    }
    scopes = {phase["name"]: phase for phase in phases}
    recorded_state, ownership = {}, False
    exports = unexports = 0
    phase_reads = {name: [] for name in scopes}
    cleanup_low_reads = []
    for event in events:
        require(
            isinstance(event, dict)
            and event.get("status") == "ok"
            and event.get("operation") in ("write", "readback")
            and event.get("scope") in ("initialization", "cleanup", *scopes),
            "Sysfs audit has invalid operation/status/scope",
        )
        begin, finish = event.get("begin_ns"), event.get("end_ns")
        require(
            type(begin) is int
            and type(finish) is int
            and previous_end <= begin <= finish <= end,
            "Sysfs event monotonic timestamps are invalid or unordered",
        )
        previous_end = finish
        scope = event["scope"]
        if scope in scopes:
            phase = scopes[scope]
            require(
                phase["begin_ns"] <= begin <= finish <= phase["readback_end_ns"],
                "Sysfs event lies outside its reported phase",
            )
        elif scope == "initialization":
            require(
                finish <= phases[0]["begin_ns"], "Initialization audit overlaps phases"
            )
        else:
            require(
                begin >= phases[-1]["readback_end_ns"], "Cleanup audit overlaps phases"
            )
        if event["operation"] == "write":
            attribute, value = event.get("attribute"), event.get("value")
            if attribute in ("export", "unexport"):
                require(
                    event.get("path") == f"{output['chip']}/{attribute}" and value == 2,
                    "Ownership writes must target the approved chip and channel2",
                )
                if attribute == "export":
                    require(
                        not ownership and not exports and scope == "initialization",
                        "Export audit does not establish fresh ownership",
                    )
                    ownership, exports = True, exports + 1
                else:
                    require(
                        ownership
                        and not unexports
                        and scope == "cleanup"
                        and recorded_state == expected_readback("normal", 0, 0),
                        "Unexport must follow restored normal-low disabled state",
                    )
                    ownership, unexports = False, unexports + 1
            else:
                require(
                    ownership
                    and attribute in allowed
                    and value in allowed[attribute]
                    and event.get("path") == f"{output['chip']}/pwm2/{attribute}",
                    "Sysfs write audit has unexpected path/attribute/value or no ownership",
                )
                require(
                    attribute != "polarity" or recorded_state.get("enable") == 0,
                    "Polarity audit must switch while disabled",
                )
                recorded_state[attribute] = value
                require(
                    recorded_state.get("polarity") != "inversed"
                    or recorded_state.get("duty_cycle", 0) == 0,
                    "Inversed polarity audit permits zero duty only",
                )
        else:
            state = event.get("state")
            require(
                ownership
                and isinstance(state, dict)
                and state == event.get("expected") == recorded_state
                and state.get("period") == PERIOD_NS
                and state.get("duty_cycle") in (0, ACTIVE_DUTY_NS)
                and state.get("polarity") in ("normal", "inversed")
                and state.get("enable") in (0, 1),
                "Sysfs readback audit disagrees with expected/written state",
            )
            if scope in scopes:
                require(
                    state
                    == expected_readback(
                        phase["polarity"], phase["duty_ns"], state["enable"]
                    ),
                    "Sysfs readback audit differs from phase state",
                )
                phase_reads[scope].append(event)
            elif scope == "cleanup" and state == expected_readback("normal", 0, 1):
                cleanup_low_reads.append(event)
    require(
        exports == unexports == 1
        and not ownership
        and events[0].get("attribute") == "export"
        and events[-1].get("attribute") == "unexport",
        "Audit must show one fresh export and final unexport",
    )
    require(
        len(cleanup_low_reads) >= 2
        and cleanup_low_reads[-1]["begin_ns"] - cleanup_low_reads[0]["end_ns"]
        >= 90_000_000,
        "Audit lacks settled enabled normal-low cleanup readbacks",
    )
    for name, phase in scopes.items():
        reads = [event for event in phase_reads[name] if event["state"]["enable"] == 1]
        require(
            any(event["end_ns"] <= phase["stable_begin_ns"] for event in reads)
            and any(event["begin_ns"] >= phase["end_ns"] for event in reads),
            f"Phase {name} audit lacks start and end enabled readbacks",
        )


def validate_saved_capture(path):
    """Read recorded settings, not merely requested settings in results.json."""
    try:
        with zipfile.ZipFile(path) as archive:
            data = json.loads(archive.read("meta.json"))["data"]
        settings = data["legacySettings"]
        require(
            settings["enabledChannels"] == [{"type": "Digital", "index": 0}],
            "Saved SAL must capture digital channel0 only",
        )
        require(
            settings["sampleRate"].get("digital") == SAMPLE_RATE_HZ,
            "Saved SAL must confirm 100 MSa/s",
        )
        require(
            settings["glitchFilter"] == {"enabled": False, "channels": []},
            "Saved SAL must confirm disabled, empty glitch filter",
        )
        require(
            data["legacyDevice"].get("isSimulation") is False,
            "Saved SAL must identify a physical, non-simulated device",
        )
        device_id = data["legacyDevice"].get("deviceId")
        if device_id is not None:
            try:
                device_id = int(str(device_id), 10 if str(device_id).isdigit() else 16)
            except ValueError as error:
                raise ValueError("Invalid saved SAL device identity") from error
            require(
                device_id == int("81F8C2631DF5BF30", 16),
                "Saved SAL uses an unexpected device",
            )
    except (
        OSError,
        zipfile.BadZipFile,
        KeyError,
        TypeError,
        json.JSONDecodeError,
    ) as error:
        raise ValueError(f"Invalid saved SAL settings: {error}") from error
    return {
        "digital_channels": [0],
        "digital_sample_rate_hz": SAMPLE_RATE_HZ,
        "glitch_filter_enabled": False,
        "glitch_filter_channels": [],
        "physical_device": True,
    }


def read_continuous(path):
    """Reuse binary reader, adding mandatory checks even under python -O."""
    try:
        with path.open("rb") as stream:
            magic = stream.read(8)
            version_header, kind = struct.unpack("<ii", stream.read(8))
        require(
            magic == b"<SALEAE>" and version_header in (0, 1) and kind == 0,
            "Invalid Saleae digital header",
        )
        version, chunks = read_digital(path)
        require(len(chunks) == 1, "Requires one continuous capture chunk")
        initial, begin, end, sample_rate, edges = chunks[0]
        require(
            finite_number(begin) and finite_number(end) and begin < end,
            "Invalid digital capture bounds",
        )
        require(
            sample_rate is None or sample_rate == SAMPLE_RATE_HZ,
            "Binary header sample rate must match 100 MSa/s",
        )
        require(
            initial in (0, 1)
            and all(finite_number(edge) and begin <= edge <= end for edge in edges)
            and all(first < second for first, second in itertools.pairwise(edges)),
            "Digital transitions must be finite, ordered and covered",
        )
        expected_bytes = (
            16 + (8 if version else 0) + (36 if version else 28) + 8 * len(edges)
        )
        require(
            path.stat().st_size == expected_bytes,
            "Unexpected trailing/truncated binary data",
        )
    except (AssertionError, OSError, EOFError, ValueError, struct.error) as error:
        raise ValueError(f"Invalid digital export {path.name}: {error}") from error
    require(initial == 0, "Digital capture did not start low")
    final = initial ^ (len(edges) % 2)
    require(final == 0, "Digital capture did not finish low")
    require(
        edges and edges[0] - begin >= 0.15,
        "Capture lacks initial low coverage of at least 0.15 s",
    )
    tail = end - edges[-1]
    require(tail >= 0.15, "Capture lacks stable final low tail of at least 0.15 s")
    require(end - begin >= 2.3, "Capture lacks full protocol observation coverage")
    return {
        "binary_format_version": version,
        "header_sample_rate_hz": sample_rate,
        "chunks": 1,
        "begin_seconds": begin,
        "end_seconds": end,
        "initial_state": initial,
        "final_state": final,
        "edge_count": len(edges),
        "initial_low_seconds": edges[0] - begin,
        "quiet_tail_seconds": tail,
    }, edges


def bounded(value, bounds):
    return bounds[0] <= value <= bounds[1]


def validate_waveform(waveform, edges):
    highs = [(edges[index], edges[index + 1]) for index in range(0, len(edges), 2)]
    long_indices = []
    for index, (rise, fall) in enumerate(highs):
        width = fall - rise
        if bounded(width, HIGH_HOLD_BOUNDS_SECONDS):
            long_indices.append(index)
        else:
            require(
                bounded(width, PWM_HIGH_BOUNDS_SECONDS),
                "Unexpected high width/extra transitions: possible low dip inside a hold",
            )
    require(
        len(long_indices) == 2 and long_indices[1] == long_indices[0] + 1,
        "Requires two uninterrupted static high holds between the PWM trains",
    )
    first, second = long_indices
    groups = (highs[:first], highs[second + 1 :])
    controls = []
    for name, group in zip(("normal_active_control", "normal_active_recovery"), groups):
        require(
            18 <= len(group) <= 22,
            f"{name} requires 18–22 complete pulses for the 0.4 s control",
        )
        periods = [
            next_rise - rise for (rise, _), (next_rise, _) in itertools.pairwise(group)
        ]
        require(
            all(bounded(period, PWM_PERIOD_BOUNDS_SECONDS) for period in periods),
            f"{name} has irregular periods, missing cycles or extra transitions",
        )
        widths = [fall - rise for rise, fall in group]
        extent = group[-1][0] - group[0][0] + statistics.median(periods)
        require(0.35 <= extent <= 0.45, f"{name} does not span approximately 0.4 s")
        controls.append(
            {
                "phase": name,
                "pulse_count": len(group),
                "first_rise_seconds": group[0][0],
                "last_fall_seconds": group[-1][1],
                "train_duration_estimate_seconds": extent,
                "period_us": describe([period * 1e6 for period in periods]),
                "high_us": describe([width * 1e6 for width in widths]),
            }
        )
    holds = [highs[index] for index in long_indices]
    gaps = [
        holds[0][0] - groups[0][-1][1],
        holds[1][0] - holds[0][1],
        groups[1][0][0] - holds[1][1],
    ]
    require(
        all(bounded(gap, LOW_GAP_BOUNDS_SECONDS) for gap in gaps),
        "Static high holds and PWM trains lack expected normal-low gaps",
    )
    sample_interval = 1 / SAMPLE_RATE_HZ
    endpoints = []
    for index, (rise, fall) in enumerate(holds, 1):
        width = fall - rise
        endpoints.append(
            {
                "phase": f"inverse_zero_high_{index}",
                "rise_seconds": rise,
                "fall_seconds": fall,
                "digitized_high_width_seconds": width,
                "sampling_only_width_bounds_seconds": [
                    width - sample_interval,
                    width + sample_interval,
                ],
                "captured_interior_low_transition_count": 0,
            }
        )
    waveform["transition_seconds"] = list(edges)
    return {
        "physical_sequence_validated": True,
        "sequence": [phase[0] for phase in PHASES],
        "phase_alignment_proven": False,
        "controls": controls,
        "inverse_zero_high_holds": endpoints,
        "normal_low_gap_seconds": gaps,
        "high_hold_acceptance_bounds_seconds": list(HIGH_HOLD_BOUNDS_SECONDS),
        "additional_captured_low_dips_inside_high_holds": 0,
    }


def analyze(directory):
    directory = Path(directory)
    metadata = json.loads((directory / "results.json").read_text())
    remote = json.loads((directory / "remote.stdout").read_text())
    provider = validate_metadata(metadata, remote)
    saved_settings = validate_saved_capture(directory / "waveform.sal")
    waveform, edges = read_continuous(directory / "digital_0.bin")
    physical = validate_waveform(waveform, edges)
    return {
        "capture": directory.name,
        "mode": MODE,
        "host": metadata["host"],
        "offline_analysis": True,
        "accepted": True,
        "sample_rate_hz": SAMPLE_RATE_HZ,
        "production_backend_unchanged_reported": True,
        "sysfs_released_reported": True,
        "cleanup_normal_low_confirmed_reported": True,
        "provider": {
            key: provider[key]
            for key in ("gpio", "channel", "chip", "of_node", "compatible", "backend")
        },
        "source_sha256_reported": remote["metadata"]["source_sha256"],
        "saved_capture_settings": saved_settings,
        "common_observation_interval_seconds": [
            waveform["begin_seconds"],
            waveform["end_seconds"],
        ],
        "common_final_low_tail_seconds": waveform["quiet_tail_seconds"],
        "clock_alignment": "Saleae time is not aligned to Pi monotonic phase clocks.",
        "quantization": {
            "nominal_sample_interval_ns": 10.0,
            "timebase_calibrated": False,
            "width_bounds_include_clock_accuracy": False,
            "note": "Width bounds include sampling quantization only, not clock accuracy.",
        },
        "limitation": "Finite 100 MSa/s digital threshold observation with no glitch filter; "
        "no extra captured transitions, not analog proof or exclusion of sub-sample glitches.",
        "outputs": [{**OUTPUT, "waveform": waveform}],
        "physical": physical,
    }


def write_analysis(directory, output_name="analysis.json"):
    require(
        bool(output_name)
        and Path(output_name).name == output_name
        and output_name not in (".", ".."),
        "Output must be a filename in capture directory",
    )
    result = analyze(directory)
    with (Path(directory) / output_name).open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output-name", default="analysis.json")
    args = parser.parse_args()
    try:
        result = write_analysis(args.directory, args.output_name)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
