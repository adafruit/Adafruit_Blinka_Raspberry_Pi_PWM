"""Fake-only genuine native consumer collector tests; no hardware or SSH."""

import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_native_pwm_consumers as bench
import pytest
import test_native_pwm_consumers_eval as consumer_fakes

ROOT = "/tmp/blinka-pwm-native-consumers.abc123"
PYTHON = "/tmp/blinka-pwm-oct6.F3SDcm/venv/bin/python"
old_environment = consumer_fakes.old_environment
dual_environment = consumer_fakes.dual_environment
environment = consumer_fakes.environment


def configure(monkeypatch, scenario="success"):
    events = []
    manifest = {"schema_version": 1, "source_sha256": {"fake": "a" * 64}}
    receipt = {"backend": bench.BACKEND, "manifest_path": ROOT + "/manifest.json"}
    monkeypatch.setattr(bench.helper, "load_manifest", lambda _path: manifest)
    local = MagicMock(return_value=manifest["source_sha256"])
    validate = MagicMock()
    if scenario == "bad_receipt":
        validate.side_effect = ValueError("bad consumer action receipt")
    monkeypatch.setattr(bench, "validate_local_manifest", local)
    monkeypatch.setattr(bench, "validate_remote", validate)
    capture = MagicMock()
    capture.__enter__.return_value = capture
    capture.stop.side_effect = lambda: events.append("stop")

    def save(path):
        events.append("save")
        if scenario == "save_error":
            raise OSError("save failed")
        Path(path).write_bytes(b"fake SAL")

    def export(path, **kwargs):
        assert kwargs == {"digital_channels": [0, 1]}
        events.append("export")
        (Path(path) / "digital_0.bin").write_bytes(b"fake GPIO18 PWM edges")
        if scenario != "missing_gpio23":
            (Path(path) / "digital_1.bin").write_bytes(b"fake GPIO23 PWM edges")

    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = export
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=MagicMock(return_value=manager)),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            PYTHON,
            ROOT + "/native_pwm_consumers_eval.py",
            "--manifest",
            ROOT + "/manifest.json",
        ]
        assert set(kwargs) == {"stdout", "stderr", "text", "check", "timeout"}
        assert (
            kwargs["text"] is True
            and kwargs["check"] is False
            and kwargs["timeout"] == 30
        )
        if scenario in ("timeout", "interrupt"):
            kwargs["stdout"].write("partial receipt")
            kwargs["stderr"].write("partial diagnostic")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            raise KeyboardInterrupt("interrupted")
        kwargs["stdout"].write(json.dumps(receipt))
        return subprocess.CompletedProcess(
            command, 1 if scenario == "helper_failed" else 0
        )

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(
        bench.time, "sleep", lambda duration: events.append(("sleep", duration))
    )
    return events, manager, runner, local, validate, manifest, receipt


def test_capture_both_unfiltered_pwm_channels_and_defer_verdict(monkeypatch, tmp_path):
    events, manager, runner, _local, validate, manifest, receipt = configure(
        monkeypatch
    )
    output = tmp_path / "capture"
    result = bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    assert events == [("sleep", 0.5), "ssh", ("sleep", 0.2), "stop", "save", "export"]
    manager.start_capture.assert_called_once_with(
        device_id="81F8C2631DF5BF30",
        device_configuration={
            "enabled_digital_channels": [0, 1],
            "digital_sample_rate": 100_000_000,
        },
    )
    runner.assert_called_once()
    validate.assert_called_once_with(receipt, manifest)
    assert result["collection_success"] is True
    assert result["outputs"] == [
        {"gpio": 18, "saleae_channel": 0, "backend": bench.BACKEND},
        {"gpio": 23, "saleae_channel": 1, "backend": bench.BACKEND},
    ]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert result["parity_evaluated"] is False and result["analysis_deferred"] is True
    assert json.loads((output / "manifest.json").read_text()) == manifest
    assert json.loads((output / "results.json").read_text()) == result
    assert (output / "waveform.sal").read_bytes() == b"fake SAL"
    assert (output / "digital_0.bin").read_bytes() == b"fake GPIO18 PWM edges"
    assert (output / "digital_1.bin").read_bytes() == b"fake GPIO23 PWM edges"


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "save_error",
        "missing_gpio23",
        "simulation",
        "helper_failed",
        "bad_receipt",
    ],
)
def test_failures_keep_metadata_and_available_raw_evidence(
    monkeypatch, tmp_path, scenario
):
    events, _manager, runner, _local, _validate, _manifest, _receipt = configure(
        monkeypatch, scenario
    )
    output = tmp_path / "capture"
    with pytest.raises((ValueError, RuntimeError, KeyboardInterrupt)):
        bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    acquisition = json.loads((output / "acquisition.json").read_text())
    result = json.loads((output / "results.json").read_text())
    assert result["collection_success"] is False and result["receipt_validation_error"]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    if scenario == "simulation":
        runner.assert_not_called()
        assert not events
    else:
        assert events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
        assert (output / "digital_0.bin").is_file()
        if scenario != "missing_gpio23":
            assert (output / "digital_1.bin").is_file()
    if scenario in ("timeout", "interrupt"):
        assert (output / "remote.stdout").read_text() == "partial receipt"
        assert (output / "remote.stderr").read_text() == "partial diagnostic"
        assert acquisition["remote_returncode"] == (
            124 if scenario == "timeout" else None
        )
    if scenario == "save_error":
        assert acquisition["evidence_errors"] == ["save_capture: OSError: save failed"]


@pytest.mark.parametrize(
    "root,python",
    [("/tmp", PYTHON), (ROOT, PYTHON + ";unsafe"), (ROOT, "/usr/bin/python3")],
)
def test_invalid_remote_inputs_refuse_before_output_and_ssh(
    monkeypatch, tmp_path, root, python
):
    _events, _manager, runner, local, _validate, _manifest, _receipt = configure(
        monkeypatch
    )
    with pytest.raises(ValueError):
        bench.capture_test(
            tmp_path / "capture", root, python, tmp_path / "manifest.json"
        )
    runner.assert_not_called()
    local.assert_not_called()
    assert not (tmp_path / "capture").exists()


def test_exclusive_output_preserves_existing_evidence(monkeypatch, tmp_path):
    _events, _manager, runner, _local, _validate, _manifest, _receipt = configure(
        monkeypatch
    )
    output = tmp_path / "capture"
    output.mkdir()
    sentinel = output / "previous.txt"
    sentinel.write_text("keep")
    with pytest.raises(FileExistsError):
        bench.capture_test(output, ROOT, PYTHON, tmp_path / "manifest.json")
    assert sentinel.read_text() == "keep"
    runner.assert_not_called()


def test_genuine_consumer_fake_receipt_validates_local_python_and_software_states(
    environment,
):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = bench.helper.experiment(ROOT + "/manifest.json")
    assert receipt["success"]
    bench.validate_remote(receipt, manifest)
    assert bench.validate_local_manifest(manifest) == manifest["source_sha256"]


@pytest.mark.parametrize(
    "problem",
    [
        "midpoint",
        "brake",
        "shim",
        "action_error",
        "cleanup",
        "fd",
        "constructor",
        "sibling",
    ],
)
def test_receipt_rejects_wrong_consumer_mapping_or_unsafe_claims(environment, problem):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = bench.helper.experiment(ROOT + "/manifest.json")
    assert receipt["success"]
    if problem == "midpoint":
        receipt["actions"][1]["consumer_readback"] = 90
    elif problem == "brake":
        receipt["phases"][7]["api_state"][0]["duty_u16"] = 0
    elif problem == "shim":
        receipt["integration_shim"]["installed_blinka_compatibility_proven"] = True
    elif problem == "action_error":
        receipt["actions"][4]["status"] = "error"
    elif problem == "cleanup":
        receipt["outputs"][1]["cleanup_final_readback"]["gpio_level"] = False
    elif problem == "fd":
        receipt["outputs"][2]["owned_request"]["fd"] = receipt["outputs"][1][
            "owned_request"
        ]["fd"]
    elif problem == "constructor":
        event = next(
            e for e in receipt["events"] if e["operation"] == "PWMOut.__init__"
        )
        event["arguments"]["variable_frequency"] = False
    else:
        receipt["shutdowns"][1]["sibling_after"]["gpio_level"] = 1
    with pytest.raises(ValueError):
        bench.validate_remote(receipt, manifest)


def test_cli_no_blinka_or_actuator_verdict(monkeypatch, tmp_path, capsys):
    capture = MagicMock(return_value={"collection_success": True})
    monkeypatch.setattr(bench, "capture_test", capture)
    assert (
        bench.main(
            [
                str(tmp_path / "capture"),
                "--remote-root",
                ROOT,
                "--remote-python",
                PYTHON,
                "--manifest",
                str(tmp_path / "manifest.json"),
            ]
        )
        == 0
    )
    capture.assert_called_once_with(
        tmp_path / "capture", ROOT, PYTHON, tmp_path / "manifest.json"
    )
    summary = json.loads(capsys.readouterr().out)
    assert summary["waveform_accepted"] is None and summary["parity_evaluated"] is False
