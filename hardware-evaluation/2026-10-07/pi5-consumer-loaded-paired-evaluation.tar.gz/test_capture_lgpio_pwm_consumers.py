"""Hardware-free original-consumer collector fakes; no manager/SSH calls."""

import hashlib
import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_lgpio_pwm_consumers as bench
import pytest
import test_lgpio_pwm_consumers_eval as helper_fakes

ROOT = "/tmp/blinka-pwm-lgpio-consumers.ABC123"
PYTHON = "/tmp/blinka-pwm-oct6.F3SDcm/venv/bin/python"
original_environment = helper_fakes.original_environment
original_consumer_environment = helper_fakes.environment


def manifest_for_local(monkeypatch):
    hashes = {key: "a" * 64 for key in bench.helper.SOURCE_KEYS}
    hashes.update(bench.helper.SOURCE_PINS)
    hashes.update(
        {
            key: hashlib.sha256(path.read_bytes()).hexdigest()
            for key, path in bench.local_source_inventory().items()
        }
    )
    monkeypatch.setattr(bench, "HELPER_SHA256", hashes[bench.helper.NEW_SOURCE])
    return {"schema_version": 1, "motor_version": "3.5.0", "source_sha256": hashes}


def configure(monkeypatch, tmp_path, scenario="success"):
    events = []
    manifest = manifest_for_local(monkeypatch)
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(manifest))
    receipt = {
        "backend": bench.BACKEND,
        "source_sha256": manifest["source_sha256"],
        "manifest_path": ROOT + "/manifest.json",
        "python_executable": PYTHON,
    }
    if scenario == "wrong_root":
        receipt["manifest_path"] = "/tmp/other/manifest.json"
    if scenario == "wrong_python":
        receipt["python_executable"] = "/usr/bin/python3"
    validate = MagicMock()
    if scenario == "bad_receipt":
        validate.side_effect = bench.helper.core.BenchError("bad action receipt")
    monkeypatch.setattr(bench.helper, "validate_receipt", validate)
    capture = MagicMock()
    capture.__enter__.return_value = capture

    def stop():
        events.append("stop")
        if scenario == "stop_error":
            raise OSError("stop failed")

    def save(path):
        events.append("save")
        if scenario in ("save_error", "multiple_errors"):
            raise OSError("save failed")
        Path(path).write_bytes(b"fake saved SAL")

    def export(path, **kwargs):
        assert kwargs == {"digital_channels": [0, 1]}
        events.append("export")
        (Path(path) / "digital_0.bin").write_bytes(b"complete fake ch0")
        if scenario in ("export_error", "multiple_errors"):
            raise OSError("export failed after ch0")
        if scenario != "missing_ch1":
            (Path(path) / "digital_1.bin").write_bytes(
                b"" if scenario == "empty_ch1" else b"complete fake ch1"
            )

    capture.stop.side_effect = stop
    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = export
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = (
        []
        if scenario == "unavailable"
        else [
            SimpleNamespace(
                device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
            )
        ]
    )
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    if scenario == "manager_close_error":
        manager.__exit__.side_effect = OSError("manager close failed")
    connect = MagicMock(return_value=manager)
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=connect),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            PYTHON,
            ROOT + "/lgpio_pwm_consumers_eval.py",
            "--manifest",
            ROOT + "/manifest.json",
        ]
        assert (
            kwargs["text"] is True
            and kwargs["check"] is False
            and kwargs["timeout"] == 30
        )
        if scenario in ("timeout", "interrupt", "multiple_errors"):
            kwargs["stdout"].write("partial receipt")
            kwargs["stderr"].write("partial diagnostic")
            if scenario == "interrupt":
                raise KeyboardInterrupt("interrupted")
            raise subprocess.TimeoutExpired(command, 30)
        kwargs["stdout"].write(json.dumps(receipt))
        kwargs["stderr"].write("nonempty informational diagnostic\n")
        return subprocess.CompletedProcess(
            command,
            17 if scenario == "ssh_failed" else False if scenario == "bool_exit" else 0,
        )

    runner = MagicMock(side_effect=run)
    # Replace only the NEW collector's facade, never frozen collector globals.
    monkeypatch.setattr(bench, "subprocess", SimpleNamespace(run=runner))

    def sleep(duration):
        events.append(("sleep", duration))
        if scenario == "tail_error" and duration == 0.2:
            raise OSError("tail failed")

    clock = iter(range(1000, 10000))
    monkeypatch.setattr(
        bench, "time", SimpleNamespace(sleep=sleep, monotonic_ns=lambda: next(clock))
    )
    return path, manifest, receipt, events, manager, connect, runner, validate


def test_local_inventory_exact_python_sources_not_mac_guesses_for_linux(monkeypatch):
    manifest = manifest_for_local(monkeypatch)
    paths = bench.local_source_inventory()
    assert len(manifest["source_sha256"]) == 21 and len(paths) == 13
    assert not set(paths) & bench.REMOTE_LIBRARY_KEYS
    assert set(paths) | bench.REMOTE_LIBRARY_KEYS == bench.helper.SOURCE_KEYS
    assert bench.validate_local_manifest(manifest) == manifest["source_sha256"]
    assert len([key for key in paths if key.startswith("adafruit_motor/")]) == 3


def test_fixed_physical_channels_actual_exit_nonempty_stderr_and_deferred_verdict(
    monkeypatch, tmp_path
):
    path, manifest, receipt, events, manager, _connect, runner, validate = configure(
        monkeypatch, tmp_path
    )
    output = tmp_path / "capture"
    result = bench.capture_test(output, ROOT, PYTHON, path)
    assert events == [("sleep", 0.5), "ssh", ("sleep", 0.2), "stop", "save", "export"]
    manager.start_capture.assert_called_once_with(
        device_id=bench.DEVICE_ID,
        device_configuration={
            "enabled_digital_channels": [0, 1],
            "digital_sample_rate": 100_000_000,
            "glitch_filters": [],
        },
    )
    runner.assert_called_once()
    validate.assert_called_once_with(receipt, manifest)
    assert result["remote"] == receipt and result["remote_returncode"] == 0
    assert result["source_manifest"] == manifest
    assert (
        result["collection_success"]
        and result["original_variable_frequency_default"] is False
    )
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert not result["parity_evaluated"] and result["analysis_deferred"]
    assert (
        not result["installed_blinka_compatibility_proven"]
        and not result["actual_actuators_attached"]
    )
    assert (
        not result["native_backend_executed"]
        and result["additional_lab_cleanup_required"]
    )
    assert (
        output / "remote.stderr"
    ).read_text() == "nonempty informational diagnostic\n"
    assert json.loads((output / "results.json").read_text()) == result
    acquisition = json.loads((output / "acquisition.json").read_text())
    assert acquisition["primary_error"] is None and acquisition["evidence_errors"] == []
    assert not acquisition["ssh_exit_unavailable_after_exception"]
    assert (output / "digital_1.bin").read_bytes() == b"complete fake ch1"


def test_original_percent_quantization_nominals_not_native_targets():
    assert {
        key: row["submitted_duty_percent"]
        for key, row in bench.PERCENT_NOMINALS.items()
    } == {
        "servo_angle0": 5,
        "servo_angle90": 7,
        "servo_angle180": 10,
        "motor_half": 50,
    }
    assert {
        key: row["submitted_nominal_high_us"]
        for key, row in bench.PERCENT_NOMINALS.items()
    } == {
        "servo_angle0": 1000,
        "servo_angle90": 1400,
        "servo_angle180": 2000,
        "motor_half": 500,
    }


@pytest.mark.parametrize(
    "scenario",
    [
        "unavailable",
        "simulation",
        "ssh_failed",
        "bool_exit",
        "timeout",
        "interrupt",
        "save_error",
        "export_error",
        "stop_error",
        "tail_error",
        "manager_close_error",
        "multiple_errors",
        "missing_ch1",
        "empty_ch1",
        "wrong_root",
        "wrong_python",
        "bad_receipt",
    ],
)
def test_failure_artifacts_actual_status_and_finalization_preserved(
    monkeypatch, tmp_path, scenario
):
    path, _manifest, _receipt, events, _manager, _connect, runner, _validate = (
        configure(monkeypatch, tmp_path, scenario)
    )
    output = tmp_path / "capture"
    with pytest.raises((ValueError, RuntimeError, bench.helper.core.BenchError)):
        bench.capture_test(output, ROOT, PYTHON, path)
    acquisition = json.loads((output / "acquisition.json").read_text())
    result = json.loads((output / "results.json").read_text())
    assert not result["collection_success"] and result["receipt_validation_error"]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert (output / "remote.stdout").is_file() and (output / "remote.stderr").is_file()
    if scenario in ("unavailable", "simulation"):
        runner.assert_not_called()
        assert not events and acquisition["remote_returncode"] is None
    else:
        assert events[-4:] == [("sleep", 0.2), "stop", "save", "export"]
        assert (output / "digital_0.bin").is_file()
    if scenario in ("timeout", "interrupt", "multiple_errors"):
        assert acquisition["remote_returncode"] is None
        assert acquisition["ssh_exit_unavailable_after_exception"]
        assert (output / "remote.stdout").read_text() == "partial receipt"
        assert (output / "remote.stderr").read_text() == "partial diagnostic"
    if scenario == "ssh_failed":
        assert acquisition["remote_returncode"] == 17
    if scenario == "multiple_errors":
        assert acquisition["primary_error"].startswith("TimeoutExpired:")
        assert acquisition["evidence_errors"] == [
            "save_capture: OSError: save failed",
            "export_binary: OSError: export failed after ch0",
        ]


def test_local_source_change_refused_before_output_or_connect(monkeypatch, tmp_path):
    path, manifest, _receipt, _events, _manager, connect, runner, _validate = configure(
        monkeypatch, tmp_path
    )
    manifest["source_sha256"][bench.helper.NEW_SOURCE] = "0" * 64
    path.write_text(json.dumps(manifest))
    output = tmp_path / "capture"
    with pytest.raises(ValueError, match="Frozen original consumer helper"):
        bench.capture_test(output, ROOT, PYTHON, path)
    assert not output.exists()
    connect.assert_not_called()
    runner.assert_not_called()


def test_available_consumer_bytes_mismatch_refused_without_mutating_source(
    monkeypatch, tmp_path
):
    path, _manifest, _receipt, _events, _manager, connect, runner, _validate = (
        configure(monkeypatch, tmp_path)
    )
    inventory = bench.local_source_inventory()
    wrong = tmp_path / "wrong-servo.py"
    wrong.write_text("not the pinned genuine Servo source")
    inventory["adafruit_motor/servo.py"] = wrong
    monkeypatch.setattr(bench, "local_source_inventory", lambda: inventory)
    output = tmp_path / "capture"
    with pytest.raises(ValueError, match="Local original/helper/consumer Python"):
        bench.capture_test(output, ROOT, PYTHON, path)
    assert not output.exists()
    connect.assert_not_called()
    runner.assert_not_called()


def test_frozen_helper_and_genuine_original_receipt_integration(
    original_consumer_environment,
):
    manifest = original_consumer_environment[2]
    remote = helper_fakes.run(original_consumer_environment)
    assert (
        hashlib.sha256(Path(bench.helper.__file__).read_bytes()).hexdigest()
        == bench.HELPER_SHA256
    )
    assert bench.validate_local_manifest(manifest) == manifest["source_sha256"]
    bench.validate_remote(remote, manifest)
    assert [
        row["submitted_duty_percent"] for row in remote["actions"][1]["api_state_after"]
    ] == [7]
    assert (
        remote["actions"][1]["api_state_after"][0]["submitted_nominal_high_us"] == 1400
    )
    assert remote["integration_shim"]["restored"]
    assert not remote["public_deinit_cancels_or_frees_gpio"]


@pytest.mark.parametrize("tamper", [None, "duty", "shim", "source"])
def test_capture_uses_real_validator_for_genuine_class_receipt(
    original_consumer_environment, monkeypatch, tmp_path, tamper
):
    genuine = helper_fakes.run(original_consumer_environment)
    validator = bench.helper.validate_receipt
    path, manifest, receipt, _events, _manager, _connect, _runner, _validate = (
        configure(monkeypatch, tmp_path)
    )
    assert manifest == original_consumer_environment[2]
    receipt.clear()
    receipt.update(genuine)
    receipt["manifest_path"] = ROOT + "/manifest.json"
    receipt["python_executable"] = PYTHON
    if tamper == "duty":
        receipt["actions"][1]["api_state_after"][0]["duty_u16"] = 4915
    elif tamper == "shim":
        receipt["integration_shim"]["restored"] = False
    elif tamper == "source":
        receipt["source_sha256"] = {**receipt["source_sha256"], "_lgpio.so": "0" * 64}
    monkeypatch.setattr(bench.helper, "validate_receipt", validator)
    output = tmp_path / "capture"
    if tamper is None:
        result = bench.capture_test(output, ROOT, PYTHON, path)
        assert result["collection_success"] and result["remote"] == json.loads(
            json.dumps(receipt)
        )
    else:
        with pytest.raises(bench.helper.core.BenchError):
            bench.capture_test(output, ROOT, PYTHON, path)
        result = json.loads((output / "results.json").read_text())
        assert not result["collection_success"]
        assert (output / "digital_1.bin").read_bytes() == b"complete fake ch1"
        assert (
            output / "remote.stderr"
        ).read_text() == "nonempty informational diagnostic\n"


@pytest.mark.parametrize(
    "root,python",
    [("/tmp", PYTHON), (ROOT, "/usr/bin/python3"), (ROOT, PYTHON + ";unsafe")],
)
def test_unapproved_remote_inputs_refused_before_artifacts(
    monkeypatch, tmp_path, root, python
):
    path, _manifest, _receipt, _events, _manager, connect, runner, _validate = (
        configure(monkeypatch, tmp_path)
    )
    output = tmp_path / "capture"
    with pytest.raises(ValueError):
        bench.capture_test(output, root, python, path)
    assert not output.exists()
    connect.assert_not_called()
    runner.assert_not_called()


@pytest.mark.parametrize("symlink", [False, True])
def test_exclusive_output_preserves_existing_or_linked_data(
    monkeypatch, tmp_path, symlink
):
    path, _manifest, _receipt, _events, _manager, connect, runner, _validate = (
        configure(monkeypatch, tmp_path)
    )
    existing = tmp_path / "existing"
    existing.mkdir()
    (existing / "sentinel").write_text("preserve")
    output = tmp_path / "capture"
    if symlink:
        output.symlink_to(existing, target_is_directory=True)
    else:
        output = existing
    with pytest.raises((FileExistsError, ValueError)):
        bench.capture_test(output, ROOT, PYTHON, path)
    assert (existing / "sentinel").read_text() == "preserve"
    connect.assert_not_called()
    runner.assert_not_called()


@pytest.mark.parametrize("text", ['{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}', "[]"])
def test_strict_receipt_json(text):
    with pytest.raises(ValueError):
        bench.read_json(text)


def test_cli_exposes_collection_not_waveform_or_parity(monkeypatch, tmp_path, capsys):
    capture = MagicMock(return_value={"collection_success": True})
    monkeypatch.setattr(bench, "capture_test", capture)
    assert (
        bench.main(
            [
                str(tmp_path / "capture"),
                "--remote-root",
                ROOT,
                "--remote-python",
                PYTHON,
                "--manifest",
                str(tmp_path / "manifest.json"),
            ]
        )
        == 0
    )
    result = json.loads(capsys.readouterr().out)
    assert result["waveform_accepted"] is None and result["parity_evaluated"] is False
