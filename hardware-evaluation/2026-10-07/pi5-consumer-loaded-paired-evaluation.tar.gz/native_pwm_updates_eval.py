"""Lab-only default-native GPIO18 direct/frequency/half50 characterization.

Reuse the immutable native half50 ownership/cleanup implementation and pinned
Pi5 preflight. Variable frequency is explicitly enabled for direct/frequency;
unlike the original lgpio API, the native public API requires that permission.
No timing, scheduling or GPIO-driver hooks; no electrical/parity verdicts.
"""

import argparse
import hashlib
import json
import os
import re
import signal
import sys
import time
from pathlib import Path

import native_pwm_half50_eval as base

core = base.core
BACKEND = base.BACKEND
MODES = tuple(base.baseline.SEQUENCES)
SEQUENCES = base.baseline.SEQUENCES
ROOT_PATTERN = r"/tmp/blinka-pwm-native-updates\.[A-Za-z0-9]{6}"
BASE_HELPER_SHA256 = "3ac7fba7cb7bf348019b1cadaca5793ee9dcc6740c47264e838c326488316619"
NEW_SOURCE = "native_pwm_updates_eval.py"
SOURCE_KEYS = base.SOURCE_KEYS | {NEW_SOURCE}
MAX_RUN_SECONDS = base.MAX_RUN_SECONDS


def validate_manifest(manifest):
    if not isinstance(manifest, dict):
        raise core.BenchError("Invalid native updates source manifest")
    hashes = manifest.get("source_sha256")
    if not isinstance(hashes, dict) or set(hashes) != SOURCE_KEYS:
        raise core.BenchError("Exact seven-source SHA256 manifest required")
    base.validate_manifest(
        {
            "schema_version": manifest.get("schema_version"),
            "source_sha256": {
                key: value for key, value in hashes.items() if key != NEW_SOURCE
            },
        }
    )
    if hashes["native_pwm_half50_eval.py"] != BASE_HELPER_SHA256:
        raise core.BenchError("Immutable native half50 helper source manifest mismatch")
    if (
        not isinstance(hashes[NEW_SOURCE], str)
        or re.fullmatch(r"[0-9a-f]{64}", hashes[NEW_SOURCE]) is None
    ):
        raise core.BenchError("Invalid native updates helper SHA256")
    return hashes


def load_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise core.BenchError("Duplicate manifest key: " + key)
            result[key] = value
        return result

    manifest = json.loads(Path(path).read_text(), object_pairs_hook=pairs)
    validate_manifest(manifest)
    return manifest


def approved_manifest_path(path):
    path = Path(path)
    if (
        not path.is_absolute()
        or re.fullmatch(ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", str(path)) is None
    ):
        raise core.BenchError(
            "Manifest must be absolute under the isolated native-updates root"
        )
    if (
        path.resolve(strict=True) != path
        or path.parent != Path(__file__).resolve().parent
    ):
        raise core.BenchError(
            "Manifest and helper must share the isolated root without symlinks"
        )
    return path


def source_hashes():
    return {
        **base.source_hashes(),
        NEW_SOURCE: hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }


class Owner(base.Owner):
    def construct(self, pwm_class):
        self.pwm = pwm_class.__new__(pwm_class)
        kwargs = {"frequency": 50, "duty_cycle": 0}
        if self.receipt["variable_frequency"]:
            kwargs["variable_frequency"] = True
        with self.guard.atomic():
            self.call(
                "PWMOut.__init__",
                lambda: self.pwm.__init__((self.identity["gpiochip"], 18), **kwargs),
                {
                    "gpiochip": self.identity["gpiochip"],
                    "gpio": 18,
                    "frequency": 50,
                    "duty_u16": 0,
                    "variable_frequency": self.receipt["variable_frequency"],
                },
            )
            if not self.track_request():
                raise core.BenchError(
                    "Native PWM output returned without a private line request"
                )


def run_phase(owner, phases, name, duration, frequency, duty):
    owner.scope = name
    begin = time.monotonic_ns()
    # Match the baseline caller order, with no extra settles between setters.
    if owner.pwm.frequency != frequency:
        owner.call(
            "PWMOut.frequency",
            lambda: setattr(owner.pwm, "frequency", frequency),
            {"frequency": frequency, "duty_u16": owner.pwm.duty_cycle},
        )
    if owner.pwm.duty_cycle != duty:
        owner.call(
            "PWMOut.duty_cycle",
            lambda: setattr(owner.pwm, "duty_cycle", duty),
            {"frequency": frequency, "duty_u16": duty},
        )
    stable = time.monotonic_ns()
    phase = {
        "name": name,
        "generation": 1,
        "frequency": frequency,
        "duty_u16": duty,
        "duration_seconds": duration,
        "intent": "low"
        if duty == 0
        else "constant_high"
        if duty == 65535
        else "interior_pwm",
        "begin_ns": begin,
        "transition_begin_ns": begin,
        "stable_begin_ns": stable,
        "api_state": {
            "frequency": owner.pwm.frequency,
            "duty_cycle": owner.pwm.duty_cycle,
        },
    }
    time.sleep(duration)
    phase["end_ns"] = time.monotonic_ns()
    phase["api_state_end"] = {
        "frequency": owner.pwm.frequency,
        "duty_cycle": owner.pwm.duty_cycle,
    }
    phase["readback_end_ns"] = time.monotonic_ns()
    phases.append(phase)


def experiment(mode, manifest_path):
    variable_frequency = mode != "half50-direct"
    receipt = {
        "schema_version": 1,
        "mode": mode,
        "sequence_marker": f"native-updates-{mode}-v1",
        "backend": BACKEND,
        "gpio": 18,
        "helper_pid": os.getpid(),
        "characterization_only": True,
        "production_backend_unchanged": True,
        "parity_pass": None,
        "api_readbacks_are_not_electrical": True,
        "variable_frequency": variable_frequency,
        "original_variable_frequency_default": False,
        "variable_frequency_differs_from_original": variable_frequency,
        "runtime_flags": {"short_slice": False, "shared": False},
        "inherited_environment": {
            name: os.environ.get(name)
            for name in ("BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED")
        },
        "watchdog_seconds": MAX_RUN_SECONDS,
        "watchdog_cannot_bound_native_hang_or_sigkill": True,
        "begin_ns": time.monotonic_ns(),
        "phases": [],
        "events": [],
        "signals_received": [],
        "source_sha256": {},
        "before": None,
        "after": None,
        "primary_error": None,
        "cleanup_errors": [],
        "completed_normally": False,
        "fresh_claim_accepted": False,
        "gpio18_released": False,
        "read_only_chip_closed": False,
        "low_confirmed": False,
        "cleanup_final_readback": None,
        "success": False,
    }
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            if mode not in MODES:
                raise core.BenchError(
                    "Only direct, frequency and half50-direct are approved"
                )
            manifest_path = approved_manifest_path(manifest_path)
            manifest = load_manifest(manifest_path)
            validate_manifest(manifest)
            receipt["manifest_path"] = str(manifest_path)
            receipt["source_sha256"] = source_hashes()
            if receipt["source_sha256"] != manifest["source_sha256"]:
                raise core.BenchError(
                    "Installed native/updates/immutable helper source hash mismatch"
                )
            if any(value == "1" for value in receipt["inherited_environment"].values()):
                raise core.BenchError(
                    "Refusing inherited BLINKA_PWM_SHORT_SLICE/BLINKA_PWM_SHARED=1"
                )
            receipt["identity"] = base.baseline.preflight()
            receipt["before"] = core.system_snapshot()
            issues = core.thermal_issues(receipt["before"], 65000)
            if issues:
                raise core.BenchError("Thermal preflight: " + "; ".join(issues))
            library, module = base.load_backend()
            chip_info, line_info = base.inspect_line(library, receipt["identity"])
            receipt.update(
                chip_info=chip_info,
                preclaim_line_info=line_info,
                read_only_chip_closed=True,
            )
            if line_info["used"] or line_info["consumer"] not in (None, ""):
                raise core.BenchError("GPIO18 is already claimed; never borrow it")
            owner = Owner(library, receipt["identity"], guard, receipt)
            try:
                owner.construct(module.PWMOut)
                for phase in SEQUENCES[mode]:
                    run_phase(owner, receipt["phases"], *phase)
                receipt["completed_normally"] = True
            finally:
                with guard.cleanup():
                    signal.alarm(0)
                    owner.cleanup()
        except BaseException as error:
            receipt["primary_error"] = f"{type(error).__name__}: {error}"
        finally:
            with guard.cleanup():
                signal.alarm(0)
                try:
                    receipt["after"] = core.system_snapshot()
                    receipt["cleanup_errors"].extend(
                        core.thermal_issues(receipt["after"], 70000)
                    )
                except BaseException as error:
                    receipt["cleanup_errors"].append(
                        f"Thermal postflight: {type(error).__name__}: {error}"
                    )
                receipt["signals_received"] = list(guard.received)
    receipt["end_ns"] = time.monotonic_ns()
    receipt["success"] = bool(
        receipt["completed_normally"]
        and receipt["primary_error"] is None
        and not receipt["cleanup_errors"]
        and not receipt["signals_received"]
        and receipt["fresh_claim_accepted"]
        and receipt["gpio18_released"]
        and receipt["read_only_chip_closed"]
        and receipt["low_confirmed"]
        and receipt["end_ns"] - receipt["begin_ns"] < MAX_RUN_SECONDS * 1_000_000_000
    )
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=MODES, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    receipt = experiment(args.mode, args.manifest)
    print(json.dumps(receipt, sort_keys=True), flush=True)
    if not receipt["success"]:
        print(
            receipt["primary_error"]
            or "; ".join(receipt["cleanup_errors"])
            or "Native characterization did not complete",
            file=sys.stderr,
        )
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
