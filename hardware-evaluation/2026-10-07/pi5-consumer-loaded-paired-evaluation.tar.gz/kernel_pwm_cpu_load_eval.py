"""Fixed, lab-only CPU pressure: two independently expiring ten-second workers.

No GPIO libraries, PWM/sysfs access, kernel configuration, external commands,
affinity, or priority changes. Workers only calculate and emit timing receipts.
The launcher cleans up only the Popen objects it created. Receipts use the same
host's monotonic clock; worker start/end times establish actual capture overlap.
No arguments select the worker command, count, or duration.
"""

import argparse
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from contextlib import contextmanager
from pathlib import Path

WORKER_COUNT = 2
WORKER_SECONDS = 10
STARTUP_GRACE_SECONDS = 2
TERMINATE_WAIT_SECONDS = 0.75
KILL_WAIT_SECONDS = 0.75


class LoadError(RuntimeError):
    pass


class LoadAbort(LoadError):
    pass


class LoadSignals:
    """Defer signals only for Popen ownership handoff and bounded cleanup."""

    def __init__(self):
        self.depth = 0
        self.received = []
        self.previous = {}

    def handler(self, signum, _frame):
        self.received.append(signum)
        if self.depth == 0:
            raise LoadAbort(f"Stopped by {signal.Signals(signum).name}")

    @contextmanager
    def atomic(self):
        count = len(self.received)
        completed = False
        self.depth += 1
        try:
            yield
            completed = True
        finally:
            self.depth -= 1
            if completed and self.depth == 0 and len(self.received) != count:
                raise LoadAbort("Signal received during worker ownership handoff")

    @contextmanager
    def cleanup(self):
        self.depth += 1
        try:
            yield
        finally:
            self.depth -= 1

    def __enter__(self):
        try:
            for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
                self.previous[signum] = signal.signal(signum, self.handler)
        except BaseException:
            for signum, previous in self.previous.items():
                signal.signal(signum, previous)
            raise
        return self

    def __exit__(self, *_exc):
        for signum, previous in self.previous.items():
            signal.signal(signum, previous)


def _worker_source():
    # Only the module constant is injected; there is no CLI duration/command API.
    return (
        "import json, os, time\n"
        f"duration = {WORKER_SECONDS!r}\n"
        "begin_ns = time.monotonic_ns()\n"
        "deadline = time.monotonic() + duration\n"
        "print(json.dumps({'event': 'worker_started', 'pid': os.getpid(), "
        "'begin_ns': begin_ns, 'duration_seconds': duration}), flush=True)\n"
        "iterations = 0\n"
        "while time.monotonic() < deadline:\n"
        "    sum(range(10000))\n"
        "    iterations += 1\n"
        "end_ns = time.monotonic_ns()\n"
        "print(json.dumps({'event': 'worker_completed', 'pid': os.getpid(), "
        "'begin_ns': begin_ns, 'end_ns': end_ns, 'iterations': iterations, "
        "'duration_seconds': duration}), flush=True)\n"
    )


def _emit(receipt):
    print(json.dumps(receipt, sort_keys=True), flush=True)


def _collect(record, timeout):
    process = record["process"]
    stdout, stderr = process.communicate(timeout=timeout)
    record.update(
        returncode=process.returncode,
        completed_ns=time.monotonic_ns(),
        stdout=stdout or "",
        stderr=stderr or "",
        reaped=True,
    )
    receipts = []
    try:
        for line in record["stdout"].splitlines():
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError("Worker receipt is not an object")
            receipts.append(value)
    except (ValueError, TypeError) as exc:
        record["receipt_error"] = f"{type(exc).__name__}: {exc}"
    record["worker_receipts"] = receipts


def _validate_worker(record):
    if record["returncode"] != 0:
        raise LoadError(f"Worker {record['index']} exited {record['returncode']}")
    reports = record["worker_receipts"]
    if record.get("receipt_error") or len(reports) != 2:
        raise LoadError(f"Worker {record['index']} did not emit two valid receipts")
    started, completed = reports
    if (
        started.get("event") != "worker_started"
        or completed.get("event") != "worker_completed"
        or started.get("pid") != record["pid"]
        or completed.get("pid") != record["pid"]
        or started.get("duration_seconds") != WORKER_SECONDS
        or completed.get("duration_seconds") != WORKER_SECONDS
        or type(started.get("begin_ns")) is not int
        or type(completed.get("end_ns")) is not int
        or type(completed.get("iterations")) is not int
        or completed["iterations"] <= 0
        or started["begin_ns"] < record["popen_begin_ns"]
        or completed.get("begin_ns") != started["begin_ns"]
        or completed["end_ns"] - started["begin_ns"] < WORKER_SECONDS * 1_000_000_000
        or completed["end_ns"] > record["completed_ns"]
    ):
        raise LoadError(f"Worker {record['index']} timing/provenance receipt mismatch")


def _cleanup_worker(record, errors):
    """Never resolve a PID or target anything except this owned Popen object."""
    if record["reaped"]:
        return
    process = record["process"]
    try:
        if process.poll() is None:
            record["terminate_requested_ns"] = time.monotonic_ns()
            try:
                process.terminate()
            except ProcessLookupError:
                pass  # An exit racing the poll still needs reaping.
            except BaseException as exc:
                errors.append(
                    f"Worker {record['index']} terminate: {type(exc).__name__}: {exc}"
                )
        _collect(record, TERMINATE_WAIT_SECONDS)
        return
    except subprocess.TimeoutExpired:
        pass
    except BaseException as exc:
        errors.append(f"Worker {record['index']} collect: {type(exc).__name__}: {exc}")
    try:
        record["kill_requested_ns"] = time.monotonic_ns()
        process.kill()
    except ProcessLookupError:
        pass
    except BaseException as exc:
        errors.append(f"Worker {record['index']} kill: {type(exc).__name__}: {exc}")
    try:
        _collect(record, KILL_WAIT_SECONDS)
    except BaseException as exc:
        errors.append(f"Worker {record['index']} reap: {type(exc).__name__}: {exc}")


def _public_record(record):
    return {key: value for key, value in record.items() if key != "process"}


def run_load(*, popen_factory=None, emit=None, guard=None):
    """Injection seams are for local tests only; the CLI has no load options."""
    popen_factory = popen_factory or subprocess.Popen
    emit = emit or _emit
    guard = guard or LoadSignals()
    source = _worker_source()
    begin_ns = time.monotonic_ns()
    deadline = time.monotonic() + WORKER_SECONDS + STARTUP_GRACE_SECONDS
    base = {
        "schema_version": 1,
        "mode": "cpu-only-fixed-two-workers",
        "launcher_pid": os.getpid(),
        "worker_count": WORKER_COUNT,
        "worker_duration_seconds": WORKER_SECONDS,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "worker_source_sha256": hashlib.sha256(source.encode("ascii")).hexdigest(),
        "gpio_writes": False,
        "pwm_sysfs_access": False,
        "kernel_configuration_changes": False,
        "begin_ns": begin_ns,
    }
    records, errors = [], []
    primary = None
    launch_attempted = False
    with guard:
        try:
            for index in range(WORKER_COUNT):
                with guard.atomic():
                    popen_begin = time.monotonic_ns()
                    process = popen_factory(
                        [sys.executable, "-c", source],
                        stdin=subprocess.DEVNULL,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                    )
                    # Latch the actual object before leaving the signal guard.
                    records.append(
                        {
                            "process": process,
                            "index": index,
                            "pid": process.pid,
                            "popen_begin_ns": popen_begin,
                            "popen_end_ns": time.monotonic_ns(),
                            "returncode": None,
                            "completed_ns": None,
                            "reaped": False,
                            "worker_receipts": [],
                        }
                    )
            launch_attempted = True
            emit(
                {
                    **base,
                    "event": "load_launched",
                    "receipt_ns": time.monotonic_ns(),
                    "started_worker_count": len(records),
                    "launch_complete": True,
                    "owned_workers": [_public_record(record) for record in records],
                }
            )
            for record in records:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise LoadError("Shared worker completion deadline expired")
                _collect(record, remaining)
                _validate_worker(record)
        except BaseException as exc:
            primary = exc
        finally:
            with guard.cleanup():
                if not launch_attempted:
                    launch_attempted = True
                    try:
                        emit(
                            {
                                **base,
                                "event": "load_launched",
                                "receipt_ns": time.monotonic_ns(),
                                "started_worker_count": len(records),
                                "launch_complete": False,
                                "primary_error": f"{type(primary).__name__}: {primary}",
                                "owned_workers": [
                                    _public_record(record) for record in records
                                ],
                            }
                        )
                    except BaseException as exc:
                        if primary is None:
                            primary = exc
                        else:
                            errors.append(
                                f"Launch receipt: {type(exc).__name__}: {exc}"
                            )
                for record in records:
                    _cleanup_worker(record, errors)
                if guard.received and primary is None:
                    primary = LoadAbort("Termination signal received during cleanup")
                completion = {
                    **base,
                    "event": "load_completed",
                    "end_ns": time.monotonic_ns(),
                    "receipt_boundary": "after worker cleanup; signals arriving during receipt emission can still fail exit status",
                    "success": primary is None
                    and not errors
                    and len(records) == WORKER_COUNT
                    and all(
                        record["reaped"] and record["returncode"] == 0
                        for record in records
                    ),
                    "signals_received": list(guard.received),
                    "cleanup_errors": errors,
                    "primary_error": None
                    if primary is None
                    else f"{type(primary).__name__}: {primary}",
                    "owned_workers": [_public_record(record) for record in records],
                }
                try:
                    emit(completion)
                except BaseException as exc:
                    if primary is None:
                        primary = exc
                    else:
                        errors.append(
                            f"Completion receipt: {type(exc).__name__}: {exc}"
                        )
                # The already-flushed receipt cannot be rewritten. A signal
                # arriving during its emission must nevertheless fail the CLI;
                # consumers must check the process exit status as well as JSON.
                if guard.received and primary is None:
                    primary = LoadAbort(
                        "Termination signal received during completion receipt emission"
                    )
                    try:
                        print(f"{type(primary).__name__}: {primary}", file=sys.stderr)
                    except BaseException as exc:
                        errors.append(f"Late abort report: {type(exc).__name__}: {exc}")
    return 0 if primary is None and not errors else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args(argv)
    try:
        return run_load()
    except BaseException as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
