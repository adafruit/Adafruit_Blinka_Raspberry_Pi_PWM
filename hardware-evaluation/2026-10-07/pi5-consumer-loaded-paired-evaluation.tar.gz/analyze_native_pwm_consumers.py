"""Offline passive-probe Servo/DCMotor facts, not actuator or Blinka parity.

Preserve all raw edges, widths, lows and adjacent-rise intervals. Consumer
phase associations require the frozen ordered joint waveform topology, never
Pi/Saleae clock matching. Any full-run sibling overlap remains ambiguous.
"""

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

import analyze_native_pwm_dual_initial as raw
import capture_native_pwm_consumers as collector

require = raw.require
PLAN_NAME = "oct7-native-consumers-plan.json"
PLAN_SHA256 = "97bb31a21eee3d2ed33241a5a8ebd92f5b10f56a5081cfad4f7fdb6227eaf0d2"
HELPER_SHA256 = "db6d32ec066a7683fd85613f638f60a7e13e7a736cea362e9fe4b751641b54dc"
BAND = 0.10
MIN_PULSES = 5
LONG_HIGH_US = 100_000
MIN_BRAKE_OVERLAP_SECONDS = 0.10
TARGETS = {
    "servo_angle0": (50, 3276),
    "servo_angle90": (50, 4914),
    "servo_angle180": (50, 6553),
    "motor_half": (1000, 32767),
}
NOMINALS = {
    tag: {"frequency_hz": frequency, "duty_u16": duty, **raw.nominal(frequency, duty)}
    for tag, (frequency, duty) in TARGETS.items()
}


def read_plan(path=None):
    path = Path(path) if path is not None else Path(__file__).with_name(PLAN_NAME)
    data = path.read_bytes()
    require(
        hashlib.sha256(data).hexdigest() == PLAN_SHA256, "Frozen consumer plan changed"
    )
    plan = collector.read_json(data.decode())
    rules = plan["pre_capture_waveform_identification"]
    require(
        plan["mode"] == collector.MODE
        and plan["sequence_marker"] == collector.SEQUENCE_MARKER
        and plan["motor_version"] == "3.5.0"
        and plan["helper_sha256"] == HELPER_SHA256
        and plan["sequence"]
        == [
            {
                "name": name,
                "duration_seconds": duration,
                "operation": operation,
                "value": value,
            }
            for name, duration, operation, value in collector.helper.SEQUENCE
        ]
        and rules["ordinary_width_period_relative_band"] == BAND
        and rules["minimum_identifiable_train_pulses"] == MIN_PULSES
        and rules["sustained_high_threshold_seconds"] * 1e6 == LONG_HIGH_US
        and rules["minimum_joint_brake_overlap_seconds"] == MIN_BRAKE_OVERLAP_SECONDS,
        "Frozen consumer sequence/identification contract changed",
    )
    for name, digest in (
        ("native_pwm_consumers_eval.py", plan["helper_sha256"]),
        ("capture_native_pwm_consumers.py", plan["collector_sha256"]),
    ):
        require(
            hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()
            == digest,
            "Frozen consumer source changed: " + name,
        )
    return plan


def retarget_channel(facts):
    """Retarget fresh raw facts; imported dual bins must not label consumers."""
    for high in facts["all_high_runs"]:
        width = high["width_us"]
        nearest = min(NOMINALS, key=lambda tag: abs(width - NOMINALS[tag]["high_us"]))
        high.update(
            width_target_candidates=[
                tag
                for tag in NOMINALS
                if math.isclose(width, NOMINALS[tag]["high_us"], rel_tol=BAND)
            ],
            nearest_width_target=nearest,
            nearest_width_target_error_us=width - NOMINALS[nearest]["high_us"],
            descriptive_long_high=width > LONG_HIGH_US,
        )
    highs = facts["all_high_runs"]
    facts["unmatched_width_pair_indices"] = [
        row["pair_index"]
        for row in highs
        if not row["width_target_candidates"] and not row["descriptive_long_high"]
    ]
    facts["descriptive_long_high_runs"] = [
        row for row in highs if row["descriptive_long_high"]
    ]
    facts["nearest_target_error_stats_us_including_all_nonlong_anomalies"] = {
        tag: raw.stats(
            [
                row["nearest_width_target_error_us"]
                for row in highs
                if row["nearest_width_target"] == tag
                and not row["descriptive_long_high"]
            ]
        )
        for tag in NOMINALS
    }
    return facts


def read_channel(path):
    return retarget_channel(raw.read_channel(path))


def train_blocks(channel, tag):
    """Keep every compatible fragment, even if too short to identify a train."""
    blocks, block = [], []
    for high in channel["all_high_runs"]:
        compatible = tag in high["width_target_candidates"]
        connects = block and math.isclose(
            (high["rise_seconds"] - block[-1]["rise_seconds"]) * 1e6,
            NOMINALS[tag]["period_us"],
            rel_tol=BAND,
        )
        if not compatible or not connects:
            if block:
                blocks.append(block)
            block = []
        if compatible:
            block.append(high)
    if block:
        blocks.append(block)
    return [
        {
            "tag": tag,
            "pair_indices": [row["pair_index"] for row in block],
            "begin_seconds": block[0]["rise_seconds"],
            "end_seconds": block[-1]["fall_seconds"],
            "eligible_train": len(block) >= MIN_PULSES,
            "high_width_stats_us": raw.stats([row["width_us"] for row in block]),
            "period_stats_us": raw.stats(
                [
                    (b["rise_seconds"] - a["rise_seconds"]) * 1e6
                    for a, b in itertools.pairwise(block)
                ]
            ),
        }
        for block in blocks
    ]


def quiet_facts(channel, begin, end):
    """Include sample-tied boundary runs: do not invent cross-channel ordering."""
    overlapping = [
        row
        for row in channel["all_high_runs"]
        if row["fall_seconds"] >= begin and row["rise_seconds"] <= end
    ]
    return {
        "low_throughout_full_window_observed": not overlapping,
        "overlapping_or_boundary_touching_high_runs": overlapping,
        "guarded_core_substitution_used": False,
    }


def functional_facts(gpio18, gpio23):
    observations, ambiguities = [], []

    def unique(feature, candidates):
        if len(candidates) != 1:
            ambiguities.append(
                {
                    "feature": feature,
                    "candidate_count": len(candidates),
                    "candidates": candidates,
                }
            )
            return None
        return candidates[0]

    def observe(feature, begin, end, evidence, supported=False):
        observations.append(
            {
                "feature": feature,
                "evidence": evidence,
                "gpio18": raw.window_facts(gpio18, begin, end),
                "gpio23": raw.window_facts(gpio23, begin, end),
                "frozen_ordered_topology_association_supported": supported,
                "command_phase_clocks_aligned": False,
                "complete_command_phase_extent_identified": False,
                "exact_application_or_deinit_instant_identified": False,
            }
        )

    all_blocks = {
        "gpio18": {tag: train_blocks(gpio18, tag) for tag in NOMINALS},
        "gpio23": {tag: train_blocks(gpio23, tag) for tag in NOMINALS},
    }
    joint_overlaps = []
    for high18, high23 in itertools.product(
        gpio18["descriptive_long_high_runs"], gpio23["descriptive_long_high_runs"]
    ):
        begin, end = (
            max(high18["rise_seconds"], high23["rise_seconds"]),
            min(high18["fall_seconds"], high23["fall_seconds"]),
        )
        if end > begin:
            joint_overlaps.append(
                {
                    "begin_seconds": begin,
                    "end_seconds": end,
                    "duration_seconds": end - begin,
                    "gpio18_high": high18,
                    "gpio23_high": high23,
                    "eligible_joint_brake": end - begin >= MIN_BRAKE_OVERLAP_SECONDS,
                }
            )
    brake = unique(
        "joint_long_high_brake",
        [row for row in joint_overlaps if row["eligible_joint_brake"]],
    )
    servo = {}
    for tag in ("servo_angle0", "servo_angle90", "servo_angle180"):
        blocks = [
            row
            for row in all_blocks["gpio18"][tag]
            if not brake or row["end_seconds"] < brake["begin_seconds"]
        ]
        selected = unique(tag, [row for row in blocks if row["eligible_train"]])
        servo[tag] = selected
        if selected and len(blocks) != 1:
            ambiguities.append(
                {
                    "feature": tag + "_full_extent",
                    "reason": "Additional short or eligible width/period fragments retained; one guarded train does not identify the complete command phase",
                    "all_fragments": blocks,
                }
            )
    servo_order = bool(
        brake
        and all(servo.values())
        and servo["servo_angle0"]["end_seconds"]
        < servo["servo_angle90"]["begin_seconds"]
        and servo["servo_angle90"]["end_seconds"]
        < servo["servo_angle180"]["begin_seconds"]
        and servo["servo_angle180"]["end_seconds"] < brake["begin_seconds"]
    )
    if not servo_order:
        ambiguities.append(
            {
                "feature": "servo_order_before_brake",
                "reason": "Unique angle0/90/180 train order before joint brake not established",
            }
        )
    full_positive = unique(
        "gpio18_full_positive_high",
        [
            row
            for row in gpio18["descriptive_long_high_runs"]
            if brake and row["rise_seconds"] > brake["gpio18_high"]["fall_seconds"]
        ],
    )
    full_negative = unique(
        "gpio23_full_negative_high",
        [
            row
            for row in gpio23["descriptive_long_high_runs"]
            if brake and row["rise_seconds"] > brake["gpio23_high"]["fall_seconds"]
        ],
    )
    long_order = bool(
        brake
        and full_positive
        and full_negative
        and brake["end_seconds"]
        < full_positive["rise_seconds"]
        < full_positive["fall_seconds"]
        < full_negative["rise_seconds"]
    )
    if not long_order:
        ambiguities.append(
            {
                "feature": "motor_long_high_order",
                "reason": "Unique joint brake then GPIO18 high then GPIO23 high order not established",
            }
        )
    half_positive = unique(
        "gpio18_forward_half_train",
        [
            row
            for row in all_blocks["gpio18"]["motor_half"]
            if row["eligible_train"]
            and long_order
            and brake["gpio18_high"]["fall_seconds"] < row["begin_seconds"]
            and row["end_seconds"] < full_positive["rise_seconds"]
        ],
    )
    half_negative = unique(
        "gpio23_reverse_half_train",
        [
            row
            for row in all_blocks["gpio23"]["motor_half"]
            if row["eligible_train"]
            and long_order
            and full_positive["fall_seconds"] < row["begin_seconds"]
            and row["end_seconds"] < full_negative["rise_seconds"]
        ],
    )
    complete_topology = bool(
        servo_order
        and long_order
        and half_positive
        and half_negative
        and not ambiguities
        and all(
            quiet_facts(sibling, begin, end)["low_throughout_full_window_observed"]
            for begin, end, sibling in (
                *(
                    (row["begin_seconds"], row["end_seconds"], gpio23)
                    for row in servo.values()
                    if row
                ),
                (half_positive["begin_seconds"], half_positive["end_seconds"], gpio23),
                (half_negative["begin_seconds"], half_negative["end_seconds"], gpio18),
                (full_positive["rise_seconds"], full_positive["fall_seconds"], gpio23),
                (full_negative["rise_seconds"], full_negative["fall_seconds"], gpio18),
            )
        )
    )
    for feature, selected, own, sibling in (
        ("servo_angle0", servo["servo_angle0"], gpio18, gpio23),
        ("servo_angle90", servo["servo_angle90"], gpio18, gpio23),
        ("servo_angle180", servo["servo_angle180"], gpio18, gpio23),
        ("motor_forward_half", half_positive, gpio18, gpio23),
        ("motor_reverse_half", half_negative, gpio23, gpio18),
    ):
        if selected:
            begin, end = selected["begin_seconds"], selected["end_seconds"]
            quiet = quiet_facts(sibling, begin, end)
            if not quiet["low_throughout_full_window_observed"]:
                ambiguities.append(
                    {
                        "feature": feature + "_sibling_low",
                        "reason": "Sibling high/boundary overlap prevents full-window isolated association",
                        **quiet,
                    }
                )
            observe(
                feature + "_guarded_train",
                begin,
                end,
                {"train": selected, "sibling": quiet},
                complete_topology,
            )
    if brake:
        observe(
            "joint_brake_physical_both_high_overlap",
            brake["begin_seconds"],
            brake["end_seconds"],
            brake,
            complete_topology,
        )
    for feature, selected, sibling in (
        ("motor_forward_full", full_positive, gpio23),
        ("motor_reverse_full", full_negative, gpio18),
    ):
        if selected:
            begin, end = selected["rise_seconds"], selected["fall_seconds"]
            quiet = quiet_facts(sibling, begin, end)
            if not quiet["low_throughout_full_window_observed"]:
                ambiguities.append(
                    {
                        "feature": feature + "_sibling_low",
                        "reason": "Whole long-high span has sibling or boundary overlap; no post-capture core guard substituted",
                        **quiet,
                    }
                )
            observe(
                feature + "_physical_long_high",
                begin,
                end,
                {"complete_high_run": selected, "sibling": quiet},
                complete_topology,
            )
    if servo_order:
        begin, end = (
            servo["servo_angle180"]["end_seconds"],
            brake["gpio18_high"]["rise_seconds"],
        )
        if end > begin:
            observe(
                "between_servo_and_motor_gpio18_gap",
                begin,
                end,
                {
                    "gpio18_low": quiet_facts(gpio18, begin, end),
                    "generation_identity_from_receipt_only": True,
                },
            )
    begin = max(
        channel["all_high_runs"][-1]["fall_seconds"]
        if channel["all_high_runs"]
        else channel["waveform"]["begin_seconds"]
        for channel in (gpio18, gpio23)
    )
    end = gpio18["waveform"]["end_seconds"]
    if begin < end:
        observe(
            "final_both_low_physical_tail",
            begin,
            end,
            {"silent_waveform_does_not_identify_disable_vs_release_calls": True},
        )
    return {
        "physical_observations": observations,
        "ambiguities": ambiguities,
        "all_width_period_train_fragments_including_short": all_blocks,
        "all_joint_long_high_overlap_candidates": joint_overlaps,
        "unique_servo_order_before_joint_brake": servo_order,
        "unique_brake_positive_negative_long_high_order": long_order,
        "complete_frozen_ordered_joint_topology_supported": complete_topology,
        "rules": {
            "band": BAND,
            "minimum_pulses": MIN_PULSES,
            "long_high_us": LONG_HIGH_US,
            "minimum_brake_overlap_seconds": MIN_BRAKE_OVERLAP_SECONDS,
            "whole_run_sibling_low_required": True,
            "identification_only_not_acceptance": True,
        },
        "waveform_contains_no_consumer_command_or_generation_labels": True,
    }


def analyze(directory, plan_path=None):
    directory, plan = Path(directory), read_plan(plan_path)

    def read(name):
        return collector.read_json((directory / name).read_text())

    manifest, remote, metadata, acquisition = (
        read(name)
        for name in (
            "manifest.json",
            "remote.stdout",
            "results.json",
            "acquisition.json",
        )
    )
    collector.validate_remote(remote, manifest)
    require(
        manifest["source_sha256"]["native_pwm_consumers_eval.py"] == HELPER_SHA256,
        "Frozen consumer helper mismatch",
    )
    require(
        type(metadata.get("schema_version")) is int
        and metadata["schema_version"] == 1
        and metadata.get("host") == "test-pi5.local"
        and metadata.get("mode") == collector.MODE
        and metadata.get("backend") == collector.BACKEND
        and metadata.get("sequence_marker") == collector.SEQUENCE_MARKER
        and type(metadata.get("sample_rate_hz")) is int
        and metadata["sample_rate_hz"] == 100_000_000
        and metadata.get("remote") == remote
        and metadata.get("collection_success") is True
        and metadata.get("production_backend_unchanged") is True
        and metadata.get("parity_evaluated") is False
        and metadata.get("analysis_deferred") is True
        and metadata.get("installed_blinka_compatibility_proven") is False
        and metadata.get("actual_actuators_attached") is False
        and "waveform_accepted" in metadata
        and metadata["waveform_accepted"] is None
        and "parity_pass" in metadata
        and metadata["parity_pass"] is None
        and metadata.get("outputs")
        == [
            {"gpio": gpio, "saleae_channel": channel, "backend": collector.BACKEND}
            for gpio, channel in ((18, 0), (23, 1))
        ],
        "Successful passive unchanged consumer collection required without waveform/parity verdict",
    )
    require(
        acquisition.get("mode") == collector.MODE
        and acquisition.get("backend") == collector.BACKEND
        and acquisition.get("remote_root") == plan["remote_root"]
        and acquisition.get("remote_python") == plan["remote_python"]
        and remote["manifest_path"]
        == acquisition.get("remote_root", "") + "/manifest.json"
        and "primary_error" in acquisition
        and acquisition["primary_error"] is None
        and acquisition.get("evidence_errors") == []
        and acquisition.get("local_timing_not_aligned_to_pi_or_saleae") is True
        and all(
            type(row.get("remote_returncode")) is int
            and row["remote_returncode"] == 0
            and row.get("pre_helper_lead_seconds") == 0.5
            and row.get("post_helper_tail_seconds") == 0.2
            for row in (metadata, acquisition)
        ),
        "Consumer acquisition/root/lead/tail/evidence validation failed",
    )
    settings = raw.validate_sal(directory / "waveform.sal")
    channels = [read_channel(directory / f"digital_{index}.bin") for index in (0, 1)]
    bounds = [
        (row["waveform"]["begin_seconds"], row["waveform"]["end_seconds"])
        for row in channels
    ]
    require(
        bounds[0] == bounds[1], "Both consumer channels must share acquisition bounds"
    )
    require(
        bounds[0][1] - bounds[0][0] >= sum(row[1] for row in collector.helper.SEQUENCE),
        "Insufficient full consumer capture coverage",
    )
    names = (
        "manifest.json",
        "remote.stdout",
        "remote.stderr",
        "results.json",
        "acquisition.json",
        "waveform.sal",
        "digital_0.bin",
        "digital_1.bin",
    )
    return {
        "schema_version": 1,
        "capture": directory.name,
        "mode": collector.MODE,
        "backend": collector.BACKEND,
        "plan_sha256": PLAN_SHA256,
        "source_manifest": manifest,
        "offline_analyzer_sha256": hashlib.sha256(
            Path(__file__).read_bytes()
        ).hexdigest(),
        "reused_raw_facts_module_sha256": hashlib.sha256(
            Path(raw.__file__).read_bytes()
        ).hexdigest(),
        "saved_capture_settings": settings,
        "collection_receipts_validated": True,
        "evidence_sha256": {
            name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
            for name in names
        },
        "gpio18_channel0": channels[0],
        "gpio23_channel1": channels[1],
        "functional_waveform_facts": functional_facts(*channels),
        "actual_consumer_u16_c_rounded_nominals": NOMINALS,
        "common_requested_servo_high_us_minus_actual_c_rounded_us": {
            tag: requested - NOMINALS[tag]["high_us"]
            for tag, requested in (
                ("servo_angle0", 1000),
                ("servo_angle90", 1500),
                ("servo_angle180", 2000),
            )
        },
        "validated_receipt_consumer_api_and_ownership_not_electrical_phase_identity": {
            key: remote[key]
            for key in (
                "consumers",
                "integration_shim",
                "outputs",
                "shutdowns",
                "phases",
                "actions",
            )
        },
        "caller_events_pi_clock": [
            {
                **event,
                "caller_duration_us": (event["end_ns"] - event["begin_ns"]) / 1000,
            }
            for event in remote["events"]
        ],
        "functional_consumer_integration_only": True,
        "passive_probes_only": True,
        "actual_actuator_operation_established": False,
        "installed_blinka_compatibility_proven": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "matched_performance_parity": False,
        "pi_saleae_clocks_aligned": False,
        "application_latency_measured": False,
        "physical_channels_share_acquisition_timestamps": True,
        "no_edge_trimming_or_glitch_filtering": True,
        "timebase_gpio_driver_and_threshold_skew_calibrated": False,
        "limitation": "Finite passive digital observations using genuine motor3.5.0 classes and an in-memory pwmio export, not installed Blinka or real actuator compatibility. Receipt clocks do not assign waveform phases. Quantized actual u16/C-rounded targets differ from ideal requested servo widths. Full-run sibling/boundary overlap prevents isolated-state association; no post-capture guard replaces it. All anomalous edges and short fragments retained. Silent GPIO states cannot identify exact disable/deinit/release calls. No latency, scheduling guarantee or parity verdict.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", type=Path, nargs="+")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output-name", default="consumer-analysis.json")
    args = parser.parse_args(argv)
    require(
        Path(args.output_name).name == args.output_name
        and args.output_name not in ("", ".", ".."),
        "Output must be a filename",
    )
    outputs = [directory / args.output_name for directory in args.directories]
    require(
        len(set(outputs)) == len(outputs)
        and all(not path.exists() and not path.is_symlink() for path in outputs),
        "Exclusive fresh report outputs required",
    )
    reports = [analyze(directory, args.plan) for directory in args.directories]
    for path, report in zip(outputs, reports):
        with path.open("x") as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
