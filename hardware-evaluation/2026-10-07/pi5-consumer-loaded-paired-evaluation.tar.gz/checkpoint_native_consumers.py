"""Exclusive consumer evidence snapshot, with byte checks and offline replay."""

import hashlib
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

import native_pwm_consumers_eval as helper

LAB = Path(__file__).resolve().parent
ARCHIVE = (
    LAB.parent
    / "Adafruit_Blinka_Raspberry_Pi_PWM/hardware-evaluation/2026-10-07/native-pi5-consumer-evaluation.tar.gz"
)
CAPTURES = json.loads((LAB / "oct7-native-consumers-plan.json").read_text())[
    "capture_order"
]
TARGETS = CAPTURES + [
    "native_pwm_consumers_eval.py",
    "capture_native_pwm_consumers.py",
    "analyze_native_pwm_consumers.py",
    "test_native_pwm_consumers_eval.py",
    "test_capture_native_pwm_consumers.py",
    "test_analyze_native_pwm_consumers.py",
    "native_pwm_dual_eval.py",
    "capture_native_pwm_dual.py",
    "analyze_native_pwm_dual_initial.py",
    "test_native_pwm_dual_eval.py",
    "native_pwm_updates_eval.py",
    "native_pwm_half50_eval.py",
    "kernel_pwm_lgpio_baseline_eval.py",
    "kernel_pwm_eval.py",
    "capture_native_pwm_half50.py",
    "capture_kernel_pwm_lgpio_baseline.py",
    "capture_pwm.py",
    "analyze_kernel_pwm_inverse.py",
    "analyze_gpio_pwm_marker.py",
    "capture_gpio_pwm_marker.py",
    "gpio_pwm_marker_eval.py",
    "baseline_pwmout.py",
    "lgpio_pin.py",
    "test_native_pwm_half50_eval.py",
    "test_kernel_pwm_lgpio_baseline_eval.py",
    "prepare_native_consumers.py",
    "prepare_native_dual.py",
    "record_native_consumers_postflight.py",
    "record_native_updates_postflight.py",
    "oct7-native-consumers-plan.json",
    "oct7-native-consumers-manifest.json",
    "oct7-native-consumers-preflight.json",
    "oct7-native-consumers-postflight.json",
    "oct7-native-consumers-postflight.json.stdout",
    "oct7-native-consumers-postflight.json.stderr",
    "oct7-native-dual-postflight.json",
    "oct7-native-consumers-independent-audit.json",
    "oct7-native-consumers-final-report-audit.json",
    "oct7-native-consumers-notes.txt",
    "oct7-native-half50-runtime",
    "checkpoint_native_consumers.py",
]
REPLAY = r"""
import json,pathlib,sys
sys.path.insert(0,sys.argv[1])
import analyze_native_pwm_consumers as analysis
root=pathlib.Path(sys.argv[1])
names=json.loads((root/'oct7-native-consumers-plan.json').read_text())['capture_order']
for name in names:
    assert analysis.analyze(root/name)==json.loads((root/name/'analysis.json').read_text()),name
print(json.dumps({'consumer_reports_reproduced':len(names)}))
"""


def main():
    if len(TARGETS) != len(set(TARGETS)):
        raise ValueError("Duplicate recovery targets")
    files = {}
    for name in TARGETS:
        path = LAB / name
        if not path.exists() or path.is_symlink():
            raise ValueError("Missing or linked target: " + name)
        for member in [path] if path.is_file() else sorted(path.rglob("*")):
            if member.is_symlink() or not (member.is_file() or member.is_dir()):
                raise ValueError("Unsupported member: " + str(member))
            if member.is_file():
                key = str(member.relative_to(LAB))
                if key in files:
                    raise ValueError("Duplicate member: " + key)
                files[key] = hashlib.sha256(member.read_bytes()).hexdigest()
    consumers = helper.consumer_inventory()
    for key, path in consumers.items():
        if path.is_symlink() or not path.is_file():
            raise ValueError("Unsupported consumer source: " + key)
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != helper.CONSUMER_PINS[key]:
            raise ValueError("Consumer source changed: " + key)
        files["consumer-library-source/" + key] = digest
    with (
        ARCHIVE.open("xb") as stream,
        tarfile.open(fileobj=stream, mode="w:gz") as archive,
    ):
        for name in TARGETS:
            archive.add(LAB / name, arcname=name)
        for key, path in consumers.items():
            archive.add(path, arcname="consumer-library-source/" + key)
    extracted = Path(
        tempfile.mkdtemp(prefix="blinka-consumers-checkpoint-", dir="/private/tmp")
    )
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if (
                path.is_absolute()
                or ".." in path.parts
                or not (member.isfile() or member.isdir())
            ):
                raise ValueError("Unsafe archive member: " + member.name)
        archive.extractall(extracted, filter="data")
    recovered = {
        str(path.relative_to(extracted)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in extracted.rglob("*")
        if path.is_file()
    }
    if recovered != files:
        raise ValueError("Archive file set/bytes differ")
    result = subprocess.run(
        [sys.executable, "-c", REPLAY, str(extracted)],
        cwd=extracted,
        capture_output=True,
        text=True,
        check=True,
    )
    report = {
        "archive": str(ARCHIVE),
        "size_bytes": ARCHIVE.stat().st_size,
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "top_level_targets": len(TARGETS) + 1,
        "regular_files": len(files),
        "safe_extraction": str(extracted),
        "all_file_bytes_match": True,
        "replay": json.loads(result.stdout),
        "replay_stderr": result.stderr,
        "consumer_library_sources": {
            "version": helper.MOTOR_VERSION,
            "selected_files": helper.CONSUMER_PINS,
            "scope": "Three exact executed Python files, not whole-distribution provenance",
        },
    }
    with (LAB / "oct7-native-consumers-checkpoint-verification.json").open(
        "x"
    ) as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
