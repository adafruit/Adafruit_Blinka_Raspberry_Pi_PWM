"""Fake-only load/capture handshake: never SSH, Saleae, GPIO or real load."""

import importlib.util
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

SCRIPT = Path(__file__).with_name("capture_kernel_pwm_loaded.py")
spec = importlib.util.spec_from_file_location("capture_kernel_pwm_loaded", SCRIPT)
loaded = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = loaded
spec.loader.exec_module(loaded)
STEM = "bench-loaded-r2"
ROOT = "/tmp/blinka-pwm-oct6.ABC123"


@pytest.fixture(autouse=True)
def safe_tmp_workdir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)


def receipt():
    return {
        "schema_version": 1,
        "worker_source_sha256": loaded.WORKER_SHA256,
        "event": "load_launched",
        "mode": "cpu-only-fixed-two-workers",
        "worker_count": 2,
        "started_worker_count": 2,
        "worker_duration_seconds": 10,
        "launch_complete": True,
        "gpio_writes": False,
        "pwm_sysfs_access": False,
        "kernel_configuration_changes": False,
        "source_sha256": loaded.LOAD_SHA256,
        "launcher_pid": 100,
        "owned_workers": [{"pid": 101, "reaped": False}, {"pid": 102, "reaped": False}],
    }


def fake_handshake(
    monkeypatch, *, launch=None, capture_rc=0, capture_error=None, load_rc=0
):
    launch = receipt() if launch is None else launch
    events, captures = [], []

    def record(stem, remote_root, *, launch_callback):
        events.append("load_started")
        assert stem == STEM and remote_root == ROOT + "/cpu-load-eval"
        first = json.dumps(launch) + "\n"
        with Path(stem + ".load.stdout").open("x") as stream:
            stream.write(first)
            stream.flush()
            Path(stem + ".load.stderr").write_bytes(b"load stderr\n")
            events.append("launch_persisted")
            launch_callback(launch)
            events.append("callback_returned")
            stream.write(
                json.dumps({"event": "load_completed", "success": load_rc == 0}) + "\n"
            )
            stream.flush()
        events.append("load_drained")
        if load_rc:
            raise loaded.recorder.LoadRecordingError("load helper failed", load_rc)
        return 0

    def capture(command, **kwargs):
        assert Path(STEM + ".load.stdout").read_text().endswith("\n")
        assert len(Path(STEM + ".load.stdout").read_text().splitlines()) == 1
        events.append("capture_started")
        captures.append((command, kwargs))
        kwargs["stdout"].write(b"child stdout\n")
        kwargs["stderr"].write(b"child stderr\n")
        if capture_error is not None:
            raise capture_error
        return SimpleNamespace(returncode=capture_rc)

    monkeypatch.setattr(loaded.recorder, "record", record)
    monkeypatch.setattr(loaded.subprocess, "run", capture)
    return events, captures


@pytest.mark.parametrize("mode", ["settled-direct", "half50"])
def test_handshake_launches_fixed_capture_after_flush_and_records_separate_codes(
    monkeypatch, mode
):
    events, captures = fake_handshake(monkeypatch)
    result = loaded.coordinate(STEM, ROOT, mode)
    assert events == [
        "load_started",
        "launch_persisted",
        "capture_started",
        "callback_returned",
        "load_drained",
    ]
    command, kwargs = captures[0]
    filename, subdir, child_mode = loaded.MODES[mode]
    assert command == [
        sys.executable,
        str(SCRIPT.with_name(filename)),
        STEM,
        "--remote-root",
        ROOT + "/" + subdir,
        "--mode",
        child_mode,
    ]
    assert kwargs["timeout"] == 20 and kwargs["check"] is False
    assert kwargs["stdin"] == subprocess.DEVNULL
    assert (
        result["load_helper_returncode"] == 0 and result["load_recorder_exit_code"] == 0
    )
    assert result["capture_returncode"] == 0 and result["coordination_success"]
    assert result["launch_validated"] and result["load_launcher_pid"] == 100
    assert result["capture_begin_ns"] <= result["capture_end_ns"]
    assert result["overlap_verified"] is False and result["waveform_accepted"] is None
    assert Path(STEM + ".capture.stdout").read_bytes() == b"child stdout\n"
    assert Path(STEM + ".capture.stderr").read_bytes() == b"child stderr\n"
    assert len(Path(STEM + ".load.stdout").read_text().splitlines()) == 2
    assert json.loads(Path(STEM + ".coordination.json").read_text()) == result
    assert not Path(STEM).exists()  # The fake child, not the coordinator, owns this.


@pytest.mark.parametrize(
    "field,value",
    [
        ("worker_count", 4),
        ("started_worker_count", 1),
        ("worker_duration_seconds", 20),
        ("launch_complete", False),
        ("gpio_writes", True),
        ("pwm_sysfs_access", True),
        ("kernel_configuration_changes", True),
        ("source_sha256", "wrong"),
        ("launcher_pid", 0),
        ("owned_workers", []),
        ("worker_count", True),
        ("schema_version", True),
        ("worker_source_sha256", "wrong"),
        (
            "owned_workers",
            [{"pid": 101, "reaped": False}, {"pid": 101, "reaped": False}],
        ),
        (
            "owned_workers",
            [{"pid": 100, "reaped": False}, {"pid": 102, "reaped": False}],
        ),
    ],
)
def test_launch_precondition_failure_never_starts_capture_but_drains_load(
    monkeypatch, field, value
):
    launch = receipt()
    launch[field] = value
    events, captures = fake_handshake(monkeypatch, launch=launch)
    result = loaded.coordinate(STEM, ROOT, "settled-direct")
    assert captures == [] and events[-1] == "load_drained"
    assert not result["launch_validated"] and result["launch_validation_errors"]
    assert not result["capture_started"] and result["capture_returncode"] is None
    assert result["load_helper_returncode"] == 0 and not result["coordination_success"]
    assert len(Path(STEM + ".load.stdout").read_text().splitlines()) == 2


@pytest.mark.parametrize(
    "capture_rc,error",
    [
        (1, None),
        (0, subprocess.TimeoutExpired("capture", 20)),
        (0, OSError("child start failed")),
        (0, KeyboardInterrupt("interrupted capture")),
    ],
)
def test_capture_failure_retains_child_and_complete_load_evidence(
    monkeypatch, capture_rc, error
):
    events, _captures = fake_handshake(
        monkeypatch, capture_rc=capture_rc, capture_error=error
    )
    result = loaded.coordinate(STEM, ROOT, "half50")
    assert events[-1] == "load_drained"
    assert (
        result["load_recorder_exit_code"] == 0 and result["load_helper_returncode"] == 0
    )
    assert not result["coordination_success"]
    assert result["capture_returncode"] == (capture_rc if error is None else None)
    if error is None:
        assert result["capture_error"] is None
    if error is not None:
        assert type(error).__name__ in result["capture_error"]
    assert len(Path(STEM + ".load.stdout").read_text().splitlines()) == 2
    assert Path(STEM + ".capture.stdout").read_bytes() == b"child stdout\n"
    assert Path(STEM + ".capture.stderr").read_bytes() == b"child stderr\n"


def test_nonzero_load_is_distinct_from_successful_child_capture(monkeypatch):
    fake_handshake(monkeypatch, load_rc=3)
    result = loaded.coordinate(STEM, ROOT, "settled-direct")
    assert result["capture_returncode"] == 0
    assert (
        result["load_helper_returncode"] == 3 and result["load_recorder_exit_code"] == 1
    )
    assert result["load_recorder_error"] and not result["coordination_success"]


@pytest.mark.parametrize(
    "stem,root,mode",
    [
        ("old-stem", ROOT, "half50"),
        ("../escape-loaded-r2", ROOT, "half50"),
        (STEM, ROOT + "/cpu-load-eval", "half50"),
        (STEM, ROOT, "frequency"),
    ],
)
def test_invalid_coordinator_inputs_create_no_files_or_processes(
    monkeypatch, stem, root, mode
):
    _events, captures = fake_handshake(monkeypatch)
    with pytest.raises(ValueError):
        loaded.coordinate(stem, root, mode)
    assert captures == [] and list(Path.cwd().iterdir()) == []


@pytest.mark.parametrize(
    "suffix",
    [
        "",
        ".load.stdout",
        ".load.stderr",
        ".capture.stdout",
        ".capture.stderr",
        ".coordination.json",
    ],
)
def test_any_existing_target_blocks_load_and_capture_without_overwrite(
    monkeypatch, suffix
):
    events, captures = fake_handshake(monkeypatch)
    target = Path(STEM + suffix)
    target.write_bytes(b"old evidence")
    with pytest.raises(FileExistsError):
        loaded.coordinate(STEM, ROOT, "half50")
    assert target.read_bytes() == b"old evidence" and events == [] and captures == []


def test_missing_launch_receipt_does_not_start_capture(monkeypatch):
    monkeypatch.setattr(loaded.recorder, "record", lambda *_args, **_kwargs: 0)
    result = loaded.coordinate(STEM, ROOT, "half50")
    assert not result["capture_started"] and not result["coordination_success"]
    assert (
        result["load_recorder_exit_code"] == 0 and result["capture_returncode"] is None
    )
