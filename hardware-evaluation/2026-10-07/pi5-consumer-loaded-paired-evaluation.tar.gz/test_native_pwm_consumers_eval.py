"""Genuine installed consumer classes and public native API, fake GPIO engine."""

import hashlib
import signal
import sys
from pathlib import Path
from types import SimpleNamespace

import native_pwm_consumers_eval as bench
import pytest
import test_native_pwm_dual_eval as dual_fakes

ROOT = "/tmp/blinka-pwm-native-consumers.abc123"
old_environment = dual_fakes.old_environment
dual_environment = dual_fakes.environment


@pytest.fixture
def environment(dual_environment, monkeypatch):
    state, guard, module, old_manifest, sleeps = dual_environment
    old_engine = module.SoftwarePWM

    class Engine(old_engine):
        def __init__(self, pin, frequency, duty):
            assert frequency == (
                50 if pin[1] == 18 and state.generation[18] == 0 else 1000
            )
            # Reuse the fake ownership mechanics; public API retains the actual
            # consumer frequency. No production/native engine is patched.
            super().__init__(pin, 50 if pin[1] == 18 else 500, duty)

        def configure(self, frequency, duty):
            assert state.claimed.get(self.gpio) is self._request
            assert frequency in (50, 1000)
            state.log.append(("configure", self.gpio, frequency, duty))
            if state.hook:
                state.hook("configure", self.gpio)
            if state.fail == ("configure", self.gpio):
                raise OSError(f"injected configure GPIO{self.gpio}")
            state.levels[self.gpio] = int(duty != 0)

    monkeypatch.setattr(module, "SoftwarePWM", Engine)
    manifest = {
        "schema_version": 1,
        "motor_version": bench.MOTOR_VERSION,
        "source_sha256": {
            **old_manifest["source_sha256"],
            **bench.CONSUMER_PINS,
            bench.NEW_SOURCE: hashlib.sha256(
                Path(bench.__file__).read_bytes()
            ).hexdigest(),
        },
    }
    monkeypatch.setattr(bench, "approved_manifest_path", lambda path: Path(path))
    monkeypatch.setattr(bench, "load_manifest", lambda path: manifest)
    monkeypatch.setattr(bench, "source_hashes", lambda: dict(manifest["source_sha256"]))
    for name in (
        "pwmio",
        "adafruit_motor",
        "adafruit_motor.servo",
        "adafruit_motor.motor",
    ):
        monkeypatch.delitem(sys.modules, name, raising=False)
    return state, guard, module, manifest, sleeps


def test_real_consumer_mapping_quantized_readback_private_release_and_shim_restoration(
    environment,
):
    state, _guard, _module, manifest, sleeps = environment
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert receipt["success"] and receipt["source_sha256"] == manifest["source_sha256"]
    assert receipt["consumers"]["version"] == "3.5.0"
    assert receipt["integration_shim"] == {
        "kind": "in-memory-pwmio-export",
        "unwrapped_public_pwm_objects": True,
        "installed_blinka_compatibility_proven": False,
        "installed_pwmio_module_used": False,
        "restored": True,
    }
    assert "pwmio" not in sys.modules and "adafruit_motor.servo" not in sys.modules
    assert all(
        bench.readback_matches(action["consumer_readback"], expected)
        for action, expected in zip(
            receipt["actions"][:4], [0.0, bench.servo_readback(90), 180.0, None]
        )
    )
    assert receipt["actions"][1]["consumer_readback"] != 90
    assert [a["api_state_after"][0]["duty_u16"] for a in receipt["actions"][:4]] == [
        3276,
        4914,
        6553,
        0,
    ]
    assert [
        tuple(row["duty_u16"] for row in a["api_state_after"])
        for a in receipt["actions"][4:]
    ] == [(65535, 65535), (32767, 0), (65535, 0), (0, 32767), (0, 65535), (0, 0)]
    assert [a["consumer_readback"] for a in receipt["actions"][4:]] == [
        0,
        0.5,
        1,
        -0.5,
        -1,
        None,
    ]
    assert [row["output_id"] for row in receipt["outputs"]] == [
        row[0] for row in bench.OUTPUTS
    ]
    assert [row["initial_frequency"] for row in receipt["outputs"]] == [50, 1000, 1000]
    assert [row["output_id"] for row in receipt["shutdowns"]] == [
        "servo18-g1",
        "motor18-g2",
        "motor23-g1",
    ]
    assert receipt["shutdowns"][1]["sibling_after"]["output_id"] == "motor23-g1"
    assert all(
        row["cleanup_final_readback"] == {"gpio_level": 0, "inactive": True}
        and row["released"]
        for row in receipt["outputs"]
    )
    assert not state.claimed and state.levels == {18: 0, 23: 0}
    expected_sleeps = []
    for _name, duration, operation, _value in bench.SEQUENCE:
        if "release" in operation:
            expected_sleeps.append(0.1)
        expected_sleeps.append(duration)
    assert sleeps == expected_sleeps and sum(sleeps) == pytest.approx(3.75)
    assert all(p["api_state"] == p["api_state_end"] for p in receipt["phases"])
    assert (
        receipt["parity_pass"] is None
        and not receipt["installed_blinka_compatibility_proven"]
    )


def test_consumer_sources_are_installed_genuine_pinned_version():
    paths = bench.consumer_inventory()
    assert {
        key: hashlib.sha256(path.read_bytes()).hexdigest()
        for key, path in paths.items()
    } == bench.CONSUMER_PINS
    assert bench.servo_duty(90) == 4914 and bench.motor_duties(0) == (65535, 65535)


@pytest.mark.parametrize("gpio", [18, 23])
def test_foreign_line_on_either_pin_prevents_all_claims(environment, gpio):
    state, *_rest = environment
    state.foreign.add(gpio)
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "fresh unused" in receipt["primary_error"]
    assert not any(row[0] == "claim" for row in state.log)


@pytest.mark.parametrize("problem", ["source", "pin", "flag"])
def test_source_and_enabled_flag_gates_prevent_all_claims(
    environment, monkeypatch, problem
):
    state, _guard, _module, manifest, _sleeps = environment
    if problem == "source":
        monkeypatch.setattr(
            bench,
            "source_hashes",
            lambda: {**manifest["source_sha256"], "adafruit_motor/motor.py": "0" * 64},
        )
    elif problem == "pin":
        manifest["source_sha256"]["native_pwm_dual_eval.py"] = "0" * 64
    else:
        monkeypatch.setenv("BLINKA_PWM_SHORT_SLICE", "1")
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and receipt["primary_error"] and not state.claimed
    assert not any(row[0] == "claim" for row in state.log)


def test_preexisting_pwmio_is_not_replaced_or_called(environment, monkeypatch):
    state, *_rest = environment
    sentinel = SimpleNamespace(PWMOut=lambda: pytest.fail("foreign pwmio used"))
    monkeypatch.setitem(sys.modules, "pwmio", sentinel)
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert "preexisting" in receipt["primary_error"] and not receipt["success"]
    assert sys.modules["pwmio"] is sentinel and not state.claimed


@pytest.mark.parametrize("gpio", [18, 23])
def test_consumer_setter_failure_keeps_action_error_and_releases_owned_outputs(
    environment, gpio
):
    state, *_rest = environment
    state.fail = ("configure", gpio)
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "configure" in receipt["primary_error"]
    assert receipt["actions"][-1]["status"] == "error"
    assert not state.claimed and receipt["integration_shim"]["restored"]
    assert all(row["released"] for row in receipt["outputs"])


def test_signal_during_second_motor_claim_does_not_lose_either_private_request(
    environment,
):
    state, guard, *_rest = environment

    def hook(name, gpio):
        if name == "claim" and gpio == 23:
            guard.handler(signal.SIGTERM, None)

    state.hook = hook
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "SafetyAbort" in receipt["primary_error"]
    assert receipt["signals_received"] == [signal.SIGTERM] and not state.claimed
    assert all(row["released"] for row in receipt["outputs"])


def test_final_deinit_error_still_inspects_release_and_preserves_failure(environment):
    state, *_rest = environment
    state.fail = ("stop", 23)
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert (
        not receipt["success"]
        and "independent shutdown failed" in receipt["primary_error"]
    )
    assert any("PWMOut.deinit" in error for error in receipt["cleanup_errors"])
    assert not state.claimed and all(row["released"] for row in receipt["outputs"])


def test_consumer_manifest_exact_shape_and_version(environment):
    _state, _guard, _module, manifest, _sleeps = environment
    assert len(bench.validate_manifest(manifest)) == 18
    for version in (None, "3.4.0"):
        with pytest.raises(bench.core.BenchError, match="3.5.0"):
            bench.validate_manifest({**manifest, "motor_version": version})


@pytest.mark.parametrize(
    "path", ["manifest.json", "/tmp/manifest.json", ROOT + "/../manifest.json"]
)
def test_manifest_path_constrained_to_new_root(path):
    with pytest.raises(bench.core.BenchError, match="absolute"):
        bench.approved_manifest_path(path)
