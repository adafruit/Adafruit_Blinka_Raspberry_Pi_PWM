"""Capture native independent GPIO18/GPIO23 coexistence and lifecycle evidence.

Use only after source inspection and physical GPIO18/channel0, GPIO23/channel1
wiring confirmation. Capture every raw edge with no filters or analyzers.
Success is acquisition/source/functional ownership/cleanup, not performance
parity or waveform acceptance. Retain all available evidence on failure.
"""

import argparse
import hashlib
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

import native_pwm_dual_eval as helper
from capture_native_pwm_half50 import DEVICE_ID, _write, read_json, require
from saleae import automation

MODE = "dual-independent-lifecycle"
BACKEND = "native-blinka-pwm"
SEQUENCE_MARKER = "native-dual-lifecycle-v1"


def validate_local_manifest(manifest):
    hashes = helper.validate_manifest(manifest)
    directory = Path(__file__).resolve().parent
    package = (
        directory.parent
        / "Adafruit_Blinka_Raspberry_Pi_PWM/src/adafruit_blinka_raspberry_pi_pwm"
    )
    paths = {
        name: directory / name
        for name in (
            "native_pwm_dual_eval.py",
            "native_pwm_updates_eval.py",
            "native_pwm_half50_eval.py",
            "kernel_pwm_lgpio_baseline_eval.py",
            "kernel_pwm_eval.py",
        )
    }
    paths.update(
        {
            "adafruit_blinka_raspberry_pi_pwm/" + name: package / name
            for name in ("__init__.py", "_software.py")
        }
    )
    require(
        all(
            hashlib.sha256(path.read_bytes()).hexdigest() == hashes[name]
            for name, path in paths.items()
        ),
        "Manifest helper/core/native Python sources must match local production sources",
    )
    return hashes


def validate_remote(remote, manifest):
    hashes = helper.validate_manifest(manifest)
    require(isinstance(remote, dict), "Dual receipt must be an object")
    require(
        _fields(
            remote,
            {
                "schema_version": 1,
                "mode": MODE,
                "backend": BACKEND,
                "sequence_marker": SEQUENCE_MARKER,
                "gpios": [18, 23],
            },
        )
        and remote.get("source_sha256") == hashes,
        "Dual schema/backend/pin/selected-source provenance mismatch",
    )
    require(
        all(
            remote.get(key) is True
            for key in (
                "success",
                "completed_normally",
                "read_only_chip_closed",
                "characterization_only",
                "functional_coexistence_only",
                "production_backend_unchanged",
                "api_readbacks_are_not_electrical",
                "selected_source_hashes_are_not_whole_system_attestation",
                "variable_frequency",
                "watchdog_cannot_bound_native_hang_or_sigkill",
            )
        )
        and _fields(
            remote,
            {
                "matched_performance_parity": False,
                "parity_pass": None,
                "primary_error": None,
                "cleanup_errors": [],
                "signals_received": [],
                "sequence_dwell_seconds": round(
                    sum(row[1] for row in helper.SEQUENCE), 6
                ),
                "low_settle_seconds": 0.1,
                "normal_fixed_wait_seconds": round(
                    sum(row[1] for row in helper.SEQUENCE) + 0.3, 6
                ),
            },
        ),
        "Dual functional-only/ownership/cleanup receipt must not claim performance parity",
    )
    require(
        _exact(remote.get("runtime_flags"), {"short_slice": False, "shared": False})
        and isinstance(remote.get("inherited_environment"), dict)
        and set(remote["inherited_environment"])
        == {"BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED"}
        and all(
            value is None or isinstance(value, str) and value != "1"
            for value in remote["inherited_environment"].values()
        ),
        "Dual shared/short-slice flags must remain disabled",
    )
    require(
        type(remote.get("helper_pid")) is int
        and remote["helper_pid"] > 0
        and type(remote.get("begin_ns")) is int
        and type(remote.get("end_ns")) is int
        and 0 <= remote["begin_ns"] < remote["end_ns"]
        and remote["end_ns"] - remote["begin_ns"]
        < helper.MAX_RUN_SECONDS * 1_000_000_000
        and _fields(remote, {"watchdog_seconds": 14}),
        "Invalid bounded dual helper identity/run interval",
    )
    identity = remote.get("identity")
    require(
        _fields(
            identity,
            {
                "gpio": 18,
                "label": "pinctrl-rp1",
                "kernel_release": helper.base.baseline.KERNEL,
                "compatible": ["raspberrypi,rp1-gpio"],
            },
        )
        and type(identity.get("gpiochip_index")) is int
        and identity["gpiochip_index"] >= 0
        and identity.get("gpiochip") == f"/dev/gpiochip{identity['gpiochip_index']}"
        and isinstance(identity.get("gpiochip_device_number"), str)
        and re.fullmatch(r"[0-9]+:[0-9]+", identity["gpiochip_device_number"])
        and isinstance(identity.get("model"), str)
        and identity["model"].startswith("Raspberry Pi 5 Model B Rev ")
        and isinstance(identity.get("boot_id"), str)
        and re.fullmatch(
            r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", identity["boot_id"]
        ),
        "Expected approved Pi5 RP1 GPIO18/GPIO23 identity",
    )
    require(
        isinstance(remote.get("manifest_path"), str)
        and re.fullmatch(
            helper.ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", remote["manifest_path"]
        ),
        "Manifest must be in the isolated native-dual root",
    )
    preclaim = remote.get("preclaim_lines")
    require(
        isinstance(preclaim, list) and len(preclaim) == 2,
        "Both fresh unused GPIO lines must be inspected",
    )
    for row, gpio in zip(preclaim, (18, 23)):
        require(_fields(row, {"gpio": gpio}), "Preclaim pin mismatch")
        _chip(row.get("chip_info"), identity)
        _line(row.get("line_info"), gpio)
    outputs = remote.get("outputs")
    require(
        isinstance(outputs, list) and len(outputs) == len(helper.OUTPUTS),
        "Exactly three fixed output generations required",
    )
    records = {}
    for row, (output_id, gpio, generation, frequency) in zip(outputs, helper.OUTPUTS):
        require(
            _fields(
                row,
                {
                    "output_id": output_id,
                    "gpio": gpio,
                    "generation": generation,
                    "initial_frequency": frequency,
                    "variable_frequency": True,
                    "fresh_claim_accepted": True,
                    "initial_low_confirmed": True,
                    "low_confirmed": True,
                    "released": True,
                    "read_only_chip_closed": True,
                },
            )
            and _exact(row.get("initial_readback"), {"gpio_level": 0, "inactive": True})
            and _exact(
                row.get("cleanup_final_readback"), {"gpio_level": 0, "inactive": True}
            ),
            "Fresh private output initial/cleanup inactive and release proof required: "
            + output_id,
        )
        request = row.get("owned_request")
        require(
            _fields(
                request,
                {"chip_name": Path(identity["gpiochip"]).name, "offsets": [gpio]},
            )
            and set(request) == {"chip_name", "offsets", "fd"}
            and type(request.get("fd")) is int
            and request["fd"] >= 0,
            "Each output generation must own only its verified pin and private FD",
        )
        _chip(row.get("chip_info"), identity)
        for key in ("preclaim_line_info", "released_line_info"):
            _line(row.get(key), gpio)
        records[output_id] = row
    _validate_lifecycle(remote, records)
    for key, limit in (("before", 65000), ("after", 70000)):
        require(
            isinstance(remote.get(key), dict)
            and not helper.core.thermal_issues(remote[key], limit),
            "Dual thermal/firmware gate failed: " + key,
        )


def _exact(actual, expected):
    if type(actual) is not type(expected):
        return False
    if isinstance(expected, dict):
        return set(actual) == set(expected) and all(
            _exact(actual[key], value) for key, value in expected.items()
        )
    if isinstance(expected, list):
        return len(actual) == len(expected) and all(
            _exact(a, b) for a, b in zip(actual, expected)
        )
    return actual == expected


def _fields(actual, expected):
    return isinstance(actual, dict) and all(
        key in actual and _exact(actual[key], value) for key, value in expected.items()
    )


def _chip(chip, identity):
    require(
        _fields(chip, {"name": Path(identity["gpiochip"]).name, "label": "pinctrl-rp1"})
        and type(chip.get("num_lines")) is int
        and chip["num_lines"] > 23,
        "Verified read-only gpiod RP1 chip identity required",
    )


def _line(line, gpio):
    require(
        _fields(line, {"offset": gpio, "used": False})
        and line.get("consumer") in (None, ""),
        f"Unclaimed read-only GPIO{gpio} evidence required",
    )


def _snapshot(output_id, state, records):
    row = records[output_id]
    return {
        "output_id": output_id,
        "gpio": row["gpio"],
        "generation": row["generation"],
        "owned_request": row["owned_request"],
        "frequency": state[0],
        "duty_u16": state[1],
    }


def _validate_lifecycle(remote, records):
    phases = remote.get("phases")
    require(
        isinstance(phases, list)
        and len(phases) == len(helper.SEQUENCE)
        and all(isinstance(phase, dict) for phase in phases),
        "Missing fixed dual lifecycle phases",
    )
    expected_events, expected_shutdowns = [], []
    states = {
        output_id: (frequency, 0)
        for output_id, _gpio, _generation, frequency in helper.OUTPUTS[:2]
    }

    def event(output_id, operation, scope, arguments, lower, upper):
        expected_events.append((output_id, operation, scope, arguments, lower, upper))

    def construct(output_id, scope, lower, upper):
        row = records[output_id]
        event(output_id, "gpiod_line_info_preclaim", scope, None, lower, upper)
        event(
            output_id,
            "PWMOut.__init__",
            scope,
            {
                "gpiochip": remote["identity"]["gpiochip"],
                "gpio": row["gpio"],
                "frequency": row["initial_frequency"],
                "duty_u16": 0,
                "variable_frequency": True,
            },
            lower,
            upper,
        )
        event(output_id, "initial_request.get_value", scope, None, lower, upper)

    def shutdown(output_id, sibling_id, scope, reason, lower, upper):
        first = len(expected_events)
        sibling_state = (
            _snapshot(sibling_id, states[sibling_id], records) if sibling_id else None
        )
        if sibling_id:
            event(
                sibling_id,
                "sibling_before_request.get_value",
                scope,
                None,
                lower,
                upper,
            )
        for operation in (
            "track_owned_request",
            "PWMOut.duty_cycle_zero",
            "low_settle",
            "owned_request.get_value",
            "PWMOut.deinit",
            "gpiod_line_info_released",
        ):
            event(output_id, operation, scope, None, lower, upper)
        if sibling_id:
            event(
                sibling_id, "sibling_after_request.get_value", scope, None, lower, upper
            )
        expected_shutdowns.append(
            (
                output_id,
                sibling_id,
                sibling_state,
                scope,
                reason,
                lower,
                upper,
                first,
                len(expected_events) - 1,
            )
        )
        del states[output_id]

    for output_id in states:
        construct(
            output_id,
            "initialization_" + output_id,
            remote["begin_ns"],
            phases[0].get("begin_ns"),
        )
    previous_end = remote["begin_ns"]
    for index, (phase, (name, duration, actions)) in enumerate(
        zip(phases, helper.SEQUENCE)
    ):
        scope = f"{index:02d}_{name}"
        require(
            isinstance(phase, dict)
            and set(phase)
            == {
                "index",
                "name",
                "scope",
                "duration_seconds",
                "actions",
                "begin_ns",
                "stable_begin_ns",
                "api_state",
                "end_ns",
                "api_state_end",
                "readback_end_ns",
            }
            and _fields(
                phase,
                {
                    "index": index,
                    "name": name,
                    "scope": scope,
                    "actions": list(actions),
                },
            )
            and type(phase.get("duration_seconds")) in (int, float)
            and phase["duration_seconds"] == duration,
            "Fixed dual phase/actions mismatch: " + name,
        )
        clocks = [
            phase.get(key)
            for key in ("begin_ns", "stable_begin_ns", "end_ns", "readback_end_ns")
        ]
        require(
            all(type(value) is int for value in clocks)
            and previous_end
            <= clocks[0]
            <= clocks[1]
            < clocks[2]
            <= clocks[3]
            <= remote["end_ns"]
            and clocks[2] - clocks[1] >= round(duration * 1_000_000_000),
            "Dual phase interval/dwell mismatch: " + name,
        )
        previous_end = clocks[-1]
        for action in actions:
            output_id, operation = action["output_id"], action["operation"]
            if operation == "construct":
                construct(output_id, scope, clocks[0], clocks[1])
                states[output_id] = (records[output_id]["initial_frequency"], 0)
            elif operation == "shutdown":
                shutdown(
                    output_id,
                    action["sibling_id"],
                    scope,
                    "sequence",
                    clocks[0],
                    clocks[1],
                )
            else:
                frequency, duty = action["frequency"], action["duty_u16"]
                old_frequency, old_duty = states[output_id]
                if frequency != old_frequency:
                    event(
                        output_id,
                        "PWMOut.frequency",
                        scope,
                        {"frequency": frequency, "duty_u16": old_duty},
                        clocks[0],
                        clocks[1],
                    )
                if duty != old_duty:
                    event(
                        output_id,
                        "PWMOut.duty_cycle",
                        scope,
                        {"frequency": frequency, "duty_u16": duty},
                        clocks[0],
                        clocks[1],
                    )
                states[output_id] = (frequency, duty)
        expected_state = [
            _snapshot(output_id, state, records) for output_id, state in states.items()
        ]
        require(
            len({row["owned_request"]["fd"] for row in expected_state})
            == len(expected_state),
            "Concurrent native outputs must own distinct private request FDs",
        )
        for key in ("api_state", "api_state_end"):
            require(
                _exact(phase.get(key), expected_state),
                "Active generation/request/software-state mismatch: " + name,
            )
    shutdown(
        "gpio18-g2",
        None,
        "safety_cleanup_gpio18-g2",
        "safety_cleanup",
        previous_end,
        remote["end_ns"],
    )
    events = remote.get("events")
    require(
        isinstance(events, list) and len(events) == len(expected_events),
        "Exact fixed dual constructor/setter/cleanup events required",
    )
    previous_end = remote["begin_ns"]
    for ordinal, (actual, spec) in enumerate(zip(events, expected_events)):
        output_id, operation, scope, arguments, lower, upper = spec
        record = records[output_id]
        require(
            isinstance(actual, dict)
            and set(actual)
            == {
                "ordinal",
                "output_id",
                "gpio",
                "generation",
                "operation",
                "scope",
                "arguments",
                "begin_ns",
                "end_ns",
                "status",
            }
            and _fields(
                actual,
                {
                    "ordinal": ordinal,
                    "output_id": output_id,
                    "gpio": record["gpio"],
                    "generation": record["generation"],
                    "operation": operation,
                    "scope": scope,
                    "arguments": arguments,
                    "status": "ok",
                },
            )
            and type(actual.get("begin_ns")) is int
            and type(actual.get("end_ns")) is int
            and max(previous_end, lower)
            <= actual["begin_ns"]
            <= actual["end_ns"]
            <= upper,
            "Dual caller event pin/generation/order/arguments/interval mismatch",
        )
        if operation == "low_settle":
            require(
                actual["end_ns"] - actual["begin_ns"] >= 100_000_000,
                "Owned output low-settle interval is too short",
            )
        previous_end = actual["end_ns"]
    shutdowns = remote.get("shutdowns")
    require(
        isinstance(shutdowns, list) and len(shutdowns) == len(expected_shutdowns),
        "Exactly three independent shutdowns required",
    )
    for actual, spec in zip(shutdowns, expected_shutdowns):
        (
            output_id,
            sibling_id,
            sibling_state,
            scope,
            reason,
            lower,
            upper,
            first,
            last,
        ) = spec
        require(
            _fields(
                actual,
                {
                    "output_id": output_id,
                    "scope": scope,
                    "reason": reason,
                    "sibling_id": sibling_id,
                    "errors": [],
                    "success": True,
                },
            )
            and type(actual.get("begin_ns")) is int
            and type(actual.get("end_ns")) is int
            and lower
            <= actual["begin_ns"]
            <= events[first]["begin_ns"]
            <= events[last]["end_ns"]
            <= actual["end_ns"]
            <= upper,
            "Independent shutdown identity/scope/interval/error mismatch",
        )
        for key in ("sibling_before", "sibling_after"):
            snapshot = actual.get(key)
            if sibling_id is None:
                require(
                    key in actual and snapshot is None,
                    "Final shutdown must not touch a sibling",
                )
            else:
                require(
                    isinstance(snapshot, dict)
                    and type(snapshot.get("gpio_level")) is int
                    and snapshot["gpio_level"] in (0, 1)
                    and _exact(
                        {k: v for k, v in snapshot.items() if k != "gpio_level"},
                        sibling_state,
                    ),
                    "Continuing sibling private request/software state must remain unchanged",
                )


def capture_test(directory, remote_root, remote_python, manifest_path):
    require(
        isinstance(remote_root, str) and re.fullmatch(helper.ROOT_PATTERN, remote_root),
        "Requires the isolated Pi5 native-dual root",
    )
    require(
        isinstance(remote_python, str)
        and (
            re.fullmatch(
                r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/venv/bin/python", remote_python
            )
            or remote_python == remote_root + "/venv/bin/python"
        ),
        "Requires an explicit approved absolute venv Python",
    )
    manifest = helper.load_manifest(manifest_path)
    validate_local_manifest(manifest)
    output = Path(directory).resolve()
    require(
        re.fullmatch(r"[A-Za-z0-9_-]+", output.name),
        "Use a simple capture directory name",
    )
    output.mkdir(parents=True, exist_ok=False)
    _write(output, "manifest.json", json.dumps(manifest, indent=2) + "\n")
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(
            [
                remote_python,
                remote_root + "/native_pwm_dual_eval.py",
                "--manifest",
                remote_root + "/manifest.json",
            ]
        ),
    ]
    remote, primary, logic_version = None, None, None
    evidence_errors, timing = [], {}
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            require(
                any(
                    device.device_id == DEVICE_ID and not device.is_simulation
                    for device in manager.get_devices()
                ),
                "Confirmed physical Logic8 analyzer is unavailable",
            )
            logic_version = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[0, 1], digital_sample_rate=100_000_000
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as capture:
                try:
                    timing["lead_begin_ns"] = time.monotonic_ns()
                    time.sleep(0.5)
                    timing["lead_end_ns"] = time.monotonic_ns()
                    with (
                        (output / "remote.stdout").open("x") as stdout_file,
                        (output / "remote.stderr").open("x") as stderr_file,
                    ):
                        remote = subprocess.run(
                            command,
                            stdout=stdout_file,
                            stderr=stderr_file,
                            text=True,
                            check=False,
                            timeout=30,
                        )
                except subprocess.TimeoutExpired as error:
                    primary, remote = error, subprocess.CompletedProcess(command, 124)
                except BaseException as error:
                    primary, remote = error, subprocess.CompletedProcess(command, None)
                finally:
                    for name in ("remote.stdout", "remote.stderr"):
                        try:
                            if not (output / name).exists():
                                _write(output, name, "")
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
                    for name, action in (
                        ("tail", lambda: time.sleep(0.2)),
                        ("stop", capture.stop),
                        (
                            "save_capture",
                            lambda: capture.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_binary",
                            lambda: capture.export_raw_data_binary(
                                str(output), digital_channels=[0, 1]
                            ),
                        ),
                    ):
                        try:
                            if name == "tail":
                                timing["tail_begin_ns"] = time.monotonic_ns()
                            action()
                            if name == "tail":
                                timing["tail_end_ns"] = time.monotonic_ns()
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:
        if primary is None:
            primary = error
        else:
            evidence_errors.append(f"acquisition: {type(error).__name__}: {error}")
    acquisition = {
        "mode": MODE,
        "backend": BACKEND,
        "remote_root": remote_root,
        "remote_python": remote_python,
        "remote_command": command,
        "remote_returncode": None if remote is None else remote.returncode,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "local_timing_ns": timing,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None
        if primary is None
        else f"{type(primary).__name__}: {primary}",
        "evidence_errors": evidence_errors,
    }
    _write(output, "acquisition.json", json.dumps(acquisition, indent=2) + "\n")
    result = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": MODE,
        "backend": BACKEND,
        "sequence_marker": SEQUENCE_MARKER,
        "sample_rate_hz": 100_000_000,
        "logic_version": logic_version,
        "production_backend_unchanged": True,
        "outputs": [
            {"gpio": 18, "saleae_channel": 0, "backend": BACKEND},
            {"gpio": 23, "saleae_channel": 1, "backend": BACKEND},
        ],
        "remote": None,
        "remote_returncode": acquisition["remote_returncode"],
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "success_scope": "acquisition and helper source/functional ownership/cleanup only; not waveform acceptance or parity",
    }
    try:
        if primary is not None or evidence_errors:
            raise RuntimeError(
                "Capture failure evidence retained: "
                + (acquisition["primary_error"] or "; ".join(evidence_errors))
            ) from primary
        require(
            remote is not None
            and type(remote.returncode) is int
            and remote.returncode == 0,
            "Dual native helper did not exit0; raw evidence retained",
        )
        require(
            all(
                (output / name).is_file() and (output / name).stat().st_size > 0
                for name in ("waveform.sal", "digital_0.bin", "digital_1.bin")
            ),
            "Missing SAL/raw PWM channel evidence",
        )
        result["remote"] = read_json((output / "remote.stdout").read_text())
        validate_remote(result["remote"], manifest)
        require(
            result["remote"]["manifest_path"] == remote_root + "/manifest.json",
            "Remote manifest root does not match acquisition",
        )
        result["collection_success"] = True
    except BaseException as error:
        result["receipt_validation_error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        _write(output, "results.json", json.dumps(result, indent=2) + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--remote-python", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    result = capture_test(
        args.directory, args.remote_root, args.remote_python, args.manifest
    )
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "mode": MODE,
                "backend": BACKEND,
                "collection_success": result["collection_success"],
                "waveform_accepted": None,
                "parity_evaluated": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
