"""One-process CPU-load/capture handshake using only fixed reviewed helpers.

The CLI can capture only settled-direct or half50 on the existing approved
bench. This wrapper has no GPIO implementation: it starts the frozen local
capture helper only after a validated, already-persisted CPU launch receipt.
Local timing/exit status is coordination evidence, not proof of load overlap or
waveform acceptance. Independently audit the saved Pi-clock worker/PWM receipts.
"""

import argparse
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

import record_kernel_pwm_cpu_load as recorder

LOAD_SHA256 = "0644d9b0e0228bca813e7b3cbb909165e1c313d04baf2405c8f0f78badbc18ca"
WORKER_SHA256 = "430c6552b38acb6a87ee9aca00dfb0df1422969f5d8afea4869af6eac890918d"
MODES = {
    "settled-direct": ("capture_kernel_pwm_settled.py", "settled-eval", "direct"),
    "half50": ("capture_kernel_pwm_half50.py", "half50-eval", "half50-direct"),
}


def launch_issues(receipt):
    expected = {
        "schema_version": 1,
        "worker_source_sha256": WORKER_SHA256,
        "event": "load_launched",
        "mode": "cpu-only-fixed-two-workers",
        "worker_count": 2,
        "started_worker_count": 2,
        "worker_duration_seconds": 10,
        "launch_complete": True,
        "gpio_writes": False,
        "pwm_sysfs_access": False,
        "kernel_configuration_changes": False,
        "source_sha256": LOAD_SHA256,
    }
    issues = [
        f"Unexpected launch field {name}"
        for name, value in expected.items()
        if type(receipt.get(name)) is not type(value) or receipt.get(name) != value
    ]
    if type(receipt.get("launcher_pid")) is not int or receipt["launcher_pid"] <= 0:
        issues.append("Invalid launcher PID")
    workers = receipt.get("owned_workers")
    if not isinstance(workers, list) or len(workers) != 2:
        issues.append("Require two owned worker records")
    elif any(
        not isinstance(worker, dict)
        or type(worker.get("pid")) is not int
        or worker["pid"] <= 0
        or worker.get("reaped") is not False
        for worker in workers
    ):
        issues.append("Invalid owned worker launch records")
    else:
        pids = [worker["pid"] for worker in workers]
        if len(set(pids)) != 2 or receipt.get("launcher_pid") in pids:
            issues.append("Worker and launcher PIDs must be distinct")
    return issues


def coordinate(stem, remote_root, mode):
    if not isinstance(stem, str) or not re.fullmatch(r"[A-Za-z0-9_-]+-loaded-r2", stem):
        raise ValueError("Use a fresh simple stem ending -loaded-r2")
    if not isinstance(remote_root, str) or not re.fullmatch(
        r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}", remote_root
    ):
        raise ValueError("Requires the isolated Pi 5 bench root")
    if mode not in MODES:
        raise ValueError("Only settled-direct and half50 are approved")
    targets = [Path(stem)] + [
        Path(stem + suffix)
        for suffix in (
            ".load.stdout",
            ".load.stderr",
            ".capture.stdout",
            ".capture.stderr",
            ".coordination.json",
        )
    ]
    if any(path.exists() or path.is_symlink() for path in targets):
        raise FileExistsError("Fresh capture and receipt targets are required")
    script_name, subdirectory, child_mode = MODES[mode]
    script = Path(__file__).resolve().with_name(script_name)
    command = [
        sys.executable,
        str(script),
        stem,
        "--remote-root",
        remote_root + "/" + subdirectory,
        "--mode",
        child_mode,
    ]
    summary = {
        "schema_version": 1,
        "stem": stem,
        "mode": mode,
        "remote_root": remote_root,
        "load_remote_root": remote_root + "/cpu-load-eval",
        "capture_remote_root": remote_root + "/" + subdirectory,
        "capture_directory": stem,
        "capture_command": command,
        "load_source_sha256": LOAD_SHA256,
        "coordinator_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "recorder_sha256": hashlib.sha256(
            Path(recorder.__file__).read_bytes()
        ).hexdigest(),
        "launch_receipt": None,
        "launch_validated": False,
        "launch_validation_errors": [],
        "load_launcher_pid": None,
        "capture_started": False,
        "capture_begin_ns": None,
        "capture_end_ns": None,
        "capture_returncode": None,
        "capture_error": None,
        "load_helper_returncode": None,
        "load_recorder_exit_code": None,
        "load_recorder_error": None,
        "coordination_success": False,
        "overlap_verified": False,
        "waveform_accepted": None,
        "timing_clock": "local_monotonic_not_aligned_to_pi_or_saleae",
    }
    with Path(stem + ".coordination.json").open("x") as coordination_file:
        with Path(stem + ".capture.stdout").open("xb") as capture_stdout:
            with Path(stem + ".capture.stderr").open("xb") as capture_stderr:

                def launch_capture(receipt):
                    summary["launch_receipt"] = receipt
                    summary["load_launcher_pid"] = receipt.get("launcher_pid")
                    issues = launch_issues(receipt)
                    summary["launch_validation_errors"] = issues
                    if issues:
                        return
                    summary["launch_validated"] = True
                    summary["capture_started"] = True
                    summary["capture_begin_ns"] = time.monotonic_ns()
                    try:
                        child = subprocess.run(
                            command,
                            stdin=subprocess.DEVNULL,
                            stdout=capture_stdout,
                            stderr=capture_stderr,
                            check=False,
                            timeout=20,
                        )
                        summary["capture_returncode"] = child.returncode
                    except BaseException as error:
                        summary["capture_error"] = f"{type(error).__name__}: {error}"
                    finally:
                        summary["capture_end_ns"] = time.monotonic_ns()
                        capture_stdout.flush()
                        capture_stderr.flush()

                try:
                    summary["load_helper_returncode"] = recorder.record(
                        stem,
                        summary["load_remote_root"],
                        launch_callback=launch_capture,
                    )
                    summary["load_recorder_exit_code"] = 0
                except BaseException as error:
                    summary["load_helper_returncode"] = getattr(
                        error, "returncode", None
                    )
                    summary["load_recorder_exit_code"] = 1
                    summary["load_recorder_error"] = f"{type(error).__name__}: {error}"
                summary["coordination_success"] = (
                    summary["launch_validated"]
                    and summary["capture_started"]
                    and summary["load_helper_returncode"] == 0
                    and summary["load_recorder_exit_code"] == 0
                    and summary["capture_returncode"] == 0
                    and summary["capture_error"] is None
                )
                json.dump(summary, coordination_file, indent=2)
                coordination_file.write("\n")
                coordination_file.flush()
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stem")
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--mode", choices=tuple(MODES), required=True)
    args = parser.parse_args(argv)
    try:
        result = coordinate(args.stem, args.remote_root, args.mode)
    except BaseException as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        return 1
    print(
        json.dumps(
            {
                name: result[name]
                for name in (
                    "stem",
                    "mode",
                    "coordination_success",
                    "load_helper_returncode",
                    "load_recorder_exit_code",
                    "capture_returncode",
                    "capture_error",
                )
            }
        )
    )
    return 0 if result["coordination_success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
