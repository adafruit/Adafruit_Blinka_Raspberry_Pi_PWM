"""Fixed GPIO18 Pi5 characterization of two unmodified Blinka lgpio files.

This is not a production adapter or a parity verdict. API state and integer duty
rounding are recorded, not physical frequency or pulse-width readbacks. Original
setters run without added settles; separately recorded safety cleanup cancels
PWM, drives only the privately claimed line low, then deinitializes/frees/closes.
The original deinit alone does not cancel or free GPIO. No PWM sysfs/MMIO writes,
overlays, fans, PIO, load, affinity or scheduling changes are implemented here.
"""

import argparse
import hashlib
import importlib
import importlib.util
import json
import os
import platform
import re
import signal
import stat
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import kernel_pwm_eval as core

BLINKA_COMMIT = "beb49bf8ea9305dacbd14b08525f234eda563c02"
KERNEL = "6.12.75+rpt-rpi-2712"
PIN_KEY = "adafruit_blinka.microcontroller.generic_linux.lgpio_pin"
GPIO_DEVICES = Path("/sys/bus/gpio/devices")
DEVICE_TREE = Path("/sys/firmware/devicetree/base")
SYSFS_PWM = Path("/sys/class/pwm")
BOOT_ID = Path("/proc/sys/kernel/random/boot_id")
MAX_RUN_SECONDS = 14
PINNED_SOURCES = {
    "baseline_pwmout.py": "90284c9860827ee39cf9eb0b5639b1e6f296473d99fd1be222dccb1d618a9220",
    "lgpio_pin.py": "f836d4e5342639b0fa4348b8600fbc6b6401d79ce138ccbda2886bc028cdb413",
    "kernel_pwm_eval.py": "7cb4ea051e346b38b3276b92e5e0edcd9f24f4ed36f7d4f4eeffa4800f8e2111",
}
SEQUENCES = {
    "direct": (
        ("low50_initial", 0.2, 50, 0),
        ("control50_d4915", 0.4, 50, 4915),
        ("high50_first", 0.3, 50, 65535),
        ("recovery50_d4915", 0.4, 50, 4915),
        ("high50_second", 0.3, 50, 65535),
        ("recovery500_d32768", 0.4, 500, 32768),
        ("high500", 0.3, 500, 65535),
        ("high50_after_frequency", 0.3, 50, 65535),
        ("recovery50_final_d4915", 0.4, 50, 4915),
        ("low50_final", 0.2, 50, 0),
    ),
    "frequency": (
        ("low50_initial", 0.2, 50, 0),
        ("pwm50_d4915_initial", 0.4, 50, 4915),
        ("pwm500_d32768", 0.4, 500, 32768),
        ("pwm50_d4915_recovery", 0.4, 50, 4915),
        ("low50_before_high", 0.2, 50, 0),
        ("high50_first", 0.3, 50, 65535),
        ("high500", 0.3, 500, 65535),
        ("high50_after_frequency", 0.3, 50, 65535),
        ("low50_final", 0.2, 50, 0),
    ),
    "half50-direct": (
        ("low50_initial", 0.2, 50, 0),
        ("pwm50_d32768_initial", 0.4, 50, 32768),
        ("high50", 0.3, 50, 65535),
        ("pwm50_d32768_recovery", 0.4, 50, 32768),
        ("low50_final", 0.2, 50, 0),
    ),
}


def strings(path):
    return path.read_bytes().rstrip(b"\0").decode("ascii").split("\0")


def preflight():
    if platform.release() != KERNEL:
        raise core.BenchError("Only the exact approved Pi5 kernel is authorized")
    model = strings(DEVICE_TREE / "model")[0]
    if not model.startswith("Raspberry Pi 5 Model B Rev "):
        raise core.BenchError("Only Raspberry Pi 5 Model B is authorized")
    boot_id = BOOT_ID.read_text().strip()
    if not re.fullmatch(r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", boot_id):
        raise core.BenchError("Invalid boot ID")
    for path in DEVICE_TREE.rglob("compatible"):
        names = strings(path)
        node = path.parent
        status = strings(node / "status")[0] if (node / "status").exists() else "okay"
        forbidden = "pwm-gpio" in names or (
            node.name == "pwm@98000" and "raspberrypi,rp1-pwm" in names
        )
        if forbidden and status in ("okay", "ok"):
            raise core.BenchError(
                "Refusing live header PWM or pwm-gpio device-tree provider"
            )
    for chip in SYSFS_PWM.glob("pwmchip*"):
        node = chip / "device/of_node"
        if node.exists() and (
            "pwm-gpio" in strings(node / "compatible")
            or (node.resolve().name == "pwm@98000")
        ):
            raise core.BenchError("Refusing registered header PWM or pwm-gpio provider")
    candidates = []
    for chip in GPIO_DEVICES.glob("gpiochip*"):
        compatible = chip / "of_node/compatible"
        if compatible.is_file() and "raspberrypi,rp1-gpio" in strings(compatible):
            candidates.append(chip)
    if len(candidates) != 1:
        raise core.BenchError("Require exactly one RP1 gpiochip")
    chip = candidates[0]
    node = (chip / "of_node").resolve(strict=True)
    node.relative_to(DEVICE_TREE.resolve(strict=True))
    # Modern /sys/bus/gpio entries expose dev/OF identity, not legacy label/ngpio.
    # Never confuse a legacy /sys/class/gpio base with the character-device index.
    device = Path("/dev") / chip.name
    device_number = (chip / "dev").read_text().strip()
    match = re.fullmatch(r"([0-9]+):([0-9]+)", device_number)
    device_stat = device.stat()
    if (
        match is None
        or not stat.S_ISCHR(device_stat.st_mode)
        or (os.major(device_stat.st_rdev), os.minor(device_stat.st_rdev))
        != tuple(map(int, match.groups()))
    ):
        raise core.BenchError("RP1 sysfs dev does not match its GPIO character device")
    return {
        "model": model,
        "kernel_release": platform.release(),
        "boot_id": boot_id,
        "gpio": 18,
        "gpiochip_index": int(chip.name[len("gpiochip") :]),
        "gpiochip": str(device),
        "gpiochip_device_number": device_number,
        "label": "pinctrl-rp1",
        "of_node": str(node),
        "compatible": strings(chip / "of_node/compatible"),
    }


def source_hashes():
    paths = {name: Path(__file__).with_name(name) for name in PINNED_SOURCES}
    paths["kernel_pwm_eval.py"] = Path(core.__file__)
    paths[Path(__file__).name] = Path(__file__)
    hashes = {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in paths.items()
    }
    return hashes


def load_lgpio():
    return importlib.import_module("lgpio")


def load_source(name, filename):
    spec = importlib.util.spec_from_file_location(
        name, Path(__file__).with_name(filename)
    )
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class Owner:
    def __init__(self, library, identity, guard, receipt):
        self.library, self.identity, self.guard, self.receipt = (
            library,
            identity,
            guard,
            receipt,
        )
        self.handle = None
        self.line_owned = False
        self.chip_owned = False
        self.pwm = None
        self.scope = "initialization"
        self.original = {
            name: getattr(library, name)
            for name in ("gpiochip_open", "gpio_claim_output", "tx_pwm")
        }

    def call(self, name, operation, args=None):
        event = {
            "operation": name,
            "scope": self.scope,
            "arguments": args,
            "begin_ns": time.monotonic_ns(),
        }
        try:
            value = operation()
            event.update(status="ok", result=value)
            return value
        except BaseException as error:
            event.update(status="error", error=f"{type(error).__name__}: {error}")
            raise
        finally:
            event["end_ns"] = time.monotonic_ns()
            self.receipt["events"].append(event)

    @staticmethod
    def checked(value):
        if type(value) is not int or value < 0:
            raise core.BenchError(f"Unexpected lgpio result: {value!r}")
        return value

    def open(self, chip):
        if self.chip_owned or chip != self.identity["gpiochip_index"]:
            raise core.BenchError(
                "Original chip discovery selected an unauthorized chip"
            )
        with self.guard.atomic():
            handle = self.checked(
                self.call(
                    "gpiochip_open",
                    lambda: self.original["gpiochip_open"](chip),
                    [chip],
                )
            )
            self.handle, self.chip_owned = handle, True
        info = self.call(
            "gpio_get_chip_info",
            lambda: self.library.gpio_get_chip_info(handle),
            [handle],
        )
        if (
            not isinstance(info, (list, tuple))
            or len(info) != 4
            or info[0] != 0
            or info[1] <= 18
            or info[3] != "pinctrl-rp1"
        ):
            raise core.BenchError("Opened chip is not the verified RP1 GPIO controller")
        self.receipt["chip_info"] = list(info)
        return handle

    def scope_check(self, handle, gpio, *, owned=True):
        if (
            handle != self.handle
            or not self.chip_owned
            or gpio != 18
            or (owned and not self.line_owned)
        ):
            raise core.BenchError("Only this privately owned GPIO18 is authorized")

    def claim(self, handle, gpio, *args, **kwargs):
        self.scope_check(handle, gpio, owned=False)
        if self.line_owned:
            raise core.BenchError("Refusing repeated GPIO18 claim")
        mode = self.checked(
            self.call(
                "gpio_get_mode_preclaim",
                lambda: self.library.gpio_get_mode(handle, gpio),
                [handle, gpio],
            )
        )
        self.receipt["preclaim_mode"] = mode
        info = self.call(
            "gpio_get_line_info_preclaim",
            lambda: self.library.gpio_get_line_info(handle, gpio),
            [handle, gpio],
        )
        self.receipt["preclaim_line_info"] = info
        if (
            not isinstance(info, (list, tuple))
            or len(info) != 5
            or info[0] != 0
            or info[1] != 18
            or type(info[2]) is not int
        ):
            raise core.BenchError("Malformed GPIO18 line info")
        if mode & 1 or info[2] & 1 or info[4] != "":
            raise core.BenchError("GPIO18 is already claimed; never borrow it")
        with self.guard.atomic():
            value = self.checked(
                self.call(
                    "gpio_claim_output",
                    lambda: self.original["gpio_claim_output"](
                        handle, gpio, *args, **kwargs
                    ),
                    {
                        "handle": handle,
                        "gpio": gpio,
                        "args": list(args),
                        "kwargs": kwargs,
                    },
                )
            )
            self.line_owned = True
            self.receipt["fresh_claim_accepted"] = True
        return value

    def tx(self, handle, gpio, *args, **kwargs):
        self.scope_check(handle, gpio)
        return self.call(
            "tx_pwm",
            lambda: self.original["tx_pwm"](handle, gpio, *args, **kwargs),
            {"handle": handle, "gpio": gpio, "args": list(args), "kwargs": kwargs},
        )

    @contextmanager
    def hooks(self):
        previous = {
            PIN_KEY: sys.modules.get(PIN_KEY),
            "baseline_pwmout": sys.modules.get("baseline_pwmout"),
        }
        original_path = sys.path[:]
        original_exceptions = self.library.exceptions
        sys.path.insert(0, "/usr/lib/python3/dist-packages")
        (
            self.library.gpiochip_open,
            self.library.gpio_claim_output,
            self.library.tx_pwm,
        ) = self.open, self.claim, self.tx
        try:
            yield
        finally:
            for name, function in self.original.items():
                setattr(self.library, name, function)
            self.library.exceptions = original_exceptions
            sys.path[:] = original_path
            for name, module in previous.items():
                if module is None:
                    sys.modules.pop(name, None)
                else:
                    sys.modules[name] = module

    def cleanup(self):
        self.scope = "extra_safety_cleanup"

        def attempt(name, operation, *, checked=True):
            try:
                value = self.call(name, operation)
                return self.checked(value) if checked else value
            except BaseException as error:  # noqa: BLE001 - finish every owned cleanup step.
                self.receipt["cleanup_errors"].append(
                    f"{name}: {type(error).__name__}: {error}"
                )
                return None

        if self.line_owned:
            attempt(
                "cancel_pwm", lambda: self.original["tx_pwm"](self.handle, 18, 0, 0)
            )
            attempt("drive_low", lambda: self.library.gpio_write(self.handle, 18, 0))
            attempt("low_settle", lambda: time.sleep(0.1), checked=False)
            level = attempt("read_low", lambda: self.library.gpio_read(self.handle, 18))
            busy = attempt(
                "read_pwm_busy",
                lambda: self.library.tx_busy(self.handle, 18, self.library.TX_PWM),
            )
            self.receipt["cleanup_final_readback"] = {
                "gpio_level": level,
                "tx_busy": busy,
            }
            self.receipt["low_confirmed"] = level == 0 and busy == 0
            if not self.receipt["low_confirmed"]:
                self.receipt["cleanup_errors"].append(
                    "Canceled, settled GPIO18 low not confirmed"
                )
            if self.pwm is not None and hasattr(self.pwm, "_deinited"):
                attempt("original_PWMOut.deinit", self.pwm.deinit, checked=False)
            freed = attempt(
                "gpio_free", lambda: self.library.gpio_free(self.handle, 18)
            )
            if freed is not None:
                self.line_owned = False
                mode = attempt(
                    "gpio_get_mode_released",
                    lambda: self.library.gpio_get_mode(self.handle, 18),
                )
                self.receipt["released_mode"] = mode
                self.receipt["gpio18_released"] = mode is not None and not (
                    mode & 0xF01
                )
                if not self.receipt["gpio18_released"]:
                    self.receipt["cleanup_errors"].append(
                        "Fresh GPIO18 release not confirmed"
                    )
        if self.chip_owned:
            closed = attempt(
                "gpiochip_close", lambda: self.library.gpiochip_close(self.handle)
            )
            if closed is not None:
                self.chip_owned = False
                self.line_owned = False
                self.receipt["chip_closed"] = True


def run_phase(owner, phases, name, duration, frequency, duty):
    owner.scope = name
    begin = time.monotonic_ns()
    if owner.pwm.frequency != frequency:
        owner.call(
            "PWMOut.frequency",
            lambda: setattr(owner.pwm, "frequency", frequency),
            {
                "requested_frequency": frequency,
                "requested_duty_u16": owner.pwm.duty_cycle,
                "baseline_duty_percent": round(owner.pwm._duty_cycle * 100),
            },
        )
    if owner.pwm.duty_cycle != duty:
        owner.call(
            "PWMOut.duty_cycle",
            lambda: setattr(owner.pwm, "duty_cycle", duty),
            {
                "requested_frequency": frequency,
                "requested_duty_u16": duty,
                "baseline_duty_percent": round(duty / 65535 * 100),
            },
        )
    stable = time.monotonic_ns()
    phase = {
        "name": name,
        "generation": 1,
        "frequency": frequency,
        "duty_u16": duty,
        "baseline_duty_percent": round(duty / 65535 * 100),
        "duration_seconds": duration,
        "intent": "low"
        if duty == 0
        else "constant_high"
        if duty == 65535
        else "interior_pwm",
        "transition_begin_ns": begin,
        "begin_ns": begin,
        "stable_begin_ns": stable,
        "api_state": {
            "frequency": owner.pwm.frequency,
            "duty_cycle": owner.pwm.duty_cycle,
            "enabled": owner.pwm.enabled,
        },
    }
    time.sleep(duration)
    phase["end_ns"] = time.monotonic_ns()
    phase["readback_end_ns"] = time.monotonic_ns()
    phases.append(phase)


def experiment(mode):
    if mode not in SEQUENCES:
        raise core.BenchError("Only direct, frequency and half50-direct are approved")
    receipt = {
        "schema_version": 1,
        "mode": mode,
        "sequence_marker": "original-lgpio-" + mode + "-v1",
        "backend": "original-blinka-lgpio",
        "gpio": 18,
        "helper_pid": os.getpid(),
        "baseline_commit": BLINKA_COMMIT,
        "characterization_only": True,
        "production_backend_unchanged": True,
        "parity_pass": None,
        "api_readbacks_are_not_electrical": True,
        "begin_ns": time.monotonic_ns(),
        "phases": [],
        "events": [],
        "signals_received": [],
        "source_sha256": {},
        "before": None,
        "after": None,
        "primary_error": None,
        "cleanup_errors": [],
        "completed_normally": False,
        "fresh_claim_accepted": False,
        "gpio18_released": False,
        "chip_closed": False,
        "low_confirmed": False,
        "cleanup_final_readback": None,
        "success": False,
    }
    owner = None
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            receipt["source_sha256"] = source_hashes()
            if any(
                receipt["source_sha256"].get(name) != expected
                for name, expected in PINNED_SOURCES.items()
            ):
                raise core.BenchError("Unmodified baseline/core source hash mismatch")
            receipt["identity"] = preflight()
            receipt["before"] = core.system_snapshot()
            issues = core.thermal_issues(receipt["before"], 65000)
            if issues:
                raise core.BenchError("Thermal preflight: " + "; ".join(issues))
            # The source's only dependency comes from the approved distro path.
            original_path = sys.path[:]
            try:
                sys.path.insert(0, "/usr/lib/python3/dist-packages")
                library = load_lgpio()
            finally:
                sys.path[:] = original_path
            receipt["lgpio_version"] = library.get_module_version()
            owner = Owner(library, receipt["identity"], guard, receipt)
            with owner.hooks():
                try:
                    pins = load_source(PIN_KEY, "lgpio_pin.py")
                    module = load_source("baseline_pwmout", "baseline_pwmout.py")
                    owner.pwm = module.PWMOut.__new__(module.PWMOut)
                    owner.call(
                        "PWMOut.__init__",
                        lambda: owner.pwm.__init__(
                            pins.Pin(18), frequency=50, duty_cycle=0
                        ),
                        {
                            "gpio": 18,
                            "requested_frequency": 50,
                            "requested_duty_u16": 0,
                            "baseline_duty_percent": 0,
                            "variable_frequency": False,
                        },
                    )
                    for phase in SEQUENCES[mode]:
                        run_phase(owner, receipt["phases"], *phase)
                    receipt["completed_normally"] = True
                finally:
                    with guard.cleanup():
                        signal.alarm(0)
                        owner.cleanup()
        except BaseException as error:  # noqa: BLE001 - retain failures after owned cleanup.
            receipt["primary_error"] = f"{type(error).__name__}: {error}"
        finally:
            with guard.cleanup():
                signal.alarm(0)
                try:
                    receipt["after"] = core.system_snapshot()
                    receipt["cleanup_errors"].extend(
                        core.thermal_issues(receipt["after"], 70000)
                    )
                except BaseException as error:  # noqa: BLE001 - postflight failure is evidence.
                    receipt["cleanup_errors"].append(
                        f"Thermal postflight: {type(error).__name__}: {error}"
                    )
                finally:
                    receipt["signals_received"] = list(guard.received)
    receipt["end_ns"] = time.monotonic_ns()
    receipt["success"] = bool(
        receipt["completed_normally"]
        and receipt["primary_error"] is None
        and not receipt["cleanup_errors"]
        and not receipt["signals_received"]
        and receipt["fresh_claim_accepted"]
        and receipt["gpio18_released"]
        and receipt["chip_closed"]
        and receipt["low_confirmed"]
        and receipt["end_ns"] - receipt["begin_ns"] < 15_000_000_000
    )
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=tuple(SEQUENCES), required=True)
    args = parser.parse_args(argv)
    receipt = experiment(args.mode)
    print(json.dumps(receipt, sort_keys=True), flush=True)
    if not receipt["success"]:
        print(
            receipt["primary_error"]
            or "; ".join(receipt["cleanup_errors"])
            or "Characterization did not complete",
            file=sys.stderr,
        )
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
