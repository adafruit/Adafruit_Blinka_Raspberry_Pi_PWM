"""Read-only postflight for the fixed native live-consumer capture batch."""

import hashlib
import json
import shlex
import subprocess
from pathlib import Path

from capture_native_pwm_half50 import read_json
from record_native_updates_postflight import BOOT_ID, BOOT_SHA, REMOTE, REMOTE_PYTHON

LAB = Path(__file__).resolve().parent
CAPTURES = [f"oct7-pi5-native-consumers-r{repeat}" for repeat in (1, 2)]
OUTPUT = LAB / "oct7-native-consumers-postflight.json"


def main():
    prior = read_json((LAB / "oct7-native-dual-postflight.json").read_text())
    if prior["accepted"] is not True:
        raise ValueError("Prior postflight was not accepted")
    pids = set(prior["inspected_pids"])
    for name in CAPTURES:
        receipt = read_json((LAB / name / "remote.stdout").read_text())
        result = read_json((LAB / name / "results.json").read_text())
        if receipt["success"] is not True or result["collection_success"] is not True:
            raise ValueError("Only completed captures may be postflighted")
        pids.add(receipt["helper_pid"])
    if not pids or not all(type(pid) is int and pid > 1 for pid in pids):
        raise ValueError("Invalid inspected PID set")
    targets = [OUTPUT, Path(str(OUTPUT) + ".stdout"), Path(str(OUTPUT) + ".stderr")]
    if any(path.exists() or path.is_symlink() for path in targets):
        raise ValueError("Postflight targets must be fresh")
    code = REMOTE.replace("PIDS", repr(json.dumps(sorted(pids))))
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([REMOTE_PYTHON, "-c", code]),
    ]
    with targets[1].open("xb") as stdout, targets[2].open("xb") as stderr:
        result = subprocess.run(
            command, stdout=stdout, stderr=stderr, timeout=20, check=False
        )
    remote = read_json(targets[1].read_text()) if result.returncode == 0 else None
    accepted = bool(
        remote
        and result.returncode == 0
        and remote["boot_id"] == BOOT_ID
        and remote["boot_config_sha256"] == BOOT_SHA
        and remote["gpiochip"]["label"] == "pinctrl-rp1"
        and not any(remote["pid_exists"].values())
        and all(
            line["used"] is False and not line["consumer"] for line in remote["lines"]
        )
        and all(
            query["returncode"] == 0 and "| lo" in query["stdout"]
            for query in remote["pinctrl"]
        )
        and remote["throttled"]["returncode"] == 0
        and remote["throttled"]["stdout"].strip() == "throttled=0x0"
        and int(remote["temperature_millic"]) < 65000
        and remote["pwm"]["returncode"] == 0
        and "platform/1f0009c000.pwm" in remote["pwm"]["stdout"]
        and "cooling_fan" in remote["pwm"]["stdout"]
        and "1f00098000" not in remote["pwm"]["stdout"]
        and "pwm-gpio" not in remote["pwm"]["stdout"]
    )
    receipt = {
        "capture_names": CAPTURES,
        "inspected_pids": sorted(pids),
        "ssh_returncode": result.returncode,
        "accepted": accepted,
        "remote": remote,
        "remote_read_only_code": code,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Read-only postflight, not waveform acceptance or an analog failsafe guarantee",
    }
    with OUTPUT.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {"accepted": accepted, "pids_inspected": len(pids), "remote": remote},
            indent=2,
        )
    )
    return 0 if accepted else 1


if __name__ == "__main__":
    raise SystemExit(main())
