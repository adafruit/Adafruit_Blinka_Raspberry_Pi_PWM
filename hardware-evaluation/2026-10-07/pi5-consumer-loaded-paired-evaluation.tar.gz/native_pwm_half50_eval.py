"""Lab-only, source-pinned native GPIO18 half50-direct characterization.

No scheduling/driver patches, alternate pins, or electrical/parity verdicts.
The 14-second alarm bounds ordinary Python execution, not a stuck native call,
SIGKILL, or a hardware fault. Cleanup never reclaims a released GPIO line.
"""

import argparse
import hashlib
import importlib
import importlib.machinery
import importlib.util
import json
import os
import re
import signal
import sys
import time
from pathlib import Path

import kernel_pwm_eval as core
import kernel_pwm_lgpio_baseline_eval as baseline

PACKAGE = "adafruit_blinka_raspberry_pi_pwm"
BACKEND = "native-blinka-pwm"
MODE = "half50-direct"
SEQUENCE_MARKER = "native-half50-direct-v1"
SEQUENCE = baseline.SEQUENCES[MODE]
MAX_RUN_SECONDS = 14
PINNED_SOURCES = {
    "kernel_pwm_lgpio_baseline_eval.py": "8018a1766c711a9babe8d98c4f1f77412f23876c4e7fdc96bd012caaf3808b2f",
    "kernel_pwm_eval.py": "7cb4ea051e346b38b3276b92e5e0edcd9f24f4ed36f7d4f4eeffa4800f8e2111",
}
SOURCE_KEYS = set(PINNED_SOURCES) | {
    "native_pwm_half50_eval.py",
    PACKAGE + "/__init__.py",
    PACKAGE + "/_software.py",
    PACKAGE + "/_native.so",
}
ROOT_PATTERN = r"/tmp/blinka-pwm-native-half50\.[A-Za-z0-9]{6}"


def validate_manifest(manifest):
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
    ):
        raise core.BenchError("Invalid native source manifest schema")
    hashes = manifest.get("source_sha256")
    if (
        not isinstance(hashes, dict)
        or set(hashes) != SOURCE_KEYS
        or any(
            not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None
            for value in hashes.values()
        )
    ):
        raise core.BenchError("Exact six-source SHA256 manifest required")
    if any(hashes[name] != digest for name, digest in PINNED_SOURCES.items()):
        raise core.BenchError("Unmodified baseline/core source manifest mismatch")
    return hashes


def load_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise core.BenchError("Duplicate manifest key: " + key)
            result[key] = value
        return result

    manifest = json.loads(Path(path).read_text(), object_pairs_hook=pairs)
    validate_manifest(manifest)
    return manifest


def approved_manifest_path(path):
    path = Path(path)
    if (
        not path.is_absolute()
        or re.fullmatch(ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", str(path)) is None
    ):
        raise core.BenchError(
            "Manifest must be absolute under the isolated native-half50 root"
        )
    resolved = path.resolve(strict=True)
    if resolved != path or path.parent != Path(__file__).resolve().parent:
        raise core.BenchError(
            "Manifest and helper must be in the same isolated root without symlinks"
        )
    return path


def source_hashes():
    spec = importlib.util.find_spec(PACKAGE)
    if spec is None or spec.origin is None:
        raise core.BenchError("Installed native PWM package is unavailable")
    package = Path(spec.origin).resolve().parent
    extensions = [
        package / ("_native" + suffix)
        for suffix in importlib.machinery.EXTENSION_SUFFIXES
    ]
    extensions = list(
        dict.fromkeys(path.resolve() for path in extensions if path.is_file())
    )
    if len(extensions) != 1:
        raise core.BenchError("Require exactly one installed native PWM extension")
    paths = {
        "native_pwm_half50_eval.py": Path(__file__),
        "kernel_pwm_lgpio_baseline_eval.py": Path(baseline.__file__),
        "kernel_pwm_eval.py": Path(core.__file__),
        PACKAGE + "/__init__.py": package / "__init__.py",
        PACKAGE + "/_software.py": package / "_software.py",
        PACKAGE + "/_native.so": extensions[0],
    }
    return {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in paths.items()
    }


def load_backend():
    return importlib.import_module("gpiod"), importlib.import_module(PACKAGE)


def inspect_line(library, identity):
    """Open a read-only gpiod v2 Chip; never request, set, or reclaim a line."""
    with library.Chip(identity["gpiochip"]) as chip:
        info, line = chip.get_info(), chip.get_line_info(18)
        chip_info = {
            "name": info.name,
            "label": info.label,
            "num_lines": info.num_lines,
        }
        line_info = {
            "offset": line.offset,
            "name": line.name,
            "used": line.used,
            "consumer": line.consumer,
        }
        if (
            info.name != Path(identity["gpiochip"]).name
            or info.label != "pinctrl-rp1"
            or type(info.num_lines) is not int
            or info.num_lines <= 18
        ):
            raise core.BenchError("Opened chip is not the verified RP1 GPIO controller")
        if (
            type(line.offset) is not int
            or line.offset != 18
            or type(line.used) is not bool
        ):
            raise core.BenchError("Malformed gpiod v2 GPIO18 line information")
        return chip_info, line_info


class Owner:
    def __init__(self, library, identity, guard, receipt):
        self.library, self.identity, self.guard, self.receipt = (
            library,
            identity,
            guard,
            receipt,
        )
        self.pwm = None
        self.scope = "initialization"

    def call(self, name, operation, arguments=None):
        event = {
            "operation": name,
            "scope": self.scope,
            "arguments": arguments,
            "begin_ns": time.monotonic_ns(),
        }
        try:
            value = operation()
            event["status"] = "ok"
            return value
        except BaseException as error:
            event.update(status="error", error=f"{type(error).__name__}: {error}")
            raise
        finally:
            event["end_ns"] = time.monotonic_ns()
            self.receipt["events"].append(event)

    def request(self):
        engine = getattr(self.pwm, "_engine", None)
        return getattr(engine, "_request", None)

    def track_request(self):
        request = self.request()
        if request is None:
            return False
        if (
            list(request.offsets) != [18]
            or request.chip_name != Path(self.identity["gpiochip"]).name
        ):
            raise core.BenchError(
                "Native PWM output did not privately claim only verified GPIO18"
            )
        self.receipt["owned_request"] = {
            "chip_name": request.chip_name,
            "offsets": list(request.offsets),
        }
        self.receipt["fresh_claim_accepted"] = True
        return True

    def construct(self, pwm_class):
        # Retain even a partially initialized public object for explicit deinit.
        self.pwm = pwm_class.__new__(pwm_class)
        with self.guard.atomic():
            self.call(
                "PWMOut.__init__",
                lambda: self.pwm.__init__(
                    (self.identity["gpiochip"], 18), frequency=50, duty_cycle=0
                ),
                {
                    "gpiochip": self.identity["gpiochip"],
                    "gpio": 18,
                    "frequency": 50,
                    "duty_u16": 0,
                    "variable_frequency": False,
                },
            )
            if not self.track_request():
                raise core.BenchError(
                    "Native PWM output returned without a private line request"
                )

    def cleanup(self):
        self.scope = "safety_cleanup"

        def attempt(name, operation):
            try:
                return self.call(name, operation)
            except BaseException as error:
                self.receipt["cleanup_errors"].append(
                    f"{name}: {type(error).__name__}: {error}"
                )
                return None

        if self.pwm is None:
            return
        try:
            if attempt("track_owned_request", self.track_request):
                attempt(
                    "PWMOut.duty_cycle_zero", lambda: setattr(self.pwm, "duty_cycle", 0)
                )
                attempt("low_settle", lambda: time.sleep(0.1))
                request = self.request()
                if request is not None:
                    level = attempt(
                        "owned_request.get_value", lambda: request.get_value(18)
                    )
                    inactive = level == self.library.line.Value.INACTIVE
                    self.receipt["cleanup_final_readback"] = {
                        "gpio_level": getattr(level, "value", None),
                        "inactive": inactive,
                    }
                    self.receipt["low_confirmed"] = inactive
                if not self.receipt["low_confirmed"]:
                    self.receipt["cleanup_errors"].append(
                        "Settled privately owned GPIO18 inactive not confirmed"
                    )
        finally:
            # Always attempt the public deinitializer, including constructor failure.
            attempt("PWMOut.deinit", self.pwm.deinit)
            inspected = attempt(
                "gpiod_line_info_released",
                lambda: inspect_line(self.library, self.identity),
            )
            if inspected is not None:
                self.receipt["released_line_info"] = inspected[1]
                self.receipt["read_only_chip_closed"] = True
                self.receipt["gpio18_released"] = inspected[1][
                    "used"
                ] is False and inspected[1]["consumer"] in (None, "")
                if not self.receipt["gpio18_released"]:
                    self.receipt["cleanup_errors"].append(
                        "GPIO18 unclaimed after deinit not confirmed; no reclaim attempted"
                    )


def run_phase(owner, phases, name, duration, frequency, duty):
    owner.scope = name
    begin = time.monotonic_ns()
    if owner.pwm.duty_cycle != duty:
        owner.call(
            "PWMOut.duty_cycle",
            lambda: setattr(owner.pwm, "duty_cycle", duty),
            {"frequency": frequency, "duty_u16": duty},
        )
    stable = time.monotonic_ns()
    phase = {
        "name": name,
        "generation": 1,
        "frequency": frequency,
        "duty_u16": duty,
        "duration_seconds": duration,
        "intent": "low"
        if duty == 0
        else "constant_high"
        if duty == 65535
        else "interior_pwm",
        "begin_ns": begin,
        "transition_begin_ns": begin,
        "stable_begin_ns": stable,
        "api_state": {
            "frequency": owner.pwm.frequency,
            "duty_cycle": owner.pwm.duty_cycle,
        },
    }
    time.sleep(duration)
    phase["end_ns"] = time.monotonic_ns()
    phase["api_state_end"] = {
        "frequency": owner.pwm.frequency,
        "duty_cycle": owner.pwm.duty_cycle,
    }
    phase["readback_end_ns"] = time.monotonic_ns()
    phases.append(phase)


def experiment(manifest_path):
    receipt = {
        "schema_version": 1,
        "mode": MODE,
        "sequence_marker": SEQUENCE_MARKER,
        "backend": BACKEND,
        "gpio": 18,
        "helper_pid": os.getpid(),
        "characterization_only": True,
        "production_backend_unchanged": True,
        "parity_pass": None,
        "api_readbacks_are_not_electrical": True,
        "variable_frequency": False,
        "runtime_flags": {"short_slice": False, "shared": False},
        "inherited_environment": {
            name: os.environ.get(name)
            for name in ("BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED")
        },
        "watchdog_seconds": MAX_RUN_SECONDS,
        "watchdog_cannot_bound_native_hang_or_sigkill": True,
        "begin_ns": time.monotonic_ns(),
        "phases": [],
        "events": [],
        "signals_received": [],
        "source_sha256": {},
        "before": None,
        "after": None,
        "primary_error": None,
        "cleanup_errors": [],
        "completed_normally": False,
        "fresh_claim_accepted": False,
        "gpio18_released": False,
        "read_only_chip_closed": False,
        "low_confirmed": False,
        "cleanup_final_readback": None,
        "success": False,
    }
    owner = None
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            manifest_path = approved_manifest_path(manifest_path)
            manifest = load_manifest(manifest_path)
            receipt["manifest_path"] = str(manifest_path)
            receipt["source_sha256"] = source_hashes()
            if receipt["source_sha256"] != manifest["source_sha256"]:
                raise core.BenchError(
                    "Installed native/helper/core source hash mismatch"
                )
            if any(value == "1" for value in receipt["inherited_environment"].values()):
                raise core.BenchError(
                    "Refusing inherited BLINKA_PWM_SHORT_SLICE/BLINKA_PWM_SHARED=1"
                )
            receipt["identity"] = baseline.preflight()
            receipt["before"] = core.system_snapshot()
            issues = core.thermal_issues(receipt["before"], 65000)
            if issues:
                raise core.BenchError("Thermal preflight: " + "; ".join(issues))
            library, module = load_backend()
            chip_info, line_info = inspect_line(library, receipt["identity"])
            receipt.update(
                chip_info=chip_info,
                preclaim_line_info=line_info,
                read_only_chip_closed=True,
            )
            if line_info["used"] or line_info["consumer"] not in (None, ""):
                raise core.BenchError("GPIO18 is already claimed; never borrow it")
            owner = Owner(library, receipt["identity"], guard, receipt)
            try:
                owner.construct(module.PWMOut)
                for phase in SEQUENCE:
                    run_phase(owner, receipt["phases"], *phase)
                receipt["completed_normally"] = True
            finally:
                with guard.cleanup():
                    signal.alarm(0)
                    owner.cleanup()
        except BaseException as error:
            receipt["primary_error"] = f"{type(error).__name__}: {error}"
        finally:
            with guard.cleanup():
                signal.alarm(0)
                try:
                    receipt["after"] = core.system_snapshot()
                    receipt["cleanup_errors"].extend(
                        core.thermal_issues(receipt["after"], 70000)
                    )
                except BaseException as error:
                    receipt["cleanup_errors"].append(
                        f"Thermal postflight: {type(error).__name__}: {error}"
                    )
                receipt["signals_received"] = list(guard.received)
    receipt["end_ns"] = time.monotonic_ns()
    receipt["success"] = bool(
        receipt["completed_normally"]
        and receipt["primary_error"] is None
        and not receipt["cleanup_errors"]
        and not receipt["signals_received"]
        and receipt["fresh_claim_accepted"]
        and receipt["gpio18_released"]
        and receipt["read_only_chip_closed"]
        and receipt["low_confirmed"]
        and receipt["end_ns"] - receipt["begin_ns"] < MAX_RUN_SECONDS * 1_000_000_000
    )
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    receipt = experiment(args.manifest)
    print(json.dumps(receipt, sort_keys=True), flush=True)
    if not receipt["success"]:
        print(
            receipt["primary_error"]
            or "; ".join(receipt["cleanup_errors"])
            or "Native characterization did not complete",
            file=sys.stderr,
        )
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
