"""Fixed read-only paired consumer pre/postflight; never drives GPIO."""

import argparse
import hashlib
import json
import re
import shlex
import subprocess
from pathlib import Path

import capture_lgpio_pwm_consumers as original
import capture_native_pwm_consumers as native
from record_native_updates_postflight import BOOT_ID, BOOT_SHA, REMOTE, REMOTE_PYTHON

LAB = Path(__file__).resolve().parent
NATIVE_ROOT = "/tmp/blinka-pwm-native-consumers.oPHx3J"
PLAN_SHA256 = "a4bf9e03fd8fd7d95f2dff9118108f046999272e63d95f7cc78d87caa3f80c7c"
PRIOR_SHA256 = "df61294e4d852d964dfcceb9cedaf14c522254dc483ee4281a30b20dfda7b301"
CAPTURES = (
    "oct7-pi5-lgpio-consumers-r1",
    "oct7-pi5-native-consumers-paired-r1",
    "oct7-pi5-native-consumers-paired-r2",
    "oct7-pi5-lgpio-consumers-r2",
)
require, read_json = original.require, original.read_json


def read(name):
    return read_json((LAB / name).read_text())


def inputs(stage, root):
    require(stage in ("preflight", "postflight"), "Fixed paired stage required")
    require(
        isinstance(root, str) and re.fullmatch(original.helper.ROOT_PATTERN, root),
        "Approved isolated original root required",
    )
    require(
        hashlib.sha256(
            (LAB / "oct7-lgpio-consumers-plan.json").read_bytes()
        ).hexdigest()
        == PLAN_SHA256,
        "Frozen paired plan changed",
    )
    plan = read("oct7-lgpio-consumers-plan.json")
    require(
        plan["remote_root"] == root
        and plan["remote_python"] == REMOTE_PYTHON
        and plan["capture_order"] == list(CAPTURES)
        and plan["native_reference"]["remote_root"] == NATIVE_ROOT,
        "Paired runtime/order changed",
    )
    manifests = {
        "original": read("oct7-lgpio-consumers-manifest.json"),
        "native": read("oct7-native-consumers-manifest.json"),
    }
    original.validate_local_manifest(manifests["original"])
    native.validate_local_manifest(manifests["native"])
    require(
        len(manifests["original"]["source_sha256"]) == 21
        and len(manifests["native"]["source_sha256"]) == 18,
        "Exact original/native selected inventories required",
    )
    require(
        hashlib.sha256(
            (LAB / "oct7-native-consumers-loaded-postflight.json").read_bytes()
        ).hexdigest()
        == PRIOR_SHA256,
        "Prior loaded postflight changed",
    )
    prior = read("oct7-native-consumers-loaded-postflight.json")
    prior_pids = prior.get("inspected_pids", [])
    require(
        prior.get("accepted") is True
        and type(prior.get("ssh_returncode")) is int
        and prior["ssh_returncode"] == 0
        and len(prior_pids) == len(set(prior_pids)) == 100
        and all(type(pid) is int and pid > 1 for pid in prior_pids),
        "Accepted exact 100-PID prior postflight required",
    )
    pids, capture_receipts = set(prior_pids), {}
    if stage == "postflight":
        for name in CAPTURES:
            collector, key, expected_root = (
                (original, "original", root)
                if "-lgpio-" in name
                else (native, "native", NATIVE_ROOT)
            )
            remote = read(name + "/remote.stdout")
            collector.validate_remote(remote, manifests[key])
            result, acquisition = (
                read(name + "/results.json"),
                read(name + "/acquisition.json"),
            )
            require(
                result.get("collection_success") is True
                and result.get("remote") == remote
                and remote.get("manifest_path") == expected_root + "/manifest.json"
                and acquisition.get("remote_root") == expected_root
                and acquisition.get("remote_python") == REMOTE_PYTHON
                and all(
                    type(row.get("remote_returncode")) is int
                    and row["remote_returncode"] == 0
                    for row in (result, acquisition)
                )
                and acquisition.get("primary_error") is None
                and acquisition.get("evidence_errors") == [],
                "Successful actual-exit0 paired capture linkage required",
            )
            pid = remote["helper_pid"]
            require(type(pid) is int and pid > 1, "Actual helper PID required")
            pids.add(pid)
            capture_receipts[name] = {
                "helper_pid": pid,
                "backend": collector.BACKEND,
                "stdout_sha256": hashlib.sha256(
                    (LAB / name / "remote.stdout").read_bytes()
                ).hexdigest(),
            }
        require(
            len({row["helper_pid"] for row in capture_receipts.values()}) == 4,
            "Distinct paired helper PIDs required",
        )
    return manifests, sorted(pids), capture_receipts


def remote_code(root, pids):
    extra = f"""
import sys, importlib.metadata
for root in ({root!r}, {NATIVE_ROOT!r}):
    assert pathlib.Path(root).is_dir() and not pathlib.Path(root).is_symlink()
    assert not pathlib.Path(root + '/manifest.json').is_symlink()
sys.path.insert(0, {root!r})
import lgpio_pwm_consumers_eval as original
spec = importlib.util.spec_from_file_location('_paired_native_consumer_state', {NATIVE_ROOT + "/native_pwm_consumers_eval.py"!r})
native = importlib.util.module_from_spec(spec)
spec.loader.exec_module(native)
gpio, lgpio = original.marker.load_libraries()
receipt['remote_manifests'] = {{'original': original.load_manifest({root + "/manifest.json"!r}), 'native': native.load_manifest({NATIVE_ROOT + "/manifest.json"!r})}}
receipt['selected_source_sha256'] = {{'original': original.source_hashes(), 'native': native.source_hashes()}}
receipt['program_paths'] = {{'original': str(pathlib.Path(original.__file__).resolve()), 'native': str(pathlib.Path(native.__file__).resolve())}}
receipt['runtime'] = {{'python_executable': sys.executable, 'python_version': sys.version, 'gpiod_version': gpio.__version__, 'lgpio_version': lgpio.get_module_version(), 'motor_version': importlib.metadata.version('adafruit-circuitpython-motor')}}
print(json.dumps(receipt, indent=2))
"""
    return REMOTE.replace("PIDS", repr(json.dumps(pids))).replace(
        "print(json.dumps(receipt, indent=2))", extra
    )


def validate_state(remote, root, manifests, pids):
    require(
        remote.get("read_only") is True
        and remote.get("no_gpio_request_or_write") is True
        and remote.get("hostname") == "test-pi5"
        and remote.get("kernel") == original.helper.baseline.KERNEL
        and remote.get("boot_id") == BOOT_ID
        and remote.get("boot_config_sha256") == BOOT_SHA,
        "Pi identity/boot/read-only gate changed",
    )
    require(
        remote.get("remote_manifests") == manifests
        and remote.get("selected_source_sha256")
        == {key: value["source_sha256"] for key, value in manifests.items()},
        "Both selected source/manifests must match",
    )
    require(
        remote.get("program_paths")
        == {
            "original": root + "/lgpio_pwm_consumers_eval.py",
            "native": NATIVE_ROOT + "/native_pwm_consumers_eval.py",
        },
        "Private helper program origins changed",
    )
    runtime = remote.get("runtime", {})
    require(
        runtime.get("python_executable") == REMOTE_PYTHON
        and isinstance(runtime.get("python_version"), str)
        and runtime.get("gpiod_version") == "2.5.0"
        and runtime.get("lgpio_version") == "lgpio.py_0.2.2.0"
        and runtime.get("motor_version") == "3.5.0",
        "Selected interpreter/library versions changed",
    )
    require(
        remote.get("pid_exists") == {str(pid): False for pid in pids},
        "Every exact inspected PID must be absent",
    )
    chip, lines = remote.get("gpiochip", {}), remote.get("lines", [])
    require(
        chip.get("name") == "gpiochip0"
        and chip.get("label") == "pinctrl-rp1"
        and chip.get("num_lines") == 54
        and len(lines) == 2
        and [row.get("offset") for row in lines] == [18, 23]
        and all(
            row.get("used") is False and row.get("consumer") in (None, "")
            for row in lines
        ),
        "Both private header pins must be unused",
    )
    pins = remote.get("pinctrl", [])
    require(
        len(pins) == 2
        and all(
            row.get("arguments") == ["pinctrl", "get", str(gpio)]
            and type(row.get("returncode")) is int
            and row["returncode"] == 0
            and "| lo" in row.get("stdout", "")
            for row, gpio in zip(pins, (18, 23))
        ),
        "Both pins must read physically low",
    )
    throttled, pwm = remote.get("throttled", {}), remote.get("pwm", {})
    require(
        type(throttled.get("returncode")) is int
        and throttled["returncode"] == 0
        and throttled.get("stdout", "").strip() == "throttled=0x0"
        and 0 <= int(remote["temperature_millic"]) < 65000,
        "Temperature/throttling gate failed",
    )
    text = pwm.get("stdout", "")
    require(
        type(pwm.get("returncode")) is int
        and pwm["returncode"] == 0
        and re.findall(r"^\d+: ([^,]+),", text, re.M) == ["platform/1f0009c000.pwm"]
        and "cooling_fan" in text
        and all(
            "cooling_fan" in line for line in text.splitlines() if "requested" in line
        )
        and "1f00098000" not in text
        and "pwm-gpio" not in text,
        "Only unchanged separate fan PWM provider permitted",
    )


def record(stage, root):
    manifests, pids, captures = inputs(stage, root)
    output = LAB / f"oct7-lgpio-consumers-paired-{stage}.json"
    stdout, stderr = Path(str(output) + ".stdout"), Path(str(output) + ".stderr")
    require(
        not any(
            path.exists() or path.is_symlink() for path in (output, stdout, stderr)
        ),
        "Exclusive fresh paired state targets required",
    )
    code = remote_code(root, pids)
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([REMOTE_PYTHON, "-c", code]),
    ]
    result, remote, error = None, None, None
    with stdout.open("xb") as out, stderr.open("xb") as err:
        try:
            result = subprocess.run(
                command, stdout=out, stderr=err, timeout=20, check=False
            )
        except BaseException as failure:
            error = f"{type(failure).__name__}: {failure}"
    try:
        require(
            error is None
            and result is not None
            and type(result.returncode) is int
            and result.returncode == 0,
            "Actual read-only SSH exit0 required",
        )
        remote = read_json(stdout.read_text())
        validate_state(remote, root, manifests, pids)
    except BaseException as failure:
        error = error or f"{type(failure).__name__}: {failure}"
    receipt = {
        "schema_version": 1,
        "stage": stage,
        "remote_root": root,
        "native_root": NATIVE_ROOT,
        "source_manifests": manifests,
        "plan_sha256": PLAN_SHA256,
        "prior_postflight_sha256": PRIOR_SHA256,
        "capture_receipts": captures,
        "inspected_pids": pids,
        "ssh_returncode": None if result is None else result.returncode,
        "accepted": error is None,
        "validation_error": error,
        "remote": remote,
        "remote_read_only_code": code,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Fixed read-only state/source/absence check, not waveform acceptance, analog failsafe, parity or actuator safety",
    }
    with output.open("x") as stream:
        json.dump(receipt, stream, indent=2, allow_nan=False)
        stream.write("\n")
    print(
        json.dumps(
            {
                "accepted": receipt["accepted"],
                "inspected_pids": len(pids),
                "validation_error": error,
            }
        )
    )
    return 0 if receipt["accepted"] else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stage", choices=("preflight", "postflight"))
    parser.add_argument("--remote-root", required=True)
    args = parser.parse_args(argv)
    return record(args.stage, args.remote_root)


if __name__ == "__main__":
    raise SystemExit(main())
