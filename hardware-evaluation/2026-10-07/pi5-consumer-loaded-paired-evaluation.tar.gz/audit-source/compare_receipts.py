"""Offline final-report receipt/source/load-proof comparison; no lab imports."""
import hashlib
import json
from pathlib import Path

ROOT=Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
FROZEN=Path('/private/tmp/paired-loaded-receipts-final.YS17ye/receipt_checks.json')
INITIAL=ROOT/'oct7-lgpio-consumers-loaded-paired-independent-audit.json'
DEST=Path('/private/tmp/paired-loaded-final-receipts.M9ejzf/comparison_receipts.json')
METHOD=Path(__file__)
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def zero(v): return type(v) is int and v==0
CHECKS=[]; COVERAGE=[]; LOAD_FACTS=[]
def check(name,value): CHECKS.append({'name':name,'passed':bool(value)})
def overlap(worker,begin,end):
    return {'begin_ns':begin,'end_ns':end,'duration_ns':end-begin,'overlap_ns':max(0,min(end,worker['end_ns'])-max(begin,worker['begin_ns'])),'bracketed':worker['begin_ns']<=begin and end<=worker['end_ns'],'start_margin_ns':begin-worker['begin_ns'],'end_margin_ns':worker['end_ns']-end}
frozen=read(FROZEN); initial=read(INITIAL); plan=read(ROOT/'oct7-lgpio-consumers-loaded-plan.json')
check('immutable initial audit exact SHA256',sha(INITIAL)=='53dbeff251145601f291dc8cb076ae2da827fd27e17df66975a7652daaf0ac1b')
check('immutable receipt check exact SHA256',sha(FROZEN)=='9aad2bc8535d7cd0f2743ceba001ab4b96df86639be4d7813a9f9e7893c88313')
check('immutable receipt method exact SHA256',sha(Path(frozen['method_source_path']))==frozen['method_source_sha256']=='dfd3338643080f7835f98fc8e63b9190bd970c79aeee949df89678a3580e9b24')
check('initial audit embeds exact frozen independent receipt check',initial['additional_independent_receipt_checks']==frozen and initial['additional_receipt_check_file_sha256']==sha(FROZEN))
check('frozen2156checks successful',frozen['passed'] is True and frozen['check_count']==2156 and frozen['failures']==[])
for run in frozen['runs']:
    name=run['name']; p=ROOT/name; original='lgpio-consumers' in name
    filename='analysis.json' if original else 'consumer-analysis.json'; report=read(p/filename)
    remote=read(p/'remote.stdout'); results=read(p/'results.json'); acq=read(p/'acquisition.json'); manifest=read(p/'manifest.json'); coordination=read(ROOT/(name+'.consumers-coordination.json'))
    check(name+' raw remote unchanged',remote==run['remote_receipt_raw_unmapped_to_saleae']==results['remote'])
    check(name+' raw coordinator unchanged',coordination==run['coordination_receipt_corroboration'])
    for rel,value in run['raw_file_sha256_and_sizes'].items():
        path=ROOT/rel
        check(name+' frozen raw file bytes '+rel,sha(path)==value['sha256'] and path.stat().st_size==value['size_bytes'])
    check(name+' final report identity',report['capture']==name and report['backend']==run['backend'])
    for filename_raw in ['results.json','acquisition.json','remote.stdout','remote.stderr','manifest.json']:
        check(name+' report evidence receipt hash '+filename_raw,report['evidence_sha256'][filename_raw]==sha(p/filename_raw))
    check(name+' raw actual typed consumer SSH exit chain',zero(results['remote_returncode']) and zero(acq['remote_returncode']) and zero(coordination['consumer_remote_returncode']))
    check(name+' raw actual typed load SSH exit',zero(coordination['load_helper_returncode']))
    load_bytes=(ROOT/(name+'.load.stdout')).read_bytes(); lines=load_bytes.splitlines(keepends=True)
    check(name+' unchanged exact2loadreceipt framing',len(lines)==2 and all(s.endswith(b'\n') for s in lines))
    launch,completion=[json.loads(s) for s in lines]
    check(name+' unchanged complete raw load records',[launch,completion]==run['raw_load_receipts'])
    check(name+' unchanged raw load/worker source hashes',all(o['source_sha256']==plan['load_source_sha256'] and o['worker_source_sha256']==plan['worker_source_sha256'] for o in [launch,completion]))
    load_rows=[]
    for w,cw in zip(run['independently_reconstructed_actual_workers'],completion['owned_workers']):
        label=name+' worker'+str(w['index']); started,done=[json.loads(s) for s in cw['stdout'].splitlines()]
        check(label+' raw worker reparse consistent',started==cw['worker_receipts'][0] and done==cw['worker_receipts'][1] and started['pid']==done['pid']==w['pid'] and started['begin_ns']==done['begin_ns']==w['begin_ns'] and done['end_ns']==w['end_ns'] and done['iterations']==w['iterations'])
        check(label+' typed actual process exit',zero(cw['returncode']) and zero(w['returncode']) and cw['reaped'] is w['reaped'] is True)
        helper=overlap(w,remote['begin_ns'],remote['end_ns']); phases=[{'name':phase['name'],**overlap(w,phase['begin_ns'],phase['readback_end_ns'])} for phase in remote['phases']]
        check(label+' independently recomputed full helper proof',helper==w['entire_helper_overlap'] and helper['bracketed'])
        check(label+' independently recomputed all15phase proof',phases==w['phase_overlaps'] and len(phases)==15 and all(s['bracketed'] for s in phases))
        load_rows.append({'index':w['index'],'pid':w['pid'],'actual_begin_ns':w['begin_ns'],'actual_end_ns':w['end_ns'],'iterations':w['iterations'],'actual_worker_process_exit':w['returncode'],'whole_helper_overlap':helper,'all15phase_readback_overlap':phases})
    check(name+' load margins remain exact',run['whole_helper_min_start_margin_ns']==min(w['entire_helper_overlap']['start_margin_ns'] for w in run['independently_reconstructed_actual_workers']) and run['whole_helper_min_end_margin_ns']==min(w['entire_helper_overlap']['end_margin_ns'] for w in run['independently_reconstructed_actual_workers']))
    LOAD_FACTS.append({'name':name,'basis':'Raw .load.stdout worker stdout and consumer remote.stdout, independently frozen before final reports; not provided by final report fields','actual_exit_labels':run['actual_exit_labels'],'workers':load_rows})
    initial_receipts=initial['runs'][name]['offline_receipt_source_ownership_checks']
    check(name+' initial frozen manifest exact',initial_receipts['selected_frozen_manifest']==manifest)
    check(name+' initial receipts full ownership/actions/phases/events/shutdown',initial_receipts['outputs_ownership_and_cleanup']==remote['outputs'] and initial_receipts['recorded_actions_unmapped_to_saleae']==remote['actions'] and initial_receipts['recorded_phase_data_unmapped_to_saleae']==remote['phases'] and initial_receipts['recorded_events_on_pi_clock_not_latency']==remote['events'] and initial_receipts['shutdowns']==remote['shutdowns'])
    if original:
        fr=report['functional_receipts']
        check(name+' report exact21 selected source hashes',fr['selected_source_sha256']==manifest['source_sha256']==remote['source_sha256'] and len(fr['selected_source_sha256'])==21)
        check(name+' report actual typed consumer SSH exit',zero(fr['actual_ssh_returncode']) and fr['actual_ssh_returncode']==results['remote_returncode']==acq['remote_returncode']==coordination['consumer_remote_returncode'])
        for k in ['remote_root','remote_python','remote_program']: check(name+' report runtime path '+k,fr[k]==results[k]==acq[k])
        check(name+' original exact percent nominal table',report['original_percent_nominals']==results['original_percent_nominals']==plan['original_percent_nominals'])
        check(name+' original loaded plan identity',report['frozen_plan']['path']==str(ROOT/'oct7-lgpio-consumers-loaded-plan.json') and report['frozen_plan']['sha256']==sha(ROOT/'oct7-lgpio-consumers-loaded-plan.json')==initial['frozen_plan_sha256'])
        check(name+' delegated receipt method explicit',fr['receipt_validation']=='delegated to capture_lgpio_pwm_consumers.validate_remote / helper.validate_receipt' and 'not electrical facts' in fr['scope'])
        check(name+' original limited scope assertions',all(any(text in line for line in report['limitations']) for text in ['not waveform acceptance','clocks are unaligned','not deadtime','deinit alone does not cancel/free GPIO','not installed Blinka or actual actuator proof']))
        coverage={'name':name,'report_filename':filename,'report_sha256':sha(p/filename),'selected_source_count':21,'consumer_ssh_exit_field':'functional_receipts.actual_ssh_returncode','embedded_receipt_blocks':[],'basis_distinctions':['Original consumer/API/private-handle-generation/cleanup validation is delegated, not embedded as raw arrays.','Report frozen_plan points to the loaded plan, but load sidecars and actual-worker overlap are not exposed/hashed in this report.','Original private request wording is generic; actual ownership is lgpio chip handle/GPIO/generation, not native gpiod request.'],'omitted_facts':['78 nested events and15phases/10actions/3owner generations','runtime flags/inherited environment','shim/library-hook restoration and private chip closure','actual load SSH/worker process exits','load/worker source hashes and raw stdout','worker PIDs/actual intervals/full-helper and all15phase margins','local coordinator CLI exit','dynamic cooling-fan observation and stderr diagnostic text']}
    else:
        vr=report['validated_receipt_consumer_api_and_ownership_not_electrical_phase_identity']
        check(name+' exact18 full report manifest',report['source_manifest']==manifest and len(report['source_manifest']['source_sha256'])==18)
        check(name+' six expected native receipt blocks',set(vr)=={'consumers','integration_shim','outputs','shutdowns','phases','actions'})
        for k,value in vr.items(): check(name+' exact embedded raw block '+k,value==remote[k])
        events=report['caller_events_pi_clock']; check(name+' exact41 native caller events',len(events)==41 and [{k:v for k,v in e.items() if k!='caller_duration_us'} for e in events]==remote['events'])
        for e in events: check(name+' derived Pi caller duration '+str(e['ordinal']),e['caller_duration_us']==(e['end_ns']-e['begin_ns'])/1000)
        targets={'servo_angle0':(50,3276),'servo_angle90':(50,4914),'servo_angle180':(50,6553),'motor_half':(1000,32767)}
        for key,(hz,duty) in targets.items():
            period_ns=round(1e9/hz); high_ns=round(period_ns*duty/65535)
            check(name+' independent C-rounded nominal '+key,report['actual_consumer_u16_c_rounded_nominals'][key]=={'frequency_hz':hz,'duty_u16':duty,'period_us':period_ns/1000,'high_us':high_ns/1000})
        check(name+' ideal-minus-u16 C-rounded nominal deltas',report['common_requested_servo_high_us_minus_actual_c_rounded_us']=={k:v-report['actual_consumer_u16_c_rounded_nominals'][k]['high_us'] for k,v in {'servo_angle0':1000,'servo_angle90':1500,'servo_angle180':2000}.items()})
        check(name+' unchanged native protocol plan basis',report['plan_sha256']==plan['native_reference']['unchanged_protocol_plan_sha256']==sha(ROOT/'oct7-native-consumers-plan.json'))
        expected={'collection_receipts_validated':True,'functional_consumer_integration_only':True,'passive_probes_only':True,'actual_actuator_operation_established':False,'installed_blinka_compatibility_proven':False,'waveform_accepted':None,'parity_pass':None,'matched_performance_parity':False,'pi_saleae_clocks_aligned':False,'application_latency_measured':False,'timebase_gpio_driver_and_threshold_skew_calibrated':False}
        for k,v in expected.items(): check(name+' native limited scope '+k,report[k]==v)
        coverage={'name':name,'report_filename':filename,'report_sha256':sha(p/filename),'selected_source_count':18,'consumer_ssh_exit_field':None,'embedded_receipt_blocks':list(vr),'caller_event_count':len(events),'basis_distinctions':['Native report uses the unchanged native consumer protocol plan97bb31a…af0d2, not the paired-loaded coordination plan1cedb74…694b; this is expected basis, not a mismatch.','collection_receipts_validated=true is not an exposed actual SSH exit field.','Six receipt blocks and41 Pi-clock events exactly match raw data; worker/load proof is separate and not exposed/hashed in final report.'],'omitted_facts':['actual consumer/load SSH exits and worker process exits','runtime flags/inherited environment','helper begin/end/global read-only chip closure/error/signal state','load/worker source hashes and raw stdout','worker PIDs/actual intervals/full-helper and all15phase margins','local coordinator CLI exit','dynamic cooling-fan observation and stderr diagnostic text']}
    expected_sidecars=[name+'.load.stdout',name+'.load.stderr',name+'.consumers-coordination.json']
    check(name+' coverage observation load sidecars not exposed',not any(k in report['evidence_sha256'] for k in expected_sidecars) and not any(k in report for k in ['load','workers','load_overlap','load_stdout','load_helper_returncode']))
    coverage['loaded_proof_in_report']=False; coverage['loaded_proof_basis']='frozen2156check receipt audit + raw .load.stdout/.consumers-coordination.json/remote.stdout, not final waveform report'
    COVERAGE.append(coverage)
for stage in frozen['pre_postflight']:
    p=ROOT/f"oct7-lgpio-consumers-loaded-paired-{stage['stage']}.json"
    check(stage['stage']+' unchanged source/PID/free-line/load snapshot',sha(p)==stage['sha256'] and read(p)==stage['raw_state'])
check('16 new PID identity unchanged',len(set(frozen['distinct_new_pi_pids']))==16)
check('recorded fan observation retained without fixed-duty assertion',frozen['observed_kernel_cooling_fan_state']['fan_state_bytes_changed'] is True and frozen['observed_kernel_cooling_fan_state']['preflight_temperature_millic']=='46850' and frozen['observed_kernel_cooling_fan_state']['postflight_temperature_millic']=='52350')
OUT={'schema_version':1,'purpose':'Independent final loaded-report source/receipts/typed exit/load-overlap comparison; waveform arrays/topology are owned by parent and not evaluated here','method_source_path':str(METHOD),'method_source_sha256':sha(METHOD),'frozen_receipt_checks_path':str(FROZEN),'frozen_receipt_checks_sha256':sha(FROZEN),'initial_immutable_audit_path':str(INITIAL),'initial_immutable_audit_sha256':sha(INITIAL),'passed':all(c['passed'] for c in CHECKS),'check_count':len(CHECKS),'mismatches':[c for c in CHECKS if not c['passed']],'checks':CHECKS,'report_coverage':COVERAGE,'separate_unchanged_actual_worker_proof':LOAD_FACTS,'retained_fan_observation':frozen['observed_kernel_cooling_fan_state'],'limitations':['Report omissions are coverage/basis distinctions, not false raw mismatches.','Neither report family independently supplies loaded worker proof; proof remains in frozen raw receipts and audit.','Actual worker intervals do not prove CPU saturation or continuous residency.','Recorded consumer/load SSH and worker process exits are not local collector/coordinator CLI exits.','No analyzer source, hardware/network/SSH/Saleae or existing artifact writes used.']}
DEST.write_text(json.dumps(OUT,indent=2)+'\n')
print(json.dumps({'output':str(DEST),'output_sha256':sha(DEST),'method':str(METHOD),'method_sha256':sha(METHOD),'passed':OUT['passed'],'check_count':len(CHECKS),'mismatches':OUT['mismatches'],'coverage':COVERAGE},indent=2))
