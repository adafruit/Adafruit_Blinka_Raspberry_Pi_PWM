"""Independent offline loaded receipts/ownership audit. No lab modules imported."""
import ast
import hashlib
import json
import math
import re
from pathlib import Path

ROOT=Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
DEST=Path('/private/tmp/paired-loaded-receipts-final.YS17ye/receipt_checks.json')
METHOD=Path(__file__)
NAMES=['oct7-pi5-lgpio-consumers-loaded-r1','oct7-pi5-paired-native-consumers-loaded-r1','oct7-pi5-paired-native-consumers-loaded-r2','oct7-pi5-lgpio-consumers-loaded-r2']
SEQUENCE=[('servo_initial_low',.1,'servo_initialize',None),('servo_angle0',.4,'Servo.angle',0),('servo_angle90',.4,'Servo.angle',90),('servo_angle180',.4,'Servo.angle',180),('servo_disable',.15,'Servo.angle',None),('servo_release',.15,'servo_release',None),('motor_initial_low',.1,'motor_initialize',None),('motor_brake',.2,'DCMotor.throttle',0),('motor_forward_half',.35,'DCMotor.throttle',.5),('motor_forward_full',.2,'DCMotor.throttle',1),('motor_reverse_half',.35,'DCMotor.throttle',-.5),('motor_reverse_full',.2,'DCMotor.throttle',-1),('motor_disable',.15,'DCMotor.throttle',None),('motor_release_positive',.15,'motor_release_positive',None),('motor_release_negative',.15,'motor_release_negative',None)]
OWNERS=[('servo18-g1',18,1,50),('motor18-g2',18,2,1000),('motor23-g1',23,1,1000)]
DUTIES=[[0],[3276],[4914],[6553],[0],[],[0,0],[65535,65535],[32767,0],[65535,0],[0,32767],[0,65535],[0,0],[0],[]]
ACTIONS=[1,2,3,4,7,8,9,10,11,12]
CHECKS=[]; RUNS=[]
def pairs(rows):
    d={}
    for k,v in rows:
        if k in d: raise ValueError('Duplicate JSON key: '+k)
        d[k]=v
    return d
def parse(text): return json.loads(text,object_pairs_hook=pairs)
def read(p): return parse(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check(name,passed): CHECKS.append({'name':name,'passed':bool(passed)})
def zero(v): return type(v) is int and v==0
def same_number(a,b): return a is None if b is None else type(a) in (int,float) and math.isclose(a,b,rel_tol=0,abs_tol=1e-9)
def bounded(row,lo,hi): return type(row['begin_ns']) is int and type(row['end_ns']) is int and lo<=row['begin_ns']<=row['end_ns']<=hi
def expected_state(i):
    specs=OWNERS[:1] if i<=4 else OWNERS[1:] if 6<=i<=12 else OWNERS[2:] if i==13 else []
    return [(oid,gpio,generation,hz,duty) for (oid,gpio,generation,hz),duty in zip(specs,DUTIES[i])]
def angle(i): return {1:0,2:180*(4914-3276)/(6553-3276),3:180,4:None}.get(i)
def expected_consumer(i):
    if i<=4: return {'kind':'Servo','angle':angle(i)}
    if 6<=i<=12: return {'kind':'DCMotor','throttle':None if i==6 else SEQUENCE[i][3],'decay_mode':0}
    return None
def consumer_matches(a,b):
    if b is None: return a is None
    return a.keys()==b.keys() and all(same_number(a[k],v) if v is None or type(v) in (int,float) else a[k]==v for k,v in b.items())
def states(label,rows,i,r,original):
    check(label+' exact API tuples',[(s['output_id'],s['gpio'],s['generation'],s['frequency'],s['duty_u16']) for s in rows]==expected_state(i))
    owners={s['output_id']:s for s in r['outputs']}
    for s in rows:
        k='ownership' if original else 'owned_request'
        check(label+' stable private identity '+s['output_id'],s[k]==owners[s['output_id']][k])
        if original:
            pc=round(s['duty_u16']/65535*100)
            check(label+' original submission '+s['output_id'],s['enabled'] is True and s['submitted_duty_percent']==pc and s['submitted_nominal_high_us']==1e6/s['frequency']*pc/100)
    if not original: check(label+' active distinct FDs',len({s['owned_request']['fd'] for s in rows})==len(rows))
def interval(worker,begin,end):
    return {'begin_ns':begin,'end_ns':end,'duration_ns':end-begin,'overlap_ns':max(0,min(end,worker['end_ns'])-max(begin,worker['begin_ns'])),'bracketed':worker['begin_ns']<=begin and end<=worker['end_ns'],'start_margin_ns':begin-worker['begin_ns'],'end_margin_ns':worker['end_ns']-end}

plan_path=ROOT/'oct7-lgpio-consumers-loaded-plan.json'; plan=read(plan_path)
check('frozen loaded plan SHA256',sha(plan_path)=='1cedb74c5e1ff8531fe7b34d3e8da3aa37643ebc28a1341562db9468a512694b')
check('frozen capture order',plan['capture_order']==NAMES)
check('frozen 15-phase declaration',[(s['name'],s['duration_seconds'],s['operation'],s['value']) for s in plan['sequence']]==SEQUENCE)
check('bounded load scope',plan['load']=={'owned_worker_count':2,'duration_seconds':10,'workload':'sum(range(10000))','independently_expiring':True,'required_overlap':'each actual worker brackets entire helper and all 15 phases','cpu_saturation_proven':False,'priority_affinity_governor_changed':False})
manifests={'original':read(ROOT/'oct7-lgpio-consumers-manifest.json'),'native':read(ROOT/'oct7-native-consumers-manifest.json')}
for key,count in [('original',21),('native',18)]:
    m=manifests[key]
    check(key+' selected source inventory',len(m['source_sha256'])==count and all(re.fullmatch('[0-9a-f]{64}',v) for v in m['source_sha256'].values()) and m['motor_version']=='3.5.0' and m['selected_sources_not_whole_system_attestation'] is True)
    check(key+' exact manifest bytes pinned',sha(ROOT/('oct7-lgpio-consumers-manifest.json' if key=='original' else 'oct7-native-consumers-manifest.json'))==plan['manifest_sha256' if key=='original' else 'native_manifest_sha256'])
    for source,value in m['source_sha256'].items():
        path=ROOT/source
        if path.is_file(): check(key+' local frozen source '+source,sha(path)==value)
for source in ['adafruit_motor/__init__.py','adafruit_motor/servo.py','adafruit_motor/motor.py']:
    check('identical genuine motor3.5.0 hash '+source,manifests['original']['source_sha256'][source]==manifests['native']['source_sha256'][source])
for key,sources in plan['loaded_coordinator_source_sha256'].items():
    for source,value in sources.items():
        path=ROOT/source
        if path.is_file() and not source.startswith(('analyze_','test_analyze_')): check(key+' local non-analyzer coordinator dependency '+source,sha(path)==value)
for source,value in [('record_lgpio_consumers_loaded_paired_state.py',plan['state_recorder_sha256']),('kernel_pwm_cpu_load_eval.py',plan['load_source_sha256']),('capture_lgpio_pwm_consumers_loaded.py',plan['loaded_coordinators_sha256']['original']),('capture_native_pwm_consumers_loaded.py',plan['loaded_coordinators_sha256']['native'])]: check('frozen preparation source '+source,sha(ROOT/source)==value)
tree=ast.parse((ROOT/'kernel_pwm_cpu_load_eval.py').read_text()); f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_worker_source'); parts=[]
for n in f.body[0].value.values:
    if isinstance(n,ast.Constant): parts.append(n.value)
    elif isinstance(n,ast.FormattedValue) and isinstance(n.value,ast.Name) and n.value.id=='WORKER_SECONDS' and n.conversion==114: parts.append(repr(10))
    else: raise ValueError('Unexpected worker-source syntax')
check('worker string reconstructed without importing load module',hashlib.sha256(''.join(parts).encode('ascii')).hexdigest()==plan['worker_source_sha256'])

for name in NAMES:
    p=ROOT/name; original='lgpio-consumers' in name; key='original' if original else 'native'; m=manifests[key]
    metadata=read(p/'results.json'); acq=read(p/'acquisition.json'); r=read(p/'remote.stdout'); saved=read(p/'manifest.json'); co_path=ROOT/(name+'.consumers-coordination.json'); co=read(co_path)
    files=[p/f for f in ['results.json','acquisition.json','remote.stdout','remote.stderr','manifest.json']]+[co_path,ROOT/(name+'.load.stdout'),ROOT/(name+'.load.stderr')]
    for fp in files: check(name+' regular nonsymlink file '+fp.name,fp.is_file() and not fp.is_symlink())
    check(name+' raw/result/source equality',metadata['remote']==r and saved==m and r['source_sha256']==m['source_sha256'])
    check(name+' actual typed consumer SSH exits',zero(metadata['remote_returncode']) and zero(acq['remote_returncode']) and zero(co['consumer_remote_returncode']))
    check(name+' clean acquisition',acq['primary_error'] is None and acq['evidence_errors']==[] and acq.get('ssh_exit_unavailable_after_exception',False) is False and acq['local_timing_not_aligned_to_pi_or_saleae'] is True)
    check(name+' collection not waveform acceptance',metadata['collection_success'] is True and metadata['waveform_accepted'] is None and metadata['parity_pass'] is None and metadata['parity_evaluated'] is False and metadata['analysis_deferred'] is True)
    check(name+' passive acquisition metadata',metadata['sample_rate_hz']==100000000 and [(s['gpio'],s['saleae_channel']) for s in metadata['outputs']]==[(18,0),(23,1)] and (not original or (acq['requested_channels']==[0,1] and acq['requested_sample_rate_hz']==100000000 and acq['requested_glitch_filters']==[])))
    check(name+' helper normal success',r['success'] is True and r['completed_normally'] is True and r['primary_error'] is None and r['cleanup_errors']==[] and r['signals_received']==[])
    check(name+' flags/environment/variable-frequency',r['runtime_flags']=={'short_slice':False,'shared':False} and r['inherited_environment']=={'BLINKA_PWM_SHORT_SLICE':None,'BLINKA_PWM_SHARED':None} and r['variable_frequency'] is (not original))
    check(name+' helper limitations',r['actual_actuators_attached'] is False and r['installed_blinka_compatibility_proven'] is False and r['production_backend_unchanged'] is True and r['api_readbacks_are_not_electrical'] is True and r['parity_pass'] is None and r['passive_probes_only'] is True)
    check(name+' restored unwrapped in-memory shim',r['integration_shim']=={'kind':'in-memory-pwmio-export','unwrapped_public_pwm_objects':True,'installed_blinka_compatibility_proven':False,'installed_pwmio_module_used':False,'restored':True})
    check(name+' RP1 same-Pi identity',r['identity']['boot_id']=='71305dc8-e9a8-49b1-a623-678032cbd3f5' and r['identity']['gpiochip']=='/dev/gpiochip0' and r['identity']['label']=='pinctrl-rp1')
    check(name+' genuine consumer configuration',r['motor_version']=='3.5.0' and r['consumers']['version']=='3.5.0' and r['consumers']['distribution']=='adafruit-circuitpython-motor' and r['consumers']['servo']=={'actuation_range':180,'min_pulse_us':1000,'max_pulse_us':2000} and r['consumers']['motor']=={'decay_mode':0,'throttle_zero_is_both_high_brake':True})
    check(name+' free preclaim pins',[(s['gpio'],s['line_info']['used'],s['line_info']['consumer']) for s in r['preclaim_lines']]==[(18,False,None),(23,False,None)])
    check(name+' thermal snapshots',r['before']['throttled']==r['after']['throttled']=='throttled=0x0' and int(r['before']['temperature_millic'])<65000 and int(r['after']['temperature_millic'])<70000)
    check(name+' fixed waits/watchdog',r['sequence_dwell_seconds']==3.45 and r['normal_fixed_wait_seconds']==3.75 and r['low_settle_seconds']==.1 and r['watchdog_seconds']==14 and r['end_ns']-r['begin_ns']<14e9)
    check(name+' exact phase/action/owner counts',len(r['phases'])==15 and [s['phase_index'] for s in r['actions']]==ACTIONS and [(s['output_id'],s['gpio'],s['generation'],s['initial_frequency']) for s in r['outputs']]==OWNERS)
    phase_timings=[]
    for i,(phase,spec) in enumerate(zip(r['phases'],SEQUENCE)):
        check(name+f' phase{i} declaration',(phase['index'],phase['name'],phase['duration_seconds'],phase['operation'],phase['value'],phase['scope'])==(i,*spec,f'{i:02d}_{spec[0]}'))
        check(name+f' phase{i} own-Pi chronology',r['begin_ns']<=phase['begin_ns']<=phase['stable_begin_ns']<=phase['end_ns']<=phase['readback_end_ns']<=r['end_ns'] and (i==0 or r['phases'][i-1]['readback_end_ns']<=phase['begin_ns']))
        check(name+f' phase{i} full fixed dwell',phase['end_ns']-phase['stable_begin_ns']>=round(spec[1]*1e9))
        states(name+f' phase{i} begin',phase['api_state'],i,r,original); states(name+f' phase{i} end',phase['api_state_end'],i,r,original)
        check(name+f' phase{i} consumer readbacks',consumer_matches(phase['consumer_state'],expected_consumer(i)) and consumer_matches(phase['consumer_state_end'],expected_consumer(i)))
        phase_timings.append({'index':i,'name':spec[0],'stable_dwell_excess_ns':phase['end_ns']-phase['stable_begin_ns']-round(spec[1]*1e9),'post_dwell_readback_ns':phase['readback_end_ns']-phase['end_ns']})
    for action in r['actions']:
        i=action['phase_index']; phase=r['phases'][i]
        check(name+f' action{i} declaration/chronology',action['status']=='ok' and (action['operation'],action['value'])==SEQUENCE[i][2:] and bounded(action,phase['begin_ns'],phase['stable_begin_ns']))
        states(name+f' action{i} before',action['api_state_before'],i-1,r,original); states(name+f' action{i} after',action['api_state_after'],i,r,original)
        check(name+f' action{i} consumer readback',same_number(action['consumer_readback'],angle(i) if i<5 else SEQUENCE[i][3]))
    for o in r['outputs']:
        check(name+' clean independent owner '+o['output_id'],all(o[k] is True for k in ['fresh_claim_accepted','initial_low_confirmed','low_confirmed','released']) and o['variable_frequency'] is (not original) and zero(o['initial_readback']['gpio_level']) and zero(o['cleanup_final_readback']['gpio_level']) and o['released_line_info']['used'] is False and o['released_line_info']['consumer'] is None)
        if original: check(name+' original handle/generation/free '+o['output_id'],o['ownership']=={'private_chip_handle':r['private_chip_handle'],'gpio':o['gpio'],'generation':o['generation']} and o['freed'] is True and zero(o['cleanup_final_readback']['tx_busy']) and o['preclaim_mode']==o['released_mode']==2)
        else: check(name+' native private request '+o['output_id'],o['owned_request']['chip_name']=='gpiochip0' and o['owned_request']['offsets']==[o['gpio']] and type(o['owned_request']['fd']) is int and o['owned_request']['fd']>=0 and o['read_only_chip_closed'] is True and o['cleanup_final_readback']['inactive'] is True)
    check(name+' three successful shutdowns',len(r['shutdowns'])==3 and all(s['success'] is True and s['errors']==[] and s['reason']=='sequence' for s in r['shutdowns']))
    for shutdown,i in zip(r['shutdowns'],[5,13,14]): check(name+f' shutdown{i} within phase',shutdown['scope']==r['phases'][i]['scope'] and bounded(shutdown,r['phases'][i]['begin_ns'],r['phases'][i]['stable_begin_ns']))
    sb=r['shutdowns'][1]; check(name+' continuing negative sibling preserved low',sb['sibling_id']=='motor23-g1' and sb['sibling_before']==sb['sibling_after'] and zero(sb['sibling_before']['gpio_level']) and sb['sibling_before']['frequency']==1000 and sb['sibling_before']['duty_u16']==0)
    check(name+' release before GPIO18 generation2',r['shutdowns'][0]['end_ns']<=r['phases'][6]['begin_ns'])
    events=r['events']; nested=0
    check(name+' complete successful event count',len(events)==(78 if original else 41) and all(e['status']=='ok' and bounded(e,r['begin_ns'],r['end_ns']) for e in events))
    scopes={phase['scope']:phase for phase in r['phases']}
    for e in events:
        if e['scope'] in scopes: check(name+' event scoped bound '+str(e.get('event_id',e.get('ordinal'))),bounded(e,scopes[e['scope']]['begin_ns'],scopes[e['scope']]['stable_begin_ns']))
    if original:
        by_id={e['event_id']:e for e in events}
        check(name+' nested IDs/completion ordering',set(by_id)==set(range(78)) and [e['end_ns'] for e in events]==sorted(e['end_ns'] for e in events) and [e['event_id'] for e in sorted(events,key=lambda s:s['begin_ns'])]==list(range(78)))
        for e in events:
            if e['parent_event_id'] is not None:
                nested+=1; pe=by_id[e['parent_event_id']]
                check(name+' nested containment '+str(e['event_id']),pe['event_id']<e['event_id'] and bounded(e,pe['begin_ns'],pe['end_ns']) and pe['scope']==e['scope'])
        tops=[e for e in events if e['parent_event_id'] is None]; check(name+' top-level serial',all(a['end_ns']<=b['begin_ns'] for a,b in zip(tops,tops[1:])))
        check(name+' original public/lab capabilities distinct',r['chip_closed'] is True and r['library_hooks_restored'] is True and r['native_backend_executed'] is False and r['public_deinit_cancels_or_frees_gpio'] is False and r['additional_lab_cleanup_required'] is True and r['library_hooks_are_ownership_enforcement_only'] is True)
        tx=[{'scope':e['scope'],'output_id':e['output_id'],'frequency':e['arguments']['args'][0],'percent':e['arguments']['args'][1]} for e in events if e['operation']=='tx_pwm']; expected_tx=[]
        for i in [0,1,2,3,4,6,7,8,9,10,11,12]:
            expected_tx.extend({'scope':r['phases'][i]['scope'],'output_id':oid,'frequency':hz,'percent':round(duty/65535*100)} for oid,gpio,generation,hz,duty in expected_state(i))
        check(name+' exact19 original submissions',tx==expected_tx)
        check(name+' exact original metadata targets',metadata['source_manifest']==m and metadata['original_percent_nominals']==plan['original_percent_nominals'] and metadata['helper_sha256']==plan['helper_sha256'])
        for e in events:
            if e['operation'] in ['tx_pwm','gpio_claim_output']: check(name+' private hooked call '+str(e['event_id']),e['arguments']['private_handle']==r['private_chip_handle'] and e['arguments']['gpio']==next(o['gpio'] for o in r['outputs'] if o['output_id']==e['output_id']))
        cleanup_ops=['lab.cancel_tx_pwm','lab.drive_low','lab.low_settle','lab.gpio_read_low','lab.tx_busy','original_PWMOut.deinit','lab.gpio_free','gpio_get_mode_released','read_only_line_released']
    else:
        check(name+' serial native caller events',[e['ordinal'] for e in events]==list(range(41)) and all(a['end_ns']<=b['begin_ns'] for a,b in zip(events,events[1:])))
        check(name+' native global read-only chip closed',r['read_only_chip_closed'] is True)
        cleanup_ops=['track_owned_request','PWMOut.duty_cycle_zero','low_settle','owned_request.get_value','PWMOut.deinit','gpiod_line_info_released']; tx=None
    for o,i in zip(r['outputs'],[5,13,14]):
        oe=[e for e in events if e['output_id']==o['output_id'] and e['scope']==r['phases'][i]['scope']]
        check(name+' exact cleanup operation order '+o['output_id'],[e['operation'] for e in oe]==cleanup_ops)
        settle=next(e for e in oe if e['operation']==('lab.low_settle' if original else 'low_settle'))
        check(name+' actual cleanup settle '+o['output_id'],settle['end_ns']-settle['begin_ns']>=1e8)
        if original: check(name+' successful original lab results '+o['output_id'],all(zero(e['result']) for e in oe if e['operation'] in ['lab.cancel_tx_pwm','lab.drive_low','lab.gpio_read_low','lab.tx_busy','lab.gpio_free']))
    stderr=(p/'remote.stderr').read_text(); diag=[]
    for line in stderr.splitlines():
        match=re.fullmatch(r'I1007 \d\d:\d\d:\d\d\.\d+\s+(\d+) ev_poll_posix\.cc:587\] FD from fork parent still in poll list: fd\((\d+), generation: (\d+)\)',line)
        check(name+' preserved local gRPC diagnostic format '+str(len(diag)),match is not None)
        if match: diag.append({'pid':int(match[1]),'fd':int(match[2]),'generation':int(match[3])})
    check(name+' diagnostics distinct from Pi helper',bool(diag) and all(s['pid']!=r['helper_pid'] for s in diag))

    root=plan['remote_root'] if original else plan['native_reference']['remote_root']; program=root+'/'+('lgpio_pwm_consumers_eval.py' if original else 'native_pwm_consumers_eval.py')
    check(name+' exact consumer SSH program/interpreter',acq['remote_command']==['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','pi@test-pi5.local',plan['remote_python']+' '+program+' --manifest '+root+'/manifest.json'] and r['manifest_path']==root+'/manifest.json' and (not original or r['python_executable']==plan['remote_python']))
    check(name+' coordinator frozen source chain',co['source_sha256']==plan['loaded_coordinator_source_sha256'][key] and co['consumer_source_manifest']==m and co['manifest_sha256']==plan['manifest_sha256' if original else 'native_manifest_sha256'])
    check(name+' coordinator root/stem/interpreter',co['stem']==name and co['consumer_root']==root and co['remote_python']==plan['remote_python'] and co['bench_root']==plan['bench_root'])
    check(name+' clean coordinator without accepting waveform',all(co[s] is True for s in ['coordination_success','launch_validated','collector_returned_normally','collector_collection_success','load_recorder_returned_normally','launch_is_not_actual_worker_start_proof']) and co['launch_validation_errors']==[] and all(co[s] is None for s in ['capture_error','capture_evidence_error','load_recorder_error','audit_error','waveform_accepted','parity_pass']) and co['actual_actuators_attached'] is False and co['installed_blinka_compatibility_proven'] is False and co['local_timing_not_aligned_to_pi_or_saleae'] is True)
    check(name+' collector is in-process not CLI exit',co['collector_invocation']=='in-process frozen '+('capture_lgpio_pwm_consumers' if original else 'capture_native_pwm_consumers')+'.capture_test')
    check(name+' actual typed load SSH exit',zero(co['load_helper_returncode']))
    load_path=ROOT/(name+'.load.stdout'); load_bytes=load_path.read_bytes(); lines=load_bytes.splitlines(keepends=True)
    check(name+' exactly two complete load stdout lines',len(lines)==2 and all(s.endswith(b'\n') for s in lines)); launch,completion=[parse(s.decode()) for s in lines]
    common={'schema_version':1,'mode':'cpu-only-fixed-two-workers','worker_count':2,'worker_duration_seconds':10,'source_sha256':plan['load_source_sha256'],'worker_source_sha256':plan['worker_source_sha256'],'gpio_writes':False,'pwm_sysfs_access':False,'kernel_configuration_changes':False}
    check(name+' load outer fixed source/workload',all(type(outer.get(k)) is type(v) and outer[k]==v for outer in [launch,completion] for k,v in common.items()))
    check(name+' launch/completion identity and success',launch['event']=='load_launched' and launch['launch_complete'] is True and launch['started_worker_count']==2 and completion['event']=='load_completed' and launch['launcher_pid']==completion['launcher_pid'] and launch['begin_ns']==completion['begin_ns'] and completion['success'] is True and completion['signals_received']==[] and completion['cleanup_errors']==[] and completion['primary_error'] is None)
    check(name+' persisted launch exact prefix',co['launch_receipt']==launch and co['persisted_launch_sha256']==hashlib.sha256(lines[0]).hexdigest())
    check(name+' outer launch chronology',launch['begin_ns']<=launch['receipt_ns']<=completion['end_ns'])
    check(name+' two real worker records',len(launch['owned_workers'])==len(completion['owned_workers'])==2)
    workers=[]
    for j,(lw,cw) in enumerate(zip(launch['owned_workers'],completion['owned_workers'])):
        lab=name+f' worker{j}'
        check(lab+' launch only is not start proof',lw['index']==j and lw['returncode'] is None and lw['completed_ns'] is None and lw['reaped'] is False and lw['worker_receipts']==[])
        check(lab+' owned launch/completion identity',all(cw[k]==lw[k] for k in ['index','pid','popen_begin_ns','popen_end_ns']))
        wl=cw['stdout'].splitlines(keepends=True); check(lab+' exactly2 actual raw worker lines',len(wl)==2 and all(s.endswith('\n') for s in wl)); started,done=[parse(s) for s in wl]
        check(lab+' reparsed raw equals nested receipts',[started,done]==cw['worker_receipts'])
        check(lab+' actual timing/provenance',started['event']=='worker_started' and done['event']=='worker_completed' and started['pid']==done['pid']==cw['pid'] and type(started['begin_ns']) is type(done['end_ns']) is int and done['begin_ns']==started['begin_ns'] and started['duration_seconds']==done['duration_seconds']==10 and type(done['iterations']) is int and done['iterations']>0 and done['end_ns']-started['begin_ns']>=10e9)
        check(lab+' process provenance/reaping order',launch['begin_ns']<=cw['popen_begin_ns']<=cw['popen_end_ns']<=launch['receipt_ns'] and cw['popen_begin_ns']<=started['begin_ns']<=done['end_ns']<=cw['completed_ns']<=completion['end_ns'])
        check(lab+' actual typed worker exit/clean reap',zero(cw['returncode']) and cw['reaped'] is True and cw['stderr']=='' and not any(k in cw for k in ['receipt_error','terminate_requested_ns','kill_requested_ns']))
        worker={'index':j,'pid':cw['pid'],'popen_begin_ns':cw['popen_begin_ns'],'popen_end_ns':cw['popen_end_ns'],'begin_ns':started['begin_ns'],'end_ns':done['end_ns'],'elapsed_ns':done['end_ns']-started['begin_ns'],'iterations':done['iterations'],'reaped_ns':cw['completed_ns'],'returncode':cw['returncode'],'reaped':cw['reaped']}
        worker['entire_helper_overlap']=interval(worker,r['begin_ns'],r['end_ns'])
        worker['phase_overlaps']=[{'name':phase['name'],**interval(worker,phase['begin_ns'],phase['readback_end_ns'])} for phase in r['phases']]
        check(lab+' actual full-helper bracketing',worker['entire_helper_overlap']['bracketed'])
        for phase in worker['phase_overlaps']: check(lab+' actual phase/readback bracketing '+phase['name'],phase['bracketed'])
        workers.append(worker)
    pids=[r['helper_pid'],launch['launcher_pid'],*[w['pid'] for w in workers]]
    check(name+' four distinct positive Pi PIDs',len(set(pids))==4 and all(type(v) is int and v>1 for v in pids))
    computed=co['overlap']; check(name+' coordinator worker calculations match independent raw reconstruction',computed['workers']==workers and computed['load_launcher_pid']==launch['launcher_pid'] and computed['consumer_helper_pid']==r['helper_pid'] and computed['load_stdout_sha256']==sha(load_path) and computed['consumer_stdout_sha256']==sha(p/'remote.stdout') and computed['accepted'] is True and computed['rejection_reasons']==[] and computed['all_phases_bracketed_by_each_worker'] is True and computed['entire_helper_bracketed_by_each_worker'] is True)
    check(name+' empty raw load stderr',(ROOT/(name+'.load.stderr')).read_bytes()==b'')
    local=acq['local_timing_ns']; check(name+' own-Mac chronology only',co['capture_begin_local_ns']<=local['lead_begin_ns']<=local['lead_end_ns']<=local['tail_begin_ns']<=local['tail_end_ns']<=co['capture_end_local_ns'])
    RUNS.append({'name':name,'backend':r['backend'],'helper_pid':r['helper_pid'],'distinct_pi_pids':pids,'helper_begin_ns':r['begin_ns'],'helper_end_ns':r['end_ns'],'helper_duration_ns':r['end_ns']-r['begin_ns'],'event_count':len(events),'nested_child_count':nested,'top_level_event_count':len(events)-nested,'phase_timings':phase_timings,'actual_exit_labels':{'consumer_ssh_recorded_results':metadata['remote_returncode'],'consumer_ssh_recorded_acquisition':acq['remote_returncode'],'consumer_ssh_recorded_coordinator':co['consumer_remote_returncode'],'load_ssh_recorded_coordinator':co['load_helper_returncode'],'worker_process_recorded_exits':[w['returncode'] for w in workers],'local_coordinator_cli_exit_independently_observed':None,'collector_cli_exit':'not applicable; collector called in-process'},'independently_reconstructed_actual_workers':workers,'whole_helper_min_start_margin_ns':min(w['entire_helper_overlap']['start_margin_ns'] for w in workers),'whole_helper_min_end_margin_ns':min(w['entire_helper_overlap']['end_margin_ns'] for w in workers),'raw_file_sha256_and_sizes':{str(fp.relative_to(ROOT)):{'sha256':sha(fp),'size_bytes':fp.stat().st_size} for fp in files},'raw_load_receipts':[launch,completion],'remote_receipt_raw_unmapped_to_saleae':r,'coordination_receipt_corroboration':co,'original_tx_submissions':tx,'preserved_remote_stderr':{'complete_text':stderr,'line_count':len(diag),'diagnostic_pids':sorted({s['pid'] for s in diag}),'interpretation':'Local Mac gRPC fork/poll diagnostics distinct from Pi helper; no lines dropped'}})

all_pids=[pid for run in RUNS for pid in run['distinct_pi_pids']]
check('16 distinct new Pi PIDs across four runs',len(set(all_pids))==16)
check('ordered nonoverlapping same-Pi helper runs',all(a['helper_end_ns']<=b['helper_begin_ns'] for a,b in zip(RUNS,RUNS[1:])))
STATES=[]
for stage,count in [('preflight',104),('postflight',120)]:
    path=ROOT/f'oct7-lgpio-consumers-loaded-paired-{stage}.json'; z=read(path); rr=z['remote']; sp=Path(str(path)+'.stdout'); ep=Path(str(path)+'.stderr')
    check(stage+' exact state wrapper/raw stdout chain',rr==read(sp) and z['stdout_sha256']==sha(sp) and z['stderr_sha256']==sha(ep) and z['source_sha256']==plan['state_recorder_sha256'])
    check(stage+' typed actual state SSH exit0',zero(z['ssh_returncode']) and z['accepted'] is True and z['validation_error'] is None and z['stage']==stage)
    check(stage+' frozen loaded plan/source origin',z['plan_sha256']==sha(plan_path) and z['frozen_plan']['sha256']==sha(plan_path) and z['frozen_plan']['loaded_coordinator_source_sha256']==plan['loaded_coordinator_source_sha256'] and z['prior_postflight_sha256']==plan['prior_postflight_sha256'])
    check(stage+' full selected manifest/source chain',z['source_manifests']==manifests and rr['remote_manifests']==manifests and all(rr['selected_source_sha256'][k]==manifests[k]['source_sha256'] for k in manifests))
    check(stage+' exact inspected PID count and absence',len(z['inspected_pids'])==len(set(z['inspected_pids']))==len(rr['pid_exists'])==count and set(map(str,z['inspected_pids']))==set(rr['pid_exists']) and all(v is False for v in rr['pid_exists'].values()))
    check(stage+' free GPIO18/23 and read-only state',[(l['offset'],l['used'],l['consumer']) for l in rr['lines']]==[(18,False,None),(23,False,None)] and rr['read_only'] is True and rr['no_gpio_request_or_write'] is True)
    check(stage+' exact remote load source/worker pins',rr['load_program_path']==plan['bench_root']+'/cpu-load-eval/kernel_pwm_cpu_load_eval.py' and rr['load_source_sha256']==plan['load_source_sha256'] and rr['worker_source_sha256']==plan['worker_source_sha256'])
    check(stage+' clean thermal/pinctrl reads',rr['throttled']['stdout']=='throttled=0x0\n' and zero(rr['throttled']['returncode']) and all(zero(o['returncode']) and '| lo //' in o['stdout'] and o['stderr']=='' for o in rr['pinctrl']))
    check(stage+' frozen runtime versions',rr['runtime']['python_executable']==plan['remote_python'] and rr['runtime']['motor_version']=='3.5.0' and rr['runtime']['gpiod_version']=='2.5.0' and rr['runtime']['lgpio_version']=='lgpio.py_0.2.2.0')
    if stage=='postflight':
        for run in RUNS:
            name=run['name']; linked=z['capture_receipts'][name]
            check('postflight linked raw receipts '+name,linked['backend']==run['backend'] and linked['helper_pid']==run['helper_pid'] and linked['load_launcher_pid']==run['distinct_pi_pids'][1] and linked['worker_pids']==run['distinct_pi_pids'][2:] and linked['coordination_sha256']==sha(ROOT/(name+'.consumers-coordination.json')) and linked['load_stdout_sha256']==sha(ROOT/(name+'.load.stdout')) and linked['consumer_stdout_sha256']==sha(ROOT/name/'remote.stdout'))
    STATES.append({'stage':stage,'raw_state':z,'sha256':sha(path),'stdout_sha256':sha(sp),'stderr_sha256':sha(ep)})
pre=STATES[0]['raw_state']; post=STATES[1]['raw_state']
check('postflight120 exact prior104 plus new16 union',set(post['inspected_pids'])==set(pre['inspected_pids'])|set(all_pids) and not set(pre['inspected_pids']).intersection(all_pids))
check('unchanged same Pi boot and boot config',pre['remote']['boot_id']==post['remote']['boot_id']==RUNS[0]['remote_receipt_raw_unmapped_to_saleae']['identity']['boot_id'] and pre['remote']['boot_config_sha256']==post['remote']['boot_config_sha256'])
pre_pwm=pre['remote']['pwm']; post_pwm=post['remote']['pwm']; pre_pwm_lines=pre_pwm['stdout'].splitlines(); post_pwm_lines=post_pwm['stdout'].splitlines()
check('unchanged unclaimed PWM0-2 and provider header',pre_pwm_lines[:4]==post_pwm_lines[:4] and all('period: 0 ns duty: 0 ns' in line and '(null)' in line for line in pre_pwm_lines[1:4]))
check('cooling_fan provider period and polarity preserved',all('pwm-3' in lines[4] and 'cooling_fan' in lines[4] and 'period: 41566 ns' in lines[4] and 'polarity: inverse usage_power' in lines[4] for lines in [pre_pwm_lines,post_pwm_lines]) and zero(pre_pwm['returncode']) and zero(post_pwm['returncode']) and pre_pwm['stderr']==post_pwm['stderr']=='')
fan_observation={'preflight_exact_pwm3_line':pre_pwm_lines[4],'postflight_exact_pwm3_line':post_pwm_lines[4],'preflight_temperature_millic':pre['remote']['temperature_millic'],'postflight_temperature_millic':post['remote']['temperature_millic'],'fan_state_bytes_changed':pre_pwm_lines[4]!=post_pwm_lines[4],'interpretation':'Recorded cooling_fan duty changed from0ns to enabled12225ns at unchanged41566ns period; PWM0-2 stay unused. Consistent with automatic thermal response, but this offline audit does not prove why the duty changed or assert a manual configuration/fan change.'}
OUT={'schema_version':1,'audit_kind':'independent-offline-paired-loaded-consumer-receipts-source-private-ownership-real-worker-overlap','method_source_path':str(METHOD),'method_source_sha256':sha(METHOD),'frozen_plan_sha256':sha(plan_path),'passed':all(c['passed'] for c in CHECKS),'check_count':len(CHECKS),'failures':[c for c in CHECKS if not c['passed']],'checks':CHECKS,'runs':RUNS,'pre_postflight':STATES,'distinct_new_pi_pids':all_pids,'observed_kernel_cooling_fan_state':fan_observation,'uncertainties':['Only saved selected-source receipts are corroborated; no live hardware or whole-system attestation.','Actual worker start/completion intervals and positive iterations establish bounded workload overlap, not CPU saturation or continuous CPU residency.','All helper/worker/phase calculations remain on the same Pi monotonic clock; no Mac/Saleae mapping or application/deinit electrical latency inference.','Typed consumer/load SSH and worker process exits are separate; local coordinator CLI exits were not independently observed by this audit.','Original flags-only public deinit is not credited with lab cancel/drive-low/read/free/chip-close capability.','Finite passive probes, genuine motor3.5.0 and an in-memory shim do not prove installed Blinka compatibility, actuators, calibrated deadtime, scheduling guarantees, saturation or quantitative parity.','Native acquisition requested channel/glitch fields are not serialized; sample/channel facts here use saved results and frozen collector semantics.','No analyzer source or generated report was read; no GPIO/SSH/Saleae/network actions performed; existing artifacts unchanged.']}
DEST.write_text(json.dumps(OUT,indent=2)+'\n')
print(json.dumps({'output':str(DEST),'output_sha256':sha(DEST),'method_source':str(METHOD),'method_sha256':sha(METHOD),'passed':OUT['passed'],'check_count':len(CHECKS),'failures':OUT['failures'],'run_summary':[{k:run[k] for k in ['name','distinct_pi_pids','helper_duration_ns','event_count','nested_child_count','whole_helper_min_start_margin_ns','whole_helper_min_end_margin_ns']} for run in RUNS]},indent=2))
