"""Offline post-reconstruction report comparison. No project imports."""
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

ROOT=Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
INITIAL=ROOT/'oct7-lgpio-consumers-loaded-paired-independent-audit.json'
NOTES=ROOT/'oct7-lgpio-consumers-loaded-paired-independent-notes.txt'
FINAL=ROOT/'oct7-lgpio-consumers-loaded-paired-final-report-audit.json'
INITIAL_HASH='53dbeff251145601f291dc8cb076ae2da827fd27e17df66975a7652daaf0ac1b'
NOTES_HASH='e11249e803ce464b20d8af7f67db17314628eae4f74510e5fdadb1f00ff20e63'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(v):
    v=list(v)
    return {'count':0}if not v else{'count':len(v),'min':min(v),'median':statistics.median(v),'max':max(v),'mean':statistics.mean(v)}
def same_stats(a,b):
    return {k:a[k]==b[k]if k=='count'else math.isclose(a[k],b[k],abs_tol=1e-7,rel_tol=0)for k in b}
def touching(highs,a,b):return [x['high_index']for x in highs if x['start_s']<=b and x['end_s']>=a]
def window_checks(raw,window):
    a,b=window['window_seconds'];highs=raw['all_high_intervals'];lows=raw['all_low_intervals_including_endpoints'];rises=raw['all_adjacent_rise_intervals_including_discontinuities']
    contained_highs=[x for x in highs if a<=x['start_s'] and x['end_s']<=b]
    contained_rises=[x for x in rises if a<=x['earlier_rise_s'] and x['later_rise_s']<=b]
    overlapping_lows=[x for x in lows if x['start_s']<=b and x['end_s']>=a]
    return {'duration_exact':window['duration_seconds']==b-a,
            'all_boundary_inclusive_edge_indices_exact':window['edge_indices_including_boundaries']==[i for i,t in enumerate(raw['all_transition_times_s'])if a<=t<=b],
            'all_overlapping_or_touching_high_indices_exact':window['overlapping_high_pair_indices']==touching(highs,a,b),
            'all_wholly_contained_high_indices_exact':window['wholly_contained_high_pair_indices']==[x['high_index']for x in contained_highs],
            'all_wholly_contained_adjacent_rises_exact':[(x['begin_seconds'],x['end_seconds'],x['rise_to_rise_us'])for x in window['wholly_contained_adjacent_rise_intervals']]==[(x['earlier_rise_s'],x['later_rise_s'],x['duration_us'])for x in contained_rises],
            'contained_high_stats_exact_basis':same_stats(stats(x['duration_us']for x in contained_highs),window['contained_high_width_stats_us']),
            'contained_adjacent_rise_stats_exact_basis':same_stats(stats(x['duration_us']for x in contained_rises),window['contained_adjacent_rise_stats_us']),
            'all_overlapping_lows_including_boundary_touches_exact':[(x['begin_seconds'],x['end_seconds'],x['width_us'])for x in window['overlapping_low_runs']]==[(x['start_s'],x['end_s'],x['duration_us'])for x in overlapping_lows],
            'boundary_runs_preserved':window['boundary_runs_not_discarded']is True}
def false_paths(v,prefix=''):
    found=[]
    if isinstance(v,dict):
        for k,x in v.items():found.extend(false_paths(x,prefix+'.'+k if prefix else k))
    elif v is not True:found.append(prefix)
    return found
def checked_leaf_count(v):return sum(checked_leaf_count(x)for x in v.values())if isinstance(v,dict)else 1

assert sha(INITIAL)==INITIAL_HASH and sha(NOTES)==NOTES_HASH
base=json.loads(INITIAL.read_text())
result={'schema_version':1,'audit_kind':'final-report-comparison-after-immutable-independent-loaded-paired-audit',
        'comparison_method_source_path':__file__,'comparison_method_source_sha256':sha(Path(__file__)),
        'immutable_initial_artifacts':{'audit':{'path':INITIAL.name,'sha256':INITIAL_HASH},'notes':{'path':NOTES.name,'sha256':NOTES_HASH}},
        'initial_bytes_unchanged':True,'hardware_network_or_saleae_used':False,
        'analyzer_sources_read':False,'reports_modified':False,
        'report_filename_selection':{'original':'analysis.json','native':'consumer-analysis.json','difference_is_cli_filename_default_not_waveform_data':True},
        'statistics_tolerance_us':1e-7,
        'method_differences':["Direct struct reconstruction was frozen before reports and imports no project helper/analyzer. All report transition/high/endpoint-and-interior-low/adjacent-rise arrays are compared against those immutable arrays, including unselected complete trains and discontinuities.","Both the NEW frozen loaded plan and reports use symmetric math.isclose(measured, nominal, rel_tol=0.10) for diagnostic identity. Initial audit additionally retains target-normalized +/-10% diagnostics. All current fragment memberships agree; neither identity band is waveform performance acceptance.","All original reverse highs (350 in r1;351 in r2) match the diagnostic motor-half width/period band but their complete trains have a0.610us boundary peer-high overlap. Reports retain all these raw highs and explicitly mark all reverse indices unassigned, select no isolated reverse candidate, and withhold whole topology. No central stable window substitutes for the complete train.","Initial nearest-nominal enclosing groups cover full physical extents; report candidate/distribution bases are checked against exact raw pair indices. These captures have no ordinary out-of-band highs/periods, so diagnostic membership agrees without removing any highs.","Independent within-block low summaries exclude cross-label/end-point lows; all such lows remain in complete arrays. Original feature-window lists retain overlapping endpoint/boundary lows. Comparison recomputes shared statistics on the stated exact basis and validates whole boundary-inclusive windows.","Independent stats add nearest-rank quantiles/population standard deviations and complete target errors. Shared count/min/median/max/mean statistics are compared with1e-7us absolute tolerance; exact raw arrays and interval endpoints use exact equality.","Original final ownership/source validation is summarized/delegated; native reports embed full phase/action/ownership fields. The2156-check initial receipt audit and two agreeing raw-worker reconstructions remain the detailed independent protocol, cleanup and typed exit proof.","Neither waveform report exposes/hashes load stdout/stderr/coordination, actual worker PID intervals, or helper/all15phase overlap. This omission is report scope, not a waveform mismatch; final comparison separately verifies every saved workload hash and exact independent overlap calculation remains unchanged.","Original reports reference the NEW loaded plan1cedb74c...; native frozen reports reference unchanged native protocol plan97bb31a2... pinned by that loaded plan. Filename defaults also differ (analysis.json/consumer-analysis.json); neither difference changes waveform data.","Original withheld topology is null in reports versus false in initial audit; both mean no complete isolated ordered topology established. Native complete isolated descriptive topology remains true. No calibrated deadtime, CPU saturation, cross-clock alignment, installed-Blinka, actuator or quantitative parity verdict."],
        'runs':{}}

for stem,own in base['runs'].items():
    original=own['backend']=='original-blinka-lgpio';name='analysis.json'if original else'consumer-analysis.json';path=ROOT/stem/name
    report=json.loads(path.read_text());check={};raw_summary=[];fragment_checks=[];normalized=[]
    channels=report['raw_channels']if original else{'gpio18_ch0':report['gpio18_channel0'],'gpio23_ch1':report['gpio23_channel1']}
    for ch,key in[('0','gpio18_ch0'),('1','gpio23_ch1')]:
        a=own['channels'][ch];b=channels[key];header=a['header'];wave=b['waveform']
        check[key+'_header']={k:wave[k]==header[v]for k,v in{'binary_format_version':'version','begin_seconds':'begin_s','end_seconds':'end_s','initial_state':'initial_state','edge_count':'transition_count'}.items()}
        check[key+'_header']['final_state']=wave['final_state']==a['final_state']
        check[key+'_all_transition_times_exact']=wave['transition_seconds']==a['all_transition_times_s']
        hi=[(x['start_s'],x['end_s'],x['duration_us'])for x in a['all_high_intervals']]
        lo=[(x['start_s'],x['end_s'],x['duration_us'])for x in a['all_low_intervals_including_endpoints']]
        ri=[(x['earlier_rise_s'],x['later_rise_s'],x['duration_us'])for x in a['all_adjacent_rise_intervals_including_discontinuities']]
        check[key+'_all_high_intervals_exact']=hi==[(x['rise_seconds'],x['fall_seconds'],x['width_us'])for x in b['all_high_runs']]
        check[key+'_all_low_intervals_including_endpoints_exact']=lo==[(x['begin_seconds'],x['end_seconds'],x['width_us'])for x in b['all_low_runs']]
        check[key+'_all_adjacent_rises_and_discontinuities_exact']=ri==[(x['begin_seconds'],x['end_seconds'],x['rise_to_rise_us'])for x in b['all_adjacent_rise_intervals']]
        for tag,key_stats,v in[('high','all_high_width_stats_us',hi),('low','all_low_width_stats_us',lo),('rise','all_adjacent_rise_stats_us',ri)]:check[key+'_global_'+tag+'_stats']=same_stats(stats(x[2]for x in v),b[key_stats])
        check[key+'_sub_microsecond_highs']=len(b['sub_microsecond_highs'])==len(a['sub_microsecond_high_indices'])==0
        check[key+'_sub_microsecond_interior_lows']=len(b['sub_microsecond_interior_lows'])==len(a['sub_microsecond_interior_low_indices'])==0
        targets=own['nominal_targets_us'];candidate_checks=[];unmatched=[]
        for x,y in zip(a['all_high_intervals'],b['all_high_runs']):
            if x['duration_us']>=100000:candidates=[]
            else:candidates=[tag for tag,target in targets.items()if math.isclose(x['duration_us'],target,rel_tol=.1,abs_tol=0)]
            nearest=min(targets,key=lambda tag:abs(x['duration_us']-targets[tag]))
            candidate_checks.append(candidates==y['width_target_candidates'] and nearest==y['nearest_width_target'] and math.isclose(x['duration_us']-targets[nearest],y['nearest_width_target_error_us'],rel_tol=0,abs_tol=1e-7))
            if not candidates and x['duration_us']<100000:unmatched.append(x['high_index'])
        check[key+'_diagnostic_candidate_mapping_reproduced_by_symmetric_relative_tolerance']=all(candidate_checks)
        check[key+'_unmatched_pairs_under_report_candidate_convention']=unmatched==b['unmatched_width_pair_indices']
        raw_summary.append({'channel':int(ch),'transitions':len(a['all_transition_times_s']),'complete_high_count':len(hi),'all_low_count_including_endpoints':len(lo),'all_adjacent_rise_count':len(ri),
                            'complete_raw_high_stats_us':a['all_high_width_stats_us'],'report_unmatched_candidate_high_indices':unmatched})
        if original:
            for tag,dist in b['target_normalized_width_distributions'].items():
                ids=dist['pair_indices'];vals=[a['all_high_intervals'][i]['duration_us']for i in ids];target=targets[tag]
                expected_ids=[x['high_index']for x in a['all_high_intervals']if x['duration_us']<100000 and math.isclose(x['duration_us'],target,rel_tol=.1)]
                item={'channel':ch,'target_tag':tag,'pair_indices_match_report_candidate_convention':ids==expected_ids,
                      'raw_width_stats':same_stats(stats(vals),dist['width_us']),
                      'ratio_stats':same_stats(stats(v/target for v in vals),dist['width_divided_by_target']),
                      'difference_stats':same_stats(stats(v-target for v in vals),dist['width_minus_target_us'])}
                normalized.append(item);check[key+'_normalized_'+tag]={k:v for k,v in item.items()if k not in('channel','target_tag')}
            blocks=b['all_width_period_blocks']
        else:blocks=report['functional_waveform_facts']['all_width_period_train_fragments_including_short']['gpio18'if ch=='0'else'gpio23']
        expected_blocks={tag:[]for tag in targets}
        for row in own['nearest_nominal_descriptive_full_width_blocks_not_command_labels'][ch]:
            if row['descriptive_label']=='long_high':continue
            expected_blocks[row['descriptive_label']].extend([list(range(f['first_high_index'],f['last_high_index']+1))for f in row['all_frozen_band_fragments_including_single_anomalies']if f['widths_all_in_band']])
        check[key+'_all_reported_fragment_memberships_equal_frozen_primary_full_reconstruction']={tag:[x['pair_indices']for x in blocks[tag]]==indices for tag,indices in expected_blocks.items()}
        for tag,arr in blocks.items():
            for index,t in enumerate(arr):
                ids=t['pair_indices'];hs=[a['all_high_intervals'][i]for i in ids]
                periods=[(n['start_s']-p['start_s'])*1e6 for p,n in zip(hs,hs[1:])]
                item={'channel':ch,'tag':tag,'first_high_index':ids[0],'last_high_index':ids[-1],'pulse_count':len(ids),
                      'checks':{'contiguous_raw_indices':ids==list(range(ids[0],ids[-1]+1)),
                                'begin_end_exact':(t['begin_seconds'],t['end_seconds'])==(hs[0]['start_s'],hs[-1]['end_s']),
                                'complete_fragment_high_stats':same_stats(stats(x['duration_us']for x in hs),t['high_width_stats_us']),
                                'complete_fragment_adjacent_rise_stats':same_stats(stats(periods),t['period_stats_us'])}}
                fragment_checks.append(item);check[key+'_fragment_'+tag+'_'+str(index)]=item['checks']
    hashes=own['raw_file_sha256_and_sizes']
    check['all_evidence_hashes_match_immutable_initial_raw_audit']=all(hashes[stem+'/'+filename]['sha256']==digest for filename,digest in report['evidence_sha256'].items())
    check['all_raw_files_still_match_immutable_initial_hashes']=all(sha(ROOT/file)==v['sha256']for file,v in hashes.items())
    saved=report['saved_sal']if original else report['saved_capture_settings']
    check['saved_sal_metadata_flags_agree']=saved=={'channels':[0,1],'sample_rate_hz':100000000,'physical_device':True,'glitch_filter':False}
    initial_receipts=own['offline_receipt_source_ownership_checks'];remote=json.loads((ROOT/stem/'results.json').read_text())['remote'];acq=json.loads((ROOT/stem/'acquisition.json').read_text())
    check['recorded_actual_ssh_exit_evidence_zero_and_unchanged']=initial_receipts['actual_consumer_ssh_exit_statuses']=={'acquisition_remote_returncode':0,'results_remote_returncode':0}and acq['remote_returncode']==0
    check['prior_detailed_independent_receipt_checks_passed']=base['additional_independent_receipt_checks']['passed']is True and base['additional_independent_receipt_checks']['failures']==[]
    if original:
        check['frozen_plan_reference_hash_agrees']=report['frozen_plan']['sha256']==base['frozen_plan_sha256']
        check['frozen_helper_collector_analyzer_hash_declarations_agree']={k:report['frozen_plan']['source_sha256'][name]==base['frozen_plan'][k]for k,name in[('helper_sha256','lgpio_pwm_consumers_eval.py'),('collector_sha256','capture_lgpio_pwm_consumers.py'),('analyzer_sha256','analyze_lgpio_pwm_consumers.py')]}
        check['selected_original21_source_hashes_exact']=report['functional_receipts']['selected_source_sha256']==remote['source_sha256']==initial_receipts['selected_frozen_manifest']['source_sha256']
        check['report_actual_ssh_returncode_exact']=report['functional_receipts']['actual_ssh_returncode']==0
        check['original_nominal_percent_targets_exact']=report['original_percent_nominals']==base['frozen_plan']['original_percent_nominals']
        check['original90_4914_submits7percent_1400us']=report['original_percent_nominals']['servo_angle90']=={'frequency_hz':50,'duty_u16':4914,'submitted_duty_percent':7,'submitted_nominal_high_us':1400.0}
        top=report['ordered_raw_topology'];selection=top['selected_candidates']
        check['original_complete_isolated_topology_withheld']=top['compatible_unique_ordered_topology']is None and own['complete_frozen_isolated_ordered_topology_supported']is False
        observations=top['candidate_whole_run_observations']
        for obs in observations:
            gpio=obs['gpio'];ch='0'if gpio==18 else'1';peer=own['channels']['1'if ch=='0'else'0']['all_high_intervals'];candidate=obs['candidate']
            if 'pair_indices'in candidate:
                ids=candidate['pair_indices'];hs=[own['channels'][ch]['all_high_intervals'][i]for i in ids];begin,end=hs[0]['start_s'],hs[-1]['end_s']
                check['selected_'+obs['feature']+'_raw_width_stats']=same_stats(stats(x['duration_us']for x in hs),candidate['high_width_stats_us'])
            else:begin,end=candidate['rise_seconds'],candidate['fall_seconds']
            sibling=obs['sibling_raw_window'];touch=touching(peer,begin,end)
            check['selected_'+obs['feature']+'_complete_own_raw_window']=window_checks(own['channels'][ch],obs['own_raw_window'])
            check['selected_'+obs['feature']+'_complete_sibling_raw_window']=window_checks(own['channels']['1'if ch=='0'else'0'],sibling)
            check['selected_'+obs['feature']+'_whole_boundary_sibling']={'touching_indices_exact':sibling['overlapping_high_pair_indices']==touch,
                 'full_window_exact':sibling['window_seconds']==[begin,end],'low_throughout_full_window_flag':sibling['whole_run_boundary_inclusive_low']==(not touch),
                 'boundary_runs_preserved':sibling['boundary_runs_not_discarded']is True}
        check['original_full_positive_peer_overlap_explicitly_withheld']=any(x['feature']=='motor_forward_full'and x['reason']=='sibling_high_overlaps_or_touches_whole_run_boundary'and x['sibling_high_pair_indices']==[1]for x in top['ambiguities'])
        check['complete_final_low_fragments_exact']={gpio:(top['final_low_runs'][gpio]['begin_seconds'],top['final_low_runs'][gpio]['end_seconds'],top['final_low_runs'][gpio]['width_us'])==(own['channels'][ch]['all_low_intervals_including_endpoints'][-1]['start_s'],own['channels'][ch]['all_low_intervals_including_endpoints'][-1]['end_s'],own['channels'][ch]['all_low_intervals_including_endpoints'][-1]['duration_us'])for gpio,ch in [('18','0'),('23','1')]}
        check['no_isolated_reverse_candidate']=('motor_reverse_half'not in selection and any(x['feature']=='motor_reverse_half'and x['candidate_count']==0 for x in top['ambiguities']))
        reverse=own['nearest_nominal_descriptive_full_width_blocks_not_command_labels']['1'][1]
        check['all_complete_reverse_highs_explicitly_unassigned']=any(x['feature']=='reverse_half_full_extent'and x['pair_indices']==list(range(reverse['first_high_index'],reverse['last_high_index']+1))for x in top['ambiguities'])
        check['exact_three_original_topology_ambiguities']=len(top['ambiguities'])==3
        brake=selection['joint_brake'];joint=own['all_both_high_positive_duration_intersections'][0]
        check['joint_brake_complete_overlap_endpoints_exact']=(brake['begin_seconds'],brake['end_seconds'])==(joint['start_s'],joint['end_s'])
        scope={'report_scope':report['functional_receipts']['scope'],'ownership_validation_is_summary_delegation_not_reemitted_raw':report['functional_receipts']['receipt_validation'],
               'public_deinit_vs_lab_cleanup_limitation_preserved':any('Public original deinit alone does not cancel/free GPIO'in x for x in report['limitations']),
               'quantitative_parity_or_command_clock_alignment_not_claimed':report['limitations']}
        check['original_public_deinit_separate_from_lab_cleanup_caveat']=scope['public_deinit_vs_lab_cleanup_limitation_preserved']
        verdict={'compatible_unique_ordered_topology':top['compatible_unique_ordered_topology'],'ambiguities':top['ambiguities'],
                 'selected_reverse_candidate_range':([selection['motor_reverse_half']['pair_indices'][0],selection['motor_reverse_half']['pair_indices'][-1]]if'motor_reverse_half'in selection else None)}
    else:
        check['native_unchanged_protocol_plan_hash_expected']=report['plan_sha256']==base['frozen_plan']['native_reference']['unchanged_protocol_plan_sha256']
        check['selected_native18_source_manifest_exact']=report['source_manifest']==initial_receipts['selected_frozen_manifest']
        check['native_rounded_targets_exact']={tag:report['actual_consumer_u16_c_rounded_nominals'][tag]['high_us']==target for tag,target in own['nominal_targets_us'].items()}
        api=report['validated_receipt_consumer_api_and_ownership_not_electrical_phase_identity'];check['native_full_api_ownership_receipts_exact']={k:v==remote[k]for k,v in api.items()}
        check['native_event_count_and_caller_durations_exact']=len(report['caller_events_pi_clock'])==41 and all({k:v for k,v in event.items()if k!='caller_duration_us'}==raw and math.isclose(event['caller_duration_us'],(raw['end_ns']-raw['begin_ns'])/1000,abs_tol=1e-7,rel_tol=0)for event,raw in zip(report['caller_events_pi_clock'],remote['events']))
        facts=report['functional_waveform_facts'];check['native_complete_isolated_topology_supported_agrees']=facts['complete_frozen_ordered_joint_topology_supported']is True and own['complete_frozen_isolated_ordered_topology_supported']is True and facts['ambiguities']==[]
        for obs in facts['physical_observations']:
            if'sibling'not in obs['evidence']:continue
            if'train'in obs['evidence']:
                candidate=obs['evidence']['train'];ch='1'if obs['feature']=='motor_reverse_half_guarded_train'else'0';begin,end=candidate['begin_seconds'],candidate['end_seconds']
            else:
                candidate=obs['evidence']['complete_high_run'];ch='1'if obs['feature']=='motor_reverse_full_physical_long_high'else'0';begin,end=candidate['rise_seconds'],candidate['fall_seconds']
            peer=own['channels']['1'if ch=='0'else'0']['all_high_intervals'];sibling=obs['evidence']['sibling']
            check[obs['feature']+'_full_boundary_inclusive_sibling']={'no_peer_highs':not touching(peer,begin,end),'full_window_low_flag':sibling['low_throughout_full_window_observed']is True,
                 'no_guarded_core_substitution':sibling['guarded_core_substitution_used']is False}
        flag_values={'functional_consumer_integration_only':True,'passive_probes_only':True,'actual_actuator_operation_established':False,'installed_blinka_compatibility_proven':False,'waveform_accepted':None,'parity_pass':None,'matched_performance_parity':False,'pi_saleae_clocks_aligned':False,'application_latency_measured':False,'no_edge_trimming_or_glitch_filtering':True,'timebase_gpio_driver_and_threshold_skew_calibrated':False}
        check['native_scope_flags_exact']={k:report[k]==v for k,v in flag_values.items()}
        verdict={'complete_frozen_ordered_joint_topology_supported':facts['complete_frozen_ordered_joint_topology_supported'],'ambiguities':facts['ambiguities']}
        scope={'limitation':report['limitation'],'actual_ssh_exit_not_exposed_as_separate_report_field':'Validated saved acquisition/results hashes refer to the same SSH0 receipts; collection_receipts_validated=true does not itself identify local CLI exits.'}
    failures=false_paths(check)
    result['runs'][stem]={'report_path':str(path),'report_sha256':sha(path),'report_size_bytes':path.stat().st_size,
         'checked_facts':check,'checked_fact_mismatch_paths':failures,'all_compared_raw_receipt_numeric_facts_agree':not failures,
         'raw_counts_and_stats':raw_summary,'all_reported_fragment_stats_recomputed_from_immutable_raw':fragment_checks,
         'original_target_normalized_distributions_recomputed_on_reported_raw_basis':normalized,
         'direction_handoff_from_immutable_independent_audit':own['direction_handoff_observation'],
         'all_raw_both_high_intersections_from_independent_audit':own['all_both_high_positive_duration_intersections'],
         'complete_descriptive_groups_stats_extrema_and_boundaries_from_immutable_audit':own['nearest_nominal_descriptive_full_width_blocks_not_command_labels'],
         'actual_raw_workload_overlap_proof_separate_from_waveform_report':own['primary_raw_worker_overlap_proof'],
         'waveform_report_does_not_supply_loaded_worker_proof':True,
         'report_full_extent_association_verdict':verdict,'source_ownership_scope_notes':scope}
    print(stem,'checked fact mismatches',failures)
result['checked_fact_mismatch_count']=sum(len(x['checked_fact_mismatch_paths'])for x in result['runs'].values())
result['main_checked_boolean_fact_count']=sum(checked_leaf_count(x['checked_facts'])for x in result['runs'].values())
result['all_checked_numeric_raw_receipt_and_scope_facts_agree']=result['checked_fact_mismatch_count']==0
result['diagnostic_classification_differences']=[]
result['observed_kernel_cooling_fan_state_from_immutable_initial_audit']=base['additional_independent_receipt_checks']['observed_kernel_cooling_fan_state']
result['overall_conclusion']=f'{result["checked_fact_mismatch_count"]} mismatches in checked complete raw arrays, common numeric statistics, frozen symmetric-band fragments, source/exit/ownership references and full-extent association verdicts. Report workload-proof omissions and differing statistics/plan/filename bases are explicit; exact workload receipts remain separately validated against immutable initial evidence. No hardware/network used; no reports/initial artifacts/analyzer sources modified.'
assert sha(INITIAL)==INITIAL_HASH and sha(NOTES)==NOTES_HASH
if len(sys.argv)>1 and not sys.argv[1].startswith('--'):
    specialist_path=Path(sys.argv[1]); specialist=json.loads(specialist_path.read_text())
    assert specialist['passed'] is True and specialist['mismatches']==[] and len(specialist['checks'])==specialist['check_count'] and all(c['passed']for c in specialist['checks'])
    result['additional_final_receipt_comparison']=specialist
    result['additional_final_receipt_comparison_path']=str(specialist_path)
    result['additional_final_receipt_comparison_sha256']=sha(specialist_path)
    result['specialist_checked_fact_count']=specialist['check_count']
if '--save' in sys.argv:
    assert 'additional_final_receipt_comparison' in result,'Require complete specialist comparison before freeze'
    assert not FINAL.exists(),'Final audit output must be exclusive'
    with FINAL.open('x')as out:out.write(json.dumps(result,indent=2)+'\n')
    print(FINAL,'SHA256',sha(FINAL))
else:
    preview=Path('/private/tmp/loaded-paired-report-comparison.An4rpK/comparison-preview.json')
    preview.write_text(json.dumps(result,indent=2)+'\n')
    print('Preview:',preview)
