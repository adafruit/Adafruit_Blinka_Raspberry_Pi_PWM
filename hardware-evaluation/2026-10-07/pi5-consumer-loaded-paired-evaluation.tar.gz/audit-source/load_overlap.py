"""Independent raw worker-stdout interval reconstruction; no project imports."""
import hashlib
import json
from pathlib import Path
root=Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
output=Path('/private/tmp/loaded-paired-independent.BY13uN/load_overlap_checks.json')
plan=json.loads((root/'oct7-lgpio-consumers-loaded-plan.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit={'method_source_path':__file__,'method_source_sha256':sha(Path(__file__)),'cross_clock_alignment':False,'cpu_saturation_proven':False,'runs':{}}
def interval(begin,end,wb,we):
    assert wb<=begin<=end<=we
    return {'begin_ns':begin,'end_ns':end,'duration_ns':end-begin,'actual_worker_begin_ns':wb,'actual_worker_end_ns':we,'start_margin_ns':begin-wb,'end_margin_ns':we-end,'bracketed':True}
for stem in plan['capture_order']:
    directory=root/stem
    loadfile=root/(stem+'.load.stdout')
    lines=loadfile.read_text().splitlines()
    assert len(lines)==2
    launch,complete=map(json.loads,lines)
    remote=json.loads((directory/'remote.stdout').read_text())
    coordination=json.loads((root/(stem+'.consumers-coordination.json')).read_text())
    results=json.loads((directory/'results.json').read_text())
    acquisition=json.loads((directory/'acquisition.json').read_text())
    assert launch['event']=='load_launched' and complete['event']=='load_completed'
    assert launch['launcher_pid']==complete['launcher_pid'] and launch['begin_ns']==complete['begin_ns']
    assert launch['worker_count']==complete['worker_count']==launch['started_worker_count']==2
    assert launch['worker_duration_seconds']==complete['worker_duration_seconds']==10
    assert launch['source_sha256']==complete['source_sha256']=='0644d9b0e0228bca813e7b3cbb909165e1c313d04baf2405c8f0f78badbc18ca'
    assert launch['worker_source_sha256']==complete['worker_source_sha256']=='430c6552b38acb6a87ee9aca00dfb0df1422969f5d8afea4869af6eac890918d'
    assert complete['success'] is True and complete['primary_error'] is None and complete['cleanup_errors']==[] and complete['signals_received']==[]
    assert len(remote['phases'])==15 and len(launch['owned_workers'])==len(complete['owned_workers'])==2
    statuses={'consumer_ssh_exit_acquisition':acquisition['remote_returncode'],'consumer_ssh_exit_results':results['remote_returncode'],'consumer_ssh_exit_coordination':coordination['consumer_remote_returncode'],'load_ssh_exit_coordination':coordination['load_helper_returncode']}
    assert all(type(x)is int and x==0 for x in statuses.values())
    workers=[]
    for original,worker in zip(launch['owned_workers'],complete['owned_workers']):
        assert all(original[k]==worker[k] for k in ('index','pid','popen_begin_ns','popen_end_ns'))
        assert worker['reaped'] is True and type(worker['returncode'])is int and worker['returncode']==0 and worker['stderr']==''
        raw_worker_lines=worker['stdout'].splitlines();assert len(raw_worker_lines)==2
        started,finished=map(json.loads,raw_worker_lines)
        assert [started,finished]==worker['worker_receipts']
        assert started['event']=='worker_started' and finished['event']=='worker_completed'
        assert started['pid']==finished['pid']==worker['pid'] and started['begin_ns']==finished['begin_ns'] and started['duration_seconds']==finished['duration_seconds']==10
        wb,we=started['begin_ns'],finished['end_ns']
        assert worker['popen_begin_ns']<=worker['popen_end_ns']<=wb<we<=worker['completed_ns']<=complete['end_ns']
        assert we-wb>=10_000_000_000 and type(finished['iterations'])is int and finished['iterations']>0
        row={'index':worker['index'],'pid':worker['pid'],'actual_begin_ns':wb,'actual_end_ns':we,'actual_elapsed_ns':we-wb,'iterations':finished['iterations'],'raw_worker_stdout':worker['stdout'],'raw_worker_stdout_sha256':hashlib.sha256(worker['stdout'].encode()).hexdigest(),'whole_helper':interval(remote['begin_ns'],remote['end_ns'],wb,we),'all_15_phase_readback_inclusive_intervals':[{'name':p['name'],**interval(p['begin_ns'],p['readback_end_ns'],wb,we)}for p in remote['phases']]}
        workers.append(row)
    pids=[remote['helper_pid'],launch['launcher_pid'],*[w['pid']for w in workers]]
    assert len(set(pids))==4
    run={'load_stdout_sha256':sha(loadfile),'parsed_raw_load_stdout':[launch,complete],'distinct_helper_launcher_two_worker_pids':pids,'actual_recorded_exit_statuses':statuses,'local_cli_exit_not_inferred':True,'workers':workers,'minimum_whole_helper_start_margin_ns':min(w['whole_helper']['start_margin_ns']for w in workers),'minimum_whole_helper_end_margin_ns':min(w['whole_helper']['end_margin_ns']for w in workers),'launch_popen_not_used_for_overlap_proof':True,'coordinator_overlap_not_used_for_primary_proof':True}
    audit['runs'][stem]=run
    print(stem,run['minimum_whole_helper_start_margin_ns'],run['minimum_whole_helper_end_margin_ns'])
with output.open('x')as stream:stream.write(json.dumps(audit,indent=2)+'\n')
print(output,'SHA256',sha(output))
