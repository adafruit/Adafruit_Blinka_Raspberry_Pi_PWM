"""Saved-SAL load/export only; creates and closes its own Capture objects."""
from pathlib import Path
import hashlib
import json
from saleae import automation
root=Path('/Users/melissa/Documents/Codex/2026-08-07/ca/work/pwm-measurements')
output=Path('/private/tmp/loaded-paired-salcheck.BYVXRZ')
plan=json.loads((root/'oct7-lgpio-consumers-loaded-plan.json').read_text())
checks=[]
with automation.Manager.connect(port=10430,connect_timeout_seconds=8) as manager:
    for stem in plan['capture_order']:
        destination=output/stem
        destination.mkdir()
        capture=manager.load_capture(str(root/stem/'waveform.sal'))
        try:
            capture.export_raw_data_binary(str(destination),digital_channels=[0,1],analog_channels=[])
            for ch in (0,1):
                raw=(root/stem/f'digital_{ch}.bin').read_bytes()
                exported=(destination/f'digital_{ch}.bin').read_bytes()
                check={'run':stem,'channel':ch,'byte_identical':raw==exported,'size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
                checks.append(check)
                print(json.dumps(check),flush=True)
                assert raw==exported
        finally:
            capture.close()
with (output/'export_checks.json').open('x') as stream:
    stream.write(json.dumps({'checks':checks,'all_own_capture_objects_closed':True,'manager_disconnected':True,'offline_saved_capture_only':True},indent=2)+'\n')
print('All own Capture objects closed; Manager context disconnected.',flush=True)
