"""Offline original-lgpio consumer facts; identification is not acceptance.

Reuse frozen binary/SAL readers, not native topology or native u16 targets.
All sampled transitions and complete intervals remain in the report. Pi clocks
are never aligned with Saleae, and no central-window refinement is performed.
"""

import argparse
import hashlib
import itertools
import json
import math
import shlex
from pathlib import Path

import analyze_native_pwm_dual_initial as raw
import capture_lgpio_pwm_consumers as collector

require = raw.require
PLAN_NAME = "oct7-lgpio-consumers-plan.json"
BAND, MIN_PULSES, LONG_HIGH_US, BRAKE_SECONDS = 0.10, 5, 100_000, 0.10
TARGETS = {
    "servo_angle0": {
        "frequency_hz": 50,
        "duty_u16": 3276,
        "submitted_duty_percent": 5,
        "submitted_nominal_high_us": 1000.0,
    },
    "servo_angle90": {
        "frequency_hz": 50,
        "duty_u16": 4914,
        "submitted_duty_percent": 7,
        "submitted_nominal_high_us": 1400.0,
    },
    "servo_angle180": {
        "frequency_hz": 50,
        "duty_u16": 6553,
        "submitted_duty_percent": 10,
        "submitted_nominal_high_us": 2000.0,
    },
    "motor_half": {
        "frequency_hz": 1000,
        "duty_u16": 32767,
        "submitted_duty_percent": 50,
        "submitted_nominal_high_us": 500.0,
    },
}
RULES = {
    "ordinary_width_period_relative_band": BAND,
    "minimum_identifiable_train_pulses": MIN_PULSES,
    "sustained_high_threshold_seconds": LONG_HIGH_US / 1e6,
    "minimum_joint_brake_overlap_seconds": BRAKE_SECONDS,
    "sibling_low_rule": "whole-run-boundary-inclusive",
}
RAW_SOURCE_PINS = {
    "analyze_native_pwm_dual_initial.py": "61f5f31343c09e06ec213d4c19f64d35605d0eda2140057d0b08cb539d17a350",
    "analyze_gpio_pwm_marker.py": "a06410da89a0f5e84eacb1445cd5ae1b2a75fc40293bd12597c05edba8111c4e",
    "analyze_kernel_pwm_inverse.py": "7616b03ad3278a85c031f4efcf2029e8da41ed3b954ff404d9d732876d36d3c4",
}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sequence_contract():
    return [
        {
            "name": name,
            "duration_seconds": duration,
            "operation": operation,
            "value": value,
        }
        for name, duration, operation, value in collector.helper.SEQUENCE
    ]


def read_plan(path=None):
    """The plan pins this file, rather than creating a cyclic plan-SHA pin."""
    path = Path(path) if path is not None else Path(__file__).with_name(PLAN_NAME)
    plan = collector.read_json(path.read_text())
    require(
        all(
            plan.get(key) == value
            for key, value in {
                "mode": collector.MODE,
                "backend": collector.BACKEND,
                "sequence_marker": collector.SEQUENCE_MARKER,
                "motor_version": "3.5.0",
                "outputs": [
                    {"gpio": 18, "saleae_channel": 0},
                    {"gpio": 23, "saleae_channel": 1},
                ],
                "sequence": sequence_contract(),
                "original_percent_nominals": TARGETS,
            }.items()
        ),
        "Frozen original consumer plan/targets/sequence changed",
    )
    require(
        all(
            plan.get("pre_capture_waveform_identification", {}).get(key) == value
            for key, value in RULES.items()
        ),
        "Frozen identification rules changed",
    )
    require(collector.PERCENT_NOMINALS == TARGETS, "Collector percent targets changed")
    sources = {
        "lgpio_pwm_consumers_eval.py": plan.get("helper_sha256"),
        "capture_lgpio_pwm_consumers.py": plan.get("collector_sha256"),
        Path(__file__).name: plan.get("analyzer_sha256"),
        **RAW_SOURCE_PINS,
    }
    for name, digest in sources.items():
        require(
            sha256(Path(__file__).with_name(name)) == digest,
            "Frozen analysis/capture source changed: " + name,
        )
    return plan, {
        "path": str(path.resolve()),
        "sha256": sha256(path),
        "source_sha256": sources,
    }


def in_band(value, target):
    return math.isclose(value, target, rel_tol=BAND)


def retarget(channel):
    """Replace every native diagnostic field; interval construction is shared."""
    highs = channel["all_high_runs"]
    for high in highs:
        width = high["width_us"]
        nearest = min(
            TARGETS,
            key=lambda tag: abs(width - TARGETS[tag]["submitted_nominal_high_us"]),
        )
        nominal = TARGETS[nearest]["submitted_nominal_high_us"]
        high.update(
            width_target_candidates=[
                tag
                for tag, target in TARGETS.items()
                if in_band(width, target["submitted_nominal_high_us"])
            ],
            nearest_width_target=nearest,
            nearest_width_target_error_us=width - nominal,
            nearest_width_target_ratio=width / nominal,
        )
    channel["unmatched_width_pair_indices"] = [
        row["pair_index"]
        for row in highs
        if not row["width_target_candidates"] and not row["descriptive_long_high"]
    ]
    channel["target_normalized_width_distributions"] = {}
    for tag, target in TARGETS.items():
        rows = [row for row in highs if tag in row["width_target_candidates"]]
        nominal = target["submitted_nominal_high_us"]
        channel["target_normalized_width_distributions"][tag] = {
            "target": target,
            "pair_indices": [row["pair_index"] for row in rows],
            "width_us": raw.stats([row["width_us"] for row in rows]),
            "width_divided_by_target": raw.stats(
                [row["width_us"] / nominal for row in rows]
            ),
            "width_minus_target_us": raw.stats(
                [row["width_us"] - nominal for row in rows]
            ),
        }
    channel["all_width_period_blocks"] = {
        tag: train_blocks(channel, tag) for tag in TARGETS
    }
    return channel


def train_blocks(channel, tag):
    """Retain short blocks too; never merge across an anomalous width/period."""
    target = TARGETS[tag]
    period = 1e6 / target["frequency_hz"]
    blocks, block = [], []
    for high in channel["all_high_runs"]:
        compatible = tag in high["width_target_candidates"]
        connects = block and in_band(
            (high["rise_seconds"] - block[-1]["rise_seconds"]) * 1e6, period
        )
        if not compatible or not connects:
            if block:
                blocks.append(block)
            block = []
        if compatible:
            block.append(high)
    if block:
        blocks.append(block)
    return [
        {
            "tag": tag,
            "pair_indices": [row["pair_index"] for row in rows],
            "pulse_count": len(rows),
            "eligible_minimum_pulses": len(rows) >= MIN_PULSES,
            "begin_seconds": rows[0]["rise_seconds"],
            "end_seconds": rows[-1]["fall_seconds"],
            "high_width_stats_us": raw.stats([row["width_us"] for row in rows]),
            "high_width_target_ratio_stats": raw.stats(
                [row["width_us"] / target["submitted_nominal_high_us"] for row in rows]
            ),
            "period_stats_us": raw.stats(
                [
                    (b["rise_seconds"] - a["rise_seconds"]) * 1e6
                    for a, b in itertools.pairwise(rows)
                ]
            ),
            "period_target_ratio_stats": raw.stats(
                [
                    (b["rise_seconds"] - a["rise_seconds"]) * target["frequency_hz"]
                    for a, b in itertools.pairwise(rows)
                ]
            ),
            "preceding_pair_index": rows[0]["pair_index"] - 1
            if rows[0]["pair_index"]
            else None,
            "following_pair_index": rows[-1]["pair_index"] + 1
            if rows[-1]["pair_index"] + 1 < len(channel["all_high_runs"])
            else None,
        }
        for rows in blocks
    ]


def sibling_facts(channel, begin, end):
    facts = raw.window_facts(channel, begin, end)
    facts["whole_run_boundary_inclusive_low"] = not facts[
        "overlapping_high_pair_indices"
    ]
    return facts


def topology(gpio18, gpio23):
    """Small ordered candidate search, with full-run isolation and extent caveats."""
    channels = {18: gpio18, 23: gpio23}
    ambiguities, selected = [], {}

    def unique(name, candidates):
        if len(candidates) != 1:
            ambiguities.append(
                {
                    "feature": name,
                    "reason": "not_unique",
                    "candidate_count": len(candidates),
                    "candidates": candidates,
                }
            )
            return None
        selected[name] = candidates[0]
        return candidates[0]

    brakes = []
    for a, b in itertools.product(
        gpio18["descriptive_long_high_runs"], gpio23["descriptive_long_high_runs"]
    ):
        begin, end = (
            max(a["rise_seconds"], b["rise_seconds"]),
            min(a["fall_seconds"], b["fall_seconds"]),
        )
        if end - begin >= BRAKE_SECONDS:
            brakes.append(
                {
                    "begin_seconds": begin,
                    "end_seconds": end,
                    "overlap_seconds": end - begin,
                    "gpio18_high": a,
                    "gpio23_high": b,
                }
            )
    brake = unique("joint_brake", brakes)
    if brake:
        servo_cutoff = brake["gpio18_high"]["rise_seconds"]
        servo = [
            unique(
                tag,
                [
                    row
                    for row in gpio18["all_width_period_blocks"][tag]
                    if row["eligible_minimum_pulses"]
                    and row["end_seconds"] < servo_cutoff
                ],
            )
            for tag in ("servo_angle0", "servo_angle90", "servo_angle180")
        ]
        if all(servo) and not all(
            a["end_seconds"] < b["begin_seconds"] for a, b in itertools.pairwise(servo)
        ):
            ambiguities.append(
                {
                    "feature": "servo_order",
                    "reason": "three_unique_trains_not_in_frozen_order",
                }
            )
        full18 = unique(
            "motor_forward_full",
            [
                row
                for row in gpio18["descriptive_long_high_runs"]
                if row["rise_seconds"] > brake["gpio18_high"]["fall_seconds"]
            ],
        )
        full23 = unique(
            "motor_reverse_full",
            [
                row
                for row in gpio23["descriptive_long_high_runs"]
                if row["rise_seconds"] > brake["gpio23_high"]["fall_seconds"]
            ],
        )
        if full18 and full23:
            if not full18["fall_seconds"] < full23["rise_seconds"]:
                ambiguities.append(
                    {
                        "feature": "motor_full_order",
                        "reason": "forward_full_not_before_reverse_full",
                    }
                )
            for name, gpio, begin, end in (
                (
                    "motor_forward_half",
                    18,
                    brake["gpio18_high"]["fall_seconds"],
                    full18["rise_seconds"],
                ),
                (
                    "motor_reverse_half",
                    23,
                    full18["fall_seconds"],
                    full23["rise_seconds"],
                ),
            ):
                if begin < end:
                    unique(
                        name,
                        [
                            row
                            for row in channels[gpio]["all_width_period_blocks"][
                                "motor_half"
                            ]
                            if row["eligible_minimum_pulses"]
                            and begin <= row["begin_seconds"]
                            and row["end_seconds"] <= end
                        ],
                    )
                else:
                    unique(name, [])
        # Any otherwise unassigned ordinary pulse in these candidate extents is
        # visible ambiguity, not permission to choose a central quiet subwindow.
        extents = [
            (
                "servo_full_extent",
                18,
                gpio18["waveform"]["begin_seconds"],
                servo_cutoff,
                [row for row in servo if row],
            )
        ]
        if full18:
            extents.append(
                (
                    "forward_half_full_extent",
                    18,
                    brake["gpio18_high"]["fall_seconds"],
                    full18["rise_seconds"],
                    [selected["motor_forward_half"]]
                    if "motor_forward_half" in selected
                    else [],
                )
            )
        if full18 and full23:
            extents.append(
                (
                    "reverse_half_full_extent",
                    23,
                    full18["fall_seconds"],
                    full23["rise_seconds"],
                    [selected["motor_reverse_half"]]
                    if "motor_reverse_half" in selected
                    else [],
                )
            )
        for name, gpio, begin, end, rows in extents:
            covered = {index for row in rows for index in row["pair_indices"]}
            extra = [
                row["pair_index"]
                for row in channels[gpio]["all_high_runs"]
                if row["rise_seconds"] < end
                and row["fall_seconds"] > begin
                and row["pair_index"] not in covered
            ]
            if extra:
                ambiguities.append(
                    {
                        "feature": name,
                        "reason": "unassigned_boundary_or_fragment_highs",
                        "pair_indices": extra,
                    }
                )
    observations = []
    for name, row in selected.items():
        if name == "joint_brake":
            continue
        gpio = 23 if name.startswith("motor_reverse") else 18
        begin = row.get("begin_seconds", row.get("rise_seconds"))
        end = row.get("end_seconds", row.get("fall_seconds"))
        sibling = sibling_facts(channels[41 - gpio], begin, end)
        if not sibling["whole_run_boundary_inclusive_low"]:
            ambiguities.append(
                {
                    "feature": name,
                    "reason": "sibling_high_overlaps_or_touches_whole_run_boundary",
                    "sibling_high_pair_indices": sibling[
                        "overlapping_high_pair_indices"
                    ],
                }
            )
        observations.append(
            {
                "feature": name,
                "gpio": gpio,
                "candidate": row,
                "own_raw_window": raw.window_facts(channels[gpio], begin, end),
                "sibling_raw_window": sibling,
            }
        )
    expected = (
        "servo_angle0",
        "servo_angle90",
        "servo_angle180",
        "joint_brake",
        "motor_forward_half",
        "motor_forward_full",
        "motor_reverse_half",
        "motor_reverse_full",
    )
    return {
        "compatible_unique_ordered_topology": list(expected)
        if not ambiguities and set(selected) == set(expected)
        else None,
        "selected_candidates": selected,
        "candidate_whole_run_observations": observations,
        "ambiguities": ambiguities,
        "all_joint_long_high_overlap_candidates": brakes,
        "association_scope": "Conditional raw feature identity only; no Pi phase-clock alignment, setter adoption, shutdown instant or electrical actuator safety",
        "final_low_runs": {
            str(gpio): channel["all_low_runs"][-1] for gpio, channel in channels.items()
        },
    }


def validate_capture(directory, plan):
    """Delegate helper/API/ownership exactness; check acquisition linkage here."""
    data = {
        name: collector.read_json((directory / name).read_text())
        for name in (
            "manifest.json",
            "remote.stdout",
            "results.json",
            "acquisition.json",
        )
    }
    manifest, receipt, result, acquisition = (data[name] for name in data)
    hashes = collector.validate_local_manifest(manifest)
    require(len(hashes) == 21, "Exact twenty-one selected source hashes required")
    collector.validate_remote(receipt, manifest)
    require(
        hashes[collector.helper.NEW_SOURCE] == plan["helper_sha256"],
        "Receipt helper differs from frozen plan",
    )
    require(
        result.get("remote") == receipt and result.get("source_manifest") == manifest,
        "Results do not contain the exact stdout/manifest",
    )
    root, python = plan.get("remote_root"), plan.get("remote_python")
    require(
        isinstance(root, str) and isinstance(python, str),
        "Frozen remote runtime required",
    )
    program, remote_manifest = (
        root + "/" + collector.helper.NEW_SOURCE,
        root + "/manifest.json",
    )
    for row in (result, acquisition):
        require(
            type(row.get("remote_returncode")) is int and row["remote_returncode"] == 0,
            "Actual helper SSH exit0 required",
        )
        require(
            all(
                row.get(key) == value
                for key, value in {
                    "mode": collector.MODE,
                    "backend": collector.BACKEND,
                    "remote_root": root,
                    "remote_python": python,
                    "remote_program": program,
                    "pre_helper_lead_seconds": 0.5,
                    "post_helper_tail_seconds": 0.2,
                }.items()
            ),
            "Capture/runtime/lead-tail linkage changed",
        )
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([python, program, "--manifest", remote_manifest]),
    ]
    require(
        acquisition.get("remote_command") == command
        and acquisition.get("remote_manifest") == remote_manifest
        and receipt.get("manifest_path") == remote_manifest
        and receipt.get("python_executable") == python,
        "Actual SSH/runtime/manifest command linkage changed",
    )
    require(
        all(
            acquisition.get(key) == value
            for key, value in {
                "requested_channels": [0, 1],
                "requested_sample_rate_hz": 100_000_000,
                "requested_glitch_filters": [],
                "primary_error": None,
                "evidence_errors": [],
                "ssh_exit_unavailable_after_exception": False,
                "local_timing_not_aligned_to_pi_or_saleae": True,
            }.items()
        ),
        "Acquisition incomplete or wrong physical settings",
    )
    require(
        all(
            result.get(key) == value
            for key, value in {
                "schema_version": 1,
                "host": "test-pi5.local",
                "collection_success": True,
                "sequence_marker": collector.SEQUENCE_MARKER,
                "motor_version": "3.5.0",
                "helper_sha256": plan["helper_sha256"],
                "sample_rate_hz": 100_000_000,
                "original_variable_frequency_default": False,
                "original_percent_nominals": TARGETS,
                "native_backend_executed": False,
                "installed_blinka_compatibility_proven": False,
                "actual_actuators_attached": False,
                "public_deinit_cancels_or_frees_gpio": False,
                "additional_lab_cleanup_required": True,
                "production_backend_unchanged": True,
                "waveform_accepted": None,
                "parity_pass": None,
                "parity_evaluated": False,
                "outputs": [
                    {
                        "gpio": gpio,
                        "saleae_channel": channel,
                        "backend": collector.BACKEND,
                    }
                    for gpio, channel in ((18, 0), (23, 1))
                ],
            }.items()
        ),
        "Collector scope/settings/source contract changed",
    )
    return {
        "selected_source_sha256": hashes,
        "actual_ssh_returncode": 0,
        "receipt_validation": "delegated to capture_lgpio_pwm_consumers.validate_remote / helper.validate_receipt",
        "scope": "Genuine consumer API/readbacks, private request ownership and cleanup receipts; not electrical facts",
        "remote_root": root,
        "remote_python": python,
        "remote_program": program,
    }


def analyze(directory, plan_path=None):
    directory = Path(directory)
    plan, frozen = read_plan(plan_path)
    require(
        directory.name in plan.get("capture_order", []),
        "Capture not declared before collection",
    )
    evidence_names = (
        "manifest.json",
        "remote.stdout",
        "remote.stderr",
        "results.json",
        "acquisition.json",
        "waveform.sal",
        "digital_0.bin",
        "digital_1.bin",
    )
    require(
        all(
            (directory / name).is_file() and not (directory / name).is_symlink()
            for name in evidence_names
        ),
        "Complete regular, non-symlink evidence required",
    )
    receipts = validate_capture(directory, plan)
    sal = raw.validate_sal(directory / "waveform.sal")
    gpio18, gpio23 = [
        retarget(raw.read_channel(directory / f"digital_{channel}.bin"))
        for channel in (0, 1)
    ]
    bounds = [
        (row["waveform"]["begin_seconds"], row["waveform"]["end_seconds"])
        for row in (gpio18, gpio23)
    ]
    require(
        bounds[0] == bounds[1]
        and bounds[0][1] - bounds[0][0]
        >= sum(row[1] for row in collector.helper.SEQUENCE) + 0.7,
        "Matching complete channel bounds and entire protocol plus lead/tail coverage required",
    )
    return {
        "schema_version": 1,
        "capture": directory.name,
        "backend": collector.BACKEND,
        "frozen_plan": frozen,
        "original_percent_nominals": TARGETS,
        "identification_rules": RULES,
        "evidence_sha256": {name: sha256(directory / name) for name in evidence_names},
        "functional_receipts": receipts,
        "saved_sal": sal,
        "raw_channels": {"gpio18_ch0": gpio18, "gpio23_ch1": gpio23},
        "ordered_raw_topology": topology(gpio18, gpio23),
        "limitations": [
            "Diagnostic +/-10% width/period identity bands, not waveform acceptance or numerical parity thresholds.",
            "All transitions, intervals, short trains, anomalies and boundary fragments retained; no central-window trimming.",
            "Pi, local collector and Saleae clocks are unaligned; no exact adoption or deinit timing inferred.",
            "Sampled sibling separation is uncalibrated, not deadtime or actuator-safety evidence.",
            "Public original deinit alone does not cancel/free GPIO; private cleanup proven only by delegated receipts.",
            "In-memory pwmio export with genuine motor3.5.0 is not installed Blinka or actual actuator proof.",
        ],
    }


def write_reports(directories, filename="analysis.json", plan_path=None):
    require(
        isinstance(filename, str)
        and Path(filename).name == filename
        and filename.endswith(".json"),
        "Report must be a plain JSON filename",
    )
    outputs = [Path(directory) / filename for directory in directories]
    require(
        len({str(path.absolute()) for path in outputs}) == len(outputs),
        "Duplicate report outputs",
    )
    require(
        all(not path.exists() and not path.is_symlink() for path in outputs),
        "Exclusive new report outputs required",
    )
    reports = [analyze(directory, plan_path) for directory in directories]
    for output, report in zip(outputs, reports):
        with output.open("x") as handle:
            handle.write(json.dumps(report, indent=2, allow_nan=False) + "\n")
    return reports


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", nargs="+", type=Path)
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output", default="analysis.json")
    args = parser.parse_args(argv)
    reports = write_reports(args.directories, args.output, args.plan)
    print(
        json.dumps(
            [
                {
                    "capture": report["capture"],
                    "ambiguity_count": len(
                        report["ordered_raw_topology"]["ambiguities"]
                    ),
                }
                for report in reports
            ]
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
