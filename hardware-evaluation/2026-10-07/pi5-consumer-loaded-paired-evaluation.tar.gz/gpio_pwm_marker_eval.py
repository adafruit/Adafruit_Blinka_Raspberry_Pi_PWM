"""Fixed GPIO18 PWM/GPIO23 setter-bound experiment; lab only, no parity verdict.

GPIO23 is privately requested through pinned gpiod v2. Its high/low edges bracket
each explicit caller setter, not an exact invocation instant. GPIO/threshold
skew is uncalibrated, and instrumentation changes caller timing. Configuration,
GPIO drivers and production code are otherwise unchanged. The ordinary watchdog
does not bound a stuck native call, SIGKILL, or a hardware fault.
"""

import argparse
import hashlib
import importlib
import importlib.machinery
import importlib.util
import json
import os
import re
import signal
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import native_pwm_updates_eval as native

base = native.base
baseline = base.baseline
core = base.core
BACKENDS = ("native", "lgpio")
BACKEND_NAMES = {"native": base.BACKEND, "lgpio": "original-blinka-lgpio"}
MODE = "electrical-marker-updates"
SEQUENCE_MARKER = "gpio23-setter-bounds-v1"
ROOT_PATTERN = r"/tmp/blinka-pwm-gpio-marker\.[A-Za-z0-9]{6}"
DISTRO = Path("/usr/lib/python3/dist-packages")
MAX_RUN_SECONDS = 14
GPIOD_FILES = (
    "__init__.py",
    "chip.py",
    "line_request.py",
    "line_settings.py",
    "line.py",
)
SOURCE_PINS = {
    **base.PINNED_SOURCES,
    "native_pwm_half50_eval.py": native.BASE_HELPER_SHA256,
    "native_pwm_updates_eval.py": "c55606d9f20e39a81d32a6e27917cec41eb48705957661025ab61be6ec77cba3",
    "baseline_pwmout.py": baseline.PINNED_SOURCES["baseline_pwmout.py"],
    "lgpio_pin.py": baseline.PINNED_SOURCES["lgpio_pin.py"],
}
SOURCE_KEYS = (
    native.SOURCE_KEYS
    | {
        "gpio_pwm_marker_eval.py",
        "baseline_pwmout.py",
        "lgpio_pin.py",
        "lgpio.py",
        "_lgpio.so",
    }
    | {"gpiod/" + name for name in (*GPIOD_FILES, "_ext.so")}
)


def fixed_sequence():
    phases = [("initial_low50", 0.10, 50, 0)]
    for index, (before, recovery, low) in enumerate(
        ((0.073, 0.087, 0.035), (0.087, 0.103, 0.045), (0.103, 0.073, 0.055)), 1
    ):
        phases.extend(
            (
                (f"50_r{index}_ordinary", before, 50, 4915),
                (f"50_r{index}_high", 0.120, 50, 65535),
                (f"50_r{index}_recovery", recovery, 50, 4915),
                (f"50_r{index}_low", low, 50, 0),
            )
        )
    for index, (before, recovery, low) in enumerate(
        ((0.033, 0.037, 0.017), (0.037, 0.041, 0.019), (0.041, 0.033, 0.023)), 1
    ):
        phases.extend(
            (
                (f"500_r{index}_ordinary", before, 500, 32768),
                (f"500_r{index}_high", 0.060, 500, 65535),
                (f"500_r{index}_recovery", recovery, 500, 32768),
                (f"500_r{index}_low", low, 500, 0),
            )
        )
    phases.extend(
        (name, duration, frequency, 32768)
        for name, duration, frequency in (
            ("frequency_r1_to50", 0.093, 50),
            ("frequency_r1_to500", 0.047, 500),
            ("frequency_r2_to50", 0.107, 50),
            ("frequency_r2_to500", 0.051, 500),
            ("frequency_r3_to50", 0.079, 50),
        )
    )
    phases.append(("final_low50", 0.10, 50, 0))
    return tuple(phases)


SEQUENCE = fixed_sequence()


def validate_manifest(manifest):
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
    ):
        raise core.BenchError("Invalid marker selected-source manifest schema")
    hashes = manifest.get("source_sha256")
    if (
        not isinstance(hashes, dict)
        or set(hashes) != SOURCE_KEYS
        or any(
            not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None
            for value in hashes.values()
        )
    ):
        raise core.BenchError("Exact eighteen selected-source SHA256 hashes required")
    if any(hashes[name] != digest for name, digest in SOURCE_PINS.items()):
        raise core.BenchError(
            "Immutable PWM helper/original/core selected-source mismatch"
        )
    return hashes


def load_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise core.BenchError("Duplicate manifest key: " + key)
            result[key] = value
        return result

    manifest = json.loads(Path(path).read_text(), object_pairs_hook=pairs)
    validate_manifest(manifest)
    return manifest


def approved_manifest_path(path):
    path = Path(path)
    if (
        not path.is_absolute()
        or re.fullmatch(ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", str(path)) is None
    ):
        raise core.BenchError(
            "Manifest must be absolute under the isolated gpio-marker root"
        )
    if (
        path.resolve(strict=True) != path
        or path.parent != Path(__file__).resolve().parent
    ):
        raise core.BenchError(
            "Marker helper and manifest must share the isolated root without symlinks"
        )
    return path


@contextmanager
def distro_path():
    previous = sys.path[:]
    sys.path.append(str(DISTRO))
    try:
        yield
    finally:
        sys.path[:] = previous


def extension(package, name):
    paths = list(
        dict.fromkeys(
            (package / (name + suffix)).resolve()
            for suffix in importlib.machinery.EXTENSION_SUFFIXES
            if (package / (name + suffix)).is_file()
        )
    )
    if len(paths) != 1:
        raise core.BenchError("Require one ABI-compatible extension: " + name)
    return paths[0]


def source_inventory():
    # Resolve gpiod BEFORE making distro lgpio visible, to avoid duplicate gpiod.
    spec = importlib.util.find_spec("gpiod")
    if spec is None or spec.origin is None:
        raise core.BenchError("The selected interpreter has no gpiod")
    package = Path(spec.origin).resolve().parent
    paths = {
        "gpio_pwm_marker_eval.py": Path(__file__),
        "native_pwm_updates_eval.py": Path(native.__file__),
        "native_pwm_half50_eval.py": Path(base.__file__),
        "kernel_pwm_lgpio_baseline_eval.py": Path(baseline.__file__),
        "kernel_pwm_eval.py": Path(core.__file__),
        "baseline_pwmout.py": Path(__file__).with_name("baseline_pwmout.py"),
        "lgpio_pin.py": Path(__file__).with_name("lgpio_pin.py"),
        **{"gpiod/" + name: package / name for name in GPIOD_FILES},
        "gpiod/_ext.so": extension(package, "_ext"),
    }
    with distro_path():
        for name, key in (("lgpio", "lgpio.py"), ("_lgpio", "_lgpio.so")):
            module = importlib.util.find_spec(name)
            if (
                module is None
                or module.origin is None
                or Path(module.origin).parent != DISTRO
            ):
                raise core.BenchError(
                    "Require the inspected distro lgpio origin: " + name
                )
            paths[key] = Path(module.origin)
    return paths


def source_hashes():
    return {
        **base.source_hashes(),
        **{
            name: hashlib.sha256(path.read_bytes()).hexdigest()
            for name, path in source_inventory().items()
        },
    }


def load_libraries():
    # Keep this interpreter's gpiod already loaded before exposing distro lgpio.
    library = importlib.import_module("gpiod")
    if getattr(library, "__version__", None) != "2.5.0":
        raise core.BenchError("Only the inspected gpiod v2.5.0 is authorized")
    with distro_path():
        original = baseline.load_lgpio()
        extension_module = importlib.import_module("_lgpio")
    if (
        Path(original.__file__).parent != DISTRO
        or Path(extension_module.__file__).parent != DISTRO
    ):
        raise core.BenchError(
            "Loaded lgpio origins differ from inspected distro sources"
        )
    return library, original


def load_native_api():
    return importlib.import_module(base.PACKAGE)


def inspect(library, identity, offset):
    with library.Chip(identity["gpiochip"]) as chip:
        info, line = chip.get_info(), chip.get_line_info(offset)
        if (
            info.name != Path(identity["gpiochip"]).name
            or info.label != "pinctrl-rp1"
            or type(info.num_lines) is not int
            or info.num_lines <= 23
        ):
            raise core.BenchError("Marker chip is not the verified RP1 controller")
        if (
            type(line.offset) is not int
            or line.offset != offset
            or type(line.used) is not bool
        ):
            raise core.BenchError("Malformed read-only marker/PWM line information")
        return {"name": info.name, "label": info.label, "num_lines": info.num_lines}, {
            "offset": line.offset,
            "name": line.name,
            "used": line.used,
            "consumer": line.consumer,
        }


class Marker:
    def __init__(self, library, identity, guard, receipt):
        self.library, self.identity, self.guard, self.receipt = (
            library,
            identity,
            guard,
            receipt,
        )
        self.request = None
        receipt["marker"] = {
            "gpio": 23,
            "preclaim_line_info": None,
            "owned_request": None,
            "fresh_claim_accepted": False,
            "initial_low_confirmed": False,
            "final_low_confirmed": False,
            "cleanup_final_readback": None,
            "released_line_info": None,
            "gpio23_released": False,
            "read_only_chip_closed": False,
        }

    def claim(self):
        chip, line = inspect(self.library, self.identity, 23)
        self.receipt["marker"].update(
            chip_info=chip, preclaim_line_info=line, read_only_chip_closed=True
        )
        if line["used"] or line["consumer"] not in (None, ""):
            raise core.BenchError("GPIO23 is already claimed; never borrow it")
        with self.guard.atomic():
            self.request = self.library.request_lines(
                self.identity["gpiochip"],
                consumer="blinka-pwm-setter-marker",
                config={
                    23: self.library.LineSettings(
                        direction=self.library.line.Direction.OUTPUT,
                        output_value=self.library.line.Value.INACTIVE,
                    )
                },
            )
            if (
                list(self.request.offsets) != [23]
                or self.request.chip_name != chip["name"]
            ):
                raise core.BenchError(
                    "Marker did not privately claim only verified GPIO23"
                )
            self.receipt["marker"]["owned_request"] = {
                "chip_name": self.request.chip_name,
                "offsets": list(self.request.offsets),
            }
            self.receipt["marker"]["fresh_claim_accepted"] = True
        self.receipt["marker"]["initial_low_confirmed"] = (
            self.request.get_value(23) == self.library.line.Value.INACTIVE
        )
        if not self.receipt["marker"]["initial_low_confirmed"]:
            raise core.BenchError("Fresh privately owned GPIO23 is not inactive")

    def invoke(self, owner, operation, action, arguments):
        event = {
            "ordinal": len(self.receipt["setter_events"]),
            "phase_index": owner.phase_index,
            "scope": owner.scope,
            "operation": operation,
            "arguments": arguments,
            "category": "safety_cleanup"
            if owner.scope in ("safety_cleanup", "extra_safety_cleanup")
            else "sequence",
            "begin_ns": time.monotonic_ns(),
            "marker_high_begin_ns": None,
            "marker_high_end_ns": None,
            "caller_begin_ns": None,
            "caller_end_ns": None,
            "marker_low_begin_ns": None,
            "marker_low_end_ns": None,
            "status": "error",
            "primary_error": None,
            "marker_low_error": None,
        }
        primary = None
        result = None
        try:
            event["marker_high_begin_ns"] = time.monotonic_ns()
            self.request.set_value(23, self.library.line.Value.ACTIVE)
            event["marker_high_end_ns"] = time.monotonic_ns()
            event["caller_begin_ns"] = time.monotonic_ns()
            try:
                result = action()
            finally:
                event["caller_end_ns"] = time.monotonic_ns()
        except BaseException as error:
            primary = error
            event["primary_error"] = f"{type(error).__name__}: {error}"
        finally:
            with self.guard.cleanup():
                event["marker_low_begin_ns"] = time.monotonic_ns()
                try:
                    self.request.set_value(23, self.library.line.Value.INACTIVE)
                except BaseException as error:
                    event["marker_low_error"] = f"{type(error).__name__}: {error}"
                    self.receipt["cleanup_errors"].append(
                        "marker pulse low: " + event["marker_low_error"]
                    )
                    if primary is None:
                        primary = error
                event["marker_low_end_ns"] = time.monotonic_ns()
                event["end_ns"] = time.monotonic_ns()
                if primary is None:
                    event["status"] = "ok"
                self.receipt["setter_events"].append(event)
        if primary is not None:
            raise primary
        return result

    def cleanup(self):
        if self.request is None:
            return

        def attempt(name, action):
            try:
                return action()
            except BaseException as error:
                self.receipt["cleanup_errors"].append(
                    f"marker {name}: {type(error).__name__}: {error}"
                )
                return None

        try:
            if self.receipt["marker"]["fresh_claim_accepted"]:
                attempt(
                    "drive_low",
                    lambda: self.request.set_value(
                        23, self.library.line.Value.INACTIVE
                    ),
                )
                value = attempt("read_low", lambda: self.request.get_value(23))
                inactive = value == self.library.line.Value.INACTIVE
                self.receipt["marker"]["cleanup_final_readback"] = {
                    "gpio_level": getattr(value, "value", None),
                    "inactive": inactive,
                }
                self.receipt["marker"]["final_low_confirmed"] = inactive
                if not inactive:
                    self.receipt["cleanup_errors"].append(
                        "Privately owned GPIO23 inactive not confirmed"
                    )
            else:
                self.receipt["cleanup_errors"].append(
                    "Marker request identity unverified; no GPIO drive/read attempted"
                )
        finally:
            attempt("release", self.request.release)
            self.request = None
            result = attempt(
                "released_line_info", lambda: inspect(self.library, self.identity, 23)
            )
            if result is not None:
                self.receipt["marker"].update(
                    released_line_info=result[1],
                    read_only_chip_closed=True,
                    gpio23_released=result[1]["used"] is False
                    and result[1]["consumer"] in (None, ""),
                )
                if not self.receipt["marker"]["gpio23_released"]:
                    self.receipt["cleanup_errors"].append(
                        "GPIO23 unclaimed after release not confirmed; no reclaim attempted"
                    )


class MarkedCalls:
    phase_index = None

    def call(self, name, operation, arguments=None):
        original_call = super().call
        if name in ("PWMOut.frequency", "PWMOut.duty_cycle", "PWMOut.duty_cycle_zero"):
            if arguments is None:
                arguments = {"frequency": self.pwm.frequency, "duty_u16": 0}
            return self.marker.invoke(
                self, name, lambda: original_call(name, operation, arguments), arguments
            )
        return original_call(name, operation, arguments)


class NativeOwner(MarkedCalls, native.Owner):
    pass


class OriginalOwner(MarkedCalls, baseline.Owner):
    pass


def run_phase(owner, phases, index, name, duration, frequency, duty):
    owner.scope, owner.phase_index = f"{index:02d}_{name}", index
    begin = time.monotonic_ns()
    if owner.pwm.frequency != frequency:
        owner.call(
            "PWMOut.frequency",
            lambda: setattr(owner.pwm, "frequency", frequency),
            {"frequency": frequency, "duty_u16": owner.pwm.duty_cycle},
        )
    if owner.pwm.duty_cycle != duty:
        owner.call(
            "PWMOut.duty_cycle",
            lambda: setattr(owner.pwm, "duty_cycle", duty),
            {"frequency": frequency, "duty_u16": duty},
        )
    stable = time.monotonic_ns()
    phase = {
        "name": name,
        "scope": owner.scope,
        "phase_index": index,
        "frequency": frequency,
        "duty_u16": duty,
        "duration_seconds": duration,
        "begin_ns": begin,
        "transition_begin_ns": begin,
        "stable_begin_ns": stable,
        "api_state": {
            "frequency": owner.pwm.frequency,
            "duty_cycle": owner.pwm.duty_cycle,
        },
    }
    time.sleep(duration)
    phase["end_ns"] = time.monotonic_ns()
    phase["api_state_end"] = {
        "frequency": owner.pwm.frequency,
        "duty_cycle": owner.pwm.duty_cycle,
    }
    phase["readback_end_ns"] = time.monotonic_ns()
    phases.append(phase)


def experiment(backend, manifest_path):
    receipt = {
        "schema_version": 1,
        "mode": MODE,
        "sequence_marker": SEQUENCE_MARKER,
        "backend": BACKEND_NAMES.get(backend),
        "backend_selector": backend,
        "gpio": 18,
        "marker_gpio": 23,
        "helper_pid": os.getpid(),
        "characterization_only": True,
        "production_backend_unchanged": True,
        "parity_pass": None,
        "api_readbacks_are_not_electrical": True,
        "marker_bounds_not_exact_invocation": True,
        "gpio_driver_and_threshold_skew_not_calibrated": True,
        "marker_instrumentation_changes_caller_timing": True,
        "marker_edge_does_not_prove_application_edge": True,
        "selected_source_hashes_not_whole_system_attestation": True,
        "variable_frequency": backend == "native",
        "original_variable_frequency_default": False,
        "runtime_flags": {"short_slice": False, "shared": False},
        "inherited_environment": {
            name: os.environ.get(name)
            for name in ("BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED")
        },
        "watchdog_seconds": MAX_RUN_SECONDS,
        "watchdog_cannot_bound_native_hang_or_sigkill": True,
        "begin_ns": time.monotonic_ns(),
        "source_sha256": {},
        "events": [],
        "setter_events": [],
        "phases": [],
        "before": None,
        "after": None,
        "primary_error": None,
        "cleanup_errors": [],
        "signals_received": [],
        "completed_normally": False,
        "fresh_claim_accepted": False,
        "gpio18_released": False,
        "read_only_chip_closed": False,
        "low_confirmed": False,
        "cleanup_final_readback": None,
        "success": False,
    }
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            if backend not in BACKENDS:
                raise core.BenchError(
                    "Only fixed native and original-lgpio backends are approved"
                )
            manifest_path = approved_manifest_path(manifest_path)
            manifest = load_manifest(manifest_path)
            validate_manifest(manifest)
            receipt["manifest_path"] = str(manifest_path)
            receipt["source_sha256"] = source_hashes()
            if receipt["source_sha256"] != manifest["source_sha256"]:
                raise core.BenchError(
                    "Marker/native/original selected-source hash mismatch"
                )
            if any(value == "1" for value in receipt["inherited_environment"].values()):
                raise core.BenchError("Refusing inherited native shared/short-slice=1")
            receipt["identity"] = baseline.preflight()
            receipt["before"] = core.system_snapshot()
            issues = core.thermal_issues(receipt["before"], 65000)
            if issues:
                raise core.BenchError("Thermal preflight: " + "; ".join(issues))
            library, original = load_libraries()
            receipt["gpiod_version"] = library.__version__
            receipt["lgpio_version"] = original.get_module_version()
            receipt["chip_info"], receipt["preclaim_line_info"] = inspect(
                library, receipt["identity"], 18
            )
            receipt["read_only_chip_closed"] = True
            if receipt["preclaim_line_info"]["used"] or receipt["preclaim_line_info"][
                "consumer"
            ] not in (None, ""):
                raise core.BenchError("GPIO18 is already claimed; never borrow it")
            marker = Marker(library, receipt["identity"], guard, receipt)
            owner = None
            try:
                marker.claim()
                owner_class = NativeOwner if backend == "native" else OriginalOwner
                owner = owner_class(
                    library if backend == "native" else original,
                    receipt["identity"],
                    guard,
                    receipt,
                )
                owner.marker = marker
                if backend == "native":
                    module = load_native_api()
                    owner.construct(module.PWMOut)
                    for index, phase in enumerate(SEQUENCE):
                        run_phase(owner, receipt["phases"], index, *phase)
                    receipt["completed_normally"] = True
                else:
                    with owner.hooks():
                        try:
                            pins = baseline.load_source(
                                baseline.PIN_KEY, "lgpio_pin.py"
                            )
                            module = baseline.load_source(
                                "baseline_pwmout", "baseline_pwmout.py"
                            )
                            owner.pwm = module.PWMOut.__new__(module.PWMOut)
                            owner.call(
                                "PWMOut.__init__",
                                lambda: owner.pwm.__init__(
                                    pins.Pin(18), frequency=50, duty_cycle=0
                                ),
                                {
                                    "gpio": 18,
                                    "frequency": 50,
                                    "duty_u16": 0,
                                    "variable_frequency": False,
                                },
                            )
                            for index, phase in enumerate(SEQUENCE):
                                run_phase(owner, receipt["phases"], index, *phase)
                            receipt["completed_normally"] = True
                        finally:
                            with guard.cleanup():
                                signal.alarm(0)
                                owner.phase_index = None
                                try:
                                    owner.cleanup()
                                except BaseException as error:
                                    receipt["cleanup_errors"].append(
                                        f"PWM cleanup: {type(error).__name__}: {error}"
                                    )
                                finally:
                                    owner = None
            finally:
                with guard.cleanup():
                    signal.alarm(0)
                    try:
                        if owner is not None:
                            owner.phase_index = None
                            try:
                                owner.cleanup()
                            except BaseException as error:
                                receipt["cleanup_errors"].append(
                                    f"PWM cleanup: {type(error).__name__}: {error}"
                                )
                    finally:
                        marker.cleanup()
        except BaseException as error:
            receipt["primary_error"] = f"{type(error).__name__}: {error}"
        finally:
            with guard.cleanup():
                signal.alarm(0)
                try:
                    receipt["after"] = core.system_snapshot()
                    receipt["cleanup_errors"].extend(
                        core.thermal_issues(receipt["after"], 70000)
                    )
                except BaseException as error:
                    receipt["cleanup_errors"].append(
                        f"Thermal postflight: {type(error).__name__}: {error}"
                    )
                receipt["signals_received"] = list(guard.received)
    receipt["end_ns"] = time.monotonic_ns()
    marker_receipt = receipt.get("marker", {})
    receipt["sequence_setter_count"] = sum(
        event["category"] == "sequence" for event in receipt["setter_events"]
    )
    receipt["success"] = bool(
        receipt["completed_normally"]
        and receipt["primary_error"] is None
        and not receipt["cleanup_errors"]
        and not receipt["signals_received"]
        and receipt["fresh_claim_accepted"]
        and receipt["gpio18_released"]
        and receipt["low_confirmed"]
        and all(
            marker_receipt.get(key) is True
            for key in (
                "fresh_claim_accepted",
                "initial_low_confirmed",
                "final_low_confirmed",
                "gpio23_released",
                "read_only_chip_closed",
            )
        )
        and all(event["status"] == "ok" for event in receipt["setter_events"])
        and receipt["end_ns"] - receipt["begin_ns"] < MAX_RUN_SECONDS * 1_000_000_000
    )
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backend", choices=BACKENDS, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    receipt = experiment(args.backend, args.manifest)
    print(json.dumps(receipt, sort_keys=True), flush=True)
    if not receipt["success"]:
        print(
            receipt["primary_error"]
            or "; ".join(receipt["cleanup_errors"])
            or "Marker experiment did not complete",
            file=sys.stderr,
        )
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
