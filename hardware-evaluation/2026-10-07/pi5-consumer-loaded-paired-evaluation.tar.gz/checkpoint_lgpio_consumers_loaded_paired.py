"""Exclusive loaded-paired recovery with four waveform/worker-overlap replays.

Older captures and audits are excluded; their immutable recovery dependencies
and the accepted prior idle postflight chain remain. This script never launches
load, contacts a Pi, acquires data, changes Git, or overwrites evidence. External
independent-method paths/hashes must be supplied before the execution gate opens.
"""

import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path

import checkpoint_lgpio_consumers_paired as paired

LAB = Path(__file__).resolve().parent
PLAN_NAME = "oct7-lgpio-consumers-loaded-plan.json"
PLAN_SHA256 = "1cedb74c5e1ff8531fe7b34d3e8da3aa37643ebc28a1341562db9468a512694b"
CAPTURES = (
    "oct7-pi5-lgpio-consumers-loaded-r1",
    "oct7-pi5-paired-native-consumers-loaded-r1",
    "oct7-pi5-paired-native-consumers-loaded-r2",
    "oct7-pi5-lgpio-consumers-loaded-r2",
)
ARCHIVE = (
    LAB.parent
    / "Adafruit_Blinka_Raspberry_Pi_PWM/hardware-evaluation/2026-10-07/pi5-consumer-loaded-paired-evaluation.tar.gz"
)
VERIFICATION_NAME = "oct7-lgpio-consumers-loaded-paired-checkpoint-verification.json"
# Exact independent method bytes; original paths/output behavior need review
# before reuse. These are provenance, not an instruction to execute the scripts.
AUDIT_SOURCES = {
    "audit-source/raw_audit.py": (
        "/private/tmp/loaded-paired-independent.BY13uN/raw_audit.py",
        "8e4e459c5761a13d4b6e8a634546a63a07861a383420f2a9ef32033b2927e982",
    ),
    "audit-source/reexport_saved_sal.py": (
        "/private/tmp/loaded-paired-independent.BY13uN/reexport_saved_sal.py",
        "8ba660fe94fee6660fb689882b11f58135089052f63a3abe811919897a21f2a0",
    ),
    "audit-source/load_overlap.py": (
        "/private/tmp/loaded-paired-independent.BY13uN/load_overlap.py",
        "35d59e0c8d22be4d98646296a6f6ec4bfcd6a46ab38c7d1c0320a1d49e231381",
    ),
    "audit-source/load_overlap_checks.json": (
        "/private/tmp/loaded-paired-independent.BY13uN/load_overlap_checks.json",
        "6fbac144c9b3296d895e31c1845e73d77b0a6adaa25f8d130583746e7a8a7b46",
    ),
    "audit-source/check_receipts.py": (
        "/private/tmp/paired-loaded-receipts-final.YS17ye/check_receipts.py",
        "dfd3338643080f7835f98fc8e63b9190bd970c79aeee949df89678a3580e9b24",
    ),
    "audit-source/receipt_checks.json": (
        "/private/tmp/paired-loaded-receipts-final.YS17ye/receipt_checks.json",
        "9aad2bc8535d7cd0f2743ceba001ab4b96df86639be4d7813a9f9e7893c88313",
    ),
    "audit-source/export_checks.json": (
        "/private/tmp/loaded-paired-salcheck.BYVXRZ/export_checks.json",
        "1f31980a052e0939ea05641629cb23ff510416c7fd8fafc51d56fb665b932c18",
    ),
    "audit-source/compare_reports.py": (
        "/private/tmp/loaded-paired-report-comparison.An4rpK/compare_reports.py",
        "02ff5804154c65847797025b3b9b6f98061179e50cde6a47bba336532c4ee5aa",
    ),
    "audit-source/compare_receipts.py": (
        "/private/tmp/paired-loaded-final-receipts.M9ejzf/compare_receipts.py",
        "c18c6f221e13e55642ba6f2174b1ff455c2b9018311e25efdb78710d5a2f48e5",
    ),
    "audit-source/comparison_receipts.json": (
        "/private/tmp/paired-loaded-final-receipts.M9ejzf/comparison_receipts.json",
        "450c048a970f63e2199df3717ce32619e1db895b11002ebc1195eb30dc70805f",
    ),
}
DEPENDENCY_PINS = {
    "checkpoint_lgpio_consumers_paired.py": "bf0b11e3ea2fb28cc22c9b6403e378af09232e54560c36ae041ad35c68d3b834",
    "checkpoint_native_consumers.py": "4d7ef9dca9483b2e180361be768fc04b2bc3876ae51f1ef35ba242446f32117e",
}
digest, safe_name, tree_files = paired.digest, paired.safe_name, paired.tree_files
PLAN = json.loads((LAB / PLAN_NAME).read_text())
SOURCE_DEPENDENCIES = sorted(
    {
        name
        for inventory in PLAN["loaded_coordinator_source_sha256"].values()
        for name in inventory
        if name not in paired.idle.helper.CONSUMER_PINS
    }
)
EXCLUDE = set(paired.CAPTURES) | {
    "oct7-lgpio-consumers-paired-independent-audit.json",
    "oct7-lgpio-consumers-paired-final-report-audit.json",
    "oct7-lgpio-consumers-paired-independent-notes.txt",
}
TARGETS = [name for name in paired.TARGETS if name not in EXCLUDE]
for name in (
    SOURCE_DEPENDENCIES
    + [
        "test_capture_native_pwm_consumers_loaded.py",
        "record_lgpio_consumers_loaded_paired_state.py",
        "test_record_lgpio_consumers_loaded_paired_state.py",
        PLAN_NAME,
        "oct7-lgpio-consumers-loaded-paired-preflight.json",
        "oct7-lgpio-consumers-loaded-paired-preflight.json.stdout",
        "oct7-lgpio-consumers-loaded-paired-preflight.json.stderr",
        "oct7-lgpio-consumers-loaded-paired-postflight.json",
        "oct7-lgpio-consumers-loaded-paired-postflight.json.stdout",
        "oct7-lgpio-consumers-loaded-paired-postflight.json.stderr",
        "oct7-lgpio-consumers-loaded-paired-independent-audit.json",
        "oct7-lgpio-consumers-loaded-paired-final-report-audit.json",
        "oct7-lgpio-consumers-loaded-paired-independent-notes.txt",
        "checkpoint_lgpio_consumers_loaded_paired.py",
        "test_checkpoint_lgpio_consumers_loaded_paired.py",
    ]
    + list(CAPTURES)
    + [
        name + suffix
        for name in CAPTURES
        for suffix in (".load.stdout", ".load.stderr", ".consumers-coordination.json")
    ]
):
    if name not in TARGETS:
        TARGETS.append(name)
REPLAY = r"""
import json,pathlib,sys
sys.path.insert(0,sys.argv[1])
import analyze_lgpio_pwm_consumers as original
import analyze_native_pwm_consumers as native
import capture_lgpio_pwm_consumers_loaded as original_loaded
import capture_native_pwm_consumers_loaded as native_loaded
root=pathlib.Path(sys.argv[1])
original_lab=pathlib.Path(sys.argv[2])
plan_path=root/'oct7-lgpio-consumers-loaded-plan.json'
plan=json.loads(plan_path.read_text())
manifests={
    'original':json.loads((root/'oct7-lgpio-consumers-manifest.json').read_text()),
    'native':json.loads((root/'oct7-native-consumers-manifest.json').read_text()),
}
original_count=native_count=overlap_count=0
for name in plan['capture_order']:
    if name.startswith('oct7-pi5-lgpio-consumers-loaded-'):
        saved=json.loads((root/name/'analysis.json').read_text())
        report=original.analyze(root/name,plan_path)
        assert report['frozen_plan']['path']==str(plan_path.resolve()),name
        assert saved['frozen_plan']['path']==str(original_lab/plan_path.name),name
        # Exactly one verified location relocates. All facts and hashes match.
        del report['frozen_plan']['path']
        del saved['frozen_plan']['path']
        key,coordinator,remote_root='original',original_loaded,plan['remote_root']
        original_count+=1
    else:
        saved=json.loads((root/name/'consumer-analysis.json').read_text())
        report=native.analyze(root/name)
        key,coordinator,remote_root='native',native_loaded,plan['native_reference']['remote_root']
        native_count+=1
    assert report==saved,name
    receipt=json.loads((root/(name+'.consumers-coordination.json')).read_text())
    assert receipt['coordination_success'] is True,name
    assert all(type(receipt[k]) is int and receipt[k]==0
               for k in ('consumer_remote_returncode','load_helper_returncode')),name
    assert receipt['source_sha256']==plan['loaded_coordinator_source_sha256'][key],name
    stem=str((root/name).resolve(strict=True))
    assert pathlib.Path(stem).is_absolute(),name
    overlap=coordinator.audit(stem,remote_root,plan['remote_python'],manifests[key])
    assert overlap['accepted'] is True and overlap==receipt['overlap'],name
    overlap_count+=1
assert (original_count,native_count,overlap_count)==(2,2,4)
print(json.dumps({'original_reports_reproduced':original_count,
                  'native_reports_reproduced':native_count,
                  'load_overlap_reports_reproduced':overlap_count,
                  'original_plan_path_only_relocated':True}))
"""


def frozen_inputs(files):
    if digest(LAB / PLAN_NAME) != PLAN_SHA256:
        raise ValueError("Frozen loaded-paired pre-capture plan changed")
    plan = json.loads((LAB / PLAN_NAME).read_text())
    if tuple(plan["capture_order"]) != CAPTURES:
        raise ValueError("Exact four predeclared loaded-paired captures required")
    pins = {
        **DEPENDENCY_PINS,
        "lgpio_pwm_consumers_eval.py": plan["helper_sha256"],
        "capture_lgpio_pwm_consumers.py": plan["collector_sha256"],
        "analyze_lgpio_pwm_consumers.py": plan["analyzer_sha256"],
        "native_pwm_consumers_eval.py": plan["native_reference"]["helper_sha256"],
        "capture_native_pwm_consumers.py": plan["native_reference"]["collector_sha256"],
        "analyze_native_pwm_consumers.py": plan["native_reference"]["analyzer_sha256"],
        "oct7-native-consumers-plan.json": plan["native_reference"][
            "unchanged_protocol_plan_sha256"
        ],
        "oct7-lgpio-consumers-paired-postflight.json": plan["prior_postflight_sha256"],
        "oct7-lgpio-consumers-manifest.json": plan["manifest_sha256"],
        "oct7-native-consumers-manifest.json": plan["native_manifest_sha256"],
        "record_lgpio_consumers_loaded_paired_state.py": plan["state_recorder_sha256"],
        "test_record_lgpio_consumers_loaded_paired_state.py": plan[
            "state_recorder_test_sha256"
        ],
        "capture_lgpio_pwm_consumers_loaded.py": plan["loaded_coordinators_sha256"][
            "original"
        ],
        "capture_native_pwm_consumers_loaded.py": plan["loaded_coordinators_sha256"][
            "native"
        ],
        "kernel_pwm_cpu_load_eval.py": plan["load_source_sha256"],
    }
    for inventory in plan["loaded_coordinator_source_sha256"].values():
        for name, expected in inventory.items():
            key = (
                "consumer-library-source/" + name
                if name in paired.idle.helper.CONSUMER_PINS
                else name
            )
            if key in pins and pins[key] != expected:
                raise ValueError("Conflicting frozen source identity: " + name)
            pins[key] = expected
    if any(files[name] != expected for name, expected in pins.items()):
        raise ValueError("Pre-capture frozen recovery source/plan/manifest changed")
    return plan


def audit_inventory(files):
    """Read-only, fail-closed verification of later supplied method provenance."""
    if not isinstance(AUDIT_SOURCES, dict) or not AUDIT_SOURCES:
        raise ValueError("Independent audit mapping pending; do not checkpoint")
    sources = {}
    for name, (source, expected) in AUDIT_SOURCES.items():
        safe_name(name)
        path = Path(source)
        if (
            not name.startswith("audit-source/")
            or not path.is_absolute()
            or not path.is_file()
            or path.is_symlink()
            or path.resolve(strict=True) != path
            or digest(path) != expected
            or name in files
        ):
            raise ValueError("Independent audit source changed: " + name)
        sources[name] = path
    return sources


def main():
    if digest(LAB / PLAN_NAME) != PLAN_SHA256:
        raise ValueError("Frozen loaded-paired pre-capture plan changed")
    verification = LAB / VERIFICATION_NAME
    if any(path.exists() or path.is_symlink() for path in (ARCHIVE, verification)):
        raise ValueError("Archive and verification outputs must be fresh")
    audit_sources = audit_inventory({})
    files = tree_files(LAB, TARGETS)
    consumers = paired.idle.helper.consumer_inventory()
    for key, path in consumers.items():
        safe_name(key)
        if path.is_symlink() or not path.is_file() or path.resolve(strict=True) != path:
            raise ValueError("Unsupported consumer source: " + key)
        value = digest(path)
        if value != paired.idle.helper.CONSUMER_PINS[key]:
            raise ValueError("Consumer source changed: " + key)
        files["consumer-library-source/" + key] = value
    frozen_inputs(files)
    for name in audit_sources:
        if name in files:
            raise ValueError("Duplicate independent audit member: " + name)
        files[name] = AUDIT_SOURCES[name][1]
    with (
        ARCHIVE.open("xb") as stream,
        tarfile.open(fileobj=stream, mode="w:gz", dereference=True) as archive,
    ):
        for name in TARGETS:
            archive.add(LAB / name, arcname=name)
        for key, path in consumers.items():
            archive.add(path, arcname="consumer-library-source/" + key)
        for name, path in audit_sources.items():
            archive.add(path, arcname=name)
    extracted = Path(
        tempfile.mkdtemp(
            prefix="blinka-consumers-loaded-paired-checkpoint-", dir="/private/tmp"
        )
    )
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        names = set()
        for member in archive.getmembers():
            key = str(safe_name(member.name))
            if key in names or not (member.isfile() or member.isdir()):
                raise ValueError("Duplicate/unsafe archive member: " + member.name)
            names.add(key)
        archive.extractall(extracted, filter="data")
    recovered = tree_files(
        extracted, [path.name for path in sorted(extracted.iterdir())]
    )
    if recovered != files:
        raise ValueError("Archive file set/bytes differ")
    result = subprocess.run(
        [sys.executable, "-I", "-c", REPLAY, str(extracted), str(LAB)],
        cwd=extracted,
        capture_output=True,
        text=True,
        check=True,
        timeout=60,
    )
    report = {
        "archive": str(ARCHIVE),
        "size_bytes": ARCHIVE.stat().st_size,
        "sha256": digest(ARCHIVE),
        "frozen_loaded_paired_plan_sha256": PLAN_SHA256,
        "top_level_targets": len(TARGETS) + 2,
        "regular_files": len(files),
        "safe_extraction": str(extracted),
        "all_file_bytes_match": True,
        "replay": json.loads(result.stdout),
        "replay_stderr": result.stderr,
        "consumer_library_sources": {
            "version": paired.idle.helper.MOTOR_VERSION,
            "selected_files": paired.idle.helper.CONSUMER_PINS,
            "scope": "Three exact executed Python files, not whole-distribution provenance",
        },
        "independent_audit_sources": {
            name: expected for name, (_source, expected) in AUDIT_SOURCES.items()
        },
        "load_metadata_scope": "Actual launcher/worker JSON lines in load.stdout plus coordination receipts; no invented separate metadata or process exits",
        "scope": "Recovery of four loaded-paired functional recordings and actual workload overlap; not CPU saturation, quantitative backend parity or waveform acceptance",
    }
    with verification.open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
