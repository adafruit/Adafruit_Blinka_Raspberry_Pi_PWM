"""Offline, independent overlap audit for the frozen two-worker CPU-only load.

This reads receipts, never executes a load or accesses GPIO/PWM. It creates only
an exclusive load-overlap.json in an existing capture directory. Original
results and waveform predicates remain untouched. Receipt validation cannot
prove the recorder/helper's process exit status, CPU saturation, or alignment
of Pi monotonic timestamps with Saleae waveform edges.
"""

import argparse
import hashlib
import json
from pathlib import Path

LOAD_SOURCE_SHA256 = "0644d9b0e0228bca813e7b3cbb909165e1c313d04baf2405c8f0f78badbc18ca"
WORKER_SOURCE_SHA256 = (
    "430c6552b38acb6a87ee9aca00dfb0df1422969f5d8afea4869af6eac890918d"
)
MODES = ("direct", "frequency", "lifecycle", "half50-direct")
OUTPUT_NAME = "load-overlap.json"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, f"Invalid {label}")
    return value


def _object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def _constant(value):
    raise ValueError(f"Non-finite JSON value: {value}")


def parse_lines(text, count, label):
    require(isinstance(text, str), f"Invalid {label} text")
    require(text.endswith("\n"), f"Partial {label}: missing final newline")
    lines = text.split("\n")[:-1]
    require(len(lines) == count, f"{label} requires exactly {count} JSON lines")
    result = [
        json.loads(line, object_pairs_hook=_object, parse_constant=_constant)
        for line in lines
    ]
    require(all(isinstance(value, dict) for value in result), f"Invalid {label} object")
    return result


def validate_load(launch, completion):
    expected = {
        "schema_version": 1,
        "mode": "cpu-only-fixed-two-workers",
        "worker_count": 2,
        "worker_duration_seconds": 10,
        "source_sha256": LOAD_SOURCE_SHA256,
        "worker_source_sha256": WORKER_SOURCE_SHA256,
        "gpio_writes": False,
        "pwm_sysfs_access": False,
        "kernel_configuration_changes": False,
    }
    for label, receipt in (("launch", launch), ("completion", completion)):
        for key, value in expected.items():
            require(
                type(receipt.get(key)) is type(value) and receipt.get(key) == value,
                f"{label} {key} provenance mismatch",
            )
        integer(receipt.get("launcher_pid"), f"{label} launcher PID", 1)
        integer(receipt.get("begin_ns"), f"{label} begin_ns")
        require(receipt.get("primary_error") is None, f"{label} primary error")
        require(not receipt.get("cleanup_errors"), f"{label} cleanup failure")
        require(not receipt.get("signals_received"), f"{label} termination signal")
    require(launch.get("event") == "load_launched", "Missing launch receipt")
    require(completion.get("event") == "load_completed", "Missing completion receipt")
    require(launch.get("launch_complete") is True, "Partial launch")
    require(
        type(launch.get("started_worker_count")) is int
        and launch["started_worker_count"] == 2,
        "Partial worker launch",
    )
    require(completion.get("success") is True, "Load completion failed")
    require(completion.get("cleanup_errors") == [], "Missing/failed cleanup record")
    require(completion.get("signals_received") == [], "Missing/signal record")
    require("primary_error" in completion, "Missing primary error record")
    require(
        completion.get("receipt_boundary")
        == "after worker cleanup; signals arriving during receipt emission can still fail exit status",
        "Invalid completion receipt boundary",
    )
    require(
        launch["launcher_pid"] == completion["launcher_pid"]
        and launch["begin_ns"] == completion["begin_ns"],
        "Launcher identity/timing mismatch",
    )
    receipt_ns = integer(launch.get("receipt_ns"), "launch receipt_ns")
    end_ns = integer(completion.get("end_ns"), "completion end_ns")
    require(launch["begin_ns"] <= receipt_ns <= end_ns, "Invalid launcher chronology")
    before, after = launch.get("owned_workers"), completion.get("owned_workers")
    require(
        isinstance(before, list)
        and isinstance(after, list)
        and len(before) == len(after) == 2,
        "Requires two owned worker records in each receipt",
    )
    workers, pids = [], {launch["launcher_pid"]}
    previous_spawn_end = launch["begin_ns"]
    for index, (started_record, record) in enumerate(zip(before, after)):
        require(
            isinstance(started_record, dict) and isinstance(record, dict),
            "Invalid owned worker object",
        )
        for key in ("index", "pid", "popen_begin_ns", "popen_end_ns"):
            integer(record.get(key), f"worker {index} {key}", 1 if key == "pid" else 0)
            require(
                type(started_record.get(key)) is int
                and started_record[key] == record[key],
                f"worker {index} launch/completion {key} mismatch",
            )
        require(record["index"] == index, "Invalid worker index/order")
        require(record["pid"] not in pids, "Duplicate worker/launcher PID")
        pids.add(record["pid"])
        require(
            previous_spawn_end
            <= record["popen_begin_ns"]
            <= record["popen_end_ns"]
            <= receipt_ns,
            f"worker {index} invalid spawn chronology",
        )
        previous_spawn_end = record["popen_end_ns"]
        require(
            started_record.get("reaped") is False
            and "returncode" in started_record
            and started_record["returncode"] is None
            and "completed_ns" in started_record
            and started_record["completed_ns"] is None
            and started_record.get("worker_receipts") == [],
            f"worker {index} invalid launch ownership state",
        )
        require(
            record.get("reaped") is True
            and type(record.get("returncode")) is int
            and record["returncode"] == 0,
            f"worker {index} not successfully reaped",
        )
        require(record.get("stderr") == "", f"worker {index} stderr present/missing")
        require(
            "receipt_error" not in record
            and "terminate_requested_ns" not in record
            and "kill_requested_ns" not in record,
            f"worker {index} cleanup/receipt failure",
        )
        reports = parse_lines(record.get("stdout"), 2, f"worker {index} stdout")
        require(
            isinstance(record.get("worker_receipts"), list)
            and json.dumps(reports, sort_keys=True)
            == json.dumps(record["worker_receipts"], sort_keys=True),
            f"worker {index} raw/parsed receipt mismatch",
        )
        start, finish = reports
        require(
            set(start) == {"event", "pid", "begin_ns", "duration_seconds"}
            and set(finish)
            == {"event", "pid", "begin_ns", "end_ns", "iterations", "duration_seconds"},
            f"worker {index} unexpected receipt fields",
        )
        require(
            start.get("event") == "worker_started"
            and finish.get("event") == "worker_completed",
            f"worker {index} missing start/completion",
        )
        for label, report in (("started", start), ("completed", finish)):
            require(
                type(report.get("pid")) is int and report["pid"] == record["pid"],
                f"worker {index} {label} PID mismatch",
            )
            require(
                type(report.get("duration_seconds")) is int
                and report["duration_seconds"] == 10,
                f"worker {index} {label} duration mismatch",
            )
            integer(report.get("begin_ns"), f"worker {index} {label} begin_ns")
        begin = start["begin_ns"]
        finish_ns = integer(finish.get("end_ns"), f"worker {index} end_ns")
        iterations = integer(finish.get("iterations"), f"worker {index} iterations", 1)
        collected = integer(record.get("completed_ns"), f"worker {index} completed_ns")
        require(
            record["popen_begin_ns"] <= begin
            and finish["begin_ns"] == begin
            and finish_ns - begin >= 10_000_000_000
            and receipt_ns <= collected
            and finish_ns <= collected <= end_ns,
            f"worker {index} invalid actual interval/collection chronology",
        )
        workers.append(
            {
                "index": index,
                "pid": record["pid"],
                "popen_begin_ns": record["popen_begin_ns"],
                "popen_end_ns": record["popen_end_ns"],
                "begin_ns": begin,
                "end_ns": finish_ns,
                "elapsed_ns": finish_ns - begin,
                "iterations": iterations,
                "reaped_ns": collected,
                "returncode": 0,
                "reaped": True,
            }
        )
    return workers


def validate_pwm(remote):
    require(
        type(remote.get("schema_version")) is int and remote["schema_version"] == 1,
        "Invalid PWM schema",
    )
    require(remote.get("mode") in MODES, "Unsupported PWM helper mode")
    integer(remote.get("helper_pid"), "PWM helper PID", 1)
    begin = integer(remote.get("begin_ns"), "PWM helper begin_ns")
    end = integer(remote.get("end_ns"), "PWM helper end_ns")
    require(begin < end, "Invalid PWM helper interval")
    require(
        remote.get("sysfs_released") is True
        and remote.get("low_confirmed") is True
        and remote.get("cleanup_errors") == [],
        "PWM helper cleanup not confirmed",
    )
    require(remote.get("burner_pids") == [], "Unexpected PWM-helper-owned burners")
    phases = remote.get("phases")
    require(isinstance(phases, list) and phases, "Missing PWM phases")
    previous, intervals = begin, []
    names = set()
    for index, phase in enumerate(phases):
        require(isinstance(phase, dict), "Invalid PWM phase object")
        name = phase.get("name")
        require(
            isinstance(name, str) and name and name not in names,
            "Missing/duplicate PWM phase name",
        )
        names.add(name)
        generation = integer(phase.get("generation"), f"phase {index} generation", 1)
        times = [
            integer(phase.get(key), f"phase {index} {key}")
            for key in ("begin_ns", "stable_begin_ns", "end_ns", "readback_end_ns")
        ]
        require(
            previous <= times[0] <= times[1] <= times[2] <= times[3] <= end
            and phase.get("transition_begin_ns") == times[0]
            and type(phase.get("transition_begin_ns")) is int,
            f"phase {index} invalid chronology",
        )
        previous = times[3]
        intervals.append(
            {
                "name": name,
                "generation": generation,
                "begin_ns": times[0],
                "readback_end_ns": times[3],
            }
        )
    return intervals


def interval_overlap(worker, begin, end):
    overlap = max(0, min(worker["end_ns"], end) - max(worker["begin_ns"], begin))
    return {
        "begin_ns": begin,
        "end_ns": end,
        "duration_ns": end - begin,
        "overlap_ns": overlap,
        "bracketed": worker["begin_ns"] <= begin and worker["end_ns"] >= end,
        "start_margin_ns": begin - worker["begin_ns"],
        "end_margin_ns": worker["end_ns"] - end,
    }


def analyze(load_stdout, capture_directory):
    load_stdout, capture_directory = Path(load_stdout), Path(capture_directory)
    remote_stdout = capture_directory / "remote.stdout"
    load_bytes, remote_bytes = load_stdout.read_bytes(), remote_stdout.read_bytes()
    launch, completion = parse_lines(load_bytes.decode("utf-8"), 2, "load stdout")
    (remote,) = parse_lines(remote_bytes.decode("utf-8"), 1, "PWM remote stdout")
    workers = validate_load(launch, completion)
    phases = validate_pwm(remote)
    require(
        remote["helper_pid"]
        not in {launch["launcher_pid"], *(w["pid"] for w in workers)},
        "PWM/load process identities collide",
    )
    reasons = []
    for worker in workers:
        worker["phase_overlaps"] = [
            {
                "name": phase["name"],
                "generation": phase["generation"],
                **interval_overlap(worker, phase["begin_ns"], phase["readback_end_ns"]),
            }
            for phase in phases
        ]
        worker["all_phases_bracketed"] = all(
            item["bracketed"] for item in worker["phase_overlaps"]
        )
        worker["entire_helper_overlap"] = interval_overlap(
            worker, remote["begin_ns"], remote["end_ns"]
        )
        reasons.extend(
            f"Worker {worker['index']} did not bracket phase {item['name']}"
            for item in worker["phase_overlaps"]
            if not item["bracketed"]
        )
    return {
        "schema_version": 1,
        "audit": "independent-external-cpu-load-overlap",
        "offline_analysis": True,
        "accepted": not reasons,
        "acceptance_scope": "receipt provenance and every PWM phase begin-to-readback-end overlap only",
        "rejection_reasons": reasons,
        "capture": capture_directory.name,
        "mode": remote["mode"],
        "inputs": {
            "load_stdout": {
                "path": str(load_stdout.resolve()),
                "sha256": hashlib.sha256(load_bytes).hexdigest(),
            },
            "remote_stdout": {
                "path": str(remote_stdout.resolve()),
                "sha256": hashlib.sha256(remote_bytes).hexdigest(),
            },
        },
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "load_source_sha256": LOAD_SOURCE_SHA256,
        "worker_source_sha256": WORKER_SOURCE_SHA256,
        "launcher_pid": launch["launcher_pid"],
        "launcher_begin_ns": launch["begin_ns"],
        "launch_receipt_ns": launch["receipt_ns"],
        "launcher_end_ns": completion["end_ns"],
        "worker_count": 2,
        "worker_duration_seconds": 10,
        "workers": workers,
        "all_phases_bracketed_by_each_worker": not reasons,
        "entire_helper_bracketed_by_each_worker": all(
            worker["entire_helper_overlap"]["bracketed"] for worker in workers
        ),
        "pwm_helper_pid": remote["helper_pid"],
        "pwm_helper_begin_ns": remote["begin_ns"],
        "pwm_helper_end_ns": remote["end_ns"],
        "pwm_helper_burner_pids": remote["burner_pids"],
        "burner_pid_semantics": "empty PWM-helper burner_pids means it started none; external owned workers are reported independently",
        "gpio_writes": False,
        "pwm_sysfs_access": False,
        "kernel_configuration_changes": False,
        "recorder_exit_zero_required": True,
        "recorder_exit_status_verified": False,
        "pwm_helper_exit_zero_required": True,
        "pwm_helper_exit_status_verified": False,
        "original_results_or_waveform_predicates_modified": False,
        "limitations": [
            "Recorder/remote-helper exit0 must be independently checked; receipt JSON cannot prove it, including signals during final receipt emission.",
            "Clock comparison assumes matching same-host, same-boot Pi monotonic clocks; receipts do not carry a boot identity.",
            "Actual worker intervals and positive iterations show recorded concurrent CPU work, not CPU saturation, scheduling fairness or continuous execution.",
            "Pi timestamps are not aligned to Saleae edges; this is not edge-command alignment or electrical proof.",
            "PWM source provenance and waveform acceptance remain separate frozen capture-analyzer checks; this audit does not reclassify them.",
        ],
    }


def write_analysis(load_stdout, capture_directory):
    report = analyze(load_stdout, capture_directory)
    with (Path(capture_directory) / OUTPUT_NAME).open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("load_stdout", type=Path)
    parser.add_argument("capture_directory", type=Path)
    args = parser.parse_args(argv)
    try:
        report = write_analysis(args.load_stdout, args.capture_directory)
    except (ValueError, OSError, UnicodeError) as error:
        parser.error(str(error))
    print(json.dumps(report, indent=2))
    return 0 if report["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
