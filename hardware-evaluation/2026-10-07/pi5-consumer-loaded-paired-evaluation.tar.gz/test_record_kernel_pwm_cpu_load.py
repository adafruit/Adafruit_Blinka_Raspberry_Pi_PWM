"""Local fake-process evidence recording tests; never start SSH or load."""

import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest

SCRIPT = Path(__file__).with_name("record_kernel_pwm_cpu_load.py")
spec = importlib.util.spec_from_file_location("record_kernel_pwm_cpu_load", SCRIPT)
recorder = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = recorder
spec.loader.exec_module(recorder)
REMOTE_ROOT = "/tmp/blinka-pwm-oct6.ABC123/cpu-load-eval"


@pytest.fixture(autouse=True)
def exclusive_tmp_workdir(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)


def forbid_process(monkeypatch):
    calls = []

    def fail(*args, **kwargs):
        calls.append((args, kwargs))
        raise AssertionError(
            "No process may start on validation/exclusive-open failure"
        )

    monkeypatch.setattr(recorder.subprocess, "Popen", fail)
    return calls


@pytest.mark.parametrize("stem", ["", "../escape", "a/b", "a.b", "a;command", "a b"])
def test_invalid_stem_refused_before_any_files_or_process(stem, monkeypatch):
    calls = forbid_process(monkeypatch)
    with pytest.raises(ValueError, match="exclusive receipt stem"):
        recorder.record(stem, REMOTE_ROOT)
    assert calls == [] and list(Path.cwd().iterdir()) == []


@pytest.mark.parametrize(
    "remote_root",
    [
        "/tmp/other.ABC123/cpu-load-eval",
        "/tmp/blinka-pwm-oct6.ABC12/cpu-load-eval",
        "/tmp/blinka-pwm-oct6.ABC123/other-helper",
        "/tmp/blinka-pwm-oct6.ABC123/cpu-load-eval/",
        "/tmp/blinka-pwm-oct6.ABC123/cpu-load-eval;echo bad",
        "tmp/blinka-pwm-oct6.ABC123/cpu-load-eval",
    ],
)
def test_invalid_root_refused_before_files_or_process(remote_root, monkeypatch):
    calls = forbid_process(monkeypatch)
    with pytest.raises(ValueError, match="CPU-only helper directory"):
        recorder.record("capture", remote_root)
    assert calls == [] and list(Path.cwd().iterdir()) == []


@pytest.mark.parametrize("existing_suffix", ["stdout", "stderr"])
def test_existing_evidence_is_never_overwritten_or_followed_by_invocation(
    existing_suffix, monkeypatch
):
    calls = forbid_process(monkeypatch)
    existing = Path(f"capture.load.{existing_suffix}")
    existing.write_text("existing evidence\n")
    with pytest.raises(FileExistsError):
        recorder.record("capture", REMOTE_ROOT)
    assert existing.read_text() == "existing evidence\n" and calls == []


def fake_process(
    monkeypatch, *, returncode=0, chunks=None, stall=False, need_kill=False
):
    launched = {
        "event": "load_launched",
        "launcher_pid": 1234,
        "started_worker_count": 2,
        "launch_complete": True,
    }
    completed = {
        "event": "load_completed",
        "launcher_pid": 1234,
        "worker_count": 2,
        "success": returncode == 0,
    }
    lines = [
        (json.dumps(launched) + "\n").encode(),
        (json.dumps(completed) + "\n").encode(),
    ]
    chunks = list(lines if chunks is None else chunks)
    if not stall:
        chunks.append(b"")
    calls = []
    received = []

    class Pipe:
        closed = False

        def fileno(self):
            return 123

        def close(self):
            self.closed = True

    class Process:
        def __init__(self):
            self.wait_calls = []
            self.returncode = None
            self.terminated = False
            self.killed = False
            self.stdout = Pipe()

        def wait(self, timeout):
            self.wait_calls.append(timeout)
            if need_kill and self.terminated and not self.killed:
                raise subprocess.TimeoutExpired("fake owned SSH", timeout)
            self.returncode = returncode
            return returncode

        def poll(self):
            return self.returncode

        def terminate(self):
            self.terminated = True

        def kill(self):
            self.killed = True

    process = Process()

    def create(command, **kwargs):
        calls.append((command, kwargs))
        kwargs["stderr"].write(b"fake helper diagnostic\n")
        kwargs["stderr"].flush()
        return process

    monkeypatch.setattr(recorder.subprocess, "Popen", create)

    class Selector:
        def __enter__(self):
            return self

        def __exit__(self, *_exc):
            pass

        def register(self, pipe, event):
            assert pipe is process.stdout and event == recorder.selectors.EVENT_READ

        def select(self, timeout):
            assert 0 < timeout <= 1
            return [(None, recorder.selectors.EVENT_READ)] if chunks else []

    def read(fd, size):
        assert fd == 123 and size == 4096
        # Check persistence before every subsequent read, including EOF.
        assert Path("capture.load.stdout").read_bytes() == b"".join(received)
        chunk = chunks.pop(0)
        received.append(chunk)
        return chunk

    monkeypatch.setattr(recorder.selectors, "DefaultSelector", Selector)
    monkeypatch.setattr(recorder.os, "read", read)
    return process, calls, lines


def test_two_receipts_are_persisted_flushed_and_only_fixed_helper_is_invoked(
    monkeypatch, capsys
):
    process, calls, lines = fake_process(monkeypatch)
    recorder.record("capture", REMOTE_ROOT)
    assert len(calls) == 1
    command, kwargs = calls[0]
    assert command == [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        "/usr/bin/python3 /tmp/blinka-pwm-oct6.ABC123/cpu-load-eval/kernel_pwm_cpu_load_eval.py",
    ]
    assert kwargs["stdin"] == subprocess.DEVNULL
    assert kwargs["stdout"] == subprocess.PIPE and "text" not in kwargs
    assert Path("capture.load.stdout").read_bytes() == b"".join(lines)
    assert Path("capture.load.stderr").read_text() == "fake helper diagnostic\n"
    assert kwargs["stderr"].closed and process.stdout.closed
    assert len(process.wait_calls) == 1 and 0 < process.wait_calls[0] <= 25
    assert not process.terminated and not process.killed
    summaries = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert summaries == [
        {
            "event": "load_launched",
            "launcher_pid": 1234,
            "worker_count": 2,
            "success": None,
        },
        {
            "event": "load_completed",
            "launcher_pid": 1234,
            "worker_count": 2,
            "success": True,
        },
    ]


@pytest.mark.parametrize("returncode", [1, -15])
def test_nonzero_helper_retains_both_evidence_artifacts(monkeypatch, returncode):
    process, calls, lines = fake_process(monkeypatch, returncode=returncode)
    with pytest.raises(RuntimeError, match="receipts retained"):
        recorder.record("capture", REMOTE_ROOT)
    assert len(calls) == 1 and process.stdout.closed
    assert Path("capture.load.stdout").read_bytes() == b"".join(lines)
    assert Path("capture.load.stderr").read_text() == "fake helper diagnostic\n"


@pytest.mark.parametrize("malformed", [b"not JSON\n", b"[]\n", b"\xff\n"])
def test_malformed_first_receipt_does_not_lose_completion_evidence(
    monkeypatch, capsys, malformed
):
    completion = b'{"event":"load_completed","success":true}\n'
    process, _calls, _lines = fake_process(monkeypatch, chunks=[malformed, completion])
    with pytest.raises(RuntimeError, match="Malformed/partial"):
        recorder.record("capture", REMOTE_ROOT)
    assert Path("capture.load.stdout").read_bytes() == malformed + completion
    summaries = [json.loads(line) for line in capsys.readouterr().out.splitlines()]
    assert len(summaries) == 1 and summaries[0]["event"] == "load_completed"
    assert process.stdout.closed and process.returncode == 0


def test_split_receipts_and_partial_final_bytes_are_retained(monkeypatch):
    first = b'{"event":"load_launched"}\n'
    partial = b'{"event":"load_completed"'
    process, _calls, _lines = fake_process(
        monkeypatch, chunks=[first[:8], first[8:] + partial]
    )
    with pytest.raises(RuntimeError, match="Malformed/partial"):
        recorder.record("capture", REMOTE_ROOT)
    assert Path("capture.load.stdout").read_bytes() == first + partial
    assert process.stdout.closed


@pytest.mark.parametrize("need_kill", [False, True])
def test_stalled_stream_deadline_preserves_launch_and_bounds_owned_ssh_cleanup(
    monkeypatch, need_kill
):
    launch = b'{"event":"load_launched"}\n'
    process, _calls, _lines = fake_process(
        monkeypatch,
        chunks=[launch],
        stall=True,
        need_kill=need_kill,
    )
    ticks = iter([0.0, 0.0, 0.0, 26.0])
    monkeypatch.setattr(recorder.time, "monotonic", lambda: next(ticks))
    with pytest.raises(TimeoutError, match="exceeded 25 seconds"):
        recorder.record("capture", REMOTE_ROOT)
    assert Path("capture.load.stdout").read_bytes() == launch
    assert Path("capture.load.stderr").read_bytes() == b"fake helper diagnostic\n"
    assert process.terminated and process.killed == need_kill and process.stdout.closed
    assert process.wait_calls == ([0.75, 0.75] if need_kill else [0.75])


def test_callback_runs_once_after_persistence_before_draining_completion(monkeypatch):
    launch = b'{"event":"load_launched"}\n'
    completion = b'{"event":"load_completed"}\n'
    process, _calls, _lines = fake_process(
        monkeypatch, chunks=[launch, launch, completion]
    )
    callbacks = []

    def callback(value):
        assert Path("capture.load.stdout").read_bytes() == launch
        callbacks.append(value)

    assert recorder.record("capture", REMOTE_ROOT, launch_callback=callback) == 0
    assert callbacks == [{"event": "load_launched"}]
    assert Path("capture.load.stdout").read_bytes() == launch + launch + completion
    assert process.returncode == 0 and process.stdout.closed


def test_callback_error_does_not_mask_later_load_evidence_or_cleanup(monkeypatch):
    process, _calls, lines = fake_process(monkeypatch)

    def callback(_value):
        raise ValueError("capture callback failed")

    with pytest.raises(ValueError, match="capture callback failed"):
        recorder.record("capture", REMOTE_ROOT, launch_callback=callback)
    assert Path("capture.load.stdout").read_bytes() == b"".join(lines)
    assert process.returncode == 0 and process.stdout.closed


def test_nonzero_load_error_exposes_distinct_helper_returncode(monkeypatch):
    fake_process(monkeypatch, returncode=7)
    with pytest.raises(recorder.LoadRecordingError) as error:
        recorder.record("capture", REMOTE_ROOT)
    assert error.value.returncode == 7
