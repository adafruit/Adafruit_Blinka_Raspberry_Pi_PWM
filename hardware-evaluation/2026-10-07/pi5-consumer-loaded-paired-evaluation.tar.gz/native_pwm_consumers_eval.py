"""Passive-probe-only Servo/DCMotor integration using genuine native PWMOut.

An in-memory pwmio export is a planned-integration shim, not proof of installed
Blinka compatibility. Genuine motor 3.5.0 classes receive unwrapped public PWM
objects; neither consumers nor GPIO/scheduling code are patched. No actuators
are attached. API readbacks are not electrical/physical motion measurements.
"""

import argparse
import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import math
import os
import re
import signal
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from types import ModuleType

import native_pwm_dual_eval as dual

core = dual.core
BACKEND = dual.BACKEND
MODE = "live-consumer-passive-probes"
SEQUENCE_MARKER = "native-servo-dcmotor-v1"
ROOT_PATTERN = r"/tmp/blinka-pwm-native-consumers\.[A-Za-z0-9]{6}"
MOTOR_VERSION = "3.5.0"
NEW_SOURCE = "native_pwm_consumers_eval.py"
MAX_RUN_SECONDS = dual.MAX_RUN_SECONDS
CONSUMER_PINS = {
    "adafruit_motor/__init__.py": "21975233204360bf1495db2b1bcceb8e3c1dc1232f2fc6fcc9ce06ba4deaae05",
    "adafruit_motor/servo.py": "8881b267bb6da5ad9f7e04b942dd3e71ebaede49543b75be37a5bd86043ec5e8",
    "adafruit_motor/motor.py": "caf0b4913550e4103f59f92e656992530b24d338e6ee080a8fc40974e84d48d9",
}
SOURCE_PINS = {
    **dual.SOURCE_PINS,
    **CONSUMER_PINS,
    "native_pwm_dual_eval.py": "4d051ad2f4378a7aaaa4f45b89098f6766f4197362ba7a353970c94630c8b93b",
}
SOURCE_KEYS = dual.SOURCE_KEYS | {NEW_SOURCE} | set(CONSUMER_PINS)
OUTPUTS = (
    ("servo18-g1", 18, 1, 50),
    ("motor18-g2", 18, 2, 1000),
    ("motor23-g1", 23, 1, 1000),
)
SEQUENCE = (
    ("servo_initial_low", 0.10, "servo_initialize", None),
    ("servo_angle0", 0.40, "Servo.angle", 0),
    ("servo_angle90", 0.40, "Servo.angle", 90),
    ("servo_angle180", 0.40, "Servo.angle", 180),
    ("servo_disable", 0.15, "Servo.angle", None),
    ("servo_release", 0.15, "servo_release", None),
    ("motor_initial_low", 0.10, "motor_initialize", None),
    ("motor_brake", 0.20, "DCMotor.throttle", 0),
    ("motor_forward_half", 0.35, "DCMotor.throttle", 0.5),
    ("motor_forward_full", 0.20, "DCMotor.throttle", 1),
    ("motor_reverse_half", 0.35, "DCMotor.throttle", -0.5),
    ("motor_reverse_full", 0.20, "DCMotor.throttle", -1),
    ("motor_disable", 0.15, "DCMotor.throttle", None),
    ("motor_release_positive", 0.15, "motor_release_positive", None),
    ("motor_release_negative", 0.15, "motor_release_negative", None),
)


def servo_duty(angle):
    minimum = int(1000 * 50 / 1_000_000 * 65535)
    span = int(2000 * 50 / 1_000_000 * 65535 - minimum)
    return 0 if angle is None else minimum + int(angle / 180 * span)


def servo_readback(angle):
    return (
        None
        if angle is None
        else 180
        * (servo_duty(angle) - servo_duty(0))
        / (servo_duty(180) - servo_duty(0))
    )


def motor_duties(throttle):
    if throttle is None:
        return 0, 0
    if throttle == 0:
        return 65535, 65535  # Intentional consumer braking state.
    duty = int(65535 * abs(throttle))
    return (0, duty) if throttle < 0 else (duty, 0)


def readback_matches(actual, expected):
    if expected is None:
        return actual is None
    return (
        type(actual) in (int, float)
        and math.isfinite(actual)
        and math.isclose(actual, expected, rel_tol=0, abs_tol=1e-9)
    )


def validate_manifest(manifest):
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
        or manifest.get("motor_version") != MOTOR_VERSION
    ):
        raise core.BenchError("Motor 3.5.0 selected-source manifest required")
    hashes = manifest.get("source_sha256")
    if (
        not isinstance(hashes, dict)
        or set(hashes) != SOURCE_KEYS
        or any(
            not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None
            for value in hashes.values()
        )
    ):
        raise core.BenchError("Exact eighteen selected-source hashes required")
    if any(hashes[key] != digest for key, digest in SOURCE_PINS.items()):
        raise core.BenchError("Frozen native/consumer/helper source mismatch")
    return hashes


def load_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise core.BenchError("Duplicate manifest key: " + key)
            result[key] = value
        return result

    manifest = json.loads(Path(path).read_text(), object_pairs_hook=pairs)
    validate_manifest(manifest)
    return manifest


def approved_manifest_path(path):
    path = Path(path)
    if (
        not path.is_absolute()
        or re.fullmatch(ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", str(path)) is None
    ):
        raise core.BenchError(
            "Manifest must be absolute under the isolated consumers root"
        )
    if (
        path.resolve(strict=True) != path
        or path.parent != Path(__file__).resolve().parent
    ):
        raise core.BenchError(
            "Consumer helper and manifest must share the isolated root without symlinks"
        )
    return path


def consumer_inventory():
    distribution = importlib.metadata.distribution("adafruit-circuitpython-motor")
    spec = importlib.util.find_spec("adafruit_motor")
    if distribution.version != MOTOR_VERSION or spec is None or spec.origin is None:
        raise core.BenchError("Require the inspected installed motor 3.5.0")
    package = Path(spec.origin).resolve().parent
    paths = {key: package / Path(key).name for key in CONSUMER_PINS}
    if any(
        Path(distribution.locate_file(key)).resolve() != path.resolve()
        for key, path in paths.items()
    ):
        raise core.BenchError("Motor metadata and selected Python sources disagree")
    return paths


def source_hashes():
    return {
        **dual.source_hashes(),
        NEW_SOURCE: hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        **{
            key: hashlib.sha256(path.read_bytes()).hexdigest()
            for key, path in consumer_inventory().items()
        },
    }


@contextmanager
def consumer_api(pwm_class, receipt, guard):
    names = ("pwmio", "adafruit_motor", "adafruit_motor.servo", "adafruit_motor.motor")
    if any(name in sys.modules for name in names):
        raise core.BenchError("Refusing preexisting pwmio or consumer modules")
    shim = ModuleType("pwmio")
    shim.PWMOut = pwm_class
    shim.__all__ = ["PWMOut"]
    receipt["integration_shim"] = {
        "kind": "in-memory-pwmio-export",
        "unwrapped_public_pwm_objects": True,
        "installed_blinka_compatibility_proven": False,
        "installed_pwmio_module_used": False,
        "restored": False,
    }
    sys.modules["pwmio"] = shim
    try:
        paths = consumer_inventory()
        servo, motor = (
            importlib.import_module("adafruit_motor.servo"),
            importlib.import_module("adafruit_motor.motor"),
        )
        if any(
            getattr(module, "__version__", None) != MOTOR_VERSION
            or Path(module.__file__).resolve() != paths[key].resolve()
            for module, key in (
                (servo, "adafruit_motor/servo.py"),
                (motor, "adafruit_motor/motor.py"),
            )
        ):
            raise core.BenchError(
                "Loaded genuine motor consumer origin/version mismatch"
            )
        receipt["consumers"] = {
            "distribution": "adafruit-circuitpython-motor",
            "version": MOTOR_VERSION,
            "source_paths": {key: str(path.resolve()) for key, path in paths.items()},
            "servo": {
                "actuation_range": 180,
                "min_pulse_us": 1000,
                "max_pulse_us": 2000,
            },
            "motor": {
                "decay_mode": motor.FAST_DECAY,
                "throttle_zero_is_both_high_brake": True,
            },
        }
        yield servo, motor
    finally:
        with guard.cleanup():
            for name in reversed(names):
                sys.modules.pop(name, None)
            receipt["integration_shim"]["restored"] = True


class Owner(dual.Owner):
    def __init__(self, library, identity, guard, receipt, output_id):
        # Only the new fixed constructor records differ; all request identity,
        # snapshots, public construction, caller instrumentation and cleanup
        # are inherited unchanged from the frozen dual owner.
        dual.base.Owner.__init__(self, library, identity, guard, receipt)
        matches = [row for row in OUTPUTS if row[0] == output_id]
        if len(matches) != 1:
            raise core.BenchError("Unapproved consumer output generation")
        self.output_id, self.gpio, self.generation, self.initial_frequency = matches[0]
        self.cleaned, self.private_request = False, None
        self.record = {
            "output_id": output_id,
            "gpio": self.gpio,
            "generation": self.generation,
            "initial_frequency": self.initial_frequency,
            "variable_frequency": True,
            "fresh_claim_accepted": False,
            "initial_low_confirmed": False,
            "low_confirmed": False,
            "released": False,
            "read_only_chip_closed": False,
            "owned_request": None,
            "cleanup_final_readback": None,
        }
        receipt["outputs"].append(self.record)


def run_action(owner, controller, operation, value, index, owners, receipt):
    action = {
        "phase_index": index,
        "operation": operation,
        "value": value,
        "begin_ns": time.monotonic_ns(),
        "status": "pending",
    }
    receipt["actions"].append(action)
    try:
        action["api_state_before"] = dual.active_snapshots(owners)
        attribute = "angle" if operation == "Servo.angle" else "throttle"
        output_ids = (
            ["servo18-g1"] if attribute == "angle" else ["motor18-g2", "motor23-g1"]
        )
        owner.call(
            operation,
            lambda: setattr(controller, attribute, value),
            {"value": value, "output_ids": output_ids},
        )
        action["consumer_readback"] = getattr(controller, attribute)
        action["api_state_after"] = dual.active_snapshots(owners)
        action["status"] = "ok"
    except BaseException as error:
        action.update(status="error", error=f"{type(error).__name__}: {error}")
        raise
    finally:
        action["end_ns"] = time.monotonic_ns()


def run_protocol(
    library, pwm_module, servo_module, motor_module, identity, guard, receipt, owners
):
    servo = motor = None
    for index, (name, duration, operation, value) in enumerate(SEQUENCE):
        scope = f"{index:02d}_{name}"
        phase = {
            "index": index,
            "name": name,
            "scope": scope,
            "duration_seconds": duration,
            "operation": operation,
            "value": value,
            "begin_ns": time.monotonic_ns(),
        }
        for owner in owners.values():
            owner.scope = scope
        if operation in ("servo_initialize", "motor_initialize"):
            output_ids = (
                ("servo18-g1",)
                if operation == "servo_initialize"
                else ("motor18-g2", "motor23-g1")
            )
            for output_id in output_ids:
                owner = Owner(library, identity, guard, receipt, output_id)
                owners[output_id] = owner
                owner.scope = scope
                owner.construct(pwm_module.PWMOut)
                dual.active_snapshots(owners)
            if operation == "servo_initialize":
                servo = owners["servo18-g1"].call(
                    "Servo.__init__",
                    lambda: servo_module.Servo(
                        owners["servo18-g1"].pwm,
                        actuation_range=180,
                        min_pulse=1000,
                        max_pulse=2000,
                    ),
                    {
                        "actuation_range": 180,
                        "min_pulse_us": 1000,
                        "max_pulse_us": 2000,
                    },
                )
            else:
                motor = owners["motor18-g2"].call(
                    "DCMotor.__init__",
                    lambda: motor_module.DCMotor(
                        owners["motor18-g2"].pwm, owners["motor23-g1"].pwm
                    ),
                    {
                        "output_ids": ["motor18-g2", "motor23-g1"],
                        "default_decay_mode": 0,
                    },
                )
                if motor.decay_mode != motor_module.FAST_DECAY:
                    raise core.BenchError("Unexpected motor default decay mode")
        elif operation in ("Servo.angle", "DCMotor.throttle"):
            run_action(
                owners["servo18-g1" if operation == "Servo.angle" else "motor18-g2"],
                servo if operation == "Servo.angle" else motor,
                operation,
                value,
                index,
                owners,
                receipt,
            )
        else:
            output_id = (
                "servo18-g1"
                if operation == "servo_release"
                else "motor18-g2"
                if operation == "motor_release_positive"
                else "motor23-g1"
            )
            sibling = (
                owners.get("motor23-g1")
                if operation == "motor_release_positive"
                else None
            )
            with guard.atomic():
                owners[output_id].cleanup(sibling, "sequence")
                if not receipt["shutdowns"][-1]["success"]:
                    raise core.BenchError("Consumer output independent shutdown failed")
            servo = None if operation == "servo_release" else servo
            motor = None if operation.startswith("motor_release") else motor
        phase["stable_begin_ns"] = time.monotonic_ns()
        phase["api_state"] = dual.active_snapshots(owners)
        phase["consumer_state"] = (
            {"kind": "Servo", "angle": servo.angle}
            if servo
            else {
                "kind": "DCMotor",
                "throttle": motor.throttle,
                "decay_mode": motor.decay_mode,
            }
            if motor
            else None
        )
        time.sleep(duration)
        phase["end_ns"] = time.monotonic_ns()
        phase["api_state_end"] = dual.active_snapshots(owners)
        phase["consumer_state_end"] = (
            {"kind": "Servo", "angle": servo.angle}
            if servo
            else {
                "kind": "DCMotor",
                "throttle": motor.throttle,
                "decay_mode": motor.decay_mode,
            }
            if motor
            else None
        )
        phase["readback_end_ns"] = time.monotonic_ns()
        receipt["phases"].append(phase)


def experiment(manifest_path):
    receipt = {
        "schema_version": 1,
        "mode": MODE,
        "backend": BACKEND,
        "sequence_marker": SEQUENCE_MARKER,
        "gpios": [18, 23],
        "helper_pid": os.getpid(),
        "characterization_only": True,
        "functional_consumer_integration_only": True,
        "passive_probes_only": True,
        "actual_actuators_attached": False,
        "installed_blinka_compatibility_proven": False,
        "production_backend_unchanged": True,
        "parity_pass": None,
        "api_readbacks_are_not_electrical": True,
        "selected_source_hashes_are_not_whole_system_attestation": True,
        "variable_frequency": True,
        "motor_version": MOTOR_VERSION,
        "runtime_flags": {"short_slice": False, "shared": False},
        "inherited_environment": {
            name: os.environ.get(name)
            for name in ("BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED")
        },
        "watchdog_seconds": MAX_RUN_SECONDS,
        "watchdog_cannot_bound_native_hang_or_sigkill": True,
        "sequence_dwell_seconds": round(sum(row[1] for row in SEQUENCE), 6),
        "low_settle_seconds": 0.1,
        "normal_fixed_wait_seconds": round(sum(row[1] for row in SEQUENCE) + 0.3, 6),
        "begin_ns": time.monotonic_ns(),
        "phases": [],
        "actions": [],
        "events": [],
        "outputs": [],
        "shutdowns": [],
        "source_sha256": {},
        "before": None,
        "after": None,
        "signals_received": [],
        "primary_error": None,
        "cleanup_errors": [],
        "completed_normally": False,
        "read_only_chip_closed": False,
        "success": False,
    }
    owners = {}
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            manifest_path = approved_manifest_path(manifest_path)
            manifest = load_manifest(manifest_path)
            validate_manifest(manifest)
            receipt["manifest_path"] = str(manifest_path)
            receipt["source_sha256"] = source_hashes()
            if receipt["source_sha256"] != manifest["source_sha256"]:
                raise core.BenchError(
                    "Installed consumer/native/gpiod/helper source hash mismatch"
                )
            if any(value == "1" for value in receipt["inherited_environment"].values()):
                raise core.BenchError("Refusing inherited shared/short-slice flags")
            receipt["identity"] = dual.base.baseline.preflight()
            receipt["before"] = core.system_snapshot()
            issues = core.thermal_issues(receipt["before"], 65000)
            if issues:
                raise core.BenchError("Thermal preflight: " + "; ".join(issues))
            library, module = dual.load_backend()
            receipt["preclaim_lines"] = []
            for gpio in (18, 23):
                chip, line = dual.inspect_line(library, receipt["identity"], gpio)
                receipt["preclaim_lines"].append(
                    {"gpio": gpio, "chip_info": chip, "line_info": line}
                )
                receipt["read_only_chip_closed"] = True
                if line["used"] or line["consumer"] not in (None, ""):
                    raise core.BenchError(
                        "Both consumer pins must be fresh unused lines"
                    )
            with consumer_api(module.PWMOut, receipt, guard) as (
                servo_module,
                motor_module,
            ):
                run_protocol(
                    library,
                    module,
                    servo_module,
                    motor_module,
                    receipt["identity"],
                    guard,
                    receipt,
                    owners,
                )
            receipt["completed_normally"] = True
        except BaseException as error:
            receipt["primary_error"] = f"{type(error).__name__}: {error}"
        finally:
            with guard.cleanup():
                signal.alarm(0)
                for owner in owners.values():
                    owner.scope = "safety_cleanup_" + owner.output_id
                    try:
                        owner.cleanup()
                    except BaseException as error:
                        receipt["cleanup_errors"].append(
                            owner.output_id + f": {type(error).__name__}: {error}"
                        )
                try:
                    receipt["after"] = core.system_snapshot()
                    receipt["cleanup_errors"].extend(
                        core.thermal_issues(receipt["after"], 70000)
                    )
                except BaseException as error:
                    receipt["cleanup_errors"].append(
                        f"Thermal postflight: {type(error).__name__}: {error}"
                    )
                receipt["signals_received"] = list(guard.received)
    receipt["end_ns"] = time.monotonic_ns()
    receipt["success"] = bool(
        receipt["completed_normally"]
        and receipt["primary_error"] is None
        and not receipt["cleanup_errors"]
        and not receipt["signals_received"]
        and receipt["read_only_chip_closed"]
        and receipt["integration_shim"]["restored"]
        and len(receipt["outputs"]) == 3
        and all(
            row["fresh_claim_accepted"]
            and row["initial_low_confirmed"]
            and row["low_confirmed"]
            and row["released"]
            and row["read_only_chip_closed"]
            for row in receipt["outputs"]
        )
        and len(receipt["shutdowns"]) == 3
        and all(row["success"] for row in receipt["shutdowns"])
        and receipt["end_ns"] - receipt["begin_ns"] < MAX_RUN_SECONDS * 1_000_000_000
    )
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args(argv)
    receipt = experiment(args.manifest)
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
