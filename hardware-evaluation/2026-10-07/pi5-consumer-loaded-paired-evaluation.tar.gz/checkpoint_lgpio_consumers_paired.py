"""Exclusive four-capture consumer recovery snapshot and isolated offline replay.

Older idle captures/audits/notes are excluded. Frozen native recovery sources,
protocol identity and runtime provenance are retained as dependencies, not new
paired evidence. No GPIO, SSH, Git, acquisition or archive overwrite interface.
"""

import hashlib
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

import checkpoint_native_consumers as idle

LAB = Path(__file__).resolve().parent
PLAN_NAME = "oct7-lgpio-consumers-plan.json"
PLAN_SHA256 = "a4bf9e03fd8fd7d95f2dff9118108f046999272e63d95f7cc78d87caa3f80c7c"
CAPTURES = (
    "oct7-pi5-lgpio-consumers-r1",
    "oct7-pi5-native-consumers-paired-r1",
    "oct7-pi5-native-consumers-paired-r2",
    "oct7-pi5-lgpio-consumers-r2",
)
ARCHIVE = (
    LAB.parent
    / "Adafruit_Blinka_Raspberry_Pi_PWM/hardware-evaluation/2026-10-07/pi5-consumer-paired-evaluation.tar.gz"
)
VERIFICATION_NAME = "oct7-lgpio-consumers-paired-checkpoint-verification.json"
AUDIT_SOURCES = {
    "audit-source/raw_audit.py": (
        "/private/tmp/paired-consumer-independent.f2YuIZ/raw_audit.py",
        "ad292d3b27c5cb623fcda729235a5c3119efedccb68679204b932ebb9937ffb3",
    ),
    "audit-source/compare_reports.py": (
        "/private/tmp/paired-consumer-independent.f2YuIZ/compare_reports.py",
        "0e62a316a8e51d2c8cd1c4632796cc328aae669a41c82dd5966d907742653a46",
    ),
    "audit-source/check_receipts.py": (
        "/private/tmp/paired-receipts-audit.WL4JrM/check_receipts.py",
        "027f8a24a8c8bb17ac7afc11fdc540a162ed71972f911e32665d6b83eb2bf6c1",
    ),
    "audit-source/check_final_reports.py": (
        "/private/tmp/paired-receipts-audit.WL4JrM/check_final_reports.py",
        "07ed228209cd51dd79d2aebb569ac212a993b3c613e24b1bb584af1695e0ab49",
    ),
    "audit-source/receipt_checks.json": (
        "/private/tmp/paired-receipts-audit.WL4JrM/receipt_checks.json",
        "dcd9b87e8ad954bdffe22496ea5bd59c6d0d4889cfe261133079159a86043ff0",
    ),
    "audit-source/final_receipt_comparison.json": (
        "/private/tmp/paired-receipts-audit.WL4JrM/final_receipt_comparison.json",
        "1ce1c2ea9bf9e23a7ba2fd1e663de7f8e805071fa878bf91085a189f2467fbb8",
    ),
}
EXCLUDE = set(idle.CAPTURES) | {
    "oct7-native-consumers-independent-audit.json",
    "oct7-native-consumers-final-report-audit.json",
    "oct7-native-consumers-notes.txt",
}
TARGETS = (
    [name for name in idle.TARGETS if name not in EXCLUDE]
    + list(CAPTURES)
    + [
        "lgpio_pwm_consumers_eval.py",
        "test_lgpio_pwm_consumers_eval.py",
        "capture_lgpio_pwm_consumers.py",
        "test_capture_lgpio_pwm_consumers.py",
        "analyze_lgpio_pwm_consumers.py",
        "test_analyze_lgpio_pwm_consumers.py",
        "prepare_lgpio_consumers.py",
        "record_lgpio_consumers_paired_state.py",
        "test_record_lgpio_consumers_paired_state.py",
        PLAN_NAME,
        "oct7-lgpio-consumers-manifest.json",
        "oct7-lgpio-consumers-preflight.json",
        "oct7-native-consumers-loaded-postflight.json",
        "oct7-native-consumers-loaded-postflight.json.stdout",
        "oct7-native-consumers-loaded-postflight.json.stderr",
        "oct7-lgpio-consumers-paired-preflight.json",
        "oct7-lgpio-consumers-paired-preflight.json.stdout",
        "oct7-lgpio-consumers-paired-preflight.json.stderr",
        "oct7-lgpio-consumers-paired-postflight.json",
        "oct7-lgpio-consumers-paired-postflight.json.stdout",
        "oct7-lgpio-consumers-paired-postflight.json.stderr",
        "oct7-lgpio-consumers-paired-independent-audit.json",
        "oct7-lgpio-consumers-paired-final-report-audit.json",
        "oct7-lgpio-consumers-paired-independent-notes.txt",
        "checkpoint_lgpio_consumers_paired.py",
    ]
)
REPLAY = r"""
import json,pathlib,sys
sys.path.insert(0,sys.argv[1])
import analyze_lgpio_pwm_consumers as original
import analyze_native_pwm_consumers as native
root=pathlib.Path(sys.argv[1])
original_lab=pathlib.Path(sys.argv[2])
plan_path=root/'oct7-lgpio-consumers-plan.json'
plan=json.loads(plan_path.read_text())
original_count=native_count=0
for name in plan['capture_order']:
    if name.startswith('oct7-pi5-lgpio-consumers-'):
        saved=json.loads((root/name/'analysis.json').read_text())
        report=original.analyze(root/name,plan_path)
        assert report['frozen_plan']['path']==str(plan_path.resolve()),name
        assert saved['frozen_plan']['path']==str(original_lab/plan_path.name),name
        # Only this verified provenance location changes during extraction.
        # Every source/plan/evidence hash and all receipt/raw facts must match.
        del report['frozen_plan']['path']
        del saved['frozen_plan']['path']
        original_count+=1
    else:
        saved=json.loads((root/name/'consumer-analysis.json').read_text())
        report=native.analyze(root/name)
        native_count+=1
    assert report==saved,name
assert (original_count,native_count)==(2,2)
print(json.dumps({'original_reports_reproduced':original_count,
                  'native_reports_reproduced':native_count,
                  'original_plan_path_only_relocated':True}))
"""


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    if (
        not name
        or path.is_absolute()
        or ".." in path.parts
        or "\\" in name
        or str(path) != name.rstrip("/")
        or str(path) == "."
    ):
        raise ValueError("Unsafe recovery member: " + name)
    return path


def tree_files(root, targets):
    """Validate each resolved target/member before hashing regular file bytes."""
    if len(targets) != len(set(targets)):
        raise ValueError("Duplicate recovery targets")
    files = {}
    for name in targets:
        safe_name(name)
        path = root / name
        if (
            not path.exists()
            or path.is_symlink()
            or path.resolve(strict=True) != path
            or not (path.is_file() or path.is_dir())
        ):
            raise ValueError("Missing or linked target: " + name)
        for member in [path] if path.is_file() else sorted(path.rglob("*")):
            if (
                member.is_symlink()
                or member.resolve(strict=True) != member
                or not (member.is_file() or member.is_dir())
            ):
                raise ValueError("Unsupported member: " + str(member))
            if member.is_file():
                key = str(member.relative_to(root))
                safe_name(key)
                if key in files:
                    raise ValueError("Duplicate member: " + key)
                files[key] = digest(member)
    return files


def frozen_inputs(files):
    if digest(LAB / PLAN_NAME) != PLAN_SHA256:
        raise ValueError("Frozen paired pre-capture plan changed")
    plan = json.loads((LAB / PLAN_NAME).read_text())
    if tuple(plan["capture_order"]) != CAPTURES:
        raise ValueError("Exact four predeclared paired captures required")
    pins = {
        "lgpio_pwm_consumers_eval.py": plan["helper_sha256"],
        "capture_lgpio_pwm_consumers.py": plan["collector_sha256"],
        "analyze_lgpio_pwm_consumers.py": plan["analyzer_sha256"],
        "native_pwm_consumers_eval.py": plan["native_reference"]["helper_sha256"],
        "capture_native_pwm_consumers.py": plan["native_reference"]["collector_sha256"],
        "analyze_native_pwm_consumers.py": plan["native_reference"]["analyzer_sha256"],
        "oct7-native-consumers-plan.json": plan["native_reference"][
            "unchanged_protocol_plan_sha256"
        ],
        "oct7-native-consumers-loaded-postflight.json": "df61294e4d852d964dfcceb9cedaf14c522254dc483ee4281a30b20dfda7b301",
    }
    if any(files[name] != expected for name, expected in pins.items()):
        raise ValueError("Pre-capture frozen recovery source/plan changed")
    return plan


def main():
    # Check the execution guard before collecting bytes or creating anything.
    if digest(LAB / PLAN_NAME) != PLAN_SHA256:
        raise ValueError("Frozen paired pre-capture plan changed")
    verification = LAB / VERIFICATION_NAME
    if any(path.exists() or path.is_symlink() for path in (ARCHIVE, verification)):
        raise ValueError("Archive and verification outputs must be fresh")
    files = tree_files(LAB, TARGETS)
    frozen_inputs(files)
    audit_sources = {}
    for name, (source, expected) in AUDIT_SOURCES.items():
        safe_name(name)
        path = Path(source)
        if (
            not path.is_file()
            or path.is_symlink()
            or path.resolve(strict=True) != path
            or digest(path) != expected
            or name in files
        ):
            raise ValueError("Independent audit source changed: " + name)
        files[name] = expected
        audit_sources[name] = path
    consumers = idle.helper.consumer_inventory()
    for key, path in consumers.items():
        safe_name(key)
        if path.is_symlink() or not path.is_file() or path.resolve(strict=True) != path:
            raise ValueError("Unsupported consumer source: " + key)
        value = digest(path)
        if value != idle.helper.CONSUMER_PINS[key]:
            raise ValueError("Consumer source changed: " + key)
        files["consumer-library-source/" + key] = value
    with (
        ARCHIVE.open("xb") as stream,
        tarfile.open(fileobj=stream, mode="w:gz", dereference=True) as archive,
    ):
        for name in TARGETS:
            archive.add(LAB / name, arcname=name)
        for key, path in consumers.items():
            archive.add(path, arcname="consumer-library-source/" + key)
        for name, path in audit_sources.items():
            archive.add(path, arcname=name)
    extracted = Path(
        tempfile.mkdtemp(
            prefix="blinka-consumers-paired-checkpoint-", dir="/private/tmp"
        )
    )
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        names = set()
        for member in archive.getmembers():
            key = str(safe_name(member.name))
            if key in names or not (member.isfile() or member.isdir()):
                raise ValueError("Duplicate/unsafe archive member: " + member.name)
            names.add(key)
        archive.extractall(extracted, filter="data")
    recovered = tree_files(
        extracted, [path.name for path in sorted(extracted.iterdir())]
    )
    if recovered != files:
        raise ValueError("Archive file set/bytes differ")
    result = subprocess.run(
        [sys.executable, "-I", "-c", REPLAY, str(extracted), str(LAB)],
        cwd=extracted,
        capture_output=True,
        text=True,
        check=True,
        timeout=60,
    )
    report = {
        "archive": str(ARCHIVE),
        "size_bytes": ARCHIVE.stat().st_size,
        "sha256": digest(ARCHIVE),
        "frozen_paired_plan_sha256": PLAN_SHA256,
        "top_level_targets": len(TARGETS) + 2,
        "regular_files": len(files),
        "safe_extraction": str(extracted),
        "all_file_bytes_match": True,
        "replay": json.loads(result.stdout),
        "replay_stderr": result.stderr,
        "consumer_library_sources": {
            "version": idle.helper.MOTOR_VERSION,
            "selected_files": idle.helper.CONSUMER_PINS,
            "scope": "Three exact executed Python files, not whole-distribution provenance",
        },
        "independent_audit_sources": {
            name: expected for name, (_source, expected) in AUDIT_SOURCES.items()
        },
        "scope": "Recovery of four fresh paired functional recordings; no quantitative backend parity or waveform acceptance verdict",
    }
    with verification.open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
