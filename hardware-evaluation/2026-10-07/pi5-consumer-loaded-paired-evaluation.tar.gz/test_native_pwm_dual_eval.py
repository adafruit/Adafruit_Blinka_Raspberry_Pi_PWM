"""Dual-output safety fakes; real public Python API, no GPIO/native/SSH calls."""

import hashlib
import signal
from pathlib import Path
from types import SimpleNamespace

import native_pwm_dual_eval as bench
import pytest
import test_native_pwm_half50_eval as old_fakes

ROOT = "/tmp/blinka-pwm-native-dual.abc123"
old_environment = old_fakes.environment


@pytest.fixture
def environment(old_environment, monkeypatch):
    _old_state, guard, module, old_manifest, sleeps = old_environment
    state = SimpleNamespace(
        log=[],
        claimed={},
        levels={18: 0, 23: 0},
        foreign=set(),
        generation={18: 0, 23: 0},
        fail=None,
        hook=None,
        alias_fd=False,
        chip_label="pinctrl-rp1",
    )

    def note(name, gpio, *args):
        state.log.append((name, gpio, *args))
        if state.hook:
            state.hook(name, gpio)
        if state.fail == (name, gpio):
            raise OSError(f"injected {name} GPIO{gpio}")

    class Chip:
        def __init__(self, path):
            assert path == old_fakes.IDENTITY["gpiochip"]

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            pass

        def get_info(self):
            return SimpleNamespace(
                name="gpiochip4", label=state.chip_label, num_lines=54
            )

        def get_line_info(self, gpio):
            assert gpio in (18, 23)
            state.log.append(("line_info", gpio))
            used = gpio in state.claimed or gpio in state.foreign
            return SimpleNamespace(
                offset=gpio,
                name=f"GPIO{gpio}",
                used=used,
                consumer="foreign"
                if gpio in state.foreign
                else "adafruit-blinka-pwm"
                if used
                else None,
            )

    class Request:
        chip_name = "gpiochip4"

        def __init__(self, gpio):
            self.offsets = [gpio]
            self.fd = 100 if gpio == 18 or state.alias_fd else 101

        def get_value(self, gpio):
            assert self.offsets == [gpio] and state.claimed.get(gpio) is self
            note("get_value", gpio)
            return (
                old_fakes.Value.ACTIVE
                if state.levels[gpio]
                else old_fakes.Value.INACTIVE
            )

    class Engine:
        def __init__(self, pin, frequency, duty):
            chip, self.gpio = pin
            assert chip == old_fakes.IDENTITY["gpiochip"] and self.gpio in (18, 23)
            assert frequency == (50 if self.gpio == 18 else 500) and duty == 0
            assert self.gpio not in state.claimed and self.gpio not in state.foreign
            self._request = None
            note("construct", self.gpio, frequency, duty)
            state.generation[self.gpio] += 1
            self._request = Request(self.gpio)
            state.claimed[self.gpio] = self._request
            state.levels[self.gpio] = 0
            note("claim", self.gpio, self._request.fd)

        def configure(self, frequency, duty):
            assert state.claimed.get(self.gpio) is self._request and frequency in (
                50,
                500,
            )
            note("configure", self.gpio, frequency, duty)
            state.levels[self.gpio] = int(duty != 0)

        def check(self):
            assert state.claimed.get(self.gpio) is self._request

        def close(self):
            try:
                note("stop", self.gpio)
                state.levels[self.gpio] = 0
            finally:
                note("release", self.gpio)
                assert state.claimed.get(self.gpio) is self._request
                del state.claimed[self.gpio]
                self._request = None

    library = SimpleNamespace(
        Chip=Chip, line=SimpleNamespace(Value=old_fakes.Value), __version__="2.5.0"
    )
    monkeypatch.setattr(module, "SoftwarePWM", Engine)
    monkeypatch.setattr(bench, "load_backend", lambda: (library, module))
    manifest = {
        "schema_version": 1,
        "source_sha256": {
            **old_manifest["source_sha256"],
            "native_pwm_updates_eval.py": bench.SOURCE_PINS[
                "native_pwm_updates_eval.py"
            ],
            bench.NEW_SOURCE: hashlib.sha256(
                Path(bench.__file__).read_bytes()
            ).hexdigest(),
            **{"gpiod/" + name: "b" * 64 for name in (*bench.GPIOD_FILES, "_ext.so")},
        },
    }
    monkeypatch.setattr(bench, "approved_manifest_path", lambda path: Path(path))
    monkeypatch.setattr(bench, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(bench, "source_hashes", lambda: dict(manifest["source_sha256"]))
    return state, guard, module, manifest, sleeps


def test_exact_protocol_private_requests_independent_shutdown_and_fd_reuse(environment):
    state, _guard, _module, manifest, sleeps = environment
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert receipt["success"] and receipt["source_sha256"] == manifest["source_sha256"]
    assert receipt["functional_coexistence_only"] and receipt["parity_pass"] is None
    assert not receipt["matched_performance_parity"]
    assert [row["output_id"] for row in receipt["outputs"]] == [
        row[0] for row in bench.OUTPUTS
    ]
    assert [row["output_id"] for row in receipt["shutdowns"]] == [
        "gpio18-g1",
        "gpio23-g1",
        "gpio18-g2",
    ]
    assert [row["reason"] for row in receipt["shutdowns"]] == [
        "sequence",
        "sequence",
        "safety_cleanup",
    ]
    assert [row["sibling_id"] for row in receipt["shutdowns"]] == [
        "gpio23-g1",
        "gpio18-g2",
        None,
    ]
    expected_sleeps = [phase[1] for phase in bench.SEQUENCE]
    expected_sleeps.insert(8, 0.1)
    expected_sleeps.insert(11, 0.1)
    expected_sleeps.append(0.1)
    assert sleeps == expected_sleeps and sum(sleeps) < 6
    assert [
        (p["name"], p["duration_seconds"], p["actions"]) for p in receipt["phases"]
    ] == [(name, duration, list(actions)) for name, duration, actions in bench.SEQUENCE]
    assert all(p["api_state"] == p["api_state_end"] for p in receipt["phases"])
    for row in receipt["outputs"]:
        assert row["variable_frequency"] and row["fresh_claim_accepted"]
        assert (
            row["initial_readback"]
            == row["cleanup_final_readback"]
            == {"gpio_level": 0, "inactive": True}
        )
        assert row["released"] and row["released_line_info"]["used"] is False
        assert row["owned_request"]["offsets"] == [row["gpio"]]
    # A fresh GPIO18 generation may reuse the old integer FD after release.
    assert [row["owned_request"]["fd"] for row in receipt["outputs"]] == [100, 101, 100]
    for row in receipt["shutdowns"][:2]:
        before, after = row["sibling_before"], row["sibling_after"]
        assert {k: v for k, v in before.items() if k != "gpio_level"} == {
            k: v for k, v in after.items() if k != "gpio_level"
        }
    assert state.claimed == {} and state.generation == {18: 2, 23: 1}
    assert state.levels == {18: 0, 23: 0} and receipt["cleanup_errors"] == []
    assert receipt["runtime_flags"] == {"short_slice": False, "shared": False}
    assert [(e["ordinal"], e["status"]) for e in receipt["events"]] == [
        (i, "ok") for i in range(len(receipt["events"]))
    ]
    assert all(
        a["end_ns"] <= b["begin_ns"]
        for a, b in zip(receipt["events"], receipt["events"][1:])
    )
    for output_id in ("gpio18-g1", "gpio23-g1", "gpio18-g2"):
        operations = [
            e["operation"] for e in receipt["events"] if e["output_id"] == output_id
        ]
        assert operations[-6:] == [
            "track_owned_request",
            "PWMOut.duty_cycle_zero",
            "low_settle",
            "owned_request.get_value",
            "PWMOut.deinit",
            "gpiod_line_info_released",
        ]


def test_public_setters_use_frequency_then_old_duty_before_new_duty(environment):
    receipt = bench.experiment(ROOT + "/manifest.json")
    events = [e for e in receipt["events"] if e["scope"] == "06_swap_frequencies"]
    assert [(e["output_id"], e["operation"], e["arguments"]) for e in events] == [
        ("gpio18-g1", "PWMOut.frequency", {"frequency": 500, "duty_u16": 4915}),
        ("gpio18-g1", "PWMOut.duty_cycle", {"frequency": 500, "duty_u16": 32768}),
        ("gpio23-g1", "PWMOut.frequency", {"frequency": 50, "duty_u16": 32768}),
        ("gpio23-g1", "PWMOut.duty_cycle", {"frequency": 50, "duty_u16": 4915}),
    ]


@pytest.mark.parametrize("gpio", [18, 23])
def test_foreign_preclaim_on_either_pin_never_constructs(environment, gpio):
    state, *_rest = environment
    state.foreign.add(gpio)
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "fresh unused" in receipt["primary_error"]
    assert state.claimed == {} and not any(row[0] == "construct" for row in state.log)


@pytest.mark.parametrize("problem", ["source", "pin", "flag", "thermal", "chip"])
def test_preflight_gates_refuse_without_claim(environment, monkeypatch, problem):
    state, _guard, _module, manifest, _sleeps = environment
    if problem == "source":
        monkeypatch.setattr(
            bench,
            "source_hashes",
            lambda: {**manifest["source_sha256"], "gpiod/_ext.so": "0" * 64},
        )
    elif problem == "pin":
        manifest["source_sha256"]["native_pwm_updates_eval.py"] = "0" * 64
    elif problem == "flag":
        monkeypatch.setenv("BLINKA_PWM_SHARED", "1")
    elif problem == "thermal":
        monkeypatch.setattr(
            bench.core,
            "system_snapshot",
            lambda: {"temperature_millic": "66000", "throttled": "throttled=0x0"},
        )
    else:
        state.chip_label = "other"
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and receipt["primary_error"]
    assert not state.claimed and not any(row[0] == "construct" for row in state.log)


def test_partial_second_constructor_always_deinits_both_objects(
    environment, monkeypatch
):
    state, _guard, module, _manifest, _sleeps = environment
    original = module.PWMOut

    class Partial(original):
        def __init__(self, pin, **kwargs):
            super().__init__(pin, **kwargs)
            if pin[1] == 23:
                raise OSError("partial public constructor")

    monkeypatch.setattr(module, "PWMOut", Partial)
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert (
        not receipt["success"]
        and "partial public constructor" in receipt["primary_error"]
    )
    assert not state.claimed and all(row["released"] for row in receipt["outputs"])
    assert [
        e["output_id"] for e in receipt["events"] if e["operation"] == "PWMOut.deinit"
    ] == ["gpio18-g1", "gpio23-g1"]
    assert len([row for row in state.log if row[0] == "claim"]) == 2


@pytest.mark.parametrize("at,gpio", [("claim", 23), ("stop", 18)])
def test_signal_during_atomic_claim_or_shutdown_cleans_only_owned_generations(
    environment, at, gpio
):
    state, guard, _module, _manifest, _sleeps = environment
    fired = False

    def hook(name, pin):
        nonlocal fired
        if name == at and pin == gpio and not fired:
            fired = True
            guard.handler(signal.SIGTERM, None)

    state.hook = hook
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "SafetyAbort" in receipt["primary_error"]
    assert receipt["signals_received"] == [signal.SIGTERM] and not state.claimed
    assert state.generation == {18: 1, 23: 1}
    assert all(row["released"] for row in receipt["outputs"])


def test_primary_setter_failure_preserved_and_both_outputs_cleaned(environment):
    state, *_rest = environment
    state.fail = ("configure", 23)
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert not receipt["success"] and "configure GPIO23" in receipt["primary_error"]
    assert any("duty_cycle_zero" in error for error in receipt["cleanup_errors"])
    assert not state.claimed and all(row["released"] for row in receipt["outputs"])
    assert [row[1] for row in state.log if row[0] == "release"] == [18, 23]


def test_deinit_failure_releases_target_and_stops_protocol_before_restart(environment):
    state, *_rest = environment
    state.fail = ("stop", 18)
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert (
        not receipt["success"]
        and "Independent shutdown failed" in receipt["primary_error"]
    )
    assert any("PWMOut.deinit" in error for error in receipt["cleanup_errors"])
    assert not state.claimed and state.generation == {18: 1, 23: 1}
    assert receipt["shutdowns"][0]["sibling_after"]["output_id"] == "gpio23-g1"


def test_simultaneous_fd_alias_is_rejected_without_reclaim(environment):
    state, *_rest = environment
    state.alias_fd = True
    receipt = bench.experiment(ROOT + "/manifest.json")
    assert (
        not receipt["success"]
        and "distinct pins and request FDs" in receipt["primary_error"]
    )
    assert not state.claimed and state.generation == {18: 1, 23: 1}


def test_selected_source_pins_and_exact_manifest_shape(environment):
    _state, _guard, _module, manifest, _sleeps = environment
    assert len(bench.validate_manifest(manifest)) == 14
    for name, expected in bench.SOURCE_PINS.items():
        assert (
            hashlib.sha256(
                Path(bench.__file__).with_name(name).read_bytes()
            ).hexdigest()
            == expected
        )
    bad = {
        "schema_version": 1,
        "source_sha256": {**manifest["source_sha256"], "extra": "b" * 64},
    }
    with pytest.raises(bench.core.BenchError, match="fourteen"):
        bench.validate_manifest(bad)


@pytest.mark.parametrize(
    "path",
    [
        "manifest.json",
        "/tmp/manifest.json",
        ROOT + "/../manifest.json",
        old_fakes.ROOT + "/manifest.json",
    ],
)
def test_manifest_requires_new_isolated_absolute_root(path):
    with pytest.raises(bench.core.BenchError, match="absolute"):
        bench.approved_manifest_path(path)
