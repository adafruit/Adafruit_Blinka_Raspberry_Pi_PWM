"""Fixed passive original-lgpio consumer collector; acquisition, not parity.

Only physical Logic8 GPIO18/ch0 and GPIO23/ch1 at 100 MSa/s are authorized.
Preserve complete SAL/raw channels, actual SSH status and failure diagnostics.
The helper owns protocol/ownership/cleanup validation; no native backend runs,
installed Blinka compatibility or actual actuator operation is established.
"""

import argparse
import hashlib
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

import lgpio_pwm_consumers_eval as helper
from capture_kernel_pwm_lgpio_baseline import _write, read_json, require
from saleae import automation

DEVICE_ID = "81F8C2631DF5BF30"
MODE, BACKEND, SEQUENCE_MARKER = helper.MODE, helper.BACKEND, helper.SEQUENCE_MARKER
HELPER_SHA256 = "7026f71cc47ed46d2b4eeb9a838ca764ff7895e28180a453ae92b2b99bdaf8dd"
REMOTE_LIBRARY_KEYS = {
    "lgpio.py",
    "_lgpio.so",
    *("gpiod/" + name for name in (*helper.marker.GPIOD_FILES, "_ext.so")),
}
PERCENT_NOMINALS = {
    name: {
        "frequency_hz": frequency,
        "duty_u16": duty,
        "submitted_duty_percent": round(duty / 65535 * 100),
        "submitted_nominal_high_us": 1_000_000
        / frequency
        * round(duty / 65535 * 100)
        / 100,
    }
    for name, frequency, duty in (
        ("servo_angle0", 50, 3276),
        ("servo_angle90", 50, 4914),
        ("servo_angle180", 50, 6553),
        ("motor_half", 1000, 32767),
    )
}


def local_source_inventory():
    directory = Path(__file__).resolve().parent
    consumers = helper.protocol.consumer_inventory()
    return {
        key: consumers[key] if key in consumers else directory / key
        for key in helper.SOURCE_KEYS - REMOTE_LIBRARY_KEYS
    }


def validate_local_manifest(manifest):
    hashes = helper.validate_manifest(manifest)
    require(
        hashes[helper.NEW_SOURCE] == HELPER_SHA256,
        "Frozen original consumer helper SHA required",
    )
    paths = local_source_inventory()
    require(
        set(paths) == helper.SOURCE_KEYS - REMOTE_LIBRARY_KEYS
        and all(
            path.is_file()
            and hashlib.sha256(path.read_bytes()).hexdigest() == hashes[key]
            for key, path in paths.items()
        ),
        "Local original/helper/consumer Python bytes must match manifest",
    )
    return hashes


def validate_remote(remote, manifest):
    require(isinstance(remote, dict), "Original consumer receipt must be an object")
    helper.validate_receipt(remote, manifest)


def capture_test(directory, remote_root, remote_python, manifest_path):
    require(
        isinstance(remote_root, str) and re.fullmatch(helper.ROOT_PATTERN, remote_root),
        "Requires the isolated Pi5 lgpio-consumers root",
    )
    require(
        isinstance(remote_python, str)
        and (
            re.fullmatch(
                r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/venv/bin/python", remote_python
            )
            or remote_python == remote_root + "/venv/bin/python"
        ),
        "Requires an explicit approved absolute venv Python",
    )
    manifest = read_json(Path(manifest_path).read_text())
    hashes = validate_local_manifest(manifest)
    directory = Path(directory)
    require(not directory.is_symlink(), "Capture output cannot be a symlink")
    output = directory.resolve()
    require(
        re.fullmatch(r"[A-Za-z0-9_-]+", output.name), "Simple capture name required"
    )
    output.mkdir(parents=True, exist_ok=False)
    _write(output, "manifest.json", json.dumps(manifest, indent=2) + "\n")
    program = remote_root + "/" + helper.NEW_SOURCE
    remote_manifest = remote_root + "/manifest.json"
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([remote_python, program, "--manifest", remote_manifest]),
    ]
    remote, primary, logic_version = None, None, None
    evidence_errors, timing = [], {}
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            require(
                any(
                    device.device_id == DEVICE_ID and not device.is_simulation
                    for device in manager.get_devices()
                ),
                "Confirmed physical Logic8 analyzer is unavailable",
            )
            logic_version = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[0, 1],
                digital_sample_rate=100_000_000,
                glitch_filters=[],
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as capture:
                try:
                    timing["lead_begin_ns"] = time.monotonic_ns()
                    time.sleep(0.5)
                    timing["lead_end_ns"] = time.monotonic_ns()
                    with (
                        (output / "remote.stdout").open("x") as stdout_file,
                        (output / "remote.stderr").open("x") as stderr_file,
                    ):
                        remote = subprocess.run(
                            command,
                            stdout=stdout_file,
                            stderr=stderr_file,
                            text=True,
                            check=False,
                            timeout=30,
                        )
                except BaseException as error:
                    # Timeout/interruption does not provide an actual SSH exit.
                    primary = error
                finally:
                    for name, action in (
                        ("tail", lambda: time.sleep(0.2)),
                        ("stop", capture.stop),
                        (
                            "save_capture",
                            lambda: capture.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_binary",
                            lambda: capture.export_raw_data_binary(
                                str(output), digital_channels=[0, 1]
                            ),
                        ),
                    ):
                        try:
                            if name == "tail":
                                timing["tail_begin_ns"] = time.monotonic_ns()
                            action()
                            if name == "tail":
                                timing["tail_end_ns"] = time.monotonic_ns()
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:
        if primary is None:
            primary = error
        else:
            evidence_errors.append(f"acquisition: {type(error).__name__}: {error}")
    for name in ("remote.stdout", "remote.stderr"):
        try:
            if not (output / name).exists():
                _write(output, name, "")
        except BaseException as error:
            evidence_errors.append(f"{name}: {type(error).__name__}: {error}")
    acquisition = {
        "mode": MODE,
        "backend": BACKEND,
        "remote_root": remote_root,
        "remote_python": remote_python,
        "remote_program": program,
        "remote_manifest": remote_manifest,
        "remote_command": command,
        "remote_returncode": None if remote is None else remote.returncode,
        "ssh_exit_unavailable_after_exception": remote is None,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "requested_channels": [0, 1],
        "requested_sample_rate_hz": 100_000_000,
        "requested_glitch_filters": [],
        "local_timing_ns": timing,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None
        if primary is None
        else f"{type(primary).__name__}: {primary}",
        "evidence_errors": evidence_errors,
    }
    _write(output, "acquisition.json", json.dumps(acquisition, indent=2) + "\n")
    result = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": MODE,
        "backend": BACKEND,
        "sequence_marker": SEQUENCE_MARKER,
        "baseline_commit": helper.baseline.BLINKA_COMMIT,
        "helper_sha256": hashes[helper.NEW_SOURCE],
        "source_manifest": manifest,
        "remote_root": remote_root,
        "remote_python": remote_python,
        "remote_program": program,
        "motor_version": "3.5.0",
        "original_variable_frequency_default": False,
        "original_percent_nominals": PERCENT_NOMINALS,
        "percent_nominals_are_not_native_u16_targets_or_continuous_high_durations": True,
        "sample_rate_hz": 100_000_000,
        "logic_version": logic_version,
        "production_backend_unchanged": True,
        "outputs": [
            {"gpio": gpio, "saleae_channel": channel, "backend": BACKEND}
            for gpio, channel in ((18, 0), (23, 1))
        ],
        "remote": None,
        "remote_returncode": acquisition["remote_returncode"],
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "installed_blinka_compatibility_proven": False,
        "actual_actuators_attached": False,
        "native_backend_executed": False,
        "public_deinit_cancels_or_frees_gpio": False,
        "additional_lab_cleanup_required": True,
        "success_scope": "acquisition and genuine consumer API/private lab cleanup only; not waveform, actuator, parity or installed Blinka compatibility",
    }
    try:
        if primary is not None or evidence_errors:
            raise RuntimeError(
                "Capture failure evidence retained: "
                + (acquisition["primary_error"] or "; ".join(evidence_errors))
            ) from primary
        require(
            remote is not None
            and type(remote.returncode) is int
            and remote.returncode == 0,
            "Original consumer SSH did not exit0; raw evidence retained",
        )
        require(
            all(
                (output / name).is_file() and (output / name).stat().st_size > 0
                for name in ("waveform.sal", "digital_0.bin", "digital_1.bin")
            ),
            "Missing SAL/raw PWM channel evidence",
        )
        result["remote"] = read_json((output / "remote.stdout").read_text())
        validate_remote(result["remote"], manifest)
        require(
            result["remote"].get("manifest_path") == remote_manifest
            and result["remote"].get("python_executable") == remote_python,
            "Remote manifest root/interpreter differs from acquisition",
        )
        result["collection_success"] = True
    except BaseException as error:
        result["receipt_validation_error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        _write(output, "results.json", json.dumps(result, indent=2) + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--remote-python", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    result = capture_test(
        args.directory, args.remote_root, args.remote_python, args.manifest
    )
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "backend": BACKEND,
                "collection_success": result["collection_success"],
                "waveform_accepted": None,
                "parity_evaluated": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
