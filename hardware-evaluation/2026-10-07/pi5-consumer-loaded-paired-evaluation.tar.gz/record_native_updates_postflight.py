"""Read-only Pi 5 postflight; retain actual SSH output and all inspected PIDs."""

import argparse
import hashlib
import json
import shlex
import subprocess
from pathlib import Path

REMOTE_PYTHON = "/tmp/blinka-pwm-oct6.F3SDcm/venv/bin/python"
BOOT_ID = "71305dc8-e9a8-49b1-a623-678032cbd3f5"
BOOT_SHA = "b7c4bef8c3e955d6e9b93b0f209ce4b4301549796978b845fbb4ff8ba48f7776"

REMOTE = r"""
import datetime, hashlib, importlib.util, json, pathlib, platform, subprocess
import gpiod
pids = json.loads(PIDS)
def query(args):
    result = subprocess.run(args, capture_output=True, text=True, check=False)
    return {"arguments": args, "returncode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}
with gpiod.Chip("/dev/gpiochip0") as chip:
    info = chip.get_info()
    lines = []
    for offset in (18, 23):
        line = chip.get_line_info(offset)
        lines.append({"offset": offset, "used": line.used,
                      "consumer": line.consumer, "direction": line.direction.name})
receipt = {
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "hostname": platform.node(), "kernel": platform.release(),
    "boot_id": pathlib.Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    "boot_config_sha256": hashlib.sha256(pathlib.Path("/boot/firmware/config.txt").read_bytes()).hexdigest(),
    "pid_exists": {str(pid): pathlib.Path(f"/proc/{pid}").exists() for pid in pids},
    "gpiochip": {"name": info.name, "label": info.label, "num_lines": info.num_lines},
    "lines": lines,
    "temperature_millic": pathlib.Path("/sys/class/thermal/thermal_zone0/temp").read_text().strip(),
    "throttled": query(["vcgencmd", "get_throttled"]),
    "pinctrl": [query(["pinctrl", "get", str(offset)]) for offset in (18,23)],
    "pwm": query(["sudo", "-n", "cat", "/sys/kernel/debug/pwm"]),
    "module_paths": {name: (spec.origin if (spec := importlib.util.find_spec(name)) else None)
                     for name in ("lgpio", "_lgpio", "gpiod")},
    "read_only": True, "no_gpio_request_or_write": True,
}
print(json.dumps(receipt, indent=2))
"""


def record(output):
    output = Path(output)
    captures = [
        f"oct7-pi5-native-updates-{mode}-r{repeat}"
        for mode in ("frequency", "direct")
        for repeat in (1, 2)
    ] + [
        f"oct7-pi5-{backend}-updates-{mode}-loaded-r{repeat}"
        for backend in ("native", "lgpio")
        for mode in ("frequency", "direct", "half50-direct")
        for repeat in (1, 2)
    ]
    pids = set()
    for name in captures:
        remote = json.loads((Path(name) / "remote.stdout").read_text())
        if remote["success"] is not True or remote["cleanup_errors"]:
            raise ValueError("Only completed captures may be postflighted")
        pids.add(remote["helper_pid"])
        if "-loaded-" in name:
            for line in Path(name + ".load.stdout").read_text().splitlines():
                load = json.loads(line)
                pids.add(load["launcher_pid"])
                pids.update(worker["pid"] for worker in load["owned_workers"])
    if not pids or not all(type(pid) is int and pid > 1 for pid in pids):
        raise ValueError("Invalid inspected PID set")
    targets = [output, Path(str(output) + ".stdout"), Path(str(output) + ".stderr")]
    if any(path.exists() or path.is_symlink() for path in targets):
        raise ValueError("Postflight targets must be fresh")
    code = REMOTE.replace("PIDS", repr(json.dumps(sorted(pids))))
    command = [
        "ssh",
        "-T",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join([REMOTE_PYTHON, "-c", code]),
    ]
    with targets[1].open("xb") as stdout, targets[2].open("xb") as stderr:
        result = subprocess.run(
            command, stdout=stdout, stderr=stderr, timeout=20, check=False
        )
    remote = json.loads(targets[1].read_text()) if result.returncode == 0 else None
    accepted = (
        result.returncode == 0
        and remote["boot_id"] == BOOT_ID
        and remote["boot_config_sha256"] == BOOT_SHA
        and remote["gpiochip"]["label"] == "pinctrl-rp1"
        and not any(remote["pid_exists"].values())
        and all(
            line["used"] is False and not line["consumer"] for line in remote["lines"]
        )
        and remote["throttled"]["returncode"] == 0
        and remote["throttled"]["stdout"].strip() == "throttled=0x0"
        and remote["pwm"]["returncode"] == 0
        and "platform/1f0009c000.pwm" in remote["pwm"]["stdout"]
        and "cooling_fan" in remote["pwm"]["stdout"]
        and "1f00098000" not in remote["pwm"]["stdout"]
        and "pwm-gpio" not in remote["pwm"]["stdout"]
    )
    receipt = {
        "capture_names": captures,
        "inspected_pids": sorted(pids),
        "ssh_returncode": result.returncode,
        "accepted": bool(accepted),
        "remote": remote,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Read-only postflight, not waveform acceptance or an analog failsafe guarantee",
    }
    with output.open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps(
            {"accepted": bool(accepted), "pids_inspected": len(pids), "remote": remote},
            indent=2,
        )
    )
    return 0 if accepted else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    raise SystemExit(record(parser.parse_args().output))
