"""Genuine motor3.5.0 and frozen original PWM/Pin; private GPIO is fake."""

import copy
import gc
import hashlib
import signal
import sys
from pathlib import Path
from types import SimpleNamespace

import lgpio_pwm_consumers_eval as bench
import pytest
import test_kernel_pwm_lgpio_baseline_eval as original_fakes

ROOT = "/tmp/blinka-pwm-lgpio-consumers.abc123"
original_environment = original_fakes.environment


class PrivateLgpio:
    SET_PULL_NONE, TX_PWM, exceptions = 128, 0, False

    def __init__(self):
        self.log, self.claimed, self.foreign = [], set(), set()
        self.levels, self.busy = {18: 0, 23: 0}, {18: False, 23: False}
        self.hook, self.fail, self.claim_result = None, None, 0
        self.chip_info = [0, 54, "gpiochip4", "pinctrl-rp1"]

    def note(self, name, *args):
        self.log.append((name, *args))
        if self.hook:
            self.hook(name, args)
        if self.fail and self.fail(name, args):
            raise OSError("injected " + name)

    def get_module_version(self):
        return "fake-lgpio"

    def gpiochip_open(self, chip):
        assert chip == 4
        self.note("open", chip)
        return 7

    def gpiochip_close(self, handle):
        assert handle == 7
        self.note("close", handle, tuple(sorted(self.claimed)))
        self.claimed.clear()
        return 0

    def gpio_get_chip_info(self, handle):
        assert handle == 7
        self.note("chip_info", handle)
        return list(self.chip_info)

    def gpio_get_mode(self, handle, gpio):
        assert handle == 7 and gpio in (18, 23)
        self.note("mode", handle, gpio)
        return int(gpio in self.claimed | self.foreign)

    def gpio_get_line_info(self, handle, gpio):
        self.note("line_info", handle, gpio)
        used = gpio in self.claimed | self.foreign
        return [0, gpio, int(used), f"GPIO{gpio}", "foreign" if used else ""]

    def gpio_claim_output(self, handle, gpio, *, lFlags):
        assert handle == 7 and gpio in (18, 23) and lFlags == 128
        assert gpio not in self.claimed | self.foreign
        if self.claim_result >= 0:
            self.claimed.add(gpio)
        self.note("claim", handle, gpio, lFlags)
        return self.claim_result

    def tx_pwm(self, handle, gpio, frequency, duty):
        assert handle == 7 and gpio in self.claimed
        self.note("tx", handle, gpio, frequency, duty)
        self.busy[gpio], self.levels[gpio] = bool(frequency), int(bool(duty))
        return 0

    def gpio_write(self, handle, gpio, level):
        assert handle == 7 and gpio in self.claimed and level == 0
        self.note("write", handle, gpio, level)
        self.levels[gpio] = level
        return 0

    def gpio_read(self, handle, gpio):
        assert handle == 7 and gpio in self.claimed
        self.note("read", handle, gpio)
        return self.levels[gpio]

    def tx_busy(self, handle, gpio, kind):
        assert handle == 7 and gpio in self.claimed and kind == 0
        self.note("busy", handle, gpio, kind)
        return int(self.busy[gpio])

    def gpio_free(self, handle, gpio):
        assert handle == 7 and gpio in self.claimed
        self.note("free", handle, gpio)
        self.claimed.remove(gpio)
        return 0


@pytest.fixture
def environment(original_environment, monkeypatch):
    _old, _dt, _pwm, sleeps = original_environment
    fake = PrivateLgpio()

    class Chip:
        def __init__(self, path):
            assert path == "/dev/gpiochip4"

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            pass

        def get_info(self):
            return SimpleNamespace(name="gpiochip4", label="pinctrl-rp1", num_lines=54)

        def get_line_info(self, gpio):
            used = gpio in fake.claimed | fake.foreign
            return SimpleNamespace(
                offset=gpio,
                name=f"GPIO{gpio}",
                used=used,
                consumer="lgpio" if used else None,
            )

    monkeypatch.setitem(sys.modules, "lgpio", fake)
    monkeypatch.setattr(
        bench.marker,
        "load_libraries",
        lambda: (SimpleNamespace(Chip=Chip, __version__="2.5.0"), fake),
    )
    manifest = {
        "schema_version": 1,
        "motor_version": "3.5.0",
        "source_sha256": {
            key: bench.SOURCE_PINS.get(key, "a" * 64) for key in bench.SOURCE_KEYS
        },
    }
    manifest["source_sha256"][bench.NEW_SOURCE] = hashlib.sha256(
        Path(bench.__file__).read_bytes()
    ).hexdigest()
    monkeypatch.setattr(bench, "approved_manifest_path", lambda path: Path(path))
    monkeypatch.setattr(bench, "load_manifest", lambda path: manifest)
    monkeypatch.setattr(bench, "source_hashes", lambda: dict(manifest["source_sha256"]))
    guard = bench.core.SafetySignals()
    monkeypatch.setattr(bench.core, "SafetySignals", lambda: guard)
    clock = [1_000_000]

    def now():
        clock[0] += 1000
        return clock[0]

    def sleep(duration):
        sleeps.append(duration)
        clock[0] += round(duration * 1e9)

    monkeypatch.setattr(bench.time, "monotonic_ns", now)
    monkeypatch.setattr(bench.time, "sleep", sleep)
    for name in (
        "pwmio",
        "adafruit_motor",
        "adafruit_motor.servo",
        "adafruit_motor.motor",
    ):
        monkeypatch.delitem(sys.modules, name, raising=False)
    return fake, guard, manifest, sleeps


def run(environment):
    return bench.experiment(ROOT + "/manifest.json")


def test_genuine_consumers_original_rounding_and_independent_private_lifetimes(
    environment, capsys
):
    fake, _guard, manifest, sleeps = environment
    receipt = run(environment)
    assert receipt["success"], receipt
    bench.validate_receipt(receipt, manifest)
    assert (
        bench.SEQUENCE is bench.protocol.SEQUENCE
        and bench.OUTPUTS is bench.protocol.OUTPUTS
    )
    assert not capsys.readouterr().out  # Original False default, no True warning.
    assert receipt["consumers"]["version"] == "3.5.0"
    assert receipt["integration_shim"]["restored"] and "pwmio" not in sys.modules
    actions = receipt["actions"]
    assert [a["api_state_after"][0]["duty_u16"] for a in actions[:4]] == [
        3276,
        4914,
        6553,
        0,
    ]
    assert [a["api_state_after"][0]["submitted_duty_percent"] for a in actions[:4]] == [
        5,
        7,
        10,
        0,
    ]
    assert [
        a["api_state_after"][0]["submitted_nominal_high_us"] for a in actions[:4]
    ] == [1000, 1400, 2000, 0]
    assert actions[1]["consumer_readback"] == pytest.approx(89.97253585596583)
    assert [
        tuple(r["duty_u16"] for r in a["api_state_after"]) for a in actions[4:]
    ] == [
        (65535, 65535),
        (32767, 0),
        (65535, 0),
        (0, 32767),
        (0, 65535),
        (0, 0),
    ]
    assert actions[5]["api_state_after"][0]["submitted_nominal_high_us"] == 500
    assert [r["output_id"] for r in receipt["shutdowns"]] == [
        r[0] for r in bench.OUTPUTS
    ]
    assert all(
        r["ownership"]
        == {"private_chip_handle": 7, "gpio": r["gpio"], "generation": r["generation"]}
        for r in receipt["outputs"]
    )
    assert (
        receipt["shutdowns"][1]["sibling_before"]
        == receipt["shutdowns"][1]["sibling_after"]
    )
    assert receipt["shutdowns"][1]["sibling_after"]["ownership"]["gpio"] == 23
    assert fake.log[-1] == ("close", 7, ()) and not fake.claimed
    assert [row[2] for row in fake.log if row[0] == "free"] == [18, 18, 23]
    assert fake.levels == {18: 0, 23: 0} and fake.exceptions is False
    assert sum(sleeps) == pytest.approx(3.75)
    assert (
        not receipt["public_deinit_cancels_or_frees_gpio"]
        and receipt["additional_lab_cleanup_required"]
    )
    assert (
        receipt["native_backend_executed"] is False and receipt["parity_pass"] is None
    )
    # Nested tx spans finish before their caller. Do not assert serial clocks.
    nested = [e for e in receipt["events"] if e["parent_event_id"] is not None]
    assert nested and any(e["operation"] == "tx_pwm" for e in nested)


@pytest.mark.parametrize("gpio", [18, 23])
def test_foreign_pin_preclaim_prevents_private_chip_open_and_any_mutation(
    environment, gpio
):
    fake, *_ = environment
    fake.foreign.add(gpio)
    receipt = run(environment)
    assert not receipt["success"] and "fresh unused" in receipt["primary_error"]
    assert fake.log == [] and fake.foreign == {gpio}


@pytest.mark.parametrize("gate", ["source", "pin", "flag", "thermal", "chip"])
def test_source_flags_thermal_and_controller_gates(environment, monkeypatch, gate):
    fake, _guard, manifest, _sleeps = environment
    if gate == "source":
        monkeypatch.setattr(
            bench,
            "source_hashes",
            lambda: {**manifest["source_sha256"], "lgpio.py": "0" * 64},
        )
    elif gate == "pin":
        manifest["source_sha256"]["baseline_pwmout.py"] = "0" * 64
    elif gate == "flag":
        monkeypatch.setenv("BLINKA_PWM_SHARED", "1")
    elif gate == "thermal":
        monkeypatch.setattr(
            bench.core,
            "system_snapshot",
            lambda: {"temperature_millic": "66000", "throttled": "throttled=0x0"},
        )
    else:
        fake.chip_info[3] = "foreign-chip"
    receipt = run(environment)
    assert not receipt["success"] and receipt["primary_error"]
    assert not any(row[0] in ("claim", "tx", "free", "write") for row in fake.log)
    if gate == "chip":
        assert receipt["chip_closed"] and receipt["library_hooks_restored"]
    else:
        assert not fake.log


@pytest.mark.parametrize("point", ["open", "second_motor_claim"])
def test_signal_after_owned_resource_created_is_latched_before_abort(
    environment, point
):
    fake, guard, *_ = environment

    def hook(name, args):
        if (point == "open" and name == "open") or (
            point == "second_motor_claim" and name == "claim" and args[1] == 23
        ):
            guard.handler(signal.SIGTERM, None)

    fake.hook = hook
    receipt = run(environment)
    assert not receipt["success"] and "SafetyAbort" in receipt["primary_error"]
    assert receipt["signals_received"] == [signal.SIGTERM]
    assert (
        receipt["chip_closed"]
        and receipt["library_hooks_restored"]
        and not fake.claimed
    )
    assert all(row["freed"] and row["released"] for row in receipt["outputs"])


def test_partial_constructor_tx_failure_cleans_claim_without_reading_uninitialized_api(
    environment,
):
    fake, *_ = environment
    fake.fail = lambda name, args: name == "tx" and args[1:] == (23, 1000, 0)
    receipt = run(environment)
    assert not receipt["success"] and "injected tx" in receipt["primary_error"]
    assert len(receipt["outputs"]) == 3 and all(
        r["released"] for r in receipt["outputs"]
    )
    assert (
        not fake.claimed
        and receipt["chip_closed"]
        and receipt["library_hooks_restored"]
    )


@pytest.mark.filterwarnings("ignore::pytest.PytestUnraisableExceptionWarning")
@pytest.mark.parametrize("problem", ["claim_rejected", "foreign_appeared_after_open"])
def test_rejected_constructor_never_cleans_a_line_it_did_not_claim(
    environment, problem
):
    fake, *_ = environment
    if problem == "claim_rejected":
        fake.claim_result = -5
    else:
        fake.hook = lambda name, _args: fake.foreign.add(23) if name == "open" else None
    receipt = run(environment)
    assert not receipt["success"] and receipt["primary_error"]
    target = 18 if problem == "claim_rejected" else 23
    assert not any(
        row[0] in ("tx", "write", "free") and row[2] == target for row in fake.log
    )
    assert receipt["chip_closed"] and not fake.claimed
    if target == 23:
        assert fake.foreign == {23}
        assert all(row["released"] for row in receipt["outputs"][:2])
    assert any("original_PWMOut.deinit" in error for error in receipt["cleanup_errors"])
    # Frozen original __del__ is also unsafe after its rejected constructor.
    # Do not patch it: the explicit attempted deinit failure is retained above.
    gc.collect()


def test_ownership_hooks_reject_foreign_handles_pins_and_unowned_submissions(
    environment,
):
    fake, guard, *_ = environment
    receipt = {"events": [], "outputs": [], "cleanup_errors": [], "chip_closed": False}
    registry = bench.Registry(
        fake, None, {"gpiochip_index": 4, "gpiochip": "/dev/gpiochip4"}, guard, receipt
    )
    for chip in (0, True):
        with pytest.raises(bench.core.BenchError):
            registry.open(chip)
    registry.open(4)
    before = list(fake.log)
    owner = bench.Owner(registry, "servo18-g1")
    registry.constructing = owner
    for handle, gpio in ((8, 18), (7, 17), (7, 23)):
        with pytest.raises(bench.core.BenchError):
            registry.claim(handle, gpio, lFlags=128)
    with pytest.raises(bench.core.BenchError):
        registry.tx(7, 18, 50, 10)
    with pytest.raises(bench.core.BenchError):
        registry.open(4)
    assert fake.log == before
    registry.close()


def test_caller_error_is_preserved_even_when_explicit_lab_cancel_also_fails(
    environment,
):
    fake, *_ = environment
    caller_failed = [False]

    def fail(name, args):
        if name == "tx" and args[1:] == (18, 1000, 50):
            caller_failed[0] = True
            return True
        return caller_failed[0] and name == "tx" and args[1:] == (18, 0, 0)

    fake.fail = fail
    receipt = run(environment)
    assert not receipt["success"] and "injected tx" in receipt["primary_error"]
    assert receipt["actions"][-1]["status"] == "error"
    assert any("lab.cancel_tx_pwm" in e for e in receipt["cleanup_errors"])
    assert not fake.claimed and all(r["released"] for r in receipt["outputs"])


def test_sibling_observation_failure_does_not_skip_owned_target_cleanup(environment):
    fake, *_ = environment
    fake.fail = lambda name, args: (
        name == "read"
        and args[1] == 23
        and sum(row[0] == "read" and row[2] == 23 for row in fake.log) == 2
    )
    receipt = run(environment)
    assert not receipt["success"] and receipt["cleanup_errors"]
    assert [row[2] for row in fake.log if row[0] == "free"] == [18, 18, 23]
    assert not fake.claimed and receipt["chip_closed"]
    assert receipt["outputs"][1]["low_confirmed"]


def test_unexpected_cleanup_exception_does_not_replace_primary_or_skip_sibling(
    environment, monkeypatch
):
    fake, *_ = environment
    fake.fail = lambda name, args: name == "tx" and args[1:] == (18, 1000, 50)
    original = bench.Registry.cleanup

    def cleanup(registry, owner, *args, **kwargs):
        original(registry, owner, *args, **kwargs)
        if owner.output_id == "motor18-g2":
            raise RuntimeError("unexpected cleanup bookkeeping")

    monkeypatch.setattr(bench.Registry, "cleanup", cleanup)
    receipt = run(environment)
    assert "injected tx" in receipt["primary_error"]
    assert any("unexpected cleanup bookkeeping" in e for e in receipt["cleanup_errors"])
    assert not fake.claimed and all(r["released"] for r in receipt["outputs"])


@pytest.mark.parametrize(
    "mutation",
    ["action_order", "phase_clock", "phase_state", "sibling", "percent", "default"],
)
def test_compact_receipt_validation_rejects_protocol_or_ownership_mismatch(
    environment, mutation
):
    receipt = run(environment)
    manifest = environment[2]
    bench.validate_receipt(receipt, manifest)
    bad = copy.deepcopy(receipt)
    if mutation == "action_order":
        bad["actions"][0] = copy.deepcopy(bad["actions"][1])
    elif mutation == "phase_clock":
        bad["phases"][7]["begin_ns"] = bad["phases"][6]["begin_ns"]
    elif mutation == "phase_state":
        bad["phases"][8]["api_state"][0]["duty_u16"] = 32768
    elif mutation == "sibling":
        bad["shutdowns"][1]["sibling_after"]["ownership"]["gpio"] = 18
    elif mutation == "percent":
        bad["actions"][1]["api_state_after"][0]["submitted_duty_percent"] = (
            7.498283360036621
        )
    else:
        bad["variable_frequency"] = True
    with pytest.raises(bench.core.BenchError):
        bench.validate_receipt(bad, manifest)


def test_manifest_selected_sources_are_exact_and_genuine(environment):
    manifest = environment[2]
    assert len(bench.validate_manifest(manifest)) == 21
    assert not (bench.NATIVE_PACKAGE_KEYS & bench.SOURCE_KEYS)
    assert {
        key: hashlib.sha256(path.read_bytes()).hexdigest()
        for key, path in bench.protocol.consumer_inventory().items()
    } == bench.protocol.CONSUMER_PINS
    for key, digest in bench.SOURCE_PINS.items():
        if "/" not in key:
            assert (
                hashlib.sha256(
                    Path(bench.__file__).with_name(key).read_bytes()
                ).hexdigest()
                == digest
            )
    with pytest.raises(bench.core.BenchError):
        bench.validate_manifest({**manifest, "motor_version": "3.4.0"})


@pytest.mark.parametrize(
    "path", ["manifest.json", "/tmp/manifest.json", ROOT + "/../manifest.json"]
)
def test_manifest_path_rejects_nonisolated_targets(path):
    with pytest.raises(bench.core.BenchError):
        bench.approved_manifest_path(path)
