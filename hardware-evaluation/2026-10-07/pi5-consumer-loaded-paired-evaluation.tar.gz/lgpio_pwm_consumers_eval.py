"""Lab-only genuine original-lgpio Servo/DCMotor reference on passive probes.

The imported consumer protocol is unchanged. Original setters, percent rounding
and Pin chip discovery are unmodified. Scoped library open/claim/tx hooks only
enforce and record private ownership. Explicit lab cancellation/low/free cleanup
is NOT a production deinit capability. Nested caller/library spans are retained
in completion order, not falsely asserted to be serial. No actuators or native
PWM backend are executed; the in-memory pwmio export is not installed Blinka.
"""

import argparse
import hashlib
import json
import os
import re
import signal
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import gpio_pwm_marker_eval as marker
import native_pwm_consumers_eval as protocol

baseline, core = marker.baseline, marker.core
SEQUENCE, OUTPUTS = protocol.SEQUENCE, protocol.OUTPUTS
MODE, BACKEND = protocol.MODE, "original-blinka-lgpio"
SEQUENCE_MARKER = "original-lgpio-servo-dcmotor-v1"
ROOT_PATTERN = r"/tmp/blinka-pwm-lgpio-consumers\.[A-Za-z0-9]{6}"
MAX_RUN_SECONDS = 14
NEW_SOURCE = "lgpio_pwm_consumers_eval.py"
PWM_KEY = "_lab_original_lgpio_consumers_pwmout"
NATIVE_PACKAGE_KEYS = {
    marker.base.PACKAGE + "/" + name
    for name in ("__init__.py", "_software.py", "_native.so")
}
SOURCE_KEYS = (
    (marker.SOURCE_KEYS - NATIVE_PACKAGE_KEYS)
    | {
        "native_pwm_dual_eval.py",
        "native_pwm_consumers_eval.py",
        NEW_SOURCE,
    }
    | set(protocol.CONSUMER_PINS)
)
SOURCE_PINS = {
    **marker.SOURCE_PINS,
    **protocol.CONSUMER_PINS,
    "gpio_pwm_marker_eval.py": "7528cd4a4378be4bfc24419255fdb199a45f912fb9a4d8b70e143faa43cea456",
    "native_pwm_dual_eval.py": "4d051ad2f4378a7aaaa4f45b89098f6766f4197362ba7a353970c94630c8b93b",
    "native_pwm_consumers_eval.py": "db6d32ec066a7683fd85613f638f60a7e13e7a736cea362e9fe4b751641b54dc",
}


def validate_manifest(manifest):
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
        or manifest.get("motor_version") != "3.5.0"
    ):
        raise core.BenchError("Original consumer motor3.5.0 manifest required")
    hashes = manifest.get("source_sha256")
    if (
        not isinstance(hashes, dict)
        or set(hashes) != SOURCE_KEYS
        or any(
            not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None
            for value in hashes.values()
        )
    ):
        raise core.BenchError(
            "Exact21 selected original consumer source hashes required"
        )
    if any(hashes[key] != digest for key, digest in SOURCE_PINS.items()):
        raise core.BenchError("Frozen original/helper/consumer sources changed")
    return hashes


def load_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise core.BenchError("Duplicate manifest key: " + key)
            result[key] = value
        return result

    manifest = json.loads(Path(path).read_text(), object_pairs_hook=pairs)
    validate_manifest(manifest)
    return manifest


def approved_manifest_path(path):
    path = Path(path)
    if (
        not path.is_absolute()
        or re.fullmatch(ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", str(path)) is None
    ):
        raise core.BenchError("Absolute isolated lgpio-consumers manifest required")
    if (
        path.resolve(strict=True) != path
        or path.parent != Path(__file__).resolve().parent
    ):
        raise core.BenchError(
            "Original helper and manifest must share an isolated nonsymlink root"
        )
    return path


def source_hashes():
    # The marker inventory resolves this interpreter's gpiod before distro lgpio.
    # Do not call marker.source_hashes: this run never executes native PWM.
    paths = {
        **marker.source_inventory(),
        **protocol.consumer_inventory(),
        "native_pwm_dual_eval.py": Path(protocol.dual.__file__),
        "native_pwm_consumers_eval.py": Path(protocol.__file__),
        NEW_SOURCE: Path(__file__),
    }
    return {
        key: hashlib.sha256(path.read_bytes()).hexdigest()
        for key, path in paths.items()
    }


class Owner:
    def __init__(self, registry, output_id):
        matches = [row for row in OUTPUTS if row[0] == output_id]
        if len(matches) != 1:
            raise core.BenchError("Unapproved original consumer generation")
        self.output_id, self.gpio, self.generation, self.frequency = matches[0]
        self.registry, self.pwm, self.line_owned, self.cleaned = (
            registry,
            None,
            False,
            False,
        )
        self.record = {
            "output_id": output_id,
            "gpio": self.gpio,
            "generation": self.generation,
            "initial_frequency": self.frequency,
            "variable_frequency": False,
            "fresh_claim_accepted": False,
            "initial_low_confirmed": False,
            "low_confirmed": False,
            "freed": False,
            "released": False,
            "ownership": None,
            "cleanup_final_readback": None,
            "last_submission": None,
        }
        registry.receipt["outputs"].append(self.record)

    def construct(self, pin_class, pwm_class):
        self.pwm = pwm_class.__new__(pwm_class)
        self.registry.constructing = self
        try:
            with self.registry.guard.atomic():
                self.registry.call(
                    "original_PWMOut.__init__",
                    lambda: self.pwm.__init__(
                        pin_class(self.gpio), frequency=self.frequency, duty_cycle=0
                    ),
                    self,
                    {
                        "gpio": self.gpio,
                        "frequency": self.frequency,
                        "duty_u16": 0,
                        "variable_frequency": False,
                    },
                )
                self.registry.scope_check(self.registry.handle, self.gpio)
                level = self.registry.call(
                    "initial_gpio_read",
                    lambda: self.registry.library.gpio_read(
                        self.registry.handle, self.gpio
                    ),
                    self,
                )
                self.record["initial_low_confirmed"] = type(level) is int and level == 0
                self.record["initial_readback"] = {"gpio_level": level}
                if not self.record["initial_low_confirmed"]:
                    raise core.BenchError(
                        "New private original output did not read low"
                    )
        finally:
            self.registry.constructing = None

    def snapshot(self, private_read=False):
        self.registry.scope_check(self.registry.handle, self.gpio)
        submitted = self.record["last_submission"]
        result = {
            "output_id": self.output_id,
            "gpio": self.gpio,
            "generation": self.generation,
            "ownership": dict(self.record["ownership"]),
            "frequency": self.pwm.frequency,
            "duty_u16": self.pwm.duty_cycle,
            "enabled": self.pwm.enabled,
            "submitted_duty_percent": submitted["duty_percent"],
            "submitted_nominal_high_us": submitted["nominal_high_us"],
        }
        if private_read:
            result["gpio_level"] = self.registry.checked(
                self.registry.call(
                    "sibling_gpio_read",
                    lambda: self.registry.library.gpio_read(
                        self.registry.handle, self.gpio
                    ),
                    self,
                )
            )
        return result


class Registry:
    def __init__(self, library, gpio_library, identity, guard, receipt):
        self.library, self.gpio_library, self.identity, self.guard, self.receipt = (
            library,
            gpio_library,
            identity,
            guard,
            receipt,
        )
        self.handle, self.chip_owned, self.constructing = None, False, None
        self.active, self.owners, self.stack = {}, {}, []
        self.event_id, self.scope = 0, "initialization"
        self.original = {
            name: getattr(library, name)
            for name in ("gpiochip_open", "gpio_claim_output", "tx_pwm")
        }

    @staticmethod
    def checked(value):
        if type(value) is not int or value < 0:
            raise core.BenchError(f"Unexpected lgpio result: {value!r}")
        return value

    def call(self, name, operation, owner=None, arguments=None):
        event_id = self.event_id
        self.event_id += 1
        event = {
            "event_id": event_id,
            "parent_event_id": self.stack[-1] if self.stack else None,
            "operation": name,
            "scope": self.scope,
            "output_id": owner.output_id if owner else None,
            "arguments": arguments,
            "begin_ns": time.monotonic_ns(),
        }
        self.stack.append(event_id)
        try:
            value = operation()
            event["status"] = "ok"
            if value is None or type(value) in (
                int,
                bool,
                float,
                str,
                list,
                tuple,
                dict,
            ):
                event["result"] = value
            return value
        except BaseException as error:
            event.update(status="error", error=f"{type(error).__name__}: {error}")
            raise
        finally:
            self.stack.pop()
            event["end_ns"] = time.monotonic_ns()
            self.receipt["events"].append(event)

    def open(self, chip):
        if (
            self.chip_owned
            or type(chip) is not int
            or chip != self.identity["gpiochip_index"]
        ):
            raise core.BenchError(
                "Only one private verified RP1 chip open is authorized"
            )
        with self.guard.atomic():
            self.handle = self.checked(
                self.call(
                    "gpiochip_open",
                    lambda: self.original["gpiochip_open"](chip),
                    arguments=[chip],
                )
            )
            self.chip_owned = True
        info = self.call(
            "gpio_get_chip_info", lambda: self.library.gpio_get_chip_info(self.handle)
        )
        if (
            not isinstance(info, (list, tuple))
            or len(info) != 4
            or type(info[0]) is not int
            or info[0] != 0
            or type(info[1]) is not int
            or info[1] <= 23
            or info[2] != Path(self.identity["gpiochip"]).name
            or info[3] != "pinctrl-rp1"
        ):
            raise core.BenchError(
                "Opened original chip is not the verified RP1 controller"
            )
        self.receipt["chip_info"] = list(info)
        self.receipt["private_chip_handle"] = self.handle
        return self.handle

    def scope_check(self, handle, gpio, *, claiming=False):
        owner = self.constructing if claiming else self.active.get(gpio)
        if (
            handle != self.handle
            or not self.chip_owned
            or type(gpio) is not int
            or gpio not in (18, 23)
            or owner is None
            or owner.gpio != gpio
            or (not claiming and not owner.line_owned)
        ):
            raise core.BenchError(
                "Only this generation's privately owned original line is authorized"
            )
        return owner

    def claim(self, handle, gpio, *args, **kwargs):
        owner = self.scope_check(handle, gpio, claiming=True)
        if gpio in self.active or owner.line_owned:
            raise core.BenchError("Refusing repeated/borrowed original line claim")
        mode = self.checked(
            self.call(
                "gpio_get_mode_preclaim",
                lambda: self.library.gpio_get_mode(handle, gpio),
                owner,
            )
        )
        info = self.call(
            "gpio_get_line_info_preclaim",
            lambda: self.library.gpio_get_line_info(handle, gpio),
            owner,
        )
        _chip, line = marker.inspect(self.gpio_library, self.identity, gpio)
        if (
            not isinstance(info, (list, tuple))
            or len(info) != 5
            or type(info[0]) is not int
            or info[0] != 0
            or type(info[1]) is not int
            or info[1] != gpio
            or type(info[2]) is not int
        ):
            raise core.BenchError("Malformed original preclaim line information")
        owner.record.update(
            preclaim_mode=mode,
            preclaim_line_info=list(info),
            read_only_preclaim_line_info=line,
        )
        if (
            mode & 1
            or info[2] & 1
            or info[4] != ""
            or line["used"]
            or line["consumer"] not in (None, "")
        ):
            raise core.BenchError(
                "Original consumer GPIO already claimed; never borrow it"
            )
        with self.guard.atomic():
            value = self.checked(
                self.call(
                    "gpio_claim_output",
                    lambda: self.original["gpio_claim_output"](
                        handle, gpio, *args, **kwargs
                    ),
                    owner,
                    {
                        "private_handle": handle,
                        "gpio": gpio,
                        "args": list(args),
                        "kwargs": kwargs,
                    },
                )
            )
            # Ownership is latched before deferred signals can be raised.
            self.active[gpio], owner.line_owned = owner, True
            owner.record.update(
                fresh_claim_accepted=True,
                ownership={
                    "private_chip_handle": handle,
                    "gpio": gpio,
                    "generation": owner.generation,
                },
            )
        return value

    def tx(self, handle, gpio, *args, **kwargs):
        owner = self.scope_check(handle, gpio)
        result = self.checked(
            self.call(
                "tx_pwm",
                lambda: self.original["tx_pwm"](handle, gpio, *args, **kwargs),
                owner,
                {
                    "private_handle": handle,
                    "gpio": gpio,
                    "args": list(args),
                    "kwargs": kwargs,
                },
            )
        )
        frequency, duty = args[:2]
        owner.record["last_submission"] = {
            "frequency": frequency,
            "duty_percent": duty,
            "nominal_high_us": 1_000_000 / frequency * duty / 100
            if frequency
            else None,
        }
        return result

    @contextmanager
    def hooks(self):
        previous = {name: sys.modules.get(name) for name in (baseline.PIN_KEY, PWM_KEY)}
        old_exceptions = self.library.exceptions
        (
            self.library.gpiochip_open,
            self.library.gpio_claim_output,
            self.library.tx_pwm,
        ) = self.open, self.claim, self.tx
        try:
            pin = baseline.load_source(baseline.PIN_KEY, "lgpio_pin.py")
            pwm = baseline.load_source(PWM_KEY, "baseline_pwmout.py")
            yield pin, pwm
        finally:
            with self.guard.cleanup():
                for name, function in self.original.items():
                    setattr(self.library, name, function)
                self.library.exceptions = old_exceptions
                for name, module in previous.items():
                    if module is None:
                        sys.modules.pop(name, None)
                    else:
                        sys.modules[name] = module
                self.receipt["library_hooks_restored"] = True

    def snapshots(self):
        return [owner.snapshot() for owner in self.owners.values() if owner.line_owned]

    def cleanup(self, owner, sibling=None, reason="safety_cleanup"):
        if owner.cleaned or owner.pwm is None:
            return
        record = {
            "output_id": owner.output_id,
            "scope": self.scope,
            "reason": reason,
            "sibling_id": sibling.output_id if sibling else None,
            "sibling_before": None,
            "sibling_after": None,
            "begin_ns": time.monotonic_ns(),
            "errors": [],
            "success": False,
        }
        self.receipt["shutdowns"].append(record)

        def attempt(name, operation, checked=True):
            try:
                value = self.call(name, operation, owner)
                return self.checked(value) if checked else value
            except BaseException as error:
                record["errors"].append(f"{name}: {type(error).__name__}: {error}")
                return None

        with self.guard.cleanup():
            if sibling:
                try:
                    record["sibling_before"] = sibling.snapshot(True)
                except BaseException as error:
                    record["errors"].append(
                        f"Continuing sibling before cleanup: {type(error).__name__}: {error}"
                    )
            try:
                if owner.line_owned:
                    if self.scope_check(self.handle, owner.gpio) is not owner:
                        raise core.BenchError("Cleanup generation ownership changed")
                    attempt(
                        "lab.cancel_tx_pwm",
                        lambda: self.original["tx_pwm"](self.handle, owner.gpio, 0, 0),
                    )
                    attempt(
                        "lab.drive_low",
                        lambda: self.library.gpio_write(self.handle, owner.gpio, 0),
                    )
                    attempt("lab.low_settle", lambda: time.sleep(0.1), False)
                    level = attempt(
                        "lab.gpio_read_low",
                        lambda: self.library.gpio_read(self.handle, owner.gpio),
                    )
                    busy = attempt(
                        "lab.tx_busy",
                        lambda: self.library.tx_busy(
                            self.handle, owner.gpio, self.library.TX_PWM
                        ),
                    )
                    owner.record["cleanup_final_readback"] = {
                        "gpio_level": level,
                        "tx_busy": busy,
                    }
                    owner.record["low_confirmed"] = (
                        type(level) is int
                        and level == 0
                        and type(busy) is int
                        and busy == 0
                    )
                    if not owner.record["low_confirmed"]:
                        record["errors"].append(
                            "Privately canceled settled low/not-busy not confirmed"
                        )
            except BaseException as error:
                record["errors"].append(
                    f"Cleanup preparation: {type(error).__name__}: {error}"
                )
            finally:
                # Original deinit only changes flags. The explicit cancel/drive
                # above and free below are distinct lab cleanup operations.
                attempt("original_PWMOut.deinit", owner.pwm.deinit, False)
                if (
                    owner.line_owned
                    and self.chip_owned
                    and self.active.get(owner.gpio) is owner
                ):
                    freed = attempt(
                        "lab.gpio_free",
                        lambda: self.library.gpio_free(self.handle, owner.gpio),
                    )
                    if freed is not None:
                        owner.line_owned = False
                        self.active.pop(owner.gpio)
                        owner.record["freed"] = True
                        mode = attempt(
                            "gpio_get_mode_released",
                            lambda: self.library.gpio_get_mode(self.handle, owner.gpio),
                        )
                        inspected = attempt(
                            "read_only_line_released",
                            lambda: marker.inspect(
                                self.gpio_library, self.identity, owner.gpio
                            ),
                            False,
                        )
                        if inspected is not None:
                            owner.record.update(
                                released_mode=mode,
                                released_line_info=inspected[1],
                                released=mode is not None
                                and not (mode & 0xF01)
                                and inspected[1]["used"] is False
                                and inspected[1]["consumer"] in (None, ""),
                            )
                owner.cleaned = True
                if not owner.record["released"]:
                    record["errors"].append(
                        "Private line release not confirmed; no reclaim attempted"
                    )
                if sibling:
                    try:
                        record["sibling_after"] = sibling.snapshot(True)
                    except BaseException as error:
                        record["errors"].append(
                            f"Continuing sibling: {type(error).__name__}: {error}"
                        )
                    before, after = record["sibling_before"], record["sibling_after"]
                    if (
                        before is None
                        or after is None
                        or {
                            key: value
                            for key, value in before.items()
                            if key != "gpio_level"
                        }
                        != {
                            key: value
                            for key, value in after.items()
                            if key != "gpio_level"
                        }
                    ):
                        record["errors"].append(
                            "Sibling private ownership/API changed during line cleanup"
                        )
                record["end_ns"] = time.monotonic_ns()
                record["success"] = (
                    owner.record["fresh_claim_accepted"]
                    and owner.record["low_confirmed"]
                    and owner.record["released"]
                    and not record["errors"]
                )
                self.receipt["cleanup_errors"].extend(
                    owner.output_id + ": " + error for error in record["errors"]
                )

    def close(self):
        if not self.chip_owned:
            return
        try:
            self.checked(
                self.call(
                    "lab.private_gpiochip_close",
                    lambda: self.library.gpiochip_close(self.handle),
                )
            )
            self.chip_owned = False
            self.receipt["chip_closed"] = True
        except BaseException as error:
            self.receipt["cleanup_errors"].append(
                f"Private chip close: {type(error).__name__}: {error}"
            )


def run_protocol(registry, pin, pwm, servo_module, motor_module):
    servo = motor = None
    for index, (name, duration, operation, value) in enumerate(SEQUENCE):
        registry.scope = f"{index:02d}_{name}"
        phase = {
            "index": index,
            "name": name,
            "scope": registry.scope,
            "operation": operation,
            "value": value,
            "duration_seconds": duration,
            "begin_ns": time.monotonic_ns(),
        }
        if operation in ("servo_initialize", "motor_initialize"):
            ids = (
                ("servo18-g1",)
                if operation == "servo_initialize"
                else ("motor18-g2", "motor23-g1")
            )
            for output_id in ids:
                owner = Owner(registry, output_id)
                registry.owners[output_id] = owner
                owner.construct(pin.Pin, pwm.PWMOut)
            if operation == "servo_initialize":
                servo = registry.call(
                    "Servo.__init__",
                    lambda: servo_module.Servo(
                        registry.owners["servo18-g1"].pwm,
                        actuation_range=180,
                        min_pulse=1000,
                        max_pulse=2000,
                    ),
                    registry.owners["servo18-g1"],
                )
            else:
                motor = registry.call(
                    "DCMotor.__init__",
                    lambda: motor_module.DCMotor(
                        registry.owners["motor18-g2"].pwm,
                        registry.owners["motor23-g1"].pwm,
                    ),
                    registry.owners["motor18-g2"],
                )
        elif operation in ("Servo.angle", "DCMotor.throttle"):
            controller, attribute = (
                (servo, "angle") if operation == "Servo.angle" else (motor, "throttle")
            )
            owner = registry.owners["servo18-g1" if servo else "motor18-g2"]
            action = {
                "phase_index": index,
                "operation": operation,
                "value": value,
                "begin_ns": time.monotonic_ns(),
                "api_state_before": registry.snapshots(),
            }
            registry.receipt["actions"].append(action)
            try:
                registry.call(
                    operation,
                    lambda: setattr(controller, attribute, value),
                    owner,
                    {"value": value},
                )
                action.update(
                    status="ok",
                    consumer_readback=getattr(controller, attribute),
                    api_state_after=registry.snapshots(),
                )
            except BaseException as error:
                action.update(status="error", error=f"{type(error).__name__}: {error}")
                raise
            finally:
                action["end_ns"] = time.monotonic_ns()
        else:
            output_id = (
                "servo18-g1"
                if operation == "servo_release"
                else "motor18-g2"
                if operation == "motor_release_positive"
                else "motor23-g1"
            )
            sibling = (
                registry.owners["motor23-g1"]
                if operation == "motor_release_positive"
                else None
            )
            with registry.guard.atomic():
                registry.cleanup(registry.owners[output_id], sibling, "sequence")
                if not registry.receipt["shutdowns"][-1]["success"]:
                    raise core.BenchError(
                        "Original consumer independent line shutdown failed"
                    )
            if operation == "servo_release":
                servo = None
            else:
                motor = None
        phase["stable_begin_ns"] = time.monotonic_ns()
        phase["api_state"] = registry.snapshots()
        phase["consumer_state"] = (
            {"kind": "Servo", "angle": servo.angle}
            if servo
            else {
                "kind": "DCMotor",
                "throttle": motor.throttle,
                "decay_mode": motor.decay_mode,
            }
            if motor
            else None
        )
        time.sleep(duration)
        phase["end_ns"] = time.monotonic_ns()
        phase["api_state_end"] = registry.snapshots()
        phase["consumer_state_end"] = (
            {"kind": "Servo", "angle": servo.angle}
            if servo
            else {
                "kind": "DCMotor",
                "throttle": motor.throttle,
                "decay_mode": motor.decay_mode,
            }
            if motor
            else None
        )
        phase["readback_end_ns"] = time.monotonic_ns()
        registry.receipt["phases"].append(phase)


def validate_receipt(receipt, manifest):
    hashes = validate_manifest(manifest)
    if (
        receipt.get("source_sha256") != hashes
        or type(receipt.get("schema_version")) is not int
        or receipt["schema_version"] != 1
        or receipt.get("baseline_commit") != baseline.BLINKA_COMMIT
        or receipt.get("backend") != BACKEND
        or receipt.get("mode") != MODE
        or receipt.get("sequence_marker") != SEQUENCE_MARKER
        or receipt.get("success") is not True
    ):
        raise core.BenchError("Original consumer receipt/source contract mismatch")
    if (
        not isinstance(receipt.get("manifest_path"), str)
        or re.fullmatch(
            ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", receipt["manifest_path"]
        )
        is None
        or type(receipt.get("helper_pid")) is not int
        or receipt["helper_pid"] <= 0
        or receipt.get("gpios") != [18, 23]
        or type(receipt.get("begin_ns")) is not int
        or type(receipt.get("end_ns")) is not int
        or not 0 < receipt["end_ns"] - receipt["begin_ns"] < MAX_RUN_SECONDS * 1e9
        or receipt.get("watchdog_seconds") != MAX_RUN_SECONDS
        or receipt.get("watchdog_cannot_bound_extension_hang_or_sigkill") is not True
        or receipt.get("sequence_dwell_seconds")
        != round(sum(row[1] for row in SEQUENCE), 6)
        or receipt.get("low_settle_seconds") != 0.1
        or receipt.get("normal_fixed_wait_seconds") != 3.75
    ):
        raise core.BenchError("Original consumer root/watchdog chronology mismatch")
    if (
        receipt.get("primary_error") is not None
        or receipt.get("cleanup_errors") != []
        or receipt.get("signals_received") != []
        or receipt.get("chip_closed") is not True
        or receipt.get("library_hooks_restored") is not True
    ):
        raise core.BenchError("Original consumer ownership/cleanup failure")
    if (
        len(receipt.get("phases", [])) != 15
        or len(receipt.get("actions", [])) != 10
        or len(receipt.get("outputs", [])) != 3
        or len(receipt.get("shutdowns", [])) != 3
    ):
        raise core.BenchError("Exact imported consumer protocol required")
    if (
        receipt.get("runtime_flags") != {"short_slice": False, "shared": False}
        or receipt.get("variable_frequency") is not False
        or receipt.get("completed_normally") is not True
        or receipt.get("native_backend_executed") is not False
        or receipt.get("passive_probes_only") is not True
        or receipt.get("actual_actuators_attached") is not False
        or receipt.get("installed_blinka_compatibility_proven") is not False
        or receipt.get("production_backend_unchanged") is not True
        or receipt.get("library_hooks_are_ownership_enforcement_only") is not True
        or receipt.get("api_readbacks_are_not_electrical") is not True
        or receipt.get("public_deinit_cancels_or_frees_gpio") is not False
        or receipt.get("additional_lab_cleanup_required") is not True
        or receipt.get("parity_pass") is not None
        or receipt.get("integration_shim")
        != {
            "kind": "in-memory-pwmio-export",
            "unwrapped_public_pwm_objects": True,
            "installed_blinka_compatibility_proven": False,
            "installed_pwmio_module_used": False,
            "restored": True,
        }
        or receipt.get("consumers", {}).get("version") != "3.5.0"
        or receipt.get("gpiod_version") != "2.5.0"
        or any(
            value == "1" for value in receipt.get("inherited_environment", {}).values()
        )
        or receipt.get("identity", {}).get("kernel_release") != baseline.KERNEL
        or core.thermal_issues(receipt.get("before", {}), 65000)
        or core.thermal_issues(receipt.get("after", {}), 70000)
    ):
        raise core.BenchError("Original consumer safety/default/source gates mismatch")
    handle = receipt["private_chip_handle"]
    if type(handle) is not int or handle < 0:
        raise core.BenchError("Actual privately opened lgpio handle required")
    events = receipt.get("events", [])
    by_id = {event["event_id"]: event for event in events}
    if len(by_id) != len(events) or not events:
        raise core.BenchError("Unique recorded caller/library events required")
    for event in events:
        parent = by_id.get(event["parent_event_id"])
        if (
            event.get("status") != "ok"
            or type(event["begin_ns"]) is not int
            or type(event["end_ns"]) is not int
            or not receipt["begin_ns"]
            <= event["begin_ns"]
            < event["end_ns"]
            <= receipt["end_ns"]
            or (
                event["parent_event_id"] is not None
                and (
                    parent is None
                    or not parent["begin_ns"]
                    <= event["begin_ns"]
                    < event["end_ns"]
                    <= parent["end_ns"]
                )
            )
        ):
            raise core.BenchError("Recorded nested caller/library interval mismatch")
    constructors = [
        event for event in events if event["operation"] == "original_PWMOut.__init__"
    ]
    if [event["arguments"] for event in constructors] != [
        {
            "gpio": gpio,
            "frequency": frequency,
            "duty_u16": 0,
            "variable_frequency": False,
        }
        for _output_id, gpio, _generation, frequency in OUTPUTS
    ]:
        raise core.BenchError("Original constructors must retain the False default")
    states, expected_actions, previous = {}, [], receipt["begin_ns"]
    specs = {row[0]: row for row in OUTPUTS}

    def snapshots():
        return [
            {
                "output_id": output_id,
                "gpio": specs[output_id][1],
                "generation": specs[output_id][2],
                "ownership": {
                    "private_chip_handle": handle,
                    "gpio": specs[output_id][1],
                    "generation": specs[output_id][2],
                },
                "frequency": specs[output_id][3],
                "duty_u16": duty,
                "enabled": True,
                "submitted_duty_percent": round(duty / 65535 * 100),
                "submitted_nominal_high_us": 1_000_000
                / specs[output_id][3]
                * round(duty / 65535 * 100)
                / 100,
            }
            for output_id, duty in states.items()
        ]

    for index, (phase, spec) in enumerate(zip(receipt["phases"], SEQUENCE)):
        name, duration, operation, value = spec
        clocks = [
            phase.get(key)
            for key in ("begin_ns", "stable_begin_ns", "end_ns", "readback_end_ns")
        ]
        if (
            phase["name"],
            phase["duration_seconds"],
            phase["operation"],
            phase["value"],
        ) != spec or not (
            phase.get("index") == index
            and phase.get("scope") == f"{index:02d}_{name}"
            and all(type(clock) is int for clock in clocks)
            and previous
            <= clocks[0]
            <= clocks[1]
            < clocks[2]
            <= clocks[3]
            <= receipt["end_ns"]
            and clocks[2] - clocks[1] >= round(duration * 1e9)
        ):
            raise core.BenchError("Original consumer phase mismatch")
        previous, before = clocks[-1], snapshots()
        if operation == "servo_initialize":
            states["servo18-g1"] = 0
        elif operation == "motor_initialize":
            states.update({"motor18-g2": 0, "motor23-g1": 0})
        elif operation == "Servo.angle":
            states["servo18-g1"] = protocol.servo_duty(value)
        elif operation == "DCMotor.throttle":
            positive, negative = protocol.motor_duties(value)
            states.update({"motor18-g2": positive, "motor23-g1": negative})
        else:
            del states[
                "servo18-g1"
                if index == 5
                else "motor18-g2"
                if index == 13
                else "motor23-g1"
            ]
        after = snapshots()
        if phase["api_state"] != after or phase["api_state_end"] != after:
            raise core.BenchError("Original consumer phase private/API state mismatch")
        if operation in ("Servo.angle", "DCMotor.throttle"):
            expected_actions.append((index, before, after))
        kind = "Servo" if index < 5 else "DCMotor" if 6 <= index <= 12 else None
        for key in ("consumer_state", "consumer_state_end"):
            actual = phase.get(key)
            attribute = "angle" if kind == "Servo" else "throttle"
            expected = protocol.servo_readback(value) if kind == "Servo" else value
            if (kind is None and actual is not None) or (
                kind is not None
                and (
                    not isinstance(actual, dict)
                    or actual.get("kind") != kind
                    or not protocol.readback_matches(actual.get(attribute), expected)
                    or (kind == "DCMotor" and actual.get("decay_mode") != 0)
                )
            ):
                raise core.BenchError("Original genuine consumer phase getter mismatch")
    for action, (index, before, after) in zip(receipt["actions"], expected_actions):
        _name, _duration, operation, value = SEQUENCE[index]
        expected = (
            protocol.servo_readback(value) if operation == "Servo.angle" else value
        )
        duties = (
            (protocol.servo_duty(value),)
            if operation == "Servo.angle"
            else protocol.motor_duties(value)
        )
        if (
            action.get("status") != "ok"
            or action["phase_index"] != index
            or action["operation"] != operation
            or action["value"] != value
            or not protocol.readback_matches(action.get("consumer_readback"), expected)
            or tuple(row["duty_u16"] for row in action["api_state_after"]) != duties
            or action["api_state_before"] != before
            or action["api_state_after"] != after
            or not (
                receipt["phases"][index]["begin_ns"]
                <= action["begin_ns"]
                < action["end_ns"]
                <= receipt["phases"][index]["stable_begin_ns"]
            )
        ):
            raise core.BenchError(
                "Original genuine consumer readback/duty mapping mismatch"
            )
        for row in action["api_state_after"]:
            percent = round(row["duty_u16"] / 65535 * 100)
            if (
                row["submitted_duty_percent"] != percent
                or row["submitted_nominal_high_us"]
                != 1_000_000 / row["frequency"] * percent / 100
            ):
                raise core.BenchError("Original percent submission must not be adapted")
    for row, spec in zip(receipt["outputs"], OUTPUTS):
        output_id, gpio, generation, frequency = spec
        if (
            (row["output_id"], row["gpio"], row["generation"], row["initial_frequency"])
            != spec
            or row["variable_frequency"] is not False
            or not all(
                row[key] is True
                for key in (
                    "fresh_claim_accepted",
                    "initial_low_confirmed",
                    "low_confirmed",
                    "freed",
                    "released",
                )
            )
            or row["ownership"]
            != {
                "private_chip_handle": receipt["private_chip_handle"],
                "gpio": gpio,
                "generation": generation,
            }
            or row["cleanup_final_readback"] != {"gpio_level": 0, "tx_busy": 0}
        ):
            raise core.BenchError("Original per-line generation cleanup proof mismatch")
    for shutdown, index, spec in zip(receipt["shutdowns"], (5, 13, 14), OUTPUTS):
        phase = receipt["phases"][index]
        if (
            shutdown["output_id"] != spec[0]
            or shutdown["scope"] != phase["scope"]
            or shutdown["reason"] != "sequence"
            or shutdown["success"] is not True
            or shutdown["errors"] != []
            or not (
                phase["begin_ns"]
                <= shutdown["begin_ns"]
                < shutdown["end_ns"]
                <= phase["stable_begin_ns"]
            )
        ):
            raise core.BenchError("Ordered private line shutdown proof mismatch")
        expected_sibling = (
            {**phase["api_state"][0], "gpio_level": 0} if index == 13 else None
        )
        if (
            shutdown["sibling_id"] != ("motor23-g1" if index == 13 else None)
            or shutdown["sibling_before"] != expected_sibling
            or shutdown["sibling_after"] != expected_sibling
        ):
            raise core.BenchError("Continuing original sibling ownership/API mismatch")


def experiment(manifest_path):
    receipt = {
        "schema_version": 1,
        "mode": MODE,
        "backend": BACKEND,
        "sequence_marker": SEQUENCE_MARKER,
        "baseline_commit": baseline.BLINKA_COMMIT,
        "gpios": [18, 23],
        "helper_pid": os.getpid(),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "motor_version": "3.5.0",
        "characterization_only": True,
        "passive_probes_only": True,
        "actual_actuators_attached": False,
        "native_backend_executed": False,
        "installed_blinka_compatibility_proven": False,
        "production_backend_unchanged": True,
        "api_readbacks_are_not_electrical": True,
        "parity_pass": None,
        "public_deinit_cancels_or_frees_gpio": False,
        "additional_lab_cleanup_required": True,
        "library_hooks_are_ownership_enforcement_only": True,
        "event_ordering": "completion order; nested spans retain parent_event_id",
        "selected_source_hashes_are_not_whole_system_attestation": True,
        "variable_frequency": False,
        "runtime_flags": {"short_slice": False, "shared": False},
        "native_scheduler_flags_not_used_by_lgpio": True,
        "inherited_environment": {
            name: os.environ.get(name)
            for name in ("BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED")
        },
        "watchdog_seconds": MAX_RUN_SECONDS,
        "watchdog_cannot_bound_extension_hang_or_sigkill": True,
        "sequence_dwell_seconds": round(sum(row[1] for row in SEQUENCE), 6),
        "low_settle_seconds": 0.1,
        "normal_fixed_wait_seconds": round(sum(row[1] for row in SEQUENCE) + 0.3, 6),
        "begin_ns": time.monotonic_ns(),
        "phases": [],
        "actions": [],
        "events": [],
        "outputs": [],
        "shutdowns": [],
        "source_sha256": {},
        "before": None,
        "after": None,
        "signals_received": [],
        "primary_error": None,
        "cleanup_errors": [],
        "completed_normally": False,
        "chip_closed": False,
        "library_hooks_restored": False,
        "success": False,
    }
    registry = None
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            manifest_path = approved_manifest_path(manifest_path)
            manifest = load_manifest(manifest_path)
            validate_manifest(manifest)
            receipt["manifest_path"] = str(manifest_path)
            receipt["source_sha256"] = source_hashes()
            if receipt["source_sha256"] != manifest["source_sha256"]:
                raise core.BenchError(
                    "Installed original/lgpio/gpiod/helper source mismatch"
                )
            if any(value == "1" for value in receipt["inherited_environment"].values()):
                raise core.BenchError(
                    "Refusing inherited shared/short-slice environment flags"
                )
            receipt["identity"] = baseline.preflight()
            receipt["before"] = core.system_snapshot()
            issues = core.thermal_issues(receipt["before"], 65000)
            if issues:
                raise core.BenchError("Thermal preflight: " + "; ".join(issues))
            gpio_library, library = marker.load_libraries()
            receipt["gpiod_version"] = gpio_library.__version__
            receipt["lgpio_version"] = library.get_module_version()
            receipt["preclaim_lines"] = []
            for gpio in (18, 23):
                chip, line = marker.inspect(gpio_library, receipt["identity"], gpio)
                receipt["preclaim_lines"].append(
                    {"gpio": gpio, "chip_info": chip, "line_info": line}
                )
                if line["used"] or line["consumer"] not in (None, ""):
                    raise core.BenchError(
                        "Both original consumer pins must be fresh unused lines"
                    )
            registry = Registry(
                library, gpio_library, receipt["identity"], guard, receipt
            )
            try:
                with registry.hooks() as (pin, pwm):
                    try:
                        with protocol.consumer_api(pwm.PWMOut, receipt, guard) as (
                            servo,
                            motor,
                        ):
                            run_protocol(registry, pin, pwm, servo, motor)
                        receipt["completed_normally"] = True
                    finally:
                        with guard.cleanup():
                            signal.alarm(0)
                            registry.scope = "safety_cleanup"
                            for owner in registry.owners.values():
                                try:
                                    registry.cleanup(owner)
                                except BaseException as error:
                                    receipt["cleanup_errors"].append(
                                        f"{owner.output_id} cleanup: {type(error).__name__}: {error}"
                                    )
                            registry.close()
            finally:
                with guard.cleanup():
                    # Also close an owned handle if Pin source import/open failed.
                    registry.close()
        except BaseException as error:
            receipt["primary_error"] = f"{type(error).__name__}: {error}"
        finally:
            with guard.cleanup():
                signal.alarm(0)
                try:
                    receipt["after"] = core.system_snapshot()
                    receipt["cleanup_errors"].extend(
                        core.thermal_issues(receipt["after"], 70000)
                    )
                except BaseException as error:
                    receipt["cleanup_errors"].append(
                        f"Thermal postflight: {type(error).__name__}: {error}"
                    )
                receipt["signals_received"] = list(guard.received)
    receipt["end_ns"] = time.monotonic_ns()
    receipt["success"] = bool(
        receipt["completed_normally"]
        and receipt["primary_error"] is None
        and not receipt["cleanup_errors"]
        and not receipt["signals_received"]
        and receipt["chip_closed"]
        and receipt["library_hooks_restored"]
        and receipt["integration_shim"]["restored"]
        and len(receipt["outputs"]) == 3
        and all(
            row["fresh_claim_accepted"]
            and row["initial_low_confirmed"]
            and row["low_confirmed"]
            and row["freed"]
            and row["released"]
            for row in receipt["outputs"]
        )
        and len(receipt["shutdowns"]) == 3
        and all(row["success"] for row in receipt["shutdowns"])
        and receipt["end_ns"] - receipt["begin_ns"] < MAX_RUN_SECONDS * 1_000_000_000
    )
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args(argv)
    receipt = experiment(args.manifest)
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
