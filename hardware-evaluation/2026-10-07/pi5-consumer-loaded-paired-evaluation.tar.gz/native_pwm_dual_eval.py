"""Lab-only native GPIO18/GPIO23 coexistence and independent lifecycle test.

Two public PWMOut objects own separate private gpiod requests. GPIO18 is
restarted once after its first request is released; GPIO23 is never reclaimed.
This is functional/coexistence evidence, not matched performance parity or an
electrical waveform verdict. A 14-second ordinary watchdog cannot bound a
stuck native call, SIGKILL, or a hardware fault. No driver/scheduling patches.
"""

import argparse
import hashlib
import importlib.machinery
import importlib.util
import json
import os
import re
import signal
import sys
import time
from pathlib import Path

import native_pwm_updates_eval as native

base = native.base
core = base.core
BACKEND = base.BACKEND
MODE = "dual-independent-lifecycle"
SEQUENCE_MARKER = "native-dual-lifecycle-v1"
ROOT_PATTERN = r"/tmp/blinka-pwm-native-dual\.[A-Za-z0-9]{6}"
MAX_RUN_SECONDS = 14
GPIOD_FILES = (
    "__init__.py",
    "chip.py",
    "line_request.py",
    "line_settings.py",
    "line.py",
)
NEW_SOURCE = "native_pwm_dual_eval.py"
SOURCE_PINS = {
    **base.PINNED_SOURCES,
    "native_pwm_half50_eval.py": native.BASE_HELPER_SHA256,
    "native_pwm_updates_eval.py": "c55606d9f20e39a81d32a6e27917cec41eb48705957661025ab61be6ec77cba3",
}
SOURCE_KEYS = (
    native.SOURCE_KEYS
    | {NEW_SOURCE}
    | {"gpiod/" + name for name in (*GPIOD_FILES, "_ext.so")}
)
OUTPUTS = (
    ("gpio18-g1", 18, 1, 50),
    ("gpio23-g1", 23, 1, 500),
    ("gpio18-g2", 18, 2, 50),
)


def setting(output_id, frequency, duty):
    return {
        "operation": "set",
        "output_id": output_id,
        "frequency": frequency,
        "duty_u16": duty,
    }


def shutdown(output_id, sibling_id):
    return {"operation": "shutdown", "output_id": output_id, "sibling_id": sibling_id}


SEQUENCE = (
    ("initial_both_low", 0.10, ()),
    (
        "nominal_both",
        0.40,
        (setting("gpio18-g1", 50, 4915), setting("gpio23-g1", 500, 32768)),
    ),
    ("gpio18_high", 0.20, (setting("gpio18-g1", 50, 65535),)),
    (
        "gpio18_recover_gpio23_low",
        0.15,
        (setting("gpio18-g1", 50, 4915), setting("gpio23-g1", 500, 0)),
    ),
    ("gpio23_high", 0.20, (setting("gpio23-g1", 500, 65535),)),
    ("both_recover", 0.30, (setting("gpio23-g1", 500, 32768),)),
    (
        "swap_frequencies",
        0.25,
        (setting("gpio18-g1", 500, 32768), setting("gpio23-g1", 50, 4915)),
    ),
    (
        "return_nominal",
        0.30,
        (setting("gpio18-g1", 50, 4915), setting("gpio23-g1", 500, 32768)),
    ),
    ("shutdown_gpio18_g1", 0.35, (shutdown("gpio18-g1", "gpio23-g1"),)),
    (
        "restart_gpio18_g2",
        0.35,
        (
            {"operation": "construct", "output_id": "gpio18-g2"},
            setting("gpio18-g2", 50, 4915),
        ),
    ),
    ("shutdown_gpio23_g1", 0.35, (shutdown("gpio23-g1", "gpio18-g2"),)),
    ("gpio18_g2_half", 0.20, (setting("gpio18-g2", 50, 32768),)),
    ("final_gpio18_g2_low", 0.15, (setting("gpio18-g2", 50, 0),)),
)


def validate_manifest(manifest):
    if (
        not isinstance(manifest, dict)
        or type(manifest.get("schema_version")) is not int
        or manifest["schema_version"] != 1
    ):
        raise core.BenchError("Invalid dual selected-source manifest schema")
    hashes = manifest.get("source_sha256")
    if (
        not isinstance(hashes, dict)
        or set(hashes) != SOURCE_KEYS
        or any(
            not isinstance(value, str) or re.fullmatch(r"[0-9a-f]{64}", value) is None
            for value in hashes.values()
        )
    ):
        raise core.BenchError("Exact fourteen selected-source SHA256 hashes required")
    if any(hashes[name] != digest for name, digest in SOURCE_PINS.items()):
        raise core.BenchError("Immutable native helper/core source mismatch")
    return hashes


def load_manifest(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise core.BenchError("Duplicate manifest key: " + key)
            result[key] = value
        return result

    manifest = json.loads(Path(path).read_text(), object_pairs_hook=pairs)
    validate_manifest(manifest)
    return manifest


def approved_manifest_path(path):
    path = Path(path)
    if (
        not path.is_absolute()
        or re.fullmatch(ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", str(path)) is None
    ):
        raise core.BenchError(
            "Manifest must be absolute under the isolated native-dual root"
        )
    if (
        path.resolve(strict=True) != path
        or path.parent != Path(__file__).resolve().parent
    ):
        raise core.BenchError(
            "Dual helper and manifest must share the isolated root without symlinks"
        )
    return path


def source_hashes():
    spec = importlib.util.find_spec("gpiod")
    if spec is None or spec.origin is None:
        raise core.BenchError("The selected interpreter has no gpiod")
    package = Path(spec.origin).resolve().parent
    extensions = list(
        dict.fromkeys(
            (package / ("_ext" + suffix)).resolve()
            for suffix in importlib.machinery.EXTENSION_SUFFIXES
            if (package / ("_ext" + suffix)).is_file()
        )
    )
    if len(extensions) != 1:
        raise core.BenchError("Require one ABI-compatible gpiod extension")
    paths = {
        NEW_SOURCE: Path(__file__),
        "native_pwm_updates_eval.py": Path(native.__file__),
        **{"gpiod/" + name: package / name for name in GPIOD_FILES},
        "gpiod/_ext.so": extensions[0],
    }
    return {
        **base.source_hashes(),
        **{
            name: hashlib.sha256(path.read_bytes()).hexdigest()
            for name, path in paths.items()
        },
    }


def load_backend():
    library, module = base.load_backend()
    if getattr(library, "__version__", None) != "2.5.0":
        raise core.BenchError("Only the inspected gpiod v2.5.0 is authorized")
    return library, module


def inspect_line(library, identity, gpio):
    if gpio not in (18, 23):
        raise core.BenchError("Only fixed GPIO18 and GPIO23 are authorized")
    with library.Chip(identity["gpiochip"]) as chip:
        info, line = chip.get_info(), chip.get_line_info(gpio)
        if (
            info.name != Path(identity["gpiochip"]).name
            or info.label != "pinctrl-rp1"
            or type(info.num_lines) is not int
            or info.num_lines <= 23
        ):
            raise core.BenchError("Opened chip is not the verified RP1 GPIO controller")
        if (
            type(line.offset) is not int
            or line.offset != gpio
            or type(line.used) is not bool
        ):
            raise core.BenchError("Malformed gpiod v2 line information")
        return {"name": info.name, "label": info.label, "num_lines": info.num_lines}, {
            "offset": line.offset,
            "name": line.name,
            "used": line.used,
            "consumer": line.consumer,
        }


class Owner(base.Owner):
    """Reuse caller instrumentation shape, but never the GPIO18-only cleanup."""

    def __init__(self, library, identity, guard, receipt, output_id):
        super().__init__(library, identity, guard, receipt)
        matches = [row for row in OUTPUTS if row[0] == output_id]
        if len(matches) != 1:
            raise core.BenchError("Unapproved output generation")
        self.output_id, self.gpio, self.generation, self.initial_frequency = matches[0]
        self.cleaned = False
        self.private_request = None
        self.record = {
            "output_id": output_id,
            "gpio": self.gpio,
            "generation": self.generation,
            "initial_frequency": self.initial_frequency,
            "variable_frequency": True,
            "fresh_claim_accepted": False,
            "initial_low_confirmed": False,
            "low_confirmed": False,
            "released": False,
            "read_only_chip_closed": False,
            "owned_request": None,
            "cleanup_final_readback": None,
        }
        receipt["outputs"].append(self.record)

    def call(self, name, operation, arguments=None):
        event = {
            "ordinal": len(self.receipt["events"]),
            "output_id": self.output_id,
            "gpio": self.gpio,
            "generation": self.generation,
            "operation": name,
            "scope": self.scope,
            "arguments": arguments,
            "begin_ns": time.monotonic_ns(),
        }
        try:
            value = operation()
            event["status"] = "ok"
            return value
        except BaseException as error:
            event.update(status="error", error=f"{type(error).__name__}: {error}")
            raise
        finally:
            event["end_ns"] = time.monotonic_ns()
            self.receipt["events"].append(event)

    def track_request(self):
        request = self.request()
        if request is None:
            return False
        if self.private_request is not None and request is not self.private_request:
            raise core.BenchError("An output's private request object changed")
        if (
            list(request.offsets) != [self.gpio]
            or request.chip_name != Path(self.identity["gpiochip"]).name
            or type(request.fd) is not int
            or request.fd < 0
        ):
            raise core.BenchError(
                "PWM output did not privately claim only its verified pin"
            )
        owned = {
            "chip_name": request.chip_name,
            "offsets": list(request.offsets),
            "fd": request.fd,
        }
        if (
            self.record["owned_request"] is not None
            and self.record["owned_request"] != owned
        ):
            raise core.BenchError("An output's private request identity changed")
        self.private_request = request
        self.record.update(owned_request=owned, fresh_claim_accepted=True)
        return True

    def construct(self, pwm_class):
        chip, line = self.call(
            "gpiod_line_info_preclaim",
            lambda: inspect_line(self.library, self.identity, self.gpio),
        )
        self.record.update(
            chip_info=chip, preclaim_line_info=line, read_only_chip_closed=True
        )
        if line["used"] or line["consumer"] not in (None, ""):
            raise core.BenchError(
                "Fresh unused GPIO required; never borrow another request"
            )
        # Retain a partially initialized public object for explicit deinit.
        self.pwm = pwm_class.__new__(pwm_class)
        with self.guard.atomic():
            self.call(
                "PWMOut.__init__",
                lambda: self.pwm.__init__(
                    (self.identity["gpiochip"], self.gpio),
                    frequency=self.initial_frequency,
                    duty_cycle=0,
                    variable_frequency=True,
                ),
                {
                    "gpiochip": self.identity["gpiochip"],
                    "gpio": self.gpio,
                    "frequency": self.initial_frequency,
                    "duty_u16": 0,
                    "variable_frequency": True,
                },
            )
            if not self.track_request():
                raise core.BenchError("Native PWM returned without a private request")
            level = self.call(
                "initial_request.get_value", lambda: self.request().get_value(self.gpio)
            )
            self.record["initial_low_confirmed"] = (
                level == self.library.line.Value.INACTIVE
            )
            self.record["initial_readback"] = {
                "gpio_level": getattr(level, "value", None),
                "inactive": self.record["initial_low_confirmed"],
            }
            if not self.record["initial_low_confirmed"]:
                raise core.BenchError("New private PWM request did not read inactive")

    def snapshot(self, read_level=False, boundary="sibling"):
        if self.cleaned or not self.track_request():
            raise core.BenchError("An active output lost its private request")
        result = {
            "output_id": self.output_id,
            "gpio": self.gpio,
            "generation": self.generation,
            "owned_request": dict(self.record["owned_request"]),
            "frequency": self.pwm.frequency,
            "duty_u16": self.pwm.duty_cycle,
        }
        if read_level:
            value = self.call(
                boundary + "_request.get_value",
                lambda: self.request().get_value(self.gpio),
            )
            level = getattr(value, "value", None)
            if type(level) is not int or level not in (0, 1):
                raise core.BenchError("Malformed continuing sibling private readback")
            result["gpio_level"] = level
        return result

    def set_state(self, frequency, duty):
        # Match public caller order: frequency first, then duty, only if changed.
        if self.pwm.frequency != frequency:
            self.call(
                "PWMOut.frequency",
                lambda: setattr(self.pwm, "frequency", frequency),
                {"frequency": frequency, "duty_u16": self.pwm.duty_cycle},
            )
        if self.pwm.duty_cycle != duty:
            self.call(
                "PWMOut.duty_cycle",
                lambda: setattr(self.pwm, "duty_cycle", duty),
                {"frequency": frequency, "duty_u16": duty},
            )

    def cleanup(self, sibling=None, reason="safety_cleanup"):
        if self.cleaned or self.pwm is None:
            return
        record = {
            "output_id": self.output_id,
            "scope": self.scope,
            "reason": reason,
            "sibling_id": sibling.output_id if sibling else None,
            "begin_ns": time.monotonic_ns(),
            "sibling_before": None,
            "sibling_after": None,
            "errors": [],
            "success": False,
        }
        self.receipt["shutdowns"].append(record)

        def attempt(name, operation, instrument=True):
            try:
                return self.call(name, operation) if instrument else operation()
            except BaseException as error:
                record["errors"].append(f"{name}: {type(error).__name__}: {error}")
                return None

        with self.guard.cleanup():
            try:
                if sibling:
                    record["sibling_before"] = attempt(
                        "sibling_before",
                        lambda: sibling.snapshot(True, "sibling_before"),
                        False,
                    )
                if attempt("track_owned_request", self.track_request):
                    attempt(
                        "PWMOut.duty_cycle_zero",
                        lambda: setattr(self.pwm, "duty_cycle", 0),
                    )
                    attempt("low_settle", lambda: time.sleep(0.1))
                    request = self.request()
                    if request is not None:
                        level = attempt(
                            "owned_request.get_value",
                            lambda: request.get_value(self.gpio),
                        )
                        inactive = level == self.library.line.Value.INACTIVE
                        self.record["cleanup_final_readback"] = {
                            "gpio_level": getattr(level, "value", None),
                            "inactive": inactive,
                        }
                        self.record["low_confirmed"] = inactive
                    if not self.record["low_confirmed"]:
                        record["errors"].append(
                            "Settled privately owned output inactive not confirmed"
                        )
            finally:
                # Never close a sibling FD or reclaim a released line. Public
                # deinit also runs when construction only partially completed.
                attempt("PWMOut.deinit", self.pwm.deinit)
                self.cleaned = True
                inspected = attempt(
                    "gpiod_line_info_released",
                    lambda: inspect_line(self.library, self.identity, self.gpio),
                )
                if inspected is not None:
                    self.record.update(
                        released_line_info=inspected[1],
                        read_only_chip_closed=True,
                        released=inspected[1]["used"] is False
                        and inspected[1]["consumer"] in (None, ""),
                    )
                if not self.record["released"]:
                    record["errors"].append(
                        "Unclaimed line after deinit not confirmed; no reclaim attempted"
                    )
                if sibling:
                    record["sibling_after"] = attempt(
                        "sibling_after",
                        lambda: sibling.snapshot(True, "sibling_after"),
                        False,
                    )
                    before, after = record["sibling_before"], record["sibling_after"]
                    if (
                        before is None
                        or after is None
                        or {k: v for k, v in before.items() if k != "gpio_level"}
                        != {k: v for k, v in after.items() if k != "gpio_level"}
                    ):
                        record["errors"].append(
                            "Continuing sibling ownership/API state changed during shutdown"
                        )
                record["end_ns"] = time.monotonic_ns()
                record["success"] = bool(
                    self.record["fresh_claim_accepted"]
                    and self.record["low_confirmed"]
                    and self.record["released"]
                    and not record["errors"]
                )
                self.receipt["cleanup_errors"].extend(
                    self.output_id + ": " + error for error in record["errors"]
                )


def active_snapshots(owners):
    rows = [
        owner.snapshot()
        for owner in owners.values()
        if owner.pwm is not None and not owner.cleaned
    ]
    if len({row["gpio"] for row in rows}) != len(rows) or len(
        {row["owned_request"]["fd"] for row in rows}
    ) != len(rows):
        raise core.BenchError(
            "Concurrent outputs must own distinct pins and request FDs"
        )
    return rows


def run_phase(index, spec, owners, library, module, identity, guard, receipt):
    name, duration, actions = spec
    scope = f"{index:02d}_{name}"
    phase = {
        "index": index,
        "name": name,
        "scope": scope,
        "duration_seconds": duration,
        "actions": list(actions),
        "begin_ns": time.monotonic_ns(),
    }
    for owner in owners.values():
        owner.scope = scope
    for action in actions:
        output_id, operation = action["output_id"], action["operation"]
        if operation == "construct":
            owner = Owner(library, identity, guard, receipt, output_id)
            owners[output_id] = owner
            owner.scope = scope
            owner.construct(module.PWMOut)
        elif operation == "set":
            owners[output_id].set_state(action["frequency"], action["duty_u16"])
        else:
            with guard.atomic():
                owners[output_id].cleanup(owners[action["sibling_id"]], "sequence")
                if not receipt["shutdowns"][-1]["success"]:
                    raise core.BenchError("Independent shutdown failed")
        active_snapshots(owners)
    phase["stable_begin_ns"] = time.monotonic_ns()
    phase["api_state"] = active_snapshots(owners)
    time.sleep(duration)
    phase["end_ns"] = time.monotonic_ns()
    phase["api_state_end"] = active_snapshots(owners)
    phase["readback_end_ns"] = time.monotonic_ns()
    receipt["phases"].append(phase)


def experiment(manifest_path):
    receipt = {
        "schema_version": 1,
        "mode": MODE,
        "backend": BACKEND,
        "sequence_marker": SEQUENCE_MARKER,
        "gpios": [18, 23],
        "helper_pid": os.getpid(),
        "characterization_only": True,
        "functional_coexistence_only": True,
        "matched_performance_parity": False,
        "production_backend_unchanged": True,
        "parity_pass": None,
        "api_readbacks_are_not_electrical": True,
        "selected_source_hashes_are_not_whole_system_attestation": True,
        "variable_frequency": True,
        "runtime_flags": {"short_slice": False, "shared": False},
        "inherited_environment": {
            name: os.environ.get(name)
            for name in ("BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED")
        },
        "watchdog_seconds": MAX_RUN_SECONDS,
        "watchdog_cannot_bound_native_hang_or_sigkill": True,
        "sequence_dwell_seconds": round(sum(phase[1] for phase in SEQUENCE), 6),
        "low_settle_seconds": 0.1,
        "normal_fixed_wait_seconds": round(
            sum(phase[1] for phase in SEQUENCE) + 0.3, 6
        ),
        "begin_ns": time.monotonic_ns(),
        "phases": [],
        "events": [],
        "outputs": [],
        "shutdowns": [],
        "source_sha256": {},
        "before": None,
        "after": None,
        "signals_received": [],
        "primary_error": None,
        "cleanup_errors": [],
        "completed_normally": False,
        "read_only_chip_closed": False,
        "success": False,
    }
    owners = {}
    with core.SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            manifest_path = approved_manifest_path(manifest_path)
            manifest = load_manifest(manifest_path)
            validate_manifest(manifest)
            receipt["manifest_path"] = str(manifest_path)
            receipt["source_sha256"] = source_hashes()
            if receipt["source_sha256"] != manifest["source_sha256"]:
                raise core.BenchError(
                    "Installed dual/native/gpiod/helper source hash mismatch"
                )
            if any(value == "1" for value in receipt["inherited_environment"].values()):
                raise core.BenchError(
                    "Refusing inherited BLINKA_PWM_SHORT_SLICE/BLINKA_PWM_SHARED=1"
                )
            receipt["identity"] = base.baseline.preflight()
            receipt["before"] = core.system_snapshot()
            issues = core.thermal_issues(receipt["before"], 65000)
            if issues:
                raise core.BenchError("Thermal preflight: " + "; ".join(issues))
            library, module = load_backend()
            receipt["preclaim_lines"] = []
            for gpio in (18, 23):
                chip, line = inspect_line(library, receipt["identity"], gpio)
                receipt["preclaim_lines"].append(
                    {"gpio": gpio, "chip_info": chip, "line_info": line}
                )
                receipt["read_only_chip_closed"] = True
                if line["used"] or line["consumer"] not in (None, ""):
                    raise core.BenchError(
                        "Both GPIO18 and GPIO23 must be fresh unused lines"
                    )
            for output_id in ("gpio18-g1", "gpio23-g1"):
                owner = Owner(library, receipt["identity"], guard, receipt, output_id)
                owners[output_id] = owner
                owner.scope = "initialization_" + output_id
                owner.construct(module.PWMOut)
                active_snapshots(owners)
            for index, phase in enumerate(SEQUENCE):
                run_phase(
                    index,
                    phase,
                    owners,
                    library,
                    module,
                    receipt["identity"],
                    guard,
                    receipt,
                )
            receipt["completed_normally"] = True
        except BaseException as error:
            receipt["primary_error"] = f"{type(error).__name__}: {error}"
        finally:
            with guard.cleanup():
                signal.alarm(0)
                for owner in owners.values():
                    owner.scope = "safety_cleanup_" + owner.output_id
                    try:
                        owner.cleanup()
                    except BaseException as error:
                        receipt["cleanup_errors"].append(
                            owner.output_id
                            + f": cleanup: {type(error).__name__}: {error}"
                        )
                try:
                    receipt["after"] = core.system_snapshot()
                    receipt["cleanup_errors"].extend(
                        core.thermal_issues(receipt["after"], 70000)
                    )
                except BaseException as error:
                    receipt["cleanup_errors"].append(
                        f"Thermal postflight: {type(error).__name__}: {error}"
                    )
                receipt["signals_received"] = list(guard.received)
    receipt["end_ns"] = time.monotonic_ns()
    receipt["success"] = bool(
        receipt["completed_normally"]
        and receipt["primary_error"] is None
        and not receipt["cleanup_errors"]
        and not receipt["signals_received"]
        and receipt["read_only_chip_closed"]
        and len(receipt["outputs"]) == 3
        and all(
            row["fresh_claim_accepted"]
            and row["initial_low_confirmed"]
            and row["low_confirmed"]
            and row["released"]
            and row["read_only_chip_closed"]
            for row in receipt["outputs"]
        )
        and len(receipt["shutdowns"]) == 3
        and all(row["success"] for row in receipt["shutdowns"])
        and receipt["end_ns"] - receipt["begin_ns"] < MAX_RUN_SECONDS * 1_000_000_000
    )
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args(argv)
    receipt = experiment(args.manifest)
    print(json.dumps(receipt, indent=2))
    return 0 if receipt["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
