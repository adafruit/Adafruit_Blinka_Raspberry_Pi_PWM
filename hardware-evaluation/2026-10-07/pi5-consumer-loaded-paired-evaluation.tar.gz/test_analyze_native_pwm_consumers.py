"""Consumer analyzer fakes: genuine class receipts, synthetic digital data only."""

import copy
import json
import math
import struct
import zipfile

import analyze_native_pwm_consumers as audit
import pytest
import test_native_pwm_consumers_eval as helper_fakes

old_environment = helper_fakes.old_environment
dual_environment = helper_fakes.dual_environment
environment = helper_fakes.environment


def channel(edges, end=5.3):
    return audit.retarget_channel(
        audit.raw.channel_facts(
            {
                "begin_seconds": 0.0,
                "end_seconds": end,
                "initial_state": 0,
                "final_state": 0,
                "edge_count": len(edges),
            },
            edges,
        )
    )


def train(start, stop, tag):
    nominal = audit.NOMINALS[tag]
    period, high = nominal["period_us"] / 1e6, nominal["high_us"] / 1e6
    result, index = [], 0
    while start + index * period + high < stop:
        rise = start + index * period
        result.extend((rise, rise + high))
        index += 1
    return result


def visible_protocol():
    edges18 = (
        train(0.8, 1.2, "servo_angle0")
        + train(1.22, 1.62, "servo_angle90")
        + train(1.64, 2.04, "servo_angle180")
        + [2.55, 2.7505]
        + train(2.752, 3.10, "motor_half")
        + [3.102, 3.302]
    )
    edges23 = [2.55002, 2.75001] + train(3.304, 3.652, "motor_half") + [3.654, 3.854]
    return edges18, edges23


def binary(edges, version=0, begin=0.0, end=5.3, initial=0, rate=100_000_000):
    data = b"<SALEAE>" + struct.pack("<ii", version, 0)
    if version:
        data += struct.pack("<Q", 1)
    data += struct.pack("<I", initial)
    if version:
        data += struct.pack("<d", rate)
    return (
        data
        + struct.pack("<ddQ", begin, end, len(edges))
        + struct.pack(f"<{len(edges)}d", *edges)
    )


def features(facts):
    return {row["feature"]: row for row in facts["physical_observations"]}


def test_frozen_plan_actual_quantized_u16_c_rounded_targets():
    assert len(audit.read_plan()["sequence"]) == 15
    assert {tag: row["high_us"] for tag, row in audit.NOMINALS.items()} == {
        "servo_angle0": 999.771,
        "servo_angle90": 1499.657,
        "servo_angle180": 1999.847,
        "motor_half": 499.992,
    }
    assert [row["duty_u16"] for row in audit.NOMINALS.values()] == [
        3276,
        4914,
        6553,
        32767,
    ]
    assert audit.NOMINALS["servo_angle90"]["high_us"] != 1500


def test_changed_plan_refused(tmp_path):
    path = tmp_path / "plan.json"
    path.write_text(json.dumps(audit.read_plan()))
    with pytest.raises(ValueError, match="Frozen consumer plan changed"):
        audit.read_plan(path)


@pytest.mark.parametrize("version", [0, 1])
@pytest.mark.parametrize("edges", [[], [0.8, 0.800999771, 0.82, 0.820999771]])
def test_complete_raw_formats_and_all_low_retained(tmp_path, version, edges):
    path = tmp_path / "digital.bin"
    path.write_bytes(binary(edges, version))
    facts = audit.read_channel(path)
    assert facts["waveform"]["transition_seconds"] == edges
    assert len(facts["all_high_runs"]) == len(edges) // 2
    assert len(facts["all_low_runs"]) == len(edges) // 2 + 1
    assert len(facts["all_adjacent_rise_intervals"]) == max(0, len(edges) // 2 - 1)
    if edges:
        assert facts["all_high_runs"][0]["width_target_candidates"] == ["servo_angle0"]
        assert (
            facts["nearest_target_error_stats_us_including_all_nonlong_anomalies"][
                "servo_angle0"
            ]["count"]
            == 2
        )
    else:
        assert facts["all_low_runs"][0]["kind"] == "entire_all_low_capture"


@pytest.mark.parametrize(
    "data",
    [
        b"bad",
        binary([0.8, 0.8015]) + b"x",
        binary([0.8, 0.8015])[:-1],
        binary([0.8]),
        binary([0.8015, 0.8]),
        binary([0.8, 0.8]),
        binary([0.8, math.nan]),
        binary([0.8, math.inf]),
        binary([0.8, 0.8015], initial=1),
        binary([0.8, 0.8015], end=0.8),
        binary([0.8, 0.8015], version=1, rate=50_000_000),
        binary([0.1, 0.1015]),
        binary([5.2, 5.2015]),
    ],
)
def test_malformed_incomplete_uncovered_raw_refused(tmp_path, data):
    path = tmp_path / "digital.bin"
    path.write_bytes(data)
    with pytest.raises(ValueError):
        audit.read_channel(path)


def test_subus_and_boundary_anomalies_not_filtered_or_dual_labeled():
    edges = [0.8, 0.80000001, 0.80000002, 0.8021, 0.82, 0.97]
    facts = channel(edges)
    assert facts["waveform"]["transition_seconds"] == edges
    assert len(facts["all_high_runs"]) == 3
    assert len(facts["sub_microsecond_highs"]) == 1
    assert len(facts["sub_microsecond_interior_lows"]) == 1
    assert facts["unmatched_width_pair_indices"] == [0]
    assert facts["all_high_runs"][1]["nearest_width_target"] == "servo_angle180"
    assert facts["all_high_runs"][2]["descriptive_long_high"]
    selected = audit.raw.window_facts(facts, 0.800000005, 0.82)
    assert selected["overlapping_high_pair_indices"] == [0, 1, 2]
    assert selected["edge_indices_including_boundaries"] == [1, 2, 3, 4]
    assert set(
        facts["nearest_target_error_stats_us_including_all_nonlong_anomalies"]
    ) == set(audit.NOMINALS)


def test_unique_ordered_joint_topology_has_strict_sibling_facts_no_alignment():
    facts = audit.functional_facts(*(channel(edges) for edges in visible_protocol()))
    assert facts["unique_servo_order_before_joint_brake"]
    assert facts["unique_brake_positive_negative_long_high_order"]
    assert facts["complete_frozen_ordered_joint_topology_supported"]
    assert facts["ambiguities"] == []
    observations = features(facts)
    assert len(observations) == 10
    assert observations["joint_brake_physical_both_high_overlap"]["evidence"][
        "duration_seconds"
    ] == pytest.approx(0.19999)
    for tag in ("servo_angle0", "servo_angle90", "servo_angle180"):
        observation = observations[tag + "_guarded_train"]
        assert observation["frozen_ordered_topology_association_supported"]
        assert observation["evidence"]["train"]["high_width_stats_us"]["count"] == 20
    assert (
        observations["motor_forward_half_guarded_train"]["gpio18"][
            "contained_high_width_stats_us"
        ]["count"]
        == 348
    )
    assert all(not row["command_phase_clocks_aligned"] for row in observations.values())
    assert all(
        not row["exact_application_or_deinit_instant_identified"]
        for row in observations.values()
    )


def test_missing_pulses_are_ambiguous_not_accepted():
    facts = audit.functional_facts(channel([]), channel([]))
    assert not facts["unique_servo_order_before_joint_brake"]
    assert not facts["unique_brake_positive_negative_long_high_order"]
    assert facts["ambiguities"]
    assert list(features(facts)) == ["final_both_low_physical_tail"]


def test_short_fragments_and_long_periods_retained_without_merge():
    edges = train(0.8, 0.84, "servo_angle0") + train(1.0, 1.08, "servo_angle0")
    blocks = audit.train_blocks(channel(edges), "servo_angle0")
    assert [len(row["pair_indices"]) for row in blocks] == [2, 4]
    assert not any(row["eligible_train"] for row in blocks)
    assert len(channel(edges)["all_adjacent_rise_intervals"]) == 5


def test_anomaly_kept_and_full_servo_extent_not_inferred_from_one_fragment():
    edges18, edges23 = visible_protocol()
    edges18[5] += 0.005
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    assert facts["unique_servo_order_before_joint_brake"]
    blocks = facts["all_width_period_train_fragments_including_short"]["gpio18"][
        "servo_angle0"
    ]
    assert [len(row["pair_indices"]) for row in blocks] == [2, 17]
    assert any(
        row["feature"] == "servo_angle0_full_extent" for row in facts["ambiguities"]
    )
    assert not facts["complete_frozen_ordered_joint_topology_supported"]
    assert channel(edges18)["all_high_runs"][2]["width_us"] == pytest.approx(5999.771)


def test_extra_joint_brake_is_ambiguous_not_arbitrarily_chosen():
    edges18, edges23 = visible_protocol()
    edges18 += [4.1, 4.3]
    edges23 += [4.12, 4.32]
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    ambiguity = next(
        row for row in facts["ambiguities"] if row["feature"] == "joint_long_high_brake"
    )
    assert ambiguity["candidate_count"] == 2
    assert not facts["unique_brake_positive_negative_long_high_order"]


def test_reversed_servo_train_order_explicitly_ambiguous():
    edges18, edges23 = visible_protocol()
    edges18[:120] = (
        train(0.8, 1.2, "servo_angle90")
        + train(1.22, 1.62, "servo_angle0")
        + train(1.64, 2.04, "servo_angle180")
    )
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    assert not facts["unique_servo_order_before_joint_brake"]
    assert not features(facts)["servo_angle0_guarded_train"][
        "frozen_ordered_topology_association_supported"
    ]


@pytest.mark.parametrize("delta", [0, -0.00000001])
def test_boundary_touch_or_overlap_is_ambiguous_no_post_capture_guard(delta):
    edges18, edges23 = visible_protocol()
    shift = 3.302 + delta - 3.304
    edges23[2:-2] = [edge + shift for edge in edges23[2:-2]]
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    observations = features(facts)
    full = observations["motor_forward_full_physical_long_high"]
    assert not full["frozen_ordered_topology_association_supported"]
    assert not full["evidence"]["sibling"]["low_throughout_full_window_observed"]
    assert not full["evidence"]["sibling"]["guarded_core_substitution_used"]
    assert (
        len(full["evidence"]["sibling"]["overlapping_or_boundary_touching_high_runs"])
        == 1
    )
    assert "motor_reverse_half_guarded_train" not in observations
    assert any(
        row["feature"] == "gpio23_reverse_half_train" and row["candidate_count"] == 0
        for row in facts["ambiguities"]
    )
    assert channel(edges23)["waveform"]["transition_seconds"] == edges23
    assert len(channel(edges23)["all_high_runs"]) == 350
    assert not facts["complete_frozen_ordered_joint_topology_supported"]


def test_missing_half_train_does_not_support_full_ordered_joint_association():
    edges18, edges23 = visible_protocol()
    edges18 = [edge for edge in edges18 if not 2.752 <= edge < 3.10]
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    assert facts["unique_servo_order_before_joint_brake"]
    assert facts["unique_brake_positive_negative_long_high_order"]
    assert not facts["complete_frozen_ordered_joint_topology_supported"]
    assert not features(facts)["motor_forward_full_physical_long_high"][
        "frozen_ordered_topology_association_supported"
    ]


def test_sibling_anomalous_pulse_retained_in_complete_window():
    edges18, edges23 = visible_protocol()
    edges23[:0] = [0.91, 0.91000001]
    facts = audit.functional_facts(channel(edges18), channel(edges23))
    observation = features(facts)["servo_angle0_guarded_train"]
    assert not observation["frozen_ordered_topology_association_supported"]
    assert observation["gpio23"]["wholly_contained_high_pair_indices"] == [0]
    assert observation["gpio23"]["contained_high_width_stats_us"][
        "max"
    ] == pytest.approx(0.01)
    assert len(channel(edges23)["sub_microsecond_highs"]) == 1


def saved_capture(tmp_path, monkeypatch, environment):
    _state, _guard, _module, manifest, _sleeps = environment
    remote = audit.collector.helper.experiment(helper_fakes.ROOT + "/manifest.json")
    audit.collector.validate_remote(remote, manifest)
    plan = copy.deepcopy(audit.read_plan())
    plan["remote_root"] = helper_fakes.ROOT
    monkeypatch.setattr(audit, "read_plan", lambda _path=None: plan)
    directory = tmp_path / "fake-consumers"
    directory.mkdir()
    metadata = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": audit.collector.MODE,
        "backend": audit.collector.BACKEND,
        "sequence_marker": audit.collector.SEQUENCE_MARKER,
        "sample_rate_hz": 100_000_000,
        "remote": remote,
        "collection_success": True,
        "production_backend_unchanged": True,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "installed_blinka_compatibility_proven": False,
        "actual_actuators_attached": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "outputs": [
            {"gpio": gpio, "saleae_channel": index, "backend": audit.collector.BACKEND}
            for gpio, index in ((18, 0), (23, 1))
        ],
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
    }
    acquisition = {
        "mode": audit.collector.MODE,
        "backend": audit.collector.BACKEND,
        "remote_root": helper_fakes.ROOT,
        "remote_python": plan["remote_python"],
        "primary_error": None,
        "evidence_errors": [],
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
    }
    for name, value in (
        ("manifest.json", manifest),
        ("remote.stdout", remote),
        ("results.json", metadata),
        ("acquisition.json", acquisition),
    ):
        (directory / name).write_text(json.dumps(value))
    (directory / "remote.stderr").write_text("")
    settings = {
        "enabledChannels": [{"type": "Digital", "index": index} for index in (0, 1)],
        "sampleRate": {"digital": 100_000_000},
        "glitchFilter": {"enabled": False, "channels": []},
    }
    sal = {
        "data": {
            "legacySettings": settings,
            "legacyDevice": {"isSimulation": False, "deviceId": "81F8C2631DF5BF30"},
        }
    }
    with zipfile.ZipFile(directory / "waveform.sal", "w") as archive:
        archive.writestr("meta.json", json.dumps(sal))
    for index, edges in enumerate(visible_protocol()):
        (directory / f"digital_{index}.bin").write_bytes(binary(edges))
    return directory


def test_full_receipt_raw_sal_report_no_general_consumer_claim(
    tmp_path, monkeypatch, environment
):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    report = audit.analyze(directory)
    assert report["collection_receipts_validated"]
    assert len(report["source_manifest"]["source_sha256"]) == 18
    assert len(report["evidence_sha256"]) == 8
    assert report["functional_waveform_facts"]["ambiguities"] == []
    assert report["waveform_accepted"] is None and report["parity_pass"] is None
    assert not report["pi_saleae_clocks_aligned"]
    assert not report["application_latency_measured"]
    assert not report["installed_blinka_compatibility_proven"]
    assert not report["actual_actuator_operation_established"]
    receipt = report[
        "validated_receipt_consumer_api_and_ownership_not_electrical_phase_identity"
    ]
    assert receipt["actions"][1]["consumer_readback"] == pytest.approx(
        89.97253585596583
    )
    assert receipt["outputs"][1]["generation"] == 2
    assert report[
        "common_requested_servo_high_us_minus_actual_c_rounded_us"
    ] == pytest.approx(
        {"servo_angle0": 0.229, "servo_angle90": 0.343, "servo_angle180": 0.153}
    )


@pytest.mark.parametrize(
    "file,key,value",
    [
        ("results.json", "schema_version", True),
        ("results.json", "collection_success", False),
        ("results.json", "parity_pass", True),
        ("results.json", "remote_returncode", True),
        ("results.json", "installed_blinka_compatibility_proven", True),
        ("results.json", "actual_actuators_attached", True),
        ("acquisition.json", "evidence_errors", ["failed export"]),
        ("acquisition.json", "primary_error", "timeout"),
        ("acquisition.json", "remote_root", "/tmp/other"),
        ("acquisition.json", "local_timing_not_aligned_to_pi_or_saleae", False),
    ],
)
def test_failed_or_mismatched_acquisition_refused(
    tmp_path, monkeypatch, environment, file, key, value
):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    path = directory / file
    data = json.loads(path.read_text())
    data[key] = value
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError):
        audit.analyze(directory)


def test_wrong_consumer_getter_receipt_not_hidden_by_matching_outer_result(
    tmp_path, monkeypatch, environment
):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    path = directory / "remote.stdout"
    remote = json.loads(path.read_text())
    remote["actions"][1]["consumer_readback"] = 90
    path.write_text(json.dumps(remote))
    path = directory / "results.json"
    metadata = json.loads(path.read_text())
    metadata["remote"] = remote
    path.write_text(json.dumps(metadata))
    with pytest.raises(ValueError):
        audit.analyze(directory)


def test_mismatched_channel_bounds_refused(tmp_path, monkeypatch, environment):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    (directory / "digital_1.bin").write_bytes(binary(visible_protocol()[1], end=5.4))
    with pytest.raises(ValueError, match="share acquisition bounds"):
        audit.analyze(directory)


@pytest.mark.parametrize(
    "scope,key,value",
    [
        ("legacyDevice", "isSimulation", True),
        ("legacyDevice", "deviceId", "0000000000000001"),
        ("legacySettings", "enabledChannels", [{"type": "Digital", "index": 0}]),
        ("legacySettings", "sampleRate", {"digital": 50_000_000}),
        ("legacySettings", "glitchFilter", {"enabled": True, "channels": [0]}),
    ],
)
def test_nonphysical_wrong_rate_channels_filtered_sal_refused(
    tmp_path, monkeypatch, environment, scope, key, value
):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    path = directory / "waveform.sal"
    with zipfile.ZipFile(path) as archive:
        data = json.loads(archive.read("meta.json"))
    data["data"][scope][key] = value
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("meta.json", json.dumps(data))
    with pytest.raises(ValueError):
        audit.analyze(directory)


def test_exclusive_report_preserves_existing_bytes(tmp_path, monkeypatch, environment):
    directory = saved_capture(tmp_path, monkeypatch, environment)
    audit.main([str(directory), "--output-name", "analysis.json"])
    original = (directory / "analysis.json").read_bytes()
    with pytest.raises(ValueError, match="Exclusive"):
        audit.main([str(directory), "--output-name", "analysis.json"])
    assert (directory / "analysis.json").read_bytes() == original
