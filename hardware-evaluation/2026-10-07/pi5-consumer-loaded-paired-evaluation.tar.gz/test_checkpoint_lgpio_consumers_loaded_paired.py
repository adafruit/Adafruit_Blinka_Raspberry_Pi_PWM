"""Pure recovery gates and temporary fake files; main/replay/archive never run."""

import ast
import json
from pathlib import Path

import checkpoint_lgpio_consumers_loaded_paired as checkpoint
import pytest


@pytest.fixture
def frozen(tmp_path, monkeypatch):
    data = (checkpoint.LAB / checkpoint.PLAN_NAME).read_bytes()
    plan = json.loads(data)
    (tmp_path / checkpoint.PLAN_NAME).write_bytes(data)
    monkeypatch.setattr(checkpoint, "LAB", tmp_path.resolve())
    files = {
        **checkpoint.DEPENDENCY_PINS,
        "lgpio_pwm_consumers_eval.py": plan["helper_sha256"],
        "capture_lgpio_pwm_consumers.py": plan["collector_sha256"],
        "analyze_lgpio_pwm_consumers.py": plan["analyzer_sha256"],
        "native_pwm_consumers_eval.py": plan["native_reference"]["helper_sha256"],
        "capture_native_pwm_consumers.py": plan["native_reference"]["collector_sha256"],
        "analyze_native_pwm_consumers.py": plan["native_reference"]["analyzer_sha256"],
        "oct7-native-consumers-plan.json": plan["native_reference"][
            "unchanged_protocol_plan_sha256"
        ],
        "oct7-lgpio-consumers-paired-postflight.json": plan["prior_postflight_sha256"],
        "oct7-lgpio-consumers-manifest.json": plan["manifest_sha256"],
        "oct7-native-consumers-manifest.json": plan["native_manifest_sha256"],
        "record_lgpio_consumers_loaded_paired_state.py": plan["state_recorder_sha256"],
        "test_record_lgpio_consumers_loaded_paired_state.py": plan[
            "state_recorder_test_sha256"
        ],
        "capture_lgpio_pwm_consumers_loaded.py": plan["loaded_coordinators_sha256"][
            "original"
        ],
        "capture_native_pwm_consumers_loaded.py": plan["loaded_coordinators_sha256"][
            "native"
        ],
        "kernel_pwm_cpu_load_eval.py": plan["load_source_sha256"],
    }
    for inventory in plan["loaded_coordinator_source_sha256"].values():
        for name, value in inventory.items():
            key = (
                "consumer-library-source/" + name
                if name in checkpoint.paired.idle.helper.CONSUMER_PINS
                else name
            )
            files[key] = value
    return plan, files


def test_frozen_identity_and_all_four_exact_targets(frozen):
    plan, files = frozen
    assert checkpoint.frozen_inputs(files) == plan
    assert len(checkpoint.TARGETS) == len(set(checkpoint.TARGETS))
    assert not set(checkpoint.paired.CAPTURES).intersection(checkpoint.TARGETS)
    assert set(checkpoint.SOURCE_DEPENDENCIES) <= set(checkpoint.TARGETS)
    assert Path(__file__).name in checkpoint.TARGETS
    assert "oct7-lgpio-consumers-paired-postflight.json" in checkpoint.TARGETS
    assert "oct7-native-consumers-loaded-postflight.json" in checkpoint.TARGETS
    for name in checkpoint.CAPTURES:
        assert name in checkpoint.TARGETS
        for suffix in (".load.stdout", ".load.stderr", ".consumers-coordination.json"):
            assert name + suffix in checkpoint.TARGETS
    ast.parse(checkpoint.REPLAY)  # Parse only; no analyzer or coordinator is called.


@pytest.mark.parametrize(
    "name",
    [
        "lgpio_pwm_consumers_eval.py",
        "oct7-native-consumers-manifest.json",
        "record_lgpio_consumers_loaded_paired_state.py",
        "oct7-lgpio-consumers-paired-postflight.json",
        "consumer-library-source/adafruit_motor/servo.py",
        "checkpoint_lgpio_consumers_paired.py",
    ],
)
def test_changed_frozen_source_manifest_prior_or_consumer_is_rejected(frozen, name):
    _plan, files = frozen
    files[name] = "0" * 64
    with pytest.raises(ValueError, match="changed"):
        checkpoint.frozen_inputs(files)


def test_frozen_plan_byte_guard(frozen):
    _plan, files = frozen
    path = checkpoint.LAB / checkpoint.PLAN_NAME
    path.write_bytes(path.read_bytes() + b"\n")
    with pytest.raises(ValueError, match="plan changed"):
        checkpoint.frozen_inputs(files)


@pytest.mark.parametrize("problem", ["order", "conflicting_source"])
def test_plan_contract_remains_checked_after_its_byte_guard(
    frozen, monkeypatch, problem
):
    plan, files = frozen
    if problem == "order":
        plan["capture_order"] = list(reversed(plan["capture_order"]))
    else:
        plan["loaded_coordinator_source_sha256"]["native"][
            "kernel_pwm_cpu_load_eval.py"
        ] = "0" * 64
    path = checkpoint.LAB / checkpoint.PLAN_NAME
    path.write_text(json.dumps(plan))
    monkeypatch.setattr(checkpoint, "PLAN_SHA256", checkpoint.digest(path))
    with pytest.raises(ValueError):
        checkpoint.frozen_inputs(files)


def test_empty_independent_mapping_blocks_without_main_or_any_output(
    tmp_path, monkeypatch
):
    monkeypatch.setattr(checkpoint, "AUDIT_SOURCES", {})
    before = list(tmp_path.iterdir())
    with pytest.raises(ValueError, match="mapping pending"):
        checkpoint.audit_inventory({})
    assert list(tmp_path.iterdir()) == before


@pytest.mark.parametrize(
    "problem", [None, "hash", "symlink", "outside_prefix", "traversal", "collision"]
)
def test_exact_independent_method_bytes_and_paths(tmp_path, monkeypatch, problem):
    source = tmp_path / "method.py"
    source.write_text("# fake independent method\n")
    name, expected = "audit-source/method.py", checkpoint.digest(source)
    files = {}
    if problem == "hash":
        expected = "0" * 64
    elif problem == "symlink":
        linked = tmp_path / "linked.py"
        linked.symlink_to(source)
        source = linked
    elif problem == "outside_prefix":
        name = "other/method.py"
    elif problem == "traversal":
        name = "audit-source/../method.py"
    elif problem == "collision":
        files[name] = expected
    monkeypatch.setattr(checkpoint, "AUDIT_SOURCES", {name: (str(source), expected)})
    if problem:
        with pytest.raises(ValueError):
            checkpoint.audit_inventory(files)
    else:
        assert checkpoint.audit_inventory(files) == {name: source}


@pytest.mark.parametrize(
    "name", ["", "/absolute", "../outside", "a/../outside", "a/./b", "a\\b"]
)
def test_unsafe_archive_and_target_names_rejected(name):
    with pytest.raises(ValueError):
        checkpoint.safe_name(name)


def test_tree_bytes_and_duplicate_target_gate(tmp_path):
    root = tmp_path.resolve()
    folder = root / "fake-capture"
    folder.mkdir()
    file = folder / "empty.stderr"
    file.write_bytes(b"")
    assert checkpoint.tree_files(root, [folder.name]) == {
        "fake-capture/empty.stderr": checkpoint.digest(file)
    }
    with pytest.raises(ValueError, match="Duplicate recovery targets"):
        checkpoint.tree_files(root, [folder.name, folder.name])
    with pytest.raises(ValueError, match="Duplicate member"):
        checkpoint.tree_files(root, [folder.name, "fake-capture/empty.stderr"])


@pytest.mark.parametrize("problem", ["missing", "file_symlink", "parent_symlink"])
def test_missing_or_linked_targets_rejected_before_reading_bytes(tmp_path, problem):
    root = tmp_path.resolve()
    real = root / "real"
    real.mkdir()
    (real / "member").write_bytes(b"fake evidence")
    target = "missing"
    if problem == "file_symlink":
        (root / "linked").symlink_to(real / "member")
        target = "linked"
    elif problem == "parent_symlink":
        (root / "linked").symlink_to(real, target_is_directory=True)
        target = "linked/member"
    with pytest.raises(ValueError, match="Missing or linked target"):
        checkpoint.tree_files(root, [target])
