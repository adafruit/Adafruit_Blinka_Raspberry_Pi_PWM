"""Record the fixed CPU-only load helper; never issue GPIO commands."""

import argparse
import json
import os
import re
import selectors
import subprocess
import time
from pathlib import Path


class LoadRecordingError(RuntimeError):
    def __init__(self, message, returncode):
        super().__init__(message)
        self.returncode = returncode


def record(stem, remote_root, *, launch_callback=None):
    if not re.fullmatch(r"[A-Za-z0-9_-]+", stem):
        raise ValueError("Use a simple exclusive receipt stem")
    if not re.fullmatch(
        r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/cpu-load-eval", remote_root
    ):
        raise ValueError("Requires the isolated Pi 5 CPU-only helper directory")
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        f"/usr/bin/python3 {remote_root}/kernel_pwm_cpu_load_eval.py",
    ]
    with Path(stem + ".load.stdout").open("xb") as stdout_file:
        with Path(stem + ".load.stderr").open("xb") as stderr_file:
            process = subprocess.Popen(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=stderr_file,
            )
            malformed = []
            callback_called = False
            callback_error = None
            deadline = time.monotonic() + 25
            pending = b""
            try:
                # Two tiny receipts; flush the launch so a separate capture can
                # start while workers are active. Bound the entire stream, not
                # merely the wait after EOF; preserve malformed/partial bytes.
                with selectors.DefaultSelector() as selector:
                    selector.register(process.stdout, selectors.EVENT_READ)
                    while True:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise TimeoutError(
                                "CPU-only SSH stream exceeded 25 seconds"
                            )
                        if not selector.select(timeout=min(remaining, 1)):
                            continue
                        chunk = os.read(process.stdout.fileno(), 4096)
                        if not chunk:
                            break
                        stdout_file.write(chunk)
                        stdout_file.flush()
                        pending += chunk
                        while b"\n" in pending:
                            line, pending = pending.split(b"\n", 1)
                            try:
                                value = json.loads(line)
                                if not isinstance(value, dict):
                                    raise ValueError("Receipt is not an object")
                            except (ValueError, UnicodeError) as error:
                                malformed.append(str(error))
                                continue
                            if (
                                launch_callback is not None
                                and not callback_called
                                and value.get("event") == "load_launched"
                            ):
                                callback_called = True
                                try:
                                    launch_callback(value)
                                except BaseException as error:
                                    # A failing capture/callback must not stop
                                    # receipt draining or owned-SSH cleanup.
                                    callback_error = error
                            print(
                                json.dumps(
                                    {
                                        "event": value.get("event"),
                                        "launcher_pid": value.get("launcher_pid"),
                                        "worker_count": value.get(
                                            "started_worker_count",
                                            value.get("worker_count"),
                                        ),
                                        "success": value.get("success"),
                                    }
                                ),
                                flush=True,
                            )
                result = process.wait(timeout=max(0.01, deadline - time.monotonic()))
            finally:
                # Only this locally owned SSH process is targeted. Remote
                # CPU workers independently expire; no GPIO command is issued.
                try:
                    if process.poll() is None:
                        try:
                            process.terminate()
                        except ProcessLookupError:
                            pass  # Exited after poll; still reap the owned process.
                        try:
                            process.wait(timeout=0.75)
                        except subprocess.TimeoutExpired:
                            try:
                                process.kill()
                            except ProcessLookupError:
                                pass
                            process.wait(timeout=0.75)
                finally:
                    process.stdout.close()
    if pending or malformed:
        raise LoadRecordingError("Malformed/partial CPU-load receipts retained", result)
    if result:
        raise LoadRecordingError(
            f"CPU-only helper failed ({result}); receipts retained", result
        )
    if callback_error is not None:
        raise callback_error
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stem")
    parser.add_argument("--remote-root", required=True)
    args = parser.parse_args()
    record(args.stem, args.remote_root)


if __name__ == "__main__":
    main()
