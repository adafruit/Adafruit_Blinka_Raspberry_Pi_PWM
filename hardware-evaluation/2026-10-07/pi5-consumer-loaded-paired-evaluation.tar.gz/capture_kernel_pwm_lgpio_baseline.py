"""Collect fixed original-Blinka lgpio evidence; never infer waveform/parity.

Only schema/source/cleanup receipts are checked. SAL and every raw edge are
preserved for separate offline analysis. Collector success is not pulse
acceptance, an electrical API readback, or a baseline-parity verdict.
"""

import argparse
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

from capture_pwm import DEVICE_ID, thermal_issues
from kernel_pwm_lgpio_baseline_eval import SEQUENCES
from saleae import automation

MODES = ("direct", "frequency", "half50-direct")
BACKEND = "original-blinka-lgpio"
BASELINE_COMMIT = "beb49bf8ea9305dacbd14b08525f234eda563c02"
SOURCE_HASHES = {
    "kernel_pwm_eval.py": "7cb4ea051e346b38b3276b92e5e0edcd9f24f4ed36f7d4f4eeffa4800f8e2111",
    "baseline_pwmout.py": "90284c9860827ee39cf9eb0b5639b1e6f296473d99fd1be222dccb1d618a9220",
    "lgpio_pin.py": "f836d4e5342639b0fa4348b8600fbc6b6401d79ce138ccbda2886bc028cdb413",
    "kernel_pwm_lgpio_baseline_eval.py": "8018a1766c711a9babe8d98c4f1f77412f23876c4e7fdc96bd012caaf3808b2f",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(text):
    def object_pairs(pairs):
        value = {}
        for key, item in pairs:
            require(key not in value, f"Duplicate receipt key: {key}")
            value[key] = item
        return value

    def constant(value):
        raise ValueError(f"Non-finite receipt value: {value}")

    result = json.loads(text, object_pairs_hook=object_pairs, parse_constant=constant)
    require(isinstance(result, dict), "Baseline receipt must be an object")
    return result


def validate_remote(remote, mode):
    require(mode in MODES, "Unsupported original-lgpio mode")
    require(isinstance(remote, dict), "Baseline receipt must be an object")
    require(
        type(remote.get("schema_version")) is int
        and remote["schema_version"] == 1
        and remote.get("mode") == mode
        and remote.get("sequence_marker") == f"original-lgpio-{mode}-v1"
        and remote.get("backend") == BACKEND
        and remote.get("baseline_commit") == BASELINE_COMMIT
        and type(remote.get("gpio")) is int
        and remote["gpio"] == 18,
        "Original-lgpio schema/mode/backend/GPIO provenance mismatch",
    )
    require(
        remote.get("source_sha256") == SOURCE_HASHES,
        "Exact frozen four-source hashes required",
    )
    require(
        remote.get("characterization_only") is True
        and remote.get("production_backend_unchanged") is True
        and "parity_pass" in remote
        and remote["parity_pass"] is None
        and remote.get("api_readbacks_are_not_electrical") is True,
        "Baseline characterization must not claim parity/electrical readbacks",
    )
    require(
        all(
            remote.get(key) is True
            for key in (
                "success",
                "completed_normally",
                "fresh_claim_accepted",
                "gpio18_released",
                "chip_closed",
                "low_confirmed",
            )
        )
        and remote.get("cleanup_final_readback") == {"gpio_level": 0, "tx_busy": 0}
        and all(
            type(value) is int for value in remote["cleanup_final_readback"].values()
        )
        and remote.get("cleanup_errors") == []
        and remote.get("signals_received") == []
        and "primary_error" in remote
        and remote["primary_error"] is None,
        "Original-lgpio successful fresh ownership/low cleanup not confirmed",
    )
    require(
        type(remote.get("helper_pid")) is int
        and remote["helper_pid"] > 0
        and type(remote.get("begin_ns")) is int
        and type(remote.get("end_ns")) is int
        and 0 <= remote["begin_ns"] < remote["end_ns"]
        and remote["end_ns"] - remote["begin_ns"] < 15_000_000_000,
        "Invalid baseline helper identity/run interval",
    )
    identity = remote.get("identity")
    require(
        isinstance(identity, dict)
        and type(identity.get("gpio")) is int
        and identity["gpio"] == 18
        and type(identity.get("gpiochip_index")) is int
        and identity["gpiochip_index"] >= 0
        and identity.get("gpiochip") == f"/dev/gpiochip{identity['gpiochip_index']}"
        and isinstance(identity.get("gpiochip_device_number"), str)
        and re.fullmatch(r"[0-9]+:[0-9]+", identity["gpiochip_device_number"])
        and identity.get("label") == "pinctrl-rp1"
        and identity.get("kernel_release") == "6.12.75+rpt-rpi-2712"
        and identity.get("compatible") == ["raspberrypi,rp1-gpio"]
        and isinstance(identity.get("model"), str)
        and identity["model"].startswith("Raspberry Pi 5 Model B Rev ")
        and isinstance(identity.get("boot_id"), str)
        and re.fullmatch(
            r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", identity["boot_id"]
        ),
        "Expected fresh Pi5 RP1 GPIO18 identity",
    )
    chip_info = remote.get("chip_info")
    line_info = remote.get("preclaim_line_info")
    require(
        isinstance(chip_info, list)
        and len(chip_info) == 4
        and type(chip_info[0]) is int
        and chip_info[0] == 0
        and type(chip_info[1]) is int
        and chip_info[1] > 18
        and isinstance(chip_info[2], str)
        and chip_info[2]
        and chip_info[3] == "pinctrl-rp1"
        and type(remote.get("preclaim_mode")) is int
        and remote["preclaim_mode"] >= 0
        and remote["preclaim_mode"] & 1 == 0
        and isinstance(line_info, list)
        and len(line_info) == 5
        and type(line_info[0]) is int
        and line_info[0] == 0
        and type(line_info[1]) is int
        and line_info[1] == 18
        and type(line_info[2]) is int
        and line_info[2] >= 0
        and line_info[2] & 1 == 0
        and isinstance(line_info[3], str)
        and line_info[4] == "",
        "Opened RP1 chip/fresh unclaimed GPIO18 receipt required",
    )
    phases = remote.get("phases")
    require(
        isinstance(phases, list)
        and len(phases) == len(SEQUENCES[mode])
        and isinstance(remote.get("events"), list)
        and remote["events"],
        "Missing original-lgpio phase/API event evidence",
    )
    previous_end = remote["begin_ns"]
    for phase, (name, duration, frequency, duty) in zip(phases, SEQUENCES[mode]):
        require(isinstance(phase, dict), "Invalid fixed baseline phase")
        require(
            phase.get("name") == name
            and type(phase.get("generation")) is int
            and phase["generation"] == 1
            and type(phase.get("frequency")) is int
            and phase["frequency"] == frequency
            and type(phase.get("duty_u16")) is int
            and phase["duty_u16"] == duty
            and type(phase.get("baseline_duty_percent")) is int
            and phase["baseline_duty_percent"] == round(duty / 65535 * 100)
            and type(phase.get("duration_seconds")) in (int, float)
            and phase["duration_seconds"] == duration
            and phase.get("intent")
            == (
                "low"
                if duty == 0
                else "constant_high"
                if duty == 65535
                else "interior_pwm"
            ),
            f"Fixed original-lgpio phase specification mismatch: {name}",
        )
        clocks = [
            phase.get(key)
            for key in (
                "begin_ns",
                "transition_begin_ns",
                "stable_begin_ns",
                "end_ns",
                "readback_end_ns",
            )
        ]
        require(
            all(type(value) is int for value in clocks)
            and previous_end <= clocks[0] == clocks[1] <= clocks[2] < clocks[3]
            and clocks[3] <= clocks[4] <= remote["end_ns"],
            f"Invalid contained baseline phase timing: {name}",
        )
        previous_end = clocks[4]
        api_state = phase.get("api_state")
        require(
            api_state == {"frequency": frequency, "duty_cycle": duty, "enabled": True}
            and type(api_state["frequency"]) is int
            and type(api_state["duty_cycle"]) is int
            and api_state["enabled"] is True,
            f"Baseline API state does not match requested fixed phase: {name}",
        )
    for key, limit in (("before", 65000), ("after", 70000)):
        snapshot = remote.get(key)
        require(
            isinstance(snapshot, dict) and not thermal_issues(snapshot, limit),
            f"Baseline {key} thermal/firmware receipt failed",
        )


def _write(output, name, value):
    with (output / name).open("x") as stream:
        stream.write(value)


def capture_test(directory, remote_root, mode):
    require(mode in MODES, "Unsupported original-lgpio mode")
    require(
        isinstance(remote_root, str)
        and re.fullmatch(
            r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/lgpio-baseline-eval", remote_root
        ),
        "Requires the isolated Pi5 lgpio-baseline-eval directory",
    )
    output = Path(directory).resolve()
    require(
        re.fullmatch(r"[A-Za-z0-9_-]+", output.name),
        "Use a simple capture directory name",
    )
    output.mkdir(parents=True, exist_ok=False)
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(
            [
                "/usr/bin/python3",
                remote_root + "/kernel_pwm_lgpio_baseline_eval.py",
                "--mode",
                mode,
            ]
        ),
    ]
    remote, primary, logic_version = None, None, None
    evidence_errors, timing = [], {}
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            if not any(
                device.device_id == DEVICE_ID and not device.is_simulation
                for device in manager.get_devices()
            ):
                raise RuntimeError("Confirmed analyzer is not available")
            logic_version = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[0], digital_sample_rate=100_000_000
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as capture:
                try:
                    timing["lead_begin_ns"] = time.monotonic_ns()
                    time.sleep(0.5)
                    timing["lead_end_ns"] = time.monotonic_ns()
                    with (output / "remote.stdout").open("x") as stdout_file:
                        with (output / "remote.stderr").open("x") as stderr_file:
                            remote = subprocess.run(
                                command,
                                stdout=stdout_file,
                                stderr=stderr_file,
                                text=True,
                                check=False,
                                timeout=30,
                            )
                except subprocess.TimeoutExpired as error:
                    primary, remote = error, subprocess.CompletedProcess(command, 124)
                except BaseException as error:
                    primary, remote = error, subprocess.CompletedProcess(command, None)
                finally:
                    for name in ("remote.stdout", "remote.stderr"):
                        try:
                            if not (output / name).exists():
                                _write(output, name, "")
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
                    for name, action in (
                        ("tail", lambda: time.sleep(0.2)),
                        ("stop", capture.stop),
                        (
                            "save_capture",
                            lambda: capture.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_binary",
                            lambda: capture.export_raw_data_binary(
                                str(output), digital_channels=[0]
                            ),
                        ),
                    ):
                        try:
                            if name == "tail":
                                timing["tail_begin_ns"] = time.monotonic_ns()
                            action()
                            if name == "tail":
                                timing["tail_end_ns"] = time.monotonic_ns()
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:
        if primary is None:
            primary = error
        else:
            evidence_errors.append(f"acquisition: {type(error).__name__}: {error}")
    acquisition = {
        "mode": mode,
        "backend": BACKEND,
        "remote_root": remote_root,
        "remote_command": command,
        "remote_returncode": None if remote is None else remote.returncode,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "local_timing_ns": timing,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None
        if primary is None
        else f"{type(primary).__name__}: {primary}",
        "evidence_errors": evidence_errors,
    }
    _write(output, "acquisition.json", json.dumps(acquisition, indent=2) + "\n")
    if primary is not None or evidence_errors:
        raise RuntimeError(
            f"Capture failure evidence retained: {acquisition['primary_error'] or '; '.join(evidence_errors)}"
        ) from primary
    if remote is None or type(remote.returncode) is not int or remote.returncode != 0:
        raise RuntimeError("Capture saved; original-lgpio helper did not exit0")
    remote_data = read_json((output / "remote.stdout").read_text())
    result = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": mode,
        "backend": BACKEND,
        "sequence_marker": f"original-lgpio-{mode}-v1",
        "sample_rate_hz": 100_000_000,
        "logic_version": logic_version,
        "production_backend_unchanged": True,
        "outputs": [{"gpio": 18, "saleae_channel": 0, "backend": BACKEND}],
        "remote": remote_data,
        "remote_returncode": remote.returncode,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "success_scope": "acquisition and helper schema/source/cleanup receipts only; not pulse acceptance or parity",
    }
    # Save rejected schema/source receipts too, without claiming collection success.
    try:
        validate_remote(remote_data, mode)
    except ValueError as error:
        result["receipt_validation_error"] = str(error)
        _write(output, "results.json", json.dumps(result, indent=2) + "\n")
        raise
    result["collection_success"] = True
    _write(output, "results.json", json.dumps(result, indent=2) + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--mode", choices=MODES, required=True)
    args = parser.parse_args(argv)
    result = capture_test(args.directory, args.remote_root, args.mode)
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "mode": args.mode,
                "backend": BACKEND,
                "collection_success": result["collection_success"],
                "waveform_accepted": None,
                "parity_evaluated": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
