"""Capture genuine Servo/DCMotor consumer evidence on passive GPIO probes.

Preserve unfiltered physical Logic8 channels 0/1 and every raw edge. Collection
success covers pinned source, API-state, private ownership and cleanup only;
it is not waveform acceptance, actuator operation, parity, or installed Blinka
compatibility. Acquisition mechanics match the frozen dual-output collector.
"""

import argparse
import hashlib
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

import capture_native_pwm_dual as frozen
import native_pwm_consumers_eval as helper
from saleae import automation

DEVICE_ID, require, read_json, _write = (
    frozen.DEVICE_ID,
    frozen.require,
    frozen.read_json,
    frozen._write,
)
MODE, BACKEND, SEQUENCE_MARKER = helper.MODE, helper.BACKEND, helper.SEQUENCE_MARKER


def validate_local_manifest(manifest):
    hashes = helper.validate_manifest(manifest)
    frozen.validate_local_manifest(
        {
            "schema_version": 1,
            "source_sha256": {key: hashes[key] for key in helper.dual.SOURCE_KEYS},
        }
    )
    paths = {helper.NEW_SOURCE: Path(helper.__file__), **helper.consumer_inventory()}
    require(
        all(
            hashlib.sha256(path.read_bytes()).hexdigest() == hashes[key]
            for key, path in paths.items()
        ),
        "Local consumer/helper Python bytes must match selected-source manifest",
    )
    return hashes


def validate_remote(remote, manifest):
    hashes = helper.validate_manifest(manifest)
    require(
        frozen._fields(
            remote,
            {
                "schema_version": 1,
                "mode": MODE,
                "backend": BACKEND,
                "sequence_marker": SEQUENCE_MARKER,
                "gpios": [18, 23],
                "motor_version": "3.5.0",
                "primary_error": None,
                "cleanup_errors": [],
                "signals_received": [],
                "parity_pass": None,
                "actual_actuators_attached": False,
                "installed_blinka_compatibility_proven": False,
                "runtime_flags": {"short_slice": False, "shared": False},
                "watchdog_seconds": 14,
                "sequence_dwell_seconds": round(sum(p[1] for p in helper.SEQUENCE), 6),
                "low_settle_seconds": 0.1,
                "normal_fixed_wait_seconds": round(
                    sum(p[1] for p in helper.SEQUENCE) + 0.3, 6
                ),
            },
        )
        and remote.get("source_sha256") == hashes,
        "Consumer schema/source/functional-only contract mismatch",
    )
    require(
        all(
            remote.get(key) is True
            for key in (
                "success",
                "completed_normally",
                "read_only_chip_closed",
                "characterization_only",
                "functional_consumer_integration_only",
                "passive_probes_only",
                "production_backend_unchanged",
                "api_readbacks_are_not_electrical",
                "selected_source_hashes_are_not_whole_system_attestation",
                "variable_frequency",
                "watchdog_cannot_bound_native_hang_or_sigkill",
            )
        ),
        "Consumer positive safety gates required",
    )
    require(
        frozen._exact(
            remote.get("integration_shim"),
            {
                "kind": "in-memory-pwmio-export",
                "unwrapped_public_pwm_objects": True,
                "installed_blinka_compatibility_proven": False,
                "installed_pwmio_module_used": False,
                "restored": True,
            },
        ),
        "Only the restored planned in-memory shim is authorized",
    )
    consumers = remote.get("consumers")
    require(
        frozen._fields(
            consumers,
            {
                "distribution": "adafruit-circuitpython-motor",
                "version": "3.5.0",
                "servo": {
                    "actuation_range": 180,
                    "min_pulse_us": 1000,
                    "max_pulse_us": 2000,
                },
                "motor": {"decay_mode": 0, "throttle_zero_is_both_high_brake": True},
            },
        )
        and isinstance(consumers.get("source_paths"), dict)
        and set(consumers["source_paths"]) == set(helper.CONSUMER_PINS)
        and all(
            isinstance(path, str)
            and Path(path).is_absolute()
            and Path(path).parts[-2:] == ("adafruit_motor", Path(key).name)
            for key, path in consumers["source_paths"].items()
        ),
        "Genuine consumer version/origins required",
    )
    environment = remote.get("inherited_environment")
    require(
        isinstance(environment, dict)
        and set(environment) == {"BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED"}
        and all(
            value is None or isinstance(value, str) and value != "1"
            for value in environment.values()
        ),
        "Consumer runtime flags must remain disabled",
    )
    require(
        type(remote.get("helper_pid")) is int
        and remote["helper_pid"] > 0
        and type(remote.get("begin_ns")) is int
        and type(remote.get("end_ns")) is int
        and 0 <= remote["begin_ns"] < remote["end_ns"]
        and remote["end_ns"] - remote["begin_ns"] < 14_000_000_000
        and isinstance(remote.get("manifest_path"), str)
        and re.fullmatch(
            helper.ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", remote["manifest_path"]
        ),
        "Bounded consumer helper/isolated manifest identity required",
    )
    identity = remote.get("identity")
    require(
        frozen._fields(
            identity,
            {
                "gpio": 18,
                "label": "pinctrl-rp1",
                "kernel_release": helper.dual.base.baseline.KERNEL,
                "compatible": ["raspberrypi,rp1-gpio"],
            },
        )
        and type(identity.get("gpiochip_index")) is int
        and identity["gpiochip_index"] >= 0
        and identity.get("gpiochip") == f"/dev/gpiochip{identity['gpiochip_index']}"
        and isinstance(identity.get("gpiochip_device_number"), str)
        and re.fullmatch(r"[0-9]+:[0-9]+", identity["gpiochip_device_number"])
        and isinstance(identity.get("model"), str)
        and identity["model"].startswith("Raspberry Pi 5 Model B Rev ")
        and isinstance(identity.get("boot_id"), str)
        and re.fullmatch(
            r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", identity["boot_id"]
        ),
        "Approved Pi5 RP1 kernel/controller identity required",
    )
    preclaim = remote.get("preclaim_lines")
    require(
        isinstance(preclaim, list) and len(preclaim) == 2,
        "Both consumer pins need fresh preclaim info",
    )
    for row, gpio in zip(preclaim, (18, 23)):
        require(frozen._fields(row, {"gpio": gpio}), "Preclaim pin mismatch")
        frozen._chip(row.get("chip_info"), identity)
        frozen._line(row.get("line_info"), gpio)
    outputs = remote.get("outputs")
    require(
        isinstance(outputs, list) and len(outputs) == 3,
        "Three consumer output generations required",
    )
    records = {}
    for row, (output_id, gpio, generation, frequency) in zip(outputs, helper.OUTPUTS):
        require(
            frozen._fields(
                row,
                {
                    "output_id": output_id,
                    "gpio": gpio,
                    "generation": generation,
                    "initial_frequency": frequency,
                    "variable_frequency": True,
                    "fresh_claim_accepted": True,
                    "initial_low_confirmed": True,
                    "low_confirmed": True,
                    "released": True,
                    "read_only_chip_closed": True,
                },
            )
            and frozen._exact(
                row.get("initial_readback"), {"gpio_level": 0, "inactive": True}
            )
            and frozen._exact(
                row.get("cleanup_final_readback"), {"gpio_level": 0, "inactive": True}
            ),
            "Fresh private consumer initial/cleanup inactive and release proof required",
        )
        request = row.get("owned_request")
        require(
            frozen._fields(
                request,
                {"chip_name": Path(identity["gpiochip"]).name, "offsets": [gpio]},
            )
            and set(request) == {"chip_name", "offsets", "fd"}
            and type(request.get("fd")) is int
            and request["fd"] >= 0,
            "Consumer output must privately own its verified pin and FD",
        )
        frozen._chip(row.get("chip_info"), identity)
        for key in ("preclaim_line_info", "released_line_info"):
            frozen._line(row.get(key), gpio)
        records[output_id] = row
    _validate_protocol(remote, records)
    for key, limit in (("before", 65000), ("after", 70000)):
        require(
            isinstance(remote.get(key), dict)
            and not helper.core.thermal_issues(remote[key], limit),
            "Consumer thermal gate failed: " + key,
        )


def _validate_protocol(remote, records):
    phases, actions, events, shutdowns = (
        remote.get(key) for key in ("phases", "actions", "events", "shutdowns")
    )
    require(
        isinstance(phases, list) and len(phases) == len(helper.SEQUENCE),
        "Exact consumer phases required",
    )
    require(
        isinstance(actions, list) and len(actions) == 10,
        "All ten consumer actions required",
    )
    require(
        isinstance(events, list) and all(isinstance(e, dict) for e in events),
        "Consumer caller events required",
    )
    previous = remote["begin_ns"]
    for ordinal, event in enumerate(events):
        require(
            frozen._fields(event, {"ordinal": ordinal, "status": "ok"})
            and event.get("output_id") in records
            and frozen._fields(
                event,
                {
                    "gpio": records[event["output_id"]]["gpio"],
                    "generation": records[event["output_id"]]["generation"],
                },
            )
            and isinstance(event.get("scope"), str)
            and isinstance(event.get("operation"), str)
            and type(event.get("begin_ns")) is int
            and type(event.get("end_ns")) is int
            and previous <= event["begin_ns"] <= event["end_ns"] <= remote["end_ns"],
            "Chronological successful per-generation caller events required",
        )
        previous = event["end_ns"]
    constructors = [
        event for event in events if event["operation"] == "PWMOut.__init__"
    ]
    require(
        len(constructors) == 3, "All three public consumer PWM constructors required"
    )
    for event, (output_id, gpio, _generation, frequency) in zip(
        constructors, helper.OUTPUTS
    ):
        require(
            event["output_id"] == output_id
            and frozen._exact(
                event.get("arguments"),
                {
                    "gpiochip": remote["identity"]["gpiochip"],
                    "gpio": gpio,
                    "frequency": frequency,
                    "duty_u16": 0,
                    "variable_frequency": True,
                },
            ),
            "Consumer constructor pin/frequency/default permission mismatch",
        )
    states, action_index, previous = {}, 0, remote["begin_ns"]

    def snapshots():
        result = [
            frozen._snapshot(output_id, state, records)
            for output_id, state in states.items()
        ]
        require(
            len({r["owned_request"]["fd"] for r in result}) == len(result),
            "Live consumer requests must have distinct FDs",
        )
        return result

    for index, (phase, spec) in enumerate(zip(phases, helper.SEQUENCE)):
        name, duration, operation, value = spec
        scope = f"{index:02d}_{name}"
        require(
            frozen._fields(
                phase,
                {
                    "index": index,
                    "name": name,
                    "scope": scope,
                    "duration_seconds": duration,
                    "operation": operation,
                    "value": value,
                },
            ),
            "Exact consumer phase/action/dwell mismatch",
        )
        clocks = [
            phase.get(key)
            for key in ("begin_ns", "stable_begin_ns", "end_ns", "readback_end_ns")
        ]
        require(
            all(type(v) is int for v in clocks)
            and previous
            <= clocks[0]
            <= clocks[1]
            < clocks[2]
            <= clocks[3]
            <= remote["end_ns"]
            and clocks[2] - clocks[1] >= round(duration * 1e9),
            "Consumer phase dwell/interval mismatch",
        )
        previous, before = clocks[-1], snapshots()
        if operation == "servo_initialize":
            states["servo18-g1"] = (50, 0)
        elif operation == "motor_initialize":
            states.update({"motor18-g2": (1000, 0), "motor23-g1": (1000, 0)})
        elif operation == "Servo.angle":
            states["servo18-g1"] = (50, helper.servo_duty(value))
        elif operation == "DCMotor.throttle":
            positive, negative = helper.motor_duties(value)
            states.update(
                {"motor18-g2": (1000, positive), "motor23-g1": (1000, negative)}
            )
        else:
            del states[
                "servo18-g1"
                if operation == "servo_release"
                else "motor18-g2"
                if operation == "motor_release_positive"
                else "motor23-g1"
            ]
        after = snapshots()
        require(
            frozen._exact(phase.get("api_state"), after)
            and frozen._exact(phase.get("api_state_end"), after),
            "Consumer native API state/request mismatch",
        )
        consumer = (
            {
                "kind": "Servo",
                "angle": helper.servo_readback(
                    value if operation == "Servo.angle" else None
                ),
            }
            if index < 5
            else {
                "kind": "DCMotor",
                "throttle": value if operation == "DCMotor.throttle" else None,
                "decay_mode": 0,
            }
            if 6 <= index <= 12
            else None
        )
        for key in ("consumer_state", "consumer_state_end"):
            actual = phase.get(key)
            if consumer is None:
                require(
                    key in phase and actual is None,
                    "Released consumer must not read deinitialized PWM",
                )
            else:
                property_name = "angle" if consumer["kind"] == "Servo" else "throttle"
                require(
                    isinstance(actual, dict)
                    and set(actual) == set(consumer)
                    and actual.get("kind") == consumer["kind"]
                    and helper.readback_matches(
                        actual.get(property_name), consumer[property_name]
                    )
                    and (
                        consumer["kind"] != "DCMotor"
                        or type(actual.get("decay_mode")) is int
                        and actual["decay_mode"] == 0
                    ),
                    "Genuine consumer quantized readback/default decay mismatch",
                )
        if operation in ("Servo.angle", "DCMotor.throttle"):
            action = actions[action_index]
            action_index += 1
            expected_readback = (
                helper.servo_readback(value) if operation == "Servo.angle" else value
            )
            require(
                frozen._fields(
                    action,
                    {
                        "phase_index": index,
                        "operation": operation,
                        "value": value,
                        "status": "ok",
                    },
                )
                and frozen._exact(action.get("api_state_before"), before)
                and frozen._exact(action.get("api_state_after"), after)
                and helper.readback_matches(
                    action.get("consumer_readback"), expected_readback
                )
                and type(action.get("begin_ns")) is int
                and type(action.get("end_ns")) is int
                and clocks[0] <= action["begin_ns"] <= action["end_ns"] <= clocks[1],
                "Consumer action/readback/native state receipt mismatch",
            )
            calls = [
                e for e in events if e["scope"] == scope and e["operation"] == operation
            ]
            expected_ids = (
                ["servo18-g1"]
                if operation == "Servo.angle"
                else ["motor18-g2", "motor23-g1"]
            )
            require(
                len(calls) == 1
                and frozen._exact(
                    calls[0].get("arguments"),
                    {"value": value, "output_ids": expected_ids},
                )
                and action["begin_ns"]
                <= calls[0]["begin_ns"]
                <= calls[0]["end_ns"]
                <= action["end_ns"],
                "Consumer caller operation must be bounded by its action",
            )
    require(
        isinstance(shutdowns, list) and len(shutdowns) == 3,
        "All private consumer shutdown receipts required",
    )
    for row, (output_id, index, sibling_id) in zip(
        shutdowns,
        (
            ("servo18-g1", 5, None),
            ("motor18-g2", 13, "motor23-g1"),
            ("motor23-g1", 14, None),
        ),
    ):
        phase = phases[index]
        require(
            frozen._fields(
                row,
                {
                    "output_id": output_id,
                    "scope": phase["scope"],
                    "reason": "sequence",
                    "sibling_id": sibling_id,
                    "errors": [],
                    "success": True,
                },
            )
            and type(row.get("begin_ns")) is int
            and type(row.get("end_ns")) is int
            and phase["begin_ns"]
            <= row["begin_ns"]
            <= row["end_ns"]
            <= phase["stable_begin_ns"],
            "Private consumer shutdown interval/error mismatch",
        )
        calls = [
            e
            for e in events
            if e["scope"] == phase["scope"] and e["output_id"] == output_id
        ]
        require(
            [e["operation"] for e in calls]
            == [
                "track_owned_request",
                "PWMOut.duty_cycle_zero",
                "low_settle",
                "owned_request.get_value",
                "PWMOut.deinit",
                "gpiod_line_info_released",
            ]
            and row["begin_ns"]
            <= calls[0]["begin_ns"]
            <= calls[-1]["end_ns"]
            <= row["end_ns"]
            and calls[2]["end_ns"] - calls[2]["begin_ns"] >= 100_000_000,
            "Full private low/read/deinit/release events required",
        )
        for key in ("sibling_before", "sibling_after"):
            actual = row.get(key)
            require(
                (key in row and actual is None)
                if sibling_id is None
                else isinstance(actual, dict)
                and type(actual.get("gpio_level")) is int
                and actual["gpio_level"] == 0
                and frozen._exact(
                    {k: v for k, v in actual.items() if k != "gpio_level"},
                    frozen._snapshot(sibling_id, (1000, 0), records),
                ),
                "Independent continuing motor sibling ownership/readback required",
            )


def capture_test(directory, remote_root, remote_python, manifest_path):
    require(
        isinstance(remote_root, str) and re.fullmatch(helper.ROOT_PATTERN, remote_root),
        "Requires the isolated Pi5 native-consumers root",
    )
    require(
        isinstance(remote_python, str)
        and (
            re.fullmatch(
                r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/venv/bin/python", remote_python
            )
            or remote_python == remote_root + "/venv/bin/python"
        ),
        "Requires an explicit approved absolute venv Python",
    )
    manifest = helper.load_manifest(manifest_path)
    validate_local_manifest(manifest)
    output = Path(directory).resolve()
    require(
        re.fullmatch(r"[A-Za-z0-9_-]+", output.name),
        "Use a simple capture directory name",
    )
    output.mkdir(parents=True, exist_ok=False)
    _write(output, "manifest.json", json.dumps(manifest, indent=2) + "\n")
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(
            [
                remote_python,
                remote_root + "/native_pwm_consumers_eval.py",
                "--manifest",
                remote_root + "/manifest.json",
            ]
        ),
    ]
    remote, primary, logic_version = None, None, None
    evidence_errors, timing = [], {}
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            require(
                any(
                    device.device_id == DEVICE_ID and not device.is_simulation
                    for device in manager.get_devices()
                ),
                "Confirmed physical Logic8 analyzer is unavailable",
            )
            logic_version = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[0, 1], digital_sample_rate=100_000_000
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as capture:
                try:
                    timing["lead_begin_ns"] = time.monotonic_ns()
                    time.sleep(0.5)
                    timing["lead_end_ns"] = time.monotonic_ns()
                    with (
                        (output / "remote.stdout").open("x") as stdout_file,
                        (output / "remote.stderr").open("x") as stderr_file,
                    ):
                        remote = subprocess.run(
                            command,
                            stdout=stdout_file,
                            stderr=stderr_file,
                            text=True,
                            check=False,
                            timeout=30,
                        )
                except subprocess.TimeoutExpired as error:
                    primary, remote = error, subprocess.CompletedProcess(command, 124)
                except BaseException as error:
                    primary, remote = error, subprocess.CompletedProcess(command, None)
                finally:
                    for name in ("remote.stdout", "remote.stderr"):
                        try:
                            if not (output / name).exists():
                                _write(output, name, "")
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
                    for name, action in (
                        ("tail", lambda: time.sleep(0.2)),
                        ("stop", capture.stop),
                        (
                            "save_capture",
                            lambda: capture.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_binary",
                            lambda: capture.export_raw_data_binary(
                                str(output), digital_channels=[0, 1]
                            ),
                        ),
                    ):
                        try:
                            if name == "tail":
                                timing["tail_begin_ns"] = time.monotonic_ns()
                            action()
                            if name == "tail":
                                timing["tail_end_ns"] = time.monotonic_ns()
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:
        if primary is None:
            primary = error
        else:
            evidence_errors.append(f"acquisition: {type(error).__name__}: {error}")
    acquisition = {
        "mode": MODE,
        "backend": BACKEND,
        "remote_root": remote_root,
        "remote_python": remote_python,
        "remote_command": command,
        "remote_returncode": None if remote is None else remote.returncode,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "local_timing_ns": timing,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None
        if primary is None
        else f"{type(primary).__name__}: {primary}",
        "evidence_errors": evidence_errors,
    }
    _write(output, "acquisition.json", json.dumps(acquisition, indent=2) + "\n")
    result = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": MODE,
        "backend": BACKEND,
        "sequence_marker": SEQUENCE_MARKER,
        "sample_rate_hz": 100_000_000,
        "logic_version": logic_version,
        "production_backend_unchanged": True,
        "outputs": [
            {"gpio": 18, "saleae_channel": 0, "backend": BACKEND},
            {"gpio": 23, "saleae_channel": 1, "backend": BACKEND},
        ],
        "remote": None,
        "remote_returncode": acquisition["remote_returncode"],
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "installed_blinka_compatibility_proven": False,
        "actual_actuators_attached": False,
        "success_scope": "acquisition and pinned consumer API-state/private cleanup only; not waveform, actuator, parity or installed Blinka compatibility",
    }
    try:
        if primary is not None or evidence_errors:
            raise RuntimeError(
                "Capture failure evidence retained: "
                + (acquisition["primary_error"] or "; ".join(evidence_errors))
            ) from primary
        require(
            remote is not None
            and type(remote.returncode) is int
            and remote.returncode == 0,
            "Consumer native helper did not exit0; raw evidence retained",
        )
        require(
            all(
                (output / name).is_file() and (output / name).stat().st_size > 0
                for name in ("waveform.sal", "digital_0.bin", "digital_1.bin")
            ),
            "Missing SAL/raw PWM channel evidence",
        )
        result["remote"] = read_json((output / "remote.stdout").read_text())
        validate_remote(result["remote"], manifest)
        require(
            result["remote"]["manifest_path"] == remote_root + "/manifest.json",
            "Remote manifest root does not match acquisition",
        )
        result["collection_success"] = True
    except BaseException as error:
        result["receipt_validation_error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        _write(output, "results.json", json.dumps(result, indent=2) + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--remote-python", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    result = capture_test(
        args.directory, args.remote_root, args.remote_python, args.manifest
    )
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "mode": MODE,
                "backend": BACKEND,
                "collection_success": result["collection_success"],
                "waveform_accepted": None,
                "parity_evaluated": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
