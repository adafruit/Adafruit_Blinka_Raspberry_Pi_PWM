"""Compose frozen original-lgpio consumers with self-expiring CPU load.

No PWM/load implementation or generic command interface. The persisted launch
gate proves two owned processes were spawned; actual workload coverage is
verified retrospectively from both real worker intervals. No CPU saturation,
waveform/parity, actuator, installed Blinka or electrical-clock alignment claim.
"""

import argparse
import hashlib
import json
import re
import time
from pathlib import Path

import analyze_kernel_pwm_cpu_load as load_audit
import capture_kernel_pwm_loaded as load_gate
import capture_lgpio_pwm_consumers as consumer
import record_kernel_pwm_cpu_load as recorder

SOURCE_PINS = {
    "record_kernel_pwm_cpu_load.py": "6f755cdb1d2a8dc4a2af72248ddda88740ab2a3ab123ac5a1afe82e52d06974d",
    "capture_kernel_pwm_loaded.py": "479eade31269ee00535112eb99fedf92bb47dc0cb1d57c40534de829410eed4b",
    "analyze_kernel_pwm_cpu_load.py": "d1b45cdfc989d8cdae439534cc6af17a79d46a2bcb8622fad2bc3e0a9fdedb84",
    "kernel_pwm_cpu_load_eval.py": "0644d9b0e0228bca813e7b3cbb909165e1c313d04baf2405c8f0f78badbc18ca",
    "capture_lgpio_pwm_consumers.py": "9007973f3362b81a3d4041998cdd702182ef0edaa4a5c05e415c6aa9a2135505",
    "lgpio_pwm_consumers_eval.py": "7026f71cc47ed46d2b4eeb9a838ca764ff7895e28180a453ae92b2b99bdaf8dd",
    "capture_kernel_pwm_lgpio_baseline.py": "aba9e2d6a14537bd70f7ccdac4ea51ffbae0eb44d3b26f55156734a2509a9545",
    "capture_pwm.py": "03b3960cfb9b5a1cc87926c7dcf4e79e253aa728a31ddcf09d6eaae97c654c0c",
    "test_record_kernel_pwm_cpu_load.py": "64778f969f8e5b33acc551f20bc3436fbe3d74a220eaf8f3d4f620b8feb8c808",
    "test_capture_kernel_pwm_loaded.py": "e2b6053d0d9cc1276865fdddb74eafd9eb3491b39f149e70297d16f89277ee7d",
    "test_analyze_kernel_pwm_cpu_load.py": "3348bdcc2b68f2e1cbf6da226492614826cd80bd921ddc0b9acb45813aa09cd7",
    "test_capture_lgpio_pwm_consumers.py": "2970a80a29ab50bedc63cc110517ad38b51e481a3a9e4096476c3fec9239036f",
    "test_lgpio_pwm_consumers_eval.py": "8e7719361cd74131162c33ef8f772105e4883b9621dbd8247e02714dfe238037",
    "test_kernel_pwm_lgpio_baseline_eval.py": "4961f52f109e5f02821d3438eb51f460b672172ab4e759c47d707b78ffcbd360",
}
CONSUMER_ROOT = "/tmp/blinka-pwm-lgpio-consumers.6Hnhjx"
SUFFIXES = ("", ".load.stdout", ".load.stderr", ".consumers-coordination.json")
require = consumer.require


def source_hashes():
    directory = Path(__file__).resolve().parent
    hashes = {
        name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
        for name in SOURCE_PINS
    }
    require(hashes == SOURCE_PINS, "Frozen consumer/load source dependency changed")
    for name, path in consumer.local_source_inventory().items():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        expected = (
            consumer.HELPER_SHA256
            if name == consumer.helper.NEW_SOURCE
            else consumer.helper.SOURCE_PINS[name]
        )
        require(digest == expected, "Frozen original/consumer dependency changed")
        hashes[name] = digest
    for name in (Path(__file__).name, "test_" + Path(__file__).name):
        hashes[name] = hashlib.sha256((directory / name).read_bytes()).hexdigest()
    return hashes


def actual_exit(value):
    """Unknown/ill-typed values are not invented process exits."""
    return value if type(value) is int else None


def audit(stem, consumer_root, remote_python, manifest):
    launch, completion = load_audit.parse_lines(
        Path(stem + ".load.stdout").read_text(), 2, "load stdout"
    )
    workers = load_audit.validate_load(launch, completion)
    directory = Path(stem)
    saved_manifest, remote, metadata, acquisition = (
        consumer.read_json((directory / name).read_text())
        for name in (
            "manifest.json",
            "remote.stdout",
            "results.json",
            "acquisition.json",
        )
    )
    require(
        saved_manifest == manifest, "Capture manifest changed after initial validation"
    )
    consumer.validate_remote(remote, manifest)
    require(
        metadata.get("collection_success") is True
        and metadata.get("remote") == remote
        and metadata.get("mode") == consumer.MODE
        and metadata.get("backend") == consumer.BACKEND
        and metadata.get("host") == "test-pi5.local"
        and metadata.get("waveform_accepted") is None
        and metadata.get("parity_pass") is None
        and metadata.get("parity_evaluated") is False
        and metadata.get("source_manifest") == manifest
        and metadata.get("motor_version") == "3.5.0"
        and metadata.get("original_variable_frequency_default") is False
        and metadata.get("original_percent_nominals") == consumer.PERCENT_NOMINALS
        and metadata.get("native_backend_executed") is False
        and acquisition.get("mode") == consumer.MODE
        and acquisition.get("backend") == consumer.BACKEND
        and acquisition.get("remote_root") == consumer_root
        and acquisition.get("remote_python") == remote_python
        and remote["manifest_path"] == consumer_root + "/manifest.json"
        and remote.get("python_executable") == remote_python
        and "primary_error" in acquisition
        and acquisition["primary_error"] is None
        and acquisition.get("evidence_errors") == []
        and all(
            type(row.get("remote_returncode")) is int and row["remote_returncode"] == 0
            for row in (metadata, acquisition)
        ),
        "Clean actual-exit0 consumer collection and acquisition required",
    )
    require(
        remote["helper_pid"]
        not in {launch["launcher_pid"], *(worker["pid"] for worker in workers)},
        "Consumer/load PIDs collide",
    )
    reasons = []
    for worker in workers:
        worker["entire_helper_overlap"] = load_audit.interval_overlap(
            worker, remote["begin_ns"], remote["end_ns"]
        )
        worker["phase_overlaps"] = [
            {
                "name": phase["name"],
                **load_audit.interval_overlap(
                    worker, phase["begin_ns"], phase["readback_end_ns"]
                ),
            }
            for phase in remote["phases"]
        ]
        if not worker["entire_helper_overlap"]["bracketed"]:
            reasons.append(
                f"worker{worker['index']} does not bracket entire consumer helper"
            )
        reasons.extend(
            f"worker{worker['index']} does not bracket {phase['name']}"
            for phase in worker["phase_overlaps"]
            if not phase["bracketed"]
        )
    return {
        "accepted": not reasons,
        "rejection_reasons": reasons,
        "workers": workers,
        "load_launcher_pid": launch["launcher_pid"],
        "consumer_helper_pid": remote["helper_pid"],
        "all_phases_bracketed_by_each_worker": all(
            all(phase["bracketed"] for phase in worker["phase_overlaps"])
            for worker in workers
        ),
        "entire_helper_bracketed_by_each_worker": all(
            worker["entire_helper_overlap"]["bracketed"] for worker in workers
        ),
        "load_stdout_sha256": hashlib.sha256(
            Path(stem + ".load.stdout").read_bytes()
        ).hexdigest(),
        "consumer_stdout_sha256": hashlib.sha256(
            (directory / "remote.stdout").read_bytes()
        ).hexdigest(),
        "scope": "Both actual Pi-clock workers bracket entire helper and every phase; not CPU saturation or aligned electrical timing",
    }


def coordinate(stem, bench_root, consumer_root, manifest_path):
    require(
        isinstance(stem, str)
        and re.fullmatch(r"oct7-pi5-lgpio-consumers-loaded-r[12]", stem),
        "Only the two fixed original consumer loaded stems are approved",
    )
    require(
        isinstance(bench_root, str)
        and re.fullmatch(r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}", bench_root),
        "Require the approved Pi5 bench root",
    )
    require(
        isinstance(consumer_root, str) and consumer_root == CONSUMER_ROOT,
        "Require the prepared original consumer root",
    )
    manifest_path = Path(manifest_path)
    require(
        manifest_path.is_file() and not manifest_path.is_symlink(),
        "Reviewed existing nonsymlink manifest required",
    )
    hashes = source_hashes()
    manifest = consumer.helper.load_manifest(manifest_path)
    consumer.validate_local_manifest(manifest)
    require(
        not any(
            Path(stem + suffix).exists() or Path(stem + suffix).is_symlink()
            for suffix in SUFFIXES
        ),
        "All capture/load/coordination targets must be fresh",
    )
    remote_python = bench_root + "/venv/bin/python"
    receipt = {
        "schema_version": 1,
        "stem": stem,
        "mode": consumer.MODE,
        "backend": consumer.BACKEND,
        "bench_root": bench_root,
        "consumer_root": consumer_root,
        "remote_python": remote_python,
        "manifest_path": str(manifest_path.resolve()),
        "manifest_sha256": hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
        "source_sha256": hashes,
        "consumer_source_manifest": manifest,
        "collector_invocation": "in-process frozen capture_lgpio_pwm_consumers.capture_test",
        "launch_receipt": None,
        "launch_validated": False,
        "launch_validation_errors": [],
        "persisted_launch_sha256": None,
        "launch_is_not_actual_worker_start_proof": True,
        "collector_returned_normally": False,
        "collector_collection_success": None,
        "consumer_remote_returncode": None,
        "capture_error": None,
        "capture_evidence_error": None,
        "load_helper_returncode": None,
        "load_recorder_returned_normally": False,
        "load_recorder_error": None,
        "audit_error": None,
        "overlap": None,
        "coordination_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "installed_blinka_compatibility_proven": False,
        "actual_actuators_attached": False,
        "local_timing_not_aligned_to_pi_or_saleae": True,
    }
    with Path(stem + ".consumers-coordination.json").open("x") as summary:

        def capture(launch):
            receipt["launch_receipt"] = launch
            try:
                issues = load_gate.launch_issues(launch)
            except BaseException as error:
                issues = [f"Launch receipt: {type(error).__name__}: {error}"]
            try:
                persisted = Path(stem + ".load.stdout").read_bytes()
                lines = persisted.decode().splitlines()
                require(
                    len(lines) == 1
                    and persisted.endswith(b"\n")
                    and consumer.read_json(lines[0]) == launch,
                    "Require the already-persisted launch only, before any completion bytes",
                )
                receipt["persisted_launch_sha256"] = hashlib.sha256(
                    persisted
                ).hexdigest()
            except BaseException as error:
                issues.append(f"Persisted launch: {type(error).__name__}: {error}")
            receipt["launch_validation_errors"] = issues
            if issues:
                return
            receipt["launch_validated"] = True
            receipt["capture_begin_local_ns"] = time.monotonic_ns()
            try:
                result = consumer.capture_test(
                    stem, consumer_root, remote_python, manifest_path
                )
                receipt["collector_returned_normally"] = True
                receipt["collector_collection_success"] = result.get(
                    "collection_success"
                )
                receipt["consumer_remote_returncode"] = actual_exit(
                    result.get("remote_returncode")
                )
            except BaseException as error:
                # Do not propagate into the recorder: it must finish draining
                # and retain the actual load exit independently of capture.
                receipt["capture_error"] = f"{type(error).__name__}: {error}"
            finally:
                receipt["capture_end_local_ns"] = time.monotonic_ns()
                acquisition_path = Path(stem) / "acquisition.json"
                if (
                    receipt["consumer_remote_returncode"] is None
                    and acquisition_path.is_file()
                ):
                    try:
                        actual = consumer.read_json(acquisition_path.read_text()).get(
                            "remote_returncode"
                        )
                        receipt["consumer_remote_returncode"] = actual_exit(actual)
                    except BaseException as error:
                        receipt["capture_evidence_error"] = (
                            f"{type(error).__name__}: {error}"
                        )

        try:
            receipt["load_helper_returncode"] = actual_exit(
                recorder.record(
                    stem, bench_root + "/cpu-load-eval", launch_callback=capture
                )
            )
            receipt["load_recorder_returned_normally"] = True
        except BaseException as error:
            receipt["load_helper_returncode"] = actual_exit(
                getattr(error, "returncode", None)
            )
            receipt["load_recorder_error"] = f"{type(error).__name__}: {error}"
        try:
            if receipt["collector_returned_normally"]:
                receipt["overlap"] = audit(stem, consumer_root, remote_python, manifest)
        except BaseException as error:
            receipt["audit_error"] = f"{type(error).__name__}: {error}"
        finally:
            receipt["coordination_success"] = bool(
                receipt["launch_validated"]
                and receipt["collector_returned_normally"]
                and receipt["collector_collection_success"] is True
                and type(receipt["consumer_remote_returncode"]) is int
                and receipt["consumer_remote_returncode"] == 0
                and receipt["capture_error"] is None
                and receipt["capture_evidence_error"] is None
                and receipt["load_recorder_returned_normally"]
                and type(receipt["load_helper_returncode"]) is int
                and receipt["load_helper_returncode"] == 0
                and receipt["load_recorder_error"] is None
                and receipt["audit_error"] is None
                and receipt["overlap"] is not None
                and receipt["overlap"]["accepted"]
            )
            json.dump(receipt, summary, indent=2)
            summary.write("\n")
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stem")
    parser.add_argument("--bench-root", required=True)
    parser.add_argument("--consumer-root", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    receipt = coordinate(args.stem, args.bench_root, args.consumer_root, args.manifest)
    print(
        json.dumps(
            {
                key: receipt[key]
                for key in (
                    "stem",
                    "coordination_success",
                    "collector_returned_normally",
                    "consumer_remote_returncode",
                    "capture_error",
                    "load_helper_returncode",
                    "load_recorder_error",
                    "audit_error",
                )
            }
        )
    )
    return 0 if receipt["coordination_success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
