"""Small offline fakes: original-percent identity, retained ambiguity and gates."""

import json
import struct
import zipfile

import analyze_lgpio_pwm_consumers as a
import pytest


def facts(highs, end=4.5):
    edges = sorted(edge for pair in highs for edge in pair)
    waveform = {
        "binary_format_version": 1,
        "header_sample_rate_hz": 100_000_000,
        "chunks": 1,
        "begin_seconds": 0.0,
        "end_seconds": end,
        "initial_state": 0,
        "final_state": 0,
        "edge_count": len(edges),
    }
    return a.retarget(a.raw.channel_facts(waveform, edges))


def train(begin, width_us, period_us=20_000, count=6):
    return [
        (
            begin + index * period_us / 1e6,
            begin + index * period_us / 1e6 + width_us / 1e6,
        )
        for index in range(count)
    ]


def good_highs():
    positive = train(0.30, 1000) + train(0.50, 1400) + train(0.70, 2000)
    positive += [(1.00, 1.20)] + train(1.30, 500, 1000) + [(1.50, 1.70)]
    negative = [(1.00, 1.20)] + train(1.80, 500, 1000) + [(2.00, 2.20)]
    return positive, negative


def test_original_percent_targets_and_complete_raw_facts():
    positive, negative = good_highs()
    ch0, ch1 = facts(positive), facts(negative)
    result = a.topology(ch0, ch1)
    assert len(result["compatible_unique_ordered_topology"]) == 8
    assert not result["ambiguities"]
    assert ch0["waveform"]["edge_count"] == 2 * len(positive)
    assert len(ch0["all_low_runs"]) == len(positive) + 1
    assert len(ch0["all_adjacent_rise_intervals"]) == len(positive) - 1
    assert ch0["all_high_runs"][6]["width_target_candidates"] == ["servo_angle90"]
    assert a.TARGETS["servo_angle90"]["submitted_nominal_high_us"] == 1400
    assert a.TARGETS["motor_half"]["submitted_nominal_high_us"] == 500
    assert result["final_low_runs"]["23"]["kind"] == "final"
    assert ch0["target_normalized_width_distributions"]["servo_angle90"][
        "width_divided_by_target"
    ]["mean"] == pytest.approx(1)


def test_skewed_brake_members_are_not_ordinary_servo_fragments():
    positive, negative = good_highs()
    negative[0] = (1.00001, 1.20001)
    result = a.topology(facts(positive), facts(negative))
    assert result["compatible_unique_ordered_topology"]
    assert result["selected_candidates"]["joint_brake"]["begin_seconds"] == 1.00001


@pytest.mark.parametrize("mutation", ["swap", "missing", "duplicate"])
def test_servo_order_and_uniqueness_are_required(mutation):
    positive, negative = good_highs()
    if mutation == "swap":
        positive[:12] = train(0.30, 1400) + train(0.50, 1000)
    elif mutation == "missing":
        del positive[6:12]
    else:
        positive += train(0.90, 1400, count=5)
    result = a.topology(facts(positive), facts(negative))
    assert result["compatible_unique_ordered_topology"] is None
    assert result["ambiguities"]


def test_short_and_anomalous_pulses_are_retained_not_merged():
    positive, negative = good_highs()
    positive[19:25] = (
        train(1.30, 500, 1000, count=3)
        + train(1.303, 750, 1000, count=1)
        + train(1.304, 500, 1000, count=3)
    )
    channel = facts(positive)
    blocks = channel["all_width_period_blocks"]["motor_half"]
    assert [row["pulse_count"] for row in blocks] == [3, 3]
    assert not any(row["eligible_minimum_pulses"] for row in blocks)
    assert channel["unmatched_width_pair_indices"] == [22]
    result = a.topology(channel, facts(negative))
    assert result["compatible_unique_ordered_topology"] is None
    assert any(
        row["feature"] == "forward_half_full_extent" for row in result["ambiguities"]
    )


def test_eligible_train_plus_short_fragment_does_not_hide_partial_extent():
    positive, negative = good_highs()
    positive += train(1.4, 500, 1000, count=2)
    result = a.topology(facts(positive), facts(negative))
    assert result["selected_candidates"]["motor_forward_half"]["pulse_count"] == 6
    assert result["compatible_unique_ordered_topology"] is None
    assert any(
        row["reason"] == "unassigned_boundary_or_fragment_highs"
        for row in result["ambiguities"]
    )


@pytest.mark.parametrize("offset", [0.0, -0.00000001])
def test_whole_run_sibling_boundary_touch_or_overlap_remains_ambiguity(offset):
    positive, negative = good_highs()
    negative[1:7] = train(1.70 + offset, 500, 1000)
    result = a.topology(facts(positive), facts(negative))
    assert result["compatible_unique_ordered_topology"] is None
    forward = next(
        row
        for row in result["candidate_whole_run_observations"]
        if row["feature"] == "motor_forward_full"
    )
    assert forward["sibling_raw_window"]["overlapping_high_pair_indices"] == [1]
    assert forward["sibling_raw_window"]["whole_run_boundary_inclusive_low"] is False


def test_period_interruption_and_submicrosecond_details_survive():
    channel = facts(
        train(0.30, 500, 1000, count=3)
        + train(0.304, 500, 1000, count=3)
        + [(1.0, 1.00000015), (1.00000030, 1.001)]
    )
    assert [
        row["pulse_count"] for row in channel["all_width_period_blocks"]["motor_half"]
    ] == [3, 3]
    assert len(channel["sub_microsecond_highs"]) == 1
    assert len(channel["sub_microsecond_interior_lows"]) == 1
    assert channel["all_low_runs"][0]["kind"] == "initial"
    assert channel["all_low_runs"][-1]["kind"] == "final"


def binary(highs, end=4.5):
    edges = sorted(edge for pair in highs for edge in pair)
    return struct.pack(
        "<8siiQIdddQ", b"<SALEAE>", 1, 0, 1, 0, 100_000_000, 0, end, len(edges)
    ) + struct.pack(f"<{len(edges)}d", *edges)


@pytest.mark.parametrize(
    "mutation",
    [
        "trailing",
        "truncated",
        "odd",
        "unordered",
        "nan",
        "rate",
        "chunk",
        "short_boundary",
    ],
)
def test_strict_raw_binary_rejects_malformed_export(tmp_path, mutation):
    data = binary([(0.3, 0.301)])
    if mutation == "trailing":
        data += b"x"
    elif mutation == "truncated":
        data = data[:-1]
    elif mutation == "odd":
        data = data[:52] + struct.pack("<Qd", 1, 0.3)
    elif mutation == "unordered":
        data = data[:60] + struct.pack("<dd", 0.301, 0.3)
    elif mutation == "nan":
        data = data[:60] + struct.pack("<dd", float("nan"), 0.301)
    elif mutation == "rate":
        data = data[:28] + struct.pack("<d", 1_000_000) + data[36:]
    elif mutation == "chunk":
        data = data[:16] + struct.pack("<Q", 2) + data[24:]
    else:
        data = binary([(0.01, 0.011)])
    path = tmp_path / "digital_0.bin"
    path.write_bytes(data)
    with pytest.raises(ValueError):
        a.raw.read_channel(path)


def sal(path, mutation=None):
    settings = {
        "enabledChannels": [
            {"type": "Digital", "index": 0},
            {"type": "Digital", "index": 1},
        ],
        "sampleRate": {"digital": 100_000_000},
        "glitchFilter": {"enabled": False, "channels": []},
    }
    device = {"isSimulation": False, "deviceId": "81F8C2631DF5BF30"}
    if mutation == "simulation":
        device["isSimulation"] = True
    elif mutation == "device":
        device["deviceId"] = "11"
    elif mutation == "channel":
        settings["enabledChannels"].pop()
    elif mutation == "filter":
        settings["glitchFilter"]["enabled"] = True
    with zipfile.ZipFile(path, "x") as archive:
        archive.writestr(
            "meta.json",
            json.dumps({"data": {"legacySettings": settings, "legacyDevice": device}}),
        )


@pytest.mark.parametrize("mutation", ["simulation", "device", "channel", "filter"])
def test_saved_sal_physical_unfiltered_channels(tmp_path, mutation):
    path = tmp_path / "waveform.sal"
    sal(path, mutation)
    with pytest.raises(ValueError):
        a.raw.validate_sal(path)


def capture_fixture(tmp_path, monkeypatch):
    directory = tmp_path / "original-r1"
    directory.mkdir()
    parent = a.Path(a.__file__).parent
    plan = {
        "mode": a.collector.MODE,
        "backend": a.collector.BACKEND,
        "sequence_marker": a.collector.SEQUENCE_MARKER,
        "motor_version": "3.5.0",
        "outputs": [
            {"gpio": 18, "saleae_channel": 0},
            {"gpio": 23, "saleae_channel": 1},
        ],
        "sequence": a.sequence_contract(),
        "original_percent_nominals": a.TARGETS,
        "pre_capture_waveform_identification": a.RULES,
        "capture_order": [directory.name],
        "remote_root": "/tmp/blinka-pwm-lgpio-consumers.ABC123",
        "remote_python": "/tmp/blinka-pwm-oct6.ABC123/venv/bin/python",
        "helper_sha256": a.sha256(parent / "lgpio_pwm_consumers_eval.py"),
        "collector_sha256": a.sha256(parent / "capture_lgpio_pwm_consumers.py"),
        "analyzer_sha256": a.sha256(a.__file__),
    }
    manifest = {
        "source_sha256": {key: "1" * 64 for key in a.collector.helper.SOURCE_KEYS}
    }
    manifest["source_sha256"][a.collector.helper.NEW_SOURCE] = plan["helper_sha256"]
    root, python = plan["remote_root"], plan["remote_python"]
    program, remote_manifest = (
        root + "/lgpio_pwm_consumers_eval.py",
        root + "/manifest.json",
    )
    receipt = {"manifest_path": remote_manifest, "python_executable": python}
    common = {
        "mode": a.collector.MODE,
        "backend": a.collector.BACKEND,
        "remote_root": root,
        "remote_python": python,
        "remote_program": program,
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
    }
    acquisition = dict(
        common,
        requested_channels=[0, 1],
        requested_sample_rate_hz=100_000_000,
        requested_glitch_filters=[],
        primary_error=None,
        evidence_errors=[],
        ssh_exit_unavailable_after_exception=False,
        local_timing_not_aligned_to_pi_or_saleae=True,
        remote_manifest=remote_manifest,
        remote_command=[
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            a.shlex.join([python, program, "--manifest", remote_manifest]),
        ],
    )
    result = dict(
        common,
        remote=receipt,
        source_manifest=manifest,
        schema_version=1,
        host="test-pi5.local",
        collection_success=True,
        sequence_marker=a.collector.SEQUENCE_MARKER,
        motor_version="3.5.0",
        helper_sha256=plan["helper_sha256"],
        sample_rate_hz=100_000_000,
        original_variable_frequency_default=False,
        original_percent_nominals=a.TARGETS,
        native_backend_executed=False,
        installed_blinka_compatibility_proven=False,
        actual_actuators_attached=False,
        public_deinit_cancels_or_frees_gpio=False,
        additional_lab_cleanup_required=True,
        production_backend_unchanged=True,
        waveform_accepted=None,
        parity_pass=None,
        parity_evaluated=False,
        outputs=[
            {"gpio": gpio, "saleae_channel": channel, "backend": a.collector.BACKEND}
            for gpio, channel in ((18, 0), (23, 1))
        ],
    )
    data = {
        "manifest.json": manifest,
        "remote.stdout": receipt,
        "acquisition.json": acquisition,
        "results.json": result,
    }
    for name, value in data.items():
        (directory / name).write_text(json.dumps(value))
    (directory / "remote.stderr").write_text("")
    for index, highs in enumerate(good_highs()):
        (directory / f"digital_{index}.bin").write_bytes(binary(highs))
    sal(directory / "waveform.sal")
    plan_path = tmp_path / "plan.json"
    plan_path.write_text(json.dumps(plan))
    calls = []
    monkeypatch.setattr(
        a.collector, "validate_local_manifest", lambda actual: actual["source_sha256"]
    )
    monkeypatch.setattr(
        a.collector,
        "validate_remote",
        lambda actual, selected: calls.append((actual, selected)),
    )
    return directory, plan_path, data, calls


def test_complete_report_delegates_receipts_and_pins_evidence(tmp_path, monkeypatch):
    directory, plan, data, calls = capture_fixture(tmp_path, monkeypatch)
    report = a.analyze(directory, plan)
    assert calls == [(data["remote.stdout"], data["manifest.json"])]
    assert len(report["evidence_sha256"]) == 8
    assert len(report["functional_receipts"]["selected_source_sha256"]) == 21
    assert report["saved_sal"]["physical_device"] is True
    assert report["ordered_raw_topology"]["compatible_unique_ordered_topology"]
    assert "parity_pass" not in report and "waveform_accepted" not in report


def test_actual_collector_metadata_shape_with_fully_stubbed_hardware(
    tmp_path, monkeypatch
):
    import test_capture_lgpio_pwm_consumers as fakes

    path, manifest, _receipt, _events, _manager, _connect, _runner, validate = (
        fakes.configure(monkeypatch, tmp_path)
    )
    directory = tmp_path / "collector-output"
    a.collector.capture_test(directory, fakes.ROOT, fakes.PYTHON, path)
    plan = {
        "helper_sha256": manifest["source_sha256"][a.collector.helper.NEW_SOURCE],
        "remote_root": fakes.ROOT,
        "remote_python": fakes.PYTHON,
    }
    result = a.validate_capture(directory, plan)
    assert result["actual_ssh_returncode"] == 0
    assert validate.call_count == 2
    acquisition = json.loads((directory / "acquisition.json").read_text())
    assert len(acquisition["remote_command"]) == 7


@pytest.mark.parametrize(
    "file,key,value",
    [
        ("acquisition.json", "remote_returncode", None),
        ("results.json", "remote_returncode", False),
        ("acquisition.json", "requested_channels", [1, 0]),
        ("acquisition.json", "remote_python", "/usr/bin/python"),
        ("results.json", "collection_success", False),
        ("results.json", "original_percent_nominals", {}),
    ],
)
def test_metadata_is_not_waveform_or_exit0_substitute(
    tmp_path, monkeypatch, file, key, value
):
    directory, plan, data, _ = capture_fixture(tmp_path, monkeypatch)
    data[file][key] = value
    (directory / file).write_text(json.dumps(data[file]))
    with pytest.raises(ValueError):
        a.analyze(directory, plan)


def test_plan_target_and_source_freeze_required(tmp_path, monkeypatch):
    directory, path, _, _ = capture_fixture(tmp_path, monkeypatch)
    plan = json.loads(path.read_text())
    plan["original_percent_nominals"]["servo_angle90"]["submitted_nominal_high_us"] = (
        1500
    )
    path.write_text(json.dumps(plan))
    with pytest.raises(ValueError, match="targets/sequence"):
        a.analyze(directory, path)


def test_mismatching_binary_bounds_rejected(tmp_path, monkeypatch):
    directory, plan, _, _ = capture_fixture(tmp_path, monkeypatch)
    (directory / "digital_1.bin").write_bytes(binary(good_highs()[1], end=4.6))
    with pytest.raises(ValueError, match="complete channel bounds"):
        a.analyze(directory, plan)


def test_exclusive_reports_never_overwrite_or_partially_start_on_existing_target(
    tmp_path, monkeypatch
):
    directory, plan, _, _ = capture_fixture(tmp_path, monkeypatch)
    output = directory / "analysis.json"
    output.write_text("preserve")
    with pytest.raises(ValueError, match="Exclusive"):
        a.write_reports([directory], plan_path=plan)
    assert output.read_text() == "preserve"
    with pytest.raises(ValueError, match="Duplicate"):
        a.write_reports([directory, directory], "fresh.json", plan)
    with pytest.raises(ValueError, match="plain JSON"):
        a.write_reports([directory], "../escape.json", plan)
    a.write_reports([directory], "fresh.json", plan)
    assert (
        json.loads((directory / "fresh.json").read_text())["capture"] == directory.name
    )
