"""Only fake recorder/collector calls; no workers, SSH, GPIO or Saleae."""

import json
from pathlib import Path
from unittest.mock import MagicMock

import capture_native_pwm_consumers_loaded as bench
import pytest
import test_analyze_kernel_pwm_cpu_load as load_fakes
import test_native_pwm_consumers_eval as consumer_fakes

BENCH = "/tmp/blinka-pwm-oct6.F3SDcm"
CONSUMER = "/tmp/blinka-pwm-native-consumers.abc123"
STEM = "fake-native-consumers-loaded-r1"
old_environment = consumer_fakes.old_environment
dual_environment = consumer_fakes.dual_environment
consumer_environment = consumer_fakes.environment


def shift_times(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if key.endswith("_ns") and type(item) is int:
                value[key] += 1_000_000_000
            else:
                shift_times(item)
    elif isinstance(value, list):
        for item in value:
            shift_times(item)


@pytest.fixture
def environment(consumer_environment, tmp_path, monkeypatch):
    _state, _guard, _module, manifest, _sleeps = consumer_environment
    remote = bench.consumer.helper.experiment(CONSUMER + "/manifest.json")
    assert remote["success"]
    shift_times(remote)
    monkeypatch.chdir(tmp_path)
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(manifest) + "\n")
    return path, manifest, remote


def configure(environment, monkeypatch, scenario="success"):
    manifest_path, manifest, remote = environment
    launch, completion, _old_pwm = load_fakes.documents()
    events = []
    if scenario == "bad_launch":
        launch["started_worker_count"] = 1
    if scenario == "pid_collision":
        remote["helper_pid"] = launch["launcher_pid"]
    if scenario in ("worker_late", "whole_helper_uncovered"):
        record = completion["owned_workers"][0]
        start, finish = record["worker_receipts"]
        begin = (
            remote["phases"][0]["readback_end_ns"] + 1
            if scenario == "worker_late"
            else remote["begin_ns"] + 1
        )
        start["begin_ns"] = finish["begin_ns"] = begin
        finish["end_ns"] = begin + 10_001_000_000
        record["completed_ns"] = finish["end_ns"] + 50_000_000
        completion["end_ns"] = record["completed_ns"] + 50_000_000
        load_fakes.sync_stdout(record)

    def capture(stem, root, python, selected_manifest):
        events.append("capture")
        assert (stem, root, python, selected_manifest) == (
            STEM,
            CONSUMER,
            BENCH + "/venv/bin/python",
            manifest_path,
        )
        assert Path(stem + ".load.stdout").read_text() == json.dumps(launch) + "\n"
        output = Path(stem)
        output.mkdir()
        acquisition = {
            "mode": bench.consumer.MODE,
            "backend": bench.consumer.BACKEND,
            "remote_root": CONSUMER,
            "remote_python": python,
            "remote_returncode": 0,
            "primary_error": None,
            "evidence_errors": [],
        }
        (output / "acquisition.json").write_text(json.dumps(acquisition))
        if scenario == "capture_failure":
            (output / "failure.txt").write_text("retained fake evidence")
            raise OSError("fake capture failure after actual SSH exit0")
        metadata = {
            "mode": bench.consumer.MODE,
            "backend": bench.consumer.BACKEND,
            "host": "test-pi5.local",
            "remote": remote,
            "remote_returncode": 0,
            "collection_success": True,
            "waveform_accepted": None,
            "parity_pass": None,
            "parity_evaluated": False,
        }
        for name, value in (
            ("manifest.json", manifest),
            ("remote.stdout", remote),
            ("results.json", metadata),
        ):
            if scenario != "missing_results" or name != "results.json":
                (output / name).write_text(json.dumps(value))
        return metadata

    def record(stem, root, *, launch_callback):
        assert (stem, root) == (STEM, BENCH + "/cpu-load-eval")
        events.append("load_started")
        try:
            with Path(stem + ".load.stdout").open("x") as output:
                output.write(json.dumps(launch) + "\n")
                output.flush()
                Path(stem + ".load.stderr").write_text("")
                events.append("launch_persisted")
                launch_callback(launch)
                events.append("load_drained")
                output.write(json.dumps(completion) + "\n")
            if scenario == "load_failure":
                raise bench.recorder.LoadRecordingError("fake actual load exit1", 1)
            return 0
        finally:
            events.append("load_reaped")

    capture_mock, record_mock = (
        MagicMock(side_effect=capture),
        MagicMock(side_effect=record),
    )
    monkeypatch.setattr(bench.consumer, "capture_test", capture_mock)
    monkeypatch.setattr(bench.recorder, "record", record_mock)
    return events, capture_mock, record_mock


def test_success_requires_actual_exits_entire_helper_every_phase_and_source_pins(
    environment, monkeypatch
):
    events, capture, recorder = configure(environment, monkeypatch)
    receipt = bench.coordinate(STEM, BENCH, CONSUMER, environment[0])
    assert receipt["coordination_success"] and receipt["collector_returned_normally"]
    assert (
        receipt["consumer_remote_returncode"] == receipt["load_helper_returncode"] == 0
    )
    assert receipt["launch_validated"] and receipt["persisted_launch_sha256"]
    assert receipt["overlap"]["entire_helper_bracketed_by_each_worker"]
    assert receipt["overlap"]["all_phases_bracketed_by_each_worker"]
    assert all(
        len(worker["phase_overlaps"]) == 15 for worker in receipt["overlap"]["workers"]
    )
    assert receipt["source_sha256"].keys() == bench.SOURCE_PINS.keys() | {
        Path(bench.__file__).name
    }
    assert receipt["waveform_accepted"] is None and receipt["parity_pass"] is None
    assert "capture_returncode" not in receipt
    assert events == [
        "load_started",
        "launch_persisted",
        "capture",
        "load_drained",
        "load_reaped",
    ]
    capture.assert_called_once()
    recorder.assert_called_once()
    assert (
        json.loads(Path(STEM + ".consumers-coordination.json").read_text()) == receipt
    )


def test_bad_launch_prevents_capture_but_still_drains_reaps(environment, monkeypatch):
    events, capture, _recorder = configure(environment, monkeypatch, "bad_launch")
    receipt = bench.coordinate(STEM, BENCH, CONSUMER, environment[0])
    capture.assert_not_called()
    assert not receipt["coordination_success"] and receipt["launch_validation_errors"]
    assert receipt["load_helper_returncode"] == 0
    assert events == ["load_started", "launch_persisted", "load_drained", "load_reaped"]


@pytest.mark.parametrize(
    "scenario",
    [
        "capture_failure",
        "load_failure",
        "missing_results",
        "worker_late",
        "whole_helper_uncovered",
        "pid_collision",
    ],
)
def test_failures_preserve_actual_exits_evidence_and_reap(
    environment, monkeypatch, scenario
):
    events, _capture, _recorder = configure(environment, monkeypatch, scenario)
    receipt = bench.coordinate(STEM, BENCH, CONSUMER, environment[0])
    assert not receipt["coordination_success"] and events[-2:] == [
        "load_drained",
        "load_reaped",
    ]
    assert (
        Path(STEM + ".load.stdout").is_file()
        and Path(STEM + ".consumers-coordination.json").is_file()
    )
    assert (
        receipt["consumer_remote_returncode"] == 0
    )  # Actual saved SSH exit, even capture failure.
    if scenario == "load_failure":
        assert receipt["load_helper_returncode"] == 1 and receipt["load_recorder_error"]
    else:
        assert receipt["load_helper_returncode"] == 0
    if scenario == "capture_failure":
        assert receipt["capture_error"] and not receipt["collector_returned_normally"]
        assert (Path(STEM) / "failure.txt").read_text() == "retained fake evidence"
    elif scenario == "whole_helper_uncovered":
        assert receipt["overlap"]["all_phases_bracketed_by_each_worker"]
        assert not receipt["overlap"]["entire_helper_bracketed_by_each_worker"]
    elif scenario == "worker_late":
        assert not receipt["overlap"]["all_phases_bracketed_by_each_worker"]
    elif scenario in ("missing_results", "pid_collision"):
        assert receipt["audit_error"]


@pytest.mark.parametrize("suffix", bench.SUFFIXES)
def test_foreign_existing_or_dangling_targets_never_overwritten(
    environment, monkeypatch, suffix
):
    _events, capture, recorder = configure(environment, monkeypatch)
    target = Path(STEM + suffix)
    target.symlink_to("missing-foreign-evidence")
    with pytest.raises(ValueError, match="fresh"):
        bench.coordinate(STEM, BENCH, CONSUMER, environment[0])
    assert target.is_symlink()
    capture.assert_not_called()
    recorder.assert_not_called()


@pytest.mark.parametrize("problem", ["stem", "bench", "consumer", "manifest", "source"])
def test_invalid_inputs_or_missing_manifest_prevent_load(
    environment, monkeypatch, problem
):
    _events, capture, recorder = configure(environment, monkeypatch)
    stem, bench_root, consumer_root, manifest = STEM, BENCH, CONSUMER, environment[0]
    if problem == "stem":
        stem = "anything-loaded-r3"
    elif problem == "bench":
        bench_root = "/tmp/foreign"
    elif problem == "consumer":
        consumer_root = "/tmp/blinka-pwm-native-updates.abc123"
    elif problem == "manifest":
        manifest = Path("missing.json")
    else:
        monkeypatch.setattr(
            bench,
            "source_hashes",
            lambda: (_ for _ in ()).throw(ValueError("changed source")),
        )
    with pytest.raises(ValueError):
        bench.coordinate(stem, bench_root, consumer_root, manifest)
    capture.assert_not_called()
    recorder.assert_not_called()


def test_cli_is_fixed_composition_without_command_or_worker_options(
    monkeypatch, environment, capsys
):
    coordinate = MagicMock(
        return_value={
            "stem": STEM,
            "coordination_success": True,
            "collector_returned_normally": True,
            "consumer_remote_returncode": 0,
            "capture_error": None,
            "load_helper_returncode": 0,
            "load_recorder_error": None,
            "audit_error": None,
        }
    )
    monkeypatch.setattr(bench, "coordinate", coordinate)
    args = [
        STEM,
        "--bench-root",
        BENCH,
        "--consumer-root",
        CONSUMER,
        "--manifest",
        str(environment[0]),
    ]
    with pytest.raises(SystemExit) as error:
        bench.main(args + ["--worker-count", "4"])
    assert error.value.code == 2
    coordinate.assert_not_called()
    assert bench.main(args) == 0
    assert json.loads(capsys.readouterr().out)["collector_returned_normally"]
