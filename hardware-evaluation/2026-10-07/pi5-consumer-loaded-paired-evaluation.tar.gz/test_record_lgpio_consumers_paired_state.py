"""Hardware-free fixed paired state checks; all SSH calls are replaced."""

import copy
import hashlib
import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace

import pytest
import record_lgpio_consumers_paired_state as state

ROOT = "/tmp/blinka-pwm-lgpio-consumers.6Hnhjx"


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))
    return hashlib.sha256(path.read_bytes()).hexdigest()


@pytest.fixture
def environment(tmp_path, monkeypatch):
    monkeypatch.setattr(state, "LAB", tmp_path)
    plan = {
        "remote_root": ROOT,
        "remote_python": state.REMOTE_PYTHON,
        "capture_order": list(state.CAPTURES),
        "native_reference": {"remote_root": state.NATIVE_ROOT},
    }
    monkeypatch.setattr(
        state,
        "PLAN_SHA256",
        save(tmp_path / "oct7-lgpio-consumers-plan.json", plan),
    )
    manifests = {
        key: {"source_sha256": {str(i): "a" * 64 for i in range(count)}}
        for key, count in (("original", 21), ("native", 18))
    }
    for key, collector in (("original", state.original), ("native", state.native)):
        save(
            tmp_path
            / f"oct7-{'lgpio' if key == 'original' else key}-consumers-manifest.json",
            manifests[key],
        )
        monkeypatch.setattr(collector, "validate_local_manifest", lambda manifest: None)
        monkeypatch.setattr(collector, "validate_remote", lambda remote, manifest: None)
    pids = list(range(2001, 2101))
    monkeypatch.setattr(
        state,
        "PRIOR_SHA256",
        save(
            tmp_path / "oct7-native-consumers-loaded-postflight.json",
            {"accepted": True, "ssh_returncode": 0, "inspected_pids": pids},
        ),
    )
    reply = {
        "read_only": True,
        "no_gpio_request_or_write": True,
        "hostname": "test-pi5",
        "kernel": state.original.helper.baseline.KERNEL,
        "boot_id": state.BOOT_ID,
        "boot_config_sha256": state.BOOT_SHA,
        "remote_manifests": manifests,
        "selected_source_sha256": {
            key: value["source_sha256"] for key, value in manifests.items()
        },
        "program_paths": {
            "original": ROOT + "/lgpio_pwm_consumers_eval.py",
            "native": state.NATIVE_ROOT + "/native_pwm_consumers_eval.py",
        },
        "runtime": {
            "python_executable": state.REMOTE_PYTHON,
            "python_version": "3.13.5 fake",
            "gpiod_version": "2.5.0",
            "lgpio_version": "lgpio.py_0.2.2.0",
            "motor_version": "3.5.0",
        },
        "pid_exists": {str(pid): False for pid in pids},
        "gpiochip": {"name": "gpiochip0", "label": "pinctrl-rp1", "num_lines": 54},
        "lines": [
            {"offset": gpio, "used": False, "consumer": None} for gpio in (18, 23)
        ],
        "pinctrl": [
            {
                "arguments": ["pinctrl", "get", str(gpio)],
                "returncode": 0,
                "stdout": f"{gpio}: op -- | lo\n",
            }
            for gpio in (18, 23)
        ],
        "temperature_millic": "47000",
        "throttled": {"returncode": 0, "stdout": "throttled=0x0\n"},
        "pwm": {
            "returncode": 0,
            "stdout": "0: platform/1f0009c000.pwm, 1 PWM device\n pwm-0 (cooling_fan): requested enabled\n",
        },
    }
    calls = []

    def run(command, *, stdout, stderr, timeout, check):
        calls.append(command)
        assert command[:8] == [
            "ssh",
            "-T",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            command[-1],
        ]
        executable, option, code = shlex.split(command[-1])
        assert (executable, option) == (state.REMOTE_PYTHON, "-c")
        compile(code, "readonly-fake", "exec")
        assert timeout == 20 and check is False
        stdout.write(json.dumps(reply).encode())
        stderr.write(b"retained diagnostic: host PID 999999\n")
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(state, "subprocess", SimpleNamespace(run=run))
    return SimpleNamespace(
        path=tmp_path, manifests=manifests, pids=pids, reply=reply, calls=calls, run=run
    )


def artifact(environment, stage="preflight"):
    return environment.path / f"oct7-lgpio-consumers-paired-{stage}.json"


def paired_captures(environment):
    for index, name in enumerate(state.CAPTURES):
        root = ROOT if "-lgpio-" in name else state.NATIVE_ROOT
        remote = {"helper_pid": 3001 + index, "manifest_path": root + "/manifest.json"}
        save(environment.path / name / "remote.stdout", remote)
        save(
            environment.path / name / "results.json",
            {"collection_success": True, "remote": remote, "remote_returncode": 0},
        )
        save(
            environment.path / name / "acquisition.json",
            {
                "remote_root": root,
                "remote_python": state.REMOTE_PYTHON,
                "remote_returncode": 0,
                "primary_error": None,
                "evidence_errors": [],
            },
        )


def test_preflight_preserves_fixed_sources_and_exact_prior_pids(environment):
    assert state.record("preflight", ROOT) == 0
    result = json.loads(artifact(environment).read_text())
    assert result["accepted"] is True and result["ssh_returncode"] == 0
    assert result["source_manifests"] == environment.manifests
    assert (
        result["inspected_pids"] == environment.pids
        and result["capture_receipts"] == {}
    )
    assert len(environment.calls) == 1
    assert (
        artifact(environment)
        .with_suffix(".json.stderr")
        .read_bytes()
        .endswith(b"999999\n")
    )
    assert (
        result["source_sha256"]
        == hashlib.sha256(Path(state.__file__).read_bytes()).hexdigest()
    )


def test_postflight_links_all_four_actual_remote_exits_and_helper_pids(environment):
    paired_captures(environment)
    environment.reply["pid_exists"].update(
        {str(pid): False for pid in range(3001, 3005)}
    )
    assert state.record("postflight", ROOT) == 0
    result = json.loads(artifact(environment, "postflight").read_text())
    assert result["inspected_pids"] == environment.pids + list(range(3001, 3005))
    assert list(result["capture_receipts"]) == list(state.CAPTURES)
    assert [row["helper_pid"] for row in result["capture_receipts"].values()] == list(
        range(3001, 3005)
    )


@pytest.mark.parametrize("target", ("", ".stdout", ".stderr"))
@pytest.mark.parametrize("symlink", (False, True))
def test_exclusive_targets_refuse_existing_or_symlink(environment, target, symlink):
    path = environment.path / (artifact(environment).name + target)
    sentinel = environment.path / "untouched"
    sentinel.write_text("preserve")
    if symlink:
        path.symlink_to(sentinel)
    else:
        path.write_text("preserve")
    with pytest.raises(ValueError, match="Exclusive"):
        state.record("preflight", ROOT)
    assert environment.calls == [] and sentinel.read_text() == "preserve"
    assert path.read_text() == "preserve"


@pytest.mark.parametrize(
    "root", ("/tmp", ROOT + "/", "/tmp/blinka-pwm-lgpio-consumers.X", "")
)
def test_root_refused_before_ssh(environment, root):
    with pytest.raises(ValueError, match="root"):
        state.record("preflight", root)
    assert environment.calls == []


@pytest.mark.parametrize("which", ("plan", "prior", "inventory", "prior-pids"))
def test_frozen_inputs_gate_before_ssh(environment, monkeypatch, which):
    if which == "plan":
        monkeypatch.setattr(state, "PLAN_SHA256", "b" * 64)
    elif which == "prior":
        monkeypatch.setattr(state, "PRIOR_SHA256", "b" * 64)
    elif which == "inventory":
        manifest = copy.deepcopy(environment.manifests["native"])
        manifest["source_sha256"].pop("0")
        save(environment.path / "oct7-native-consumers-manifest.json", manifest)
    else:
        monkeypatch.setattr(
            state,
            "PRIOR_SHA256",
            save(
                environment.path / "oct7-native-consumers-loaded-postflight.json",
                {
                    "accepted": True,
                    "ssh_returncode": 0,
                    "inspected_pids": environment.pids[:-1],
                },
            ),
        )
    with pytest.raises(ValueError):
        state.record("preflight", ROOT)
    assert environment.calls == []


@pytest.mark.parametrize(
    "field,value",
    (("collection_success", False), ("remote_returncode", False), ("remote", {})),
)
def test_postflight_failure_cannot_be_absence_accepted(environment, field, value):
    paired_captures(environment)
    path = environment.path / state.CAPTURES[0] / "results.json"
    result = json.loads(path.read_text())
    result[field] = value
    save(path, result)
    with pytest.raises(ValueError, match="linkage"):
        state.record("postflight", ROOT)
    assert environment.calls == []


@pytest.mark.parametrize(
    "location,key,value",
    (
        ((), "read_only", False),
        ((), "boot_id", "changed"),
        ((), "selected_source_sha256", {}),
        ((), "program_paths", {}),
        (("runtime",), "python_executable", "/usr/bin/python"),
        (("runtime",), "gpiod_version", "2.4.0"),
        (("runtime",), "lgpio_version", "different"),
        (("runtime",), "motor_version", "3.6.0"),
        (("pid_exists",), "2001", True),
        (("lines", 0), "used", True),
        (("lines", 1), "consumer", "someone"),
        (("pinctrl", 0), "stdout", "18: op -- | hi\n"),
        (("pinctrl", 1), "returncode", False),
        ((), "temperature_millic", "65000"),
        (("throttled",), "stdout", "throttled=0x50000\n"),
        (
            ("pwm",),
            "stdout",
            "0: platform/1f00098000.pwm, 2 PWM devices\n requested cooling_fan\n",
        ),
        (
            ("pwm",),
            "stdout",
            "0: platform/1f0009c000.pwm, 1 PWM device\n requested unknown\n cooling_fan\n",
        ),
    ),
)
def test_bad_state_keeps_remote_and_diagnostic_evidence(
    environment, location, key, value
):
    row = environment.reply
    for part in location:
        row = row[part]
    row[key] = value
    assert state.record("preflight", ROOT) == 1
    result = json.loads(artifact(environment).read_text())
    assert result["accepted"] is False and result["ssh_returncode"] == 0
    assert result["remote"] == environment.reply and result["validation_error"]
    assert (
        artifact(environment)
        .with_suffix(".json.stderr")
        .read_bytes()
        .startswith(b"retained diagnostic")
    )


@pytest.mark.parametrize("failure", (17, False, "timeout", "json"))
def test_actual_ssh_failures_are_preserved_not_fabricated(
    environment, monkeypatch, failure
):
    def run(command, *, stdout, stderr, **kwargs):
        stdout.write(b"partial evidence" if failure in ("timeout", "json") else b"{}")
        stderr.write(b"nonempty failure evidence")
        if failure == "timeout":
            raise subprocess.TimeoutExpired(command, 20)
        return SimpleNamespace(returncode=0 if failure == "json" else failure)

    monkeypatch.setattr(state, "subprocess", SimpleNamespace(run=run))
    assert state.record("preflight", ROOT) == 1
    result = json.loads(artifact(environment).read_text())
    expected = None if failure == "timeout" else (0 if failure == "json" else failure)
    assert result["ssh_returncode"] is expected or result["ssh_returncode"] == expected
    assert result["accepted"] is False and result["validation_error"]
    assert (
        artifact(environment).with_suffix(".json.stderr").read_bytes()
        == b"nonempty failure evidence"
    )


def test_remote_template_reused_with_read_only_queries_and_both_pinned_programs():
    code = state.remote_code(ROOT, [1234, 5678])
    compile(code, "readonly-generated", "exec")
    assert state.REMOTE.split("pids =")[0] in code
    assert "pids = json.loads('[1234, 5678]')" in code
    for command in (
        '["vcgencmd", "get_throttled"]',
        '["pinctrl", "get", str(offset)]',
        '["sudo", "-n", "cat", "/sys/kernel/debug/pwm"]',
    ):
        assert command in code
    assert ".request_lines(" not in code and ".set_value(" not in code
    assert "lgpio_pwm_consumers_eval" in code and state.NATIVE_ROOT in code


def test_cli_fixed_stage_and_root(monkeypatch):
    calls = []
    monkeypatch.setattr(
        state, "record", lambda stage, root: calls.append((stage, root)) or 0
    )
    assert state.main(["postflight", "--remote-root", ROOT]) == 0
    assert calls == [("postflight", ROOT)]
