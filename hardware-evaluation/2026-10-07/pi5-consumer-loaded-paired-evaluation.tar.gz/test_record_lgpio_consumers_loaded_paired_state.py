"""Focused fully offline loaded-state fakes; only new-module facades change."""

import copy
import hashlib
import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest
import record_lgpio_consumers_loaded_paired_state as state
import test_analyze_kernel_pwm_cpu_load as load_fakes


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value) + "\n")
    return state.digest(path)


@pytest.fixture
def environment(tmp_path, monkeypatch):
    monkeypatch.setattr(state, "LAB", tmp_path)
    manifests = {
        key: {"source_sha256": {str(index): "a" * 64 for index in range(count)}}
        for key, count in (("original", 21), ("native", 18))
    }
    coordinators = {}
    for key, real in state.COORDINATORS.items():
        consumer = SimpleNamespace(
            __file__=real.consumer.__file__,
            MODE=real.consumer.MODE,
            BACKEND=real.consumer.BACKEND,
            helper=real.consumer.helper,
            validate_local_manifest=MagicMock(),
        )
        coordinators[key] = SimpleNamespace(
            __file__=real.__file__,
            consumer=consumer,
            source_hashes=MagicMock(return_value={"frozen": "a" * 64}),
            audit=MagicMock(),
        )
    monkeypatch.setattr(state, "COORDINATORS", coordinators)
    for key, manifest in manifests.items():
        save(
            tmp_path
            / f"oct7-{'lgpio' if key == 'original' else key}-consumers-manifest.json",
            manifest,
        )
    prior_pids = list(range(1001, 1105))
    prior = {
        "accepted": True,
        "ssh_returncode": 0,
        "inspected_pids": prior_pids,
        "remote_root": state.ROOT,
        "native_root": state.paired.NATIVE_ROOT,
    }
    monkeypatch.setattr(state, "PRIOR_SHA256", save(tmp_path / state.PRIOR_NAME, prior))
    plan = {
        "remote_root": state.ROOT,
        "remote_python": state.paired.REMOTE_PYTHON,
        "bench_root": state.BENCH,
        "capture_order": list(state.CAPTURES),
        "native_reference": {"remote_root": state.paired.NATIVE_ROOT},
        "prior_postflight_sha256": state.PRIOR_SHA256,
        "state_recorder_sha256": state.digest(state.__file__),
        "loaded_coordinators_sha256": {
            key: state.digest(module.__file__) for key, module in coordinators.items()
        },
        "load_source_sha256": state.load_audit.LOAD_SOURCE_SHA256,
        "worker_source_sha256": state.load_audit.WORKER_SOURCE_SHA256,
    }
    path = tmp_path / "loaded-plan.json"
    save(path, plan)
    reply = {
        "read_only": True,
        "no_gpio_request_or_write": True,
        "hostname": "test-pi5",
        "kernel": state.paired.original.helper.baseline.KERNEL,
        "boot_id": state.paired.BOOT_ID,
        "boot_config_sha256": state.paired.BOOT_SHA,
        "remote_manifests": manifests,
        "selected_source_sha256": {
            key: value["source_sha256"] for key, value in manifests.items()
        },
        "program_paths": {
            "original": state.ROOT + "/lgpio_pwm_consumers_eval.py",
            "native": state.paired.NATIVE_ROOT + "/native_pwm_consumers_eval.py",
        },
        "runtime": {
            "python_executable": state.paired.REMOTE_PYTHON,
            "python_version": "fake3.13.5",
            "gpiod_version": "2.5.0",
            "lgpio_version": "lgpio.py_0.2.2.0",
            "motor_version": "3.5.0",
        },
        "pid_exists": {str(pid): False for pid in prior_pids},
        "gpiochip": {"name": "gpiochip0", "label": "pinctrl-rp1", "num_lines": 54},
        "lines": [
            {"offset": gpio, "used": False, "consumer": None} for gpio in (18, 23)
        ],
        "pinctrl": [
            {
                "arguments": ["pinctrl", "get", str(gpio)],
                "returncode": 0,
                "stdout": f"{gpio}: op -- | lo\n",
            }
            for gpio in (18, 23)
        ],
        "temperature_millic": "48000",
        "throttled": {"returncode": 0, "stdout": "throttled=0x0\n"},
        "pwm": {
            "returncode": 0,
            "stdout": "0: platform/1f0009c000.pwm, 1 PWM device\n pwm-0 (cooling_fan): requested enabled\n",
        },
        "load_program_path": state.BENCH + "/cpu-load-eval/kernel_pwm_cpu_load_eval.py",
        "load_source_sha256": state.load_audit.LOAD_SOURCE_SHA256,
        "worker_source_sha256": state.load_audit.WORKER_SOURCE_SHA256,
    }
    calls = []

    def run(command, *, stdout, stderr, timeout, check):
        calls.append(command)
        executable, option, code = shlex.split(command[-1])
        assert (executable, option) == (state.paired.REMOTE_PYTHON, "-c")
        compile(code, "readonly-loaded-fake", "exec")
        assert (
            "PIDS" not in code
            and "request_lines(" not in code
            and "tx_pwm(" not in code
        )
        assert timeout == 20 and check is False
        stdout.write(json.dumps(reply).encode())
        stderr.write(b"retained read-only diagnostic\n")
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(state, "subprocess", SimpleNamespace(run=run))
    return SimpleNamespace(
        path=tmp_path,
        plan_path=path,
        plan=plan,
        manifests=manifests,
        pids=prior_pids,
        reply=reply,
        coordinators=coordinators,
        calls=calls,
        run=run,
    )


def loaded_captures(environment):
    overlaps = {}
    for index, name in enumerate(state.CAPTURES):
        key = "original" if "-lgpio-" in name else "native"
        root = state.ROOT if key == "original" else state.paired.NATIVE_ROOT
        coordinator = environment.coordinators[key]
        helper, launcher, first, second = range(2001 + 4 * index, 2005 + 4 * index)
        launch, completion, _ = load_fakes.documents()
        for receipt in (launch, completion):
            receipt["launcher_pid"] = launcher
            for worker, pid in zip(
                receipt["owned_workers"], (first, second), strict=True
            ):
                worker["pid"] = pid
                for report in worker["worker_receipts"]:
                    report["pid"] = pid
                if worker["worker_receipts"]:
                    load_fakes.sync_stdout(worker)
        remote = {"helper_pid": helper, "python_executable": state.paired.REMOTE_PYTHON}
        save(environment.path / name / "remote.stdout", remote)
        program = root + "/" + coordinator.consumer.helper.NEW_SOURCE
        command = [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
            shlex.join(
                [
                    state.paired.REMOTE_PYTHON,
                    program,
                    "--manifest",
                    root + "/manifest.json",
                ]
            ),
        ]
        save(environment.path / name / "acquisition.json", {"remote_command": command})
        load_path = environment.path / (name + ".load.stdout")
        load_path.write_text(json.dumps(launch) + "\n" + json.dumps(completion) + "\n")
        overlap = {
            "accepted": True,
            "workers": state.load_audit.validate_load(launch, completion),
        }
        overlaps[str(environment.path / name)] = overlap
        manifest_path = (
            environment.path
            / f"oct7-{'lgpio' if key == 'original' else key}-consumers-manifest.json"
        )
        coordination = {
            "schema_version": 1,
            "stem": name,
            "mode": coordinator.consumer.MODE,
            "backend": coordinator.consumer.BACKEND,
            "bench_root": state.BENCH,
            "consumer_root": root,
            "remote_python": state.paired.REMOTE_PYTHON,
            "manifest_path": str(manifest_path.resolve()),
            "manifest_sha256": state.digest(manifest_path),
            "consumer_source_manifest": environment.manifests[key],
            "source_sha256": coordinator.source_hashes(),
            "coordination_success": True,
            "launch_validated": True,
            "launch_validation_errors": [],
            "collector_returned_normally": True,
            "collector_collection_success": True,
            "load_recorder_returned_normally": True,
            "capture_error": None,
            "capture_evidence_error": None,
            "load_recorder_error": None,
            "audit_error": None,
            "consumer_remote_returncode": 0,
            "load_helper_returncode": 0,
            "launch_receipt": launch,
            "persisted_launch_sha256": hashlib.sha256(
                load_path.read_bytes().splitlines(keepends=True)[0]
            ).hexdigest(),
            "overlap": overlap,
            "collector_invocation": "in-process frozen "
            + Path(coordinator.consumer.__file__).stem
            + ".capture_test",
        }
        save(environment.path / (name + ".consumers-coordination.json"), coordination)
        environment.reply["pid_exists"].update(
            {str(pid): False for pid in (helper, launcher, first, second)}
        )
    for module in environment.coordinators.values():
        module.audit.side_effect = lambda stem, root, python, manifest: copy.deepcopy(
            overlaps[stem]
        )


def output(environment, stage="preflight"):
    return environment.path / f"oct7-lgpio-consumers-loaded-paired-{stage}.json"


def test_preflight_reuses_state_gates_and_exact_104_prior_pids(environment):
    assert state.record("preflight", environment.plan_path) == 0
    receipt = json.loads(output(environment).read_text())
    assert receipt["accepted"] and receipt["ssh_returncode"] == 0
    assert (
        receipt["inspected_pids"] == environment.pids
        and not receipt["capture_receipts"]
    )
    assert len(environment.calls) == 1
    assert (
        Path(str(output(environment)) + ".stderr")
        .read_bytes()
        .endswith(b"diagnostic\n")
    )


def test_postflight_adds_all_16_actual_helper_launcher_worker_pids(environment):
    loaded_captures(environment)
    assert state.record("postflight", environment.plan_path) == 0
    receipt = json.loads(output(environment, "postflight").read_text())
    assert len(receipt["inspected_pids"]) == 120
    assert receipt["inspected_pids"] == environment.pids + list(range(2001, 2017))
    assert list(receipt["capture_receipts"]) == list(state.CAPTURES)
    assert all(
        module.audit.call_count == 2 for module in environment.coordinators.values()
    )


@pytest.mark.parametrize(
    "field,value",
    [
        ("consumer_remote_returncode", False),
        ("load_helper_returncode", None),
        ("coordination_success", False),
        ("source_sha256", {}),
        ("consumer_source_manifest", {}),
        ("remote_python", "/usr/bin/python"),
        ("persisted_launch_sha256", "b" * 64),
    ],
)
def test_postflight_rejects_coordination_exit_source_and_runtime_mismatches(
    environment, field, value
):
    loaded_captures(environment)
    path = environment.path / (state.CAPTURES[0] + ".consumers-coordination.json")
    receipt = json.loads(path.read_text())
    receipt[field] = value
    save(path, receipt)
    with pytest.raises(ValueError):
        state.record("postflight", environment.plan_path)
    assert not environment.calls


def test_unvalidated_actual_worker_raw_receipts_are_rejected(environment):
    loaded_captures(environment)
    path = environment.path / (state.CAPTURES[0] + ".load.stdout")
    launch, completion = state.load_audit.parse_lines(path.read_text(), 2, "fake")
    completion["owned_workers"][0]["stdout"] = "{}\n{}\n"
    path.write_text(json.dumps(launch) + "\n" + json.dumps(completion) + "\n")
    with pytest.raises(ValueError):
        state.record("postflight", environment.plan_path)
    assert not environment.calls


@pytest.mark.parametrize(
    "field,value",
    [
        ("load_source_sha256", "b" * 64),
        ("worker_source_sha256", "b" * 64),
        ("load_program_path", "/tmp/elsewhere.py"),
        ("boot_id", "changed"),
    ],
)
def test_remote_source_and_reused_state_failures_are_persisted(
    environment, field, value
):
    environment.reply[field] = value
    assert state.record("preflight", environment.plan_path) == 1
    receipt = json.loads(output(environment).read_text())
    assert (
        not receipt["accepted"] and receipt["ssh_returncode"] == 0 and receipt["remote"]
    )


@pytest.mark.parametrize("status", [False, None, 17])
def test_only_actual_typed_ssh_zero_is_accepted(environment, monkeypatch, status):
    monkeypatch.setattr(
        state,
        "subprocess",
        SimpleNamespace(run=lambda *args, **kwargs: SimpleNamespace(returncode=status)),
    )
    assert state.record("preflight", environment.plan_path) == 1
    receipt = json.loads(output(environment).read_text())
    assert receipt["ssh_returncode"] == (status if type(status) is int else None)
    assert not receipt["accepted"]


def test_timeout_preserves_partial_stdout_and_stderr(environment, monkeypatch):
    def timeout(command, *, stdout, stderr, **kwargs):
        stdout.write(b"partial")
        stderr.write(b"partial diagnostic")
        raise subprocess.TimeoutExpired(command, 20)

    monkeypatch.setattr(state, "subprocess", SimpleNamespace(run=timeout))
    assert state.record("preflight", environment.plan_path) == 1
    assert json.loads(output(environment).read_text())["ssh_returncode"] is None
    assert Path(str(output(environment)) + ".stdout").read_bytes() == b"partial"
    assert (
        Path(str(output(environment)) + ".stderr").read_bytes() == b"partial diagnostic"
    )


@pytest.mark.parametrize("suffix", ["", ".stdout", ".stderr"])
@pytest.mark.parametrize("symlink", [False, True])
def test_exclusive_state_outputs_preserve_existing_files(environment, suffix, symlink):
    target = Path(str(output(environment)) + suffix)
    sentinel = environment.path / "preserve"
    sentinel.write_text("old")
    if symlink:
        target.symlink_to(sentinel)
    else:
        target.write_text("old")
    with pytest.raises(ValueError, match="Exclusive"):
        state.record("preflight", environment.plan_path)
    assert not environment.calls and target.read_text() == sentinel.read_text() == "old"


def test_plan_contract_gates_all_remote_access(environment):
    environment.plan["capture_order"].reverse()
    save(environment.plan_path, environment.plan)
    with pytest.raises(ValueError, match="Frozen loaded paired plan"):
        state.record("preflight", environment.plan_path)
    assert not environment.calls


def test_pinned_prior_bytes_gate_all_remote_access(environment):
    path = environment.path / state.PRIOR_NAME
    path.write_text(path.read_text() + " ")
    with pytest.raises(ValueError, match="prior bytes changed"):
        state.record("preflight", environment.plan_path)
    assert not environment.calls


def test_loaded_pid_reuse_cannot_shrink_the_exact_120_pid_set(environment):
    loaded_captures(environment)
    path = environment.path / state.CAPTURES[0] / "remote.stdout"
    receipt = json.loads(path.read_text())
    receipt["helper_pid"] = environment.pids[0]
    save(path, receipt)
    with pytest.raises(ValueError, match="distinct from prior"):
        state.record("postflight", environment.plan_path)
    assert not environment.calls
