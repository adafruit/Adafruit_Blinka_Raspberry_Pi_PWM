"""Evaluation-only Pi 5 kernel PWM bench; never removes providers or overlays.

Run as a standalone script on the authorized, already configured bench Pi:
    python3 kernel_pwm_eval.py --mode endpoints|idle|loaded

Only newly exported GPIO18 RP1 PWM channel 2 and GPIO23 pwm-gpio channel 0
are touched. A successful run emits one JSON object after complete cleanup.
The runtime uses only the Python standard library, not Saleae or GPIO libraries.
"""

import argparse
import json
import os
import platform
import signal
import struct
import subprocess
import sys
import time
from contextlib import contextmanager, nullcontext
from dataclasses import dataclass
from pathlib import Path

SYSFS_PWM = Path("/sys/class/pwm")
DEVICE_TREE = Path("/sys/firmware/devicetree/base")
SPECS = ((18, 50, 4915), (23, 500, 32768))
LOW_SETTLE_SECONDS = 0.1
EXPORT_READY_SECONDS = 2.0
MAX_RUN_SECONDS = 30
BURNER_SECONDS = 25


class BenchError(RuntimeError):
    pass


class SafetyAbort(BenchError):
    pass


def strings(path):
    return path.read_bytes().rstrip(b"\0").decode("ascii").split("\0")


def cells(path):
    data = path.read_bytes()
    if not data or len(data) % 4:
        raise BenchError(f"Malformed big-endian OF property: {path}")
    return struct.unpack(">" + "I" * (len(data) // 4), data)


@dataclass(frozen=True)
class Provider:
    gpio: int
    chip: Path
    of_node: Path
    channel: int
    compatible: tuple
    gpio_of_node: str = ""

    @property
    def channel_path(self):
        return self.chip / f"pwm{self.channel}"

    def identity(self):
        return {
            "gpio": self.gpio,
            "chip": str(self.chip),
            "of_node": str(self.of_node),
            "channel": self.channel,
            "compatible": list(self.compatible),
            "gpio_of_node": self.gpio_of_node or None,
        }


def discover(sysfs_pwm=SYSFS_PWM, device_tree=DEVICE_TREE):
    """Discover by OF identity, never by unstable pwmchip numbering."""
    model = strings(device_tree / "model")[0]
    if not model.startswith("Raspberry Pi 5 Model B Rev "):
        raise BenchError(f"Only Raspberry Pi 5 Model B is authorized, got {model!r}")
    rp1_gpios = {}
    for compatible_path in device_tree.rglob("compatible"):
        compatible = strings(compatible_path)
        if "raspberrypi,rp1-gpio" not in compatible:
            continue
        node = compatible_path.parent
        gpio_cells = cells(node / "#gpio-cells")
        if gpio_cells != (2,):
            raise BenchError(f"Unexpected RP1 GPIO cell count at {node}")
        handles = set()
        for name in ("phandle", "linux,phandle"):
            prop = node / name
            if prop.exists():
                values = cells(prop)
                if len(values) != 1 or values[0] == 0:
                    raise BenchError(f"Invalid RP1 GPIO phandle at {node}")
                handles.add(values[0])
        if len(handles) != 1:
            raise BenchError(f"Missing or inconsistent RP1 GPIO phandle at {node}")
        handle = handles.pop()
        if handle in rp1_gpios:
            raise BenchError("Duplicate RP1 GPIO phandle")
        rp1_gpios[handle] = node
    if len(rp1_gpios) != 1:
        raise BenchError("Cannot identify exactly one RP1 GPIO provider")

    candidates = {18: [], 23: []}
    for chip in sorted(sysfs_pwm.glob("pwmchip*")):
        node_link = chip / "device" / "of_node"
        if not node_link.exists():
            continue
        node = node_link.resolve(strict=True)
        try:
            node.relative_to(device_tree.resolve(strict=True))
        except ValueError as exc:
            raise BenchError(
                f"OF node is outside the live device tree: {node}"
            ) from exc
        compatible = tuple(strings(node / "compatible"))
        npwm = int((chip / "npwm").read_text().strip())
        if "raspberrypi,rp1-pwm" in compatible and node.name == "pwm@98000":
            if node.parent != next(iter(rp1_gpios.values())).parent:
                raise BenchError(
                    "Header PWM and GPIO providers are not on the same RP1"
                )
            if npwm != 4:
                raise BenchError(f"Unexpected RP1 header PWM channel count: {npwm}")
            candidates[18].append(Provider(18, chip, node, 2, compatible))
        elif "pwm-gpio" in compatible:
            gpios = cells(node / "gpios")
            if len(gpios) != 3:
                raise BenchError(f"Unexpected pwm-gpio OF GPIO specifier at {node}")
            handle, pin, flags = gpios
            if pin != 23:
                continue
            if handle not in rp1_gpios or flags != 0 or npwm != 1:
                raise BenchError(
                    "GPIO23 PWM must use RP1 GPIO23, normal polarity, one channel"
                )
            candidates[23].append(
                Provider(23, chip, node, 0, compatible, str(rp1_gpios[handle]))
            )
        # The fan pwm@9c000 and PIO/other providers are never selected.
    providers = []
    for gpio in (18, 23):
        if len(candidates[gpio]) != 1:
            raise BenchError(f"GPIO{gpio}: require exactly one approved PWM provider")
        provider = candidates[gpio][0]
        if provider.channel_path.exists():
            raise BenchError(
                f"Refusing existing exported channel: {provider.channel_path}"
            )
        providers.append(provider)
    return model, providers


class SafetySignals:
    """Raise once in normal operation; defer further signals during cleanup."""

    def __init__(self):
        self.depth = 0
        self.received = []
        self.previous = {}

    def handler(self, signum, _frame):
        self.received.append(signum)
        if self.depth == 0:
            raise SafetyAbort(f"Stopped by {signal.Signals(signum).name}")

    @contextmanager
    def atomic(self):
        # Export success and its ownership latch must be indivisible to handlers.
        self.depth += 1
        completed = False
        count = len(self.received)
        try:
            yield
            completed = True
        finally:
            self.depth -= 1
            if completed and self.depth == 0 and len(self.received) != count:
                raise SafetyAbort("Signal received during PWM ownership transition")

    @contextmanager
    def cleanup(self):
        self.depth += 1
        try:
            yield
        finally:
            self.depth -= 1

    def __enter__(self):
        for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGALRM):
            self.previous[signum] = signal.signal(signum, self.handler)
        return self

    def __exit__(self, *_exc):
        signal.alarm(0)
        for signum, handler in self.previous.items():
            signal.signal(signum, handler)


class SysfsIO:
    def write(self, path, value):
        path.write_text(str(value) + "\n", encoding="ascii")

    def read(self, path):
        return path.read_text(encoding="ascii").strip()


class PWMChannel:
    """Own only an export that this instance successfully created."""

    def __init__(
        self, provider, frequency, duty_u16, *, io=None, guard=None, cleanup_errors=None
    ):
        self.provider = provider
        self.period_ns = round(1_000_000_000 / frequency)
        self.frequency = frequency
        self.duty_u16 = duty_u16
        self.active_duty_ns = self.period_ns * duty_u16 // 65535
        self.io = io or SysfsIO()
        self.guard = guard
        self.cleanup_errors = cleanup_errors if cleanup_errors is not None else []
        self.owned = False
        self.events = []
        self.released = False
        if frequency <= 0 or self.period_ns <= 0 or not 0 < duty_u16 < 65535:
            raise BenchError("Positive frequency and interior PWM duty are required")
        if self.path.exists():
            raise BenchError(f"Refusing existing exported channel: {self.path}")
        try:
            with self.guard.atomic() if self.guard else nullcontext():
                # EBUSY is a conflict, never a reason to borrow an existing export.
                self.io.write(self.provider.chip / "export", self.provider.channel)
                self.owned = True
            deadline = time.monotonic() + EXPORT_READY_SECONDS
            attributes = [
                self.path / name
                for name in ("enable", "polarity", "period", "duty_cycle")
            ]
            # Sysfs creation can precede asynchronous udev group/permission rules.
            while not all(
                path.exists() and os.access(path, os.R_OK | os.W_OK)
                for path in attributes
            ):
                if time.monotonic() >= deadline:
                    raise BenchError(
                        f"Export attributes not readable/writable: {self.path}"
                    )
                time.sleep(0.01)
            self._write("enable", 0)
            self._write("polarity", "normal")
            self._write("period", self.period_ns)
            self._write("duty_cycle", 0)
            self._write("enable", 1)
            time.sleep(LOW_SETTLE_SECONDS)
            self.readback(expected_duty=0, expected_enable=1)
        except BaseException:
            # Keep the primary exception intact; cleanup failures latch separately.
            self.close()
            raise

    @property
    def path(self):
        return self.provider.channel_path

    def _write(self, attribute, value):
        begin = time.monotonic_ns()
        self.io.write(self.path / attribute, value)
        self.events.append(
            {
                "attribute": attribute,
                "value": value,
                "begin_ns": begin,
                "end_ns": time.monotonic_ns(),
            }
        )

    def readback(self, expected_duty=None, expected_enable=None):
        state = {
            name: self.io.read(self.path / name)
            for name in ("period", "duty_cycle", "polarity", "enable")
        }
        for name in ("period", "duty_cycle", "enable"):
            state[name] = int(state[name])
        if state["polarity"] != "normal" or state["period"] != self.period_ns:
            raise BenchError(
                f"Unexpected GPIO{self.provider.gpio} sysfs readback: {state}"
            )
        if expected_duty is not None and state["duty_cycle"] != expected_duty:
            raise BenchError(
                f"GPIO{self.provider.gpio} duty readback mismatch: {state}"
            )
        if expected_enable is not None and state["enable"] != expected_enable:
            raise BenchError(
                f"GPIO{self.provider.gpio} enable readback mismatch: {state}"
            )
        return state

    def set_duty(self, duty_ns):
        if not self.owned or not 0 <= duty_ns <= self.period_ns:
            raise BenchError("Invalid duty or missing ownership")
        self._write("duty_cycle", duty_ns)

    def close(self):
        if not self.owned:
            return
        with self.guard.cleanup() if self.guard else nullcontext():
            operations = (
                ("low", lambda: self._write("duty_cycle", 0)),
                ("low settle", lambda: time.sleep(LOW_SETTLE_SECONDS)),
                ("disable", lambda: self._write("enable", 0)),
                (
                    "unexport",
                    lambda: self.io.write(
                        self.provider.chip / "unexport", self.provider.channel
                    ),
                ),
            )
            for name, operation in operations:
                try:
                    operation()
                except BaseException as exc:  # noqa: BLE001 -- finish every cleanup step
                    self.cleanup_errors.append(
                        f"GPIO{self.provider.gpio} {name}: {type(exc).__name__}: {exc}"
                    )
            if self.path.exists():
                self.cleanup_errors.append(f"GPIO{self.provider.gpio} remains exported")
            else:
                self.owned = False
                self.released = True


def thermal_issues(snapshot, maximum_millic):
    """Same conservative bench gate as capture_pwm, without importing Saleae."""
    issues = []
    try:
        temperature = int(snapshot["temperature_millic"])
        if not 0 <= temperature <= maximum_millic:
            issues.append(f"Temperature {temperature / 1000:.1f} C exceeds bench limit")
    except (KeyError, TypeError, ValueError):
        issues.append("Temperature reading unavailable")
    try:
        flags = snapshot["throttled"]
        if not flags.startswith("throttled=0x"):
            raise ValueError("Malformed firmware flags")
        if int(flags.split("=", 1)[1], 16) != 0:
            issues.append(f"Firmware limiting flags are not clear: {flags}")
    except (KeyError, AttributeError, TypeError, ValueError):
        issues.append("Firmware limiting flags unavailable")
    return issues


def optional_read(path):
    try:
        return {"value": Path(path).read_text().strip(), "error": None}
    except OSError as exc:
        return {"value": None, "error": f"{type(exc).__name__}: {exc}"}


def optional_command(args):
    try:
        result = subprocess.run(
            args, capture_output=True, text=True, timeout=2, check=True
        )
        return {"value": result.stdout.strip(), "error": None}
    except (OSError, subprocess.SubprocessError) as exc:
        return {"value": None, "error": f"{type(exc).__name__}: {exc}"}


def system_snapshot():
    return {
        "temperature_millic": optional_read("/sys/class/thermal/thermal_zone0/temp")[
            "value"
        ],
        "throttled": optional_command(["vcgencmd", "get_throttled"])["value"],
        "cpu0_frequency_khz": optional_read(
            "/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq"
        )["value"],
        "arm_clock": optional_command(["vcgencmd", "measure_clock", "arm"]),
    }


def debug_metadata():
    clock = time.get_clock_info("monotonic")
    return {
        "kernel": platform.uname()._asdict(),
        "python": sys.version,
        "firmware_version": optional_command(["vcgencmd", "version"]),
        "monotonic_clock": {
            "implementation": clock.implementation,
            "resolution_seconds": clock.resolution,
            "monotonic": clock.monotonic,
            "adjustable": clock.adjustable,
        },
        "pwm_debug": optional_read("/sys/kernel/debug/pwm"),
        "clock_debug": optional_read("/sys/kernel/debug/clk/clk_summary"),
    }


def run_phase(channels, phases, name, duration, duties):
    transition_begin = time.monotonic_ns()
    for channel, duty in zip(channels, duties):
        channel.set_duty(duty)
    readbacks = {
        str(channel.provider.gpio): channel.readback(duty, 1)
        for channel, duty in zip(channels, duties)
    }
    stable_begin = time.monotonic_ns()
    time.sleep(duration)
    phases.append(
        {
            "name": name,
            "duration_seconds": duration,
            "duties": {
                str(channel.provider.gpio): round(duty * 65535 / channel.period_ns)
                for channel, duty in zip(channels, duties)
            },
            "duty_ns": {
                str(channel.provider.gpio): duty
                for channel, duty in zip(channels, duties)
            },
            "transition_begin_ns": transition_begin,
            "begin_ns": transition_begin,
            "stable_begin_ns": stable_begin,
            "end_ns": time.monotonic_ns(),
            "sysfs_readbacks": readbacks,
        }
    )


def start_burners(processes):
    # Each independent child expires even if the parent disappears. No GPIO or I/O.
    code = (
        "import time\n"
        f"deadline = time.monotonic() + {BURNER_SECONDS}\n"
        "while time.monotonic() < deadline:\n"
        "    sum(range(10000))\n"
    )
    for _ in range(4):
        processes.append(
            subprocess.Popen(
                [sys.executable, "-c", code],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        )


def stop_burners(processes, cleanup_errors):
    for process in processes:
        if process.poll() is None:
            try:
                process.terminate()
            except ProcessLookupError:
                pass
            except OSError as exc:
                cleanup_errors.append(f"Burner {process.pid} terminate: {exc}")
    for process in processes:
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:
                process.kill()
                process.wait(timeout=2)
            except (OSError, subprocess.SubprocessError) as exc:
                cleanup_errors.append(f"Burner {process.pid} kill/wait: {exc}")
        except OSError as exc:
            cleanup_errors.append(f"Burner {process.pid} wait: {exc}")


def experiment(mode):
    if mode not in ("endpoints", "idle", "loaded"):
        raise BenchError("Invalid experiment mode")
    model, providers = discover()
    metadata = debug_metadata()
    before = system_snapshot()
    issues = thermal_issues(before, 65000)
    if issues:
        raise BenchError(
            "Thermal preflight failed before PWM/load startup: " + "; ".join(issues)
        )
    channels, processes, phases, cleanup_errors = [], [], [], []
    primary = None
    primary_traceback = None
    after = None
    start = time.monotonic_ns()
    with SafetySignals() as guard:
        signal.alarm(MAX_RUN_SECONDS)
        try:
            for provider, (_, frequency, duty_u16) in zip(providers, SPECS):
                with guard.atomic():
                    channels.append(
                        PWMChannel(
                            provider,
                            frequency,
                            duty_u16,
                            guard=guard,
                            cleanup_errors=cleanup_errors,
                        )
                    )
            if mode == "endpoints":
                p18, p23 = [channel.period_ns for channel in channels]
                for name, duties in (
                    ("both_low_initial", (0, 0)),
                    ("gpio18_high", (p18, 0)),
                    ("both_low_after_gpio18", (0, 0)),
                    ("gpio23_high", (0, p23)),
                    ("both_low_after_gpio23", (0, 0)),
                    ("both_high", (p18, p23)),
                    ("both_low_final", (0, 0)),
                ):
                    run_phase(channels, phases, name, 0.2, duties)
            else:
                run_phase(channels, phases, "both_low_initial", 0.2, (0, 0))
                if mode == "loaded":
                    # Latch child ownership together with each successful Popen.
                    with guard.atomic():
                        start_burners(processes)
                    if any(process.poll() is not None for process in processes):
                        raise BenchError("CPU burner exited before active interval")
                run_phase(
                    channels,
                    phases,
                    "both_active",
                    3.0 if mode == "idle" else 20.0,
                    [channel.active_duty_ns for channel in channels],
                )
                if any(process.poll() is not None for process in processes):
                    raise BenchError("CPU burner exited during active interval")
                run_phase(channels, phases, "both_low_final", 0.2, (0, 0))
        except BaseException as exc:  # noqa: BLE001 -- defer re-raise until outputs stop
            primary = exc
            primary_traceback = exc.__traceback__
        finally:
            # No signal, including a second termination request, interrupts cleanup.
            with guard.cleanup():
                signal.alarm(0)
                # Set every owned output low before waiting on any individual one.
                for channel in channels:
                    if channel.owned:
                        try:
                            channel.set_duty(0)
                        except BaseException as exc:  # noqa: BLE001 -- keep cleaning others
                            cleanup_errors.append(
                                f"GPIO{channel.provider.gpio} final low: {exc}"
                            )
                for channel in channels:
                    channel.close()
                try:
                    stop_burners(processes, cleanup_errors)
                except BaseException as exc:  # noqa: BLE001 -- record cleanup failure
                    cleanup_errors.append(
                        f"CPU-load cleanup: {type(exc).__name__}: {exc}"
                    )
                try:
                    after = system_snapshot()
                except BaseException as exc:  # noqa: BLE001 -- report failed final snapshot
                    cleanup_errors.append(
                        f"Post-run snapshot: {type(exc).__name__}: {exc}"
                    )
        if guard.received and primary is None:
            primary = SafetyAbort("Termination signal received during cleanup")
    if cleanup_errors:
        # Preserve original exception while explicitly reporting every latched failure.
        print("Cleanup failures: " + "; ".join(cleanup_errors), file=sys.stderr)
        if primary is None:
            primary = BenchError("PWM or CPU-load cleanup failed")
    if primary is not None:
        raise primary.with_traceback(primary_traceback)
    issues = thermal_issues(after, 75000)
    if issues:
        raise BenchError("Post-run thermal gate failed: " + "; ".join(issues))
    if len(channels) != 2 or not all(channel.released for channel in channels):
        raise BenchError("Cannot confirm both fresh exports were released")
    return {
        "schema_version": 1,
        "mode": mode,
        "model": model,
        "begin_ns": start,
        "end_ns": time.monotonic_ns(),
        "phases": phases,
        "sysfs_released": True,
        "outputs": [
            {
                **channel.provider.identity(),
                "backend": "rp1-pwm" if channel.provider.gpio == 18 else "pwm-gpio",
                "frequency": channel.frequency,
                "duty_u16": channel.duty_u16,
                "period_ns": channel.period_ns,
                "active_duty_ns": channel.active_duty_ns,
                "sysfs_events": channel.events,
            }
            for channel in channels
        ],
        "burner_pids": [process.pid for process in processes],
        "burner_watchdog_seconds": BURNER_SECONDS,
        "hard_max_run_seconds": MAX_RUN_SECONDS,
        "thermal": {"before": before, "after": after},
        "cleanup_errors": cleanup_errors,
        "metadata": metadata,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mode", required=True, choices=("endpoints", "idle", "loaded")
    )
    args = parser.parse_args(argv)
    try:
        result = experiment(args.mode)
    except BaseException as exc:  # noqa: BLE001 -- failure always means no success JSON
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
