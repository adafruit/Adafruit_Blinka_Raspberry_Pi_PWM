"""Fake updates harness tests; public Python API, no native/GPIO/SSH activity."""

import hashlib
import signal
from pathlib import Path

import native_pwm_updates_eval as bench
import pytest
import test_native_pwm_half50_eval as old_fakes

ROOT = "/tmp/blinka-pwm-native-updates.abc123"
old_environment = old_fakes.environment


@pytest.fixture
def environment(old_environment, monkeypatch):
    state, guard, module, old_manifest, sleeps = old_environment
    original_engine = module.SoftwarePWM

    class Engine(original_engine):
        def configure(self, frequency, duty):
            assert state.claimed and frequency in (50, 500)
            state.log.append(("configure", frequency, duty))
            if state.hook:
                state.hook("configure")
            if state.fail == "configure":
                raise OSError("injected configure")
            state.level = int(duty != 0)

    monkeypatch.setattr(module, "SoftwarePWM", Engine)
    manifest = {
        "schema_version": 1,
        "source_sha256": {
            **old_manifest["source_sha256"],
            bench.NEW_SOURCE: hashlib.sha256(
                Path(bench.__file__).read_bytes()
            ).hexdigest(),
        },
    }
    monkeypatch.setattr(bench, "approved_manifest_path", lambda path: Path(path))
    monkeypatch.setattr(bench, "load_manifest", lambda _path: manifest)
    monkeypatch.setattr(bench, "source_hashes", lambda: dict(manifest["source_sha256"]))
    return state, guard, module, manifest, sleeps


@pytest.mark.parametrize("mode", bench.MODES)
def test_fixed_sequence_public_frequency_permission_and_exact_setter_order(
    environment, mode
):
    state, _guard, _module, manifest, sleeps = environment
    receipt = bench.experiment(mode, ROOT + "/manifest.json")
    assert receipt["success"] and receipt["source_sha256"] == manifest["source_sha256"]
    assert (
        receipt["mode"] == mode
        and receipt["sequence_marker"] == f"native-updates-{mode}-v1"
    )
    assert receipt["variable_frequency"] is (mode != "half50-direct")
    assert receipt["original_variable_frequency_default"] is False
    assert receipt["variable_frequency_differs_from_original"] is (
        mode != "half50-direct"
    )
    assert sleeps == [phase[1] for phase in bench.SEQUENCES[mode]] + [0.1]
    expected_configures, expected_events = [], []
    frequency, duty = 50, 0
    for name, duration, target_frequency, target_duty in bench.SEQUENCES[mode]:
        if target_frequency != frequency:
            frequency = target_frequency
            expected_configures.append(("configure", frequency, duty))
            expected_events.append(
                ("PWMOut.frequency", name, {"frequency": frequency, "duty_u16": duty})
            )
        if target_duty != duty:
            duty = target_duty
            expected_configures.append(("configure", frequency, duty))
            expected_events.append(
                ("PWMOut.duty_cycle", name, {"frequency": frequency, "duty_u16": duty})
            )
    expected_configures.append(("configure", frequency, 0))
    assert [row for row in state.log if row[0] == "configure"] == expected_configures
    assert [
        (e["operation"], e["scope"], e["arguments"])
        for e in receipt["events"]
        if e["operation"] in ("PWMOut.frequency", "PWMOut.duty_cycle")
    ] == expected_events
    assert [
        (p["name"], p["duration_seconds"], p["frequency"], p["duty_u16"])
        for p in receipt["phases"]
    ] == list(bench.SEQUENCES[mode])
    assert all(
        p["api_state"]
        == p["api_state_end"]
        == {"frequency": p["frequency"], "duty_cycle": p["duty_u16"]}
        for p in receipt["phases"]
    )
    assert receipt["runtime_flags"] == {"short_slice": False, "shared": False}
    assert receipt["cleanup_final_readback"] == {"gpio_level": 0, "inactive": True}
    assert (
        receipt["fresh_claim_accepted"]
        and receipt["gpio18_released"]
        and not state.claimed
    )
    assert receipt["cleanup_errors"] == [] and receipt["signals_received"] == []


@pytest.mark.parametrize("mode", ["direct", "frequency"])
def test_frequency_and_duty_transition_uses_old_duty_for_frequency_first(
    environment, mode
):
    receipt = bench.experiment(mode, ROOT + "/manifest.json")
    setters = [
        e
        for e in receipt["events"]
        if e["scope"] == ("recovery500_d32768" if mode == "direct" else "pwm500_d32768")
    ]
    assert [e["operation"] for e in setters] == [
        "PWMOut.frequency",
        "PWMOut.duty_cycle",
    ]
    assert [e["arguments"] for e in setters] == [
        {"frequency": 500, "duty_u16": 65535 if mode == "direct" else 4915},
        {"frequency": 500, "duty_u16": 32768},
    ]


@pytest.mark.parametrize(
    "problem", ["foreign", "construct", "source", "base_pin", "flag", "mode"]
)
def test_unsafe_preflight_or_failed_constructor_never_drives_foreign_line(
    environment, monkeypatch, problem
):
    state, _guard, _module, manifest, _sleeps = environment
    mode = "frequency"
    if problem == "foreign":
        state.foreign = True
    elif problem == "construct":
        state.fail = "construct"
    elif problem == "source":
        monkeypatch.setattr(
            bench,
            "source_hashes",
            lambda: {**manifest["source_sha256"], bench.NEW_SOURCE: "0" * 64},
        )
    elif problem == "base_pin":
        manifest["source_sha256"]["native_pwm_half50_eval.py"] = "0" * 64
    elif problem == "flag":
        monkeypatch.setenv("BLINKA_PWM_SHARED", "1")
    else:
        mode = "unsupported"
    receipt = bench.experiment(mode, ROOT + "/manifest.json")
    assert (
        not receipt["success"]
        and receipt["primary_error"]
        and not receipt["fresh_claim_accepted"]
    )
    assert not state.claimed
    assert not any(row[0] in ("configure", "stop", "release") for row in state.log)
    if problem == "construct":
        assert any(e["operation"] == "PWMOut.deinit" for e in receipt["events"])


@pytest.mark.parametrize("at", ["claim", "configure"])
def test_signal_preserves_private_ownership_cleanup(environment, at):
    state, guard, _module, _manifest, _sleeps = environment
    fired = False

    def hook(name):
        nonlocal fired
        if name == at and not fired:
            fired = True
            guard.handler(signal.SIGTERM, None)

    state.hook = hook
    receipt = bench.experiment("frequency", ROOT + "/manifest.json")
    assert not receipt["success"] and "SafetyAbort" in receipt["primary_error"]
    assert receipt["signals_received"] == [signal.SIGTERM]
    assert (
        receipt["fresh_claim_accepted"]
        and receipt["gpio18_released"]
        and not state.claimed
    )


def test_setter_primary_error_and_cleanup_error_are_independent(environment):
    state, *_rest = environment
    state.fail = "configure"
    receipt = bench.experiment("direct", ROOT + "/manifest.json")
    assert "injected configure" in receipt["primary_error"] and not receipt["success"]
    assert any("duty_cycle_zero" in error for error in receipt["cleanup_errors"])
    assert ("stop",) in state.log and ("release",) in state.log
    assert receipt["gpio18_released"] and not state.claimed


def test_deinit_error_does_not_skip_release_inspection(environment):
    state, *_rest = environment
    state.fail = "stop"
    receipt = bench.experiment("frequency", ROOT + "/manifest.json")
    assert not receipt["success"] and receipt["completed_normally"]
    assert receipt["primary_error"] is None and any(
        "PWMOut.deinit" in error for error in receipt["cleanup_errors"]
    )
    assert receipt["gpio18_released"] and not state.claimed
    assert len([row for row in state.log if row[0] == "claim"]) == 1


def test_immutable_base_hash_is_still_exact():
    assert (
        hashlib.sha256(Path(bench.base.__file__).read_bytes()).hexdigest()
        == bench.BASE_HELPER_SHA256
    )


@pytest.mark.parametrize(
    "path",
    [
        "manifest.json",
        "/tmp/manifest.json",
        ROOT + "/../manifest.json",
        old_fakes.ROOT + "/manifest.json",
    ],
)
def test_manifest_path_is_new_isolated_root_only(path):
    with pytest.raises(bench.core.BenchError, match="absolute"):
        bench.approved_manifest_path(path)
