"""Capture lab-only native GPIO18 updates; never accept waveform or parity.

Use only after source inspection and physical GPIO18/channel0 wiring confirmation.
Capture every raw edge with no pulse filters or analyzers. Failure stdout/stderr,
acquisition metadata, SAL and raw export are retained for offline analysis.
"""

import argparse
import hashlib
import json
import re
import shlex
import subprocess
import time
from pathlib import Path

import native_pwm_updates_eval as helper
from capture_native_pwm_half50 import DEVICE_ID, _write, read_json, require
from saleae import automation

BACKEND = helper.BACKEND
MODES = helper.MODES
SEQUENCES = helper.SEQUENCES
LOCAL_PACKAGE = (
    Path(__file__).resolve().parent.parent
    / "Adafruit_Blinka_Raspberry_Pi_PWM/src"
    / helper.base.PACKAGE
)
PHASE_KEYS = {
    "name",
    "generation",
    "frequency",
    "duty_u16",
    "duration_seconds",
    "intent",
    "begin_ns",
    "transition_begin_ns",
    "stable_begin_ns",
    "end_ns",
    "readback_end_ns",
    "api_state",
    "api_state_end",
}
CLEANUP_OPERATIONS = (
    "track_owned_request",
    "PWMOut.duty_cycle_zero",
    "low_settle",
    "owned_request.get_value",
    "PWMOut.deinit",
    "gpiod_line_info_released",
)


def validate_local_manifest(manifest):
    """Check local Python sources; never compare a Mac binary to the Pi binary."""
    hashes = helper.validate_manifest(manifest)
    package = helper.base.PACKAGE
    paths = {
        "native_pwm_updates_eval.py": Path(helper.__file__),
        "native_pwm_half50_eval.py": Path(helper.base.__file__),
        "kernel_pwm_lgpio_baseline_eval.py": Path(helper.base.baseline.__file__),
        "kernel_pwm_eval.py": Path(helper.core.__file__),
        package + "/__init__.py": LOCAL_PACKAGE / "__init__.py",
        package + "/_software.py": LOCAL_PACKAGE / "_software.py",
    }
    require(
        all(
            hashlib.sha256(path.read_bytes()).hexdigest() == hashes[name]
            for name, path in paths.items()
        ),
        "Manifest helper/core/installed Python sources must match local production sources",
    )
    return hashes


def _arguments_match(actual, expected):
    if expected is None:
        return actual is None
    return (
        isinstance(actual, dict)
        and set(actual) == set(expected)
        and all(
            type(actual[name]) is type(value) and actual[name] == value
            for name, value in expected.items()
        )
    )


def _validate_events(remote, mode):
    phases = remote["phases"]
    expected = [
        (
            "PWMOut.__init__",
            "initialization",
            {
                "gpiochip": remote["identity"]["gpiochip"],
                "gpio": 18,
                "frequency": 50,
                "duty_u16": 0,
                "variable_frequency": mode != "half50-direct",
            },
            remote["begin_ns"],
            phases[0]["begin_ns"],
        )
    ]
    previous_frequency, previous_duty = 50, 0
    for phase, (_name, _duration, frequency, duty) in zip(phases, SEQUENCES[mode]):
        interval = phase["begin_ns"], phase["stable_begin_ns"]
        if frequency != previous_frequency:
            expected.append(
                (
                    "PWMOut.frequency",
                    phase["name"],
                    {"frequency": frequency, "duty_u16": previous_duty},
                    *interval,
                )
            )
        if duty != previous_duty:
            expected.append(
                (
                    "PWMOut.duty_cycle",
                    phase["name"],
                    {"frequency": frequency, "duty_u16": duty},
                    *interval,
                )
            )
        previous_frequency, previous_duty = frequency, duty
    expected.extend(
        (
            operation,
            "safety_cleanup",
            None,
            phases[-1]["readback_end_ns"],
            remote["end_ns"],
        )
        for operation in CLEANUP_OPERATIONS
    )
    events = remote.get("events")
    require(
        isinstance(events, list) and len(events) == len(expected),
        "Exact native constructor/changed-setter/cleanup events required",
    )
    previous_end = remote["begin_ns"]
    for event, (operation, scope, arguments, lower, upper) in zip(events, expected):
        require(
            isinstance(event, dict)
            and set(event)
            == {"operation", "scope", "arguments", "begin_ns", "end_ns", "status"}
            and event.get("operation") == operation
            and event.get("scope") == scope
            and event.get("status") == "ok"
            and _arguments_match(event.get("arguments"), arguments)
            and type(event.get("begin_ns")) is int
            and type(event.get("end_ns")) is int
            and max(lower, previous_end)
            <= event["begin_ns"]
            <= event["end_ns"]
            <= upper,
            "Native caller event scope/order/arguments/interval mismatch: " + operation,
        )
        if operation == "low_settle":
            require(
                event["end_ns"] - event["begin_ns"] >= 100_000_000,
                "Native privately owned low-settle interval is too short",
            )
        previous_end = event["end_ns"]


def validate_remote(remote, mode, manifest):
    require(mode in MODES, "Unsupported native-updates mode")
    hashes = helper.validate_manifest(manifest)
    require(isinstance(remote, dict), "Native receipt must be an object")
    require(
        type(remote.get("schema_version")) is int
        and remote["schema_version"] == 1
        and remote.get("mode") == mode
        and remote.get("backend") == BACKEND
        and remote.get("sequence_marker") == f"native-updates-{mode}-v1"
        and type(remote.get("gpio")) is int
        and remote["gpio"] == 18,
        "Native schema/mode/backend/GPIO provenance mismatch",
    )
    require(
        remote.get("source_sha256") == hashes,
        "Exact manifest native/updates/helper/core source hashes required",
    )
    variable_frequency = mode != "half50-direct"
    require(
        all(
            remote.get(key) is True
            for key in (
                "characterization_only",
                "production_backend_unchanged",
                "api_readbacks_are_not_electrical",
            )
        )
        and "parity_pass" in remote
        and remote["parity_pass"] is None
        and remote.get("variable_frequency") is variable_frequency
        and remote.get("original_variable_frequency_default") is False
        and remote.get("variable_frequency_differs_from_original")
        is variable_frequency,
        "Native characterization/API difference must not claim parity/electrical readbacks",
    )
    flags, inherited = remote.get("runtime_flags"), remote.get("inherited_environment")
    require(
        isinstance(flags, dict)
        and set(flags) == {"short_slice", "shared"}
        and all(value is False for value in flags.values())
        and isinstance(inherited, dict)
        and set(inherited) == {"BLINKA_PWM_SHORT_SLICE", "BLINKA_PWM_SHARED"}
        and all(
            value is None or isinstance(value, str) and value != "1"
            for value in inherited.values()
        ),
        "Native shared/short-slice flags must be disabled, not inherited as 1",
    )
    require(
        all(
            remote.get(key) is True
            for key in (
                "success",
                "completed_normally",
                "fresh_claim_accepted",
                "gpio18_released",
                "read_only_chip_closed",
                "low_confirmed",
            )
        )
        and remote.get("cleanup_final_readback") == {"gpio_level": 0, "inactive": True}
        and type(remote["cleanup_final_readback"]["gpio_level"]) is int
        and remote["cleanup_final_readback"]["inactive"] is True
        and remote.get("cleanup_errors") == []
        and remote.get("signals_received") == []
        and "primary_error" in remote
        and remote["primary_error"] is None,
        "Native fresh ownership/low cleanup receipt failed",
    )
    require(
        type(remote.get("helper_pid")) is int
        and remote["helper_pid"] > 0
        and type(remote.get("begin_ns")) is int
        and type(remote.get("end_ns")) is int
        and 0 <= remote["begin_ns"] < remote["end_ns"]
        and remote["end_ns"] - remote["begin_ns"]
        < helper.MAX_RUN_SECONDS * 1_000_000_000
        and type(remote.get("watchdog_seconds")) is int
        and remote["watchdog_seconds"] == 14
        and remote.get("watchdog_cannot_bound_native_hang_or_sigkill") is True,
        "Invalid bounded native helper identity/run interval",
    )
    identity = remote.get("identity")
    require(
        isinstance(identity, dict)
        and type(identity.get("gpio")) is int
        and identity["gpio"] == 18
        and type(identity.get("gpiochip_index")) is int
        and identity["gpiochip_index"] >= 0
        and identity.get("gpiochip") == f"/dev/gpiochip{identity['gpiochip_index']}"
        and isinstance(identity.get("gpiochip_device_number"), str)
        and re.fullmatch(r"[0-9]+:[0-9]+", identity["gpiochip_device_number"])
        and identity.get("label") == "pinctrl-rp1"
        and identity.get("kernel_release") == helper.base.baseline.KERNEL
        and identity.get("compatible") == ["raspberrypi,rp1-gpio"]
        and isinstance(identity.get("model"), str)
        and identity["model"].startswith("Raspberry Pi 5 Model B Rev ")
        and isinstance(identity.get("boot_id"), str)
        and re.fullmatch(
            r"[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}", identity["boot_id"]
        ),
        "Expected approved Pi5 RP1 GPIO18 identity",
    )
    chip = remote.get("chip_info")
    require(
        isinstance(chip, dict)
        and chip.get("name") == Path(identity["gpiochip"]).name
        and chip.get("label") == "pinctrl-rp1"
        and type(chip.get("num_lines")) is int
        and chip["num_lines"] > 18,
        "Verified read-only gpiod v2 chip identity required",
    )
    for key in ("preclaim_line_info", "released_line_info"):
        line = remote.get(key)
        require(
            isinstance(line, dict)
            and type(line.get("offset")) is int
            and line["offset"] == 18
            and line.get("used") is False
            and line.get("consumer") in (None, ""),
            f"Native GPIO18 unclaimed {key} receipt required",
        )
    request = remote.get("owned_request")
    require(
        isinstance(request, dict)
        and request.get("chip_name") == chip["name"]
        and request.get("offsets") == [18]
        and type(request["offsets"][0]) is int,
        "Only this native output's private GPIO18 request is authorized",
    )
    require(
        isinstance(remote.get("manifest_path"), str)
        and re.fullmatch(
            helper.ROOT_PATTERN + r"/[A-Za-z0-9_-]+\.json", remote["manifest_path"]
        ),
        "Manifest must be absolute in the isolated native-updates root",
    )
    phases = remote.get("phases")
    require(
        isinstance(phases, list) and len(phases) == len(SEQUENCES[mode]),
        "Missing native fixed phases",
    )
    previous_end = remote["begin_ns"]
    for phase, (name, duration, frequency, duty) in zip(phases, SEQUENCES[mode]):
        require(
            isinstance(phase, dict)
            and set(phase) == PHASE_KEYS
            and phase.get("name") == name
            and type(phase.get("generation")) is int
            and phase["generation"] == 1
            and type(phase.get("frequency")) is int
            and phase["frequency"] == frequency
            and type(phase.get("duty_u16")) is int
            and phase["duty_u16"] == duty
            and type(phase.get("duration_seconds")) in (int, float)
            and phase["duration_seconds"] == duration
            and phase.get("intent")
            == (
                "low"
                if duty == 0
                else "constant_high"
                if duty == 65535
                else "interior_pwm"
            ),
            "Native fixed phase specification mismatch: " + name,
        )
        clocks = [
            phase.get(key)
            for key in (
                "begin_ns",
                "transition_begin_ns",
                "stable_begin_ns",
                "end_ns",
                "readback_end_ns",
            )
        ]
        require(
            all(type(value) is int for value in clocks)
            and previous_end
            <= clocks[0]
            == clocks[1]
            <= clocks[2]
            < clocks[3]
            <= clocks[4]
            <= remote["end_ns"]
            and clocks[3] - clocks[2] >= round(duration * 1_000_000_000),
            "Native phase interval/dwell mismatch: " + name,
        )
        previous_end = clocks[4]
        for key in ("api_state", "api_state_end"):
            state = phase.get(key)
            require(
                state == {"frequency": frequency, "duty_cycle": duty}
                and type(state["frequency"]) is int
                and type(state["duty_cycle"]) is int,
                "Native software-only API state mismatch: " + name,
            )
    _validate_events(remote, mode)
    for key, limit in (("before", 65000), ("after", 70000)):
        require(
            isinstance(remote.get(key), dict)
            and not helper.core.thermal_issues(remote[key], limit),
            "Native thermal/firmware gate failed: " + key,
        )


def capture_test(directory, remote_root, remote_python, mode, manifest_path):
    require(mode in MODES, "Unsupported native-updates mode")
    require(
        isinstance(remote_root, str) and re.fullmatch(helper.ROOT_PATTERN, remote_root),
        "Requires the isolated Pi5 native-updates root",
    )
    require(
        isinstance(remote_python, str)
        and (
            re.fullmatch(
                r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}/venv/bin/python", remote_python
            )
            or remote_python == remote_root + "/venv/bin/python"
        ),
        "Requires an explicit approved absolute venv Python",
    )
    manifest = helper.load_manifest(manifest_path)
    validate_local_manifest(manifest)
    output = Path(directory).resolve()
    require(
        re.fullmatch(r"[A-Za-z0-9_-]+", output.name),
        "Use a simple capture directory name",
    )
    output.mkdir(parents=True, exist_ok=False)
    _write(output, "manifest.json", json.dumps(manifest, indent=2) + "\n")
    command = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        "ConnectTimeout=8",
        "pi@test-pi5.local",
        shlex.join(
            [
                remote_python,
                remote_root + "/native_pwm_updates_eval.py",
                "--mode",
                mode,
                "--manifest",
                remote_root + "/manifest.json",
            ]
        ),
    ]
    remote, primary, logic_version = None, None, None
    evidence_errors, timing = [], {}
    try:
        with automation.Manager.connect(
            port=10430, connect_timeout_seconds=5
        ) as manager:
            if not any(
                device.device_id == DEVICE_ID and not device.is_simulation
                for device in manager.get_devices()
            ):
                raise RuntimeError("Confirmed physical Logic8 analyzer is unavailable")
            logic_version = manager.get_app_info().app_version
            config = automation.LogicDeviceConfiguration(
                enabled_digital_channels=[0], digital_sample_rate=100_000_000
            )
            with manager.start_capture(
                device_id=DEVICE_ID, device_configuration=config
            ) as capture:
                try:
                    timing["lead_begin_ns"] = time.monotonic_ns()
                    time.sleep(0.5)
                    timing["lead_end_ns"] = time.monotonic_ns()
                    with (
                        (output / "remote.stdout").open("x") as stdout_file,
                        (output / "remote.stderr").open("x") as stderr_file,
                    ):
                        remote = subprocess.run(
                            command,
                            stdout=stdout_file,
                            stderr=stderr_file,
                            text=True,
                            check=False,
                            timeout=30,
                        )
                except subprocess.TimeoutExpired as error:
                    primary, remote = error, subprocess.CompletedProcess(command, 124)
                except BaseException as error:
                    primary, remote = error, subprocess.CompletedProcess(command, None)
                finally:
                    for name in ("remote.stdout", "remote.stderr"):
                        try:
                            if not (output / name).exists():
                                _write(output, name, "")
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
                    for name, action in (
                        ("tail", lambda: time.sleep(0.2)),
                        ("stop", capture.stop),
                        (
                            "save_capture",
                            lambda: capture.save_capture(str(output / "waveform.sal")),
                        ),
                        (
                            "export_binary",
                            lambda: capture.export_raw_data_binary(
                                str(output), digital_channels=[0]
                            ),
                        ),
                    ):
                        try:
                            if name == "tail":
                                timing["tail_begin_ns"] = time.monotonic_ns()
                            action()
                            if name == "tail":
                                timing["tail_end_ns"] = time.monotonic_ns()
                        except BaseException as error:
                            evidence_errors.append(
                                f"{name}: {type(error).__name__}: {error}"
                            )
    except BaseException as error:
        if primary is None:
            primary = error
        else:
            evidence_errors.append(f"acquisition: {type(error).__name__}: {error}")
    acquisition = {
        "mode": mode,
        "backend": BACKEND,
        "remote_root": remote_root,
        "remote_python": remote_python,
        "remote_command": command,
        "remote_returncode": None if remote is None else remote.returncode,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "local_timing_ns": timing,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None
        if primary is None
        else f"{type(primary).__name__}: {primary}",
        "evidence_errors": evidence_errors,
    }
    _write(output, "acquisition.json", json.dumps(acquisition, indent=2) + "\n")
    result = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": mode,
        "backend": BACKEND,
        "sequence_marker": f"native-updates-{mode}-v1",
        "sample_rate_hz": 100_000_000,
        "logic_version": logic_version,
        "production_backend_unchanged": True,
        "outputs": [{"gpio": 18, "saleae_channel": 0, "backend": BACKEND}],
        "remote": None,
        "remote_returncode": acquisition["remote_returncode"],
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
        "analysis_deferred": True,
        "success_scope": "acquisition and helper schema/source/cleanup only; not waveform acceptance or parity",
    }
    try:
        if primary is not None or evidence_errors:
            raise RuntimeError(
                "Capture failure evidence retained: "
                + (acquisition["primary_error"] or "; ".join(evidence_errors))
            ) from primary
        require(
            remote is not None
            and type(remote.returncode) is int
            and remote.returncode == 0,
            "Native helper did not exit0; raw evidence retained",
        )
        require(
            all(
                (output / name).is_file() and (output / name).stat().st_size > 0
                for name in ("waveform.sal", "digital_0.bin")
            ),
            "Missing SAL/raw channel0 evidence",
        )
        result["remote"] = read_json((output / "remote.stdout").read_text())
        validate_remote(result["remote"], mode, manifest)
        require(
            result["remote"]["manifest_path"] == remote_root + "/manifest.json",
            "Remote manifest root does not match acquisition",
        )
        result["collection_success"] = True
    except BaseException as error:
        result["receipt_validation_error"] = f"{type(error).__name__}: {error}"
        raise
    finally:
        _write(output, "results.json", json.dumps(result, indent=2) + "\n")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--remote-root", required=True)
    parser.add_argument("--remote-python", required=True)
    parser.add_argument("--mode", choices=MODES, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    args = parser.parse_args(argv)
    result = capture_test(
        args.directory, args.remote_root, args.remote_python, args.mode, args.manifest
    )
    print(
        json.dumps(
            {
                "capture": args.directory.name,
                "mode": args.mode,
                "backend": BACKEND,
                "collection_success": result["collection_success"],
                "waveform_accepted": None,
                "parity_evaluated": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
