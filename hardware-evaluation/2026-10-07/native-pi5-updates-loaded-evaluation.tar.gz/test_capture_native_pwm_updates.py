"""Fake acquisition/receipt tests: no analyzer, SSH, GPIO or waveform verdict."""

import copy
import json
import shlex
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

import capture_native_pwm_updates as bench
import native_pwm_updates_eval as helper
import pytest
import test_native_pwm_updates_eval as helper_fakes

ROOT = helper_fakes.ROOT
old_environment = helper_fakes.old_environment
environment = helper_fakes.environment
PYTHON = "/tmp/blinka-pwm-oct6.F3SDcm/venv/bin/python"


def configure(monkeypatch, receipt, scenario="success", remote_python=PYTHON):
    events = []
    capture = MagicMock()
    capture.__enter__.return_value = capture

    def stop():
        events.append("stop")
        if scenario == "stop_error":
            raise OSError("stop failed")

    def save(path):
        events.append("save")
        if scenario == "save_error":
            raise OSError("save failed")
        Path(path).write_bytes(b"fake SAL evidence")

    def export(path, **kwargs):
        events.append(("export", kwargs["digital_channels"]))
        assert kwargs == {"digital_channels": [0]}
        if scenario == "export_error":
            raise OSError("export failed")
        if scenario != "missing_raw":
            (Path(path) / "digital_0.bin").write_bytes(b"fake unfiltered edges")

    capture.stop.side_effect = stop
    capture.save_capture.side_effect = save
    capture.export_raw_data_binary.side_effect = export
    manager = MagicMock()
    manager.__enter__.return_value = manager
    manager.get_devices.return_value = [
        SimpleNamespace(
            device_id=bench.DEVICE_ID, is_simulation=scenario == "simulation"
        )
    ]
    if scenario == "wrong_device":
        manager.get_devices.return_value[0].device_id = "other-device"
    manager.get_app_info.return_value = SimpleNamespace(app_version="fake")
    manager.start_capture.return_value = capture
    monkeypatch.setattr(
        bench,
        "automation",
        SimpleNamespace(
            Manager=SimpleNamespace(connect=MagicMock(return_value=manager)),
            LogicDeviceConfiguration=lambda **kwargs: kwargs,
        ),
    )

    def run(command, **kwargs):
        events.append("ssh")
        assert command[:-1] == [
            "ssh",
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=8",
            "pi@test-pi5.local",
        ]
        assert shlex.split(command[-1]) == [
            remote_python,
            ROOT + "/native_pwm_updates_eval.py",
            "--mode",
            receipt["mode"],
            "--manifest",
            ROOT + "/manifest.json",
        ]
        assert set(kwargs) == {"stdout", "stderr", "text", "check", "timeout"}
        assert kwargs["text"] is True and kwargs["check"] is False
        assert kwargs["timeout"] == 30
        if scenario in ("timeout", "interrupt"):
            kwargs["stdout"].write("partial receipt")
            kwargs["stderr"].write("partial diagnostic")
            if scenario == "timeout":
                raise subprocess.TimeoutExpired(command, 30)
            raise KeyboardInterrupt("interrupted")
        data = copy.deepcopy(receipt)
        if scenario == "wrong_hash":
            data["source_sha256"][helper.base.PACKAGE + "/_native.so"] = "0" * 64
        elif scenario == "cleanup_failed":
            data["cleanup_errors"] = ["failed"]
        elif scenario == "wrong_schema":
            data["schema_version"] = True
        elif scenario == "wrong_root":
            data["manifest_path"] = ROOT.replace("abc123", "def456") + "/manifest.json"
        if scenario == "duplicate_json":
            kwargs["stdout"].write('{"success":true,"success":false}')
        elif scenario == "nonfinite_json":
            kwargs["stdout"].write('{"success":NaN}')
        else:
            kwargs["stdout"].write(json.dumps(data))
        return subprocess.CompletedProcess(
            command, 1 if scenario == "helper_failed" else 0
        )

    runner = MagicMock(side_effect=run)
    monkeypatch.setattr(bench.subprocess, "run", runner)

    def sleep(duration):
        events.append(("sleep", duration))
        if scenario == "lead_interrupt" and duration == 0.5:
            raise KeyboardInterrupt("lead interrupted")
        if scenario == "tail_error" and duration == 0.2:
            raise OSError("tail failed")

    monkeypatch.setattr(bench.time, "sleep", sleep)
    return events, manager, runner


@pytest.mark.parametrize("mode", bench.MODES)
def test_exact_helper_receipt_and_unfiltered_capture(
    environment, monkeypatch, tmp_path, mode
):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = helper.experiment(mode, ROOT + "/manifest.json")
    bench.validate_remote(receipt, mode, manifest)
    events, manager, runner = configure(monkeypatch, receipt)
    output = tmp_path / "capture"
    result = bench.capture_test(output, ROOT, PYTHON, mode, tmp_path / "manifest.json")
    assert events == [
        ("sleep", 0.5),
        "ssh",
        ("sleep", 0.2),
        "stop",
        "save",
        ("export", [0]),
    ]
    bench.automation.Manager.connect.assert_called_once_with(
        port=10430, connect_timeout_seconds=5
    )
    manager.start_capture.assert_called_once_with(
        device_id="81F8C2631DF5BF30",
        device_configuration={
            "enabled_digital_channels": [0],
            "digital_sample_rate": 100_000_000,
        },
    )
    runner.assert_called_once()
    assert result["collection_success"] is True
    assert result["mode"] == mode and result["backend"] == helper.BACKEND
    assert result["sequence_marker"] == f"native-updates-{mode}-v1"
    assert result["remote"] == receipt
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert result["parity_evaluated"] is False and result["analysis_deferred"] is True
    assert "accepted" not in result
    assert json.loads((output / "manifest.json").read_text()) == manifest
    assert json.loads((output / "results.json").read_text()) == result
    assert (output / "waveform.sal").read_bytes() == b"fake SAL evidence"
    assert (output / "digital_0.bin").read_bytes() == b"fake unfiltered edges"
    assert not (output / "analysis.json").exists()


@pytest.mark.parametrize(
    "scenario",
    [
        "timeout",
        "interrupt",
        "lead_interrupt",
        "tail_error",
        "stop_error",
        "save_error",
        "export_error",
        "helper_failed",
        "wrong_hash",
        "wrong_schema",
        "cleanup_failed",
        "simulation",
        "wrong_device",
        "missing_raw",
        "wrong_root",
        "duplicate_json",
        "nonfinite_json",
    ],
)
def test_failure_metadata_and_raw_retention(
    environment, monkeypatch, tmp_path, scenario
):
    receipt = helper.experiment("frequency", ROOT + "/manifest.json")
    events, _manager, runner = configure(monkeypatch, receipt, scenario)
    output = tmp_path / "capture"
    with pytest.raises((RuntimeError, ValueError, KeyboardInterrupt)):
        bench.capture_test(
            output, ROOT, PYTHON, "frequency", tmp_path / "manifest.json"
        )
    acquisition = json.loads((output / "acquisition.json").read_text())
    result = json.loads((output / "results.json").read_text())
    assert result["collection_success"] is False and result["receipt_validation_error"]
    assert result["waveform_accepted"] is None and result["parity_pass"] is None
    assert result["parity_evaluated"] is False and result["analysis_deferred"] is True
    if scenario in ("simulation", "wrong_device"):
        runner.assert_not_called()
        assert events == []
    else:
        assert "stop" in events and "save" in events and ("export", [0]) in events
        assert ("sleep", 0.2) in events
        if scenario != "save_error":
            assert (output / "waveform.sal").is_file()
        if scenario not in ("missing_raw", "export_error"):
            assert (output / "digital_0.bin").is_file()
    if scenario in ("timeout", "interrupt"):
        assert (output / "remote.stdout").read_text() == "partial receipt"
        assert (output / "remote.stderr").read_text() == "partial diagnostic"
        assert acquisition["remote_returncode"] == (
            124 if scenario == "timeout" else None
        )
        assert acquisition["primary_error"]
    if scenario in ("tail_error", "stop_error", "save_error", "export_error"):
        action = {
            "tail_error": "tail",
            "stop_error": "stop",
            "save_error": "save_capture",
            "export_error": "export_binary",
        }[scenario]
        assert len(acquisition["evidence_errors"]) == 1
        assert acquisition["evidence_errors"][0].startswith(action + ": OSError:")
    assert not (output / "analysis.json").exists()


@pytest.mark.parametrize(
    "root,python,mode",
    [
        ("/tmp", PYTHON, "direct"),
        (ROOT + "/../other", PYTHON, "direct"),
        (ROOT.replace("updates", "half50"), PYTHON, "half50-direct"),
        (ROOT, "/usr/bin/python3", "direct"),
        (ROOT, PYTHON + ";echo unsafe", "direct"),
        (ROOT, "/tmp/blinka-pwm-oct6.other/venv/bin/python", "direct"),
        (ROOT, PYTHON, "unsupported"),
    ],
)
def test_invalid_paths_mode_refuse_before_output_or_ssh(
    environment, monkeypatch, tmp_path, root, python, mode
):
    receipt = helper.experiment("direct", ROOT + "/manifest.json")
    _events, _manager, runner = configure(monkeypatch, receipt)
    with pytest.raises(ValueError):
        bench.capture_test(
            tmp_path / "capture", root, python, mode, tmp_path / "manifest.json"
        )
    assert not (tmp_path / "capture").exists()
    runner.assert_not_called()


def test_isolated_root_venv_python_is_approved(environment, monkeypatch, tmp_path):
    receipt = helper.experiment("direct", ROOT + "/manifest.json")
    _events, _manager, runner = configure(
        monkeypatch, receipt, remote_python=ROOT + "/venv/bin/python"
    )
    result = bench.capture_test(
        tmp_path / "capture",
        ROOT,
        ROOT + "/venv/bin/python",
        "direct",
        tmp_path / "manifest.json",
    )
    assert result["collection_success"] is True
    runner.assert_called_once()


@pytest.mark.parametrize(
    "source",
    [
        "native_pwm_updates_eval.py",
        "native_pwm_half50_eval.py",
        "kernel_pwm_lgpio_baseline_eval.py",
        "kernel_pwm_eval.py",
        helper.base.PACKAGE + "/__init__.py",
        helper.base.PACKAGE + "/_software.py",
    ],
)
def test_local_python_source_mismatch_refuses_before_capture(
    environment, monkeypatch, tmp_path, source
):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = helper.experiment("direct", ROOT + "/manifest.json")
    _events, _manager, runner = configure(monkeypatch, receipt)
    manifest["source_sha256"][source] = "0" * 64
    with pytest.raises((ValueError, helper.core.BenchError)):
        bench.capture_test(
            tmp_path / "capture", ROOT, PYTHON, "direct", tmp_path / "manifest.json"
        )
    assert not (tmp_path / "capture").exists()
    runner.assert_not_called()


@pytest.mark.parametrize("mode", bench.MODES)
@pytest.mark.parametrize(
    "field",
    [
        "flag",
        "inherited",
        "enabled",
        "cleanup",
        "request",
        "source",
        "short_dwell",
        "signal",
        "event",
        "api",
        "permission",
        "difference",
        "original",
        "scope",
        "arguments",
        "event_clock",
        "settle",
        "constructor",
        "phase_extra",
        "thermal",
        "identity",
        "manifest",
    ],
)
def test_validator_rejects_malformed_safety_provenance(environment, field, mode):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = helper.experiment(mode, ROOT + "/manifest.json")
    if field == "flag":
        receipt["runtime_flags"]["shared"] = 0
    elif field == "inherited":
        receipt["inherited_environment"]["BLINKA_PWM_SHARED"] = "1"
    elif field == "enabled":
        receipt["phases"][0]["api_state"]["enabled"] = True
    elif field == "cleanup":
        receipt["cleanup_final_readback"]["gpio_level"] = False
    elif field == "request":
        receipt["owned_request"]["offsets"] = [23]
    elif field == "source":
        receipt["source_sha256"][helper.base.PACKAGE + "/_native.so"] = "0" * 64
    elif field == "short_dwell":
        receipt["phases"][0]["end_ns"] = receipt["phases"][0]["stable_begin_ns"] + 1
    elif field == "signal":
        receipt["signals_received"] = [15]
    elif field == "event":
        receipt["events"].pop()
    elif field == "api":
        receipt["phases"][0]["api_state_end"]["duty_cycle"] = False
    elif field == "permission":
        receipt["variable_frequency"] = mode == "half50-direct"
    elif field == "difference":
        receipt["variable_frequency_differs_from_original"] = mode == "half50-direct"
    elif field == "original":
        receipt["original_variable_frequency_default"] = True
    elif field == "scope":
        receipt["events"][1]["scope"] = "initialization"
    elif field == "arguments":
        receipt["events"][1]["arguments"]["duty_u16"] = 0
    elif field == "event_clock":
        receipt["events"][1]["end_ns"] = receipt["end_ns"]
    elif field == "settle":
        event = next(e for e in receipt["events"] if e["operation"] == "low_settle")
        event["end_ns"] = event["begin_ns"] + 1
    elif field == "constructor":
        receipt["events"][0]["arguments"]["duty_u16"] = False
    elif field == "phase_extra":
        receipt["phases"][0]["baseline_percent"] = 0
    elif field == "thermal":
        receipt["after"]["throttled"] = "throttled=0x1"
    elif field == "identity":
        receipt["identity"]["label"] = "other"
    else:
        receipt["manifest_path"] = "/tmp/manifest.json"
    with pytest.raises(ValueError):
        bench.validate_remote(receipt, mode, manifest)


@pytest.mark.parametrize("mode", ["direct", "frequency"])
@pytest.mark.parametrize("problem", ["order", "old_duty", "extra", "missing"])
def test_validator_requires_frequency_first_and_only_changed_setters(
    environment, mode, problem
):
    _state, _guard, _module, manifest, _sleeps = environment
    receipt = helper.experiment(mode, ROOT + "/manifest.json")
    events = receipt["events"]
    index = next(
        i for i, event in enumerate(events) if event["operation"] == "PWMOut.frequency"
    )
    assert events[index + 1]["operation"] == "PWMOut.duty_cycle"
    if problem == "order":
        events[index], events[index + 1] = events[index + 1], events[index]
    elif problem == "old_duty":
        events[index]["arguments"]["duty_u16"] = 32768
    elif problem == "extra":
        events.insert(1, copy.deepcopy(events[1]))
    else:
        events.pop(index)
    with pytest.raises(ValueError):
        bench.validate_remote(receipt, mode, manifest)


def test_output_directory_is_exclusive(environment, monkeypatch, tmp_path):
    receipt = helper.experiment("direct", ROOT + "/manifest.json")
    _events, _manager, runner = configure(monkeypatch, receipt)
    output = tmp_path / "capture"
    output.mkdir()
    sentinel = output / "previous"
    sentinel.write_text("keep")
    with pytest.raises(FileExistsError):
        bench.capture_test(output, ROOT, PYTHON, "direct", tmp_path / "manifest.json")
    assert sentinel.read_text() == "keep"
    runner.assert_not_called()


def test_cli_requires_mode_and_reports_no_waveform_verdict(
    monkeypatch, capsys, tmp_path
):
    capture = MagicMock(return_value={"collection_success": True})
    monkeypatch.setattr(bench, "capture_test", capture)
    args = [
        str(tmp_path / "capture"),
        "--remote-root",
        ROOT,
        "--remote-python",
        PYTHON,
        "--manifest",
        str(tmp_path / "manifest.json"),
    ]
    with pytest.raises(SystemExit) as missing_mode:
        bench.main(args)
    assert missing_mode.value.code == 2
    capture.assert_not_called()
    assert bench.main(args + ["--mode", "frequency"]) == 0
    capture.assert_called_once_with(
        tmp_path / "capture", ROOT, PYTHON, "frequency", tmp_path / "manifest.json"
    )
    result = json.loads(capsys.readouterr().out)
    assert result == {
        "capture": "capture",
        "mode": "frequency",
        "backend": helper.BACKEND,
        "collection_success": True,
        "waveform_accepted": None,
        "parity_evaluated": False,
    }


def test_json_parser_rejects_duplicates_and_nonfinite():
    with pytest.raises(ValueError):
        bench.read_json('{"success":true,"success":false}')
    with pytest.raises(ValueError):
        bench.read_json('{"value":NaN}')
