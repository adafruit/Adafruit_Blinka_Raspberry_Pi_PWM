"""Unfiltered native updates facts and target-normalized finite comparisons.

Regimes are waveform-only descriptions, not synchronization to commands.
Integer-percent lgpio and rounded-nanosecond native pulse targets are distinct.
Intermediate-width runs and every anomalous/boundary edge remain visible.
"""

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path

from analyze_kernel_pwm_inverse import read_continuous, require, validate_saved_capture
from analyze_kernel_pwm_lgpio_baseline import analyze as analyze_baseline
from capture_pwm import describe

BACKEND = "native-blinka-pwm"
MODES = ("direct", "frequency", "half50-direct")
PLAN_NAME = "oct7-native-updates-plan.json"
STABLE_SPECS = {
    "servo50_d4915": (50, 4915),
    "half500_d32768": (500, 32768),
    "half50_d32768": (50, 32768),
}
INTERMEDIATE_SPECS = {
    "intermediate500_d4915": (500, 4915),
    "intermediate50_d32768": (50, 32768),
}


def target(frequency, duty, backend):
    period_ns = (1_000_000_000 + frequency // 2) // frequency
    native_high_ns = (period_ns * duty + 32767) // 65535
    original_percent = round(100 * duty / 65535)
    actual_high_us = (
        native_high_ns / 1000
        if backend == "native"
        else period_ns / 1000 * original_percent / 100
    )
    requested_high_us = period_ns / 1000 * duty / 65535
    return {
        "frequency_hz": frequency,
        "duty_u16": duty,
        "period_us": period_ns / 1000,
        "high_us": actual_high_us,
        "low_us": period_ns / 1000 - actual_high_us,
        "common_requested_u16_high_us": requested_high_us,
        "actual_minus_common_requested_high_us": actual_high_us - requested_high_us,
        "native_rounded_high_ns": native_high_ns,
        "original_rounded_integer_percent": original_percent,
    }


def targets(mode, backend="native"):
    require(
        mode in MODES and backend in ("native", "original"),
        "Unsupported fact mode/backend",
    )
    stable = {
        name: target(*spec, backend)
        for name, spec in STABLE_SPECS.items()
        if (mode == "half50-direct") == (name == "half50_d32768")
    }
    intermediate = (
        {name: target(*spec, backend) for name, spec in INTERMEDIATE_SPECS.items()}
        if mode == "frequency"
        else {}
    )
    return stable, intermediate


def summary(values):
    return describe(values) if values else None


def max_abs(values):
    return max(map(abs, values), default=None)


def waveform_facts(mode, waveform, edges, backend="native"):
    """No trimming: diagnostic bins and nearest-target assignments are separate."""
    require(len(edges) % 2 == 0, "Low-start/end trace must contain complete high runs")
    require(
        all(math.isfinite(edge) for edge in edges)
        and all(a < b for a, b in itertools.pairwise(edges)),
        "Edges must be finite and strictly ordered",
    )
    stable, intermediate = targets(mode, backend)
    highs = []
    for index, (rise, fall) in enumerate(zip(edges[::2], edges[1::2])):
        width = (fall - rise) * 1e6
        if width >= 100_000:
            regime, width_bin, assignment, nominal = (
                "constant_high",
                "constant_high",
                "long_high_run",
                None,
            )
        else:
            nearby = [
                name
                for name, nominal in intermediate.items()
                if abs(width / nominal["high_us"] - 1) <= 0.02
            ]
            if nearby:
                regime = min(
                    nearby, key=lambda name: abs(width - intermediate[name]["high_us"])
                )
                nominal = intermediate[regime]
                width_bin, assignment = (
                    regime,
                    "near_intermediate_width_not_command_proof",
                )
            else:
                regime = min(
                    stable, key=lambda name: abs(width - stable[name]["high_us"])
                )
                nominal = stable[regime]
                width_bin = (
                    regime
                    if abs(width / nominal["high_us"] - 1) <= 0.02
                    else "unmatched_high_run"
                )
                assignment = (
                    "nearest_stable_width_including_anomalies_not_command_proof"
                )
        item = {
            "pair_index": index,
            "rise_seconds": rise,
            "fall_seconds": fall,
            "width_us": width,
            "width_bin": width_bin,
            "diagnostic_regime": regime,
            "regime_assignment": assignment,
        }
        if nominal is not None:
            item.update(
                target_high_us=nominal["high_us"],
                target_error_us=width - nominal["high_us"],
                relative_target_error_percent=100 * (width / nominal["high_us"] - 1),
                common_requested_error_us=width
                - nominal["common_requested_u16_high_us"],
            )
        highs.append(item)
    lows = [
        {
            "preceding_pair_index": a["pair_index"],
            "following_pair_index": b["pair_index"],
            "fall_seconds": a["fall_seconds"],
            "rise_seconds": b["rise_seconds"],
            "width_ns": (b["rise_seconds"] - a["fall_seconds"]) * 1e9,
        }
        for a, b in itertools.pairwise(highs)
    ]
    intervals = [
        {
            "preceding_pair_index": a["pair_index"],
            "following_pair_index": b["pair_index"],
            "from_regime": a["diagnostic_regime"],
            "to_regime": b["diagnostic_regime"],
            "rise_to_rise_us": (b["rise_seconds"] - a["rise_seconds"]) * 1e6,
            "low_gap_us": (b["rise_seconds"] - a["fall_seconds"]) * 1e6,
        }
        for a, b in itertools.pairwise(highs)
    ]
    groups = []
    for regime, values in itertools.groupby(
        highs, key=lambda item: item["diagnostic_regime"]
    ):
        values = list(values)
        groups.append(
            {
                "regime": regime,
                "high_count": len(values),
                "first_pair_index": values[0]["pair_index"],
                "last_pair_index": values[-1]["pair_index"],
                "first_rise_seconds": values[0]["rise_seconds"],
                "last_fall_seconds": values[-1]["fall_seconds"],
                "high_us": summary([item["width_us"] for item in values]),
                "rise_to_rise_us": summary(
                    [
                        (b["rise_seconds"] - a["rise_seconds"]) * 1e6
                        for a, b in itertools.pairwise(values)
                    ]
                ),
            }
        )
    bins = [
        {
            "width_bin": label,
            "high_count": len(values),
            "first_pair_index": values[0]["pair_index"],
            "last_pair_index": values[-1]["pair_index"],
            "high_us": summary([item["width_us"] for item in values]),
        }
        for label, grouped in itertools.groupby(
            highs, key=lambda item: item["width_bin"]
        )
        for values in [list(grouped)]
    ]
    statistics = {}
    for name, nominal in {**stable, **intermediate}.items():
        selected = [item for item in highs if item["diagnostic_regime"] == name]
        own_intervals = [
            item
            for item in intervals
            if item["from_regime"] == item["to_regime"] == name
        ]
        width_errors = [item["target_error_us"] for item in selected]
        period_errors = [
            item["rise_to_rise_us"] - nominal["period_us"] for item in own_intervals
        ]
        low_errors = [item["low_gap_us"] - nominal["low_us"] for item in own_intervals]
        statistics[name] = {
            "nominal": nominal,
            "high_count": len(selected),
            "all_high_us": summary([item["width_us"] for item in selected]),
            "target_error_us": summary(width_errors),
            "relative_target_error_percent": summary(
                [item["relative_target_error_percent"] for item in selected]
            ),
            "common_requested_error_us": summary(
                [item["common_requested_error_us"] for item in selected]
            ),
            "rise_to_rise_us": summary(
                [item["rise_to_rise_us"] for item in own_intervals]
            ),
            "period_target_error_us": summary(period_errors),
            "interior_low_us": summary([item["low_gap_us"] for item in own_intervals]),
            "low_target_error_us": summary(low_errors),
            "max_absolute_high_target_error_us": max_abs(width_errors),
            "max_absolute_period_target_error_us": max_abs(period_errors),
            "max_absolute_low_target_error_us": max_abs(low_errors),
            "includes_all_nearest_regime_anomalies": name in stable,
        }
    waveform["transition_seconds"] = list(edges)
    return {
        "all_high_runs": highs,
        "all_interior_low_runs": lows,
        "all_adjacent_rise_intervals": intervals,
        "groups": groups,
        "diagnostic_width_bin_groups": bins,
        "boundaries": [
            item for item in intervals if item["from_regime"] != item["to_regime"]
        ],
        "constant_high_holds": [
            item for item in highs if item["width_bin"] == "constant_high"
        ],
        "intermediate_width_high_runs": [
            item for item in highs if item["diagnostic_regime"] in intermediate
        ],
        "unmatched_high_runs": [
            item for item in highs if item["width_bin"] == "unmatched_high_run"
        ],
        "sub_microsecond_low_runs": [item for item in lows if item["width_ns"] < 1000],
        "long_interior_low_runs": [
            item for item in lows if item["width_ns"] >= 100_000_000
        ],
        "target_normalized_statistics": statistics,
        "nominal_stable_targets": stable,
        "nominal_intermediate_targets": intermediate,
        "width_bins_are_diagnostic_not_acceptance_thresholds": True,
        "ordinary_bin_tolerance_percent": 2,
        "phase_alignment_proven": False,
        "regime_assignment_is_waveform_only_not_phase_or_command_association": True,
        "no_transition_trimming_or_glitch_filtering": True,
    }


FROZEN_PLAN_SHA256 = "f0850799856c0d20b54935d6d584c9e10e5f98642a23e24e9e35771d59990a9b"
FROZEN_HALF50_PLAN_SHA256 = (
    "ebf2c59ea9e00dac0f3ea88e105ef47898c45e336aed453671dc3c38c6801d7a"
)
EXPECTED_TOPOLOGIES = {
    "frequency": ["servo50_d4915", "half500_d32768", "servo50_d4915", "constant_high"],
    "direct": [
        "servo50_d4915",
        "constant_high",
        "servo50_d4915",
        "constant_high",
        "half500_d32768",
        "constant_high",
        "servo50_d4915",
    ],
    "half50-direct": ["half50_d32768", "constant_high", "half50_d32768"],
}


def read_plan(path=None):
    from capture_native_pwm_updates import read_json

    path = Path(path) if path is not None else Path(__file__).with_name(PLAN_NAME)
    raw = path.read_bytes()
    require(
        hashlib.sha256(raw).hexdigest() == FROZEN_PLAN_SHA256,
        "Frozen updates plan must not change after capture",
    )
    return read_json(raw.decode())


def mode_limits(mode, plan):
    if mode != "half50-direct":
        return plan["provisional_checks"][mode]
    from capture_native_pwm_updates import read_json

    raw = Path(__file__).with_name("oct7-native-half50-plan.json").read_bytes()
    require(
        hashlib.sha256(raw).hexdigest() == FROZEN_HALF50_PLAN_SHA256,
        "Frozen original half50 plan must remain unchanged",
    )
    old = read_json(raw.decode())["provisional_checks"]
    return {
        "target_normalized_max_errors_us": {
            "half50_d32768": {
                "high": old[
                    "max_absolute_high_deviation_from_common_10000us_reference_us"
                ],
                "period": old[
                    "max_absolute_period_deviation_from_20000us_reference_us"
                ],
                "interior_low": old[
                    "max_absolute_interior_low_deviation_from_10000us_reference_us"
                ],
            }
        },
        "ordinary_group_counts_inclusive": [
            [old["initial_pwm_high_count"]] * 2,
            old["recovery_pwm_high_count_inclusive"],
        ],
        "edge_count_inclusive": old["complete_edge_count_inclusive"],
        "continuous_high_count": old["continuous_high_runs"],
        "continuous_high_nominal_ms": [300],
        "hold_absolute_deviation_limit_ms": [
            old["max_absolute_constant_high_duration_deviation_from_300ms_ms"]
        ],
        "sub_microsecond_low_count": old["sub_microsecond_interior_low_runs"],
        "caller_max_us": {
            scope + ".PWMOut.duty_cycle": value
            for scope, value in old["caller_setter_per_scope_max_us"].items()
        },
        "half50_limits_use_common_10000us_high_and_low_references": True,
        "max_physical_boundary_low_gap_ms": old["max_physical_boundary_low_gap_ms"],
    }


def provisional_checks(report, plan=None):
    plan = read_plan() if plan is None else plan
    require(plan == read_plan(), "Supplied comparison plan must match the frozen plan")
    mode, physical = report["mode"], report["physical"]
    limits = mode_limits(mode, plan)
    checks = []

    def check(name, observed, limit, within, domain="physical_observed_envelope"):
        checks.append(
            {
                "name": name,
                "domain": domain,
                "observed": observed,
                "predeclared_limit": limit,
                "within_predeclared_limit": bool(within),
            }
        )

    topology = [item["regime"] for item in physical["groups"]]
    ordinary_counts = [
        item["high_count"]
        for item in physical["groups"]
        if item["regime"] in physical["nominal_stable_targets"]
    ]
    check(
        "observed_regime_topology",
        topology,
        EXPECTED_TOPOLOGIES[mode],
        topology == EXPECTED_TOPOLOGIES[mode],
        "waveform_only_topology_observation_not_command_association",
    )
    count_bounds = limits["ordinary_group_counts_inclusive"]
    check(
        "ordinary_group_count_observations",
        ordinary_counts,
        count_bounds,
        len(ordinary_counts) == len(count_bounds)
        and all(
            low <= value <= high
            for value, (low, high) in zip(ordinary_counts, count_bounds)
        ),
        "waveform_only_count_observation_not_automatic_regression",
    )
    edge_count = report["waveform"]["edge_count"]
    low, high = limits["edge_count_inclusive"]
    check(
        "edge_count_observation",
        edge_count,
        [low, high],
        low <= edge_count <= high,
        "whole_record_count_observation_not_automatic_regression",
    )
    check(
        "all_edges_accounted_for",
        edge_count,
        2 * len(physical["all_high_runs"]),
        edge_count == 2 * len(physical["all_high_runs"]),
    )
    waveform = report["waveform"]
    check(
        "start_and_end_low",
        [waveform["initial_state"], waveform["final_state"]],
        [0, 0],
        waveform["initial_state"] == waveform["final_state"] == 0,
    )
    holds = [item["width_us"] / 1000 for item in physical["constant_high_holds"]]
    check(
        "continuous_high_count",
        len(holds),
        limits["continuous_high_count"],
        len(holds) == limits["continuous_high_count"],
    )
    check(
        "sub_microsecond_low_count",
        len(physical["sub_microsecond_low_runs"]),
        limits["sub_microsecond_low_count"],
        len(physical["sub_microsecond_low_runs"])
        == limits["sub_microsecond_low_count"],
    )
    for index, (nominal, limit) in enumerate(
        zip(
            limits["continuous_high_nominal_ms"],
            limits["hold_absolute_deviation_limit_ms"],
        )
    ):
        observed = abs(holds[index] - nominal) if index < len(holds) else None
        check(
            f"hold_absolute_deviation_ms.{index}",
            observed,
            limit,
            observed is not None and observed <= limit + 1e-7,
        )
    for regime, bounds in limits["target_normalized_max_errors_us"].items():
        stats = physical["target_normalized_statistics"][regime]
        values = {
            "high": stats["max_absolute_high_target_error_us"],
            "period": stats["max_absolute_period_target_error_us"],
            "interior_low": stats["max_absolute_low_target_error_us"],
        }
        if mode == "half50-direct":
            values["high"] = max_abs(
                [
                    item["width_us"] - 10000
                    for item in physical["all_high_runs"]
                    if item["diagnostic_regime"] == regime
                ]
            )
            values["interior_low"] = max_abs(
                [
                    item["width_ns"] / 1000 - 10000
                    for item in physical["all_interior_low_runs"]
                ]
            )
        for statistic, limit in bounds.items():
            observed = values[statistic]
            check(
                regime + ".max_absolute_" + statistic + "_target_error_us",
                observed,
                limit,
                observed is not None
                and math.isfinite(observed)
                and observed <= limit + 1e-7,
            )
    if mode == "half50-direct":
        observed = max(
            (item["low_gap_us"] / 1000 for item in physical["boundaries"]), default=None
        )
        limit = limits["max_physical_boundary_low_gap_ms"]
        check(
            "max_physical_boundary_low_gap_ms",
            observed,
            limit,
            observed is not None and observed <= limit + 1e-7,
        )
    for key, limit in limits["caller_max_us"].items():
        observed = max(
            (
                item["caller_duration_us"]
                for item in report["caller_updates"]
                if item["scope"] + "." + item["operation"] == key
            ),
            default=None,
        )
        check(
            key,
            observed,
            limit,
            observed is not None and math.isfinite(observed) and observed <= limit,
            "caller_return_not_electrical_latency",
        )
    return {
        "checks": checks,
        "flags_to_investigate": [
            item["name"] for item in checks if not item["within_predeclared_limit"]
        ],
        "count_and_topology_are_observations_not_rigid_acceptance_of_phase_timing": True,
        "intermediate_width_count": len(physical["intermediate_width_high_runs"]),
        "unmatched_high_count": len(physical["unmatched_high_runs"]),
        "all_intermediate_and_unmatched_runs_remain_in_physical_evidence": True,
        "phase_and_electrical_latency_alignment_proven": False,
    }


def analyze(directory, plan_path=None):
    from capture_native_pwm_updates import read_json, validate_remote

    directory = Path(directory)
    plan = read_plan(plan_path)
    metadata = read_json((directory / "results.json").read_text())
    remote = read_json((directory / "remote.stdout").read_text())
    mode = metadata.get("mode")
    require(mode in MODES, "Unsupported captured mode")
    manifest = read_json((directory / "manifest.json").read_text())
    validate_remote(remote, mode, manifest)
    require(metadata.get("remote") == remote, "Native remote receipt/metadata disagree")
    require(
        type(metadata.get("schema_version")) is int
        and metadata["schema_version"] == 1
        and metadata.get("backend") == BACKEND
        and metadata.get("sequence_marker") == f"native-updates-{mode}-v1"
        and metadata.get("production_backend_unchanged") is True
        and metadata.get("collection_success") is True
        and type(metadata.get("remote_returncode")) is int
        and metadata["remote_returncode"] == 0
        and metadata.get("parity_evaluated") is False
        and "parity_pass" in metadata
        and metadata["parity_pass"] is None
        and "waveform_accepted" in metadata
        and metadata["waveform_accepted"] is None,
        "Expected successful native collection without a waveform/parity verdict",
    )
    acquisition = read_json((directory / "acquisition.json").read_text())
    require(
        acquisition.get("mode") == mode
        and acquisition.get("backend") == BACKEND
        and type(acquisition.get("remote_returncode")) is int
        and acquisition["remote_returncode"] == 0
        and "primary_error" in acquisition
        and acquisition["primary_error"] is None
        and acquisition.get("evidence_errors") == [],
        "Native acquisition failed or reported incomplete evidence",
    )
    require(
        remote.get("manifest_path")
        == str(acquisition.get("remote_root")) + "/manifest.json"
        and acquisition.get("local_timing_not_aligned_to_pi_or_saleae") is True
        and all(
            item.get("pre_helper_lead_seconds") == 0.5
            and item.get("post_helper_tail_seconds") == 0.2
            for item in (metadata, acquisition)
        ),
        "Native acquisition root/lead/tail/clock provenance mismatch",
    )
    require(
        metadata.get("host") == "test-pi5.local"
        and metadata.get("sample_rate_hz") == 100_000_000,
        "Wrong native host/sample rate",
    )
    require(
        metadata.get("outputs")
        == [{"gpio": 18, "saleae_channel": 0, "backend": BACKEND}],
        "Wrong native output mapping",
    )
    settings = validate_saved_capture(directory / "waveform.sal")
    waveform, edges = read_continuous(directory / "digital_0.bin")
    physical = waveform_facts(mode, waveform, edges)
    setters = [
        {
            "operation": event["operation"],
            "scope": event["scope"],
            "arguments": event["arguments"],
            "begin_ns": event["begin_ns"],
            "end_ns": event["end_ns"],
            "caller_duration_us": (event["end_ns"] - event["begin_ns"]) / 1000,
        }
        for event in remote["events"]
        if event["operation"] in ("PWMOut.frequency", "PWMOut.duty_cycle")
    ]
    report = {
        "capture": directory.name,
        "mode": mode,
        "backend": BACKEND,
        "collection_success": True,
        "characterization_only": True,
        "saved_capture_settings": settings,
        "waveform": waveform,
        "physical": physical,
        "caller_updates": setters,
        "phase_api_update_durations_us": [
            {
                "name": phase["name"],
                "duration_us": (phase["stable_begin_ns"] - phase["begin_ns"]) / 1000,
            }
            for phase in remote["phases"]
        ],
        "source_sha256": remote["source_sha256"],
        "source_manifest": manifest,
        "comparison_plan_sha256": FROZEN_PLAN_SHA256,
        "comparison_plan_declared_before_capture_utc": plan[
            "declared_before_capture_utc"
        ],
        "half50_original_comparison_plan_sha256": FROZEN_HALF50_PLAN_SHA256
        if mode == "half50-direct"
        else None,
        "variable_frequency": remote["variable_frequency"],
        "original_variable_frequency_default": False,
        "variable_frequency_differs_from_original": remote[
            "variable_frequency_differs_from_original"
        ],
        "quantization": {
            "native_formula": "period_ns=(1000000000+frequency//2)//frequency; high_ns=(period_ns*duty_u16+32767)//65535",
            "original_formula": "round(duty_u16/65535*100)",
            "actual_target_and_common_requested_errors_reported_separately": True,
            "nominal_sample_interval_ns": 10,
            "timebase_calibrated": False,
            "nominal_two_edge_allowance_us": 0.02,
        },
        "clock_alignment": "Pi API/phase clocks are not aligned to Saleae; no command-to-edge latency claim.",
        "caller_timing_includes_instrumentation": True,
        "limitation": "Finite unfiltered digital-threshold observation, not analog proof or exclusion of sub-sample glitches. Width/regime assignment does not synchronize phases or identify command instants. All boundary edges, unmatched highs and near-intermediate widths are retained. A flag is not automatically a material regression; no broad backend parity is established.",
    }
    report["provisional_comparison"] = provisional_checks(report, plan)
    return report


def original_report(directory):
    report = analyze_baseline(directory)
    mode = report["mode"]
    report["original_diagnostic_bins"] = report["physical"]
    report["physical"] = waveform_facts(
        mode, report["waveform"], report["waveform"]["transition_seconds"], "original"
    )
    return report


def compare_paired(native_reports, baseline_reports, plan=None):
    require(
        len(native_reports) == len(baseline_reports) == 2,
        "Matched comparison requires two native and two original captures",
    )
    mode = native_reports[0]["mode"]
    require(
        mode in MODES
        and all(report["mode"] == mode for report in native_reports + baseline_reports),
        "Matched captures must have one mode",
    )
    require(
        all(report.get("backend") == BACKEND for report in native_reports)
        and all(
            report.get("backend") == "original-blinka-lgpio"
            for report in baseline_reports
        ),
        "Matched comparison requires native/original backend receipts",
    )
    require(
        len({report["capture"] for report in native_reports})
        == len({report["capture"] for report in baseline_reports})
        == 2,
        "Each matched repeat must be distinct",
    )
    plan = read_plan() if plan is None else plan
    require(plan == read_plan(), "Supplied comparison plan must match the frozen plan")

    def metrics(report):
        return {
            "capture": report["capture"],
            "edge_count": report["waveform"]["edge_count"],
            "groups": report["physical"]["groups"],
            "target_normalized_statistics": report["physical"][
                "target_normalized_statistics"
            ],
            "constant_high_holds": report["physical"]["constant_high_holds"],
            "boundaries": report["physical"]["boundaries"],
            "intermediate_width_high_runs": report["physical"][
                "intermediate_width_high_runs"
            ],
            "unmatched_high_runs": report["physical"]["unmatched_high_runs"],
            "sub_microsecond_low_runs": report["physical"]["sub_microsecond_low_runs"],
            "caller_updates": report["caller_updates"],
            "phase_api_update_durations_us": report["phase_api_update_durations_us"],
        }

    return {
        "mode": mode,
        "comparison_kind": "predeclared_narrow_finite_target_normalized_observation",
        "comparison_plan_sha256": FROZEN_PLAN_SHA256,
        "baseline_metrics": [metrics(report) for report in baseline_reports],
        "native_comparisons": [
            {**metrics(report), **provisional_checks(report, plan)}
            for report in native_reports
        ],
        "overall_backend_parity_established": False,
        "electrical_command_latency_measured": False,
        "loaded_overlap_not_verified_by_this_analyzer": True,
        "limitation": "Two runs per backend are descriptive, not calibrated/statistical acceptance. Loaded captures additionally need independently validated real worker overlap; frozen idle-reference flags do not establish a matched loaded verdict. Correct native 16-bit widths are compared with native rounded-nanosecond targets, not original integer-percent amplitudes.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", type=Path, nargs="+")
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--output-name", default="analysis.json")
    parser.add_argument("--comparison-output", type=Path)
    parser.add_argument("--baseline", type=Path, nargs=2)
    args = parser.parse_args(argv)
    require(len(args.directories) in (1, 2), "Expected one or two native captures")
    require(
        bool(args.output_name)
        and Path(args.output_name).name == args.output_name
        and args.output_name not in (".", ".."),
        "Output must be a filename within the capture directory",
    )
    require(
        args.comparison_output is None or len(args.directories) == 2,
        "Paired output requires two native captures",
    )
    outputs = [directory / args.output_name for directory in args.directories] + (
        [args.comparison_output] if args.comparison_output is not None else []
    )
    require(
        all(not path.exists() for path in outputs),
        "Analysis outputs are exclusive; refusing to overwrite evidence",
    )
    reports = [analyze(directory, args.plan) for directory in args.directories]
    comparison = None
    if len(reports) == 2:
        mode = reports[0]["mode"]
        names = read_plan(args.plan).get("baseline_captures", {}).get(mode)
        if names is None:
            names = [
                "oct6-pi5-lgpio-baseline-half50-direct",
                "oct6-pi5-lgpio-baseline-half50-direct-r2",
            ]
        baselines = args.baseline or [Path(__file__).parent / name for name in names]
        comparison = compare_paired(
            reports, [original_report(directory) for directory in baselines]
        )
    for directory, report in zip(args.directories, reports):
        with (directory / args.output_name).open("x") as stream:
            json.dump(report, stream, indent=2)
            stream.write("\n")
    if args.comparison_output is not None:
        with args.comparison_output.open("x") as stream:
            json.dump(comparison, stream, indent=2)
            stream.write("\n")
    print(
        json.dumps(
            {
                "captures": [
                    {
                        "capture": report["capture"],
                        "mode": report["mode"],
                        "edges": report["waveform"]["edge_count"],
                        "flags_to_investigate": report["provisional_comparison"][
                            "flags_to_investigate"
                        ],
                    }
                    for report in reports
                ],
                "paired_comparison_evaluated": comparison is not None,
                "overall_backend_parity_established": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
