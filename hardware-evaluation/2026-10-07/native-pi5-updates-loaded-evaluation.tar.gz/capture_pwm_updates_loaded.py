"""Fixed Pi5 public-API captures under independently expiring two-worker load.

Only fixed native/lgpio capture helpers are launched after the frozen recorder's
persisted launch handshake. No GPIO implementation, scheduling or generic shell
command API. Actual exits and Pi-clock phase overlap are recorded separately
from physical waveforms and electrical latency. Earlier scripts stay unchanged.
"""

import argparse
import hashlib
import json
import re
import subprocess
import sys
import time
from pathlib import Path

import analyze_kernel_pwm_cpu_load as load_audit
import capture_kernel_pwm_loaded as load_gate
import record_kernel_pwm_cpu_load as recorder

RECORDER_SHA = "6f755cdb1d2a8dc4a2af72248ddda88740ab2a3ab123ac5a1afe82e52d06974d"
GATE_SHA = "479eade31269ee00535112eb99fedf92bb47dc0cb1d57c40534de829410eed4b"
MODES = ("direct", "frequency", "half50-direct")
BENCH_PATTERN = r"/tmp/blinka-pwm-oct6\.[A-Za-z0-9]{6}"
NATIVE_PATTERN = r"/tmp/blinka-pwm-native-updates\.[A-Za-z0-9]{6}"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def capture_command(stem, backend, mode, bench_root, native_root=None, manifest=None):
    require(
        isinstance(stem, str) and re.fullmatch(r"[A-Za-z0-9_-]+-loaded-r[12]", stem),
        "Use a fresh stem ending -loaded-r1 or -loaded-r2",
    )
    require(
        mode in MODES and backend in ("native", "lgpio"),
        "Unsupported fixed backend/mode",
    )
    require(
        isinstance(bench_root, str) and re.fullmatch(BENCH_PATTERN, bench_root),
        "Require the approved Pi5 bench root",
    )
    directory = Path(__file__).resolve().parent
    if backend == "lgpio":
        require(
            native_root is None and manifest is None,
            "Original-lgpio has no native manifest/root",
        )
        return [
            sys.executable,
            str(directory / "capture_kernel_pwm_lgpio_baseline.py"),
            stem,
            "--remote-root",
            bench_root + "/lgpio-baseline-eval",
            "--mode",
            mode,
        ]
    require(
        isinstance(native_root, str) and re.fullmatch(NATIVE_PATTERN, native_root),
        "Require the isolated native-updates root",
    )
    require(
        manifest is not None
        and Path(manifest).is_file()
        and not Path(manifest).is_symlink(),
        "Require the reviewed native manifest file",
    )
    return [
        sys.executable,
        str(directory / "capture_native_pwm_updates.py"),
        stem,
        "--remote-root",
        native_root,
        "--remote-python",
        bench_root + "/venv/bin/python",
        "--manifest",
        str(Path(manifest).resolve()),
        "--mode",
        mode,
    ]


def overlap(load_path, capture_path):
    launch, completion = load_audit.parse_lines(
        Path(load_path).read_text(), 2, "load stdout"
    )
    workers = load_audit.validate_load(launch, completion)
    remote = json.loads((Path(capture_path) / "remote.stdout").read_text())
    require(
        remote.get("success") is True
        and remote.get("gpio18_released") is True
        and remote.get("low_confirmed") is True
        and remote.get("cleanup_errors") == [],
        "Successful private PWM cleanup is required",
    )
    phases = remote.get("phases")
    require(isinstance(phases, list) and phases, "Missing public-API phases")
    require(
        remote["helper_pid"]
        not in {launch["launcher_pid"], *(w["pid"] for w in workers)},
        "Load/PWM PIDs collide",
    )
    reasons = []
    for worker in workers:
        worker["phase_overlaps"] = [
            {
                "name": phase["name"],
                **load_audit.interval_overlap(
                    worker, phase["begin_ns"], phase["readback_end_ns"]
                ),
            }
            for phase in phases
        ]
        worker["all_phases_bracketed"] = all(
            item["bracketed"] for item in worker["phase_overlaps"]
        )
        worker["entire_helper_overlap"] = load_audit.interval_overlap(
            worker, remote["begin_ns"], remote["end_ns"]
        )
        reasons.extend(
            f"worker{worker['index']} does not bracket {item['name']}"
            for item in worker["phase_overlaps"]
            if not item["bracketed"]
        )
    return {
        "accepted": not reasons,
        "rejection_reasons": reasons,
        "workers": workers,
        "load_launcher_pid": launch["launcher_pid"],
        "pwm_helper_pid": remote["helper_pid"],
        "all_phases_bracketed_by_each_worker": not reasons,
        "entire_helper_bracketed_by_each_worker": all(
            w["entire_helper_overlap"]["bracketed"] for w in workers
        ),
        "scope": "Pi-clock phase intervals bracketed by real worker intervals; not CPU saturation, waveform acceptance, or aligned electrical latency",
    }


def coordinate(stem, backend, mode, bench_root, native_root=None, manifest=None):
    command = capture_command(stem, backend, mode, bench_root, native_root, manifest)
    require(
        hashlib.sha256(Path(recorder.__file__).read_bytes()).hexdigest()
        == RECORDER_SHA,
        "Frozen load recorder changed",
    )
    require(
        hashlib.sha256(Path(load_gate.__file__).read_bytes()).hexdigest() == GATE_SHA,
        "Frozen launch gate changed",
    )
    suffixes = (
        "",
        ".load.stdout",
        ".load.stderr",
        ".capture.stdout",
        ".capture.stderr",
        ".updates-coordination.json",
    )
    require(
        not any(
            Path(stem + suffix).exists() or Path(stem + suffix).is_symlink()
            for suffix in suffixes
        ),
        "All targets must be fresh",
    )
    receipt = {
        "schema_version": 1,
        "stem": stem,
        "backend": backend,
        "mode": mode,
        "bench_root": bench_root,
        "capture_command": command,
        "source_sha256": {
            Path(__file__).name: hashlib.sha256(
                Path(__file__).read_bytes()
            ).hexdigest(),
            "record_kernel_pwm_cpu_load.py": RECORDER_SHA,
            "capture_kernel_pwm_loaded.py": GATE_SHA,
        },
        "launch_validated": False,
        "capture_returncode": None,
        "capture_error": None,
        "load_helper_returncode": None,
        "load_recorder_error": None,
        "overlap": None,
        "coordination_success": False,
        "waveform_accepted": None,
        "parity_pass": None,
    }
    with Path(stem + ".updates-coordination.json").open("x") as summary:
        with (
            Path(stem + ".capture.stdout").open("xb") as stdout,
            Path(stem + ".capture.stderr").open("xb") as stderr,
        ):

            def capture(launch):
                receipt["launch_receipt"] = launch
                receipt["launch_validation_errors"] = load_gate.launch_issues(launch)
                if receipt["launch_validation_errors"]:
                    return
                receipt["launch_validated"] = True
                receipt["capture_begin_local_ns"] = time.monotonic_ns()
                try:
                    result = subprocess.run(
                        command,
                        stdin=subprocess.DEVNULL,
                        stdout=stdout,
                        stderr=stderr,
                        check=False,
                        timeout=20,
                    )
                    receipt["capture_returncode"] = result.returncode
                except BaseException as error:
                    receipt["capture_error"] = f"{type(error).__name__}: {error}"
                finally:
                    receipt["capture_end_local_ns"] = time.monotonic_ns()
                    stdout.flush()
                    stderr.flush()

            try:
                receipt["load_helper_returncode"] = recorder.record(
                    stem, bench_root + "/cpu-load-eval", launch_callback=capture
                )
                receipt["load_recorder_exit_code"] = 0
                if receipt["capture_returncode"] == 0:
                    metadata = json.loads((Path(stem) / "results.json").read_text())
                    require(
                        metadata.get("collection_success") is True,
                        "Collector did not validate successful acquisition",
                    )
                    receipt["overlap"] = overlap(stem + ".load.stdout", stem)
            except BaseException as error:
                if receipt["load_helper_returncode"] is None:
                    receipt["load_helper_returncode"] = getattr(
                        error, "returncode", None
                    )
                receipt.setdefault("load_recorder_exit_code", 1)
                receipt["load_recorder_error"] = f"{type(error).__name__}: {error}"
            finally:
                receipt["coordination_success"] = (
                    receipt["launch_validated"]
                    and receipt["capture_returncode"] == 0
                    and receipt["capture_error"] is None
                    and receipt["load_helper_returncode"] == 0
                    and receipt["load_recorder_error"] is None
                    and receipt["overlap"] is not None
                    and receipt["overlap"]["accepted"]
                )
                json.dump(receipt, summary, indent=2)
                summary.write("\n")
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stem")
    parser.add_argument("--backend", choices=("native", "lgpio"), required=True)
    parser.add_argument("--mode", choices=MODES, required=True)
    parser.add_argument("--bench-root", required=True)
    parser.add_argument("--native-root")
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args(argv)
    result = coordinate(
        args.stem,
        args.backend,
        args.mode,
        args.bench_root,
        args.native_root,
        args.manifest,
    )
    print(
        json.dumps(
            {
                key: result[key]
                for key in (
                    "stem",
                    "backend",
                    "mode",
                    "coordination_success",
                    "capture_returncode",
                    "capture_error",
                    "load_helper_returncode",
                    "load_recorder_error",
                )
            }
        )
    )
    return 0 if result["coordination_success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
