"""Loaded coordination fakes only; never launch SSH, workers or an analyzer."""

import json
import subprocess
from pathlib import Path
from unittest.mock import MagicMock

import capture_pwm_updates_loaded as bench
import pytest
import test_analyze_kernel_pwm_cpu_load as load_fakes

BENCH = "/tmp/blinka-pwm-oct6.F3SDcm"
NATIVE = "/tmp/blinka-pwm-native-updates.abc123"
STEM = "fake-native-frequency-loaded-r1"


@pytest.fixture
def environment(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    manifest = tmp_path / "manifest.json"
    manifest.write_text("{}\n")
    return manifest


def configure(monkeypatch, scenario="success", backend="native"):
    launch, completion, remote = load_fakes.documents()
    remote.update(success=True, gpio18_released=True, low_confirmed=True)
    events = []
    if scenario == "launch_rejected":
        launch["started_worker_count"] = 1
    if scenario == "bad_worker_interval":
        completion["owned_workers"][0]["worker_receipts"][1]["end_ns"] = 1_099_999_999
        load_fakes.sync_stdout(completion["owned_workers"][0])
    if scenario == "not_bracketed":
        remote["phases"][0]["begin_ns"] = 1_050_000_000

    def run(command, **kwargs):
        events.append("capture")
        assert Path(command[1]).name == (
            "capture_native_pwm_updates.py"
            if backend == "native"
            else "capture_kernel_pwm_lgpio_baseline.py"
        )
        assert command[2] == STEM and command[-2:] == ["--mode", "frequency"]
        assert kwargs["timeout"] == 20 and kwargs["check"] is False
        assert kwargs["stdin"] is subprocess.DEVNULL
        kwargs["stdout"].write(b"fake capture output\n")
        kwargs["stderr"].write(b"fake diagnostics\n")
        if scenario == "capture_timeout":
            raise subprocess.TimeoutExpired(command, 20)
        if scenario == "capture_interrupt":
            raise KeyboardInterrupt("fake interrupted capture")
        output = Path(STEM)
        output.mkdir()
        (output / "remote.stdout").write_text(json.dumps(remote) + "\n")
        (output / "results.json").write_text(
            json.dumps({"collection_success": scenario != "collection_failed"}) + "\n"
        )
        return subprocess.CompletedProcess(
            command, 1 if scenario == "capture_exit1" else 0
        )

    def record(stem, root, *, launch_callback):
        assert stem == STEM and root == BENCH + "/cpu-load-eval"
        events.append("load_started")
        try:
            with Path(stem + ".load.stdout").open("x") as output:
                output.write(json.dumps(launch) + "\n")
                output.flush()
                Path(stem + ".load.stderr").write_text("")
                events.append("launch_persisted")
                launch_callback(launch)
                events.append("load_drained")
                output.write(json.dumps(completion) + "\n")
            if scenario == "recorder_error":
                raise bench.recorder.LoadRecordingError("fake actual load exit1", 1)
            return 1 if scenario == "load_exit1" else 0
        finally:
            events.append("load_reaped")

    runner = MagicMock(side_effect=run)
    recorder = MagicMock(side_effect=record)
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(bench.recorder, "record", recorder)
    return events, runner, recorder


@pytest.mark.parametrize("backend", ["native", "lgpio"])
def test_actual_exits_plus_worker_phase_overlap_required_for_success(
    environment, monkeypatch, backend
):
    events, runner, recorder = configure(monkeypatch, backend=backend)
    receipt = bench.coordinate(
        STEM,
        backend,
        "frequency",
        BENCH,
        NATIVE if backend == "native" else None,
        environment if backend == "native" else None,
    )
    assert (
        receipt["coordination_success"] is True and receipt["launch_validated"] is True
    )
    assert receipt["capture_returncode"] == receipt["load_helper_returncode"] == 0
    assert receipt["capture_error"] is None and receipt["load_recorder_error"] is None
    assert receipt["overlap"]["all_phases_bracketed_by_each_worker"] is True
    assert receipt["overlap"]["entire_helper_bracketed_by_each_worker"] is True
    assert receipt["waveform_accepted"] is None and receipt["parity_pass"] is None
    assert events == [
        "load_started",
        "launch_persisted",
        "capture",
        "load_drained",
        "load_reaped",
    ]
    runner.assert_called_once()
    recorder.assert_called_once()
    assert json.loads(Path(STEM + ".updates-coordination.json").read_text()) == receipt


def test_rejected_launch_never_starts_capture_and_still_drains_and_reaps(
    environment, monkeypatch
):
    events, runner, _recorder = configure(monkeypatch, "launch_rejected")
    receipt = bench.coordinate(STEM, "native", "frequency", BENCH, NATIVE, environment)
    runner.assert_not_called()
    assert receipt["launch_validated"] is False and receipt["launch_validation_errors"]
    assert (
        receipt["capture_returncode"] is None
        and receipt["coordination_success"] is False
    )
    assert events == ["load_started", "launch_persisted", "load_drained", "load_reaped"]


@pytest.mark.parametrize(
    "scenario",
    [
        "capture_timeout",
        "capture_interrupt",
        "capture_exit1",
        "collection_failed",
        "load_exit1",
        "recorder_error",
        "bad_worker_interval",
        "not_bracketed",
    ],
)
def test_capture_and_load_failures_preserve_outputs_and_do_not_skip_drain_reap(
    environment, monkeypatch, scenario
):
    events, runner, _recorder = configure(monkeypatch, scenario)
    receipt = bench.coordinate(STEM, "native", "frequency", BENCH, NATIVE, environment)
    assert receipt["coordination_success"] is False
    assert events[-2:] == ["load_drained", "load_reaped"]
    runner.assert_called_once()
    assert Path(STEM + ".capture.stdout").read_bytes() == b"fake capture output\n"
    assert Path(STEM + ".capture.stderr").read_bytes() == b"fake diagnostics\n"
    assert len(Path(STEM + ".load.stdout").read_text().splitlines()) == 2
    if scenario in ("capture_timeout", "capture_interrupt"):
        assert receipt["capture_error"] and receipt["load_helper_returncode"] == 0
    if scenario == "load_exit1":
        assert (
            receipt["load_helper_returncode"] == 1
            and receipt["overlap"]["accepted"] is True
        )
    if scenario in ("collection_failed", "recorder_error", "bad_worker_interval"):
        assert receipt["load_recorder_error"]
    if scenario == "not_bracketed":
        assert receipt["overlap"]["accepted"] is False
        assert receipt["overlap"]["rejection_reasons"]
    assert json.loads(Path(STEM + ".updates-coordination.json").read_text()) == receipt


@pytest.mark.parametrize(
    "field,bad",
    [
        ("stem", "unsafe;command-loaded-r1"),
        ("backend", "other"),
        ("mode", "lifecycle"),
        ("bench_root", "/tmp"),
        ("bench_root", BENCH + "/../other"),
        ("native_root", "/tmp"),
        ("native_root", NATIVE + "/../other"),
        ("manifest", Path("missing.json")),
    ],
)
def test_invalid_parameters_never_launch_or_create_targets(
    environment, monkeypatch, field, bad
):
    runner, recorder = MagicMock(), MagicMock()
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(bench.recorder, "record", recorder)
    args = {
        "stem": STEM,
        "backend": "native",
        "mode": "frequency",
        "bench_root": BENCH,
        "native_root": NATIVE,
        "manifest": environment,
    }
    args[field] = bad
    with pytest.raises(ValueError):
        bench.coordinate(**args)
    runner.assert_not_called()
    recorder.assert_not_called()
    assert not Path(STEM + ".updates-coordination.json").exists()


@pytest.mark.parametrize(
    "suffix",
    [
        "",
        ".load.stdout",
        ".load.stderr",
        ".capture.stdout",
        ".capture.stderr",
        ".updates-coordination.json",
    ],
)
def test_foreign_existing_targets_are_never_overwritten(
    environment, monkeypatch, suffix
):
    runner, recorder = MagicMock(), MagicMock()
    monkeypatch.setattr(bench.subprocess, "run", runner)
    monkeypatch.setattr(bench.recorder, "record", recorder)
    target = Path(STEM + suffix)
    target.write_text("foreign evidence")
    with pytest.raises(ValueError, match="fresh"):
        bench.coordinate(STEM, "native", "frequency", BENCH, NATIVE, environment)
    assert target.read_text() == "foreign evidence"
    runner.assert_not_called()
    recorder.assert_not_called()


def test_dangling_target_and_symlink_manifest_refused(environment, monkeypatch):
    recorder = MagicMock()
    monkeypatch.setattr(bench.recorder, "record", recorder)
    target = Path(STEM + ".load.stdout")
    target.symlink_to("does-not-exist")
    with pytest.raises(ValueError, match="fresh"):
        bench.coordinate(STEM, "native", "frequency", BENCH, NATIVE, environment)
    linked_manifest = environment.with_name("linked-manifest.json")
    linked_manifest.symlink_to(environment)
    with pytest.raises(ValueError, match="manifest"):
        bench.capture_command(
            "another-loaded-r2", "native", "direct", BENCH, NATIVE, linked_manifest
        )
    recorder.assert_not_called()


def test_lgpio_refuses_native_only_arguments(environment):
    with pytest.raises(ValueError, match="no native"):
        bench.capture_command(STEM, "lgpio", "direct", BENCH, NATIVE, environment)
