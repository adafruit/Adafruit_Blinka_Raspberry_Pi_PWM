"""Offline update facts, quantization and evidence validation; no hardware."""

import copy
import json
import struct
import zipfile
from pathlib import Path

import analyze_native_pwm_updates as analysis
import native_pwm_updates_eval as helper
import pytest
import test_native_pwm_updates_eval as helper_fakes

old_environment = helper_fakes.old_environment
environment = helper_fakes.environment
LAB = Path(__file__).parent
ROOT = helper_fakes.ROOT


def protocol_edges(mode, backend="native"):
    stable, _intermediate = analysis.targets(mode, backend)
    edges = []

    def pwm(regime, start, count):
        nominal = stable[regime]
        for index in range(count):
            rise = start + index * nominal["period_us"] / 1e6
            edges.extend((rise, rise + nominal["high_us"] / 1e6))

    if mode == "frequency":
        pwm("servo50_d4915", 0.7, 20)
        pwm("half500_d32768", 1.1, 200)
        pwm("servo50_d4915", 1.5, 20)
        edges.extend((2.1, 3.0))
    elif mode == "direct":
        pwm("servo50_d4915", 0.7, 20)
        edges.extend((1.1, 1.4))
        pwm("servo50_d4915", 1.4185, 19)
        edges.extend((1.7985, 2.0985))
        pwm("half500_d32768", 2.0995, 196)
        edges.extend((2.4915, 3.0915))
        pwm("servo50_d4915", 3.1100, 19)
    else:
        pwm("half50_d32768", 0.7, 20)
        edges.extend((1.1, 1.41))
        pwm("half50_d32768", 1.42, 19)
    return edges


def report(mode, edges=None, backend="native", name="native-first"):
    edges = protocol_edges(mode, backend) if edges is None else edges
    waveform = {"initial_state": 0, "final_state": 0, "edge_count": len(edges)}
    limits = analysis.mode_limits(mode, analysis.read_plan())
    return {
        "capture": name,
        "mode": mode,
        "backend": analysis.BACKEND if backend == "native" else "original-blinka-lgpio",
        "waveform": waveform,
        "physical": analysis.waveform_facts(mode, waveform, edges, backend),
        "caller_updates": [
            {
                "scope": key.split(".PWMOut.")[0],
                "operation": "PWMOut." + key.split(".PWMOut.")[1],
                "caller_duration_us": 1.0,
            }
            for key in limits["caller_max_us"]
        ],
        "phase_api_update_durations_us": [],
    }


@pytest.mark.parametrize(
    "frequency,duty,expected_high,expected_low",
    [
        (50, 4915, 1499.962, 18500.038),
        (500, 4915, 149.996, 1850.004),
        (500, 32768, 1000.015, 999.985),
        (50, 32768, 10000.153, 9999.847),
    ],
)
def test_actual_native_targets_follow_integer_c_formula(
    frequency, duty, expected_high, expected_low
):
    nominal = analysis.target(frequency, duty, "native")
    assert nominal["high_us"] == expected_high
    assert nominal["low_us"] == pytest.approx(expected_low)
    assert nominal["native_rounded_high_ns"] == round(expected_high * 1000)


def test_correct_native_servo_width_is_not_original_integer_percent_anomaly():
    native = report("frequency")
    original = report("frequency", backend="original", name="baseline-first")
    for item in (native, original):
        stats = item["physical"]["target_normalized_statistics"]["servo50_d4915"]
        assert stats["max_absolute_high_target_error_us"] == pytest.approx(0, abs=1e-8)
        assert not item["physical"]["unmatched_high_runs"]
    assert (
        native["physical"]["nominal_stable_targets"]["servo50_d4915"]["high_us"]
        == 1499.962
    )
    assert (
        original["physical"]["nominal_stable_targets"]["servo50_d4915"]["high_us"]
        == 1400
    )
    requested = analysis.target(50, 4915, "native")["common_requested_u16_high_us"]
    assert requested == pytest.approx(1499.9618524452583)
    assert original["physical"]["target_normalized_statistics"]["servo50_d4915"][
        "common_requested_error_us"
    ]["mean"] == pytest.approx(1400 - requested)
    assert not analysis.provisional_checks(native)["flags_to_investigate"]


@pytest.mark.parametrize("mode", analysis.MODES)
def test_protocol_keeps_every_high_low_and_boundary(mode):
    edges = protocol_edges(mode)
    result = report(mode, edges)
    physical = result["physical"]
    assert result["waveform"]["transition_seconds"] == edges
    assert len(physical["all_high_runs"]) * 2 == len(edges)
    assert len(physical["all_interior_low_runs"]) == len(edges) // 2 - 1
    assert len(physical["all_adjacent_rise_intervals"]) == len(edges) // 2 - 1
    assert physical["no_transition_trimming_or_glitch_filtering"]
    assert physical[
        "regime_assignment_is_waveform_only_not_phase_or_command_association"
    ]
    assert not analysis.provisional_checks(result)["flags_to_investigate"]


@pytest.mark.parametrize(
    "regime,width_us",
    [("intermediate500_d4915", 149.996), ("intermediate50_d32768", 10000.153)],
)
def test_near_intermediate_widths_are_separate_before_stable_assignment(
    regime, width_us
):
    edges = protocol_edges("frequency")
    pair_index = 20 if regime == "intermediate500_d4915" else 220
    edges[2 * pair_index + 1] = edges[2 * pair_index] + width_us / 1e6
    result = report("frequency", edges)
    item = result["physical"]["all_high_runs"][pair_index]
    assert item["diagnostic_regime"] == regime
    assert item["width_bin"] == regime
    assert item["regime_assignment"] == "near_intermediate_width_not_command_proof"
    assert result["physical"]["intermediate_width_high_runs"] == [item]
    assert result["waveform"]["transition_seconds"] == edges
    stats = result["physical"]["target_normalized_statistics"]
    assert stats[regime]["high_count"] == 1
    if regime == "intermediate500_d4915":
        assert stats["half500_d32768"]["high_count"] == 199
    else:
        assert stats["servo50_d4915"]["high_count"] == 39
    assert (
        "observed_regime_topology"
        in analysis.provisional_checks(result)["flags_to_investigate"]
    )


def test_anomalous_boundary_width_is_included_not_filtered_from_nearest_regime():
    edges = protocol_edges("frequency")
    edges[39] = edges[38] + 1540e-6
    result = report("frequency", edges)
    item = result["physical"]["unmatched_high_runs"][0]
    assert item["pair_index"] == 19 and item["diagnostic_regime"] == "servo50_d4915"
    stats = result["physical"]["target_normalized_statistics"]["servo50_d4915"]
    assert stats["high_count"] == 40
    assert stats["max_absolute_high_target_error_us"] == pytest.approx(40.038)
    assert stats["all_high_us"]["max"] == pytest.approx(1540)
    assert result["waveform"]["transition_seconds"] == edges


def test_10ns_hold_dip_splits_holds_and_survives_all_statistics():
    edges = protocol_edges("frequency")
    edges[-1:-1] = [2.5, 2.50000001]
    result = report("frequency", edges)
    assert len(result["physical"]["constant_high_holds"]) == 2
    assert result["physical"]["sub_microsecond_low_runs"][0][
        "width_ns"
    ] == pytest.approx(10)
    assert result["waveform"]["transition_seconds"] == edges
    flags = analysis.provisional_checks(result)["flags_to_investigate"]
    assert "continuous_high_count" in flags and "sub_microsecond_low_count" in flags


def test_per_operation_caller_flags_cannot_be_mistaken_for_electrical_latency():
    result = report("frequency")
    result["caller_updates"][1]["caller_duration_us"] = 18.661
    checked = analysis.provisional_checks(result)
    assert checked["flags_to_investigate"] == ["pwm500_d32768.PWMOut.frequency"]
    check = next(
        item
        for item in checked["checks"]
        if item["name"] == checked["flags_to_investigate"][0]
    )
    assert check["domain"] == "caller_return_not_electrical_latency"


@pytest.fixture
def capture(environment, tmp_path):
    _state, _guard, _module, manifest, _sleeps = environment
    mode = "frequency"
    receipt = helper.experiment(mode, ROOT + "/manifest.json")
    metadata = {
        "schema_version": 1,
        "host": "test-pi5.local",
        "mode": mode,
        "backend": analysis.BACKEND,
        "sequence_marker": f"native-updates-{mode}-v1",
        "sample_rate_hz": 100_000_000,
        "production_backend_unchanged": True,
        "outputs": [{"gpio": 18, "saleae_channel": 0, "backend": analysis.BACKEND}],
        "remote": receipt,
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "collection_success": True,
        "waveform_accepted": None,
        "parity_pass": None,
        "parity_evaluated": False,
    }
    acquisition = {
        "mode": mode,
        "backend": analysis.BACKEND,
        "remote_root": ROOT,
        "remote_returncode": 0,
        "pre_helper_lead_seconds": 0.5,
        "post_helper_tail_seconds": 0.2,
        "local_timing_not_aligned_to_pi_or_saleae": True,
        "primary_error": None,
        "evidence_errors": [],
    }
    for name, value in (
        ("manifest.json", manifest),
        ("results.json", metadata),
        ("remote.stdout", receipt),
        ("acquisition.json", acquisition),
    ):
        (tmp_path / name).write_text(json.dumps(value))
    sal = {
        "data": {
            "legacySettings": {
                "enabledChannels": [{"type": "Digital", "index": 0}],
                "sampleRate": {"digital": 100_000_000},
                "glitchFilter": {"enabled": False, "channels": []},
            },
            "legacyDevice": {"isSimulation": False, "deviceId": "81F8C2631DF5BF30"},
        }
    }
    with zipfile.ZipFile(tmp_path / "waveform.sal", "w") as archive:
        archive.writestr("meta.json", json.dumps(sal))
    edges = protocol_edges(mode)
    (tmp_path / "digital_0.bin").write_bytes(
        b"<SALEAE>"
        + struct.pack("<iiIddQ", 0, 0, 0, 0.0, 3.4, len(edges))
        + struct.pack(f"<{len(edges)}d", *edges)
    )
    return tmp_path, edges


def test_raw_native_capture_validates_manifest_receipts_and_api_difference(capture):
    directory, edges = capture
    result = analysis.analyze(directory)
    assert result["waveform"]["transition_seconds"] == edges
    assert len(result["source_manifest"]["source_sha256"]) == 7
    assert (
        result["variable_frequency"] is True
        and result["variable_frequency_differs_from_original"] is True
    )
    assert (
        len(result["caller_updates"]) == 10
        and len(result["phase_api_update_durations_us"]) == 9
    )
    assert "no command-to-edge latency claim" in result["clock_alignment"]
    assert not result["provisional_comparison"]["flags_to_investigate"]
    assert "parity_pass" not in result and "accepted" not in result
    assert not (directory / "analysis.json").exists()


@pytest.mark.parametrize(
    "file,key,value,match",
    [
        ("results.json", "collection_success", False, "successful native collection"),
        ("results.json", "remote_returncode", True, "successful native collection"),
        (
            "results.json",
            "sequence_marker",
            "native-half50-direct-v1",
            "successful native collection",
        ),
        ("acquisition.json", "primary_error", "failed", "acquisition failed"),
        ("acquisition.json", "evidence_errors", ["missing raw"], "acquisition failed"),
        ("acquisition.json", "remote_root", "/tmp/wrong", "root/lead/tail"),
    ],
)
def test_failed_evidence_is_not_promoted_to_waveform_success(
    capture, file, key, value, match
):
    directory, _edges = capture
    data = json.loads((directory / file).read_text())
    data[key] = value
    (directory / file).write_text(json.dumps(data))
    with pytest.raises(ValueError, match=match):
        analysis.analyze(directory)


def test_manifest_remote_mismatch_and_relaxed_plan_are_rejected(capture):
    directory, _edges = capture
    plan = json.loads((LAB / analysis.PLAN_NAME).read_text())
    plan["provisional_checks"]["frequency"]["edge_count_inclusive"] = [0, 100000]
    path = directory / "relaxed-plan.json"
    path.write_text(json.dumps(plan))
    with pytest.raises(ValueError, match="Frozen updates plan"):
        analysis.analyze(directory, path)
    manifest = json.loads((directory / "manifest.json").read_text())
    manifest["source_sha256"][helper.base.PACKAGE + "/_native.so"] = "b" * 64
    (directory / "manifest.json").write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="Exact manifest"):
        analysis.analyze(directory)


def test_in_memory_limit_override_is_rejected_too():
    plan = analysis.read_plan()
    plan["provisional_checks"]["frequency"]["edge_count_inclusive"] = [0, 100000]
    with pytest.raises(ValueError, match="match the frozen plan"):
        analysis.provisional_checks(report("frequency"), plan)


@pytest.mark.parametrize("mode", ["frequency", "direct"])
def test_all_four_original_reports_replay_exactly_with_anomalies_in_normalized_statistics(
    mode,
):
    plan = analysis.read_plan()
    originals = []
    for name in plan["baseline_captures"][mode]:
        old = analysis.analyze_baseline(LAB / name)
        authoritative = (
            "analysis-rounding-corrected.json"
            if name == "oct6-pi5-lgpio-baseline-direct"
            else "analysis.json"
        )
        assert old == json.loads((LAB / name / authoritative).read_text())
        current = analysis.original_report(LAB / name)
        assert current["original_diagnostic_bins"] == old["physical"]
        assert (
            current["waveform"]["transition_seconds"]
            == old["waveform"]["transition_seconds"]
        )
        assert sum(
            item["high_count"]
            for item in current["physical"]["target_normalized_statistics"].values()
        ) == len(old["physical"]["all_high_runs"]) - len(
            old["physical"]["constant_high_holds"]
        )
        assert not analysis.provisional_checks(current, plan)["flags_to_investigate"]
        originals.append(current)
    first = report(mode)
    second = copy.deepcopy(first)
    second["capture"] = "native-repeat"
    paired = analysis.compare_paired([first, second], originals, plan)
    assert paired["overall_backend_parity_established"] is False
    assert paired["electrical_command_latency_measured"] is False
    assert paired["loaded_overlap_not_verified_by_this_analyzer"] is True
