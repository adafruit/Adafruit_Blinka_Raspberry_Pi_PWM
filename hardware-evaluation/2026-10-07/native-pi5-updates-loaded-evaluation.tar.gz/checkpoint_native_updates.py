"""Exclusive recovery archive and byte-for-byte/replay verification, no hardware."""

import hashlib
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

LAB = Path(__file__).resolve().parent
REPO = LAB.parent / "Adafruit_Blinka_Raspberry_Pi_PWM"
ARCHIVE = (
    REPO / "hardware-evaluation/2026-10-07/native-pi5-updates-loaded-evaluation.tar.gz"
)
CAPTURES = [
    f"oct7-pi5-native-updates-{mode}-r{repeat}"
    for mode in ("frequency", "direct")
    for repeat in (1, 2)
] + [
    f"oct7-pi5-{backend}-updates-{mode}-loaded-r{repeat}"
    for backend in ("native", "lgpio")
    for mode in ("frequency", "direct", "half50-direct")
    for repeat in (1, 2)
]
BASELINES = [
    f"oct6-pi5-lgpio-baseline-{mode}{suffix}"
    for mode in ("frequency", "direct", "half50-direct")
    for suffix in ("", "-r2")
]
SOURCES = [
    "native_pwm_updates_eval.py",
    "capture_native_pwm_updates.py",
    "analyze_native_pwm_updates.py",
    "capture_pwm_updates_loaded.py",
    "record_native_updates_postflight.py",
    "checkpoint_native_updates.py",
    "test_native_pwm_updates_eval.py",
    "test_capture_native_pwm_updates.py",
    "test_analyze_native_pwm_updates.py",
    "test_capture_pwm_updates_loaded.py",
    "native_pwm_half50_eval.py",
    "capture_native_pwm_half50.py",
    "test_native_pwm_half50_eval.py",
    "test_capture_native_pwm_half50.py",
    "kernel_pwm_lgpio_baseline_eval.py",
    "capture_kernel_pwm_lgpio_baseline.py",
    "analyze_kernel_pwm_lgpio_baseline.py",
    "test_kernel_pwm_lgpio_baseline_eval.py",
    "test_capture_kernel_pwm_lgpio_baseline.py",
    "test_analyze_kernel_pwm_lgpio_baseline.py",
    "baseline_pwmout.py",
    "lgpio_pin.py",
    "kernel_pwm_eval.py",
    "capture_pwm.py",
    "analyze_kernel_pwm_inverse.py",
    "kernel_pwm_cpu_load_eval.py",
    "record_kernel_pwm_cpu_load.py",
    "capture_kernel_pwm_loaded.py",
    "analyze_kernel_pwm_cpu_load.py",
    "test_record_kernel_pwm_cpu_load.py",
    "test_capture_kernel_pwm_loaded.py",
    "test_analyze_kernel_pwm_cpu_load.py",
    "oct7-native-updates-plan.json",
    "oct7-native-updates-manifest.json",
    "oct7-native-half50-plan.json",
    "oct7-native-half50-runtime",
    "oct7-native-updates-postflight.json",
    "oct7-native-updates-postflight.json.stdout",
    "oct7-native-updates-postflight.json.stderr",
    "oct7-native-updates-loaded-independent-audit.json",
    "oct7-native-updates-frequency-comparison.json",
    "oct7-native-updates-direct-comparison.json",
] + [
    f"oct7-native-updates-{mode}-loaded-comparison.json"
    for mode in ("frequency", "direct", "half50-direct")
]
SIDECARS = [
    name + suffix
    for name in CAPTURES
    if "-loaded-" in name
    for suffix in (
        ".load.stdout",
        ".load.stderr",
        ".capture.stdout",
        ".capture.stderr",
        ".updates-coordination.json",
    )
]
TARGETS = CAPTURES + BASELINES + SOURCES + SIDECARS

REPLAY = r"""
import json, pathlib, sys
sys.path.insert(0, sys.argv[1])
import checkpoint_native_updates as checkpoint
import analyze_native_pwm_updates as analysis
import analyze_kernel_pwm_lgpio_baseline as original
import capture_pwm_updates_loaded as coordinator
root = pathlib.Path(sys.argv[1])
same = lambda actual, path: actual == json.loads(path.read_text())
reports = {}
for name in checkpoint.CAPTURES:
    directory = root/name
    report = (analysis.analyze(directory) if "-native-" in name else original.analyze(directory))
    assert same(report, directory/"analysis.json"), name
    reports[name] = report
    if "-loaded-" in name:
        receipt = json.loads((root/(name+".updates-coordination.json")).read_text())
        assert receipt["coordination_success"] is True, name
        assert coordinator.overlap(root/(name+".load.stdout"), directory) == receipt["overlap"], name
for mode in ("frequency", "direct", "half50-direct"):
    for suffix in (("", "-loaded") if mode != "half50-direct" else ("-loaded",)):
        native = [reports[f"oct7-pi5-native-updates-{mode}{suffix}-r{r}"] for r in (1,2)]
        baselines = ([root/f"oct7-pi5-lgpio-updates-{mode}-loaded-r{r}" for r in (1,2)]
                     if suffix else [root/f"oct6-pi5-lgpio-baseline-{mode}{s}" for s in ("", "-r2")])
        paired = analysis.compare_paired(native, [analysis.original_report(path) for path in baselines])
        assert same(paired, root/f"oct7-native-updates-{mode}{suffix}-comparison.json"), mode+suffix
print(json.dumps({"reports_reproduced":16, "paired_reports_reproduced":5,
                  "load_overlap_receipts_reproduced":12}))
"""


def main():
    if len(TARGETS) != len(set(TARGETS)):
        raise ValueError("Duplicate archive target")
    regular = {}
    for name in TARGETS:
        path = LAB / name
        if not path.exists() or path.is_symlink():
            raise ValueError("Missing or linked target: " + name)
        for member in [path] if path.is_file() else sorted(path.rglob("*")):
            if member.is_symlink() or not (member.is_file() or member.is_dir()):
                raise ValueError("Unsupported source member: " + str(member))
            if member.is_file():
                regular[str(member.relative_to(LAB))] = hashlib.sha256(
                    member.read_bytes()
                ).hexdigest()
    with (
        ARCHIVE.open("xb") as stream,
        tarfile.open(fileobj=stream, mode="w:gz") as archive,
    ):
        for name in TARGETS:
            archive.add(LAB / name, arcname=name)
    extracted = Path(
        tempfile.mkdtemp(prefix="blinka-native-updates-checkpoint-", dir="/private/tmp")
    )
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if (
                path.is_absolute()
                or ".." in path.parts
                or not (member.isfile() or member.isdir())
            ):
                raise ValueError("Unsafe archive member: " + member.name)
        archive.extractall(extracted, filter="data")
    recovered = {
        str(path.relative_to(extracted)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in extracted.rglob("*")
        if path.is_file()
    }
    if recovered != regular:
        raise ValueError("Archive membership/bytes differ from inspected sources")
    result = subprocess.run(
        [sys.executable, "-c", REPLAY, str(extracted)],
        cwd=extracted,
        capture_output=True,
        text=True,
        check=True,
    )
    report = {
        "archive": str(ARCHIVE),
        "size_bytes": ARCHIVE.stat().st_size,
        "sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        "top_level_targets": len(TARGETS),
        "regular_files": len(regular),
        "safe_extraction": str(extracted),
        "all_file_bytes_match": True,
        "replay": json.loads(result.stdout),
        "replay_stderr": result.stderr,
    }
    with (LAB / "oct7-native-updates-checkpoint-verification.json").open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
